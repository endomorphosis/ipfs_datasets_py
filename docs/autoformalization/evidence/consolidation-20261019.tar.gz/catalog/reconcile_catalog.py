"""One-off document reconciliation; no product imports, controllers or live-state access.

Reads the frozen revision01 catalog and the reviewed documentation preparation
manifest. It retains original observations and appends prospective relocation
information. An optional explicit qualification receipt is attached as evidence
for root review; it never silently promotes or installs a candidate.
"""
from __future__ import annotations
import argparse,copy,datetime,hashlib,json,posixpath,re
from pathlib import Path
MAX=2*1024*1024


def read(path):
 path=Path(path)
 if path.is_symlink() or not path.is_file() or path.stat().st_size>MAX:
  raise ValueError('Input must be an ordinary bounded file')
 raw=path.read_bytes()
 if len(raw)>MAX:raise ValueError('Input exceeds byte bound')
 return raw


def parse(raw):
 def unique(pairs):
  out={}
  for k,v in pairs:
   if k in out:raise ValueError('Duplicate JSON key')
   out[k]=v
  return out
 return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda s:(_ for _ in ()).throw(ValueError('nonfinite JSON')))


def reference(path):
 if path.startswith('../../artifacts/'):
  return {'root':'artifact_workspace','path':path[len('../../artifacts/'):]}
 if path.startswith(('docs/','ipfs_datasets_py/','tests/','scripts/')):
  return {'root':'datasets_repository','path':path}
 raise ValueError('Unsupported nonportable locator: '+path)


def attach_qualification_receipt(catalog, *, receipt_raw, expected_sha256, receipt_reference):
 """Attach exact reviewed bytes; root still decides qualification/installation."""
 if hashlib.sha256(receipt_raw).hexdigest()!=expected_sha256:
  raise ValueError('Qualification receipt digest differs')
 if set(receipt_reference)!={'root','path'} or receipt_reference['root'] not in ('datasets_repository','artifact_workspace'):
  raise ValueError('Portable qualification reference required')
 p=Path(receipt_reference['path'])
 if p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe qualification reference')
 receipt=parse(receipt_raw)
 row=next(x for x in catalog['known_artifact_only_work'] if x['id']=='full_norm_consequences')
 row['canonical_port_qualification']={'status':'receipt_supplied_pending_owner_review','receipt':receipt_reference,
  'receipt_sha256':expected_sha256,'receipt_bytes':len(receipt_raw),
  'reported_schema':receipt.get('schema',receipt.get('schema_version')),
  'reported_passed':receipt.get('passed'),'automatic_admission_performed':False,
  'reason':'Root must verify exact source, test scope, native closeout and installation before advancing disposition.'}
 return catalog


def reconcile(catalog, docs_manifest, *, docs_manifest_raw, previous_catalog_raw):
 result=copy.deepcopy(catalog)
 changes={x['path']:x for x in docs_manifest['changes']}
 redirects={x['source_path']:x for x in docs_manifest['changes'] if x['kind']=='compatibility_redirect'}
 mapping=docs_manifest['mapping']
 relocation=[]
 for old,new in sorted(mapping.items()):
  row=changes[new]
  redirect=redirects.get(old)
  source_digest=redirect['preimage']['sha256'] if redirect and redirect.get('preimage') else None
  relocation.append([reference(old),reference(new),source_digest,row['candidate']['sha256'],row['candidate']['bytes'],'relocated_guide'])
 recovered=docs_manifest.get('historical_recovery',{})
 recovered_sources={x['repository_relative_source']:x for x in recovered.get('sources',[])}
 for old,new in sorted(recovered.get('mapping',{}).items()):
  row=changes[new];original=recovered_sources[old]
  relocation.append([reference(old),reference(new),original['sha256'],row['candidate']['sha256'],row['candidate']['bytes'],
   'recovered_historical_evidence_json' if new.endswith('.json') else 'recovered_historical_guide'])
 result['documentation_reconciliation']={
  'prepared_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'status':'prepared_pending_owner_installation',
  'previous_catalog_sha256':hashlib.sha256(previous_catalog_raw).hexdigest(),
  'previous_catalog_observed_at_utc':catalog['observed_at_utc'],
  'original_observations_preserved':True,
  'docs_preparation_manifest':{'sha256':hashlib.sha256(docs_manifest_raw).hexdigest(),'bytes':len(docs_manifest_raw),
   'schema':docs_manifest['schema'],'observed_at_utc':docs_manifest['observed_at_utc'],
   'custody':'Root-held consolidation preparation manifest; actual installation receipt supplies the final durable location.'},
  'relocation_table_columns':['original_reference','prospective_landing_reference','original_sha256','prepared_candidate_sha256','prepared_candidate_bytes','kind'],
  'relocation_table':relocation,
  'historical_recovery_bytes':recovered.get('historical_source_bytes'),
  'preservation':'Historical source/result identities remain attributed to their original producer. Recovered JSON retains exact original bytes; guide bodies differ only by recorded link/provenance changes.',
  'installation_verified':False,'resource_or_model_actions_performed':False}
 prospective=[]
 for row in result['canonical_pipeline']:
  refs={k:(reference(mapping[x['path']]) if x['root']=='datasets_repository' and x['path'] in mapping else x) for k,x in row['files'].items()}
  prospective.append({'id':row['id'],'files':refs})
 result['prospective_pipeline_landing_paths']={'status':'Prepared documentation destinations only; implementation references retain existing owners. Original path/hash observations remain unchanged.','rows':prospective}
 for row in result['known_artifact_only_work']:
  row.pop('qualification_receipt',None);row.pop('qualification_missing_reason',None)
  row['historical_engineering_results']='Original engineering qualifications, profiles, cohorts and experiment outcomes remain retained in their original receipts; this consolidation neither erases nor reruns them.'
  row['canonical_port_qualification']={'status':'not_started','receipt':None,'reason':'No qualification receipt for this newly ported canonical profile has been supplied to this catalog.'}
  if row['id']=='full_norm_consequences':
   row['disposition']='migration_prepared_pending_validation'
   row['reason']='Reusable extraction prepared in the existing autoformal owner. Thirteen new cases plus one existing regression are planned; no executed result is inferred.'
   row['planned_validation']={'new_cases':13,'existing_regressions':1,'total_selected':14,'executed_result':None,'reason':'Owning worker will reconcile actual retained qualification and installation receipts.'}
   row['proposed_documentation']=reference('docs/autoformalization/legal_full_norm_consequences_v1.md')
  elif row['id']=='parent_native':
   row['canonical_port_qualification']['reason']='Staged candidate still requires its own retained validation and installation receipts; separate real native Lean qualification remains necessary.'
  else:
   row['canonical_port_qualification']['reason']='A versioned product port is not yet qualified. Historical experimental engineering qualifications retain their original scope and authority.'
 for row in result['shallow_artifact_directories']:
  if row['reference']['path']=='legal-ir-full-norm-native-20261017-01':
   # Preserve the shallow directory observation; append the later preparation status.
   row['later_migration_disposition']='migration_prepared_pending_validation'
 result['remaining_known_not_migrated'][0]='Prepared full-norm consequences extraction awaits its exact fourteen-case qualification and installation receipts; original historical engineering evidence remains preserved.'
 return result


def rewrite_guide(text, mapping):
 def link(match):
  target=match.group(1)
  path,sep,anchor=target.partition('#')
  if not path or '://' in path:return match.group(0)
  absolute=posixpath.normpath(posixpath.join('docs/autoformalization',path))
  if absolute not in mapping:return match.group(0)
  new=posixpath.relpath(mapping[absolute],'docs/autoformalization')
  return ']('+new+(sep+anchor if sep else '')+')'
 text=re.sub(r'\]\(([^)]+)\)',link,text)
 text=text.replace('Reusable extraction is being prepared as `logic/autoformal/legal_full_norm_consequences_v1.py`. It remains **migration required** until the owning worker records exact validation and installation receipts.',
 'Reusable extraction is prepared as `logic/autoformal/legal_full_norm_consequences_v1.py`, with [its guide](legal_full_norm_consequences_v1.md). It remains **prepared, pending validation**: 13 new cases and one existing regression are selected; the owning worker must record the actual validation and installation receipts.')
 text=text.replace('Parent shared/incremental composition and qualified human source, meaning,',
 'The original engineering qualifications and experiment results for the gated\nand journal profiles remain valid evidence for their original versions and\ncohorts. Their **new canonical-port qualification has not started**; this does\nnot erase or downgrade the historical runs. No old checkpoint or result is\nimplicitly adopted as a production default.\n\nParent shared/incremental composition and qualified human source, meaning,')
 text=text.replace('## What remains evidence',
 'The documentation relocation table in the catalog records 51 guide moves and\nrecovery of seven historical guides plus three exact-byte evidence JSON files.\nThese are prepared destinations until the owning installation receipt is\nrecorded. Original catalog observations keep their original timestamp and\nhashes; the later relocation table supplies the prospective locations.\n\n## What remains evidence')
 return text


def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--base-directory',type=Path,default=Path(__file__).parent)
 parser.add_argument('--docs-manifest',type=Path,required=True)
 args=parser.parse_args()
 base=args.base_directory.resolve()
 # This preparation tool writes only its private catalog staging directory.
 if base.name!='catalog_stage':raise ValueError('Expected private catalog_stage output')
 original=read(base/'revision01/work_inventory.json');manifest_raw=read(args.docs_manifest)
 docs=parse(manifest_raw);result=reconcile(parse(original),docs,docs_manifest_raw=manifest_raw,previous_catalog_raw=original)
 guide=rewrite_guide(read(base/'revision01/MIGRATION.md').decode(),docs['mapping'])
 wire=json.dumps(result,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n'
 if '/home/' in wire:raise ValueError('Nonportable home path in catalog')
 (base/'work_inventory.json').write_text(wire)
 (base/'MIGRATION.md').write_text(guide)
 print(json.dumps({'work_inventory.json':{'bytes':len(wire.encode()),'sha256':hashlib.sha256(wire.encode()).hexdigest()},'MIGRATION.md':{'bytes':len(guide.encode()),'sha256':hashlib.sha256(guide.encode()).hexdigest()},'relocations':len(result['documentation_reconciliation']['relocation_table'])},indent=2))

if __name__=='__main__':main()
