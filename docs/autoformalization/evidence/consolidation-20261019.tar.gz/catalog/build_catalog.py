"""One-off bounded, stdlib-only documentation catalog; never imports product code."""
from pathlib import Path
import csv, json, os, stat, hashlib, collections, datetime, re
WS=Path('/home/barberb/lift_coding')
REPO=WS/'external/ipfs_datasets'
ART=WS/'artifacts'
OUT=Path('/tmp/legal-ir-consolidation-20261019T201000Z/catalog_stage')
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
PREFIXES=('legal-','uscode-','gte-','source-span-')
LAND='docs/autoencoders/evidence/legal-ir-text-to-lean4-plan-20261018T221630Z/reuse-landing-map.csv'
REG='docs/autoencoders/evidence/legal-ir-four-dimension-reuse-20261018.json'
AUDIT='legal-ir-reuse-and-landing-audit-20261018T223853Z'
STAGES=('decoder-completion-staging','formula-decoder-staging','learned-formula-staging','lineage-followup-staging','lineage-side-by-side-staging','logic-floor-staging')
MAX_READ=4*1024*1024
MAX_SHALLOW=256*1024
SHALLOW_BUDGET=32*1024*1024
shallow_bytes=0
cache={}

def ref(path):
 p=Path(path)
 if not p.is_absolute():
  s=str(p)
  if s.startswith('external/ipfs_datasets/'): return {'root':'datasets_repository','path':s[len('external/ipfs_datasets/'):]}
  if s.startswith('artifacts/'): return {'root':'artifact_workspace','path':s[len('artifacts/'):]}
  return {'root':'datasets_repository','path':s}
 try:return {'root':'datasets_repository','path':str(p.relative_to(REPO))}
 except ValueError: pass
 try:return {'root':'artifact_workspace','path':str(p.relative_to(ART))}
 except ValueError: return None

def portable(value):
 if isinstance(value,dict):return {k:portable(v) for k,v in value.items()}
 if isinstance(value,list):return [portable(v) for v in value]
 if isinstance(value,str):
  if value.startswith(str(REPO)+'/') or value.startswith(str(ART)+'/'):return ref(value)
  if value.startswith('external/ipfs_datasets/') or value.startswith('artifacts/'):return ref(value)
  # Keep prose while replacing embedded host paths with named roots.
  value=value.replace(str(REPO)+'/','datasets_repository:').replace(str(ART)+'/','artifact_workspace:')
  if '/home/' in value:return re.sub(r'/home/[^\s,;\]\)"\']+', '[historical external locator; consult hashed original report]',value)
  return value
 return value

def safe_file(p,limit=MAX_READ):
 p=Path(p)
 r={'reference':ref(p),'exists':False,'kind':None,'bytes':None,'sha256':None,'reason':None}
 try:
  st=p.lstat();r.update(exists=True,kind='regular_file' if stat.S_ISREG(st.st_mode) else 'symlink' if stat.S_ISLNK(st.st_mode) else 'other')
  if not stat.S_ISREG(st.st_mode):r['reason']='not an ordinary file; not followed';return r
  r['bytes']=st.st_size
  if st.st_size>limit:r['reason']='file exceeds declared byte bound; contents not opened';return r
  # Every selected ancestor must be ordinary, so a parent symlink is not followed.
  boundary=REPO if REPO in p.parents else ART
  par=p.parent
  while par!=boundary:
   if stat.S_ISLNK(par.lstat().st_mode):r['reason']='symlink ancestor; not followed';return r
   par=par.parent
  with p.open('rb') as stream:data=stream.read(limit+1)
  post=p.lstat()
  if len(data)>limit or (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)!=(post.st_dev,post.st_ino,post.st_size,post.st_mtime_ns):r['reason']='changed during bounded read';return r
  r['sha256']=hashlib.sha256(data).hexdigest();r['reason']=None
  return r
 except FileNotFoundError:r['reason']='not present at observation';return r
 except OSError as exc:r['reason']='filesystem observation failed: '+type(exc).__name__;return r

def current(rel):
 if rel not in cache:cache[rel]=safe_file(REPO/rel)
 return cache[rel]

def read_json(p):
 obs=safe_file(p);assert obs['sha256'] is not None,obs
 return json.loads(Path(p).read_text()),obs

landing=list(csv.DictReader((REPO/LAND).open()))
assert len(landing)==132
register,register_obs=read_json(REPO/REG)
reports={};inputs=[safe_file(REPO/LAND),register_obs]
for name in ('source-reuse','graph-lean-reuse','model-reuse'):
 reports[name],obs=read_json(ART/AUDIT/(name+'.json'));inputs.append(obs)
assert sum(len(r['capabilities']) for r in reports.values())==54

# Reuse exact historical selected map, and preserve all historical columns.
landing_rows=[]
for row in landing:
 obs=current(row['path'])
 landing_rows.append({'reference':ref(row['path']),'historical_report':row,'current_observation':obs,
  'equals_historical_working_sha256':obs['sha256']==row['sha256'] if obs['sha256'] else None,
  'current_disposition':'canonical_present' if obs['sha256'] else 'migration_required',
  'qualification_reexecuted':False})

# Only explicit canonical source/test/doc paths in prior capability reports are refreshed.
def canonical_refs(value):
 found=set()
 def visit(v):
  if isinstance(v,dict):
   for x in v.values():visit(x)
  elif isinstance(v,list):
   for x in v:visit(x)
  elif isinstance(v,str):
   prefix='external/ipfs_datasets/'
   if v.startswith(str(REPO)+'/'):s=v[len(str(REPO))+1:]
   elif v.startswith(prefix):s=v[len(prefix):]
   elif v.startswith(('ipfs_datasets_py/','tests/','docs/','scripts/')):s=v
   else:return
   if s.endswith(('.py','.md')) and not s.startswith(('docs/implementation/reports/evidence/','workspace/')):found.add(s)
 visit(value);return sorted(found)
capabilities=[]
for name,report in reports.items():
 for i,row in enumerate(report['capabilities'],1):
  refs=canonical_refs(row)
  capabilities.append({'id':row.get('id',f'M{i:02d}'),'historical_report_source':ref(ART/AUDIT/(name+'.json')),
   'historical_report':portable(row),'current_canonical_observations':[current(x) for x in refs],
   'fresh_semantic_or_runtime_qualification':False})

PIPELINE=[
 ('plaintext_source','legal_parent_text_views','legal_parent_text_views','legal_parent_source_inventory_v1'),
 ('retained_parent_inventory','legal_parent_source_inventory_v1','legal_parent_source_inventory_v1','legal_parent_source_inventory_v1'),
 ('source_metadata','legal_parent_parquet_pages','legal_parent_complete_metadata','legal_parent_complete_source_metadata'),
 ('span_entity_join','legal_source_span_entity_join_v1','legal_source_span_entity_join_v1','legal_source_span_entity_join_v1'),
 ('entity_census','legal_source_span_entity_census_v1','legal_source_span_entity_census_v1','legal_source_span_entity_census_v1'),
 ('graph','legal_semantic_graph','plaintext_graph_custody','legal_relational_graph_v1'),
 ('definition','legal_source_definition_bridge_v2','plaintext_definition_custody','legal_source_definition_v2'),
 ('norm_definition','legal_source_definition_norm_bridge','legal_source_definition_norm_bridge','legal_corpus_definition_norm_adapter'),
 ('scoped_lookup','scoped_definition_resolution','parent_scoped_definition_resolution','scoped_definition_resolution'),
 ('combined_use','corpus_definition_use_v2','plaintext_definition_use','corpus_definition_use_v2'),
 ('combined_review','corpus_definition_use_review_v2','plaintext_definition_use_review','corpus_definition_use_review_v2'),
 ('lake_project','legal_corpus_definition_use_lake_v2','plaintext_definition_use_lake','legal_corpus_definition_use_lake_v2'),
 ('native_receipt','legal_corpus_definition_use_native_v2','plaintext_definition_use_native','legal_corpus_definition_use_native_v2'),
 ('shared_corpus','legal_corpus_shared_lake','legal_corpus_shared_lake','legal_corpus_shared_lake'),
 ('incremental_corpus','legal_corpus_incremental','legal_corpus_incremental','legal_corpus_incremental'),
]
pipeline=[]
for name,src,test,doc in PIPELINE:
 paths={'implementation':f'ipfs_datasets_py/logic/autoformal/{src}.py','test':f'tests/unit/logic/autoformal/test_{test}.py','documentation':f'docs/autoencoders/{doc}.md'}
 pipeline.append({'id':name,'files':{k:current(v) for k,v in paths.items()},'scope':'Current path/hash observation; missing test/doc paths remain explicit, not fabricated qualification.'})
# Read only the model register metadata; no checkpoint, dataset, final panel or tensor bytes.
width_docs={8:['legacy_linguistic_training','legacy_teacher_fidelity','gte_decoder_reuse'],384:['contextual_legal_reconstruction_runtime','legal_source_span_runtime','reconstruction_training'],768:['gte_decoder_reuse','gte_multilingual_preparation','gte_decoder_interface_training'],4096:['four_width_training','legal_ir_text_to_lean4_execution_plan_20261018']}
width_tests={8:['tests/unit/logic/formalization/autoencoder/test_gte_legacy8_decoder_donor.py','tests/unit/optimizers/logic_theorem_optimizer/test_modal_latent_formula.py'],384:['tests/unit/logic/formalization/autoencoder/test_contextual_legal_ir_numeric.py','tests/unit/logic/formalization/autoencoder/test_contextual_legal_ir_runtime.py'],768:['tests/unit/logic/formalization/autoencoder/test_gte_decoder_reuse.py','tests/unit/optimizers/logic_theorem_optimizer/test_legal_span_dimensions.py'],4096:['tests/unit/optimizers/logic_theorem_optimizer/test_legal_span_4096.py','tests/unit/optimizers/logic_theorem_optimizer/test_legal_span_bound_native4096.py','tests/unit/optimizers/logic_theorem_optimizer/test_legal_span_native4096_binding.py']}
widths=[]
for p in register['profiles']:
 d=p['dimension'];widths.append({'dimension':d,'lineage_names':[x['name'] for x in p['lineages']],
  'historical_register_reference':ref(REPO/REG),'reuse':p['reuse'],
  'source_files':[current(x) for x in p['product_owners']],
  'test_files':[current(x) for x in width_tests[d]],
  'documentation_files':[current('docs/autoencoders/'+x+'.md') for x in width_docs[d]],
  'payloads_read':False,'runtime_or_training_executed':False,'statutory_teacher_quality_established':p['statutory_teacher_quality_established']})

# Bounded shallow directory discovery: direct names only, selected direct Python/Markdown byte hashes.
def shallow(base,prefixes=PREFIXES):
 global shallow_bytes
 rows=[]
 for e in sorted(os.scandir(base),key=lambda e:e.name):
  if not e.name.startswith(prefixes) or not e.is_dir(follow_symlinks=False):continue
  children=[];hashes=[]
  for child in sorted(os.scandir(e.path),key=lambda e:e.name):
   st=child.stat(follow_symlinks=False)
   kind='directory' if stat.S_ISDIR(st.st_mode) else 'regular_file' if stat.S_ISREG(st.st_mode) else 'symlink' if stat.S_ISLNK(st.st_mode) else 'other'
   children.append({'name':child.name,'kind':kind,'bytes':st.st_size if kind=='regular_file' else None})
   if kind=='regular_file' and child.name.endswith(('.py','.md')):
    if st.st_size<=MAX_SHALLOW and shallow_bytes+st.st_size<=SHALLOW_BUDGET:
     obs=safe_file(Path(child.path),MAX_SHALLOW);hashes.append(obs);shallow_bytes+=st.st_size
    else:hashes.append({'reference':ref(Path(child.path)),'bytes':st.st_size,'sha256':None,'reason':'selected shallow source/doc exceeds per-file or cumulative content bound'})
  for nested_name in ('candidate','candidates','preimages'):
   nested=Path(e.path)/nested_name
   if not nested.is_dir() or nested.is_symlink():continue
   for child in sorted(os.scandir(nested),key=lambda e:e.name):
    st=child.stat(follow_symlinks=False)
    if not stat.S_ISREG(st.st_mode) or not child.name.endswith(('.py','.md')):continue
    if st.st_size<=MAX_SHALLOW and shallow_bytes+st.st_size<=SHALLOW_BUDGET:
     hashes.append(safe_file(Path(child.path),MAX_SHALLOW));shallow_bytes+=st.st_size
  rows.append({'reference':ref(Path(e.path)),'disposition':'evidence','contents_reviewed_recursively':False,
   'direct_child_count':len(children),'direct_child_kind_counts':dict(collections.Counter(x['kind'] for x in children)),
   'direct_subdirectory_names':[x['name'] for x in children if x['kind']=='directory'],
   'direct_file_extension_counts':dict(collections.Counter(Path(x['name']).suffix for x in children if x['kind']=='regular_file')),
   'direct_entry_metadata_sha256':hashlib.sha256(json.dumps(children,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
   'metadata_digest_scope':'Ordered direct name/type/apparent-file-size tuples; not content hash or stable immutable directory identity.',
   'selected_direct_source_document_hashes':hashes})
 return rows
artifacts=shallow(ART)
audit_root=REPO/'workspace/test-logs/federal-corpus-audits'
workspace=shallow(audit_root)

# Staging inspections test the historical 132 exact relative targets, never walk private captures.
stages=[]
for n in STAGES:
 base=REPO/'workspace'/n;obs=[]
 for r in landing:
  p=base/r['path']
  if p.exists() or p.is_symlink():
   snap=safe_file(p);canon=current(r['path'])
   equal=snap['sha256']==canon['sha256'] if snap['sha256'] and canon['sha256'] else None
   obs.append({'snapshot':snap,'canonical':canon,'exact_bytes_equal':equal,'disposition':'mirror' if equal else 'evidence','qualification_inferred':False})
 stages.append({'reference':ref(base),'exists':base.is_dir(),'direct_children':sorted(x.name for x in base.iterdir()) if base.is_dir() else [],'selected_canonical_relative_paths_checked':len(landing),'selected_existing_matches':obs,'recursive_scan_performed':False})

# Known artifact-only work retains explicit disposition and destination.
known_specs=[
 ('full_norm_consequences','legal-ir-full-norm-native-20261017-01','full_norm_native_replay.py','ipfs_datasets_py/logic/autoformal/legal_full_norm_consequences_v1.py','migration_required','Being extracted in this consolidation; canonical qualification and installation must be supplied by the owning worker before marking complete.'),
 ('gated_conditioning','legal-ir-step-conditioning-20261018-01','gated_conditioning.py','ipfs_datasets_py/logic/formalization/autoencoder','migration_required','Experimental historical architecture profile; preserve exact 13-to-15 tensor migration and donor/optimizer lineage in an explicit versioned port.'),
 ('gated_training_state','legal-ir-gated-training-state-20261018-01','training_state.py','ipfs_datasets_py/logic/formalization/autoencoder','migration_required','Experimental historical training state; replace experiment owner imports through a versioned interface and retain fresh-Adam policy; not an active runtime.'),
 ('journal_session','legal-ir-journal-training-session-20261018-01','candidate/session.py','ipfs_datasets_py/logic/formalization/autoencoder','migration_required','Experimental historical journal profile; fixed anchors, hard-three/cadence-two behavior and resume/mutation/close checks require a versioned port.'),
 ('journal_inference','legal-ir-journal-inference-20261018-01','candidate/runtime.py','ipfs_datasets_py/logic/formalization/autoencoder','migration_required','Experimental historical serving profile; preserve fixed journal/view/row assumptions and model-only restoration; not an active runtime.'),
 ('parent_native','legal-ir-parent-use-native-20261019T193900Z','candidates/legal_corpus_definition_use_native_v2.py','ipfs_datasets_py/logic/autoformal/legal_corpus_definition_use_native_v2.py','candidate_unqualified','Staged parent wrapper; tests/install did not execute in its recorded handoff. Dependency and native qualification receipts are required; no inferred admission.'),
]
known=[]
for ident,group,relative,destination,disposition,reason in known_specs:
 p=ART/group/relative
 known.append({'id':ident,'source':safe_file(p),'proposed_destination':ref(destination),'disposition':disposition,'reason':reason,'qualification_receipt':None,'qualification_missing_reason':'Current consolidation has not executed or installed this extraction/profile.'})
 for row in artifacts:
  if row['reference']['path']==group:row.update(disposition=disposition,disposition_reason=reason)
# Explicit superseded prototypes; inspect only selected ordinary source bytes.
superseded=[]
for name in ('score_spans.py','export_modal_ir.py'):
 superseded.append({'source':safe_file(REPO/'workspace/legacy-cuda-span-scores'/name),'disposition':'superseded',
 'canonical_successors':[current('scripts/ops/legal_ir/run_legacy_span_cuda.py'),current('ipfs_datasets_py/optimizers/logic_theorem_optimizer/legacy_span_intake.py')],
 'reason':'Dated standalone prototype. Canonical campaign preserves stronger source identity, resource admission and owner-only control. Original script remains evidence.'})
# Exact duplicate observations are byte equality only, never qualification.
byhash=collections.defaultdict(list)
for rel,obs in cache.items():
 if obs['sha256']:byhash[obs['sha256']].append(ref(rel))
duplicates=[]
for row in artifacts+workspace:
 for obs in row['selected_direct_source_document_hashes']:
  if obs.get('sha256') in byhash:
   duplicates.append({'snapshot':obs,'canonical_references':byhash[obs['sha256']],'disposition':'mirror','scope':'Exact selected file bytes only; original evidence remains in place.'})
for stage in stages:
 for pair in stage['selected_existing_matches']:
  if pair['exact_bytes_equal']:duplicates.append({'snapshot':pair['snapshot'],'canonical_references':[pair['canonical']['reference']],'disposition':'mirror','scope':'Exact historical selected path; no recursive staging audit.'})

supersessions=[
 {'old_claim':'Plaintext field/graph/source metadata adapters must be created.','current_state':'Existing parent views, metadata and graph owners must be reused; source presence is inventoried here and qualification is in original receipts.','evidence':ref(REPO/REG)},
 {'old_claim':'Parent endpoint and combined definition-use review are still unimplemented.','current_state':'The current register records installed endpoint review, lookup/use and combined review increments; preserve genuine-human-review and semantic-authority limitations.','evidence':ref(REPO/REG)},
 {'old_claim':'All generic review/Lake/native code accepts parent plaintext inputs.','current_state':'Each parent boundary needs its actual versioned API and qualification; parent native remains staged in the cited handoff.','evidence':ref(ART/'legal-ir-parent-use-native-20261019T193900Z/handoff.json')},
 {'old_claim':'A completed narrow model experiment qualifies all 8D/384D/768D/4096D models or statutes.','current_state':'Retain separate lineage, width, input producer, tokenizer/context and checkpoint identities. No cohorts or counts are pooled.','evidence':ref(REPO/REG)},
 {'old_claim':'Workspace source copies or old score/export scripts are alternate production implementations.','current_state':'Use canonical source modules and supported campaign interfaces; snapshots remain immutable evidence and obsolete prototypes remain historical.','evidence':ref(REPO/'docs/autoencoders/legacy_cuda_span_campaign.md')},
]
result={'schema':'legal-ir-consolidated-work-inventory/v1','observed_at_utc':NOW,
 'purpose':'Portable navigation and bounded current path/hash refresh of existing catalogs, not another task controller or runtime API.',
 'roots':{'datasets_repository':'Checkout root containing ipfs_datasets_py/, docs/ and workspace/.','artifact_workspace':'The existing top-level artifacts/ directory in the surrounding application workspace; optional external evidence root.'},
 'evidence_semantics':{'reported':'Value retained from a hashed prior report; not rerun.','recovered':'Existing pathname/content observed in this bounded inspection.','hash_checked':'Ordinary file bytes hashed under explicit bound.','recomputed':'Only catalog counts and exact byte equality recomputed.','replayed':False,'newly_executed_experiments':False,'null':'Missing, excluded or unmeasured; see reason.'},
 'coverage':{'artifact_directory_rule':'Direct ordinary directories whose basename starts legal-, uscode-, gte-, or source-span-.','artifact_directories_observed':len(artifacts),'workspace_audit_directory_rule':'Same direct basename prefixes beneath workspace/test-logs/federal-corpus-audits.','workspace_audit_directories_observed':len(workspace),'workspace_staging_trees_observed':len(stages),'historical_landing_rows_refreshed':len(landing_rows),'historical_capabilities_reused':len(capabilities),'shallow_selected_source_document_bytes_hashed':shallow_bytes,'shallow_source_document_per_file_limit_bytes':MAX_SHALLOW,'shallow_content_budget_bytes':SHALLOW_BUDGET,'canonical_and_report_file_limit_bytes':MAX_READ,'not_an_exhaustive_content_or_experiment_audit':True,
 'exclusions':['No model/checkpoint/tensor, dataset, protected final panel, blind-test payload or generated large output read.','No active control databases, ledgers, locks or scheduler-state contents opened.','No recursion through artifact/private-source/captured-source/worktree trees. Only direct Python/Markdown files plus one explicit candidate/candidates/preimages layer are content-hashed; staging checks use only exact 132 historical target paths.','No directories outside named prefixes included in shallow discovery, except six explicit staging trees and two explicit superseded prototypes.','No runtime imports, inference, training, native Lean invocation, test execution, resource admission, recovery, deletion or publication.','Directory entry names and file hashes are observations, not run completeness, semantic qualification or total experiment counts.']},
 'historical_inputs':inputs,'historical_register_current_reconciliation':register.get('current_reconciliation'),
 'historical_landing_map':landing_rows,'historical_capabilities':capabilities,
 'canonical_pipeline':pipeline,'model_widths':widths,
 'current_canonical_file_observations':list(cache.values()),
 'shallow_artifact_directories':artifacts,'shallow_workspace_audit_directories':workspace,'workspace_staging_trees':stages,
 'exact_selected_mirrors':duplicates,'known_artifact_only_work':known,'superseded_workspace_prototypes':superseded,'documentation_supersessions':supersessions,
 'remaining_known_not_migrated':['Full-norm consequences extraction requires its owning validation/installation receipt before completion.','Gated conditioning and training-state experimental profile require an explicit versioned port; training_core.py remains a historical harness.','Journal session and journal inference profiles require versioned compatibility, resume and serving ports.','Parent native candidate requires actual dependency, focused validation and installation receipts, then separate real compiler qualification.','Parent shared/incremental composition and statutory semantic/human applicability qualifications remain separate from source consolidation.'],
 'historical_fields_policy':'Historical landing rows retain all original CSV fields. Historical capability values are preserved except path strings converted to portable references/embedded named-root notation; original exact file hashes identify unmodified source reports. Historical Git/runtime labels do not describe this observation.',
 'package_migration_policy':'Reusable implementation belongs in existing canonical owners; tests and durable docs accompany it. Do not move historical source snapshots, receipts or active owner state into importable packages, nor rewrite historical source pins.'}
# Normalize repeated current observations; one canonical hash inventory owns them.
for row in result['historical_landing_map']:
 row['current_observation_key']=row.pop('current_observation')['reference']['path']
for row in result['historical_capabilities']:
 row['current_canonical_observation_keys']=[x['reference']['path'] for x in row.pop('current_canonical_observations')]
for row in result['canonical_pipeline']:
 row['files']={k:v['reference'] for k,v in row['files'].items()}
for row in result['model_widths']:
 for key in ('source_files','test_files','documentation_files'):row[key]=[x['reference'] for x in row[key]]
for key in ('shallow_artifact_directories','shallow_workspace_audit_directories'):
 for row in result[key]:
  prefix=row['reference']['path']+'/'
  observations=row.pop('selected_direct_source_document_hashes')
  row['selected_source_document_rows']=[[x['reference']['path'][len(prefix):],x.get('bytes'),x.get('sha256'),1 if x.get('reason') else None] for x in observations]
  row.pop('metadata_digest_scope',None);row.pop('contents_reviewed_recursively',None);row.pop('direct_file_extension_counts',None)
result['compact_table_contract']={'selected_source_document_rows_columns':['path_relative_to_directory_reference','bytes','sha256','reason_code'],'reason_codes':{'1':'Selected shallow source/document exceeds declared per-file or cumulative content-hashing bound; bytes not opened.'},'current_observation_key':'Path relative to datasets_repository; look up exact matching reference in current_canonical_file_observations.','directory_metadata_digest':'SHA256 of ordered direct child name/kind/apparent-file-size JSON tuples; metadata only, not content identity.'}
wire=json.dumps(result,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n'
assert '/home/' not in wire
(OUT/'work_inventory.json').write_text(wire)
summary={'as_of':NOW,'artifact_directories':len(artifacts),'workspace_audit_directories':len(workspace),'staging_trees':len(stages),'canonical_files':len(cache),'exact_selected_mirrors':len(duplicates),'landing_current_present':sum(cache[x['current_observation_key']]['sha256'] is not None for x in landing_rows),'landing_unchanged':sum(x['equals_historical_working_sha256'] is True for x in landing_rows),'bytes':len(wire.encode()),'sha256':hashlib.sha256(wire.encode()).hexdigest()}
(OUT/'build_observation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
