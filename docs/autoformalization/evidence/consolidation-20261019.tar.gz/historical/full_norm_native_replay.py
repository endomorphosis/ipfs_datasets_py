"""Owned mechanical full-norm replay and conditional Lean consequences.

Preserves the complete retained A/B quantified/modal declarations. hNorm and
hPermit remain explicit unverified premises. No source equivalence, governing
applicability, legal review, norm rewrite or training/gold authority is inferred.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import importlib.abc
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import time
ROOT=Path('/home/barberb/lift_coding')
REPO=ROOT/'external/ipfs_datasets'
STAGE=Path(__file__).resolve().parent
MAX_INPUT_BYTES=16*1024**2
TOOLCHAIN='leanprover/lean4:v4.34.1'
TOOLROOT=Path('/home/barberb/.elan/toolchains/leanprover--lean4---v4.34.1')
THEOREMS=['LegalFullNorms.CandidateA.norm_instance','LegalFullNorms.CandidateA.approval_from_permission',
          'LegalFullNorms.CandidateB.modal_instance']
SCOPES={'prepare':(1,2048,2,600,128*1024**2),'compile':(1,3072,4,300,128*1024**2)}
if sys.flags.optimize:raise RuntimeError('full norm qualification requires assertions enabled')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf-8')


def read(path, expected=None, maximum=MAX_INPUT_BYTES):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, 'absolute unaliased input required: ' + str(path))
    for parent in path.parents:
        need(stat.S_ISDIR(parent.lstat().st_mode), 'unaliased input parent required')
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and 0 <= before.st_size <= maximum and (before.st_size > 0 or path.suffix == ".py"),
             'bounded single-link regular input required: ' + str(path))
        raw = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns)
    need(len(raw) == before.st_size and identity(before) == identity(after) == identity(path.lstat()),
         'input changed during read: ' + str(path))
    descriptor = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    if expected is not None:
        need(descriptor['sha256'] == expected if type(expected) is str else
             descriptor == {key: expected[key] for key in descriptor}, 'independent input descriptor differs: ' + str(path))
    return raw, descriptor


def write(path, raw):
    path = Path(path)
    need(path.parent.resolve(strict=True) == path.parent, 'unaliased existing output parent required')
    with path.open('xb') as stream:
        os.fchmod(stream.fileno(), 0o600)
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def no_authority(value):
    """Check explicit authority objects without reinterpreting producer flags."""
    checked = 0
    if type(value) is dict:
        for key, child in value.items():
            if key == 'authority':
                need(type(child) is dict and child and all(type(flag) is bool and flag is False for flag in child.values()),
                     'authority object grants or changes authority')
                checked += 1
            checked += no_authority(child)
    elif type(value) is list:
        checked += sum(no_authority(child) for child in value)
    return checked


def strict_json(raw):
    def pairs(items):
        value = {}
        for key, child in items:
            need(key not in value, 'duplicate retained JSON key')
            value[key] = child
        return value
    def constant(value):
        raise ValueError('finite retained JSON required: ' + value)
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=constant)


def check_masks(value):
    count = 0
    if type(value) is dict:
        for key, child in value.items():
            if key.endswith('_mask'):
                need(type(child) is int and child == 0, 'retained declaration mask changed')
                count += 1
            elif key in {'masks', 'field_masks'}:
                need(type(child) is dict and all(type(flag) is int and flag == 0 for flag in child.values()),
                     'retained field masks changed')
                count += len(child)
            count += check_masks(child)
    elif type(value) is list:
        count += sum(check_masks(child) for child in value)
    return count


class CanonicalFinder(importlib.abc.MetaPathFinder):
    def __init__(self, namespaces, optional):
        self.namespaces, self.optional = namespaces, optional
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'lib' or fullname.startswith('lib.'):
            self.optional.append(fullname)
            raise ModuleNotFoundError('standalone_ipfs_optional_app_lib_unavailable: '+fullname, name=fullname)
        if fullname != 'ipfs_datasets_py' and not fullname.startswith('ipfs_datasets_py.'):
            return None
        base = REPO.joinpath(*fullname.split('.')); package = base/'__init__.py'
        if base.is_dir() and not package.exists() and not package.is_symlink():
            verify_namespace(base)
            self.namespaces[fullname] = {'module': fullname, 'path': str(base), 'source_origin': None,
                'execution': 'canonical_namespace_directory_no_source_bytes'}
            spec = importlib.machinery.ModuleSpec(fullname, loader=None, is_package=True)
            spec.submodule_search_locations = [str(base)]
            return spec
        file = package if package.is_file() else base.with_suffix('.py')
        if not file.is_file():
            raise ModuleNotFoundError('canonical first-party module unavailable: '+fullname, name=fullname)
        loader = importlib.machinery.SourceFileLoader(fullname, str(file))
        return importlib.util.spec_from_file_location(fullname, file, loader=loader,
            submodule_search_locations=[str(base)] if file==package else None)


def verify_namespace(path):
    need(path.resolve(strict=True)==path and REPO in path.parents
         and not (path/'__init__.py').exists() and not (path/'__init__.py').is_symlink(), 'canonical namespace required')
    for parent in (path,*path.parents):
        need(stat.S_ISDIR(parent.lstat().st_mode), 'unaliased namespace chain required')
        if parent==REPO: break


def install_compile_capture(pins, helpers, captures):
    original = importlib.machinery.SourceFileLoader.get_code
    def exact_get_code(loader, fullname):
        path = Path(loader.path).absolute()
        if REPO in path.parents or path in helpers:
            need(path.suffix=='.py' and str(path) in pins, 'direct first-party/fixture compilation omitted from frozen closure: '+str(path))
            raw, ref = read(path, pins[str(path)], 4*1024**2)
            entry = captures.setdefault(str(path), {'source': ref, 'raw': raw, 'aliases': [], 'load_count': 0})
            need(entry['raw']==raw and entry['source']==ref, 'compiled source drift')
            if fullname not in entry['aliases']: entry['aliases'].append(fullname)
            entry['load_count'] += 1
            return compile(raw, str(path), 'exec', dont_inherit=True, optimize=0)
        return original(loader, fullname)
    importlib.machinery.SourceFileLoader.get_code = exact_get_code
    return original


def capture_all(output, captures, namespaces, executed, inputs):
    loaded=[];ns=[]
    for name,module in sorted(sys.modules.items()):
        filename=getattr(module,'__file__',None)
        project_name=name=='ipfs_datasets_py' or name.startswith('ipfs_datasets_py.')
        project_file=type(filename) is str and (REPO in Path(filename).absolute().parents
            or filename in {ref['path'] for ref in inputs.get('helpers', {}).values()})
        if project_name or project_file:
            if name in namespaces:
                row=namespaces[name];path=Path(row['path']);verify_namespace(path);spec=module.__spec__
                need(getattr(module,'__file__',None) is None and list(module.__path__)==[str(path)]
                     and spec.origin is None and list(spec.submodule_search_locations)==[str(path)],'canonical namespace changed')
                ns.append(row)
            else:
                path=filename
                need(path in captures,'loaded first-party module bypassed exact compilation capture: '+name)
                loaded.append({'module':name,'source_path':path})
    files=[]
    for path,entry in sorted(captures.items()):
        read(Path(path),entry['source'],4*1024**2)
        target=output/'loaded-source'/Path(path).relative_to(ROOT);target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        files.append({'source':entry['source'],'captured':write(target,entry['raw']),'module_aliases':entry['aliases'],
            'load_count':entry['load_count'],'observed_exec':path in executed,
            'execution':'compiled_from_exact_verified_source_bytes_no_pyc'})
    need(set(executed)<=set(captures),'canonical/helper exec bypassed independently pinned compilation')
    manifest={'schema':'exact-all-first-party-compilations/v1','files':files,'namespaces':ns,'loaded_project_modules':loaded,
        'unique_source_file_count':len(files),'compile_observation_count':sum(x['load_count'] for x in files),
        'module_alias_count':sum(len(x['module_aliases']) for x in files),'unique_executed_file_count':len(executed),
        'namespace_count':len(ns),'helpers_compiled':{role:ref['path'] in captures for role,ref in inputs.get('helpers', {}).items()}}
    write(output/'loaded-source-manifest.json',wire(manifest)+b'\n');return manifest


def stream_ref(ref, maximum=256*1024**2):
    """Hash compiler data incrementally; never deserialize compiler bodies."""
    path=Path(ref['path'])
    need(path.is_absolute() and path.resolve(strict=True)==path,'unalias compiler data path')
    for parent in path.parents:need(stat.S_ISDIR(parent.lstat().st_mode),'unalias compiler data parent')
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK),'rb') as stream:
        before=os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and 0<before.st_size<=maximum,'bounded regular compiler data')
        digest=hashlib.sha256();size=0
        while True:
            raw=stream.read(1024**2)
            if not raw:break
            size+=len(raw);need(size<=maximum,'compiler data grew beyond bound');digest.update(raw)
        after=os.fstat(stream.fileno())
    identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    need(identity(before)==identity(after)==identity(path.lstat()),'compiler data changed during stream')
    actual={'path':str(path),'bytes':size,'sha256':digest.hexdigest()}
    need(wire(actual)==wire(ref),'frozen compiler data changed')
    return actual


def dump(path,value):
    raw=wire(value)+b'\n';need(len(raw)<=MAX_INPUT_BYTES,'bounded generated JSON required')
    return write(path,raw)


def lifecycle(run,process,expected):
    need(run.runtime is process.ToolRuntime.NATIVE and tuple(run.command)==tuple(expected)
         and type(run.pid) is int and run.pid>0,'actual native command/PID required')
    need(not any(getattr(run,key) for key in ('timed_out','cancelled','unavailable','output_truncated',
         'workspace_limit_exceeded','resource_exhausted')) and run.error=='' and run.workspace_cleaned is True,
         'native compiler/probe did not finish cleanly: '+run.error)
    observation=run.native_lifecycle
    need(type(observation) is process.NativeToolLifecycleObservation and observation.cleanup_confirmed is True
         and observation.parent_pid==os.getpid() and type(observation.parent_birth_ticks) is int
         and observation.parent_birth_ticks>0,'owned native cleanup/parent birth observation required')
    leader=observation.leader
    need(type(leader) is process.NativeProcessIdentity and leader.pid==run.pid
         and leader.parent_pid==os.getpid() and leader.process_group_id==leader.session_id==run.pid,
         'owned native leader identity/session required')
    for item in (leader,*observation.observed_descendants):
        need(type(item) is process.NativeProcessIdentity
             and all(type(getattr(item,key)) is int and getattr(item,key)>0
                     for key in ('pid','birth_ticks','parent_pid','process_group_id','session_id'))
             and item.process_group_id==leader.process_group_id and item.session_id==leader.session_id,
             'native child/descendant ownership observation differs')
    return observation.to_dict()


def native_run(name,command,files,output_paths,output,attempt,process,active,*,timeout=45):
    directory=output/name;directory.mkdir(mode=0o700)
    for relative,body in files.items():
        target=directory/'project'/relative;target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        write(target,body)
    limits=process.ToolRunLimits(timeout_seconds=timeout,cpu_seconds=timeout,
        resident_memory_bytes=2*1024**3,max_output_bytes=2*1024**2,max_input_bytes=8*1024**2,
        max_workspace_bytes=64*1024**2,max_file_bytes=32*1024**2,max_output_files=32)
    environment={'PATH':str(TOOLROOT/'bin')+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
        'LEAN_SYSROOT':str(TOOLROOT),'ELAN_TOOLCHAIN':TOOLCHAIN,'LEAN_NUM_THREADS':'1',
        }
    # The public runner inserts HOME/TMPDIR/TMP/TEMP equal to its actual private workspace.
    invocation=process.ToolRunRequest(argv=tuple(command),input_files=files,output_paths=tuple(output_paths),
        environment=environment,owned_process_observation=True,limits=limits,stdin=b'')
    wrapped=['/usr/bin/prlimit','--core=0:0','--fsize=33554432:33554432','--cpu='+str(timeout)+':'+str(timeout),'--',*command]
    need(active['command'] is None and active['count']<6,'at most six exact native invocations')
    active.update(command=wrapped,count=active['count']+1,cwd_root=str(attempt/'tmp'),observations=[])
    try:
        run=process.BoundedToolRunner(workspace_root=attempt/'tmp',base_environment={},
            executable_roots=(TOOLROOT/'bin',)).run(invocation)
    except process.OwnedToolCleanupError as error:
        dump(directory/'cleanup-refusal.json',{'qualified':False,'cleanup_confirmed':False,
            'error':str(error)[:2048],'cleanup_owner_retained':True})
        raise
    finally:active['command']=None
    observed=lifecycle(run,process,command)
    need(len(active['observations'])==1,'one exact Python native spawn audit required')
    logs={key:write(directory/(key+'.txt'),getattr(run,key).encode()) for key in ('stdout','stderr')}
    retained={}
    for relative,body in run.output_files.items():
        target=directory/'observed'/relative;target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        retained[relative]=write(target,body)
    for relative,body in files.items():need(run.output_files.get(relative)==body,'executed project source bytes changed')
    record=run.to_dict();record.pop('output_files')
    record.update(name=name,logs=logs,output_files=retained,input_sha256={key:sha(body) for key,body in files.items()},
        native_lifecycle=observed,subprocess_audit=active['observations'],executed_source_readback_exact=True)
    dump(directory/'tool-run.json',record)
    return run,record


def descriptor_paths(value):
    paths=set()
    def visit(item):
        if type(item) is dict:
            if {'path','bytes','sha256'}<=set(item) and type(item['path']) is str:paths.add(Path(item['path']))
            for child in item.values():visit(child)
        elif type(item) is list:
            for child in item:visit(child)
    visit(value);return paths

def input_checks(inputs,phase):
    need(inputs['schema']=='legal-full-norm-native-inputs/v1' and set(inputs['candidates'])=={'A','B'},'exact retained A/B inputs required')
    refs=inputs['retained_files'];need(len(refs)==len({r['path'] for r in refs}),'unique retained input descriptors')
    for ref in refs:
        need(not Path(ref['path']).name.endswith('.tagged.json'),'no complete-call carrier inputs allowed')
        read(ref['path'],ref)
    for label in ('A','B'):
        row=inputs['candidates'][label]
        need(set(row)=={'norm_preparation','definition_evidence','relational_request','relational_report','expected_relational_report_sha256'},
             'closed exact candidate input descriptors')
        for key in ('norm_preparation','definition_evidence','relational_request','relational_report'):read(row[key]['path'],row[key])
    for ref in inputs['empty_source_descriptors']+inputs['read_only_initializer_sources']:read(ref['path'],ref,4*1024**2)
    tool=inputs['toolchain']
    need(tool['label']==TOOLCHAIN and tool['root']==str(TOOLROOT) and tool['lake']['path']==str(TOOLROOT/'bin/lake')
         and tool['lean']['path']==str(TOOLROOT/'bin/lean') and tool['prlimit']['path']=='/usr/bin/prlimit','fixed installed toolchain paths')
    if phase=='compile':
        runtime=strict_json(read(tool['runtime_manifest']['path'],tool['runtime_manifest'])[0])
        need(runtime['schema']=='legal-bound-variable-selected-toolchain-runtime/v1' and runtime['toolchain']==TOOLCHAIN
             and type(runtime['files']) is list and 0<len(runtime['files'])<=3000
             and len(runtime['files'])==len({r['path'] for r in runtime['files']})
             and sum(r['bytes'] for r in runtime['files'])<=1024**3,'bounded exact selected compiler runtime inventory')
        for key in ('lake','lean','prlimit'):
            raw=read(tool[key]['path'],tool[key],4*1024**2)[0]
            need(raw.startswith(b'\x7fELF') and os.access(tool[key]['path'],os.X_OK),'installed native executable ELF required')
        for ref in runtime['files']:stream_ref(ref)


def completion_join(wrapper,watcher):
    fields={'generated_inputs','source_receipt','native_result','native_execution','native_durability','resource_receipt'}
    need(set(wrapper)=={'schema',*fields} and wrapper['schema']=='legal-full-norm-native-completed-preparation/v1',
         'closed completed full norm preparation wrapper')
    def watched(ref,*,parse=True):
        need(watcher.get(ref['path'])==ref['sha256'],'small preparation handoff reference omitted from watcher')
        raw=read(ref['path'],ref,4*1024**2)[0];return strict_json(raw) if parse else raw
    values={key:watched(wrapper[key]) for key in fields};generated=values['generated_inputs']
    need(set(generated)=={'schema','owned_request','request_sha256','input_manifest','reports','replayed_reports','lean_source','summary','driver'}
         and generated['schema']=='legal-full-norm-native-prepared-inputs/v1'
         and set(generated['reports'])==set(generated['replayed_reports'])=={'A','B'},'closed exact generated full norm handoff')
    prior=watched(generated['owned_request']);outer=values['source_receipt'];resource=values['resource_receipt'];dur=values['native_durability']
    for key in ('input_manifest','summary'):watched(generated[key])
    watched(generated['driver'],parse=False);watched(generated['lean_source'],parse=False)
    for label in ('A','B'):
        watched(generated['reports'][label]);watched(generated['replayed_reports'][label])
    need(prior['schema']=='owned-validation-request/v1' and prior['cwd']==str(REPO)
         and tuple(prior[k] for k in ('cpu_slots','memory_mb','child_process_slots','timeout_seconds','storage_bytes'))==SCOPES['prepare']
         and generated['request_sha256']==generated['owned_request']['sha256'] and prior['argv'][2]==generated['driver']['path']
         and prior['argv'][prior['argv'].index('--phase')+1]=='prepare'
         and prior['source_sha256'].get(generated['input_manifest']['path'])==generated['input_manifest']['sha256']
         and wire(generated['driver'])==wire(read(Path(__file__).resolve(),maximum=4*1024**2)[1]),
         'exact successful preparation request/driver/input generation required')
    need(outer['completed'] is True and outer['source_lease_released'] is True and outer['validation_returncode']==0
         and outer['mode']=='read' and outer['published_files']==[] and wire(outer['validation_request'])==wire(generated['owned_request'])
         and wire(outer['stdout'])==wire(wrapper['resource_receipt']),'preparation source closeout not successful/exact/released')
    watched(outer['request']);watched(outer['stderr'],parse=False)
    need(watcher.get(outer['lease_owner']['path'])==outer['lease_owner']['sha256'],'preparation source lease owner omitted from watcher')
    read(outer['lease_owner']['path'],outer['lease_owner'],4*1024**2)
    for key in ('native_result','native_execution'):
        row=values[key]
        need(row['completed'] is True and row['returncode']==0 and row['request_sha256']==generated['request_sha256']
             and wire(row['executed_checks'])==wire(prior['selected_checks']),'successful native preparation result/execution required')
    need(all(values['native_execution'][k] is False for k in ('admitted','Lean_admitted','authority_granted','model_weights_downloaded')),
         'preparation cannot grant authority')
    reservation=resource['reservation'];record=reservation['record']
    need(resource['admitted'] is False and reservation['status']==record['status']=='released' and reservation['cleanup_error'] is None
         and reservation['resource_lease']['released'] is True and record['artifacts_durable_asserted'] is True
         and record['validation_request_sha256']==generated['request_sha256']
         and record['native_lease_id']==reservation['resource_lease']['lease_id'],'preparation resources not durably released')
    need(dur['request_sha256']==generated['request_sha256'] and dur['result_sha256']==wrapper['native_result']['sha256']
         and dur['reservation_id']==reservation['reservation_id']==record['reservation_id'] and dur['result_path']=='logs/result.json'
         and dur['admitted'] is False and dur['arbitrary_descendant_containment'] is False,'preparation durability lineage differs')
    need(resource['result']==wrapper['native_result']['path'],'preparation resource result path differs')
    for key,name in [('native_result','result.json'),('native_execution','execution.json'),('native_durability','validation-durability.json')]:
        need(Path(wrapper[key]['path'])==Path(prior['outputs']['logs'])/name,'native preparation closeout path differs')
    payloads=[wrapper['generated_inputs'],generated['lean_source'],generated['summary'],*generated['reports'].values(),*generated['replayed_reports'].values()]
    for ref in payloads:
        relative=str(Path(ref['path']).relative_to(Path(prior['attempt_directory'])))
        rows=[r for r in dur['files'] if r['path']==relative]
        need(len(rows)==1 and rows[0]['bytes']==ref['bytes'] and rows[0]['sha256']==ref['sha256'],'generated full norm input absent from durability')
    return generated


def original_closed_custody(inputs):
    """Read saved A/B successful source/native lineages; no upstream API replay."""
    for label in ('A','B'):
        refs=inputs['prior_completion'][label]
        values={k:strict_json(read(ref['path'],ref)[0]) for k,ref in refs.items()}
        outer=values['source_receipt'];resource=values['resource_receipt'];dur=values['native_durability']
        request=values['request'];request_ref=refs['request'];res=resource['reservation'];record=res['record']
        need(outer['completed'] is True and outer['source_lease_released'] is True and outer['validation_returncode']==0
             and wire(outer['validation_request'])==wire(request_ref) and wire(outer['stdout'])==wire(refs['resource_receipt']),
             'retained candidate source completion differs')
        for key in ('native_result','native_execution'):
            need(values[key]['completed'] is True and values[key]['returncode']==0
                 and values[key]['request_sha256']==request_ref['sha256'],'retained candidate native completion differs')
        need(res['status']==record['status']=='released' and res['cleanup_error'] is None and res['resource_lease']['released'] is True
             and record['artifacts_durable_asserted'] is True and record['validation_request_sha256']==request_ref['sha256'],
             'retained candidate resource completion differs')
        need(dur['request_sha256']==request_ref['sha256'] and dur['result_sha256']==refs['native_result']['sha256']
             and dur['reservation_id']==res['reservation_id'] and values['phase']['passed'] is True,'retained candidate durability/phase differs')
        for key in ('norm_preparation','definition_evidence'):
            ref=inputs['candidates'][label][key];relative=str(Path(ref['path']).relative_to(Path(request['attempt_directory'])))
            rows=[r for r in dur['files'] if r['path']==relative]
            need(len(rows)==1 and rows[0]['bytes']==ref['bytes'] and rows[0]['sha256']==ref['sha256'],
                 'retained full norm/evidence custody absent from original durability')
    return {'candidates':['A','B'],'scope':'saved successful original A/B custody checked; only relational owners mechanically replayed now',
            'current_source_or_definition_replay_performed':False,'large_carriers_opened':False}


def actual_shape(report,label):
    need(report['profile']=='authored-object-relational-deontic/v1' and report['counts']=={
         'modal_nodes':1,'nodes':15,'predicate_occurrences':3,'quantifiers':3},'complete retained actual relational node population required')
    need(wire(report['argument_roles'])==wire([{'roles':['recipient','duties'],'symbol':'Assign'},
        {'roles':['recipient','duties'],'symbol':'Transfer'},{'roles':['approver','recipient'],'symbol':'Approve'}]),
        'exact actual arity2 ordered role declarations required')
    root=report['native_ast']
    for name in ('r','d','s'):
        need(set(root)=={'node_type','quantifier','variable','formula'} and root['node_type']=='QuantifiedFormula'
             and wire(root['quantifier'])==wire({'enum':'Quantifier','value':'∀'})
             and wire(root['variable'])==wire({'name':name,'node_type':'Variable','sort':None}),
             'exact retained universal binder order/carrier required')
        root=root['formula']
    def binary(node,operator):
        need(set(node)=={'node_type','operator','left','right'} and node['node_type']=='BinaryFormula'
             and wire(node['operator'])==wire({'enum':'LogicOperator','value':operator}),'exact retained binary constructor')
    def modal(node):
        need(set(node)=={'node_type','operator','agent','context','formula'} and node['node_type']=='DeonticFormula'
             and wire(node['operator'])==wire({'enum':'DeonticOperator','value':'P'})
             and node['agent'] is None and node['context'] is None,'exact P without agent/context annotations required')
    if label=='A':binary(root,'→');modal(root['left']);actions=root['left']['formula'];approval=root['right'];condition=root['left']
    else:modal(root);binary(root['formula'],'→');actions=root['formula']['left'];approval=root['formula']['right'];condition=root
    binary(actions,'∨')
    def atom(node,name,args):
        need(wire(node)==wire({'node_type':'Predicate','name':name,'arguments':[
            {'name':arg,'node_type':'Variable','sort':None} for arg in args]}),'exact ordered actual predicate arguments required')
    atom(actions['left'],'Assign',('r','d'));atom(actions['right'],'Transfer',('r','d'));atom(approval,'Approve',('s','r'))
    need(report['source_binding'] is None and no_authority(report)>0 and check_masks(report)>0
         and report['source_bound'] is False and report['source_translation_performed'] is False
         and report['native_build_executed'] is False and report['human_reviews']==report['signatures_constructed']==report['admissions']==0,
         'original unreviewed preparation flags must stay unchanged')
    return {'core':root,'actions':actions,'approval':approval,'condition':condition}


def joint_source(reports,emitter):
    """Use existing renderer only, retaining both whole original declaration strings."""
    shapes={label:actual_shape(reports[label],label) for label in ('A','B')};environment={'r':'r','d':'d','s':'s'}
    renderer=lambda node:emitter.FormulaRenderer().formula(node,environment)
    a_condition=renderer(shapes['A']['condition']);approval=renderer(shapes['A']['approval'])
    b_modal=renderer(shapes['B']['core']);b_plain=renderer(shapes['B']['core']['formula'])
    need(wire(shapes['A']['actions'])==wire(shapes['B']['actions']) and wire(shapes['A']['approval'])==wire(shapes['B']['approval']),
         'A/B must retain literal common ordered actions/approval subtrees')
    source='namespace LegalFullNorms\n'+emitter.PRELUDE+'\nnamespace CandidateA\n'+reports['A']['lean_body']+'\n'
    source+='def permittedActionsAt {Entity Agent : Type} (i : Interpretation Entity Agent) (r d : Entity) : Nat → Prop := '+a_condition+'\n'
    source+='def approvalAt {Entity Agent : Type} (i : Interpretation Entity Agent) (s r : Entity) : Nat → Prop := '+approval+'\n'
    source+=('theorem norm_instance {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) (r d s : Entity)\n'
        '    (hNorm : formula_0 i t) : permittedActionsAt i r d t → approvalAt i s r t := by\n'
        '  exact hNorm r d s\n#print axioms norm_instance\n'
        'theorem approval_from_permission {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) (r d s : Entity)\n'
        '    (hNorm : formula_0 i t) (hPermit : permittedActionsAt i r d t) : approvalAt i s r t := by\n'
        '  exact hNorm r d s hPermit\n#print axioms approval_from_permission\nend CandidateA\nnamespace CandidateB\n')
    source+=reports['B']['lean_body']+'\n'
    source+='def permittedImplicationAt {Entity Agent : Type} (i : Interpretation Entity Agent) (r d s : Entity) : Nat → Prop := '+b_modal+'\n'
    source+=('theorem modal_instance {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) (r d s : Entity)\n'
        '    (hNorm : formula_0 i t) : permittedImplicationAt i r d s t := by\n'
        '  exact hNorm r d s\n#print axioms modal_instance\nend CandidateB\nend LegalFullNorms\n')
    raw=source.encode();slices={}
    for label in ('A','B'):
        body=reports[label]['lean_body'].encode();need(raw.count(body)==1,'whole original emitted declaration must occur once')
        start=raw.index(body);slices[label]={'byte_start':start,'byte_end':start+len(body),'sha256':sha(body),'bytes':len(body)}
    return raw,{'emitted_body_slices':slices,'a_condition':a_condition,'approval':approval,'b_modal':b_modal,'b_plain':b_plain,
        'shared_interpretation_prelude_instances':1,'namespaces':{'A':'LegalFullNorms.CandidateA','B':'LegalFullNorms.CandidateB'}}


def preparation_phase(inputs,output,request_ref,input_ref):
    from ipfs_datasets_py.logic.autoformal import legal_relational_norm_v1 as owner
    from ipfs_datasets_py.logic.autoformal import legal_family_routes as routes
    from ipfs_datasets_py.logic.formalization.autoencoder import native_family_lean_emitters as emitter
    reports={};report_refs={};replayed_refs={};operations=[];custody={}
    for label in ('A','B'):
        refs=inputs['candidates'][label]
        norm=strict_json(read(refs['norm_preparation']['path'],refs['norm_preparation'])[0])
        evidence=strict_json(read(refs['definition_evidence']['path'],refs['definition_evidence'])[0])
        original=strict_json(read(refs['relational_report']['path'],refs['relational_report'])[0])
        raw=read(refs['relational_request']['path'],refs['relational_request'],524288)[0]
        need(raw==original['request_raw_utf8'].encode() and sha(raw)==original['request_sha256']
             and wire(original)==wire(norm['correspondence']['relational_fragment'])
             and owner.relational_norm_report_sha256(original)==refs['expected_relational_report_sha256'],
             'complete original relational request/report/norm commitments differ')
        need(evidence['counts']=={'alternatives':2,'distinct_typed_uses':3,'links':6,'supplied_definition_assessments':0}
             and len(norm['obligations'])==19 and wire(norm['obligations'])==wire(evidence['norm_obligations'])
             and evidence['norm_preparation_sha256']==sha(wire(norm)) and evidence['norm_ast_sha256']==norm['ast_sha256']
             and evidence['norm_native_ast_sha256']==norm['native_ast_sha256']
             and no_authority(norm)>0 and check_masks(norm)>0 and no_authority(evidence)>0 and check_masks(evidence)>0
             and norm['governing_definition_use'] is None
             and evidence['selected_interpretation'] is None and evidence['governing_definition_use'] is None,
             'complete unresolved source/norm/rival/nomination custody differs')
        started=time.monotonic();dump(output/(label+'-before-prepare.json'),{'operation':'prepare_relational_norm_v1','started_monotonic':started})
        report=owner.prepare_relational_norm_v1(raw,expected_request_sha256=refs['relational_request']['sha256'])
        operations.append({'candidate':label,'public_api':'prepare_relational_norm_v1','elapsed_seconds':time.monotonic()-started})
        need(wire(report)==wire(original),'fresh whole relational preparation differs from retained generation')
        report_refs[label]=write(output/(label+'-prepared-relational-report.json'),wire(report));actual_shape(report,label)
        started=time.monotonic();replayed=owner.validate_relational_norm_v1(report,raw,
            expected_request_sha256=refs['relational_request']['sha256'],expected_report_sha256=refs['expected_relational_report_sha256'])
        operations.append({'candidate':label,'public_api':'validate_relational_norm_v1','elapsed_seconds':time.monotonic()-started})
        need(wire(replayed)==wire(report),'whole public relational validator replay differs')
        replayed_refs[label]=write(output/(label+'-replayed-relational-report.json'),wire(replayed))
        started=time.monotonic();native=routes.prepare_native_fragment(family='deontic_fol',formula=original['native_formula'],expected_ast=original['native_ast'])
        operations.append({'candidate':label,'public_api':'prepare_native_fragment','elapsed_seconds':time.monotonic()-started})
        need(wire(native)==wire(original['native_fragment']) and native['lean_body']==original['lean_body']
             and wire(native['native_ast'])==wire(original['native_ast']),'exact full native route/AST/emitted declaration differs')
        reports[label]=report
        custody[label]={'norm_preparation':refs['norm_preparation'],'definition_evidence':refs['definition_evidence'],
            'relational_request':refs['relational_request'],'relational_report':refs['relational_report'],
            'norm_preparation_canonical_sha256':sha(wire(norm)),'typed_ast_sha256':norm['ast_sha256'],
            'native_ast_sha256':norm['native_ast_sha256'],'obligations':19,'definition_alternatives':2,'nominations':6,
            'original_source_scope_sha256':sha(wire(norm['correspondence']['source_scope'])),
            'original_context_evidence_sha256':sha(wire(norm['context_evidence'])),
            'original_unresolved_sha256':sha(wire(norm['correspondence']['retained_unresolved'])),
            'original_nomination_inventory_sha256':sha(wire(evidence['links'])),
            'source_meaning_and_definition_applicability_not_verified':True,'current_source_or_definition_replayed':False}
    need(reports['A']['native_ast']!=reports['B']['native_ast'],'distinct complete quantified/modal alternatives required')
    source,layout=joint_source(reports,emitter);source_ref=write(output/'LegalFullNorms.lean',source)
    summary={'schema':'legal-full-norm-native-preparation-summary/v1','passed':True,'phase':'prepare','candidates':['A','B'],
        'reports':report_refs,'replayed_reports':replayed_refs,'lean_source':source_ref,'rendering':layout,'retained_custody':custody,
        'operations':operations,'conditional_theorems':THEOREMS,
        'public_api_direct_calls_declared':{'prepare_relational_norm_v1':2,'validate_relational_norm_v1':2,'prepare_native_fragment':2},
        'call_count_scope':'driver direct API entries only; validators and relational preparation internally replay owners without a global call observer',
        'assumptions':['Each hNorm is an explicit unverified hypothesis for the whole original closed quantified/modal norm at one shared interpretation and fixed Nat time.',
            'A approval additionally requires hPermit for exactly P(Assign(r,d)∨Transfer(r,d)) with unchanged argument order and same interpretation/time.',
            'B yields only its complete permitted implication; no modal elimination, distribution, source truth, governing applicability or norm rewrite is assumed.'],
        'authority':{'source_truth':False,'source_equivalence':False,'legal_acceptance':False,'governing_selection':False,'review_authorization':False},
        'selected_interpretation':None,'governing_definition_use':None,'training_mask':0,'evaluation_gold_mask':0,
        'current_source_or_definition_replay_performed':False,'tagged_carriers_opened':False,'kernel_compilation_performed':False}
    summary_ref=dump(output/'preparation-summary.json',summary)
    generated={'schema':'legal-full-norm-native-prepared-inputs/v1','owned_request':request_ref,'request_sha256':request_ref['sha256'],
        'input_manifest':input_ref,'reports':report_refs,'replayed_reports':replayed_refs,'lean_source':source_ref,'summary':summary_ref,
        'driver':read(Path(__file__).resolve(),maximum=4*1024**2)[1]}
    generated_ref=dump(output/'preparation-manifest.json',generated)
    return dict(summary,prepared_inputs=generated_ref)
def axiom_observations(stdout,stderr,*,negative=False):
    seen={};other=[];marker=re.compile(r'\b(?:axiom|axioms|sorry|sorryAx)\b')
    for stream,text in (('stdout',stdout),('stderr',stderr)):
        for number,line in enumerate(text.splitlines(),1):
            if not marker.search(line):continue
            names=[name for name in THEOREMS if stream=='stdout' and re.fullmatch(
                r'(?:info: (?:\./)*LegalFullNorms\.lean:[1-9][0-9]*:[0-9]+: )?'+re.escape("'"+name+"' does not depend on any axioms"),line)]
            if names:
                need(names[0] not in seen,'duplicate exact empty-axiom observation');seen[names[0]]=[]
            else:other.append({'stream':stream,'line':number,'qualification_credit':0})
    need(set(seen)==set(THEOREMS) and (negative or not other),'exact three positive empty-axiom observations required')
    return seen,other


def compiler_controls(source,rendering):
    common='\nnamespace LegalFullNorms\n'
    parameters=' {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) (r d s : Entity)'
    patches={
        'missing_a_permit':common+'theorem negative_missing_a_permit'+parameters+
            '\n    (hNorm : CandidateA.formula_0 i t) : CandidateA.approvalAt i s r t := by\n'
            '  exact hNorm r d s (by assumption)\nend LegalFullNorms\n',
        'swapped_approve_arguments':common+'theorem negative_swapped_approve_arguments'+parameters+
            '\n    (hNorm : CandidateA.formula_0 i t) (hPermit : CandidateA.permittedActionsAt i r d t)\n'
            '    : CandidateA.approvalAt i r s t := by\n  exact hNorm r d s hPermit\nend LegalFullNorms\n',
        'b_illegal_p_stripping':common+'theorem negative_b_illegal_p_stripping'+parameters+
            '\n    (hNorm : CandidateB.formula_0 i t) : ('+rendering['b_plain']+') t := by\n'
            '  exact hNorm r d s\nend LegalFullNorms\n'}
    for patch in patches.values():need(not re.search(r'\b(?:sorry|admit|axiom)\b',patch),'no authored proof placeholders or axiom additions')
    return {name:(source+patch.encode(),patch) for name,patch in patches.items()}


def compilation_phase(inputs,output,input_ref,args,request,active):
    wrapper_raw,wrapper_ref=read(args.preparation_manifest,args.expected_preparation_manifest_sha256,4*1024**2)
    generated=completion_join(strict_json(wrapper_raw),request['source_sha256'])
    need(wire(generated['input_manifest'])==wire(input_ref),'prepared generation names another frozen input manifest')
    summary=strict_json(read(generated['summary']['path'],generated['summary'])[0])
    need(summary['passed'] is True and summary['phase']=='prepare' and summary['candidates']==['A','B']
         and summary['conditional_theorems']==THEOREMS and wire(summary['reports'])==wire(generated['reports'])
         and wire(summary['replayed_reports'])==wire(generated['replayed_reports'])
         and wire(summary['lean_source'])==wire(generated['lean_source']) and summary['kernel_compilation_performed'] is False
         and no_authority(summary)>0 and check_masks(summary)>0,'exact complete unreviewed prepared full norm summary required')
    source=read(generated['lean_source']['path'],generated['lean_source'])[0]
    report_raws={}
    for label in ('A','B'):
        raw=read(generated['reports'][label]['path'],generated['reports'][label])[0]
        need(raw==read(generated['replayed_reports'][label]['path'],generated['replayed_reports'][label])[0],
             'prepared/replayed whole relational bytes differ')
        report=strict_json(raw);actual_shape(report,label)
        original=strict_json(read(inputs['candidates'][label]['relational_report']['path'],inputs['candidates'][label]['relational_report'])[0])
        need(raw==wire(original),'compiled preparation changed original complete relational report')
        span=summary['rendering']['emitted_body_slices'][label];body=report['lean_body'].encode()
        need(source[span['byte_start']:span['byte_end']]==body and sha(body)==span['sha256'] and len(body)==span['bytes'],
             'whole unchanged emitted declaration slice differs')
        report_raws[label]=raw
    from ipfs_datasets_py.logic.backends import process
    attempt=Path(request['attempt_directory']);(attempt/'tmp').mkdir(mode=0o700,exist_ok=True);tool=inputs['toolchain'];probes=[]
    for name in ('lake','lean'):
        run,record=native_run(name+'-version',(tool[name]['path'],'--version'),{},(),output,attempt,process,active,timeout=10)
        versions=re.findall(r'\bLean \(?version ([0-9]+\.[0-9]+\.[0-9]+[^\s,)]*)',run.stdout)
        need(run.returncode==0 and not run.stderr and versions==['4.34.1']
             and ('Lake version' if name=='lake' else 'Lean (version') in run.stdout,'one exact stable Lean4.34.1 observation required')
        record['observed_lean_version']=versions[0];probes.append(record)
    project={'lakefile.toml':b'name = "legal_full_norms"\nversion = "0.1.0"\n\n[[lean_lib]]\nname = "legal"\nroots = ["LegalFullNorms"]\n',
        'lean-toolchain':(TOOLCHAIN+'\n').encode(),'LegalFullNorms.lean':source}
    artifact='.lake/build/lib/lean/LegalFullNorms.olean';command=(tool['lake']['path'],'--offline','--no-cache','build','legal')
    run,positive=native_run('positive',command,project,(*project,artifact),output,attempt,process,active)
    need(run.returncode==0 and run.ok and set(run.output_files)=={*project,artifact} and len(run.output_files[artifact])>0,
         'complete unchanged A/B declarations and conditional proofs must compile to nonempty olean')
    axioms,_=axiom_observations(run.stdout,run.stderr);negatives=[]
    for name,(mutant,patch) in compiler_controls(source,summary['rendering']).items():
        files=dict(project);files['LegalFullNorms.lean']=mutant
        run,record=native_run('negative-'+name,command,files,tuple(files),output,attempt,process,active)
        need(type(run.returncode) is int and run.returncode!=0,'meaning-changing proof control must fail natively')
        text=run.stdout+'\n'+run.stderr
        lines=[int(x) for x in re.findall(r'(?:error: )?(?:\./)*LegalFullNorms\.lean:([1-9][0-9]*):[0-9]+:',text)]
        need(any(line>source.count(b'\n') for line in lines)
             and (('assumption' in text.lower()) if name=='missing_a_permit' else 'type mismatch' in text.lower())
             and not re.search(r'unknown (?:module|package|identifier)|failed to (?:download|fetch)|no such file|not found',text,re.I),
             'negative must fail its exact appended proof obligation, not infrastructure')
        common_axioms,recovery=axiom_observations(run.stdout,run.stderr,negative=True)
        patch_ref=write(output/('negative-'+name)/'source-patch.lean.txt',patch.encode())
        diff=''.join(difflib.unified_diff(source.decode().splitlines(keepends=True),mutant.decode().splitlines(keepends=True),
            fromfile='unchanged-positive/LegalFullNorms.lean',tofile=name+'/LegalFullNorms.lean'))
        diff_ref=write(output/('negative-'+name)/'source.diff',diff.encode())
        record.update(control_refused=True,qualified_kernel_artifact=False,positive_common_prefix_sha256=sha(source),
            intended_theorem='LegalFullNorms.negative_'+name,patch=patch_ref,source_diff=diff_ref,
            diagnostic_source_lines=lines,common_positive_axiom_dependencies=common_axioms,
            unqualified_axiom_or_recovery_diagnostic_locations=recovery)
        dump(output/('negative-'+name)/'control-result.json',record);negatives.append(record)
    need(active['count']==6,'exact two version probes plus four offline Lake invocations')
    for label in ('A','B'):
        need(read(generated['reports'][label]['path'],generated['reports'][label])[0]==report_raws[label],
             'original relational report changed during compilation')
    return {'schema':'legal-full-norm-native-engineering-receipt/v1','passed':True,'phase':'compile',
        'preparation_completion_wrapper':wrapper_ref,'prepared_reports':generated['reports'],
        'unchanged_emitted_bodies':summary['rendering']['emitted_body_slices'],'lean_source':generated['lean_source'],
        'toolchain':tool,'bounded_version_probes':probes,'positive':positive,'compiler_negative_controls':negatives,
        'conditional_theorems':THEOREMS,'theorem_axiom_dependencies':axioms,'conditional_source_kernel_checked':True,
        'actual_native_invocations':6,'expensive_owner_replays_in_compile':0,'product_renderer_calls_in_compile':0,
        'norm_hypotheses':'explicit unverified hNorm for each full original norm at shared interpretation and fixed Nat time',
        'permission_hypothesis':'explicit unverified hPermit for exactly A whole permitted disjunction at same r,d,i,t',
        'authority':{'source_truth':False,'source_equivalence':False,'legal_acceptance':False,'governing_selection':False,
                     'review_authorization':False,'norm_rewrite':False,'training_credit':False,'gold_credit':False},
        'selected_interpretation':None,'governing_definition_use':None,'training_mask':0,'evaluation_gold_mask':0,
        'original_preparation_flags_changed':False,'negative_artifacts_qualified':False,
        'general_typed_native_Lean_denotation_preservation_proved':False,
        'native_file_access_scope':'cooperative exact three-file offline Lake project; Python audit does not observe native filesystem syscalls'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('prepare','compile'),required=True)
    parser.add_argument('--request',type=Path,required=True)
    parser.add_argument('--expected-request-sha256',required=True)
    parser.add_argument('--input-manifest',type=Path,required=True)
    parser.add_argument('--expected-input-manifest-sha256',required=True)
    parser.add_argument('--preparation-manifest',type=Path)
    parser.add_argument('--expected-preparation-manifest-sha256')
    args=parser.parse_args();started=time.monotonic()
    need(args.expected_request_sha256=='ENV_LEGAL_FULL_NORM_NATIVE_REQUEST_SHA256','fixed independently supplied native request pin sentinel required')
    expected=os.environ.get('LEGAL_FULL_NORM_NATIVE_REQUEST_SHA256','')
    need(re.fullmatch(r'[0-9a-f]{64}',expected) is not None,'source coordinator independent request pin missing')
    raw,request_ref=read(args.request,expected,1024**2);request=strict_json(raw)
    need(request['schema']=='owned-validation-request/v1' and request['cwd']==str(REPO) and Path.cwd()==REPO,
         'canonical owned native request/cwd required')
    need(request['selected_checks']==['full_norm_'+args.phase], 'exact full norm phase check required')
    need(tuple(request[k] for k in ('cpu_slots','memory_mb','child_process_slots','timeout_seconds','storage_bytes'))==SCOPES[args.phase],
         'unchanged frozen phase resource profile required')
    attempt=Path(request['attempt_directory']);output=Path(request['outputs']['exports'])
    need(output.parent==attempt and output.resolve(strict=True)==output and not any(output.iterdir())
         and stat.S_IMODE(output.stat().st_mode)&0o077==0,'private empty admitted output required')
    driver=read(Path(__file__).resolve(),maximum=4*1024**2)[1]
    need(request['argv'][2]==driver['path'] and request['source_sha256'].get(driver['path'])==driver['sha256']
         and request['source_sha256'].get(str(args.input_manifest))==args.expected_input_manifest_sha256,
         'independently frozen driver/input watcher pins required')
    need(os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and os.environ.get('IPFS_DATASETS_PY_MINIMAL_IMPORTS')=='1',
         'owned minimal environment required');sys.dont_write_bytecode=True
    need(sys.gettrace() is None and sys.getprofile() is None,'unprofiled fresh driver required')
    input_raw,input_ref=read(args.input_manifest,args.expected_input_manifest_sha256,4*1024**2)
    inputs=strict_json(input_raw);input_checks(inputs,args.phase)
    if args.phase=='prepare':
        need(args.preparation_manifest is None and args.expected_preparation_manifest_sha256 is None,'prepare cannot consume future completion')
        prior=original_closed_custody(inputs)
    else:
        need(args.preparation_manifest is not None and args.expected_preparation_manifest_sha256 is not None
             and request['source_sha256'].get(str(args.preparation_manifest))==args.expected_preparation_manifest_sha256,
             'compile requires separately watched completed preparation wrapper');prior=None
    pins=dict(request['source_sha256'])
    for ref in inputs['empty_source_descriptors']:
        need(ref['bytes']==0 and ref['path'] not in pins,'empty descriptors preserved outside nonempty native watcher');pins[ref['path']]=ref['sha256']
    for path,pin in request['source_sha256'].items():need(read(path,pin,4*1024**2)[1]['bytes']>0,'native watcher nonempty requirement')
    need(not any(name=='ipfs_datasets_py' or name.startswith('ipfs_datasets_py.') for name in sys.modules),
         'no first-party modules may be preloaded outside exact canonical source capture')
    captures,namespaces,optional,blocked,executed={}, {}, [], [], set()
    allowed_reads=descriptor_paths(inputs)|{Path(path) for path in pins}|{args.request,args.input_manifest}
    if args.phase=='compile':
        wrapper=strict_json(read(args.preparation_manifest,args.expected_preparation_manifest_sha256,4*1024**2)[0])
        generated=completion_join(wrapper,request['source_sha256'])
        allowed_reads|=descriptor_paths(wrapper)|descriptor_paths(generated)|{args.preparation_manifest}
        runtime=strict_json(read(inputs['toolchain']['runtime_manifest']['path'],inputs['toolchain']['runtime_manifest'])[0])
        allowed_reads|=descriptor_paths(runtime)
    active={'command':None,'count':0,'cwd_root':None,'observations':[]}
    forbidden={'torch','transformers','huggingface_hub','datasets','sentence_transformers','z3','cvc5',
               'pysmt','duckdb','psycopg','psycopg2','pymysql','sqlalchemy'}
    need(not any(name.split('.')[0] in forbidden for name in sys.modules),'forbidden model/solver/database module preloaded')
    def private_path(offered,dirfd=None):
        if type(offered) is int:
            offered=os.readlink('/proc/self/fd/'+str(offered))
        path=Path(os.fsdecode(offered))
        if not path.is_absolute() and type(dirfd) is int and dirfd>=0:
            base=Path(os.readlink('/proc/self/fd/'+str(dirfd)))
            need(base.resolve(strict=True)==base and attempt in base.parents,'private live directory descriptor required')
            path=base/path
        path=path.absolute()
        need(attempt in path.parents,'mutation outside owned private attempt: '+str(path));return path
    def audit(event,values):
        if event=='subprocess.Popen':
            need(args.phase=='compile' and active['command'] is not None and len(active['observations'])==0,
                 'native subprocess outside one declared bounded invocation')
            executable,argv,cwd,environment=values
            need(executable=='/usr/bin/prlimit' and list(argv)==active['command']
                 and Path(cwd).parent==attempt/'tmp' and Path(cwd).resolve(strict=True)==Path(cwd)
                 and Path(cwd).name.startswith('logic-tool-'),'native command/wrapper/cwd differs from declared bounds')
            expected_environment={'PATH':str(TOOLROOT/'bin')+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
                'LEAN_SYSROOT':str(TOOLROOT),'ELAN_TOOLCHAIN':TOOLCHAIN,'LEAN_NUM_THREADS':'1',
                'HOME':str(cwd),'TMPDIR':str(cwd),'TMP':str(cwd),'TEMP':str(cwd)}
            need(type(environment) is dict and environment==expected_environment,'native offline private compiler environment differs')
            active['observations'].append({'executable':executable,'argv':list(argv),'cwd':str(cwd),
                'environment':dict(environment),'scope':'Python parent spawn audit; native descendants covered by ToolRunner lifecycle'})
            return
        if event.startswith(('socket.','subprocess.')) or event in {'os.system','os.fork','os.forkpty',
                'os.posix_spawn','os.exec','os.spawn','pty.spawn','sqlite3.connect'} or (
                event=='import' and values and str(values[0]).split('.')[0] in forbidden):
            blocked.append(event);raise RuntimeError('event outside declared conditional/native scope: '+event)
        if event in {'os.mkdir','os.remove','os.rmdir'}:
            directory_fd=values[2] if event=='os.mkdir' else values[1]
            private_path(values[0],directory_fd)
        elif event in {'os.rename','os.link'}:
            private_path(values[0],values[2]);private_path(values[1],values[3])
        elif event in {'os.symlink','os.truncate'}:
            raise RuntimeError('symlink/truncate outside authored qualification operations')
        if event=='open' and values and isinstance(values[0],(str,bytes,os.PathLike)):
            path=Path(os.fsdecode(values[0])).absolute();mode=values[1] if len(values)>1 else None;flags=values[2] if len(values)>2 else 0
            writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)))
            if writing:private_path(path)
            need(path.suffix.lower() not in {'.pt','.pth','.ckpt','.safetensors','.onnx','.parquet'},'weights/table data outside scope')
            if not writing and ROOT/'artifacts' in path.parents and attempt not in path.parents:
                need(path in allowed_reads,'unselected artifact input read: '+str(path))
            need(not path.name.endswith('.tagged.json'),'tagged carriers outside full norm mechanical scope')
        if event=='exec':
            filename=getattr(values[0],'co_filename','')
            if filename and not filename.startswith('<'):
                path=Path(filename).absolute()
                need(ROOT/'artifacts' not in path.parents,'artifact helper execution outside exact stage driver')
                if REPO in path.parents:
                    need(str(path) in captures,'first-party execution bypassed verified compilation');executed.add(str(path))
    sys.addaudithook(audit)
    original=install_compile_capture(pins,set(),captures)
    sys.meta_path.insert(0,CanonicalFinder(namespaces,optional))
    try:
        from ipfs_datasets_py.logic.autoformal.tree_pin import require_workspace_logic_tree
        tree=require_workspace_logic_tree()
        if args.phase=='prepare':result=preparation_phase(inputs,output,request_ref,input_ref)
        else:result=compilation_phase(inputs,output,input_ref,args,request,active)
        need(not blocked and sys.gettrace() is None and sys.getprofile() is None,'unexpected event/observer state')
        need(not any(name.split('.')[0] in forbidden for name in sys.modules),'forbidden model/solver/database module loaded')
        sources=capture_all(output,captures,namespaces,executed,{})
        input_checks(inputs,args.phase)
        for path,pin in pins.items():read(path,pin,4*1024**2)
        read(args.request,request_ref);read(args.input_manifest,input_ref)
        if args.phase=='compile':
            completion_join(strict_json(read(args.preparation_manifest,args.expected_preparation_manifest_sha256,4*1024**2)[0]),request['source_sha256'])
        result.update(input_manifest=input_ref,owned_request=request_ref,driver=driver,logic_tree_pin=tree,
            retained_original_completions=prior,source_file_count=sources['unique_source_file_count'],
            compile_observation_count=sources['compile_observation_count'],namespace_count=sources['namespace_count'],
            optional_lib_import_refusals=sorted(set(optional)),blocked_events=blocked,
            fake_namespace_injection_performed=False,global_positive_call_profile_installed=False,
            source_and_product_owners_unchanged=True,elapsed_seconds=time.monotonic()-started,
            driver_authorship_scope='stage engineering harness; qualification readback is saved-artifact verification, not independent runtime replication')
        dump(output/'phase-result.json',result);print(json.dumps(result,sort_keys=True))
    finally:importlib.machinery.SourceFileLoader.get_code=original


if __name__=='__main__':main()
