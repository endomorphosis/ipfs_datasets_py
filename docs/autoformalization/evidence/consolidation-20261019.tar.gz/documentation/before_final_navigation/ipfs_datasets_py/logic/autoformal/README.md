# LegalIR autoformalization module

This is the canonical source, review, graph and Lean integration module for the
LegalIR pipeline. Start with the
[maintained documentation](../../../docs/autoformalization/README.md) and
[current handoff](../../../docs/autoformalization/CURRENT_STATE.md).

| Responsibility | Existing entry points |
| --- | --- |
| Literal source views | `legal_parent_text_views.prepare_parent_text_views`, `exact_parent_text_occurrences` |
| Source and occurrence contracts | `corpus_source.build_source_version`, `build_source_occurrence`, `build_context_declaration` |
| Declared qualification dimensions | `corpus_qualification.prepare_qualification`, `derive_eligibility` |
| Candidate graph | `corpus_graph.build_node`, `build_edge`, `build_graph_snapshot` |
| Plaintext parent definition review | `corpus_definition_review_v2.prepare_parent_definition_review_evidence_v1` and its original-bound validator/subject/assessment functions |
| Scoped parent lookup | `scoped_definition_resolution.build_parent_definition_lookup_registry_v1`, `resolve_parent_definition_lookup_v1` |
| Parent candidate use | `corpus_definition_use_v2.prepare_parent_definition_use_v1`, `validate_parent_definition_use_candidate_v1` |
| Combined parent use review | `corpus_definition_use_review_v2.prepare_parent_definition_use_review_evidence_v1` and its validator/subject/assessment functions |
| Conditional project preparation | `legal_corpus_definition_use_lake_v2`; inspect current qualification before adopting its newly present parent APIs |
| Native checking | `legal_corpus_definition_use_native_v2.build_definition_use_native_v2`; parent adaptation remains staged at the documented cutoff |
| Shared and incremental corpus | `legal_corpus_shared_lake.prepare_shared_definition_corpus`, `build_shared_definition_corpus`; `legal_corpus_incremental.build_incremental_shared_corpus` |

The eight existing qualification dimensions are processing, source integrity,
interpretation, representation, dependencies, native translation, Lean compilation
and proof. Declared evidence is not admission. Keep exact source/review inputs,
assumptions, abstentions, missing values and failed histories attached to outputs.

Numerical autoencoders retain their established owners in
`logic/formalization/autoencoder` and `optimizers/logic_theorem_optimizer`.
The public LegalIR inference facade is `logic/legal_ir/autoencoder.py`.
Reuse the distinct 8D, 384D, 768D and native4096 profiles through their existing
contracts; do not copy their implementations here or dispatch by width alone.

Put reusable source/graph/review/Lean work in this module with its owning tests
and documentation. `artifacts/` and `workspace/` contain evidence, checkpoints,
private snapshots and execution records; they are not importable production
implementations. Migrate candidates only after their original qualification and
source-compatible installation gates. Preserve historical snapshots and active
owner state, and use the existing source/resource admission interfaces.

A successful fixture, authenticated signature, prepared project or native theorem
does not independently establish statutory meaning. The
[current handoff](../../../docs/autoformalization/CURRENT_STATE.md) distinguishes
installed, staged and still-unqualified work so a new agent can reuse it directly.
