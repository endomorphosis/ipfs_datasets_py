# LegalIR autoformalization

Start with [current state and next work](CURRENT_STATE.md), then use the owner
guide below. Canonical source, review, graph and Lean code lives in
[`ipfs_datasets_py/logic/autoformal`](../../ipfs_datasets_py/logic/autoformal/README.md).
Learned numerical implementations retain their existing shared owners in
`logic/formalization/autoencoder` and `optimizers/logic_theorem_optimizer`.

This directory is the maintained home for legal autoformalization guides. The
older `docs/autoencoders` paths redirect here so existing links continue to work.
The [autoencoder handbook](../autoencoders/README.md) still owns model operations.

## Follow the pipeline

| Task | Existing guide |
| --- | --- |
| Preserve source version, exact occurrences and explicit qualification dimensions | [Source and qualification contracts](legal_corpus_contracts.md) |
| Inspect selected plaintext parent rows and unresolved source identities | [Parent inventory](legal_parent_source_inventory_v1.md), [identity bindings](legal_parent_source_identity_bindings_v1.md) |
| Join original source, paired spans and entity observations | [Source/span/entity join](legal_source_span_entity_join_v1.md), [census](legal_source_span_entity_census_v1.md) |
| Preserve complete source context and declared review requests | [Source review packets](corpus_source_review_packets.md), [source sampling review](legal_source_sampling_review.md) |
| Prepare definitions and plaintext parent review subjects | [Definition profile](legal_source_definition_v2.md), [definition review](corpus_definition_review_v2.md) |
| Resolve scoped candidates and bind an explicit alias use | [Scoped lookup](scoped_definition_resolution.md), [definition use](corpus_definition_use_v2.md) |
| Authenticate the separate combined-use subject | [Combined-use review](corpus_definition_use_review_v2.md) |
| Preserve complete typed norm declarations and applicability decisions | [Content declarations](legal_norm_content_declaration_v1.md), [applicability](legal_norm_definition_applicability_v1.md) |
| Exchange candidate graphs with source-linked companions | [Graph exchange](legal_corpus_graph_exchange.md), [proposed graph adapter](legal_corpus_proposed_graph_adapter.md) |
| Prepare and check conditional definition-use Lean projects | [Integration guide](definition_use_v2_integration.md), [active Lake owner guide](../autoencoders/legal_corpus_definition_use_lake_v2.md), [active native owner guide](../autoencoders/legal_corpus_definition_use_native_v2.md) |
| Compose shared and incremental projects | [Shared corpus](legal_corpus_shared_lake.md), [incremental corpus](legal_corpus_incremental.md) |
| Retain source-bound preservation, kernel claims and observational indexes | [Preservation](legal_corpus_definition_use_preservation_v2.md), [kernel claims](legal_corpus_definition_use_preservation_kernel_claims_v2.md), [index](legal_corpus_definition_use_preservation_index_v2.md) |
| Select an existing learned representation or checkpoint | [Model API map](../autoencoders/api_map.md), [four-profile reuse register](../autoencoders/evidence/legal-ir-four-dimension-reuse-20261018.json) |

## Keep one implementation and one current state

Extend the existing owner and its tests. Do not import product code from
`artifacts/` or `workspace/`, copy a historical candidate over newer canonical
code, or treat an old pending proposal as a fresh task. Staged candidates require
their original qualification and installation checks. Installed, tested, committed
and published are separate states.

Historical run receipts, private source snapshots, checkpoints and failed attempts
retain their identities. Documentation moves do not rerun experiments, grant legal
authority or release resources. Active owner databases and other workers' leases
remain with their existing typed owners.

The [detailed execution plan](../autoencoders/legal_ir_text_to_lean4_execution_plan_20261018.md)
and [roadmap](../autoencoders/legal_ir_uscode_roadmap_20261018.md) retain research
rationale and dated evidence. Use CURRENT_STATE for the present handoff; consult
original receipts before resuming any historical workload.
