# LegalIR current state and handoff

Observation cutoff: **2026-10-19 20:11 UTC**. This is a finite source/documentation
observation, not a new benchmark or a remote-publication audit. Start at the
[autoformalization index](README.md); update this page in place when the evidence
changes instead of adding another current plan.

## Canonical ownership

| Layer | Owner and established boundary |
| --- | --- |
| Plaintext source and context | `logic.autoformal.legal_parent_text_views`, `corpus_source`, parent inventory/identity owners preserve physical occurrences and declared context. Plaintext intake does not require invented HTML/XML. |
| Typed meaning and candidate graphs | Existing `logic.autoformal` definition, relational-norm and corpus graph owners retain unresolved interpretations, scope and source companions. |
| Review and lookup | `corpus_definition_review_v2`, `scoped_definition_resolution`, `corpus_definition_use_v2`, `corpus_definition_use_review_v2` have explicit parent APIs. Authentication and engineering fixtures establish no qualified human review. |
| Conditional Lean preparation | `legal_corpus_definition_use_lake_v2` currently contains parent prepare/validate/load/write APIs. Their qualification and installation receipts must be reconciled before declaring this increment complete. |
| Native Lean checking | Canonical `legal_corpus_definition_use_native_v2` currently exposes the official profile; the parent adapter remains a staged candidate. A specification, project or fixture test is not a native build receipt. |
| Shared/incremental corpus and preservation | Reuse `legal_corpus_shared_lake`, `legal_corpus_incremental` and the existing preservation/index/kernel owners. Parent composition and reviewed statutory admission remain separate gates. |
| Learned inference and fitting | Existing `logic.formalization.autoencoder` and `optimizers.logic_theorem_optimizer` owners preserve checkpoint compatibility, controlled model execution and numerical state. The public domain facade remains `logic.legal_ir.autoencoder`. |

## Reuse completed work

The existing [reuse register](../autoencoders/evidence/legal-ir-four-dimension-reuse-20261018.json)
identifies `parent-combined-use-review-qualified-20261019` as its latest observed
reconciliation. It retains receipt locations and historical cutoffs. Its current
implementation record includes installed parent definition review, scoped lookup,
candidate use and combined-use review. Do not schedule those implementations again.

The original combined-use review delivery records 25 parent cases plus three
official regressions. Its earlier startup refusal is a distinct zero-test event.
The parent lookup/use delivery records 141 focused passes. These are engineering
cohorts; they are not independent legal examples and must not be pooled as such.

The fixed CP38-to-CP128 continuation and its three inference jobs are closed.
Later completion-budget inference produced two complete typed outputs but zero
exact reconstructions on two exposed authored fixtures. Preserve the adverse
meaning/role results. Do not repeat these campaigns merely to migrate files.

The parent-native adapter is staged under the original
`artifacts/legal-ir-parent-use-native-20261019T193900Z` handoff. Its previous
delivery reported static review and unexecuted tests. Reconcile the now-present
parent Lake APIs against that worker's actual receipts before resuming it; source
presence alone does not establish a successful dependency qualification.

## Representation and qualification boundaries

Keep the existing 8D, 384D, 768D and genuine Leanstral4096 profiles separate. Record
producer/revision, tokenizer, normalization, source access, conditioning width,
bottleneck, decoder and checkpoint lineage. A dimension is not an interchangeable
model contract; padding or truncation cannot create compatibility. Use the
[model handbook](../autoencoders/README.md) and the existing reuse register.

The existing `corpus_qualification` owner separately records eight dimensions:
processing, source integrity, interpretation, representation, dependencies,
native translation, Lean compilation and proof. Preserve its explicit statuses
and blockers. Candidate custody, declared eligibility, native compilation and
reviewed statutory fidelity remain different outcomes.

## Next work, in dependency order

1. Reconcile canonical product/test/doc files and retained receipts through the
   finite migration inventory. Preserve foreign edits and unqualified candidates.
2. Obtain the parent Lake worker's successful qualification/installation receipts,
   or retain their missing/failed status. Resume the staged parent-native adapter
   through the existing admitted validation owner only when its inputs qualify.
3. Extend the supported parent shared-corpus boundary using existing owners;
   preserve separate preparation, native build, assumptions and review outcomes.
4. Obtain actual source/edition/context decisions and qualified reviews for one
   definition, one complete norm using it and a second genuine statutory use.
   The already retained questions remain the intake; do not invent annotations.
5. Design any model improvement from the existing adverse results and reviewed
   target eligibility. A new width sweep, training run or broad benchmark is not
   required to consolidate the codebase.

No genuine qualified statutory review, completed reviewed end-to-end corpus,
new training, new native build, commit or publication is established by this
documentation migration. Missing owner closeouts remain unknown with reasons.

Historical research detail remains in the
[execution plan](../autoencoders/legal_ir_text_to_lean4_execution_plan_20261018.md).
Its dated pending sections are evidence history and do not supersede this cutoff
or later original-owner receipts.
