#!/usr/bin/env python3
"""Prepare, but never install, a finite LegalIR documentation relocation.

Only stdlib; all writes stay below the explicitly supplied stage. No imports of
product code, test execution, databases, models, toolchains, or network access.
Run check_docs.py separately after preparation; root owns canonical installation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import unicodedata


SELECTED = """
corpus_definition_review.md
corpus_definition_review_v2.md
corpus_definition_use_review_v2.md
corpus_definition_use_v2.md
corpus_parent_alignment_adapter.md
corpus_parent_occurrence_adapter.md
corpus_source_review.md
corpus_source_review_packets.md
definition_use_v2_integration.md
legal_bound_variable_definition_v1.md
legal_corpus_contracts.md
legal_corpus_definition_norm_adapter.md
legal_corpus_definition_use_preservation_elaboration_v2.md
legal_corpus_definition_use_preservation_index_v2.md
legal_corpus_definition_use_preservation_kernel_claims_v2.md
legal_corpus_definition_use_preservation_packet_v2.md
legal_corpus_definition_use_preservation_theorem_lineage_v2.md
legal_corpus_definition_use_preservation_v2.md
legal_corpus_graph_exchange.md
legal_corpus_incremental.md
legal_corpus_lake.md
legal_corpus_legacy_source_join.md
legal_corpus_norm_definition_adapter.md
legal_corpus_proposed_graph_adapter.md
legal_corpus_shared_lake.md
legal_corpus_span_adapter.md
legal_norm_content_adjudication_v1.md
legal_norm_content_declaration_binding_v1.md
legal_norm_content_declaration_v1.md
legal_norm_content_responses_v1.md
legal_norm_definition_applicability_v1.md
legal_norm_definition_application_binding_v1.md
legal_norm_definition_evidence_v1.md
legal_norm_interpretation_review_v1.md
legal_norm_scope_correspondence_v1.md
legal_parent_complete_source_metadata.md
legal_parent_source_identity_bindings_v1.md
legal_parent_source_inventory_v1.md
legal_parent_source_metadata_inventory_v1.md
legal_source_correspondence_requests_v1.md
legal_source_definition_v2.md
legal_source_norm_scope_v1.md
legal_source_sampling.md
legal_source_sampling_definition_binding_v2.md
legal_source_sampling_definition_lake_v2.md
legal_source_sampling_review.md
legal_source_span_entity_census_v1.md
legal_source_span_entity_join_v1.md
legal_source_span_target_eligibility_v1.md
legal_source_typed_norm_join_v1.md
scoped_definition_resolution.md
""".split()

EXCLUDED = {
    "docs/autoencoders/legal_corpus_definition_use_lake_v2.md": "active worker's parent Lake guide; keep current owner/path",
    "docs/autoencoders/legal_corpus_definition_use_native_v2.md": "parent native candidate staged; keep current owner/path",
    "docs/autoencoders/legal_source_span_runtime.md": "learned-runtime guide remains with autoencoder handbook",
    "docs/autoencoders/legal_source_span_consumer_binding.md": "learned consumer contract remains with autoencoder handbook",
    "docs/autoencoders/legal_source_span_bound_training.md": "training guide remains with autoencoder handbook",
    "docs/autoencoders/evidence/legal-ir-four-dimension-reuse-20261018.json": "existing live register retained unchanged",
}
POINTERS = (
    "docs/autoencoders/README.md",
    "docs/autoencoders/api_map.md",
    "docs/autoencoders/legal_ir_text_to_lean4_execution_plan_20261018.md",
    "docs/autoencoders/legal_ir_uscode_roadmap_20261018.md",
    "docs/autoencoders/legal_ir_uscode_corpus_improvement_plan_20261015.md",
)

INLINE = re.compile(r"(?P<before>!?\[[^\]\n]*\]\()(?P<url><[^>\n]+>|[^\s)]+)(?P<after>(?:\s+[^)\n]*)?\))")
REFERENCE = re.compile(r"^(?P<before> {0,3}\[[^\]\n]+\]:\s*)(?P<url><[^>\n]+>|\S+)(?P<after>.*)$")


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def descriptor(path: Path, raw: bytes | None = None) -> dict:
    raw = path.read_bytes() if raw is None else raw
    return {"bytes": len(raw), "sha256": digest(raw)}


def unfenced_lines(text: str):
    fence = None
    for line in text.splitlines(keepends=True):
        match = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        eligible = fence is None
        if match:
            mark = match.group(1)
            if fence is None:
                fence = (mark[0], len(mark))
            elif mark[0] == fence[0] and len(mark) >= fence[1]:
                fence = None
            yield line, False
        else:
            yield line, eligible


def headings(text: str) -> list[str]:
    result = []
    for line, eligible in unfenced_lines(text):
        if eligible:
            match = re.match(r"^ {0,3}#{1,6}\s+(.+?)\s*#*\s*$", line)
            if match:
                result.append(match.group(1))
    return result


def anchors(text: str) -> list[str]:
    """GitHub-compatible heading IDs for this bounded corpus's ATX headings."""
    seen = {}
    result = []
    for heading in headings(text):
        heading = re.sub(r"<[^>]+>", "", heading)
        heading = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", heading)
        value = "".join(c for c in heading.lower() if c in " -_" or unicodedata.category(c)[0] in "LN" or unicodedata.category(c)[0] == "M").replace(" ", "-")
        number = seen.get(value, 0)
        seen[value] = number + 1
        result.append(value if number == 0 else f"{value}-{number}")
    return result


def local_target(url: str, source: str) -> tuple[str, str] | None:
    angle = url.startswith("<") and url.endswith(">")
    value = url[1:-1] if angle else url
    if value.startswith(("#", "/")) or re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", value):
        return None
    part, sep, suffix = value.partition("#")
    if not part:
        return None
    path, query, query_text = part.partition("?")
    resolved = os.path.normpath(os.path.join(os.path.dirname(source), path))
    return resolved, ("?" + query_text if query else "") + ("#" + suffix if sep else "")


def rewrite(text: str, source: str, destination: str, mapping: dict[str, str]) -> tuple[str, list[dict]]:
    changes = []
    def transform(match):
        old = match.group("url")
        local = local_target(old, source)
        if local is None:
            return match.group(0)
        target, suffix = local
        target = mapping.get(target, target)
        relative = os.path.relpath(target, os.path.dirname(destination)).replace(os.sep, "/") + suffix
        new = "<" + relative + ">" if old.startswith("<") else relative
        if old != new:
            changes.append({"original": old, "rewritten": new, "resolved_repository_relative_target": target})
        return match.group("before") + new + match.group("after")
    result = []
    for line, eligible in unfenced_lines(text):
        if eligible:
            line = INLINE.sub(transform, line)
            line = REFERENCE.sub(transform, line)
        result.append(line)
    return "".join(result), changes


def redirect(text: str, destination: str, source: str) -> str:
    title = headings(text)[0]
    target = os.path.relpath(destination, os.path.dirname(source)).replace(os.sep, "/")
    original_ids = anchors(text)
    result = f"# {title}\n\nThis guide moved to [{title}]({target}).\n\nThe maintained body lives in `docs/autoformalization/`. This compatibility page\npreserves existing links; implementation and qualification history belong to the\nlinked guide and its original receipts.\n"
    for value in original_ids[1:]:
        result += f'\n<a id="{value}"></a>\n'
    result += f"\n[Open the maintained guide]({target}).\n"
    return result


HUB = """# LegalIR autoformalization

Start with [current state and next work](CURRENT_STATE.md), then use the owner
guide below. Canonical source, review, graph and Lean code lives in
[`ipfs_datasets_py/logic/autoformal`](../../ipfs_datasets_py/logic/autoformal/README.md).
Learned numerical implementations retain their existing shared owners in
`logic/formalization/autoencoder` and `optimizers/logic_theorem_optimizer`.

This directory is the maintained home for legal autoformalization guides. The
older `docs/autoencoders` paths redirect here so existing links continue to work.
The [autoencoder handbook](../autoencoders/README.md) still owns model operations.

## Follow the pipeline

| Task | Existing guide |
| --- | --- |
| Preserve source version, exact occurrences and explicit qualification dimensions | [Source and qualification contracts](legal_corpus_contracts.md) |
| Inspect selected plaintext parent rows and unresolved source identities | [Parent inventory](legal_parent_source_inventory_v1.md), [identity bindings](legal_parent_source_identity_bindings_v1.md) |
| Join original source, paired spans and entity observations | [Source/span/entity join](legal_source_span_entity_join_v1.md), [census](legal_source_span_entity_census_v1.md) |
| Preserve complete source context and declared review requests | [Source review packets](corpus_source_review_packets.md), [source sampling review](legal_source_sampling_review.md) |
| Prepare definitions and plaintext parent review subjects | [Definition profile](legal_source_definition_v2.md), [definition review](corpus_definition_review_v2.md) |
| Resolve scoped candidates and bind an explicit alias use | [Scoped lookup](scoped_definition_resolution.md), [definition use](corpus_definition_use_v2.md) |
| Authenticate the separate combined-use subject | [Combined-use review](corpus_definition_use_review_v2.md) |
| Preserve complete typed norm declarations and applicability decisions | [Content declarations](legal_norm_content_declaration_v1.md), [applicability](legal_norm_definition_applicability_v1.md) |
| Exchange candidate graphs with source-linked companions | [Graph exchange](legal_corpus_graph_exchange.md), [proposed graph adapter](legal_corpus_proposed_graph_adapter.md) |
| Prepare and check conditional definition-use Lean projects | [Integration guide](definition_use_v2_integration.md), [active Lake owner guide](../autoencoders/legal_corpus_definition_use_lake_v2.md), [active native owner guide](../autoencoders/legal_corpus_definition_use_native_v2.md) |
| Compose shared and incremental projects | [Shared corpus](legal_corpus_shared_lake.md), [incremental corpus](legal_corpus_incremental.md) |
| Retain source-bound preservation, kernel claims and observational indexes | [Preservation](legal_corpus_definition_use_preservation_v2.md), [kernel claims](legal_corpus_definition_use_preservation_kernel_claims_v2.md), [index](legal_corpus_definition_use_preservation_index_v2.md) |
| Select an existing learned representation or checkpoint | [Model API map](../autoencoders/api_map.md), [four-profile reuse register](../autoencoders/evidence/legal-ir-four-dimension-reuse-20261018.json) |

## Keep one implementation and one current state

Extend the existing owner and its tests. Do not import product code from
`artifacts/` or `workspace/`, copy a historical candidate over newer canonical
code, or treat an old pending proposal as a fresh task. Staged candidates require
their original qualification and installation checks. Installed, tested, committed
and published are separate states.

Historical run receipts, private source snapshots, checkpoints and failed attempts
retain their identities. Documentation moves do not rerun experiments, grant legal
authority or release resources. Active owner databases and other workers' leases
remain with their existing typed owners.

The [detailed execution plan](../autoencoders/legal_ir_text_to_lean4_execution_plan_20261018.md)
and [roadmap](../autoencoders/legal_ir_uscode_roadmap_20261018.md) retain research
rationale and dated evidence. Use CURRENT_STATE for the present handoff; consult
original receipts before resuming any historical workload.
"""


CURRENT = """# LegalIR current state and handoff

Observation cutoff: **2026-10-19 20:11 UTC**. This is a finite source/documentation
observation, not a new benchmark or a remote-publication audit. Start at the
[autoformalization index](README.md); update this page in place when the evidence
changes instead of adding another current plan.

## Canonical ownership

| Layer | Owner and established boundary |
| --- | --- |
| Plaintext source and context | `logic.autoformal.legal_parent_text_views`, `corpus_source`, parent inventory/identity owners preserve physical occurrences and declared context. Plaintext intake does not require invented HTML/XML. |
| Typed meaning and candidate graphs | Existing `logic.autoformal` definition, relational-norm and corpus graph owners retain unresolved interpretations, scope and source companions. |
| Review and lookup | `corpus_definition_review_v2`, `scoped_definition_resolution`, `corpus_definition_use_v2`, `corpus_definition_use_review_v2` have explicit parent APIs. Authentication and engineering fixtures establish no qualified human review. |
| Conditional Lean preparation | `legal_corpus_definition_use_lake_v2` currently contains parent prepare/validate/load/write APIs. Their qualification and installation receipts must be reconciled before declaring this increment complete. |
| Native Lean checking | Canonical `legal_corpus_definition_use_native_v2` currently exposes the official profile; the parent adapter remains a staged candidate. A specification, project or fixture test is not a native build receipt. |
| Shared/incremental corpus and preservation | Reuse `legal_corpus_shared_lake`, `legal_corpus_incremental` and the existing preservation/index/kernel owners. Parent composition and reviewed statutory admission remain separate gates. |
| Learned inference and fitting | Existing `logic.formalization.autoencoder` and `optimizers.logic_theorem_optimizer` owners preserve checkpoint compatibility, controlled model execution and numerical state. The public domain facade remains `logic.legal_ir.autoencoder`. |

## Reuse completed work

The existing [reuse register](../autoencoders/evidence/legal-ir-four-dimension-reuse-20261018.json)
identifies `parent-combined-use-review-qualified-20261019` as its latest observed
reconciliation. It retains receipt locations and historical cutoffs. Its current
implementation record includes installed parent definition review, scoped lookup,
candidate use and combined-use review. Do not schedule those implementations again.

The original combined-use review delivery records 25 parent cases plus three
official regressions. Its earlier startup refusal is a distinct zero-test event.
The parent lookup/use delivery records 141 focused passes. These are engineering
cohorts; they are not independent legal examples and must not be pooled as such.

The fixed CP38-to-CP128 continuation and its three inference jobs are closed.
Later completion-budget inference produced two complete typed outputs but zero
exact reconstructions on two exposed authored fixtures. Preserve the adverse
meaning/role results. Do not repeat these campaigns merely to migrate files.

The parent-native adapter is staged under the original
`artifacts/legal-ir-parent-use-native-20261019T193900Z` handoff. Its previous
delivery reported static review and unexecuted tests. Reconcile the now-present
parent Lake APIs against that worker's actual receipts before resuming it; source
presence alone does not establish a successful dependency qualification.

## Representation and qualification boundaries

Keep the existing 8D, 384D, 768D and genuine Leanstral4096 profiles separate. Record
producer/revision, tokenizer, normalization, source access, conditioning width,
bottleneck, decoder and checkpoint lineage. A dimension is not an interchangeable
model contract; padding or truncation cannot create compatibility. Use the
[model handbook](../autoencoders/README.md) and the existing reuse register.

The existing `corpus_qualification` owner separately records eight dimensions:
processing, source integrity, interpretation, representation, dependencies,
native translation, Lean compilation and proof. Preserve its explicit statuses
and blockers. Candidate custody, declared eligibility, native compilation and
reviewed statutory fidelity remain different outcomes.

## Next work, in dependency order

1. Reconcile canonical product/test/doc files and retained receipts through the
   finite migration inventory. Preserve foreign edits and unqualified candidates.
2. Obtain the parent Lake worker's successful qualification/installation receipts,
   or retain their missing/failed status. Resume the staged parent-native adapter
   through the existing admitted validation owner only when its inputs qualify.
3. Extend the supported parent shared-corpus boundary using existing owners;
   preserve separate preparation, native build, assumptions and review outcomes.
4. Obtain actual source/edition/context decisions and qualified reviews for one
   definition, one complete norm using it and a second genuine statutory use.
   The already retained questions remain the intake; do not invent annotations.
5. Design any model improvement from the existing adverse results and reviewed
   target eligibility. A new width sweep, training run or broad benchmark is not
   required to consolidate the codebase.

No genuine qualified statutory review, completed reviewed end-to-end corpus,
new training, new native build, commit or publication is established by this
documentation migration. Missing owner closeouts remain unknown with reasons.

Historical research detail remains in the
[execution plan](../autoencoders/legal_ir_text_to_lean4_execution_plan_20261018.md).
Its dated pending sections are evidence history and do not supersede this cutoff
or later original-owner receipts.
"""


MODULE = """# LegalIR autoformalization module

This is the canonical source, review, graph and Lean integration module for the
LegalIR pipeline. Start with the
[maintained documentation](../../../docs/autoformalization/README.md) and
[current handoff](../../../docs/autoformalization/CURRENT_STATE.md).

| Responsibility | Existing entry points |
| --- | --- |
| Literal source views | `legal_parent_text_views.prepare_parent_text_views`, `exact_parent_text_occurrences` |
| Source and occurrence contracts | `corpus_source.build_source_version`, `build_source_occurrence`, `build_context_declaration` |
| Declared qualification dimensions | `corpus_qualification.prepare_qualification`, `derive_eligibility` |
| Candidate graph | `corpus_graph.build_node`, `build_edge`, `build_graph_snapshot` |
| Plaintext parent definition review | `corpus_definition_review_v2.prepare_parent_definition_review_evidence_v1` and its original-bound validator/subject/assessment functions |
| Scoped parent lookup | `scoped_definition_resolution.build_parent_definition_lookup_registry_v1`, `resolve_parent_definition_lookup_v1` |
| Parent candidate use | `corpus_definition_use_v2.prepare_parent_definition_use_v1`, `validate_parent_definition_use_candidate_v1` |
| Combined parent use review | `corpus_definition_use_review_v2.prepare_parent_definition_use_review_evidence_v1` and its validator/subject/assessment functions |
| Conditional project preparation | `legal_corpus_definition_use_lake_v2`; inspect current qualification before adopting its newly present parent APIs |
| Native checking | `legal_corpus_definition_use_native_v2.build_definition_use_native_v2`; parent adaptation remains staged at the documented cutoff |
| Shared and incremental corpus | `legal_corpus_shared_lake.prepare_shared_definition_corpus`, `build_shared_definition_corpus`; `legal_corpus_incremental.build_incremental_shared_corpus` |

The eight existing qualification dimensions are processing, source integrity,
interpretation, representation, dependencies, native translation, Lean compilation
and proof. Declared evidence is not admission. Keep exact source/review inputs,
assumptions, abstentions, missing values and failed histories attached to outputs.

Numerical autoencoders retain their established owners in
`logic/formalization/autoencoder` and `optimizers/logic_theorem_optimizer`.
The public LegalIR inference facade is `logic/legal_ir/autoencoder.py`.
Reuse the distinct 8D, 384D, 768D and native4096 profiles through their existing
contracts; do not copy their implementations here or dispatch by width alone.

Put reusable source/graph/review/Lean work in this module with its owning tests
and documentation. `artifacts/` and `workspace/` contain evidence, checkpoints,
private snapshots and execution records; they are not importable production
implementations. Migrate candidates only after their original qualification and
source-compatible installation gates. Preserve historical snapshots and active
owner state, and use the existing source/resource admission interfaces.

A successful fixture, authenticated signature, prepared project or native theorem
does not independently establish statutory meaning. The
[current handoff](../../../docs/autoformalization/CURRENT_STATE.md) distinguishes
installed, staged and still-unqualified work so a new agent can reuse it directly.
"""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--stage", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repository.resolve(strict=True)
    stage = args.stage.resolve(strict=True)
    if stage == repo or repo in stage.parents:
        raise SystemExit("stage must be outside the canonical repository")
    originals = stage / "originals"
    candidates = stage / "candidates"
    if originals.exists() or candidates.exists() or (stage / "manifest.json").exists():
        raise SystemExit("refusing to replace an existing preparation")
    mapping = {"docs/autoencoders/" + name: "docs/autoformalization/" + name for name in SELECTED}
    new_docs = {"docs/autoformalization/README.md": HUB, "docs/autoformalization/CURRENT_STATE.md": CURRENT, "ipfs_datasets_py/logic/autoformal/README.md": MODULE}
    conflicts = [p for p in [*mapping.values(), *new_docs] if (repo / p).exists()]
    if conflicts:
        raise SystemExit("destination conflict: " + ", ".join(conflicts))
    changes = []
    link_changes = []
    def write_candidate(path: str, raw: bytes, *, kind: str, source: str | None):
        target = candidates / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        preimage = None
        if (repo / path).exists():
            original = (repo / path).read_bytes()
            old = originals / path
            old.parent.mkdir(parents=True, exist_ok=True)
            old.write_bytes(original)
            preimage = descriptor(repo / path, original)
        changes.append({"path": path, "kind": kind, "source_path": source, "preimage": preimage, "candidate": descriptor(target, raw)})
    for source, destination in mapping.items():
        raw = (repo / source).read_bytes()
        text = raw.decode("utf-8")
        body, links = rewrite(text, source, destination, mapping)
        write_candidate(destination, body.encode(), kind="relocated_body", source=source)
        write_candidate(source, redirect(text, destination, source).encode(), kind="compatibility_redirect", source=source)
        link_changes.extend({"source_path": source, "destination_path": destination, **entry} for entry in links)
    for path, body in new_docs.items():
        write_candidate(path, body.encode(), kind="new_entry_point", source=None)
    for path in POINTERS:
        text = (repo / path).read_text()
        heading, separator, rest = text.partition("\n")
        if not separator or not heading.startswith("# "):
            raise SystemExit("unexpected pointer document heading: " + path)
        paragraph = "\n**Current LegalIR handoff:** [autoformalization guide](../autoformalization/README.md) and [current state](../autoformalization/CURRENT_STATE.md). Source, review, graph and Lean documentation is maintained there; this document retains its existing model guidance and dated research history.\n"
        write_candidate(path, (heading + "\n" + paragraph + rest).encode(), kind="entry_pointer_only", source=path)
    manifest = {
        "schema": "legal-ir-documentation-migration-preparation/v1",
        "observed_at_utc": "2026-10-19T20:11:08Z",
        "status": "prepared_not_installed_or_checked",
        "repository": str(repo),
        "stage": str(stage),
        "canonical_destination": "docs/autoformalization",
        "canonical_source_owner": "ipfs_datasets_py/logic/autoformal",
        "counts": {"relocated_guides": len(mapping), "compatibility_redirects": len(mapping), "new_entry_points": len(new_docs), "pointer_only_amendments": len(POINTERS), "candidate_files": len(changes), "rewritten_link_occurrences": len(link_changes)},
        "mapping": mapping,
        "excluded": EXCLUDED,
        "changes": changes,
        "changed_links": link_changes,
        "installation_requirements": ["Root uses existing source WRITE owner", "Every original preimage must match its digest immediately before install", "Every new destination must still be absent", "Preserve foreign edits; reprepare/review conflicts instead of overwriting", "Archive originals and retain compact migration receipt in docs/autoformalization/evidence", "No artifact, workspace, checkpoint, database or lease move", "Run the separate static link/body/redirect checker before installation"],
    }
    (stage / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    print(json.dumps(manifest["counts"], sort_keys=True))


if __name__ == "__main__":
    main()
