#!/usr/bin/env python3
"""Stage genuine retained historical docs; never write the canonical checkout."""
import hashlib
import json
import os
from pathlib import Path

import prepare_docs as prep

STAGE = Path(__file__).resolve().parent
MANIFEST = STAGE / "manifest.json"
RECORDS = {
    "docs/autoencoders/legal_ir_graph_citation_identity.md": (7279, "b6609e829640d5653883d2c37bdfe6c1560eb92f032042fd1e64e999f92cdc41"),
    "docs/autoencoders/legal_source_review_stack_integration_20261015.md": (11666, "42037d73cb94c1e3a5fd4ccc31c18b2733ce55f547c3d1b91b20cb5f4b590ae9"),
    "docs/autoencoders/legal_definition_v2_integration_20261015.md": (7530, "93760b5a5ca1f3ff0aa6d84f98c6fa446dbad89f4b8f42326b19882c8b5e000c"),
    "docs/autoencoders/legal_definition_v2_review_integration_20261015.md": (7315, "a20a824633b0de42fdcad29a6e299d5c69df6efea6a021f15067c00ef4e41641"),
    "docs/autoencoders/legal_definition_use_v2_integration_20261015.md": (6306, "88946498fcee7a33a09bc26be0fc239e7030467b8850d66b930a3da5ffcf4ebc"),
    "docs/autoformalization/legal-modality-conditions-retention-20261015.md": (8532, "44f7303d44b9240d9842b9e97d73813b4cb2db66610cca9c9c2e95328eba9c29"),
    "docs/autoformalization/legal-conditions-composition-20261015.md": (6147, "014e1487e079beb3d85892c8d6d012ec79048635b2539f5bcd93ae766648aa2b"),
    "docs/autoencoders/evidence/legal-ir-uscode-plan-20261015/reconstruction-and-assets-survey.json": (44262, "be53f4860478d6c5321edf0a7628cef6bc893c2b226fe3e0d559a40dfc0f22c1"),
    "docs/autoencoders/evidence/legal-ir-uscode-plan-20261015/pipeline-and-integration-survey.json": (48373, "a777bcba3c155d063ff860f5416c9fc75c6be3da8cba72c33da94fb084b388c6"),
    "docs/autoencoders/evidence/legal-ir-uscode-plan-20261015/hub-cache-survey.json": (111508, "735c53c37be1a512618e7561ec8a2e8ec53b29c1a68dfe3688ef848ade64976a"),
}


def main():
    original_manifest = MANIFEST.read_bytes()
    manifest = json.loads(original_manifest)
    if "historical_recovery" in manifest:
        raise SystemExit("already staged; do not overwrite a reviewed recovery")
    repo = Path(manifest["repository"])
    workspace = repo.parents[1]
    snapshot_rel = "artifacts/legal-ir-missing-component-import-20261016/datasets"
    snapshot = workspace / snapshot_rel
    second = workspace / "artifacts/legal-conditions-composition-diagnostic-20261015-01/datasets"
    mapping = {}
    for old in RECORDS:
        source = os.path.relpath(snapshot / old, repo)
        mapping[source] = "docs/autoformalization/history/" + Path(old).name if old.endswith(".md") else old
    destinations = [*mapping.values(), *(old for old in RECORDS if old.endswith(".md"))]
    for path in destinations:
        if (repo / path).exists() or (STAGE / "candidates" / path).exists():
            raise SystemExit("destination conflict: " + path)
    (STAGE / "manifest-before-history.json").write_bytes(original_manifest)
    if (STAGE / "static-check.json").exists():
        (STAGE / "static-check-before-history.json").write_bytes((STAGE / "static-check.json").read_bytes())
    sources = []
    def add(path, raw, kind, source):
        target = STAGE / "candidates" / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        manifest["changes"].append({"path": path, "kind": kind, "source_path": source["repository_relative_source"],
            "preimage": None, "candidate": prep.descriptor(target, raw), "recovered_source": source})
    for old, (size, sha) in RECORDS.items():
        source_path = snapshot / old
        raw = source_path.read_bytes()
        if len(raw) != size or hashlib.sha256(raw).hexdigest() != sha:
            raise SystemExit("historical source drift: " + str(source_path))
        saved_rel = "recovered_originals/" + snapshot_rel + "/" + old
        saved = STAGE / saved_rel
        saved.parent.mkdir(parents=True, exist_ok=True)
        saved.write_bytes(raw)
        source_rel = os.path.relpath(source_path, repo)
        mirror = second / old
        source = {"absolute_path": str(source_path), "repository_relative_source": source_rel,
            "bytes": size, "sha256": sha, "saved_original": saved_rel, "second_snapshot": None}
        if mirror.is_file():
            mirror_raw = mirror.read_bytes()
            source["second_snapshot"] = {"absolute_path": str(mirror), **prep.descriptor(mirror, mirror_raw), "byte_identical": mirror_raw == raw}
        sources.append(source)
        destination = mapping[source_rel]
        if old.endswith(".json"):
            add(destination, raw, "recovered_historical_evidence", source)
            continue
        body, changed = prep.rewrite(raw.decode(), source_rel, destination, mapping)
        notice = "> Historical document recovered from the retained October 16 source snapshot.\n> Original bytes and provenance are recorded in the documentation migration receipt.\n> This preserves the original run's claims and failures; it is not current qualification.\n\n"
        add(destination, (notice + body).encode(), "recovered_historical_body", source)
        manifest["changes"][-1]["historical_notice"] = notice
        for item in changed:
            manifest["changed_links"].append({"source_path": source_rel, "destination_path": destination, **item})
        text = raw.decode()
        title = prep.headings(text)
        if not title:
            text = "# " + text.splitlines()[0].strip("*") + "\n\n" + text
        stub = prep.redirect(text, destination, old)
        add(old, stub.encode(), "recovered_historical_redirect", source)
    corrected_path = "docs/autoformalization/legal_source_typed_norm_join_v1.md"
    item = next(row for row in manifest["changes"] if row["path"] == corrected_path)
    target = STAGE / "candidates" / corrected_path
    raw = target.read_bytes()
    before = "../../../../legal-corpus-source-typed-join-20261015-01/README.md"
    after = "../../../../artifacts/legal-corpus-source-typed-join-20261015-01/README.md"
    if raw.count(before.encode()) != 1:
        raise SystemExit("unexpected source-typed join link occurrence")
    retained = workspace / "artifacts/legal-corpus-source-typed-join-20261015-01/README.md"
    retained_raw = retained.read_bytes()
    if len(retained_raw) != 4665 or hashlib.sha256(retained_raw).hexdigest() != "184b116335d8259e95fab47e21d4a1e1fde07658d5b0f7a0c5787086eb27f5ad":
        raise SystemExit("retained source-typed join README changed")
    (STAGE / "source-typed-join-before-link-correction.md").write_bytes(raw)
    target.write_bytes(raw.replace(before.encode(), after.encode()))
    item["candidate"] = prep.descriptor(target)
    item["recorded_link_corrections"] = [{"before": before, "after": after,
        "reason": "The original relative path omitted the artifacts/ directory; exact retained report recovered.",
        "target": {"absolute_path": str(retained), **prep.descriptor(retained, retained_raw)}}]
    manifest["counts"].update({"recovered_historical_guides": 7, "recovered_historical_redirects": 7,
        "recovered_historical_evidence_files": 3, "explicit_original_link_corrections": 1,
        "candidate_files": len(manifest["changes"]), "rewritten_link_occurrences": len(manifest["changed_links"])})
    manifest["historical_recovery"] = {"status": "recovered_hash_checked_not_reexecuted", "sources": sources,
        "mapping": mapping, "historical_source_bytes": sum(row[0] for row in RECORDS.values()),
        "rule": "Body text preserved except relative links and an explicit historical provenance notice. Evidence JSON bytes preserved exactly. Links retain original snapshot source/receipts, with recovered same-byte histories and JSON mapped to their canonical destinations.",
        "source_typed_join_correction": item["recorded_link_corrections"]}
    MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    print(json.dumps(manifest["counts"], sort_keys=True))


if __name__ == "__main__":
    main()
