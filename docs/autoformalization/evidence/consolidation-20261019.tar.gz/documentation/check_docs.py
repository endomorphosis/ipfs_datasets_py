#!/usr/bin/env python3
"""Statically verify a prepared documentation move; never install or run code."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
from urllib.parse import unquote

import prepare_docs as preparation


def desc(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def links(text):
    for line, eligible in preparation.unfenced_lines(text):
        if eligible:
            for pattern in (preparation.INLINE, preparation.REFERENCE):
                for match in pattern.finditer(line):
                    yield match.group("url")


def all_anchors(text):
    result = set(preparation.anchors(text))
    for line, eligible in preparation.unfenced_lines(text):
        if eligible:
            result.update(re.findall(r'<a\s+(?:id|name)=["\']([^"\']+)["\']', line))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", required=True, type=Path)
    args = parser.parse_args()
    stage = args.stage.resolve(strict=True)
    manifest_raw = (stage / "manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    repo = Path(manifest["repository"])
    candidates = stage / "candidates"
    originals = stage / "originals"
    failures = []
    known_broken = []
    link_count = 0
    anchor_count = 0
    candidate_paths = set()
    for change in manifest["changes"]:
        path = change["path"]
        if path in candidate_paths:
            failures.append({"kind": "duplicate_candidate", "path": path})
        candidate_paths.add(path)
        raw = (candidates / path).read_bytes()
        if desc(raw) != change["candidate"]:
            failures.append({"kind": "candidate_hash", "path": path})
        if "recovered_source" in change:
            source = change["recovered_source"]
            wanted = {key: source[key] for key in ("bytes", "sha256")}
            if desc((stage / source["saved_original"]).read_bytes()) != wanted:
                failures.append({"kind": "recovered_original_hash", "path": path})
            if desc(Path(source["absolute_path"]).read_bytes()) != wanted:
                failures.append({"kind": "recovered_live_source_drift", "path": path})
        if change["preimage"] is None:
            if (repo / path).exists():
                failures.append({"kind": "new_destination_conflict", "path": path})
        else:
            old = (originals / path).read_bytes()
            if desc(old) != change["preimage"]:
                failures.append({"kind": "preimage_hash", "path": path})
            if not (repo / path).is_file() or desc((repo / path).read_bytes()) != change["preimage"]:
                failures.append({"kind": "canonical_source_changed", "path": path})

    def content(path, proposed):
        if proposed and path in candidate_paths:
            return (candidates / path).read_text()
        target = repo / path
        if target.is_file() and target.suffix == ".md":
            return target.read_text()
        return None

    def resolved(url, source):
        if url.startswith("#"):
            return source, url
        return preparation.local_target(url, source)

    def issue(url, source, proposed):
        local = resolved(url, source)
        if local is None:
            return None
        target, suffix = local
        if target not in candidate_paths or not proposed:
            if not (repo / target).exists():
                return ("missing_path", os.path.normpath(str(repo / target)))
        fragment = suffix.partition("#")[2]
        if fragment:
            text = content(target, proposed)
            if text is not None and unquote(fragment) not in all_anchors(text):
                return ("missing_anchor", os.path.normpath(str(repo / target)) + "#" + fragment)
        return None

    baseline_issues = set()
    for change in manifest["changes"]:
        if change["preimage"] is not None:
            source = change["path"]
            for url in links((originals / source).read_text()):
                found = issue(url, source, False)
                if found:
                    baseline_issues.add(found)
                    known_broken.append({"path": source, "link": url, "kind": found[0], "target": found[1]})
        if "recovered_source" in change and change["kind"] == "recovered_historical_body":
            source = change["recovered_source"]
            for url in links((stage / source["saved_original"]).read_text()):
                found = issue(url, source["repository_relative_source"], False)
                if found:
                    baseline_issues.add(found)
                    known_broken.append({"path": source["absolute_path"], "link": url, "kind": found[0], "target": found[1]})

    for change in manifest["changes"]:
        path = change["path"]
        text = (candidates / path).read_text()
        kind = change["kind"]
        if kind == "relocated_body":
            source = change["source_path"]
            old = (originals / source).read_text()
            expected, changes = preparation.rewrite(old, source, path, manifest["mapping"])
            for correction in change.get("recorded_link_corrections", []):
                if expected.count(correction["before"]) != 1:
                    failures.append({"kind": "unexpected_recorded_link_correction", "path": path})
                expected = expected.replace(correction["before"], correction["after"])
                target = correction["target"]
                if desc(Path(target["absolute_path"]).read_bytes()) != {key: target[key] for key in ("bytes", "sha256")}:
                    failures.append({"kind": "corrected_link_target_drift", "path": path})
            if expected != text:
                failures.append({"kind": "relocated_body_differs_beyond_links", "path": path})
            if preparation.anchors(old) != preparation.anchors(text):
                failures.append({"kind": "relocated_heading_anchor_drift", "path": path})
        elif kind == "compatibility_redirect":
            old = (originals / path).read_text()
            old_ids = set(preparation.anchors(old))
            anchor_count += len(old_ids)
            if old_ids - all_anchors(text):
                failures.append({"kind": "redirect_missing_anchors", "path": path, "anchors": sorted(old_ids - all_anchors(text))})
            if text != preparation.redirect(old, manifest["mapping"][path], path):
                failures.append({"kind": "redirect_body_changed", "path": path})
        elif kind == "entry_pointer_only":
            old = (originals / path).read_text()
            if not text.endswith(old.partition("\n")[2]):
                failures.append({"kind": "pointer_rewrote_existing_history", "path": path})
            if text.splitlines()[0] != old.splitlines()[0]:
                failures.append({"kind": "pointer_title_changed", "path": path})
        elif kind == "new_entry_point":
            if len(text.splitlines()) > 150:
                failures.append({"kind": "entry_point_over_150_lines", "path": path})
        elif kind == "recovered_historical_body":
            source = change["recovered_source"]
            old = (stage / source["saved_original"]).read_text()
            expected, _ = preparation.rewrite(old, source["repository_relative_source"], path,
                manifest["historical_recovery"]["mapping"])
            if text != change["historical_notice"] + expected:
                failures.append({"kind": "recovered_historical_body_drift", "path": path})
            if preparation.anchors(old) != preparation.anchors(text):
                failures.append({"kind": "recovered_historical_anchor_drift", "path": path})
        elif kind == "recovered_historical_evidence":
            if (candidates / path).read_bytes() != (stage / change["recovered_source"]["saved_original"]).read_bytes():
                failures.append({"kind": "recovered_evidence_bytes_changed", "path": path})
        elif kind == "recovered_historical_redirect":
            source = change["recovered_source"]
            old = (stage / source["saved_original"]).read_text()
            if not preparation.headings(old):
                old = "# " + old.splitlines()[0].strip("*") + "\n\n" + old
            destination = manifest["historical_recovery"]["mapping"][source["repository_relative_source"]]
            if text != preparation.redirect(old, destination, path):
                failures.append({"kind": "recovered_redirect_changed", "path": path})
        for url in links(text):
            link_count += 1
            found = issue(url, path, True)
            if found and found not in baseline_issues:
                # A historical broken target that moved retains its original identity.
                inverse = {new: old for old, new in manifest["mapping"].items()}
                normalized = found
                for new, old in inverse.items():
                    target_new = os.path.normpath(str(repo / new))
                    if found[1].startswith(target_new + "#") or found[1] == target_new:
                        normalized = (found[0], os.path.normpath(str(repo / old)) + found[1][len(target_new):])
                        break
                if normalized not in baseline_issues:
                    failures.append({"kind": "new_broken_link", "path": path, "link": url, "detail": found})

    report = {
        "schema": "legal-ir-documentation-migration-static-check/v1",
        "manifest": desc(manifest_raw),
        "status": "passed" if not failures else "failed",
        "candidate_files": len(candidate_paths),
        "link_occurrences_checked": link_count,
        "compatibility_heading_anchors_checked": anchor_count,
        "preexisting_broken_link_occurrences": known_broken,
        "failures": failures,
        "product_imports": 0,
        "product_tests_executed": 0,
        "model_calls": 0,
        "native_builds": 0,
        "canonical_writes": 0,
        "scope": "Static file, exact-body migration, link-path/fragment and preimage validation only; no test suite or qualification execution.",
    }
    (stage / "static-check.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: report[k] for k in ["status", "candidate_files", "link_occurrences_checked", "compatibility_heading_anchors_checked"]}, sort_keys=True))
    if failures:
        print(json.dumps(failures, indent=2))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
