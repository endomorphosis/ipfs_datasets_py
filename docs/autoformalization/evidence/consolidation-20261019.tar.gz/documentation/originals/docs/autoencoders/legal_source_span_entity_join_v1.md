# Source, span and entity join manifest

The public `ipfs_datasets_py.logic.autoformal.legal_source_span_entity_join_v1`
module connects selected source-package metadata, complete paired-span bundles
and legacy occurrence candidates into one replayable manifest. It preserves
unresolved source correspondence and entity bindings. The entity input in this
first profile is metadata-only; no entity Parquet file or semantic graph is
inferred from its advertised schema or row count.

## Existing owners

The adapter delegates to:

- `legal_source_package_intake_v1`: exact five-file source metadata intake,
  using `legal_primary_graph_manifest` for source manifest validation.
- `legal_paired_manifest_inventory_v1`: explicit pinned paired-v1/v2 selection.
- `legal_paired_payload_intake_v1`: actual complete paired, goal and artifact
  table verification, preserving every physical row and adapter refusal.
- `corpus_legacy_source_join`: independently pinned producer receipts and
  complete stored source sections, retaining every exact occurrence candidate.
- `legal_entity_index_intake`: the existing twelve-field entity schema contract.
  This manifest does not invoke its file iterator or claim its census coverage.

The source metadata adapter retains the exact `manifest.json`,
`release_metadata.json`, `dataset_configs.json`, `dataset_infos.json` and
`README.md` bytes. Companion descriptor discrepancies and advertised-count
differences remain report issues. Validating their transport does not repair
the source release or verify its corpus/graph tables.

## Inputs and public API

`prepare_source_span_entity_join_manifest` takes the exact outer request bytes,
source request and metadata bytes, paired-inventory request and manifest bytes,
entity schema response bytes, an independently expected outer-request SHA-256,
and optional complete legacy-join inputs.

The closed outer request has these fields:

```text
schema = legal-source-span-entity-join-request/v1
source_request_sha256
paired_inventory_request_sha256
paired_bundles = [{manifest_path_in_repo, repository_root}, ...]
legacy_joins = {manifest_path_in_repo: independent_inputs_sha256, ...}
entity = {repository_id, revision, configuration, info_sha256}
```

Paired bundle order must equal the selected metadata manifest order. Each
retained root is an explicit caller input, never a path chosen by an offered
report. Actual table custody is checked by the existing payload owner. The
entity repository is `justicedao/uscode-autoformal-entity-cache`, configuration
`autoformal_uscode`, with an immutable forty-hex revision. The response must
declare the matching dataset/configuration and supported twelve-field schema.
Its commit association is caller-bound acquisition evidence; this operation
performs no remote authentication.

Each optional legacy input contains exactly `expected_population`,
`producer_receipt_bytes`, `expected_producer_receipt_sha256`, `source_sections`
and `expected_source_sections`. `legacy_join_inputs_sha256` commits the complete
ordinary-JSON inputs while replacing receipt bytes by their SHA-256 and size.
The delegated legacy owner validates the actual receipt and section content.
No short revision alias is expanded to the current source head. The stored
Parquet-text coordinate profile is distinct from the current source wrapper,
official HTML and other normalized views.

`source_span_entity_join_manifest_sha256` hashes the complete bounded report.
`validate_source_span_entity_join_manifest` requires an independent report pin
and regenerates all selected metadata, tables and candidate joins from the
original inputs. Rehashing an altered report does not replace this replay.

## Physical identities and dispositions

Physical identity includes repository, immutable revision, table path,
whole-file SHA-256 and row ordinal. Identical derived row bytes in different
files or positions remain distinct physical rows. `row_references` retains
every selected manifest-row reference; `physical_rows` accounts separately for
distinct physical tuples and their reference ordinals. Repeated references to
one physical row must agree on its observed identity and row digest.

Duplicate bytes within one bank are computed once by the legacy candidate
owner, whose input contract requires unique row commitments. The complete
physical population and all references remain in this adapter. Conflicting
independent expectations for duplicate bytes refuse the operation.

Source candidate records preserve source sections, Unicode/UTF8 selectors and
unresolved context. A unique text candidate remains unselected. No candidate
is passed as `source_bindings` to the paired adapter. Current-source release
correspondence stays `unverified_no_independent_crosswalk`; different revision
names alone do not prove incompatible legal editions.

Entity bindings remain `unavailable_semantic_companions_not_supplied` for every
row. Complete entity-file custody and scoped semantic companions require a
future compatible profile. All admission, semantic, proof and training flags
remain false; training and evaluation-gold masks remain strict integer zero.

The current bounds are sixteen selected bundles, 256 selected row references,
a 256 KiB outer request and a 16 MiB complete report, in addition to each
delegated owner's existing byte/node/depth/row limits. Overflow refuses the
operation instead of returning a truncated successful population. Source-owner
freshness is checked around preparation. Owner pins describe selected source
files; full execution provenance belongs to the frozen validation request.

## Qualification

Run new unit tests and the retained-data integration through the existing
`scripts/ops/legal_ir/run_owned_validation.py` owner, with independently frozen
code/input pins, a private attempt, existing scheduler policy and explicit
resource limits. Retained inputs and preparation scripts live at
`artifacts/legal-ir-source-span-entity-join-20261016-01/` in the parent workspace.
Inspect that packet's request, JUnit, replay assertions and durable result
before attributing successful execution to any source generation.

This adapter creates no reviewed statutory interpretation, definition binding,
training target, model improvement, Lean build or proof receipt. Its output is
the source-custody and unresolved-join input to those later stages.
