"""Independent bounded saved-evidence recount; import no product or runner.

Run only after the source/native launcher has completed. This reads retained
artifacts, never active resource ledgers or control databases. A passing result
requires exact original request identity and the native owner's release export.
"""
from collections import Counter
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import stat
import xml.etree.ElementTree as ET

STAGE = Path(__file__).resolve().parent
REPO = Path("/home/barberb/lift_coding/external/ipfs_datasets")
SPEC_SHA = "4c01cd489e0b0e43fbe367b2e2c70f6f9e08ce21c605ebfc84d2aeff828b9560"
HANDOFF_SHA = "4985ecf9b4073bb1da413a82ef49c9343092e8fa74240bd8ea460897e92f6590"
NEW = "tests/unit/logic/autoformal/test_legal_full_norm_consequences_v1.py"
OLD = "tests/unit/logic/autoformal/test_legal_relational_norm_v1.py"
EXPECTED = {NEW + "::" + name for name in (
    "test_exact_retained_source_and_conditional_metadata",
    "test_independent_pins_are_required[request-A]", "test_independent_pins_are_required[request-B]",
    "test_independent_pins_are_required[report-A]", "test_independent_pins_are_required[report-B]",
    "test_resealed_report_still_requires_full_owner_replay[lean_body]",
    "test_resealed_report_still_requires_full_owner_replay[unknown_field]",
    "test_resealed_report_still_requires_full_owner_replay[producer_pin]",
    "test_unknown_request_fields_are_rejected",
    "test_semantic_changes_are_refused_before_composition[modal_placement]",
    "test_semantic_changes_are_refused_before_composition[argument_order]",
    "test_semantic_changes_are_refused_before_composition[authority]",
    "test_closed_candidate_mapping_and_ordinary_inputs",
)} | {OLD + "::test_full_public_replay_retains_existing_ast_ledger_and_no_authority"}


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def read(path, maximum=4 * 1024**2):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, "ordinary absolute path required")
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and
             0 <= before.st_size <= maximum, "bounded single-link regular artifact required")
        raw = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns)
    need(len(raw) == before.st_size and identity(before) == identity(after) == identity(path.lstat()),
         "artifact changed during read")
    return raw


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def ref(path):
    raw = read(path)
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def checked(item, path=None):
    target = Path(item["path"]) if path is None else path
    raw = read(target)
    need(len(raw) == item["bytes"] and sha(raw) == item["sha256"], "artifact descriptor differs: " + str(target))
    return raw


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))


def load(path):
    return parse(read(path))


def relative(value):
    path = Path(value)
    need(not path.is_absolute() and path.parts and all(part not in {".", ".."} for part in path.parts),
         "safe relative artifact path required")
    return path


def save(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return ref(path)


def recount(request_pin, manifest_pin):
    spec_raw, handoff_raw = read(STAGE / "spec-02.json"), read(STAGE / "full-norm-consequences-handoff-r02.json")
    need(sha(spec_raw) == SPEC_SHA and sha(handoff_raw) == HANDOFF_SHA, "frozen reviewed preparation differs")
    spec, handoff = parse(spec_raw), parse(handoff_raw)
    request_raw, manifest_raw = read(STAGE / "request-01.json"), read(STAGE / "manifest-01.json")
    need(sha(request_raw) == request_pin and sha(manifest_raw) == manifest_pin, "independent request/manifest commitment differs")
    request, manifest = parse(request_raw), parse(manifest_raw)
    attempt = REPO / "workspace/test-logs/federal-corpus-audits/owned-validation-runs" / (STAGE.name + "-01")
    need(request["schema"] == "owned-validation-request/v1" and request["cwd"] == str(REPO)
         and request["attempt_directory"] == manifest["attempt_directory"] == str(attempt), "native request identity differs")
    need(manifest["schema"] == "legal-full-norm-consequences-current-source-manifest/v1"
         and manifest["root_reviewed_preparation_spec"] == ref(STAGE / "spec-02.json"), "manifest/spec identity differs")
    need(request["argv"][-3:] == ["--integrate", str(attempt), manifest_pin], "native command/manifest join differs")
    need(manifest["expected_total_cases"] == 14 and manifest["expected_file_case_counts"] == {NEW: 13, OLD: 1}, "case population differs")
    for field, value in {"cpu_slots": 1, "memory_mb": 4096, "child_process_slots": 2,
                         "storage_bytes": 536870912, "timeout_seconds": 900}.items():
        need(request[field] == value, "native envelope differs: " + field)
    for name, digest in spec["control_sha256"].items():
        path = STAGE / "controls-r02" / name
        need(sha(read(path)) == digest == request["source_sha256"][str(path)], "frozen control differs")
    need(set(manifest["candidates"]) == set(spec["candidate_files"]) and
         manifest["candidates"] == spec["candidate_files"], "candidate population differs")
    for row in handoff["files"]:
        item = manifest["candidates"][row["canonical_path"]]
        need(item == {"path": row["candidate_path"], "bytes": row["bytes"], "sha256": row["sha256"]}, "candidate/handoff differs")
        checked(item)
    preparation = load(STAGE / "preparation-01.json")
    need(preparation["completed"] is True and preparation["source_lease_acquired"] is True
         and preparation["source_lease_released"] is True and preparation["request"] == ref(STAGE / "request-01.json")
         and preparation["manifest"] == ref(STAGE / "manifest-01.json"), "preparation custody incomplete")
    launch = load(STAGE / "request-01.launch.json")
    need(launch["completed"] is True and launch["validation_returncode"] == 0
         and launch["source_lease_acquired"] is True and launch["source_lease_released"] is True
         and launch["received_signals"] == [] and launch["request"] == ref(STAGE / "request-01.json"), "source/native launcher did not close successfully")
    need(launch["launcher"] == ref(STAGE / "controls-r02/launch_validation.py"), "launcher source differs")
    lines = [line for line in checked(launch["stdout"]).splitlines() if line.strip()]
    checked(launch["stderr"])
    need(lines, "native terminal export missing")
    terminal = parse(lines[-1]); reservation = terminal["reservation"]
    record, lease = reservation["record"], reservation["resource_lease"]
    need(reservation["status"] == record["status"] == "released" and reservation["cleanup_error"] is None
         and lease["released"] is True and record["artifacts_durable_asserted"] is True,
         "native release/storage durability incomplete")
    need(record["validation_request_sha256"] == request_pin and record["attempt_directory"]["path"] == str(attempt)
         and reservation["reservation_id"] == record["reservation_id"] == launch["native_terminal_release"]["reservation_id"]
         and lease["lease_id"] == record["native_lease_id"] == launch["native_terminal_release"]["native_lease_id"], "native release identity mismatch")
    for field in ("cpu_slots", "memory_mb", "child_process_slots", "storage_bytes"):
        need(record[field] == request[field], "released reservation envelope differs")
    need(record["attempt_exceeded_reservation"] is False and lease["requires_gpu"] is False,
         "resource reservation exceeded or GPU lease requested")
    need(terminal["result"] == str(attempt / "logs/result.json"), "native result locator differs")
    native = load(attempt / "logs/result.json"); execution = load(attempt / "logs/execution.json")
    for value in (native, execution):
        need(value["completed"] is True and value["returncode"] == 0 and value["request_sha256"] == request_pin
             and value["executed_checks"] == request["selected_checks"], "native executed-check result differs")
    durability = load(attempt / "logs/validation-durability.json")
    need(durability["request_sha256"] == request_pin and durability["reservation_id"] == reservation["reservation_id"]
         and durability["result_path"] == "logs/result.json" and durability["result_sha256"] == sha(read(attempt / "logs/result.json")), "durability identity differs")
    need(0 < len(durability["files"]) <= 1024 and sum(row["bytes"] for row in durability["files"]) <= 64 * 1024**2, "retained evidence exceeds recount bound")
    sealed = {}
    for row in durability["files"]:
        rel = str(relative(row["path"]))
        need(rel not in sealed, "duplicate sealed file")
        checked(row, attempt / rel); sealed[rel] = row
    need(0 < len(manifest["files"]) <= 768, "private source population exceeds bound")
    for rel, item in manifest["files"].items():
        private_rel = str(Path("exports/source") / relative(rel))
        need(private_rel in sealed and all(sealed[private_rel][key] == item[key] for key in ("bytes", "sha256")), "private source/fixture custody differs")
    for rel in ("exports/test-collection.json", "exports/tests.xml", "exports/import-origins.json",
                "exports/integration-result.json", "logs/integration-pytest-result.json", "logs/result.json", "logs/execution.json"):
        need(rel in sealed, "required result missing from native seal")
    collection = load(attempt / "exports/test-collection.json")
    need(set(collection["nodes"]) == EXPECTED and collection["collected"] == 14
         and Counter(collection["nodes"].values()) == Counter({NEW: 13, OLD: 1})
         and not collection["deselected_nodes"] and not collection["collection_errors"], "exact test identities differ")
    need(collection["terminal_dispositions"] == dict.fromkeys(EXPECTED, "passed"), "terminal test outcomes differ")
    expected_phases = Counter((node, phase, "passed", "TestReport") for node in EXPECTED for phase in ("setup", "call", "teardown"))
    observed_phases = Counter((row["nodeid"], row["when"], row["outcome"], row["report_type"]) for row in collection["reports"])
    need(observed_phases == expected_phases and sum(observed_phases.values()) == 42, "ordinary test phases differ")
    xml = ET.fromstring(read(attempt / "exports/tests.xml")); cases = xml.findall(".//testcase")
    expected_junit = Counter((node.split("::")[0][:-3].replace("/", "."), node.split("::", 1)[1]) for node in EXPECTED)
    need(len(cases) == 14 and all(not list(case) for case in cases)
         and Counter((case.get("classname"), case.get("name")) for case in cases) == expected_junit, "JUnit identity/outcomes differ")
    origins = load(attempt / "exports/import-origins.json")
    need(origins["pytest_exitstatus"] == 0 and not origins["errors"] and not origins["denied_network_or_child_attempts"]
         and all(name.partition(".")[0] == "symai" for name in origins["denied_optional_import_attempts"]), "import/process provenance differs")
    for row in origins["modules"]:
        need(row["path"] in manifest["files"] and row["sha256"] == manifest["files"][row["path"]]["sha256"], "imported module identity differs")
    for rel, row in origins["source_compile_observations"].items():
        need(rel in manifest["files"] and row["sha256"] == manifest["files"][rel]["sha256"], "compiled source identity differs")
    for rel in ("ipfs_datasets_py/logic/autoformal/legal_full_norm_consequences_v1.py", NEW, OLD):
        need(origins["source_compile_observations"][rel]["raw_compile_count"] > 0,
             "selected source lacks raw compilation observation")
    need(any(row["module"] == "ipfs_datasets_py.logic.autoformal.legal_full_norm_consequences_v1" for row in origins["modules"]), "composition module was not imported")
    namespace_names = {row["module"] for row in origins["namespace_modules"]}
    need("ipfs_datasets_py.logic.intent_ir.formalize" in namespace_names and namespace_names <= set(manifest["namespace_packages"]), "namespace population differs")
    for row in origins["namespace_modules"]:
        declaration = manifest["namespace_packages"][row["module"]]
        need(row["kind"] == "pep420_namespace_package" and row["spec_origin"] is None
             and row["spec_has_location"] is False and row["canonical_and_private_initializers_absent"] is True
             and row["private_search_locations"] == [declaration["path"]]
             and row["anchor"]["path"] == declaration["anchor"]
             and row["anchor"]["sha256"] == manifest["files"][declaration["anchor"]]["sha256"], "namespace source anchor differs")
        for child in row["imported_descendants"].values():
            need(child["path"] in manifest["files"] and child["sha256"] == manifest["files"][child["path"]]["sha256"],
                 "namespace descendant source differs")
    integration = load(attempt / "exports/integration-result.json"); child = load(attempt / "logs/integration-pytest-result.json")
    need(integration["completed"] is True and integration["manifest_sha256"] == manifest_pin
         and integration["test_counts"] == {"total": 14, "passed": 14, "failed": 0, "errors": 0, "skipped": 0}
         and set(integration["exact_nodes"]) == EXPECTED and child["returncode"] == 0
         and integration["all_private_source_unchanged"] is True and integration["canonical_source_unchanged"] is True, "integration result differs")
    return {"schema": "legal-full-norm-consequences-independent-qualification/v1", "status": "passed",
        "evidence_kind": "independent_saved_recount_of_newly_executed_tests", "tests": {"new": 13, "existing": 1, "passed": 14, "failed": 0, "errors": 0, "skipped": 0, "phase_passes": 42},
        "exact_nodes": sorted(EXPECTED), "request": ref(STAGE / "request-01.json"), "manifest": ref(STAGE / "manifest-01.json"),
        "launch": ref(STAGE / "request-01.launch.json"), "candidates": manifest["candidates"],
        "sealed_files_hash_checked": len(sealed), "sealed_bytes_hash_checked": sum(row["bytes"] for row in sealed.values()),
        "private_source_and_fixture_files": len(manifest["files"]), "observed_imports": len(origins["modules"]),
        "native_release": {"reservation_id": reservation["reservation_id"], "native_lease_id": lease["lease_id"], "storage_status": "released", "native_lease_released": True, "source_read_released": True,
            "authority": "saved existing native terminal and source-wrapper exports; no live state inspection"},
        "cost": {"native_elapsed_seconds": execution["elapsed_seconds"], "pytest_wrapper_elapsed_seconds": child["elapsed_seconds"],
            "pytest_collection_elapsed_seconds": collection["elapsed_seconds"], "timing_relation": "nested intervals; do not add",
            "peak_rss_bytes": None, "cpu_seconds": None, "provider_tokens": None, "missing_reason": "No measured peak RSS, CPU time or provider token accounting in this fixture profile."},
        "source_installed": False, "legal_meaning_verified": False, "genuine_human_review": False,
        "native_lean_executed": False, "model_or_training_executed": False, "external_publication": False,
        "recount_script": ref(Path(__file__).resolve()), "recorded_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}


def archive_plan(qualification):
    attempt = Path(load(STAGE / "request-01.json")["attempt_directory"])
    stage_names = ("spec-02.json", "manifest-01.json", "request-01.json", "preparation-01.json",
        "request-01.launch.json", "request-01.launch.stdout.txt", "request-01.launch.stderr.txt",
        "full-norm-consequences-handoff-r02.json", "recount_validation.py", "pytest.ini",
        "controls-r02/prepare.py", "controls-r02/integrate.py", "controls-r02/launch_validation.py",
        "controls-r02/readiness.json", "controls-r02/reuse-diff.patch", "qualification.json")
    attempt_names = ("exports/test-collection.json", "exports/tests.xml", "exports/import-origins.json",
        "exports/integration-result.json", "logs/integration-pytest-result.json", "logs/integration-pytest-intent.json",
        "logs/integration-pytest.stdout.txt", "logs/integration-pytest.stderr.txt", "logs/result.json",
        "logs/execution.json", "logs/validation-durability.json")
    files = [{**ref(STAGE / name), "archive_relative_path": "controls-and-receipts/" + name} for name in stage_names]
    files += [{**ref(attempt / name), "archive_relative_path": "attempt-receipts/" + name} for name in attempt_names]
    return {"schema": "legal-full-norm-consequences-compact-archive-plan/v1", "files": files,
        "total_bytes": sum(row["bytes"] for row in files), "qualification": qualification,
        "excluded": ["Whole private source mirror stays in original sealed attempt; manifest/durability retain its hashes.",
            "Canonical source/test/guide and two tiny fixtures are installed at their product destinations, not copied into another runtime tree.",
            "Active resource databases, owner ledgers, leases and queues are never archived by this plan."],
        "publication_authorized": False, "archive_performed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-request-sha256", required=True)
    parser.add_argument("--expected-manifest-sha256", required=True)
    args = parser.parse_args()
    need(not (STAGE / "qualification.json").exists() and not (STAGE / "archive-plan.json").exists(), "fresh recount outputs required")
    result = recount(args.expected_request_sha256, args.expected_manifest_sha256)
    qualification = save(STAGE / "qualification.json", result)
    archive = save(STAGE / "archive-plan.json", archive_plan(qualification))
    print(json.dumps({"qualification": qualification, "archive_plan": archive, "status": result["status"]}))


if __name__ == "__main__":
    main()
