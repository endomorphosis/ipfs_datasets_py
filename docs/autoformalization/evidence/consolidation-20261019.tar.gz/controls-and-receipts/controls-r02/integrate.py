"""Fixed A/B consequence composition qualification, only inside native admission.

Reuse the retained private-copy harness; enroll 13 new composition cases
and one existing relational public replay control. No installation or recovery.
"""
from collections import Counter
from pathlib import Path
import hashlib
import ast
import importlib.abc
import importlib.machinery
import json
import os
import stat
import subprocess
import sys
import time
import tempfile
import types
import xml.etree.ElementTree as ET

STAGE = Path(__file__).resolve().parent.parent


def need(value, message):
    if not value:
        raise ValueError(message)


def raw(path, maximum=4 * 1024**2):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, "unaliased absolute source required")
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
             and 0 <= before.st_size <= maximum, "bounded single-link regular source required")
        value = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    need(identity(before) == identity(after) == identity(path.lstat())
         and len(value) == before.st_size, "source changed during read")
    return value


def sha(value):
    return hashlib.sha256(value).hexdigest()


def save(path, value):
    value = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(value)
        stream.flush()
        os.fsync(stream.fileno())


def checked_manifest(attempt, pin):
    value = raw(STAGE / "manifest-01.json")
    need(sha(value) == pin, "independent integration manifest differs")
    manifest = json.loads(value)
    need(manifest["schema"] == "legal-full-norm-consequences-current-source-manifest/v1"
         and manifest["attempt_directory"] == str(attempt), "manifest/attempt identity differs")
    new = 'tests/unit/logic/autoformal/test_legal_full_norm_consequences_v1.py'
    official = 'tests/unit/logic/autoformal/test_legal_relational_norm_v1.py'
    expected_official = ['tests/unit/logic/autoformal/test_legal_relational_norm_v1.py::test_full_public_replay_retains_existing_ast_ledger_and_no_authority']
    need(manifest["pytest_selections"] == [new, *expected_official]
         and manifest["expected_total_cases"] == 14
         and manifest["expected_file_case_counts"] == {new: 13, official: 1},
         "exact complete composition suite and one relational control required")
    need(1 <= len(manifest["files"]) <= 768
         and sum(item["bytes"] for item in manifest["files"].values()) <= 32 * 1024**2,
         "finite bounded source closure required")
    need(manifest["namespace_packages"] == NAMESPACE_PACKAGES,
         "exact reviewed namespace declarations required")
    return manifest


NAMESPACE_PACKAGES = {
    "ipfs_datasets_py.logic.backends": {
        "path": "ipfs_datasets_py/logic/backends", "anchor": "ipfs_datasets_py/logic/__init__.py",
        "required_descendants": []},
    "ipfs_datasets_py.logic.backends.installers": {
        "path": "ipfs_datasets_py/logic/backends/installers", "anchor": "ipfs_datasets_py/logic/__init__.py",
        "required_descendants": []},
    "ipfs_datasets_py.logic.backends.kernel": {
        "path": "ipfs_datasets_py/logic/backends/kernel", "anchor": "ipfs_datasets_py/logic/__init__.py",
        "required_descendants": []},
    "ipfs_datasets_py.logic.families": {
        "path": "ipfs_datasets_py/logic/families", "anchor": "ipfs_datasets_py/logic/__init__.py",
        "required_descendants": []},
    "ipfs_datasets_py.logic.intent_ir.formalize": {
        "path": "ipfs_datasets_py/logic/intent_ir/formalize",
        "anchor": "ipfs_datasets_py/logic/intent_ir/__init__.py",
        "required_descendants": ["ipfs_datasets_py/logic/intent_ir/formalize/modal_projections.py"]},
}

def verify_sources(manifest, private=None):
    for rel, item in manifest["files"].items():
        need(not Path(rel).is_absolute() and ".." not in Path(rel).parts, "relative source path required")
        value = raw(private / rel if private is not None else item["path"])
        need(len(value) == item["bytes"] and sha(value) == item["sha256"], "source differs: " + rel)


def verify_canonical(manifest):
    for rel, item in manifest["canonical_files"].items():
        value = raw(item["path"])
        need(len(value) == item["bytes"] and sha(value) == item["sha256"], "canonical source drift: " + rel)
    for rel in manifest["canonical_expected_absent"]:
        need(not os.path.lexists(Path(manifest["canonical_repo"]) / rel), "new target no longer absent")


def module_metadata(module):
    # Read actual stored identity; never trigger a lazy module's __getattr__.
    return vars(module) if isinstance(module, types.ModuleType) else {}


def namespace_provenance(name, module, private, manifest):
    """Authenticate only declared genuine namespaces and their physical sources."""
    need(name in NAMESPACE_PACKAGES, "undeclared fileless product module")
    declaration = NAMESPACE_PACKAGES[name]
    relative, anchor = declaration["path"], declaration["anchor"]
    expected = private / relative
    metadata = module_metadata(module)
    need(type(module) is types.ModuleType and metadata.get("__name__") == name
         and metadata.get("__package__") == name and metadata.get("__file__") is None,
         "namespace module identity differs")
    spec = metadata.get("__spec__")
    need(isinstance(spec, importlib.machinery.ModuleSpec) and spec.name == name
         and spec.origin is None and spec.has_location is False
         and type(spec.loader) is importlib.machinery.NamespaceLoader
         and metadata.get("__loader__") is spec.loader,
         "genuine consistent namespace loader required")
    need(list(metadata.get("__path__", [])) == list(spec.submodule_search_locations) == [str(expected)],
         "namespace must have exactly one private location")
    suffixes = importlib.machinery.all_suffixes()
    for directory in (expected, Path(manifest["canonical_repo"]) / relative):
        need(directory.resolve(strict=True) == directory and stat.S_ISDIR(directory.lstat().st_mode),
             "ordinary namespace directory required")
        for suffix in suffixes:
            need(not os.path.lexists(directory / ("__init__" + suffix)), "namespace initializer unexpectedly exists")
    parent_name, attribute = name.rsplit(".", 1)
    need(module_metadata(sys.modules.get(parent_name)).get(attribute) is module,
         "namespace must belong to the actual imported parent")
    need(anchor in manifest["files"] and sha(raw(private / anchor)) == manifest["files"][anchor]["sha256"],
         "namespace ordinary package anchor differs")
    anchored = any(module_metadata(value).get("__file__") == str(private / anchor)
                   for value in tuple(sys.modules.values()))
    need(anchored, "namespace ordinary parent anchor not imported")
    descendants = {}
    for child_name, child in tuple(sys.modules.items()):
        if not child_name.startswith(name + "."):
            continue
        child_meta = module_metadata(child)
        filename = child_meta.get("__file__")
        if filename is None:
            need(child_name in NAMESPACE_PACKAGES, "undeclared fileless namespace descendant")
            continue
        path = Path(filename).resolve(strict=True)
        need(path.is_relative_to(expected), "namespace descendant has foreign origin")
        rel = str(path.relative_to(private))
        need(rel in manifest["files"] and sha(raw(path)) == manifest["files"][rel]["sha256"],
             "namespace descendant source differs")
        descendants[child_name] = dict(path=rel, sha256=manifest["files"][rel]["sha256"])
    need(all(rel in {row["path"] for row in descendants.values()}
             for rel in declaration["required_descendants"]), "required namespace descendant not imported")
    return dict(module=name, kind="pep420_namespace_package", source_file=None,
        source_file_reason="Initializer-free namespace container; executable descendants separately authenticated.",
        path=relative, private_search_locations=[relative], spec_origin=None, spec_has_location=False,
        loader_type=type(spec.loader).__module__ + "." + type(spec.loader).__name__,
        canonical_and_private_initializers_absent=True, initializer_suffixes_checked=suffixes,
        anchor=dict(path=anchor, sha256=manifest["files"][anchor]["sha256"]), imported_descendants=descendants)


class DenyOptionalImports(importlib.abc.MetaPathFinder):
    denied_roots = frozenset({"torch", "symai", "symbolicai", "transformers", "sentence_transformers",
        "huggingface_hub", "datasets", "tensorflow", "jax", "openai", "anthropic", "litellm"})

    def __init__(self):
        self.attempts = []

    def find_spec(self, fullname, path=None, target=None):
        if fullname.partition(".")[0] in self.denied_roots:
            self.attempts.append(fullname)
            raise ImportError("numerical/model/provider import disabled for this finite fixture")
        return None


def verify_collection(collection, manifest):
    new = manifest["pytest_selections"][0]
    official = set(manifest["pytest_selections"][1:])
    nodes = collection["nodes"]
    need(collection["collected"] == len(nodes) == manifest["expected_total_cases"]
         and not collection["deselected_nodes"] and not collection["collection_errors"],
         "complete bounded collection with no substitutions required")
    need({node for node in nodes if not node.startswith(new + "::")} == official
         and Counter(nodes.values()) == Counter(manifest["expected_file_case_counts"]),
         "exact new-file population and one relational control required")
    need(set(collection["terminal_dispositions"]) == set(nodes)
         and set(collection["terminal_dispositions"].values()) == {"passed"},
         "every selected test must finish with a terminal pass")
    expected = Counter((node, when, "passed", "TestReport")
        for node in nodes for when in ("setup", "call", "teardown"))
    need(Counter((row["nodeid"], row["when"], row["outcome"], row["report_type"])
                 for row in collection["reports"]) == expected,
         "exact ordinary setup/call/teardown report identities required")

def pytest_child(attempt, pin):
    manifest = checked_manifest(attempt, pin)
    private = attempt / "exports/source"
    verify_sources(manifest, private)
    need(not any(name == "ipfs_datasets_py" or name.startswith("ipfs_datasets_py.")
                 for name in sys.modules), "product loaded before private path selection")
    canonical = Path(manifest["canonical_repo"])
    sys.path[:] = [str(private)] + [p for p in sys.path if p
        and not Path(p).resolve().is_relative_to(canonical)]
    os.chdir(private)
    for key in list(os.environ):
        if "SYMAI" in key.upper() or key.upper().startswith("NEUROSYMBOLIC"):
            os.environ.pop(key, None)
    os.environ.update(IPFS_DATASETS_PY_SYMAI_PREFIX=str(attempt / "cache/disabled-symai"),
        NEUROSYMBOLIC_ENGINE_MODEL="llama:offline-disabled", NEUROSYMBOLIC_ENGINE_API_KEY="ipfs-disabled",
        IPFS_DATASETS_PY_DISABLE_CODEX_FOR_SYMAI="1", IPFS_DATASETS_PY_USE_CODEX_FOR_SYMAI="0")
    tempfile.tempdir = str(attempt / "tmp")
    guard = DenyOptionalImports()
    sys.meta_path.insert(0, guard)
    denied_operations, compiled_sources = [], {}
    def audit(event, args):
        if event in {"subprocess.Popen", "os.system", "os.posix_spawn", "os.spawn", "os.fork", "os.forkpty",
                     "socket.connect", "socket.connect_ex", "socket.getaddrinfo", "socket.sendto"}:
            denied_operations.append(event)
            raise RuntimeError("network and extra child execution disabled inside pytest fixture")
        if event == "compile" and len(args) > 1 and isinstance(args[1], str):
            filename = Path(args[1])
            if filename.is_absolute() and filename.is_relative_to(canonical) and not filename.is_relative_to(private):
                raise ValueError("canonical product source compiled inside private fixture")
            if not filename.is_absolute() or not filename.is_relative_to(private):
                return
            rel = str(filename.relative_to(private))
            need(rel in manifest["files"], "unmanifested private compile source: " + rel)
            source = args[0]
            row = compiled_sources.setdefault(rel, dict(sha256=manifest["files"][rel]["sha256"],
                raw_compile_count=0, rewritten_ast_compile_count=0))
            if isinstance(source, (bytes, bytearray, str)):
                body = source.encode("utf-8") if isinstance(source, str) else bytes(source)
                need(sha(body) == manifest["files"][rel]["sha256"], "compiled source buffer differs: " + rel)
                row["raw_compile_count"] += 1
            elif isinstance(source, ast.AST):
                need(sha(raw(filename)) == manifest["files"][rel]["sha256"], "rewritten source pin differs")
                row["rewritten_ast_compile_count"] += 1
            else:
                raise ValueError("unexpected private source compile representation")
    sys.addaudithook(audit)
    import pytest

    class Evidence:
        def __init__(self):
            self.nodes, self.reports, self.deselected, self.collection_errors = {}, [], [], []

        def pytest_collection_finish(self, session):
            for item in session.items:
                need(item.nodeid not in self.nodes, "duplicate collected node")
                self.nodes[item.nodeid] = str(Path(item.path).resolve().relative_to(private))

        def pytest_collectreport(self, report):
            if report.failed:
                self.collection_errors.append(report.nodeid)

        def pytest_deselected(self, items):
            self.deselected.extend(item.nodeid for item in items)

        def pytest_runtest_logreport(self, report):
            self.reports.append(dict(nodeid=report.nodeid, when=report.when,
                outcome=report.outcome, report_type=type(report).__name__))

    evidence = Evidence()
    args = ["--noconftest", "-c", str(private / "pytest.ini"), "--rootdir", str(private),
        "-o", "addopts=", "-p", "no:cacheprovider",
        "-p", "ipfs_datasets_py.optimizers.logic_theorem_optimizer.validation_pytest",
        "--basetemp=" + str(attempt / "pytest/basetemp"),
        "--junitxml=" + str(attempt / "exports/tests.xml"), "-q", *manifest["pytest_selections"]]
    started = time.monotonic()
    code = int(pytest.main(args, plugins=[evidence]))
    observed, errors, namespaces = [], [], []
    for name, module in sorted(list(sys.modules.items())):
        filename = module_metadata(module).get("__file__")
        product = name == "ipfs_datasets_py" or name.startswith("ipfs_datasets_py.")
        test_module = name == "tests" or name.startswith("tests.")
        if filename is None:
            if product:
                try:
                    namespaces.append(namespace_provenance(name, module, private, manifest))
                except Exception as error:
                    errors.append(dict(module=name, error="unverified fileless product module", message=str(error)))
            continue
        path = Path(filename).resolve()
        if not product and not test_module and not path.is_relative_to(private):
            continue
        if not path.is_relative_to(private):
            errors.append(dict(module=name, error="foreign origin", path=str(path)))
            continue
        rel = str(path.relative_to(private))
        if rel not in manifest["files"]:
            errors.append(dict(module=name, error="unmanifested private source", path=rel))
            continue
        digest = sha(raw(path))
        if digest != manifest["files"][rel]["sha256"]:
            errors.append(dict(module=name, error="imported source changed", path=rel))
        observed.append(dict(module=name, path=rel, sha256=digest))
    try:
        verify_sources(manifest, private)
    except Exception as error:
        errors.append(dict(error="private source changed", message=str(error)))
    terminal = {}
    for node in evidence.nodes:
        reports = [r for r in evidence.reports if r["nodeid"] == node]
        if any(r["outcome"] == "failed" for r in reports):
            terminal[node] = "failed" if any(r["when"] == "call" and r["outcome"] == "failed" for r in reports) else "error"
        elif any(r["outcome"] == "skipped" for r in reports):
            terminal[node] = "skipped"
        elif Counter((r["when"], r["outcome"], r["report_type"]) for r in reports) == Counter({
                ("setup", "passed", "TestReport"): 1, ("call", "passed", "TestReport"): 1,
                ("teardown", "passed", "TestReport"): 1}):
            terminal[node] = "passed"
        else:
            terminal[node] = "missing_or_unexpected_report"
    collection = dict(schema="legal-full-norm-consequences-test-collection/v1", nodes=evidence.nodes,
        collected=len(evidence.nodes), terminal_dispositions=terminal, reports=evidence.reports,
        deselected_nodes=evidence.deselected, collection_errors=evidence.collection_errors, elapsed_seconds=time.monotonic()-started)
    save(attempt / "exports/test-collection.json", collection)
    observed_namespace_names = {row["module"] for row in namespaces}
    if "ipfs_datasets_py.logic.intent_ir.formalize" not in observed_namespace_names:
        errors.append(dict(error="required formalize namespace provenance missing"))
    if denied_operations or any(name.partition(".")[0] != "symai" for name in guard.attempts):
        errors.append(dict(error="unexpected denied network/child/model operation"))
    loaded_forbidden = sorted(name for name in sys.modules if name.partition(".")[0] in guard.denied_roots)
    if loaded_forbidden:
        errors.append(dict(error="forbidden module loaded", modules=loaded_forbidden))
    save(attempt / "exports/import-origins.json", dict(modules=observed, namespace_modules=namespaces,
        errors=errors, pytest_exitstatus=code, source_compile_observations=compiled_sources,
        denied_optional_import_attempts=guard.attempts, denied_network_or_child_attempts=denied_operations,
        optional_symai_body_executed=False, dynamic_module_aliases_authenticated_by_manifested_file=True))
    need(code == 0 and not errors and not evidence.deselected, "pytest/import verification failed")
    verify_collection(collection, manifest)
    need(any(row["module"] == "ipfs_datasets_py" for row in observed), "normal package root import missing")
    return code


def main():
    need(not sys.flags.optimize and len(sys.argv) == 4, "explicit operation, attempt and manifest pin required")
    operation, attempt, pin = sys.argv[1], Path(sys.argv[2]), sys.argv[3]
    manifest = checked_manifest(attempt, pin)
    if operation == "--pytest":
        return pytest_child(attempt, pin)
    need(operation == "--integrate", "unknown integration operation")
    verify_canonical(manifest)
    verify_sources(manifest)
    private = attempt / "exports/source"
    private.mkdir(mode=0o700)
    for rel, item in manifest["files"].items():
        destination = private / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            stream.write(raw(item["path"]))
    verify_sources(manifest, private)
    env = dict(os.environ, PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONDONTWRITEBYTECODE="1",
        IPFS_DATASETS_PY_MINIMAL_IMPORTS="1", IPFS_DATASETS_AUTO_INSTALL="0", IPFS_AUTO_INSTALL="false",
        HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", CUDA_VISIBLE_DEVICES="",
        HF_DATASETS_OFFLINE="1", IPFS_DATASETS_AUTO_INSTALL_TEST_DEPS="0",
        IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI="0", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    env.pop("PYTEST_ADDOPTS", None)
    env.pop("PYTEST_PLUGINS", None)
    argv = [sys.executable, "-B", str(Path(__file__).resolve()), "--pytest", str(attempt), pin]
    save(attempt / "logs/integration-pytest-intent.json", dict(argv=argv, cwd=str(private), timeout_seconds=600))
    started = time.monotonic()
    with (attempt / "logs/integration-pytest.stdout.txt").open("xb") as stdout, \
            (attempt / "logs/integration-pytest.stderr.txt").open("xb") as stderr:
        result = subprocess.run(argv, cwd=private, env=env, stdout=stdout, stderr=stderr, timeout=600)
    save(attempt / "logs/integration-pytest-result.json", dict(returncode=result.returncode,
        elapsed_seconds=time.monotonic()-started))
    need(result.returncode == 0, "pytest child failed; inspect retained child output")
    collection = json.loads(raw(attempt / "exports/test-collection.json"))
    origins = json.loads(raw(attempt / "exports/import-origins.json"))
    verify_collection(collection, manifest)
    cases = ET.fromstring(raw(attempt / "exports/tests.xml")).findall(".//testcase")
    wanted = Counter((rel[:-3].replace("/", "."), node.split("::", 1)[1]) for node, rel in collection["nodes"].items())
    need(Counter((case.attrib.get("classname"), case.attrib.get("name")) for case in cases) == wanted
         and len(cases) == manifest["expected_total_cases"] and all(not list(case) for case in cases), "JUnit identities or outcomes differ")
    need(origins["pytest_exitstatus"] == 0 and not origins["errors"], "import provenance failed")
    need("ipfs_datasets_py.logic.intent_ir.formalize" in {row["module"] for row in origins["namespace_modules"]}
         and all(row["module"] in NAMESPACE_PACKAGES for row in origins["namespace_modules"]),
         "declared namespace provenance receipts required")
    verify_sources(manifest, private)
    verify_sources(manifest)
    verify_canonical(manifest)
    total = manifest["expected_total_cases"]
    save(attempt / "exports/integration-result.json", dict(
        schema="legal-full-norm-consequences-current-source-integration/v1", completed=True,
        manifest_sha256=pin, repository=str(private), copied_file_count=len(manifest["files"]),
        canonical_source_unchanged=True, all_private_source_unchanged=True,
        pytest_returncode=0, newly_executed_test_cases=total, passed=total,
        test_counts=dict(total=total, passed=total, failed=0, errors=0, skipped=0),
        exact_nodes=sorted(collection["nodes"]), expected_file_case_counts=manifest["expected_file_case_counts"],
        observed_import_count=len(origins["modules"]), namespace_module_count=len(origins["namespace_modules"]),
        namespace_provenance=origins["namespace_modules"],
        qualification_scope="Entire fixed A/B composition suite and one existing relational public replay control.",
        historical_native_campaign_reexecuted=False,
        source_installed=False, git_mutated=False, live_state_inspected=False, live_recovery_performed=False,
        native_release=None, native_release_reason="Only the enclosing owner can produce the later release receipt.",
        genuine_human_review=False, legal_meaning_verified=False, native_lean_result=False))
    print(json.dumps(dict(completed=True, passed=total, newly_executed_test_cases=total)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
