"""Freeze a reviewed finite private-copy manifest and native request.

This metadata-only preparation holds the existing canonical source READ lease.
It does not launch validation, import product modules, create an attempt, inspect
resource control state, or grant resources. Root reviews the exact spec first.
"""
from pathlib import Path
import argparse
import ast
import datetime
import hashlib
import importlib.machinery
import json
import os
import stat
import sys
import types

ROOT = Path('/home/barberb/lift_coding')
REPO = ROOT / 'external/ipfs_datasets'
STAGE = Path(__file__).resolve().parent.parent
CONTROLS = Path(__file__).resolve().parent
PREVIOUS = ROOT / 'artifacts/legal-ir-parent-use-review-20261019T192000Z'
BASELINE = ROOT / 'artifacts/legal-ir-plaintext-definition-use-20261019-01/source-closure-r05.json'
BASELINE_SHA = '0605fe7ca1ee84901b24af4b85396c1bcfc09be6580befc9b00664fce1c9237c'
PREVIOUS_REQUEST_SHA = '9c8ba0bf08e67727684c85db9c220685cbd4af5afac504d308b042d12c608a83'
LEASE = REPO / 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_source_lease.py'
LEASE_SHA = '42e9f07d0d458177079269d9f495f0b70512180c1adc2f7fe0bfdb05518a12f9'
NEW_TEST = 'tests/unit/logic/autoformal/test_legal_full_norm_consequences_v1.py'
OFFICIAL_TEST = 'tests/unit/logic/autoformal/test_legal_relational_norm_v1.py'
CANDIDATE_PATHS = {'ipfs_datasets_py/logic/autoformal/legal_full_norm_consequences_v1.py': 'ipfs_datasets_py/logic/autoformal/legal_full_norm_consequences_v1.py', 'docs/autoformalization/legal_full_norm_consequences_v1.md': 'docs/autoformalization/legal_full_norm_consequences_v1.md', 'tests/unit/logic/autoformal/test_legal_full_norm_consequences_v1.py': 'tests/unit/logic/autoformal/test_legal_full_norm_consequences_v1.py', 'tests/unit/logic/autoformal/fixtures/legal_full_norm_consequences_v1/LegalFullNorms.lean': 'tests/unit/logic/autoformal/fixtures/legal_full_norm_consequences_v1/LegalFullNorms.lean', 'tests/unit/logic/autoformal/fixtures/legal_full_norm_consequences_v1/provenance.json': 'tests/unit/logic/autoformal/fixtures/legal_full_norm_consequences_v1/provenance.json'}
SELECTIONS = ['tests/unit/logic/autoformal/test_legal_full_norm_consequences_v1.py', 'tests/unit/logic/autoformal/test_legal_relational_norm_v1.py::test_full_public_replay_retains_existing_ast_ledger_and_no_authority']


def need(value, message):
    if not value:
        raise ValueError(message)


def raw(path, maximum=4 * 1024**2):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, 'unaliased absolute source required')
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
             and 0 <= before.st_size <= maximum, 'bounded single-link regular source required')
        value = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    identity = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
    need(identity(before) == identity(after) == identity(path.lstat()) and len(value) == before.st_size,
         'source changed during read')
    return value


def sha(value):
    return hashlib.sha256(value).hexdigest()


def decode(value):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def invalid(_):
        raise ValueError('nonfinite JSON constant')
    return json.loads(value, object_pairs_hook=pairs, parse_constant=invalid)


def ref(path):
    value = raw(path)
    return dict(path=str(path), bytes=len(value), sha256=sha(value))


def save(name, value):
    data = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    with (STAGE / name).open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    return ref(STAGE / name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec', required=True, type=Path)
    parser.add_argument('--expected-spec-sha256', required=True)
    args = parser.parse_args()
    need(not sys.flags.optimize, 'nonoptimized preparation required')
    need(args.spec.parent == STAGE, 'preparation spec must be directly in stage')
    spec_raw = raw(args.spec)
    need(sha(spec_raw) == args.expected_spec_sha256, 'root-reviewed preparation spec differs')
    spec = decode(spec_raw)
    need(spec['schema'] == 'legal-full-norm-consequences-preparation-spec/v1', 'preparation spec schema differs')
    for name in ('prepare.py', 'integrate.py', 'launch_validation.py'):
        need(sha(raw(CONTROLS / name)) == spec['control_sha256'][name], 'reviewed control differs: ' + name)
        ast.parse(raw(CONTROLS / name), filename=str(CONTROLS / name))
    need(set(spec['candidate_files']) == set(CANDIDATE_PATHS)
         and set(spec['expected_target_preimages']) == set(CANDIDATE_PATHS), 'exact reviewed candidate and fixture targets required')
    need(raw(STAGE / 'pytest.ini') == b'[pytest]\naddopts =\n', 'minimal pytest configuration differs')
    attempt = REPO / 'workspace/test-logs/federal-corpus-audits/owned-validation-runs' / (STAGE.name + '-01')
    need(not os.path.lexists(attempt), 'fresh unique attempt must not exist during preparation')
    outputs = ('manifest-01.json', 'request-01.json', 'preparation-01.json')
    need(all(not os.path.lexists(STAGE / name) for name in outputs), 'fresh preparation outputs required')
    baseline_raw = raw(BASELINE)
    need(sha(baseline_raw) == BASELINE_SHA, 'retained finite closure locator differs')
    baseline = decode(baseline_raw)
    need(baseline['source_files'] == len(baseline['source_sha256']) == 372, 'retained 372-file closure differs')
    old_request_raw = raw(PREVIOUS / 'request-02.json')
    need(sha(old_request_raw) == PREVIOUS_REQUEST_SHA, 'reused original native request differs')
    old_request = decode(old_request_raw)
    namespace_ast = ast.parse(raw(CONTROLS / 'integrate.py'))
    declarations = [node.value for node in namespace_ast.body if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == 'NAMESPACE_PACKAGES' for target in node.targets)]
    need(len(declarations) == 1, 'one static namespace declaration required')
    namespaces = ast.literal_eval(declarations[0])
    lease_raw = raw(LEASE)
    need(sha(lease_raw) == LEASE_SHA, 'source lease owner differs')
    namespace = types.ModuleType('_pinned_full_norm_consequences_preparation_source_lease')
    namespace.__file__ = str(LEASE)
    sys.modules[namespace.__name__] = namespace
    exec(compile(lease_raw, str(LEASE), 'exec', dont_inherit=True, optimize=0), namespace.__dict__)
    preparation = dict(schema='legal-full-norm-consequences-current-integration-preparation/v1',
        completed=False, source_lease_acquired=False, source_lease_released=False,
        attempt_directory=str(attempt), attempt_created=False, native_started=False, tests_executed=False,
        product_imports=False, source_mutated=False, git_mutated=False, live_control_state_read=False)
    context, entered = None, False
    try:
        context = namespace.source_lease(REPO, mode='read', timeout_seconds=300)
        lease = context.__enter__()
        entered = True
        preparation.update(source_lease_acquired=True, source_lease=lease.to_dict())
        need(raw(args.spec) == spec_raw and raw(LEASE) == lease_raw, 'preparation custody changed')
        canonical, absent = {}, []
        for path in sorted(baseline['source_sha256']):
            path = Path(path)
            need(path.is_relative_to(REPO), 'retained closure must name canonical ordinary sources')
            canonical[str(path.relative_to(REPO))] = ref(path)
        for rel in (OFFICIAL_TEST, *CANDIDATE_PATHS):
            path = REPO / rel
            if os.path.lexists(path):
                canonical[rel] = ref(path)
            else:
                need(rel in CANDIDATE_PATHS, 'required canonical source is absent')
                absent.append(rel)
        need(set(absent) <= set(CANDIDATE_PATHS), 'only reviewed candidate targets may be absent')
        candidates = {}
        for rel, filename in CANDIDATE_PATHS.items():
            previous_sha = canonical[rel]['sha256'] if rel in canonical else None
            need(previous_sha == spec['expected_target_preimages'][rel], 'candidate canonical preimage differs: ' + rel)
            candidate = ref(STAGE / 'candidates' / filename)
            need(candidate == spec['candidate_files'][rel], 'reviewed candidate changed: ' + rel)
            if filename.endswith('.py'):
                ast.parse(raw(candidate['path']), filename=candidate['path'])
            candidates[rel] = candidate
        files = {**canonical, **candidates, 'pytest.ini': ref(STAGE / 'pytest.ini')}
        need(len(files) <= 768 and sum(item['bytes'] for item in files.values()) <= 32 * 1024**2,
             'finite source envelope exceeded')
        for declaration in namespaces.values():
            path = REPO / declaration['path']
            need(path.resolve(strict=True) == path and stat.S_ISDIR(path.lstat().st_mode), 'physical namespace required')
            for suffix in importlib.machinery.all_suffixes():
                need(not os.path.lexists(path / ('__init__' + suffix)), 'namespace initializer unexpectedly exists')
            need(declaration['anchor'] in files and all(rel in files for rel in declaration['required_descendants']),
                 'namespace anchor and descendants must be in finite closure')
        manifest = dict(schema='legal-full-norm-consequences-current-source-manifest/v1',
            canonical_repo=str(REPO), attempt_directory=str(attempt), files=files,
            canonical_files=canonical, canonical_expected_absent=absent, candidates=candidates,
            namespace_packages=namespaces, pytest_selections=SELECTIONS,
            expected_total_cases=14, expected_file_case_counts={NEW_TEST: 13, OFFICIAL_TEST: 1},
            no_deselections_required=True, individual_pytest_timeout_seconds=600,
            finite_closure_reuse=ref(BASELINE), reused_native_request=ref(PREVIOUS / 'request-02.json'),
            current_vs_reused_closure_differences=[dict(path=rel, previous_sha256=baseline['source_sha256'].get(item['path']),
                current_sha256=item['sha256']) for rel, item in canonical.items()
                if baseline['source_sha256'].get(item['path']) not in (None, item['sha256'])],
            minimal_pytest_configuration=files['pytest.ini'], root_reviewed_preparation_spec=ref(args.spec),
            no_git_clone_or_mutation=True, no_source_installation=True, no_live_state_inspection=True,
            no_live_recovery=True, source_lease='Existing canonical source READ lease around preparation; rechecked again throughout launched validation.',
            qualification_scope='All 13 fixed A/B composition cases plus one existing relational public replay control; no historical native campaign is rerun.')
        manifest_ref = save('manifest-01.json', manifest)
        pins = {}
        for path in old_request['source_sha256']:
            if Path(path).is_relative_to(REPO):
                rel = str(Path(path).relative_to(REPO))
                if not (rel.startswith('ipfs_datasets_py/') or rel == 'scripts/ops/legal_ir/run_owned_validation.py'):
                    continue
                value = ref(path)
                pins[path] = value['sha256']
        for item in candidates.values():
            pins[item['path']] = item['sha256']
        for path in (args.spec, STAGE / 'manifest-01.json', STAGE / 'pytest.ini', BASELINE,
                     CONTROLS / 'prepare.py', CONTROLS / 'integrate.py', CONTROLS / 'launch_validation.py'):
            value = ref(path)
            pins[value['path']] = value['sha256']
        need(0 < len(pins) <= 256, 'native direct source pin bound exceeded')
        request = {key: old_request[key] for key in ('schema', 'cwd', 'roots', 'scheduler_state_path',
            'expected_scheduler_policy_sha256', 'declared_external_writable_paths', 'process_scope')}
        request.update(argv=[str(ROOT / '.venv/bin/python'), '-B', str(CONTROLS / 'integrate.py'),
            '--integrate', str(attempt), manifest_ref['sha256']], attempt_directory=str(attempt),
            outputs={name: str(attempt / name) for name in ('pytest', 'tmp', 'cache', 'db', 'exports', 'logs')},
            source_sha256=dict(sorted(pins.items())),
            selected_checks=['finite_private_full_norm_consequences_candidate_copy', *SELECTIONS,
                             'exact_terminal_junit_joins_and_current_private_import_provenance'],
            cpu_slots=1, memory_mb=4096, child_process_slots=2, storage_bytes=512 * 1024**2, timeout_seconds=900)
        for item in [*canonical.values(), *candidates.values()]:
            need(item == ref(item['path']), 'source changed during manifest preparation')
        need(raw(args.spec) == spec_raw and raw(LEASE) == lease_raw, 'preparation custody changed at exit')
        request_ref = save('request-01.json', request)
        preparation.update(completed=True, manifest=manifest_ref, request=request_ref,
            direct_pin_count=len(pins), canonical_file_count=len(canonical), copied_file_count=len(files),
            expected_case_count=14, expected_case_count_is_not_execution=True,
            required_before_launch='Create exactly the declared unique empty 0700 attempt; root reviews frozen request then launches existing source/native owner.')
    except BaseException as error:
        preparation['error'] = dict(type=type(error).__name__, message=str(error)[:4096])
        raise
    finally:
        if entered:
            try:
                context.__exit__(None, None, None)
                preparation['source_lease_released'] = True
            except BaseException as error:
                preparation['completed'] = False
                preparation['source_lease_error'] = dict(type=type(error).__name__, message=str(error)[:4096])
        preparation['created_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        descriptor = save('preparation-01.json', preparation)
        print(json.dumps(dict(preparation=descriptor, completed=preparation['completed'])))
    return 0 if preparation['completed'] and preparation['source_lease_released'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
