"""Hold canonical source custody around the existing native validation runner.

The runner owns resource admission, child limits, cancellation and closeout.
This wrapper reads no resource ledger or scheduler state and starts no service.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import signal
import stat
import subprocess
import sys
import types


WORKSPACE = Path('/home/barberb/lift_coding')
REPO = WORKSPACE / 'external/ipfs_datasets'
STAGE = Path(__file__).resolve().parent.parent
LEASE = REPO / 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_source_lease.py'
LEASE_SHA = '42e9f07d0d458177079269d9f495f0b70512180c1adc2f7fe0bfdb05518a12f9'
RUNNER = REPO / 'scripts/ops/legal_ir/run_owned_validation.py'
LEDGER = REPO / 'workspace/test-logs/federal-corpus-audits/owned-daemon-resource-control/disk-reservations.json'
PYTHON = WORKSPACE / '.venv/bin/python'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def read(path, maximum=4 * 1024**2):
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, 'unaliased absolute input required')
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
             and 0 <= before.st_size <= maximum, 'bounded single-link regular input required')
        raw = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    identity = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
    need(len(raw) == before.st_size and identity(before) == identity(after) == identity(path.lstat()),
         'input changed during read')
    return raw


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def reference(path):
    raw = read(path)
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def exclusive(path):
    return os.fdopen(os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600), 'wb')


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def invalid_constant(_):
        raise ValueError('nonfinite JSON constant')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid_constant)


def main():
    need(not sys.flags.optimize, 'nonoptimized Python required')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True, type=Path)
    parser.add_argument('--expected-request-sha256', required=True)
    args = parser.parse_args()
    request_path = args.request
    need(request_path.parent == STAGE and re.fullmatch(r'[A-Za-z0-9_-]+', request_path.stem),
         'request must be a directly contained stage file with a safe stem')
    need(re.fullmatch(r'[0-9a-f]{64}', args.expected_request_sha256), 'exact request SHA256 required')
    raw = read(request_path, 1024**2)
    need(sha(raw) == args.expected_request_sha256, 'request SHA256 differs')
    request = strict_json(raw)
    need(request['schema'] == 'owned-validation-request/v1' and request['cwd'] == str(REPO),
         'canonical owned-validation request required')
    pins = request['source_sha256']
    need(type(pins) is dict and pins.get(str(RUNNER)) == sha(read(RUNNER)), 'current runner source pin required')
    lease_raw = read(LEASE)
    need(sha(lease_raw) == LEASE_SHA and pins.get(str(LEASE)) == LEASE_SHA, 'exact canonical lease owner pin required')
    paths = {name: STAGE / (request_path.stem + suffix) for name, suffix in (
        ('stdout', '.launch.stdout.txt'), ('stderr', '.launch.stderr.txt'), ('receipt', '.launch.json'))}
    need(all(not os.path.lexists(path) for path in paths.values()), 'fresh launch outputs required')
    result = dict(schema='legal-full-norm-consequences-native-validation-launch/v1', request=reference(request_path),
        launcher=reference(Path(__file__).resolve()), runner=reference(RUNNER), lease_owner=reference(LEASE),
        completed=False, validation_returncode=None, source_lease_acquired=False,
        source_lease_released=False, native_terminal_release=None, direct_resource_state_read=False,
        source_mutated=False, provider_work_authorized=False, cpu_numerical_fixture_enrolled=False, supervisor_started=False)
    context, entered, child = None, False, None
    received = []

    def forward(number, _frame):
        received.append(number)
        if child is not None and child.poll() is None:
            try:
                child.send_signal(number)
            except ProcessLookupError:
                pass

    previous = {number: signal.signal(number, forward) for number in (signal.SIGTERM, signal.SIGINT)}
    try:
        # Exclusive stdout creation also prevents two wrappers using this attempt.
        with exclusive(paths['stdout']) as stdout, exclusive(paths['stderr']) as stderr:
            try:
                namespace = types.ModuleType('_pinned_relational_validation_source_lease')
                namespace.__file__ = str(LEASE)
                sys.modules[namespace.__name__] = namespace
                exec(compile(lease_raw, str(LEASE), 'exec', dont_inherit=True, optimize=0), namespace.__dict__)
                context = namespace.source_lease(REPO, mode='read', timeout_seconds=300)
                lease = context.__enter__()
                entered = True
                result.update(source_lease_acquired=True, source_lease=lease.to_dict())
                need(read(request_path) == raw and sha(read(LEASE)) == LEASE_SHA
                     and sha(read(RUNNER)) == pins[str(RUNNER)], 'launch inputs changed under source custody')
                need(not received, 'launch cancelled before child startup')
                bytecode_prefix = str(Path(request['outputs']['cache']) / 'source-only-bytecode')
                need(not os.path.lexists(bytecode_prefix), 'fresh bytecode lookup prefix required')
                env = dict(os.environ, PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONDONTWRITEBYTECODE='1',
                    PYTHONPYCACHEPREFIX=bytecode_prefix,
                    IPFS_DATASETS_PY_MINIMAL_IMPORTS='1', IPFS_DATASETS_AUTO_INSTALL='0', IPFS_AUTO_INSTALL='false',
                    HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', CUDA_VISIBLE_DEVICES='',
                    OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
                    NUMEXPR_NUM_THREADS='1', ARROW_NUM_THREADS='1', IPFS_DATASETS_AUTO_INSTALL_TEST_DEPS='0',
                    IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI='0', GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1')
                result['bytecode_policy'] = {'prefix': bytecode_prefix, 'writes_disabled': True,
                    'prefix_absent_at_launch': True, 'product_child_uses_pinned_source_loader': False}
                command = [str(PYTHON), '-B', str(RUNNER), '--request', str(request_path),
                    '--expected-request-sha256', args.expected_request_sha256, '--resource-ledger', str(LEDGER)]
                child = subprocess.Popen(command, cwd=REPO, env=env, stdin=subprocess.DEVNULL,
                    stdout=stdout, stderr=stderr)
                for number in received:
                    if child.poll() is None:
                        try:
                            child.send_signal(number)
                        except ProcessLookupError:
                            pass
                result['validation_pid'] = child.pid
                result['validation_returncode'] = child.wait()
            finally:
                # The existing native runner must finish cleanup before source custody ends.
                if child is not None:
                    while child.poll() is None:
                        child.wait()
                    result['validation_returncode'] = child.returncode
                for stream in (stdout, stderr):
                    stream.flush()
                    os.fsync(stream.fileno())
        need(read(request_path) == raw and sha(read(LEASE)) == LEASE_SHA
             and sha(read(RUNNER)) == pins[str(RUNNER)], 'launch inputs changed during validation')
        need(result['validation_returncode'] == 0, 'native runner did not succeed')
        lines = [line for line in read(paths['stdout']).splitlines() if line.strip()]
        need(lines, 'native terminal stdout missing')
        terminal = strict_json(lines[-1])
        reservation = terminal['reservation']
        record = reservation['record']
        native = reservation['resource_lease']
        need(record['validation_request_sha256'] == args.expected_request_sha256,
             'native terminal names a different validation request')
        need(reservation['status'] == record['status'] == 'released'
             and reservation['cleanup_error'] is None and native['released'] is True,
             'native terminal did not report complete release')
        result['native_terminal_release'] = dict(reservation_id=reservation['reservation_id'],
            native_lease_id=native['lease_id'], status=record['status'], native_lease_released=True,
            cleanup_error=None, evidence='reported_by_native_terminal_stdout',
            scheduler_or_ledger_independently_read=False)
        need(not received, 'launch received cancellation signal')
        result['completed'] = True
    except BaseException as error:
        result['error'] = {'type': type(error).__name__, 'message': str(error)[:4096]}
    finally:
        if entered:
            try:
                context.__exit__(None, None, None)
                result['source_lease_released'] = True
            except BaseException as error:
                result['completed'] = False
                result['source_lease_release_error'] = {'type': type(error).__name__, 'message': str(error)[:4096]}
        for number, handler in previous.items():
            signal.signal(number, handler)
        result['received_signals'] = received
        result['recorded_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        for key in ('stdout', 'stderr'):
            if paths[key].exists():
                result[key] = reference(paths[key])
        with exclusive(paths['receipt']) as stream:
            stream.write((json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + '\n').encode())
            stream.flush()
            os.fsync(stream.fileno())
        directory = os.open(STAGE, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    print(json.dumps({'receipt': reference(paths['receipt']), 'completed': result['completed'],
        'validation_returncode': result['validation_returncode'], 'source_lease_released': result['source_lease_released']}))
    return 0 if result['completed'] and result['source_lease_released'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
