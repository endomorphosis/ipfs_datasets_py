"""Apply an exact finite migration under the existing canonical source owner.

No resource admission, model work, Git changes or historical evidence deletion.
Preparation supplies exact preimages, candidates and prior validation receipts.
"""
from pathlib import Path
import hashlib
import json
import os
import stat
import sys
import types

REPO = Path('/home/barberb/lift_coding/external/ipfs_datasets')
STAGE = Path('/tmp/legal-ir-consolidation-20261019T201000Z')
OWNER = REPO / 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_source_lease.py'
OWNER_SHA = '42e9f07d0d458177079269d9f495f0b70512180c1adc2f7fe0bfdb05518a12f9'


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    path = Path(path)
    need(path.resolve(strict=True) == path, 'aliased input: ' + str(path))
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size < 32 * 1024**2,
             'ordinary bounded single-link input required: ' + str(path))
        raw = stream.read()
        after = os.fstat(stream.fileno())
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    need(identity(before) == identity(after) == identity(path.lstat()) and len(raw) == before.st_size,
         'input changed: ' + str(path))
    return raw


def descriptor(path):
    raw = read(path)
    return {'bytes': len(raw), 'sha256': sha(raw)}


def target(relative):
    rel = Path(relative)
    need(not rel.is_absolute() and '..' not in rel.parts, 'relative canonical destination required')
    path = REPO / rel
    need(path.resolve() == path, 'aliased destination')
    return path


def main():
    need(len(sys.argv) == 2 and not sys.flags.optimize, 'manifest SHA required')
    raw = read(STAGE / 'installation-manifest.json')
    need(sha(raw) == sys.argv[1], 'installation manifest changed')
    manifest = json.loads(raw)
    need(manifest['schema'] == 'legal-ir-consolidation-installation/v1', 'unexpected schema')
    launch_path = Path(manifest['validation_launch']['path'])
    need(descriptor(launch_path) == manifest['validation_launch']['descriptor'], 'validation launch changed')
    launch = json.loads(read(launch_path))
    need(launch['completed'] is True and launch['source_lease_released'] is True
         and launch['validation_returncode'] == 0
         and launch['native_terminal_release']['native_lease_released'] is True,
         'validation resource closeout is incomplete')
    checks = json.loads(read(Path(manifest['qualification']['path'])))
    need(descriptor(Path(manifest['qualification']['path'])) == manifest['qualification']['descriptor']
         and checks['status'] == 'passed', 'qualification is not passed')
    static = json.loads(read(Path(manifest['documentation_check']['path'])))
    need(descriptor(Path(manifest['documentation_check']['path'])) == manifest['documentation_check']['descriptor']
         and static['status'] == 'passed', 'documentation checks are not passed')
    owner_raw = read(OWNER)
    need(sha(owner_raw) == OWNER_SHA, 'source owner changed')
    module = types.ModuleType('_consolidation_existing_source_owner')
    module.__file__ = str(OWNER)
    sys.modules[module.__name__] = module
    exec(compile(owner_raw, str(OWNER), 'exec'), module.__dict__)
    rows = manifest['changes']
    need(len({row['path'] for row in rows}) == len(rows), 'duplicate destinations')
    need(not (STAGE / 'installation-receipt.json').exists(), 'installation already attempted')
    installed = []
    with module.source_lease(REPO, mode='write', timeout_seconds=300) as lease:
        need(read(STAGE / 'installation-manifest.json') == raw, 'manifest changed under source custody')
        for path, pin in manifest['validated_canonical_sources'].items():
            need(sha(read(Path(path))) == pin, 'validated dependency changed: ' + path)
        candidates = {}
        for row in rows:
            path = target(row['path'])
            candidate = read(Path(row['candidate_path']))
            need({'bytes': len(candidate), 'sha256': sha(candidate)} == row['candidate'], 'candidate changed')
            if row['preimage'] is None:
                need(not os.path.lexists(path), 'new destination appeared: ' + str(path))
            else:
                need(descriptor(path) == row['preimage'], 'preimage changed: ' + str(path))
            candidates[row['path']] = candidate
        # Preflight the complete finite set before any canonical mutation. Each
        # replacement is atomic; the durable receipt lists the exact applied set.
        for row in rows:
            path = target(row['path'])
            path.parent.mkdir(parents=True, exist_ok=True)
            need(path.parent.resolve(strict=True) == path.parent, 'aliased destination parent')
            temporary = path.with_name('.' + path.name + '.consolidation-20261019.tmp')
            with os.fdopen(os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644), 'wb') as stream:
                stream.write(candidates[row['path']])
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            need(descriptor(path) == row['candidate'], 'installed bytes differ')
            installed.append({'path': row['path'], **row['candidate']})
        for directory in sorted({target(row['path']).parent for row in rows}):
            fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        source_lease = lease.to_dict()
    receipt = {'schema': 'legal-ir-consolidation-installation-receipt/v1',
        'manifest_sha256': sha(raw), 'status': 'installed', 'files': installed,
        'source_lease': source_lease, 'source_lease_released': True,
        'original_evidence_removed': False, 'git_commit_created': False, 'pushed': False}
    with (STAGE / 'installation-receipt.json').open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({'status': receipt['status'], 'files': len(installed), 'source_lease_released': True}))


if __name__ == '__main__':
    main()
