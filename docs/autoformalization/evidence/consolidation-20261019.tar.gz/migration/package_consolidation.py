"""Retain exact migration evidence and prepare the finite installation manifest."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

STAGE = Path('/tmp/legal-ir-consolidation-20261019T201000Z')
REPO = Path('/home/barberb/lift_coding/external/ipfs_datasets')


def desc(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def ref(path):
    return {'path': str(path), 'descriptor': desc(path.read_bytes())}


def main():
    plan = json.loads((STAGE / 'archive-plan.json').read_text())
    docs = STAGE / 'docs_stage'
    dm = json.loads((docs / 'manifest.json').read_text())
    dc = json.loads((docs / 'static-check.json').read_text())
    assert dc['status'] == 'passed' and dc['manifest'] == desc((docs / 'manifest.json').read_bytes())
    members = {}

    def add(name, path, expected=None):
        assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        if expected is not None:
            assert desc(raw) == expected
        members[name] = raw

    for row in plan['files']:
        add(row['archive_relative_path'], Path(row['path']), {k: row[k] for k in ('bytes', 'sha256')})
    for directory in ('originals', 'recovered_originals', 'before_final_navigation'):
        for path in sorted((docs / directory).rglob('*')):
            if path.is_file():
                add('documentation/' + str(path.relative_to(docs)), path)
    for path in sorted(docs.iterdir()):
        if path.is_file():
            add('documentation/' + path.name, path)
    for name in ('build_catalog.py', 'reconcile_catalog.py', 'static_review.json'):
        add('catalog/' + name, STAGE / 'catalog_stage' / name)
    for name in ('prepare_final_docs.py', 'package_consolidation.py', 'install_consolidation.py',
                 'consolidation-record.json'):
        add('migration/' + name, STAGE / name)
    add('historical/full_norm_native_replay.py',
        Path('/home/barberb/lift_coding/artifacts/legal-ir-full-norm-native-20261017-01/full_norm_native_replay.py'))
    index = {name: desc(raw) for name, raw in sorted(members.items())}
    index_raw = (json.dumps({'schema': 'consolidation-evidence-archive-index/v1',
        'members': index, 'excludes': ['private validation source mirror', 'datasets and checkpoints',
            'active resource and control stores'], 'archive_is_nonruntime_history': True}, indent=2, sort_keys=True) + '\n').encode()
    members['ARCHIVE_INDEX.json'] = index_raw
    archive = STAGE / 'consolidation-20261019.tar.gz'
    with archive.open('xb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as output:
                for name, raw in sorted(members.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size = len(raw)
                    entry.mode = 0o644
                    output.addfile(entry, io.BytesIO(raw))
    # Validate content hashes by reading the archive without extracting files.
    with tarfile.open(archive, 'r:gz') as saved:
        assert saved.getnames() == sorted(members)
        for member in saved:
            assert member.isfile() and saved.extractfile(member).read() == members[member.name]

    rows = {}
    for row in dm['changes']:
        rows[row['path']] = {k: row[k] for k in ('path', 'preimage', 'candidate')}
        rows[row['path']]['candidate_path'] = str(docs / 'candidates' / row['path'])
    handoff = json.loads((STAGE / 'full-norm-consequences-handoff-r02.json').read_text())
    for row in handoff['files']:
        rel = row['canonical_path']
        candidate = {k: row[k] for k in ('bytes', 'sha256')}
        if rel in rows:
            assert rows[rel]['candidate'] == candidate
        else:
            rows[rel] = {'path': rel, 'preimage': None, 'candidate': candidate,
                         'candidate_path': row['candidate_path']}
    archive_rel = 'docs/autoformalization/evidence/' + archive.name
    rows[archive_rel] = {'path': archive_rel, 'preimage': None,
                        'candidate': desc(archive.read_bytes()), 'candidate_path': str(archive)}
    vm = json.loads((STAGE / 'manifest-01.json').read_text())
    manifest = {'schema': 'legal-ir-consolidation-installation/v1',
        'changes': sorted(rows.values(), key=lambda row: row['path']),
        'validation_launch': ref(STAGE / 'request-01.launch.json'),
        'qualification': ref(STAGE / 'qualification.json'),
        'documentation_check': ref(docs / 'static-check.json'),
        'validated_canonical_sources': {row['path']: row['sha256'] for row in vm['canonical_files'].values()},
        'archive': {'path': archive_rel, **desc(archive.read_bytes()), 'members': len(members)},
        'evidence_deletion': False, 'commit_or_publication': False}
    path = STAGE / 'installation-manifest.json'
    with path.open('x') as stream:
        json.dump(manifest, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'installation_manifest_sha256': desc(path.read_bytes())['sha256'],
        'files': len(rows), 'archive_bytes': archive.stat().st_size, 'archive_members_verified': len(members)}))


if __name__ == '__main__':
    main()
