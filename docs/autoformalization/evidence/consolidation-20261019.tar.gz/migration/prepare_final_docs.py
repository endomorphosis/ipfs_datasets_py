"""Reconcile staged navigation with the exact current foreign plan preimage."""
from pathlib import Path
import hashlib
import json
import shutil

STAGE = Path('/tmp/legal-ir-consolidation-20261019T201000Z')
DOCS = STAGE / 'docs_stage'
REPO = Path('/home/barberb/lift_coding/external/ipfs_datasets')


def descriptor(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    manifest_path = DOCS / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    backup = DOCS / 'before_final_navigation'
    backup.mkdir()
    shutil.copyfile(manifest_path, backup / 'manifest.json')
    shutil.copyfile(DOCS / 'static-check.json', backup / 'static-check.json')
    rows = {row['path']: row for row in manifest['changes']}
    plan = 'docs/autoencoders/legal_ir_text_to_lean4_execution_plan_20261018.md'
    fresh = (REPO / plan).read_bytes()
    old = (DOCS / 'originals' / plan).read_bytes()
    # Only the navigation paragraph is ours. Retain the complete newly supplied
    # canonical plan, including its other worker's cancelled-run reconciliation.
    (backup / 'execution-plan-original.md').write_bytes(old)
    old_candidate = (DOCS / 'candidates' / plan).read_bytes()
    (backup / 'execution-plan-candidate.md').write_bytes(old_candidate)
    header, _, rest = fresh.decode().partition('\n')
    notice = '\n**Current LegalIR handoff:** [autoformalization guide](../autoformalization/README.md) and [current state](../autoformalization/CURRENT_STATE.md). Source, review, graph and Lean documentation is maintained there; this document retains its existing model guidance and dated research history.\n'
    (DOCS / 'originals' / plan).write_bytes(fresh)
    new = (header + '\n' + notice + rest).encode()
    (DOCS / 'candidates' / plan).write_bytes(new)
    rows[plan]['preimage'] = descriptor(fresh)
    rows[plan]['candidate'] = descriptor(new)
    manifest['foreign_plan_refresh'] = {'path': plan, 'original_preimage': descriptor(old),
        'fresh_preimage': descriptor(fresh), 'preserved_entire_fresh_body': True,
        'reason': 'Other worker completed its pending source-owner reconciliation before this validation acquired READ.'}

    def amend(relative, transform):
        path = DOCS / 'candidates' / relative
        previous = path.read_bytes()
        old_path = backup / relative
        old_path.parent.mkdir(parents=True, exist_ok=True)
        old_path.write_bytes(previous)
        raw = transform(previous.decode()).encode()
        path.write_bytes(raw)
        rows[relative]['candidate'] = descriptor(raw)

    amend('docs/autoformalization/README.md', lambda text: text.replace(
        '## Follow the pipeline',
        'Use the [migration and reuse map](MIGRATION.md) for retained work, remaining\n'
        'experimental ports and the [machine-readable inventory](evidence/work_inventory.json).\n'
        'The [consolidation record](evidence/consolidation-20261019.json) binds this move\n'
        'to its source, documentation and validation evidence.\n\n## Follow the pipeline').replace(
        '| Compose shared and incremental projects |',
        '| Prepare the retained authored A/B conditional norms | [Fixed full-norm composition](legal_full_norm_consequences_v1.md) |\n'
        '| Compose shared and incremental projects |'))
    amend('ipfs_datasets_py/logic/autoformal/README.md', lambda text: text.replace(
        '| Shared and incremental corpus |',
        '| Fixed authored A/B conditional source | `legal_full_norm_consequences_v1.prepare_full_norm_consequences_v1`; original report replay and exact retained source, without native execution |\n'
        '| Shared and incremental corpus |'))
    amend('docs/autoformalization/CURRENT_STATE.md', lambda text: text.replace(
        '## Next work, in dependency order',
        '## Consolidation handoff\n\n'
        'The [migration map](MIGRATION.md) and [inventory](evidence/work_inventory.json)\n'
        'supersede folder-by-folder discovery for the audited work. There is one maintained\n'
        'body for each of 51 relocated guides, seven recovered historical guides and three\n'
        'recovered survey records; old guide paths preserve compatibility links. The\n'
        '[consolidation record](evidence/consolidation-20261019.json) contains the actual\n'
        'validation outcome for the extracted fixed A/B composer. Its historical native\n'
        'results remain separate; this migration performs no new Lean build.\n\n'
        'Gated conditioning, companion training state and journal profiles remain retained\n'
        'experimental work with canonical-port qualification pending. Their historical\n'
        'engineering results and adverse reconstruction outcomes are preserved. Do not\n'
        'copy their run controllers or claim those profiles were ported by this move.\n\n'
        '## Next work, in dependency order').replace(
        '1. Reconcile canonical product/test/doc files and retained receipts through the\n'
        '   finite migration inventory. Preserve foreign edits and unqualified candidates.',
        '1. Use the completed finite migration inventory and canonical guides. Resume only\n'
        '   explicitly pending ports; preserve foreign edits and historical evidence.'))

    # These new documents are checked together with their same-install targets.
    for relative, source, kind in [
        ('docs/autoformalization/legal_full_norm_consequences_v1.md',
         STAGE / 'candidates/docs/autoformalization/legal_full_norm_consequences_v1.md', 'new_guide'),
        ('docs/autoformalization/MIGRATION.md', STAGE / 'catalog_stage/MIGRATION.md', 'new_guide'),
        ('docs/autoformalization/evidence/work_inventory.json', STAGE / 'catalog_stage/work_inventory.json', 'new_inventory'),
        ('docs/autoformalization/evidence/consolidation-20261019.json', STAGE / 'consolidation-record.json', 'new_record')]:
        assert relative not in rows and not (REPO / relative).exists()
        raw = source.read_bytes()
        destination = DOCS / 'candidates' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
        row = {'path': relative, 'source_path': None, 'kind': kind,
               'preimage': None, 'candidate': descriptor(raw)}
        rows[relative] = row
        manifest['changes'].append(row)
    manifest['counts']['candidate_files'] = len(rows)
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'candidate_files': len(rows), 'foreign_plan_preserved': True}))


if __name__ == '__main__':
    main()
