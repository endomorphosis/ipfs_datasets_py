"""Freeze ordered-clause study with authenticated unchanged predecessor inputs."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
A=P/'workspace/test-logs/decoder-action-binding-20261003'
BASE=json.loads((R/'base.json').read_bytes())['base']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):
 path=R/name;assert not path.exists(),path;path.write_text(json.dumps(obj,indent=2)+'\n')
def mod(path):
 spec=importlib.util.spec_from_file_location('_recurrent_freeze_'+path.stem,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
if __name__=='__main__':
 assert not (R/'experiment-source').exists()
 auto='ipfs_datasets_py/logic/formalization/autoencoder/'
 changes=[auto+n+'.py' for n in ('ordered_clause_recurrent_decoder_experiment','action_contrastive_decoder_training','long_span_source_value_training')]
 changes+=['scripts/ops/autoencoder/'+n+'.py' for n in ('benchmark_ordered_clause_recurrent_training','benchmark_clause_context_source_training')]
 changes+=['tests/unit/logic/formalization/autoencoder/test_'+n+'.py' for n in ('ordered_clause_recurrent_decoder_experiment','ordered_clause_recurrent_training_runner')]
 additions={rel:sha(P/rel) for rel in changes}
 pins=json.loads((A/'frozen-extensions.json').read_bytes());tests=json.loads((A/'validated-test-source.json').read_bytes());helpers=json.loads((A/'test-helper-sources.json').read_bytes())
 for rel,digest in {**pins,**tests,**helpers}.items():
  assert sha(A/'experiment-source'/rel)==digest,rel
  assert hashlib.sha256(subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)).hexdigest()==digest,rel
 for rel,digest in additions.items():(tests if rel.startswith('tests/') else pins)[rel]=digest
 for rel,digest in {**pins,**tests,**helpers}.items():
  source=P/rel if rel in additions else A/'experiment-source'/rel
  target=R/'experiment-source'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);assert sha(target)==digest
 save('frozen-extensions.json',pins);save('validated-test-source.json',tests);save('test-helper-sources.json',helpers)
 save('test-files.json',list(tests));save('code-files.json',changes+['docs/autoencoders/decoder_length_distillation.md'])
 clause=json.loads((A/'clause-parent-manifest.json').read_bytes());clause['extensions']=pins
 cplan=json.loads((A/'clause-parent-plan.json').read_bytes());save('clause-parent-plan.json',cplan)
 clause['plan_sha256']=sha(R/'clause-parent-plan.json');save('clause-parent-manifest.json',clause)
 native=json.loads((A/'native-parent-manifest.json').read_bytes());native['extensions']=pins
 for key,name in [('parent_manifest','clause-parent-manifest.json'),('parent_plan','clause-parent-plan.json')]:
  path=R/name;native[key]=str(path);native['inputs'][str(path)]=sha(path)
 nplan=json.loads((A/'native-parent-plan.json').read_bytes());nplan['input_sha256']=native['inputs'];save('native-parent-plan.json',nplan)
 native['plan_sha256']=sha(R/'native-parent-plan.json');save('native-parent-manifest.json',native)
 manifest=dict(native);manifest['inputs']=dict(native['inputs'])
 for key,path in [('parent_manifest',R/'native-parent-manifest.json'),('parent_plan',R/'native-parent-plan.json'),('original_action_manifest',A/'training-manifest.json'),('saved_boundary_diagnostic',R/'saved-boundary-diagnostic.json'),('saved_boundary_diagnosis',R/'saved-boundary-diagnosis.json')]:
  manifest[key]=str(path);manifest['inputs'][str(path)]=sha(path)
 manifest['baseline_summaries']={}
 for d in (8,384,768):
  for seed in (1729,2718):
   name=f'{d}-action-contrastive-{seed}';path=A/'training-r1/results'/name/'summary.json';manifest['baseline_summaries'][name]=str(path);manifest['inputs'][str(path)]=sha(path)
 for path,digest in manifest['inputs'].items():assert sha(path)==digest,path
 runner=mod(R/'experiment-source/scripts/ops/autoencoder/benchmark_ordered_clause_recurrent_training.py')
 save('training-plan.json',dict(runner.FIXED,input_sha256=manifest['inputs']))
 manifest['plan_sha256']=sha(R/'training-plan.json');save('training-manifest.json',manifest)
 for name in ('run_frozen_tests.py','adopt_shared_scheduler.py'):(R/name).write_bytes((A/name).read_bytes())
 guard=(A/'run_training_reserved.py').read_text().replace('benchmark_action_binding_source_training.py','benchmark_ordered_clause_recurrent_training.py').replace('storage_bytes=2_500_000_000','storage_bytes=2_000_000_000')
 (R/'run_training_reserved.py').write_text(guard)
 print(json.dumps(dict(extensions=len(pins),test_files=len(tests),inputs=len(manifest['inputs']))))
