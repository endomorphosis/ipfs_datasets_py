"""Read-only compact arithmetic over saved recurrent-comparison results; no model imports."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math

R=Path(__file__).resolve().parent
T=R/'training-r1/results'
ARTIFACTS={}
CHECKS=0
FALSE=dict(qualified=False,admitted=False,proof_authority=False,lake_executed=False,
    checkpoint_promoted=False,fresh_holdout=False,convergence_proven=False)

def require(value,message):
    global CHECKS
    CHECKS+=1
    if not value:raise ValueError(message)

def read(path,digest=None):
    path=Path(path).resolve();data=path.read_bytes();actual=hashlib.sha256(data).hexdigest()
    if digest is not None:require(actual==digest,'input hash differs: '+str(path))
    prior=ARTIFACTS.get(str(path));entry=dict(sha256=actual,bytes=len(data))
    require(prior is None or prior==entry,'artifact changed during analysis')
    ARTIFACTS[str(path)]=entry
    return json.loads(data)

def by_length(rows):
    out={str(n):dict(rows=0,exact=0,eos=0,duplicates=0,missing=0,extra=0,
        length_correct=0,short=0,long=0,unparsed=0,generated_action=0,generated_actor_action=0)
        for n in (1,2,4,8)}
    for row in rows:
        expected=row['expected_ir']['rules'];n=len(expected);result=out[str(n)];c=row['counts']
        require(row['clause_count']==n,'expected row length differs')
        for outkey,inkey in [('exact','ordered_exact'),('eos','eos_count'),('duplicates','duplicate_rules'),
            ('missing','whole_rules_missing'),('extra','whole_rules_extra')]:result[outkey]+=c[inkey]
        result['rows']+=1;generated=row['generated_ir'];parsed=c['parsed_documents']==1
        if not parsed:result['unparsed']+=1
        else:
            rules=generated['rules'];result['length_correct' if len(rules)==n else 'short' if len(rules)<n else 'long']+=1
            # Positional pair equality is computed from the saved parsed JSON;
            # it is not an additional syntax, semantics, or proof check.
            for reference,prediction in zip(expected,rules):
                if not isinstance(prediction,dict):continue
                result['generated_actor_action']+=int(all(reference[k]==prediction.get(k) for k in ('actor','action')))
        result['generated_action']+=row['by_facet']['action']['correct']
    return out

def panel_summary(value):
    fidelity=value['source_fidelity'];m=fidelity['metrics'];numerical=value['report'];v=value['source_values'];count=value['source_count']
    require(numerical['complete'] and numerical['sample_count']==48 and len(fidelity['rows'])==48,'complete48-row panel required')
    require(numerical['generation_temperature']==0 and not numerical['generation_target_access'],'generation policy differs')
    require(not any(numerical.get(k,False) for k in FALSE),'unexpected numerical authority')
    lengths=by_length(fidelity['rows'])
    for outkey,metric in [('exact','ordered_exact'),('eos','eos_count'),('duplicates','duplicate_rules'),('missing','whole_rules_missing'),('extra','whole_rules_extra')]:
        require(sum(x[outkey] for x in lengths.values())==m[metric],'fidelity aggregation differs: '+metric)
    require(sum(x['generated_action'] for x in lengths.values())==fidelity['by_facet']['action']['correct'],'action aggregation differs')
    rawpairs=rawaction=0
    for row in v['predictions']:
        for expected,predicted in zip(row['expected_token_ids'],row['predicted_token_ids']):
            if expected[0]<0:continue
            rawpairs+=int(predicted[:2]==expected[:2]);rawaction+=int(predicted[1]==expected[1])
    require(rawaction==v['by_field']['action']['correct'],'raw action summary differs')
    seconds=numerical['elapsed_seconds'];wall=value['timing']['postfit_evaluation_elapsed_seconds']
    require(math.isclose(seconds/48,numerical['wall_seconds_per_span'],rel_tol=1e-10),'reported per-span time differs')
    return dict(exact=m['ordered_exact'],rows=48,eos=m['eos_count'],syntax_valid=m['syntax_valid'],
        duplicates=m['duplicate_rules'],missing=m['whole_rules_missing'],extra=m['whole_rules_extra'],
        expected_rules=m['expected_rules'],generated_rules=m['generated_rules'],
        raw_action=rawaction,generated_action=fidelity['by_facet']['action']['correct'],
        raw_actor_action=rawpairs,generated_actor_action=sum(x['generated_actor_action'] for x in lengths.values()),
        raw_scalar_correct=v['correct'],raw_scalar_presentations=v['present_values'],
        raw_scalar_ce=v['cross_entropy'],count_correct=count['correct'],count_ce=count['cross_entropy'],
        count_by_length=count['by_length'],token_ce=numerical['metrics']['token_cross_entropy'],
        reconstruction_mse=numerical['metrics']['reconstructed_input_mse'],identity_mse_is_not_learned_reconstruction=True,
        by_length=lengths,numerical_seconds_per48=seconds,numerical_seconds_per_span=seconds/48,
        whole_panel_seconds_per48=wall,whole_panel_seconds_per_span=wall/48,
        potential_residual_observation_seconds=value.get('recurrent_residual_diagnostic',{}).get('elapsed_seconds'),
        numerical_timing_scope=numerical['timing_scope'],whole_panel_timing_scope=value['timing']['scope'],
        execution_kind=value['execution']['kind'])

def main():
    summary=read(T/'summary.json');require(summary['complete'] is True,'comparison incomplete')
    for key,expected in [('workers',1),('bridge_names',[]),('legal_ir_evaluate_provers',False),('metric_disk_cache_used',False),('encoder_executed',False),('downloads_performed',False)]:
        require(summary[key]==expected,'measurement configuration differs: '+key)
    child_exit=read(R/'training-r1/child-exit.json')
    require(child_exit['leader_reaped'] is True and child_exit['returncode']==0,'successful reaped numerical child required')
    require(len(summary['runs'])==12,'12 runs required')
    runs={}
    for entry in summary['runs']:
        arm=read(entry['summary_path'],entry['summary_sha256']);name=arm['arm'];report=read(arm['training_ref']['path'],arm['training_ref']['sha256'])
        require(name==entry['arm'] and arm['budget_completed'],'arm binding differs')
        require(report['optimizer_steps']==340 and report['row_presentations']==2440 and report['valid_target_token_presentations']==225840,'matched training exposure differs')
        require(report['source_value_presentations']==25600 and report['action_contrastive_weight']==.05,'auxiliary exposure differs')
        panels={};predictions={};roleheads={}
        for role,controls in arm['postfit'].items():
            require(role in ('selected','last-attempt'),'unregistered export role')
            panels[role]={};predictions[role]={};roleheads[role]={}
            require(len(controls)==8+int(arm['recipe']['recurrent']),'control coverage differs')
            for label,ref in controls.items():
                raw=read(ref['path'],ref['sha256']);panels[role][label]=panel_summary(raw)
                predictions[role][label]={r['id']:r['token_ids'] for r in raw['predictions']}
                roleheads[role][label]=raw['source_values']['predictions']
                if label=='recurrent-residual-off':
                    require(raw['execution']['recurrent_residual_disabled'] and not raw['execution']['training_performed']
                        and not raw['execution']['selection_performed'],'off control authority differs')
                    capture=raw['recurrent_residual_diagnostic']
                    require(capture['residual_disabled'] and all(x==0 for r in capture['rows'] for slot in r['potential_residuals'] for x in slot),'off residual capture differs')
        off={}
        for role in panels:
            if arm['recipe']['recurrent']:
                actual=predictions[role]['validation'];disabled=predictions[role]['recurrent-residual-off']
                require(set(actual)==set(disabled),'offcontrol sample identities differ')
                require(roleheads[role]['validation']==roleheads[role]['recurrent-residual-off'],'off control changes scalar readout')
                off[role]=dict(changed_predictions=sum(actual[k]!=disabled[k] for k in actual),
                    scalar_readout_unchanged=True,control_is_inference_only=True,
                    conditioned=panels[role]['validation'],disabled=panels[role]['recurrent-residual-off'])
        validations=[item for item in report['history'] if 'rejection_reasons' in item]
        runs[name]=dict(dimension=arm['dimension'],seed=arm['seed'],recipe=arm['recipe'],
            selected_epoch=report['selected_epoch'],accepted_validations=sum(bool(x['accepted']) for x in validations),
            validation_attempts=len(validations),last_rejection_reasons=validations[-1]['rejection_reasons'],
            all_rejection_reasons=dict(Counter(reason for item in validations for reason in item['rejection_reasons'])),
            fit_seconds=arm['training_call_elapsed_seconds'],arm_seconds=arm['elapsed_seconds'],
            training_rows_presented=report['row_presentations'],training_rows_presented_per_fit_second=2440/arm['training_call_elapsed_seconds'],
            row_rate_scope='repeated decoder-row presentations divided by whole training-call wall time including validation; not unique-source throughput',
            trainable_parameters=arm['trainable_parameter_count'],baseline_replay=arm['baseline_replay'],
            controls=panels,residual_off_effect=off,**FALSE)
    comparisons=[]
    for d in (8,384,768):
        for seed in (1729,2718):
            base=runs[f'{d}-action-contrastive-{seed}'];new=runs[f'{d}-recurrent-clause-{seed}'];a=base['controls']['last-attempt']['validation'];b=new['controls']['last-attempt']['validation']
            comparisons.append(dict(dimension=d,seed=seed,baseline=a,candidate=b,
                metric_delta_candidate_minus_baseline={k:b[k]-a[k] for k in ('exact','eos','duplicates','missing','extra','raw_action','generated_action','raw_actor_action','generated_actor_action','count_correct','token_ce')},
                baseline_fit_seconds=base['fit_seconds'],candidate_fit_seconds=new['fit_seconds'],fit_time_ratio=new['fit_seconds']/base['fit_seconds'],
                baseline_selected_epoch=base['selected_epoch'],candidate_selected_epoch=new['selected_epoch']))
    data=dict(schema='ordered-clause-recurrent-numerical-outcomes/v1',complete=True,passed=True,findings=[],
        created_at=datetime.now(timezone.utc).isoformat(),scope='read-only saved panel/receipt arithmetic, no independent model forward',
        comparisons=comparisons,runs=runs,comparison_elapsed_seconds=summary['elapsed_seconds'],
        total_fit_seconds=sum(r['fit_seconds'] for r in runs.values()),child_exit=child_exit,resource_accounting_scope='final admission/release accounting is separate from this numerical analysis',
        measurement=dict(bridge_names=[],legal_ir_evaluate_provers=False,legal_ir_metric_disk_cache=False,
            semantic_embeddings='reused authenticated cached source embeddings; no encoder call',worker_count=1,device='CPU',
            evaluation_sample_count=48,legal_ir_bridge_on_evaluate=False,
            host_isolation='shared host: external workspace tests and small stdlib saved-panel preflights overlapped; no isolated speedup claim',
            token_ce_scope='teacher-forced reference cross entropy; greedy predictions have no target access',
            target_family='authored short Legal rules with explicit source clause segmentation; no broader law coverage'),
        historical8Dteacher_unchanged=True,context_tokens=512,output_tokens=512,temperature=0,checks=CHECKS,artifacts=ARTIFACTS,**FALSE)
    for path,record in ARTIFACTS.items():require(hashlib.sha256(Path(path).read_bytes()).hexdigest()==record['sha256'],'input changed before final write')
    data['checks']=CHECKS
    (R/'outcomes.json').write_text(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+'\n')
    lines=['The matched twelve-fit experiment changes only the recurrent route from the current source clause; it keeps the same losses, source rows and selection gates. The values below describe final private attempts on repeatedly exposed validation rows, not a fresh held-out assessment.','',
        '| Dimension | Seed | Exact baseline → recurrent /48 | Raw action /180 | Generated action /180 | Duplicate rules | Token CE | Fit seconds |',
        '|---|---|---|---|---|---|---|---|']
    for c in comparisons:
        a=c['baseline'];b=c['candidate']
        lines.append(f"| {c['dimension']} | {c['seed']} | {a['exact']} → {b['exact']} | {a['raw_action']} → {b['raw_action']} | {a['generated_action']} → {b['generated_action']} | {a['duplicates']} → {b['duplicates']} | {a['token_ce']:.4f} → {b['token_ce']:.4f} | {c['baseline_fit_seconds']:.2f} → {c['candidate_fit_seconds']:.2f} |")
    lines+=['',
        'Every selected checkpoint remains at epoch 0: none of the twelve fits passed the unchanged per-length nonregression gates. The strongest final private result is 768D seed 2718: 30/48 exact versus 29/48 for its baseline, with EOS 48/48 versus 47/48 and duplicate rules 20 versus 32. Its exact counts at lengths 1/2/4/8 are 12/5/5/8 versus 12/4/3/10, so the gain is not uniform over lengths. It still has 33 extra and 10 missing whole rules; extra-rule counts include incorrect substitutions as well as surplus output.',
        '',
        'The new recurrent route has a measurable fixed-state effect: disabling it reduces the best candidate from 30 to 25 exact and changes seven predictions, while its raw scalar head stays unchanged. This is a postfit ablation, not evidence that the added training path generally wins: the other 768D seed falls from 10 to 9 exact, and the 384D seed 2718 emits fewer correct actions (79 to 58) despite a stronger raw action head (167 to 176). In 8D, EOS rises to 48/48 for both seeds, but exactness stays at 1/48 and extra-rule counts rise substantially.',
        '',
        'For the best candidate, the whole-source and clause-only shuffle controls both yield 0/48 exact, versus 30/48 conditioned; residual-off yields 25/48. The conditioned numerical call takes 0.655769 s for 48 spans (0.013662 s/span), and the broader postfit panel takes 1.550228 s (0.032296 s/span). Those timings exclude the separately recorded potential-residual observation. The raw source action head is 180/180, but actual generated actions are 172/180 and generated actor/action pairs 170/180, showing remaining output errors.',
        '',
        'Exact-by-length, EOS, extra/missing rules, all eight source controls and the additional recurrent-residual-off control are retained in outcomes.json. Raw scalar scores and actual generated action matches are separate; correct source-head values do not establish correct generated formulas.','',
        f"All twelve fits completed 340 updates with 2440 row presentations each. The runner took {summary['elapsed_seconds']:.3f}s; summed training calls took {data['total_fit_seconds']:.3f}s. These are CPU, one-worker measurements with cached embeddings, bridge names[], prover evaluation off and metric disk cache off. These are observed shared-host wall times: external workspace tests and small saved-panel arithmetic preflights overlapped, so they do not establish isolated throughput or a speedup. They are not bridge-on legal-IR timings. Each numerical/panel 48-row wall time and per-span division is retained separately; potential-residual observations are extra work outside those scopes.",
        '', 'The identity projection MSE is not learned reconstruction. The historical 8D linguistic teacher remains unchanged. Source-clause segmentation and availability are explicit inference inputs; the recurrent model may learn to stop when context is exhausted, but does not receive reference counts or force EOS. Nothing here grants Lake admission, semantic qualification, production promotion or proof of convergence.']
    (R/'proposed-outcomes-doc.txt').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(complete=True,runs=len(runs),panels=sum(len(p) for r in runs.values() for p in r['controls'].values()),checks=CHECKS,
        selected_epochs={k:r['selected_epoch'] for k,r in runs.items()},comparisons=[dict(dimension=c['dimension'],seed=c['seed'],exact_delta=c['metric_delta_candidate_minus_baseline']['exact']) for c in comparisons])))

if __name__=='__main__':main()
