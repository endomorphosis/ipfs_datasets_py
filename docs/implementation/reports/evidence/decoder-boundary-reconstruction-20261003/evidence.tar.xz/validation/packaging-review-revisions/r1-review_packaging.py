"""Read-only packaging contract review; never creates archives or Git commits."""
from pathlib import Path
import ast,datetime,hashlib,json,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[3];R=Path(__file__).resolve().parent
O=P/'docs/implementation/reports/evidence/decoder-action-binding-20261003'
artifacts={};checks=0;findings=[]
def info(path):
 path=Path(path).resolve();h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block)
 return {'sha256':h.hexdigest(),'bytes':path.stat().st_size}
def pin(path):
 path=Path(path).resolve();artifacts[str(path)]=info(path);return path
def read(path):return json.loads(pin(path).read_bytes())
def check(value,label):
 global checks
 checks+=1
 if not value:findings.append(label)

sources={}
for name in ('build_evidence.py','publish.py','prepare_publication_review.py'):
 path=pin(R/name);sources[name]=path.read_text();ast.parse(sources[name]);check(True,name+' parses')
build=sources['build_evidence.py'];pub=sources['publish.py'];compat=sources['prepare_publication_review.py']
audit=read(R/'independent-audit.json');ready=read(R/'readiness.json')
check(audit['passed'] and not audit['findings'] and audit['checks']==172172,'final independent results audit')
check(ready['passed'] and not ready['findings'],'readiness audit')
summary=read(R/'training-r1/results/summary.json');manifest=read(R/'training-manifest.json');plan=read(R/'training-plan.json')
check(summary['complete'] and len(summary['runs'])==12 and summary['all_six_original_action_contrastive_baselines_replayed'],'twelve completed fits with exact baseline replays')
check(manifest['plan_sha256']==info(R/'training-plan.json')['sha256'] and plan['input_sha256']==manifest['inputs'],'manifest recipe binding')
expected_controls={'validation','training','zero-condition','source-shuffle','cross-length-shuffle','context-only-shuffle','context-reverse','context-rotate'}
state_count=panel_count=0
for index in summary['runs']:
 run=read(index['summary_path']);check(info(index['summary_path'])['sha256']==index['summary_sha256'],index['arm']+' summary index')
 report=read(run['training_ref']['path']);check(info(run['training_ref']['path'])['sha256']==run['training_ref']['sha256'],index['arm']+' training index')
 check(report['optimizer_steps']==340 and report['selected_epoch']==0,index['arm']+' complete unpromoted budget')
 root=Path(index['summary_path']).parent
 for role in ('initial','selected','last-attempt'):
  check((root/(role+'-state.json')).is_file(),index['arm']+' '+role+' state retained');state_count+=1
 expected=expected_controls|({'recurrent-residual-off'} if run['recipe']['recurrent'] else set())
 for role,panels in run['postfit'].items():
  check(set(panels)==expected,index['arm']+' '+role+' control inventory')
  for label,panel in panels.items():
   check(Path(panel['path']).is_file() and panel['fidelity']['metrics']['rows']==48,index['arm']+' '+role+'/'+label+' full panel source')
   check('metrics' in panel['numerical'] and all(k in panel['fidelity'] for k in ('by_length','by_facet')),index['arm']+' '+role+'/'+label+' public metric schema')
   panel_count+=1
check(state_count==36 and panel_count==204,'36states and204controls')
resource=read(R/'training-r1/resources-final.json');reconciliation=read(R/'resource-reconciliation.json');child=read(R/'training-r1/child-exit.json')
pin(R/'training-r1-guardian.log');pin(R/'reconcile_completed_resources.py')
check(child['returncode']==0 and child['leader_reaped'],'model child completed successfully')
check(resource['guardian_returncode']==reconciliation['guardian_returncode']==1 and resource['recovered_after_guardian_failure'] and resource['cleanup_error'],'guardian failure retained explicitly')
check(resource['record']==reconciliation['release_record'] and resource['record']['status']=='released','resource record is exact observed completed disk release')
check(not reconciliation['guardian_success_claimed'] and not reconciliation['shared_state_mutated'] and not reconciliation['foreign_claims_modified'] and not reconciliation['model_rerun'],'read-only reconciliation does not claim guardian success')
check(reconciliation['scheduler_lease_absent'] and reconciliation['owner_exited'] and reconciliation['child_group_dead'],'own resource ownership absent')
check(reconciliation['scheduler_release_actor_unknown'] and reconciliation['failure_time_scheduler_configuration_not_captured'],'recovery limitations remain explicit')
check(resource['reconciliation_receipt']['sha256']==info(R/'resource-reconciliation.json')['sha256'],'resource reconciliation binding')
record=resource['record'];check(record['cpu_slots']==1 and record['memory_mb']==4096 and record['storage_bytes']==2000000000 and record['final_accounting']['limit_bytes']==140000000000,'exact reserved resources')
check('resources=resource' in build and 'guardian_success' not in build and 'guardian_returncode=0' not in build,'public results embed unchanged failure-bearing resource receipt')
check('result=dict(' in build and 'complete=True' in build,'complete denotes numerical evidence package, not guardian success')
old=read(O/'manifest.json');old_results=read(O/'results.json');check(old['archive']==old_results['archive'],'predecessor archive declaration binding')
h=hashlib.sha256();size=0
for index,part in enumerate(old['archive_parts'],1):
 path=pin(O/part['filename']);check(part['filename']=='evidence.tar.xz.part-'+str(index).zfill(3) and part['offset_bytes']==size,'predecessor contiguous chunk order '+str(index))
 check(info(path)=={k:part[k] for k in ('sha256','bytes')},'predecessor chunk bytes '+str(index))
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block);size+=len(block)
check({'sha256':h.hexdigest(),'bytes':size}==old['archive'],'ordered predecessor logical archive SHA/size')
check("if (O/'evidence.tar.xz').exists()" in build and 'prior_hash.update(block);prior_size+=len(block)' in build,'local predecessor logical archive is optional')
check("kind='git_blob'" in build and "Path(path).name in ('manifest.json','results.json')" in build,'large predecessor public metadata resolved by exact Git blob')
excluded={'owned-files.json','publication.json','publication-compatibility.json','build-evidence.log'}
physical={str(p.resolve()) for p in R.rglob('*') if p.is_file() and p.name not in excluded and p.suffix not in ('.pyc','.index') and not any(part=='__pycache__' or part.startswith('pytest-') or part=='.pytest_cache' for part in p.relative_to(R).parts)}
needed=set(manifest['inputs'])|set(audit['artifacts'])|set(ready['artifacts'])
for path in sorted(needed):
 handled=(path in physical or Path(path).parent==O and Path(path).name in ('manifest.json','results.json') or path in old['original_artifact_archive_paths'] or path in old['referenced_artifacts'] or path in old['external_runtime_dependencies'] or Path(path).stat().st_size<10000000)
 check(handled,'all needed artifacts have builder physical/reference route: '+path)
for path in (R/'resource-reconciliation.json',R/'reconcile_completed_resources.py',R/'training-r1-guardian.log',R/'training-r1/child-exit.json',R/'training-r1/resources-final.json'):
 check(str(path) in physical and str(path) in audit['artifacts'],'resource failure/recovery retained and independently bound: '+path.name)
check("48_000_000" in build and "archives = [p for p in owned if '.tar.xz.part-' in p" in pub,'sub100MB Git archive parts only')
check("assert artifact == manifest['archive'] == results['archive']" in pub and "assert item['offset_bytes'] == offset" in pub,'publisher hashes ordered staged concatenation')
check("== manifest['members'][entry.name]" in pub and "producer_not_in_publication_tree" in pub,'publisher verifies all archive member and producer staged bytes')
check("GIT_INDEX_FILE" in pub and "assert local_state(PACKAGE) == before" in pub and "git(root, 'read-tree', base" in pub,'alternate index preserves dirty normal tree/index')
check("assert base == compatibility['publication_parent']" in pub and "assert not compatibility['producer_overlap'] and not compatibility['owned_overlap']" in pub,'publication refuses new unreviewed remote or overlaps')
check("git('diff','--name-only',BASE+'..'+remote)" in compat and "sha((P/rel).read_bytes())==h" in compat,'compatibility uses reference-to-reference Git diff plus actual owned bytes')
check("docs['passed'] is True and docs['document_sha256']==sha(P/doc)" in build,'builder refuses absent/stale final documentation review')
check("for path,expected in item['artifacts'].items():require(info(path)==expected" in build,'builder rechecks all audited artifact hashes')
xml=ET.parse(pin(R/'tests-scoped.xml')).getroot();totals={k:sum(int(s.get(k,0)) for s in xml.iter('testsuite')) for k in ('tests','failures','errors','skipped')}
check(totals['tests']>2226 and not any(totals[k] for k in ('failures','errors','skipped')),'scoped tests clean')
for rel in read(R/'code-files.json'):
 if rel.startswith('docs/'):continue
 frozen=manifest['extensions']|read(R/'validated-test-source.json')
 check(info(P/rel)['sha256']==frozen[rel],'owned production/test matches frozen direct bytes: '+rel)
pin(__file__)
receipt={'schema':'ordered-clause-recurrent-packaging-review/v1','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':not findings,'complete':True,'checks':checks,'findings':findings,'finding_count':len(findings),'scope':'Read-only final packaging-script and saved output/resource contract review; no archive, Git mutation, model, encoder or test execution. Final documentation readiness remains a separately enforced builder prerequisite.','observations':{'states':state_count,'panels':panel_count,'test_counts':totals,'numerical_audit_checks':audit['checks'],'training_child_returncode':child['returncode'],'guardian_returncode':resource['guardian_returncode'],'guardian_success_claimed':False,'predecessor_chunk_count':len(old['archive_parts']),'local_logical_predecessor_archive_required':False},'artifacts':artifacts}
(R/'packaging-review.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='artifacts'},indent=2));raise SystemExit(0 if not findings else 1)
