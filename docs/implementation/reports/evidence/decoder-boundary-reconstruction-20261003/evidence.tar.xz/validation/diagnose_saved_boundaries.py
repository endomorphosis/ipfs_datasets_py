"""Read-only stdlib reconstruction of visited boundary decisions from saved tokens.

No model is imported or executed. Count corrections are reconstructed from
saved logits, not measured recurrent logits; they cannot identify a raw margin
or a counterfactual rollout. Targets are used only to partition observed events.
"""
from pathlib import Path
import collections
import hashlib
import json
import math

P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
R = Path(__file__).resolve().parent
A = P/'workspace/test-logs/decoder-action-binding-20261003/training-r1/results'
FIELDS = {'actor','action','modality','object','conditions','exceptions','temporal'}


def read(path, artifacts):
    raw = path.read_bytes()
    artifacts[str(path)] = dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
    return json.loads(raw)


def unique(pairs):
    result = {}
    for key,value in pairs:
        if key in result: raise ValueError('duplicate key')
        result[key] = value
    return result


def completed_rules(tokens):
    try:
        value = json.loads(''.join(tokens)+']}',object_pairs_hook=unique)
        assert type(value) is dict and set(value)=={'rules'}
        rules = value['rules']
        assert type(rules) is list and rules
        for rule in rules:
            assert type(rule) is dict and set(rule)==FIELDS
            assert all(type(rule[field]) is str for field in ('actor','action','object','modality'))
            assert rule['modality'] in ('O','P','F')
            for field in ('conditions','exceptions','temporal'):
                items = rule[field]
                assert type(items) is list and len(items)<=4 and all(type(item) is str for item in items)
                assert items==sorted(set(items))
        return len(rules)
    except (ValueError,TypeError,AssertionError):
        return None


def lse(values):
    maximum = max(values)
    return maximum+math.log(sum(math.exp(value-maximum) for value in values))


def panel_diagnosis(panel, vocabulary, prior):
    counts = {row['id']:row for row in panel['source_count']['predictions']}
    fidelity = {row['id']:row for row in panel['source_fidelity']['rows']}
    totals, lengths, events, corrections, rows = collections.Counter(), {}, collections.Counter(), {}, []
    for prediction in panel['predictions']:
        identity = prediction['id']; count = counts[identity]; scored = fidelity[identity]
        expected = scored['clause_count']
        assert expected==count['expected']
        assert count['predicted']==max(range(32),key=lambda i:count['logits'][i])+1
        totals['equal_unseen_tail_9_through_32_rows'] += int(len(set(count['logits'][8:]))==1)
        parsed = scored['generated_ir']
        generated_count = None if parsed is None else len(parsed['rules'])
        kind = 'unparsed' if parsed is None else 'under' if generated_count<expected else 'over' if generated_count>expected else 'same'
        totals[kind] += 1
        lengths.setdefault(str(expected),collections.Counter())[kind] += 1
        if count['predicted']==expected: totals['count_argmax_correct_'+kind] += 1
        tokens = [vocabulary[index] for index in prediction['token_ids']]
        observed = []
        for index,token in enumerate(tokens[:-1]):
            if token!='}': continue
            k = completed_rules(tokens[:index+1])
            if k is None: continue
            posterior = count['logits'][k-1]-lse(count['logits'][k:]) if k<32 else None
            initial = prior[k-1]-lse(prior[k:]) if k<32 else None
            delta = posterior-initial if k<32 else 0.
            phase = 'before' if k<expected else 'at' if k==expected else 'after'
            chosen = tokens[index+1]
            decision = 'close' if chosen==']' else 'continue' if chosen==',' else 'other'
            key = phase+'_'+decision
            events[key] += 1; corrections.setdefault(key,[]).append(delta)
            if count['predicted']==expected: events['correct_count_'+key] += 1
            if k>=9: events['past8_'+decision] += 1
            observed.append(dict(consumed_generated_tokens=index+1,completed_rules=k,
                prefix_sha256=hashlib.sha256(''.join(tokens[:index+1]).encode()).hexdigest(),
                chosen_token=chosen,reference_partition=phase,
                posterior_stop_tail_log_odds=posterior,prior_stop_tail_log_odds=initial,
                reconstructed_count_correction=delta))
        rows.append(dict(id=identity,reference_count_for_scoring=expected,count_argmax=count['predicted'],
            parsed_generated_count=generated_count,generation_status=prediction['generation_status'],
            ordered_exact=scored['counts']['ordered_exact'],observed_boundaries=observed))
    return dict(count_correct=panel['source_count']['correct'],count_cross_entropy=panel['source_count']['cross_entropy'],
        fidelity_metrics=panel['source_fidelity']['metrics'],parsed_length_totals=dict(totals),
        parsed_length_by_reference={key:dict(value) for key,value in lengths.items()},
        visited_events=dict(events),mean_reconstructed_correction={key:sum(value)/len(value) for key,value in corrections.items()},
        rows=rows)


def main():
    artifacts, arms = {}, []
    for folder in sorted(path for path in A.iterdir() if (path/'training.json').is_file()):
        state = read(folder/'initial-state.json',artifacts)
        vocabulary = state['codec']['target_vocabulary']; prior = state['architecture']['count_prior']['log_prior']
        assert len(set(prior[8:]))==1
        del state
        training = read(folder/'training.json',artifacts)
        result = dict(arm=folder.name,selected_epoch=training['selected_epoch'],
            final_rejection_reasons=training['history'][-1]['rejection_reasons'],splits={})
        for split,label in (('train','training'),('validation','validation')):
            panel = read(folder/'last-attempt'/('evaluation-'+label+'.json'),artifacts)
            result['splits'][split] = panel_diagnosis(panel,vocabulary,prior)
        arms.append(result)
    assert len(arms)==18
    result = dict(schema='saved-action-binding-boundary-diagnosis/v1',complete=True,arms=arms,artifacts=artifacts,
        model_executed=False,training_executed=False,encoder_executed=False,
        targets_used='posthoc scoring partitions only; no generation call',
        raw_recurrent_logits_available=False,counterfactual_generation_claimed=False,
        correction_scope='stdlib reconstruction from saved source-count logits at actual saved complete-rule prefixes',
        whole_rule_extras_are_not_identical_to_excess_generated_rule_count=True,
        admitted=False,qualified=False,convergence_proven=False,fresh_holdout=False)
    output=R/'saved-boundary-diagnosis.json'
    output.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(complete=True,arms=len(arms),panels=36,rows=sum(len(v['rows']) for arm in arms for v in arm['splits'].values()),
        output=str(output),sha256=hashlib.sha256(output.read_bytes()).hexdigest())))


if __name__=='__main__': main()
