"""Archive complete ordered-clause-recurrent observations and exact predecessor references."""
from pathlib import Path
import hashlib, json, os, subprocess, tarfile, xml.etree.ElementTree as ET
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
O=P/'docs/implementation/reports/evidence/decoder-action-binding-20261003'
E=P/'docs/implementation/reports/evidence/decoder-boundary-reconstruction-20261003'
BASE=json.loads((R/'base.json').read_bytes())['base']
FALSE=dict(qualified=False,admitted=False,proof_authority=False,source_semantics_verified=False,
 convergence_proven=False,fresh_holdout=False,lake_executed=False,formalized=False,roundtrip_ok=False,
 checkpoint_promoted=False,production_checkpoint=False,optimizer_resumable=False,native_validation_executed=False)
def require(v,message):
 if not v:raise ValueError(message)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def info(path):return dict(sha256=sha(path),bytes=Path(path).stat().st_size)
def write(path,value):
 b=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
 if path.exists():require(path.read_bytes()==b,'existing output differs: '+str(path))
 else:
  with path.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def git(*args):return subprocess.check_output(['git',*args],cwd=P)
def main():
 require(not E.exists(),'new immutable evidence directory required')
 audit=read(R/'independent-audit.json');ready=read(R/'readiness.json')
 for item in (audit,ready):
  require(item['passed'] is True and item['finding_count']==0 and not item['findings'],'clean independent audit required')
  for path,expected in item['artifacts'].items():require(info(path)==expected,'audited artifact changed: '+path)
 summary=read(R/'training-r1/results/summary.json'); require(summary['complete'] is True and len(summary['runs'])==12,'complete12 fits required')
 require(summary['all_six_original_action_contrastive_baselines_replayed'] is True,'baseline replay required')
 manifest=read(R/'training-manifest.json');plan=read(R/'training-plan.json')
 require(manifest['plan_sha256']==sha(R/'training-plan.json') and plan['input_sha256']==manifest['inputs'],'sealed recipe differs')
 for path,h in manifest['inputs'].items():require(sha(path)==h,'input changed: '+path)
 for k in FALSE:
  if k in summary:require(summary[k] is False,'authority claim: '+k)
 tests={k:0 for k in ('tests','failures','errors','skipped')}
 for suite in ET.parse(R/'tests-scoped.xml').getroot().iter('testsuite'):
  for k in tests:tests[k]+=int(suite.get(k,0))
 require(tests['tests']>2226 and not any(tests[k] for k in ('failures','errors','skipped')),'passing scoped regression required')
 docs=read(R/'documentation-review.json');doc='docs/autoencoders/decoder_length_distillation.md'
 require(docs['passed'] is True and docs['document_sha256']==sha(P/doc),'reviewed documentation required')
 code_files=read(R/'code-files.json')
 frozen_candidates=dict(manifest['extensions']);frozen_candidates.update(read(R/'validated-test-source.json'))
 for rel in code_files:
  expected=docs['document_sha256'] if rel==doc else frozen_candidates.get(rel)
  require(expected is not None and sha(P/rel)==expected,'live candidate differs from validated frozen bytes: '+rel)
 old=read(O/'manifest.json');old_results=read(O/'results.json')
 for name in ('manifest.json','results.json'):
  require((O/name).read_bytes()==git('show',BASE+':'+str((O/name).relative_to(P))),'predecessor publication differs')
 require(old['archive']==old_results['archive'],'predecessor metadata archive differs')
 prior_hash=hashlib.sha256();prior_size=0
 for index,part in enumerate(old['archive_parts'],1):
  require(part['filename']=='evidence.tar.xz.part-'+str(index).zfill(3) and part['offset_bytes']==prior_size,
   'predecessor chunk order or offset differs')
  path=O/part['filename'];require(info(path)=={k:part[k] for k in ('sha256','bytes')},'predecessor chunk differs')
  require(path.read_bytes()==git('show',BASE+':'+str(path.relative_to(P))),'predecessor published chunk differs')
  with path.open('rb') as stream:
   for block in iter(lambda:stream.read(1048576),b''):prior_hash.update(block);prior_size+=len(block)
 require(dict(sha256=prior_hash.hexdigest(),bytes=prior_size)==old['archive'],'predecessor logical archive differs')
 if (O/'evidence.tar.xz').exists():require(info(O/'evidence.tar.xz')==old['archive'],'optional logical archive differs')
 native_dep=dict(id='action-binding-'+BASE,repository='https://github.com/endomorphosis/ipfs_datasets_py',git_commit=BASE,
  archive=dict(logical_filename='evidence.tar.xz',**old['archive']),
  archive_parts=[dict(path=str((O/p['filename']).relative_to(P)),**p) for p in old['archive_parts']],
  manifest=dict(path=str((O/'manifest.json').relative_to(P)),**info(O/'manifest.json')),
  results=dict(path=str((O/'results.json').relative_to(P)),**info(O/'results.json')),
  retrieval='Read ordered archive_parts at git_commit:path, verify each chunk, concatenate, verify logical archive before extraction.')
 dependencies=[native_dep]+old['archive_dependencies'];refs={};external=old['external_runtime_dependencies']
 members={};originals={};sources={}
 def add(path,name):
  path=Path(path).resolve();require(path.is_file() and not path.is_symlink(),'regular source required')
  require(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe member')
  expected=info(path)
  if name in members:require(members[name]==expected,'archive member collision')
  members[name]=expected;sources[name]=path;originals[str(path)]=name
 # Keep complete local diagnostics, plans, states, controls, test logs and failed
 # attempts. Process-only Git indices/cache files do not carry model evidence.
 excluded={'owned-files.json','publication.json','publication-compatibility.json','build-evidence.log'}
 for path in sorted(R.rglob('*')):
  if not path.is_file() or path.name in excluded or path.suffix in ('.pyc','.index') or any(
   part=='__pycache__' or part.startswith('pytest-') or part=='.pytest_cache' for part in path.relative_to(R).parts):continue
  rel=path.relative_to(R)
  name=('source/'+str(rel.relative_to('experiment-source'))) if rel.parts[0]=='experiment-source' else 'validation/'+str(rel)
  add(path,name)
 add(P/doc,'source/'+doc)
 for rel in code_files:
  require(members['source/'+rel]==info(P/rel),'candidate archive binding differs: '+rel)
  originals[str((P/rel).resolve())]='source/'+rel
 union=dict(old['validated_producer_source_sha256']);union.update(manifest['extensions'])
 for scoped,h in summary['source_dependencies'].items():
  scope,rel=scoped.split(':',1);require(scope in ('extension','dependency'),'unknown producer scope')
  require(rel not in union or union[rel]==h,'conflicting current producer')
  union[rel]=h
 for rel,h in union.items():
  source=R/'experiment-source'/rel
  if not source.is_file():source=S/rel
  if not source.is_file() or sha(source)!=h:
   content=git('show',BASE+':'+rel);require(hashlib.sha256(content).hexdigest()==h,'missing exact producer: '+rel)
   source=R/'retained-source'/rel;source.parent.mkdir(parents=True,exist_ok=True);source.write_bytes(content)
  add(source,'source/'+rel)
 # Resolve every input and every audit dependency without copying old weights.
 needed=set(manifest['inputs'])|set(audit['artifacts'])|set(ready['artifacts'])
 for path in sorted(needed):
  if path in originals:continue
  expected=info(path)
  if Path(path).parent==O and Path(path).name in ('manifest.json','results.json'):
   require(Path(path).read_bytes()==git('show',BASE+':'+str(Path(path).relative_to(P))),'predecessor Git metadata differs')
   refs[path]=dict(kind='git_blob',dependency_id=native_dep['id'],git_commit=BASE,
    path=str(Path(path).relative_to(P)),**expected)
  elif path in old['original_artifact_archive_paths']:
   member=old['original_artifact_archive_paths'][path]
   require(old['members'].get(member)==expected,'predecessor member differs: '+path)
   refs[path]=dict(kind='archive_member',dependency_id=native_dep['id'],member=member,**expected)
  elif path in old['referenced_artifacts']:
   ref=old['referenced_artifacts'][path];require(all(ref[k]==expected[k] for k in expected),'predecessor reference differs')
   refs[path]=ref
  elif path in old['protected_external_artifacts']:
   protected=old['protected_external_artifacts'][path]
   require(all(protected[k]==expected[k] for k in expected)
    and protected.get('bundled') is False and protected.get('role')=='protected_unmodified_not_executed_input',
    'protected unexecuted artifact differs')
  elif path in external:
   require(all(external[path][k]==expected[k] for k in expected),'local external asset differs')
  else:
   # Small orchestration metadata not already in a published predecessor.
   require(Path(path).stat().st_size<10_000_000,'unresolved large external artifact: '+path)
   add(path,'additional-inputs/'+sha(path)+'-'+Path(path).name)
 E.mkdir(parents=True)
 archive=E/'evidence.tar.xz'
 with tarfile.open(archive,'w:xz',preset=6) as bundle:
  for name,path in sorted(sources.items()):
   require(info(path)==members[name],'evidence changed while archiving')
   item=bundle.gettarinfo(str(path),arcname=name);item.uid=item.gid=0;item.uname=item.gname='';item.mtime=0
   with path.open('rb') as stream:bundle.addfile(item,stream)
 parts=[];offset=0
 with archive.open('rb') as stream:
  for index,block in enumerate(iter(lambda:stream.read(48_000_000),b''),1):
   path=E/('evidence.tar.xz.part-'+str(index).zfill(3));path.write_bytes(block)
   parts.append(dict(filename=path.name,offset_bytes=offset,**info(path)));offset+=len(block)
 require(offset==archive.stat().st_size and parts,'archive chunk coverage differs')
 with tarfile.open(archive,'r:xz') as bundle:
  require(len(bundle.getmembers())==len(members),'archive inventory differs')
  for item in bundle:
   b=bundle.extractfile(item).read();require(dict(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))==members[item.name],'archive bytes differ')
 current=read(R/'before.json');checkpoint=current['checkpoint']
 require(info(checkpoint['path'])=={k:checkpoint[k] for k in ('sha256','bytes')},'protected checkpoint changed')
 resource=read(R/'training-r1/resources-final.json');record=resource['record']
 require(resource['status']==record['status']=='released' and record['artifacts_durable_asserted']
  and not record['attempt_exceeded_reservation'] and record['cpu_slots']==1 and record['memory_mb']==4096
  and record['storage_bytes']==2000000000 and record['final_accounting']['limit_bytes']==140000000000,'resource accounting differs')
 archive_info=info(archive)
 readme=E/'README.md'
 readme.write_text("""# Ordered clause recurrent decoder experiment

Twelve fresh fits compare the existing action-contrastive recipe with an optional source-clause signal into the GRU at 8D, 384D and 768D. All candidates remain unselected. Aggregate exact reconstruction is unchanged at 58/288 exposed validation spans; no default recipe or qualification gate is replaced. No Lake build or Lean admission is claimed.

`results.json` contains compact comparisons and resource accounting. `manifest.json` authenticates every archived source/result and exact predecessor references. All 36 typed states and 204 panels are retained, including failed controls. These states do not include optimizer/RNG resume data.

Reassemble the archive using only the filenames in `manifest.json` → `archive_parts`, in that listed order. Check each chunk's byte count and SHA-256, concatenate them to `evidence.tar.xz`, then check the whole archive against `manifest.json` → `archive`. The unchunked archive is not a Git file. Archive paths beginning `source/` are frozen producers; `validation/` contains commands, plans, reports, raw predictions, tests and audits. Predecessor references specify immutable commits and ordered chunks or exact Git blobs.

The numerical child completed with exit 0. Its guardian failed during scheduler lease cleanup after the disk reservation had already been released. Read-only reconciliation verified the released record, dead owned processes and absent lease; no shared state was changed. Both failure and recovery receipts are retained.

Method, APIs, per-span timings and limitations: [decoder documentation](../../../../autoencoders/decoder_length_distillation.md#ordered-clause-conditioning-in-the-recurrent-decoder-2026-10-03).
""")
 m=dict(schema='ordered-clause-recurrent-source-training-archive/v1',archive=archive_info,archive_filename=archive.name,archive_parts=parts,publication_support={'README.md':info(readme)},
  archive_compression='xz',xz_preset=6,archive_standalone=False,members=members,original_artifact_archive_paths=originals,
  referenced_artifacts=refs,archive_dependencies=dependencies,external_runtime_dependencies=external,
  protected_external_artifacts=old['protected_external_artifacts'],validated_producer_source_sha256=union,
  dependency_scope='All12fresh fits,36states,204controls and training pair evidence retained; inherited source inputs use exact prior Git archive members.',
  reproducibility_scope='Frozen producers and artifacts; installed libraries/hardware and unused encoder assets remain external. No encoding or downloads in this round.',**FALSE)
 write(E/'manifest.json',m)
 owned=read(R/'code-files.json')+[str((E/n).relative_to(P)) for n in [p['filename'] for p in parts]+['manifest.json','results.json','README.md']]
 quality=[]
 for entry in summary['runs']:
  run=read(entry['summary_path']);require(sha(entry['summary_path'])==entry['summary_sha256'],'run index differs')
  report=read(run['training_ref']['path']);require(sha(run['training_ref']['path'])==run['training_ref']['sha256'],'training ref differs')
  quality.append({k:run[k] for k in ('arm','dimension','seed','recipe','training_call_elapsed_seconds','elapsed_seconds','trainable_parameter_count','baseline_replay')}
   |dict(selected_epoch=report['selected_epoch'],optimizer_steps=report['optimizer_steps'],
    initial_weights_sha256=report['initial_weights_sha256'],selected_weights_sha256=report['selected_weights_sha256'],
    last_complete_attempt_weights_sha256=report['last_complete_attempt_weights_sha256'],
    controls={role:{label:dict(fidelity=panel['fidelity']['metrics'],by_length=panel['fidelity']['by_length'],by_facet=panel['fidelity']['by_facet'],numerical=panel['numerical']['metrics'])
        for label,panel in panels.items()} for role,panels in run['postfit'].items()}))

 candidate={rel:sha(P/rel) for rel in code_files}
 for rel,h in candidate.items():
  require(h==(docs['document_sha256'] if rel==doc else frozen_candidates[rel]),'candidate changed during packaging: '+rel)
 result=dict(schema='ordered-clause-recurrent-source-training-results/v1',complete=True,archive=archive_info,
  plan=plan,runs=quality,tests=tests,known_excluded_fixture='16 setup cases for incompatible retained384 release; not used by this experiment; original failure retained in predecessor evidence',
  independent_audit_sha256=sha(R/'independent-audit.json'),independent_audit_checks=audit['checks'],
  candidate_sha256=candidate,resources=resource,elapsed_seconds=summary['elapsed_seconds'],
  workers=1,bridge_names=[],legal_ir_evaluate_provers=False,metric_disk_cache_used=False,
  training_executed=True,encoder_executed=False,downloads_performed=False,
  guardian_succeeded=False,resource_receipt_reconciled_after_guardian_failure=True,**FALSE)
 write(E/'results.json',result);write(R/'owned-files.json',owned)
 print(json.dumps(dict(complete=True,archive=archive_info,members=len(members),sources=len(union),references=len(refs),owned=len(owned))))
if __name__=='__main__':main()
