"""Targeted read-only review of the recurrent-clause result appendix."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
from datetime import datetime,timezone
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
artifacts={};checks=[];findings=[]
def load(path,json_value=True):
 p=Path(path).resolve();data=p.read_bytes();artifacts[str(p)]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
 return json.loads(data) if json_value else data.decode()
def check(value,label):
 checks.append(label)
 if not value:findings.append(label)
doc=P/'docs/autoencoders/decoder_length_distillation.md';text=load(doc,False);digest=artifacts[str(doc)]['sha256']
check(digest=='0db0c7f6e5aa9132e0ba5e877645904341b0fcf4e39d1961c15556c6e50d9b6b','expected final document SHA')
section=text.split('## Ordered clause conditioning in the recurrent decoder (2026-10-03)',1)[1]
o=load(R/'outcomes.json');proposal=load(R/'proposed-outcomes-doc.txt',False)
check(o['passed'] and not o['findings'],'outcomes receipt clean')
check(proposal in section,'entire independently prepared numerical table and interpretation retained')
summary=load(R/'training-r1/results/summary.json');audit=load(R/'independent-audit.json')
check(summary['complete'] and len(summary['runs'])==12,'twelve complete fits')
check(audit['passed'] and not audit['findings'] and audit['checks']==172172,'independent saved-data audit clean')
for k in ('lake_executed','qualified','admitted','checkpoint_promoted','fresh_holdout','convergence_proven'):
 check(summary[k] is False,'no authority: '+k)
for item in summary['runs']:
 v=load(item['summary_path']);check(artifacts[item['summary_path']]['sha256']==item['summary_sha256'],'arm index bound '+v['arm'])
 r=o['runs'][v['arm']];f=r['controls']['last-attempt']['validation'];d=r['dimension'];seed=r['seed'];arm=r['recipe']['name']
 row=f"| {d} | {seed} | {arm} | {f['numerical_seconds_per48']:.6f} | {f['numerical_seconds_per_span']:.6f} | {f['whole_panel_seconds_per_span']:.6f} | {r['training_rows_presented_per_fit_second']:.2f} |"
 check(row in section,'runtime row exact '+v['arm'])
 check(r['selected_epoch']==0 and r['accepted_validations']==0,'unaccepted retained initializer '+v['arm'])
 check(r['training_rows_presented']==2440,'training row rate denominator '+v['arm'])
 check(len(r['controls']['selected'])==8+int(r['recipe']['recurrent']),'controls count '+v['arm'])
 if not r['recipe']['recurrent']:check(r['baseline_replay']['complete'],'exact baseline replay '+v['arm'])
for arm in ('action-contrastive','recurrent-clause'):
 check(sum(v['controls']['last-attempt']['validation']['exact'] for v in o['runs'].values() if v['recipe']['name']==arm)==58,'aggregate58/288 '+arm)
best=o['runs']['768-recurrent-clause-2718'];baseline=o['runs']['768-action-contrastive-2718'];b=best['controls']['last-attempt']['validation'];a=baseline['controls']['last-attempt']['validation']
for key,value in dict(exact=30,eos=48,duplicates=20,extra=33,missing=10,raw_action=180,generated_action=172,generated_actor_action=170).items():check(b[key]==value,'best candidate '+key)
check([b['by_length'][str(n)]['exact'] for n in (1,2,4,8)]==[12,5,5,8],'candidate exact bylength')
check([a['by_length'][str(n)]['exact'] for n in (1,2,4,8)]==[12,4,3,10],'baseline exact bylength')
check(best['controls']['last-attempt']['recurrent-residual-off']['exact']==25,'residual-off exact25')
check(best['residual_off_effect']['last-attempt']['changed_predictions']==7,'residual-off changes seven predictions')
for c in ('source-shuffle','context-only-shuffle'):check(best['controls']['last-attempt'][c]['exact']==0,'zero exact on '+c)
for phrase in ('not a fresh holdout','not an isolated speed comparison','identity projection MSE is not learned reconstruction','not actual visited-prefix traces','No bridge-on legal-IR evaluation','The Constitution remains unformalized','not a claim that the original guardian completed successfully','actor and exact intervening values are unknown'):
 check(phrase in section,'scope caveat '+phrase)
start=load(R/'training-r1/resources-start.json');final=load(R/'training-r1/resources-final.json');recovery=load(R/'resource-reconciliation.json');obs=load(R/'training-r1/resource-observations.json');exit=load(R/'training-r1/child-exit.json')
check(start['record']['cpu_slots']==1,'one CPU reservation');check(start['record']['memory_mb']==4096,'4GiB reservation');check(start['record']['storage_bytes']==2000000000,'2GB output reservation');check(final['storage_limit_bytes']==140000000000,'unchanged140GBcap')
check(len(obs)==23 and max(v['group_rss']['rss_bytes'] for v in obs)==1479499776,'observed polled RSS maximum and23samples')
check(final['record']['final_attempt_bytes']==619572063,'durable attempt byte count')
check((R/'training-r1/results/summary.json').stat().st_size==16497,'compact top-level index bytes')
check(len(list((R/'training-r1/results').glob('*/*-state.json')))==36,'36typed states retained')
check(len(list((R/'training-r1/results').glob('*/*/evaluation-*.json')))==204,'204panels retained')
check(exit['returncode']==0 and exit['leader_reaped'],'model child successful/reaped')
check(round(exit['guardian_elapsed_through_child_exit_seconds'],3)==467.248,'guardian time only through child exit')
check(final['guardian_returncode']==1 and final['recovered_after_guardian_failure'],'guardian failure explicitly recorded')
check(final['record']['status']=='released' and final['resource_lease']['released'],'reconciled release records')
for k in ('model_rerun','shared_state_mutated','scheduler_reset_performed','scheduler_release_performed','foreign_claims_modified','guardian_success_claimed'):
 check(recovery[k] is False,'read-only reconciliation '+k)
for k in ('owner_exited','child_group_dead','attempt_inode_verified','scheduler_lease_absent','scheduler_config_now_matches_adopted','configuration_change_actor_unknown','failure_time_scheduler_configuration_not_captured'):
 check(recovery[k] is True,'reconciliation evidence '+k)
check(artifacts[str(R/'resource-reconciliation.json')]['sha256']==final['reconciliation_receipt']['sha256'],'finalresource binds reconciliation bytes')
load(R/'reconcile_completed_resources.py',False)
saved=load(R/'saved-boundary-diagnostic.json');root_saved=load(R/'saved-boundary-diagnosis.json')
for seed in (1729,2718):
 val=saved['runs'][f'384-action-contrastive-{seed}']['panels']['validation']['by_length'];multi=[val[str(n)] for n in (2,4,8)]
 check(sum(x['premature_close'] for x in multi)==36,'prior384multiclauses allclose early '+str(seed))
 check(sum(x['count_correct'] for x in multi) in (20,21),'prior384correctcount multiclause '+str(seed))
val=saved['runs']['768-action-contrastive-2718']['panels']['validation']['by_length']
check(sum(x['wrong_boundary_rows'] for x in val.values())==17,'17wrong boundary rows')
check(sum(x['first_wrong_omitted_by_first_last'] for x in val.values())==12,'12of17firstwrong omitted')
check(48-sum(x['exact'] for x in val.values())==19,'19prior failed documents')
for arm in root_saved['arms']:
 for split,entry in arm['splits'].items():
  check(entry['parsed_length_totals']['equal_unseen_tail_9_through_32_rows']==48,'counttail equality '+arm['arm']+'/'+split)
xml=load(R/'tests-scoped.xml',False);suites=ET.fromstring(xml).findall('testsuite')
check(sum(int(x.attrib['tests']) for x in suites)==2314 and all(int(x.attrib['failures'])==int(x.attrib['errors'])==0 for x in suites),'2314passing scoped tests')
for name in ('ordered-model-tests.xml','recurrent-runner-tests.xml'):
 x=ET.fromstring(load(R/name,False)).find('testsuite');check(int(x.attrib['tests'])==44 and int(x.attrib['failures'])==int(x.attrib['errors'])==0,'44focused tests '+name)
check('16 setup cases' in section,'known incompatible unusedfixture failures disclosed')
for path,entry in artifacts.items():check(hashlib.sha256(Path(path).read_bytes()).hexdigest()==entry['sha256'],'reviewinput unchanged '+str(Path(path).name))
value=dict(schema='ordered-clause-recurrent-documentation-review/v1',complete=True,passed=not findings,document_path=str(doc),document_sha256=digest,
 checks=len(checks),findings=findings,reviewed_from_heading='Ordered clause conditioning in the recurrent decoder (2026-10-03)',
 scope='targeted saved-result tables, limits, timings, aggregate/best/control outcomes, scoped tests and resource reconciliation; no model execution',
 created_at=datetime.now(timezone.utc).isoformat(),artifacts=artifacts,model_executed=False,source_edited=False,document_edited=False)
(R/'documentation-review.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in value.items() if k!='artifacts'}))
