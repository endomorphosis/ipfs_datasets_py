"""Synthetic ordered-clause runner checks using frozen canonical dependencies, never HACC."""
from pathlib import Path
import hashlib,importlib,json,os,sys
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
A=P/'ipfs_datasets_py/logic/formalization/autoencoder'
files=['scripts/ops/autoencoder/benchmark_ordered_clause_recurrent_training.py',
 'tests/unit/logic/formalization/autoencoder/test_ordered_clause_recurrent_training_runner.py']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={name:sha(P/name) for name in files}
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI='0',CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
sys.dont_write_bytecode=True;sys.path.insert(0,str(S))
package=importlib.import_module('ipfs_datasets_py.logic.formalization.autoencoder');package.__path__.insert(0,str(A))
from ipfs_datasets_py.logic.autoformal.tree_pin import require_workspace_logic_tree
tree=require_workspace_logic_tree();assert all(Path(p).is_relative_to(S) for p in tree.values())
import pytest
code=pytest.main(['-q',str(P/files[-1]),'--junitxml='+str(R/'recurrent-runner-tests.xml'),'-o','cache_dir='+str(R/'pytest-runner-cache')])
assert pins=={name:sha(P/name) for name in files}
modules={}
for name,module in list(sys.modules.items()):
 if name.startswith('ipfs_datasets_py'):
  path=getattr(module,'__file__',None)
  if path and Path(path).is_file():
   resolved=Path(path).resolve();assert resolved.is_relative_to(S) or resolved.is_relative_to(A),(name,str(resolved))
   modules[name]={'path':str(resolved),'sha256':sha(resolved)}
(R/'recurrent-runner-test-provenance.json').write_text(json.dumps({'tree_pin':tree,'modules':modules,'files':pins,'pytest_returncode':code,'actual_models_executed':False,'synthetic_models_only':True,'offline':True},indent=2)+'\n')
raise SystemExit(code)
