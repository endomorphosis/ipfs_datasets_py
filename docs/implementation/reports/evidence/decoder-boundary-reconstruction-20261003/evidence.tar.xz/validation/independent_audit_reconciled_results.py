"""Independent persisted-data audit of ordered recurrent source conditioning.

No model, encoder, optimizer, compiler or prover is executed. Prior inputs and
baseline arithmetic are authenticated against the published action experiment.
Only new candidate arithmetic is recomputed; exact baseline replay is checked
against all original reports, tensors and control predictions.
"""
from pathlib import Path
from copy import deepcopy
from collections import Counter
from datetime import datetime, timezone
import argparse
import ast
import hashlib
import importlib.util
import json
import math
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
R=Path(__file__).resolve().parent; P=R.parents[2]
A=P/'workspace/test-logs/decoder-action-binding-20261003'
PUBLIC=P/'docs/implementation/reports/evidence/decoder-action-binding-20261003'
AUTO='ipfs_datasets_py/logic/formalization/autoencoder/'
SCHEMA='ordered-clause-recurrent-source-decoder-development/v1'
checks=0; findings=[]; artifacts={}


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def digest(value):return hashlib.sha256(raw(value)).hexdigest()


def check(value,label,detail=None):
    global checks
    checks+=1
    if not value:findings.append(dict(label=label,detail=detail))


def pin(path,expected=None):
    path=Path(path).resolve(); value=dict(sha256=sha(path),bytes=path.stat().st_size)
    if expected is not None:check(value['sha256']==expected,'pin/'+str(path))
    artifacts[str(path)]=value
    return path


def read(path):return json.loads(pin(path).read_bytes())


def load_arithmetic():
    pins=read(R/'audit-helper-pins.json')
    old_manifest=read(PUBLIC/'manifest.json'); old_results=read(PUBLIC/'results.json')
    base=read(R/'base.json')['base']
    for name in ('manifest.json','results.json'):
        path=PUBLIC/name
        blob=subprocess.check_output(['git','show',base+':'+str(path.relative_to(P))],cwd=P)
        check(hashlib.sha256(blob).hexdigest()==sha(path),'prior/exact_published_git_metadata/'+name)
    old_audit=read(A/'independent-audit.json')
    check(sha(A/'independent-audit.json')==old_results['independent_audit_sha256']
        and old_audit['passed'] and old_audit['finding_count']==0,'prior/published_clean_action_audit')
    for name,entry in pins.items():
        pin(R/name,entry['sha256'])
        member=old_manifest['original_artifact_archive_paths'][entry['source_path']]
        check(old_manifest['members'][member]=={k:entry[k] for k in ('sha256','bytes')},'prior/published_arithmetic/'+name)
    spec=importlib.util.spec_from_file_location('_authenticated_action_arithmetic',R/'action_audit_arithmetic.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    for owner in (module,module.native,module.clause,module.prior,module.leaf):owner.check=check;owner.read=read
    module.pin=pin;module.native.pin=pin
    return module,old_manifest,old_audit


action,old_public,old_audit=load_arithmetic()
native=action.native; clause=action.clause; prior=action.prior; leaf=action.leaf
close=prior.close; CONTROLS=action.CONTROLS


def inherited(path):
    path=Path(path).resolve(); expected=old_audit['artifacts'].get(str(path))
    if expected is None:
        member=old_public['original_artifact_archive_paths'].get(str(path))
        expected=old_public['members'][member] if member is not None else old_public['referenced_artifacts'].get(str(path))
    check(expected is not None,'prior/known_input/'+str(path))
    value=read(path)
    check(expected is not None and artifacts[str(path)]['sha256']==expected['sha256']
        and artifacts[str(path)]['bytes']==expected['bytes'],'prior/exact_input/'+str(path))
    return value


def source_guards(source):
    oldsource=A/'experiment-source'
    for name in ('decoder_distillation_experiment','decoder_source_fidelity','long_span_count_exposure_training',
                 'clause_source_context','clause_source_controls','action_factorized_clause_decoder_experiment'):
        rel=AUTO+name+'.py';check(sha(source/rel)==sha(pin(oldsource/rel)),'source/unchanged/'+name)
    rel=AUTO+'long_span_source_value_training.py'; before=(oldsource/rel).read_text(); after=(source/rel).read_text()
    def section(text,start,end):return text.split(start,1)[1].split(end,1)[0]
    for label,start,end in [('optimizer','    optimizer = torch.optim.AdamW','    evaluate = lambda:'),
        ('selection','            observed, accepted, reasons =','    report = dict('),
        ('existing_report','    report = dict(','    report["elapsed_seconds"]')]:
        check(section(before,start,end)==section(after,start,end),'source/exact_'+label)
    # The explicit new-schema dispatch and honest context-use telemetry are the
    # only approved edits; normalize those exact AST forms, then compare all.
    class ApprovedDispatch(ast.NodeTransformer):
        def visit_If(self,node):
            if isinstance(node.test,ast.Compare) and any(isinstance(n,ast.Constant) and n.value==SCHEMA for n in ast.walk(node.test)):
                if len(node.body)==2 and isinstance(node.body[0],ast.ImportFrom) and any(a.name=='ordered_clause_recurrent_decoder_experiment' for a in node.body[0].names):return None
            return self.generic_visit(node)
        def visit_Tuple(self,node):
            node=self.generic_visit(node);node.elts=[n for n in node.elts if not (isinstance(n,ast.Constant) and n.value==SCHEMA)];return node
        def visit_Compare(self,node):
            node=self.generic_visit(node)
            if len(node.ops)==1 and isinstance(node.ops[0],ast.In) and isinstance(node.comparators[0],ast.Tuple) and len(node.comparators[0].elts)==1:
                node.ops=[ast.Eq()];node.comparators=node.comparators[0].elts
            return node
        def visit_keyword(self,node):
            if node.arg=='source_context_used_for_scalar_head_only' and isinstance(node.value,ast.Call):
                expected=ast.parse('head_specification.get("source_context_used_for_scalar_head_only", True)',mode='eval').body
                check(ast.dump(node.value)==ast.dump(expected),'source/exact_context_telemetry_change');node.value=ast.Constant(True)
            return self.generic_visit(node)
    check(ast.dump(ApprovedDispatch().visit(ast.parse(after)),include_attributes=False)==ast.dump(ast.parse(before),include_attributes=False),
        'source/full_trainer_only_approved_dispatch_and_telemetry')
    oldloss=ast.parse((oldsource/AUTO/'action_contrastive_decoder_training.py').read_text())
    newloss=ApprovedDispatch().visit(ast.parse((source/AUTO/'action_contrastive_decoder_training.py').read_text()))
    check(ast.dump(oldloss)==ast.dump(newloss),'source/full_contrastive_loss_only_schema_acceptance')
    for name in ('adopt_shared_scheduler.py','run_frozen_tests.py'):
        check(pin(R/name).read_bytes()==pin(A/name).read_bytes(),'orchestration/unchanged/'+name)
    old_guardian=pin(A/'run_training_reserved.py').read_text()
    expected=old_guardian.replace('benchmark_action_binding_source_training.py','benchmark_ordered_clause_recurrent_training.py').replace('storage_bytes=2_500_000_000','storage_bytes=2_000_000_000')
    check(pin(R/'run_training_reserved.py').read_text()==expected,'orchestration/only_runner_and_storage_reservation_changed')


def common(args):
    manifest=read(args.manifest);plan=read(args.plan)
    check(sha(args.plan)==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'],'pins/recipe')
    for path,wanted in manifest['inputs'].items():pin(path,wanted)
    for rel,wanted in manifest['extensions'].items():pin(args.source/rel,wanted)
    for rel,wanted in read(R/'validated-test-source.json').items():pin(args.source/rel,wanted)
    source_guards(args.source)
    fixed=dict(schema='ordered-clause-recurrent-source-training-plan/v1',dimensions=[8,384,768],seed_order=[1729,2718],fit_count=12,
        original_training_rows=48,exposed_validation_rows=48,fixed_encoder_context_tokens=512,fixed_decoder_output_limit=512,
        temperature=0,action_contrastive_temperature=.1,fresh_initialization=True,selection_unchanged=True,
        cardinality_weight=.25,source_value_weight=.25,recurrent_parameter_delta=2048,
        expected_optimizer_steps_per_arm=340,expected_training_token_presentations_per_arm=225840,
        expected_row_presentations_per_arm=2440,expected_count_presentations_per_arm=2440,
        expected_source_value_presentations_per_arm=25600,full_vocabulary_retained=True,syntax_forced=False,closure_forced=False,
        generation_reference_count_access=False,production_promotion_allowed=False,no_downloads=True,
        encoder_executed_during_training=False,additional_candidate_control='recurrent-residual-off')
    for key,value in fixed.items():check(plan.get(key)==value,'plan/'+key)
    check([a['name'] for a in plan['arms']]==['action-contrastive','recurrent-clause']
        and all(a['action_contrastive_weight']==.05 and a['factorized'] and a['head_kind']=='clauses'
            and not a['order_augmentation'] and a['generated_boundary_weight']==0 for a in plan['arms']), 'plan/exact_loss_and_arms')
    baseline={name:inherited(path) for name,path in manifest['baseline_summaries'].items()}
    corpus=inherited(manifest['paragraphs']);prepared=inherited(manifest['dimension_inputs']);donor=inherited(manifest['donor'])
    original={r['id']:r for split in ('train','validation') for r in corpus[split]};lookup={};lanes={}
    for split in ('train','validation'):
        lookup[split]={}
        for row in corpus[split]:
            parts=row['source_text'].split('\n\n');rules=row['target']['rules']
            check(len(parts)==len(rules)==row['clause_count'],'source/unchanged_ordered_components/'+row['id'])
            for part,rule in zip(parts,rules):lookup[split][clause.textsha(part)]=dict(actor=rule['actor'],action=rule['action'],source_text=part)
    for dimension in (8,384,768):
        source=prepared['dimensions'][str(dimension)];contexts=source['source_contexts'];rows={};vectors={};unique={}
        for split in ('train','validation'):
            rows[split]=[dict(row,target_ids=original[row['id']]['target_ids']) for row in source[split]]
            vectors.update({row['id']:row['input'] for row in rows[split]});unique[split]={}
            for row in rows[split]:
                for segment in contexts[split][row['id']]['segments']:unique[split].setdefault(segment['source_sha256'],segment)
        lanes[dimension]=dict(dimension=dimension,contexts=contexts,rows=rows,vectors=vectors,unique=unique)
    return dict(manifest=manifest,plan=plan,baseline=baseline,corpus=corpus,donor=donor,lanes=lanes,lookup=lookup,
        coverage=old_audit['analysis']['coverage'],original={r['id']:r for r in corpus['train']},prepared=original,
        variants={r['id']:[r['id']] for r in corpus['train']})


def typed_digest(values):
    result=hashlib.sha256()
    for name,value in sorted(values.items()):
        integer=name.split('.')[-1] in ('head_initialization_seed','ordered_clause_recurrent_version')
        if integer:check(type(value) is int,'state/integer_buffer/'+name)
        dtype='torch.int64' if integer else 'torch.float32';data=struct.pack('<q',value) if integer else leaf.tensor_bytes(value)
        result.update(raw([name,dtype,leaf.shape(value)]));result.update(data)
    return result.hexdigest()


def state_check(path,report,role,original,ctx,recurrent,label):
    state=read(path);prior.authority(state,label);values=prior.canonical(state);base=prior.canonical(original)
    check(state['schema']=='private-native-dimension-source-state/v1' and state['role']==role
        and state['dimension']==ctx['dimension'],'state/identity/'+label)
    check(state['weights_sha256']==digest(state['model_state']) and state['tensor_sha256']==typed_digest(state['model_state']), 'state/typed_persistence/'+label)
    key='initial_weights_sha256' if role=='initial' else 'selected_weights_sha256' if role=='selected' else 'last_complete_attempt_weights_sha256'
    check(state['tensor_sha256']==report[key],'state/report_binding/'+label)
    expected=set(base)|({'clause_to_embedding.weight','ordered_clause_recurrent_version'} if recurrent else set())
    check(set(values)==expected,'state/exact_inventory/'+label)
    frozen=native.PROJECTION|{'source_mean','source_scale','count_prior_logits','head_initialization_seed','clause_source_mean','clause_source_scale'}
    check(all(values[name]==base[name] for name in frozen),'state/frozen_projection_and_source_statistics/'+label)
    check(state['codec']==original['codec'] and state['input_transform']==original['input_transform']
        and state['initializer_receipt']==original['initializer_receipt'],'state/unchanged_source_initialization/'+label)
    if recurrent:
        check(values['ordered_clause_recurrent_version']==1 and leaf.shape(values['clause_to_embedding.weight'])==[16,128], 'state/explicit_recurrent_geometry/'+label)
        check(state['architecture']['schema']==SCHEMA,'state/explicit_recurrent_schema/'+label)
        frozen.add('ordered_clause_recurrent_version')
    if role=='initial':
        check(all(values[name]==value for name,value in base.items()),'initial/all_original_tensors_equal/'+label)
        if recurrent:check(all(value==0 for value in leaf.flat(values['clause_to_embedding.weight'])),'initial/zero_route/'+label)
    count=sum(math.prod(leaf.shape(value)) for name,value in values.items() if name not in frozen)
    state['_audited_trainable_count']=count
    return state


RECURRENT_CACHE={}


def recurrent_readouts(panel,state,ctx,split,kind,off,label):
    receipt=panel['recurrent_residual_diagnostic'];v=prior.canonical(state)
    _,_,contexts,_,_=clause.control_contexts(ctx,split,kind)
    expected_digest=typed_digest({'body.'+name:value for name,value in state['model_state'].items()}) if off else state['tensor_sha256']
    check(receipt['schema']=='potential-source-clause-recurrent-residuals/v1'
        and receipt['source_only'] is True and receipt['reference_documents_passed_to_model'] is False
        and receipt['actual_prefix_routes_observed'] is False
        and receipt['control']==kind and receipt['residual_disabled'] is off
        and receipt['all_source_routes_removed'] is (kind=='zero_condition')
        and receipt['source_contexts_sha256']==digest(contexts)
        and receipt['model_tensor_sha256']==expected_digest,'recurrence/source_control_scope_and_state/'+label)
    ids=[row['id'] for row in ctx['rows'][split]]
    check([row['id'] for row in receipt['rows']]==ids,'recurrence/exact_row_order/'+label)
    maximum=0.;nonzero=0
    for row in receipt['rows']:
        segments=contexts[row['id']]['segments'];wanted=[]
        check(row['source_mask']==[i<len(segments) for i in range(8)],'recurrence/source_only_mask/'+label+'/'+row['id'])
        for slot in range(8):
            if off or kind=='zero_condition' or slot>=len(segments):wanted.append([0.]*16);continue
            vector=segments[slot]['vector'];key=(state['tensor_sha256'],digest(vector))
            if key not in RECURRENT_CACHE:
                x=[(a-b)/v['clause_source_scale'] for a,b in zip(native.projected(vector,state,ctx),v['clause_source_mean'])]
                features=[]
                for head in ('non_action_head','action_head'):
                    features.extend(math.tanh(value) for value in clause.affine(x,v[head+'.source_projection.weight'],v[head+'.source_projection.bias']))
                RECURRENT_CACHE[key]=clause.affine(features,v['clause_to_embedding.weight'],[0.]*16)
            wanted.append(RECURRENT_CACHE[key])
        observed=row['potential_residuals']
        check(leaf.shape(observed)==[8,16] and close(observed,wanted,8e-5),'recurrence/independent_source_tanh_and_route_affine/'+label+'/'+row['id'])
        maximum=max(maximum,max(abs(a-b) for x,y in zip(observed,wanted) for a,b in zip(x,y)))
        nonzero+=sum(any(value!=0 for value in slot) for slot in observed)
    return dict(rows=len(ids),maximum_float64_affine_error=maximum,nonzero_potential_slots=nonzero,
        actual_prefix_routes_observed=False,residual_disabled=off,all_source_routes_removed=kind=='zero_condition')


COUNT_CACHE={}


def count_readouts(panel,state,ctx,split,kind,label):
    receipt=panel['source_count'];v=prior.canonical(state)
    paragraphs,_,_,_,_=clause.control_contexts(ctx,split,kind)
    refs={r['id']:r for r in ctx['corpus'][split]};loss=0.;entropy=0.;confidence=0.;maximum=0.
    confusion={str(n):{str(k):0 for k in range(1,33)} for n in (1,2,4,8)}
    for row in receipt['predictions']:
        vector=ctx['vectors'][paragraphs[row['id']]];key=(state['tensor_sha256'],None if kind=='zero_condition' else digest(vector))
        if key not in COUNT_CACHE:
            x=[0.]*ctx['dimension'] if kind=='zero_condition' else [(a-b)/v['source_scale'] for a,b in zip(native.projected(vector,state,ctx),v['source_mean'])]
            scores=clause.affine(x,v['count_head.weight'],v['count_head.bias'])
            COUNT_CACHE[key]=[a+b for a,b in zip(scores,v['count_prior_logits'])]
        wanted=COUNT_CACHE[key];scores=row['logits'];normalizer=prior.lse(scores);prob=[math.exp(x-normalizer) for x in scores]
        predicted=max(range(32),key=scores.__getitem__)+1;actual=refs[row['id']]['clause_count']
        ent=-math.fsum(p*math.log(p) for p in prob if p)
        check(len(scores)==32 and close(scores,wanted,8e-5),'count/independent_frozen_normalization_affine_prior/'+label+'/'+row['id'])
        check(row['predicted']==predicted and row['expected']==actual and close(row['probabilities'],prob,2e-6)
            and close(row['predictive_entropy'],ent,2e-6),'count/independent_probability_and_prediction/'+label+'/'+row['id'])
        maximum=max(maximum,max(abs(a-b) for a,b in zip(scores,wanted)));loss+=normalizer-scores[actual-1]
        entropy+=ent;confidence+=max(prob);bucket=confusion.setdefault(str(actual),{});bucket[str(predicted)]=bucket.get(str(predicted),0)+1
    n=len(refs)
    check(receipt['confusion_matrix']==confusion and close(receipt['cross_entropy'],loss/n,2e-6)
        and close(receipt['mean_predictive_entropy'],entropy/n,2e-6) and close(receipt['mean_max_probability'],confidence/n,2e-6),
        'count/independent_full32_confusion_CE_and_entropy/'+label)
    return dict(correct=receipt['correct'],rows=n,cross_entropy=loss/n,maximum_float64_logit_error=maximum)


def baseline_replay(run,report,states,panels,old,label):
    check(set(report)==set(old['training']) and all(report[key]==value for key,value in old['training'].items()
        if key!='elapsed_seconds'),'baseline/all_report_fields_except_time/'+label)
    for role,state in states.items():
        expected=inherited(A/'training-r1/results'/old['arm']/(role+'-state.json'))
        check(state['model_state']==expected['model_state'] and state['tensor_sha256']==expected['tensor_sha256'], 'baseline/all_tensors/'+label+'/'+role)
    for role in ('selected','last-attempt'):
        for name,_,_ in CONTROLS:
            expected=inherited(A/'training-r1/results'/old['arm']/role/('evaluation-'+name+'.json'))
            actual=panels[role][name]
            check(actual['report']['metrics']==expected['report']['metrics'],'baseline/exact_panel_numerical_metrics/'+label+'/'+role+'/'+name)
            for key in ('predictions','source_fidelity','source_count','source_values','hypothetical_boundary_diagnostics'):
                check(actual[key]==expected[key],'baseline/exact_'+key+'/'+label+'/'+role+'/'+name)
    check(run['baseline_replay']['complete'] and not run['baseline_replay']['timing_equality_claimed'],'baseline/runner_receipt/'+label)


def results(args,ctx):
    root=args.results;summary=read(root/'summary.json');prior.authority(summary,'summary')
    expected=[str(d)+'-'+name+'-'+str(seed) for d in (8,384,768) for seed in (1729,2718) for name in ('action-contrastive','recurrent-clause')]
    check(summary['complete'] and summary['schema']=='ordered-clause-recurrent-source-training-comparison/v1'
        and [r['arm'] for r in summary['runs']]==expected,'results/exact_12_registered_fits')
    check(summary['all_six_original_action_contrastive_baselines_replayed'] and not summary['encoder_executed']
        and not summary['downloads_performed'],'results/scope')
    dependency=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
    command=read(root.parent/'command.json')['command']
    check(command[command.index('--dependency-root')+1]==str(dependency)
        and command[command.index('--extension-root')+1]==str(args.source),'source/executed_scope_roots')
    for scoped,wanted in summary['source_dependencies'].items():
        scope,relative=scoped.split(':',1)
        valid=scope in ('dependency','extension') and not Path(relative).is_absolute() and '..' not in Path(relative).parts
        check(valid,'source/closed_inventory_scope/'+scoped)
        if not valid:raise ValueError('invalid source inventory scope: '+scoped)
        pin((dependency if scope=='dependency' else args.source)/relative,wanted)
    lanes={d:native.lane_preparation(root,ctx,d) for d in (8,384,768)};analysis={};cache=set()
    for pointer in summary['runs']:
        pin(pointer['summary_path'],pointer['summary_sha256']);run=read(pointer['summary_path']);label=run['arm'];lane=lanes[run['dimension']]
        recurrent=run['recipe']['recurrent'];old=ctx['baseline'][str(run['dimension'])+'-action-contrastive-'+str(run['seed'])]
        pin(run['training_ref']['path'],run['training_ref']['sha256']);report=read(run['training_ref']['path']);run['training']=report
        lane['prior']={'shared-'+str(run['seed']):dict(training=old['training'])}
        detail=action.training(run,lane) if recurrent else dict(exact_prior_report_replay=True)
        original=inherited(A/'training-r1/results'/old['arm']/'initial-state.json');states={}
        for role in ('initial','selected','last-attempt'):
            states[role]=state_check(root/label/(role+'-state.json'),report,role,original,lane,recurrent,label+'/'+role)
        check(run['trainable_parameter_count']==states['last-attempt']['_audited_trainable_count']
            ==old['trainable_parameter_count']+(2048 if recurrent else 0),'state/exact_parameter_delta/'+label)
        check(all(state['architecture']==states['initial']['architecture'] for state in states.values()),'state/architecture_constant/'+label)
        parity=read(root/label/'initial-parity.json')
        check(parity==run['initial_parity'] and parity['complete'] and parity['predictions']==old['initial_parity']['predictions']
            and parity['parameter_delta']==(2048 if recurrent else 0),'initial/all96_full_greedy_parity/'+label)
        panels={};metrics={}
        for role in ('selected','last-attempt'):
            panels[role]={};metrics[role]={}
            expected_controls={name for name,_,_ in CONTROLS}|({'recurrent-residual-off'} if recurrent else set())
            check(set(run['postfit'][role])==expected_controls,'postfit/exact_control_inventory/'+label+'/'+role)
            for name,split,kind in CONTROLS+([('recurrent-residual-off','validation','conditioned')] if recurrent else []):
                entry=run['postfit'][role][name];pin(entry['path'],entry['sha256']);panel=read(entry['path']);panels[role][name]=panel
                check(entry['numerical']==panel['report'] and entry['fidelity']=={k:v for k,v in panel['source_fidelity'].items() if k!='rows'},'postfit/compact_index_binding/'+label+'/'+role+'/'+name)
                if recurrent:
                    viewed=panel
                    if name=='recurrent-residual-off':
                        check(panel['execution']['kind']=='recurrent_residual_off' and panel['execution']['recurrent_residual_disabled'] is True,'postfit/explicit_residual_ablation/'+label+'/'+role)
                        viewed=deepcopy(panel);viewed['execution']['kind']='conditioned'
                    metrics[role][name]=clause.panel_check(viewed,split,kind,states[role],lane,label+'/'+role+'/'+name,cache)
                    metrics[role][name]['count_readouts']=count_readouts(panel,states[role],lane,split,kind,label+'/'+role+'/'+name)
                    metrics[role][name]['recurrent_readouts']=recurrent_readouts(panel,states[role],lane,split,kind,
                        name=='recurrent-residual-off',label+'/'+role+'/'+name)
                else:
                    metrics[role][name]=dict(exact=panel['source_fidelity']['metrics']['ordered_exact'],
                        syntax=panel['source_fidelity']['metrics']['syntax_valid'],eos=panel['source_fidelity']['metrics']['eos_count'])
                if name=='validation':
                    target=report['selected'] if role=='selected' else report['last_complete_attempt']
                    check(panel['report']['metrics']==target['numerical'],'postfit/selection_metric_binding/'+label+'/'+role)
        if not recurrent:baseline_replay(run,report,states,panels,old,label)
        else:check(run['baseline_replay'] is None,'baseline/no_candidate_replay_claim/'+label)
        analysis[label]=dict(selected_epoch=report['selected_epoch'],training=detail,controls=metrics,
            fit_elapsed_seconds=run['training_call_elapsed_seconds'],trainable_parameter_count=run['trainable_parameter_count'])
    resource_path=root.parent/'resources-final.json';resource=None
    check(resource_path.is_file(),'resources/final_accounting_receipt_exists')
    if resource_path.is_file():
        resource=read(resource_path);record=resource['record']
        check(resource['status']==record['status']=='released' and record['artifacts_durable_asserted'] is True
            and record['attempt_exceeded_reservation'] is False and record['storage_bytes']==2000000000
            and record['memory_mb']==4096 and record['cpu_slots']==1
            and record['final_accounting']['limit_bytes']==140000000000,'resources/released_with_unchanged_admission_and_cap')
    if resource is not None and resource.get('recovered_after_guardian_failure') is True:
        binding=resource['reconciliation_receipt'];recovery=read(pin(binding['path'],binding['sha256']))
        check(Path(binding['path']).resolve()==R/'resource-reconciliation.json','recovery/local_persisted_receipt')
        helper=pin(R/'reconcile_completed_resources.py','0f57ae4125f5321683d8c395c2dbb7e47a3be573e5d5bf618a924d4f3e28cc7c')
        failure=pin(R/'training-r1-guardian.log',recovery['original_guardian_log_sha256'])
        child=read(root.parent/'child-exit.json');read(root.parent/'child-identity.json')
        check(recovery['schema']=='completed-resource-receipt-reconciliation/v1' and recovery['complete']
            and recovery['script_sha256']==sha(helper) and recovery['release_record']==record
            and recovery['guardian_returncode']==resource['guardian_returncode']==1
            and recovery['training_child_returncode']==child['returncode']==0 and child['leader_reaped'],
            'recovery/exact_completed_release_and_original_failure')
        check(all(recovery[key] is True for key in ('scheduler_lease_absent','owner_exited','child_group_dead','attempt_inode_verified',
                'failure_time_scheduler_configuration_not_captured','configuration_change_actor_unknown','scheduler_release_actor_unknown'))
            and all(recovery[key] is False for key in ('scheduler_release_performed','scheduler_reset_performed','shared_state_mutated',
                'foreign_claims_modified','guardian_success_claimed','model_rerun')),
            'recovery/observational_no_state_mutation_or_success_fabrication')
        check(recovery['observed_completed_attempt_bytes']==record['final_attempt_bytes']==record['final_total_charged_bytes']
            and 'ResourceConfigurationError' in failure.read_text()
            and resource['resource_lease']['released'] is True
            and resource['resource_lease']['release_actor_unknown'] is True
            and resource['resource_lease']['release_performed_by_reconciliation'] is False,
            'recovery/retained_accounting_and_observed_lease_absence')
    before=read(R/'before.json')['checkpoint'];pin(before['path'],before['sha256'])
    check(Path(before['path']).stat().st_size==before['bytes'],'protection/original_checkpoint_size')
    return dict(runs=analysis,states=36,panels=204,distinct_candidate_fidelity_panels=len(cache),resources=resource,
        limits=['Saved-data arithmetic only; no full recurrent/optimizer execution replay.',
            'Potential recurrent residual captures are source slot readouts, not visited-prefix traces.',
            'Previously exposed development cohort; no fresh holdout, global convergence, Lake admission or promotion.'])


def main():
    parser=argparse.ArgumentParser()
    for name in ('source','manifest','plan','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--results',type=Path);args=parser.parse_args()
    for key in vars(args):
        if getattr(args,key) is not None:setattr(args,key,getattr(args,key).resolve())
    ctx=common(args)
    tests=ET.parse(pin(R/'tests-scoped.xml'));suites=list(tests.iter('testsuite'))
    check(suites and all(int(s.get(k,0))==0 for s in suites for k in ('errors','failures','skipped')),'tests/scoped_suite_passed')
    provenance=read(R/'test-import-provenance-scoped.json')
    check(provenance['pytest_returncode']==0 and provenance['test_source_frozen'] is True,'tests/recorded_frozen_imports')
    dependency=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
    for name,entry in provenance['modules'].items():
        path=pin(entry['path'],entry['sha256'])
        check(path.is_relative_to(args.source) or path.is_relative_to(dependency),'tests/no_live_or_HACC_import/'+name)
    check(all(Path(path).is_relative_to(dependency) for path in provenance['tree_pin'].values()),'tests/authenticated_logic_tree')
    analysis=results(args,ctx) if args.results else dict(dimensions=[8,384,768],source_inputs_reused_from_authenticated_prior=True)
    analysis['tests']=dict(fresh_scoped_count=sum(int(s.get('tests',0)) for s in suites),
        historical_scheduler_tests_rerun=False,historical_unused_fixture_exclusions=16)
    check('torch' not in sys.modules and 'transformers' not in sys.modules,'audit/no_model_imports');pin(__file__)
    value=dict(schema='ordered-clause-recurrent-independent-audit/v1',phase='results' if args.results else 'readiness',
        passed=not findings,complete=not findings,checks=checks,finding_count=len(findings),findings=findings,artifacts=artifacts,
        source_path=str(Path(__file__).resolve()),source_sha256=sha(__file__),manifest_path=str(args.manifest),manifest_sha256=sha(args.manifest),
        plan_path=str(args.plan),plan_sha256=sha(args.plan),analysis=analysis,created_at_utc=datetime.now(timezone.utc).isoformat(),
        models_executed=False,training_executed=False,encoder_executed=False,qualified=False,admitted=False,lake_executed=False,fresh_holdout=False)
    if not args.results:value['pre_execution']=not bool(list(R.glob('training-*/results')))
    args.output.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(passed=not findings,checks=checks,findings=findings,output=str(args.output))))
    if findings:raise SystemExit(1)


if __name__=='__main__':main()
