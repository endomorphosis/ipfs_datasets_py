"""Append observed recurrent-clause results, including the failed cleanup."""
from pathlib import Path
import hashlib,json,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
path=P/'docs/autoencoders/decoder_length_distillation.md';base=json.loads((R/'base.json').read_bytes())['base']
old=path.read_bytes();assert old==subprocess.check_output(['git','show',base+':'+str(path.relative_to(P))],cwd=P)
o=json.loads((R/'outcomes.json').read_bytes());audit=json.loads((R/'independent-audit.json').read_bytes())
assert o['passed'] and audit['passed'] and not audit['findings']
rows=[]
for d in (8,384,768):
 for seed in (1729,2718):
  for arm in ('action-contrastive','recurrent-clause'):
   v=o['runs'][f'{d}-{arm}-{seed}'];p=v['controls']['last-attempt']['validation']
   rows.append(f"| {d} | {seed} | {arm} | {p['numerical_seconds_per48']:.6f} | {p['numerical_seconds_per_span']:.6f} | {p['whole_panel_seconds_per_span']:.6f} | {v['training_rows_presented_per_fit_second']:.2f} |")
text='''

## Ordered clause conditioning in the recurrent decoder (2026-10-03)

This twelve-fit experiment does **not** justify replacing the current decoder recipe. Aggregate exact reconstruction across the six width/seed pairs is unchanged at 58/288 exposed validation spans. The best 768D seed improves by one exact span overall but loses two exact eight-clause spans. The optional implementation and every result are retained for further objective experiments; no candidate is promoted.

The saved-data diagnosis separated source-count prediction from actual stopping. The prior 384D candidates closed early on all 36 multi-clause validation rows despite correctly predicting the count for 20–21 of those rows. In the strongest prior 768D seed, 17 of 19 failed spans had a wrong generated length or unfinished output. Count classes 9–32 had identical learned logits, leaving their prior-relative closing correction zero. These observations did not capture inherited recurrent boundary logits and do not establish which logit caused each decision.

### What changes, and what stays fixed

`ordered_clause_recurrent_decoder_experiment.bind_ordered_clause_recurrent_model(action_model, codec=codec)` copies the validated factorized model and adds one bias-free, zero-initialized `Linear(128, 16)` layer: 2,048 parameters at every native input width. It concatenates the existing 64D action and 64D non-action clause features, then adds the selected clause's projected feature to the token embedding and existing paragraph residual before the GRU. The consumed-prefix lexical state selects the clause **after** each consumed token. Closing a complete rule advances to the next clause. Exhausted, padded, invalid and post-array-close routes contribute zero.

Source segmentation availability is an explicit inference input. This authored fixture has one source clause per reference rule; the experiment does not establish segmentation quality on statutes. It uses no reference count in generation, no vocabulary mask, and no forced closure/EOS. All 32 output tokens remain available. The original paragraph conditioning, scalar residuals and count-prior correction remain intact. Full-prefix and greedy initial predictions match the predecessor exactly. The historical 8D linguistic teacher and its protected checkpoint remain unchanged: these are learned-formula sidecars at native input widths 8/384/768.

The data, losses, training exposure, optimizer and selection criteria are unchanged: 48 training and 48 repeatedly exposed validation paragraphs; lengths 1/2/4/8 with 12 of each; 180 rule occurrences in each split; 113 unique training clauses and 54 validation clauses. Validation actor/action pairs are absent from training, but these rows have been examined in previous experiments and are not a fresh holdout. Each fit starts from its original initializer and executes 340 AdamW updates over four cumulative 20-epoch stages, with learning rate 0.001, batch 8, 2,440 row/count presentations, 225,840 target-token presentations and 25,600 scalar labels. The action-contrastive coefficient is 0.05, its loss temperature is 0.1, and generation temperature stays 0. Encoder and decoder limits both remain 512. No encoder forwards or weight downloads occur.

### Observed reconstruction

'''+(R/'proposed-outcomes-doc.txt').read_text()+'''

### Runtime, retained artifacts and cleanup

The complete numerical API timings below include teacher-forced CE, free generation and identity-projection evaluation. The broader panel adds source-control construction and fidelity/count/scalar scoring. Both exclude serialization and the separately recorded potential recurrent-residual observations. Generated lengths differ. Training rows/s divides 2,440 presentations by the whole trainer-call wall time, including its internal validation. These shared-host observations are not an isolated speed comparison.

| Width | Seed | Arm | Numerical s/48 | Numerical s/span | Complete panel s/span | Training rows/s |
|---:|---:|---|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

The reservation was one CPU, 4 GiB RAM and 2 GB output under the unchanged 140 GB campaign cap. CUDA was disabled. The observed child RSS maximum was 1,479,499,776 bytes across 23 samples. The completed attempt occupied 619,572,063 bytes at final disk accounting. The top-level run index is 16,497 bytes; it references complete authenticated per-arm training reports and panels instead of repeating their arrays. All 36 typed initial/selected/final states and 204 evaluation panels are retained. These exports do not contain optimizer/RNG state for training resume.

The model child completed with exit 0 and was reaped; the guardian took 467.248 s through child exit, including admission, monitoring and accounting. The guardian then exited 1: disk finalization had already persisted a durable released reservation, but scheduler lease release encountered a configuration mismatch. The final error handling also encountered that mismatch, so it did not write `resources-final.json`. The original failure log is retained. The scheduler configuration later matched the adopted configuration again; the actor and exact intervening values are unknown.

`reconcile_completed_resources.py` recovered **only the missing receipt**, using the existing stable ledger and scheduler locks. It verified the original owner had exited, the recorded child group was dead, the reservation/attempt inode matched, the exact 619,572,063-byte output inventory matched the already released durable ledger row, and the run's scheduler lease and waiters were absent. It changed no shared scheduler state, capacities, leases or foreign claims and reran no model. `resources-final.json` explicitly records the original guardian exit 1 and the recovery evidence. This is a reconciled resource record, not a claim that the original guardian completed successfully.

### APIs, reproduction and remaining gap

- `logic/formalization/autoencoder/ordered_clause_recurrent_decoder_experiment.py` owns the new architecture, source-only recurrent features, strict typed/frozen restoration and the `bind_residual_off_model`/`bind_zero_condition_model` inference controls. State adds one versioned integer buffer and one trainable matrix while preserving inherited body tensor paths.
- `long_span_source_value_training.train` accepts this explicit new model with authenticated `source_contexts` and the unchanged `action_contrastive_weight=0.05` recipe. The default path, optimizer, scheduler, objective coefficients, deadlines and per-length acceptance are unchanged. Control wrappers are excluded from trainable schema admission.
- `scripts/ops/autoencoder/benchmark_ordered_clause_recurrent_training.py` owns the fixed twelve-fit comparison. It requires `--phase training --dependency-root ... --extension-root ... --manifest ... --plan ... --output ...`. Reproduce with the archived frozen sources/manifests through `run_training_reserved.py` and a fresh attempt directory. Restore typed states through the matching architecture; do not warm-start an unselected attempt and treat it as a new baseline.

The 2,314 scoped regression tests pass, including 44 new architecture tests and 44 new runner/integration tests. The known 16 setup cases for an incompatible, unused retained Legal 384 release remain outside this scope and are preserved in predecessor evidence. All six baseline training reports, tensor states and control predictions replay the preceding action-contrastive experiment exactly, excluding elapsed time. The independent saved-data audit also checks objective/exposure/selection arithmetic, source provenance, raw scalar and all 32 count logits, potential 8×16 recurrent clause residuals, and the read-only resource reconciliation. Potential slot residuals are not actual visited-prefix traces, and this audit does not independently replay every optimizer or neural autoregressive operation.

The result points toward testing boundary-specific training next. The existing generated-boundary collector samples the first and last visited boundaries; the saved diagnosis shows this would omit the first wrong close/continue decision in 12 of 17 erroneous rows of the prior best 768D validation arm. A future objective should retain full-vocabulary scoring, keep training labels out of generation, support the authenticated clause contexts, and test whether those actual errors improve. This experiment adds no such loss and claims no global convergence.

No bridge-on legal-IR evaluation, native-family qualification or Lake build was run. Bridge names are `[]`, prover evaluation is `false`, metric disk cache is disabled, worker count is 1, and each panel contains 48 samples. These cached-source decoder timings cannot be used as parser/compile or bridge-on timings. No admit, formalized flag, `roundtrip_ok`, fresh-holdout claim or production promotion follows. The Constitution remains unformalized. Full evidence is published under `docs/implementation/reports/evidence/decoder-boundary-reconstruction-20261003/`: `results.json`, `manifest.json`, and ordered `evidence.tar.xz.part-*` chunks. Concatenate the parts in manifest order and verify both chunk and logical-archive hashes before extraction; predecessor artifacts have explicit immutable Git references.
'''
old_text=old.decode().replace('decoder-action-binding-20261003/{results.json,manifest.json,evidence.tar.xz}', 'decoder-action-binding-20261003/{results.json,manifest.json,evidence.tar.xz.part-*}')
path.write_text(old_text+text)
(R/'documentation-edit.json').write_text(json.dumps(dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),start_line=len(old.decode().splitlines())+2,previous_sha256=hashlib.sha256(old).hexdigest(),appended_lines=len(text.splitlines())),indent=2)+'\n')
print(json.dumps(dict(path=str(path),lines=len(path.read_text().splitlines()),sha256=hashlib.sha256(path.read_bytes()).hexdigest())))
