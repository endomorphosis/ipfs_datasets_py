"""Independent saved-evidence action-binding audit. Standard library only.

No encoder, model, optimizer, proof or Lake execution. Authenticated prior
arithmetic checks context controls, scalar logits, emitted formulas and strict
selection. New checks cover factorized action heads, training-only pair labels,
contrastive arithmetic and exact original-clause baseline replay.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter, defaultdict
from copy import deepcopy
import argparse, ast, hashlib, importlib.util, json, math, sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;P=R.parents[2]
O=P/'workspace/test-logs/decoder-native-dimensions-20261003'
checks=0;findings=[];artifacts={}

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def raw(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def digest(v):return hashlib.sha256(raw(v)).hexdigest()
def check(v,label,detail=None):
    global checks
    checks+=1
    if not v:findings.append(dict(label=label,detail=detail))
def pin(path,wanted=None):
    path=Path(path).resolve();h=sha(path)
    if wanted is not None:check(h==wanted,'pin/'+str(path))
    artifacts[str(path)]=dict(sha256=h,bytes=path.stat().st_size)
    return path
def read(path):return json.loads(pin(path).read_bytes())
PINS={'native_audit_arithmetic.py':'7e707e4e227316f6d83bf14eec0cd1d009bc91cb4ea8e1b18bb81092f7d05dc9',
'clause_audit_arithmetic.py':'ec3ac052e7dbc326d9385d80a1ddc9a63511ecbc5ae65f26dd65364614275094',
'prior_training_arithmetic.py':'459eed5588f46b88550ae8568e756c11160303c1e74ee736d36e56594c6d793c',
'audit_leaf_arithmetic.py':'ea440ebb1fc7b978da165329c864a69631be88048f2b694690522674cdc98c47'}
for name,h in PINS.items():pin(R/name,h)
spec=importlib.util.spec_from_file_location('_saved_native_arithmetic',R/'native_audit_arithmetic.py')
native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
clause=native.clause;prior=native.prior;leaf=prior.leaf
for module in (native,clause,prior,leaf):module.check=check;module.read=read
native.pin=pin
close=prior.close;FIELDS=native.FIELDS;CONTROLS=native.CONTROLS
ARMS=[dict(name=n,head_kind='clauses',factorized=f,action_contrastive_weight=w,
    order_augmentation=False,generated_boundary_weight=0.) for n,f,w in
    [('clauses',False,0.),('action-head',True,0.),('action-contrastive',True,.05)]]


def source_selection_guards(source,original_manifest):
    auto='ipfs_datasets_py/logic/formalization/autoencoder/'
    for name in ('decoder_distillation_experiment','decoder_source_fidelity','long_span_count_exposure_training','clause_source_context','clause_source_controls'):
        rel=auto+name+'.py'
        check(sha(source/rel)==original_manifest['extensions'][rel],'source/unchanged_core_and_gates/'+name)
    old=O/'experiment-source'/auto/'long_span_source_value_training.py'
    new=source/auto/'long_span_source_value_training.py';pin(old)
    def tail(path):
        tree=ast.parse(path.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='train')
        for node in ast.walk(fn):
            if isinstance(node,ast.For) and isinstance(node.target,ast.Name) and node.target.id=='stage_epoch':
                body=node.body;i=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='(observed, accepted, reasons)')
                return ast.dump(ast.Module(body=body[i:],type_ignores=[]))
        raise ValueError('missing complete epoch selection block')
    check(tail(old)==tail(new),'source/entire_epoch_validation_selection_scheduler_path_identical')


def common(args):
    m=read(args.manifest);plan=read(args.plan)
    check(sha(args.plan)==m['plan_sha256'] and plan['input_sha256']==m['inputs'],'pins/plan_inputs')
    for path,h in m['inputs'].items():pin(path,h)
    for rel,h in m['extensions'].items():pin(args.source/rel,h)
    parent=read(m['parent_manifest']);grandparent=read(parent['parent_manifest'])
    original_manifest=read(m['original_native_manifest']);source_selection_guards(args.source,original_manifest)
    check(sha(m['parent_plan'])==parent['plan_sha256'],'pins/unchanged_native_parent_plan')
    public_root=P/'docs/implementation/reports/evidence/decoder-native-dimensions-20261003'
    public_results=read(public_root/'results.json');public_manifest=read(public_root/'manifest.json')
    check(sha(O/'independent-audit.json')==public_results['independent_audit_sha256'],'prior/published_audit_hash')
    old_audit=read(O/'independent-audit.json')
    check(old_audit['passed'] and old_audit['finding_count']==0,'prior/authenticated_completed_native_audit')
    for name,h in PINS.items():
        original=O/('independent_audit.py' if name=='native_audit_arithmetic.py' else name)
        check(old_audit['artifacts'][str(original)]['sha256']==h,'prior/exact_authenticated_arithmetic/'+name)
    fixed=dict(schema='action-binding-source-training-plan/v1',dimensions=[8,384,768],seed_order=[1729,2718],
        fit_count=18,original_training_rows=48,exposed_validation_rows=48,fixed_encoder_context_tokens=512,
        fixed_decoder_output_limit=512,temperature=0,action_contrastive_temperature=.1,
        contrastive_positive_policy='same_action_different_actor',contrastive_negative_policy='different_action',
        contrastive_unique_source_clauses=True,fresh_initialization=True,selection_unchanged=True,
        validation_pairs_added_to_training=False,historical_linguistic_teacher_modified=False,
        identity_projection_frozen=True,identity_mse_is_not_learned_reconstruction=True,
        learning_rate=.001,batch_size=8,epochs_per_source_stage=20,max_seconds_per_arm=180,
        expected_optimizer_steps_per_arm=340,expected_training_token_presentations_per_arm=225840,
        expected_row_presentations_per_arm=2440,expected_count_presentations_per_arm=2440,
        expected_source_value_presentations_per_arm=25600,cardinality_weight=.25,source_value_weight=.25,
        baseline_replay_required=True,full_vocabulary_retained=True,syntax_forced=False,closure_forced=False,
        production_promotion_allowed=False,generation_reference_count_access=False,no_downloads=True,
        encoder_executed_during_training=False)
    for k,v in fixed.items():check(plan.get(k)==v,'plan/'+k)
    check(plan['arms']==ARMS,'plan/exact_three_arms')
    prepared=native.input_preparation(parent,grandparent,args.source)
    donor=read(grandparent['donor']);oldshared=read(grandparent['shared_summary'])
    prep=read(grandparent['order_preparation']);byid={r['id']:r for r in prep['rows']}
    original={r['id']:r for r in prepared['corpus']['train']};variants={k:[] for k in original}
    for row in prep['rows']:variants[row['order_diagnostic']['parent_id']].append(row['id'])
    baseline_path=Path(m['baseline_summary']).resolve()
    baseline_member=public_manifest['original_artifact_archive_paths'][str(baseline_path)]
    check(sha(baseline_path)==public_manifest['members'][baseline_member]['sha256'],'prior/published_baseline_summary_hash')
    baseline=read(baseline_path)
    check(baseline['complete'] and len(baseline['runs'])==12,'prior/complete_baseline_comparison')
    lookup={};coverage={}
    for split in ('train','validation'):
        actions=Counter();pairs=Counter();sources={}
        for row in prepared['corpus'][split]:
            pieces=row['source_text'].split('\n\n');rules=row['target']['rules']
            check(len(pieces)==len(rules)==row['clause_count'],'labels/source_clause_order/'+row['id'])
            for piece,rule,component in zip(pieces,rules,row['components']):
                h=clause.textsha(piece)
                check(h==component['source_sha256'] and component['logical_slot']==[rule['actor'],rule['action'],rule['object']],
                    'labels/authored_component_mapping/'+h)
                item=dict(actor=rule['actor'],action=rule['action'],source_text=piece)
                check(h not in sources or sources[h]==item,'labels/same_source_same_pair/'+h)
                sources[h]=item;actions[rule['action']]+=1;pairs[(rule['actor'],rule['action'])]+=1
        lookup[split]=sources;coverage[split]=dict(actions=dict(actions),pairs=[dict(actor=a,action=b,count=n) for (a,b),n in sorted(pairs.items())],unique_sources=len(sources))
    trainpairs={(r['actor'],r['action']) for r in coverage['train']['pairs']};valpairs={(r['actor'],r['action']) for r in coverage['validation']['pairs']}
    check(len(trainpairs)==15 and len(valpairs)==5 and not trainpairs&valpairs and set(coverage['train']['actions'])==set(coverage['validation']['actions']),
        'labels/all_validation_pairs_novel_all_actions_seen')
    check(not set(lookup['train'])&set(lookup['validation']),'labels/no_clause_source_split_overlap')
    return dict(**prepared,manifest=m,plan=plan,parent=parent,donor=donor,original=original,prepared=byid,
        variants=variants,prior={r['arm']:r for r in oldshared['runs']},baseline={r['arm']:r for r in baseline['runs']},
        lookup=lookup,coverage=coverage)


HEAD_CACHE={}
old_head_scores=native.head_scores

def head_scores(state,ctx,vector,descriptor_value,zero=False):
    if not state['recipe']['factorized']:return old_head_scores(state,ctx,vector,descriptor_value,zero)
    v=prior.canonical(state);size=len(ctx['donor']['codec']['target_vocabulary']);result=[]
    for slot in range(8):
        if not zero and slot>=len(descriptor_value['segments']):result.append([[0.]*size for _ in FIELDS]);continue
        source=None if zero else descriptor_value['segments'][slot]['vector'];key=(state['tensor_sha256'],digest(source))
        if key not in HEAD_CACHE:
            x=[0.]*ctx['dimension'] if zero else [(a-b)/v['clause_source_scale'] for a,b in zip(native.projected(source,state,ctx),v['clause_source_mean'])]
            scores={}
            for head in ('non_action_head','action_head'):
                h=[math.tanh(n) for n in clause.affine(x,v[head+'.source_projection.weight'],v[head+'.source_projection.bias'])]
                scores[head]=clause.affine(h,v[head+'.field_readout.weight'],v[head+'.field_readout.bias'])
            other=scores['non_action_head'];HEAD_CACHE[key]=[other[:size],scores['action_head'],other[size:2*size],other[2*size:]]
        result.append(HEAD_CACHE[key])
    return result
clause.head_scores=head_scores


def state_check(path,report,role,initial,baseline_initial,ctx,label):
    state=read(path);prior.authority(state,label);v=prior.canonical(state);base=prior.canonical(baseline_initial)
    check(state['schema']=='private-native-dimension-source-state/v1' and state['dimension']==ctx['dimension'] and state['role']==role,
        'state/closed_identity/'+label)
    check(state['codec']==ctx['donor']['codec'] and state['input_transform']==ctx['donor']['input_transform']
        and state['initializer_receipt']==ctx['preparation_saved']['initializer'],'state/source_initialization_binding/'+label)
    check(state['weights_sha256']==digest(state['model_state']) and state['tensor_sha256']==clause.tensor_digest(state['model_state']),
        'state/typed_tensor_hash/'+label)
    wanted=report['initial_weights_sha256'] if role=='initial' else report['selected_weights_sha256'] if role=='selected' else report['last_complete_attempt_weights_sha256']
    check(state['tensor_sha256']==wanted,'state/report_binding/'+label)
    factorized=state['recipe']['factorized'];oldhead={k for k in base if k.startswith('clause_head.')}
    expected=set(base)
    if factorized:expected=(expected-oldhead)|{h+'.'+s for h in ('non_action_head','action_head') for s in ('source_projection.weight','source_projection.bias','field_readout.weight','field_readout.bias')}
    check(set(v)==expected,'state/exact_no_dead_head_parameters/'+label)
    vocab=len(ctx['donor']['codec']['target_vocabulary']);dim=ctx['dimension']
    if factorized:
        for head,fields in [('non_action_head',3),('action_head',1)]:
            shapes={'source_projection.weight':[64,dim],'source_projection.bias':[64],'field_readout.weight':[fields*vocab,64],'field_readout.bias':[fields*vocab]}
            check(all(leaf.shape(v[head+'.'+k])==s for k,s in shapes.items()),'state/factorized_geometry/'+label+'/'+head)
        check(state['architecture']['schema']=='action-factorized-clause-source-decoder-development/v1','state/explicit_candidate_architecture/'+label)
    else:check(state['architecture']==baseline_initial['architecture'],'state/exact_baseline_architecture/'+label)
    frozen=native.PROJECTION|{'source_mean','source_scale','count_prior_logits','head_initialization_seed','clause_source_mean','clause_source_scale'}
    check(all(v[k]==base[k] for k in frozen),'state/frozen_source_projection_statistics_prior/'+label)
    if role=='initial':
        check(all(v[k]==value for k,value in base.items() if k not in oldhead),'initial/all_inherited_tensors_exact/'+label)
        if factorized:
            for h in ('non_action_head','action_head'):
                for s in ('weight','bias'):check(v[h+'.source_projection.'+s]==base['clause_head.source_projection.'+s],'initial/projection_copy/'+label+'/'+h+'/'+s)
            for s in ('weight','bias'):
                readout=base['clause_head.field_readout.'+s]
                check(v['action_head.field_readout.'+s]==readout[vocab:2*vocab]
                    and v['non_action_head.field_readout.'+s]==readout[:vocab]+readout[2*vocab:], 'initial/readout_exact_split/'+label+'/'+s)
        else:check(v==base,'initial/baseline_all_tensors_exact/'+label)
    else:check(state['architecture']==initial['architecture'],'state/architecture_fixed_after_training/'+label)
    count=sum(math.prod(leaf.shape(x)) for k,x in v.items() if k not in frozen)
    basecount=sum(math.prod(leaf.shape(x)) for k,x in base.items() if k not in frozen)
    check(count-basecount==(64*(dim+1) if factorized else 0),'state/exact_parameter_delta/'+label)
    state['_audited_trainable_count']=count
    return state


def action_metrics(panel,ctx,split,label):
    rows={r['id']:r for r in ctx['corpus'][split]};scores={r['id']:r for r in panel['source_values']['predictions']}
    vocab=ctx['donor']['codec']['target_vocabulary'];trainpairs={(r['actor'],r['action']) for r in ctx['coverage']['train']['pairs']}
    total=Counter();confusion=Counter();pairs=Counter();by_length=defaultdict(Counter);ce=0.
    for observed in panel['source_fidelity']['rows']:
        ref=rows[observed['id']];generated=observed['generated_ir'];actual=generated.get('rules',[]) if isinstance(generated,dict) else []
        raw=scores[observed['id']]
        for slot,r in enumerate(ref['target']['rules']):
            logits=raw['raw_logits'][slot];pred=[]
            for f in (0,1):
                token=max(range(len(vocab)),key=logits[f].__getitem__)
                try:value=json.loads(vocab[token])
                except ValueError:value=None
                pred.append(value)
            target=vocab.index(json.dumps(r['action']));ce+=prior.lse(logits[1])-logits[1][target]
            out=actual[slot] if slot<len(actual) and isinstance(actual[slot],dict) else {}
            c=dict(total=1,raw_action_correct=int(pred[1]==r['action']),generated_action_correct=int(out.get('action')==r['action']),
                raw_pair_correct=int(pred==[r['actor'],r['action']]),generated_pair_correct=int(all(out.get(f)==r[f] for f in ('actor','action'))),
                novel_training_pair=int((r['actor'],r['action']) not in trainpairs),unemitted_or_unscorable=int(not out))
            total.update(c);by_length[str(len(ref['target']['rules']))].update(c)
            confusion[(r['action'],str(pred[1]),str(out.get('action','<missing>')))]+=1
            pairs[(r['actor'],r['action'])]+=1
    check(total['total']==180 and total['raw_action_correct']==panel['source_values']['by_field']['action']['correct']
        and total['generated_action_correct']==panel['source_fidelity']['by_facet']['action']['correct'], 'actions/exact_saved_totals/'+label)
    return dict(counts=dict(total),raw_action_mean_CE=ce/180,by_length={k:dict(v) for k,v in by_length.items()},
        confusion=[dict(expected=a,raw=b,generated=c,count=n) for (a,b,c),n in sorted(confusion.items())])


# Contrastive receipt arithmetic is defined below once the closed producer
# schema is finalized. No training implementation will be imported here.
def contrastive_inventory(report,ctx,label):
    inv=report['action_contrastive_inventory'];vocab=ctx['donor']['codec']['target_vocabulary'];wanted={}
    for row in ctx['rows']['train']:
        clauses=[]
        for segment in ctx['contexts']['train'][row['id']]['segments']:
            ref=ctx['lookup']['train'][segment['source_sha256']]
            clauses.append(dict(source_sha256=segment['source_sha256'],actor_token_id=vocab.index(json.dumps(ref['actor'])),action_token_id=vocab.index(json.dumps(ref['action']))))
        wanted[row['id']]=dict(source_sha256=clause.textsha(row['source_text']),input_sha256=digest(row['input']),clauses=clauses)
    check(inv['schema']=='training-action-contrastive/v1' and inv['inventory_sha256']==digest({k:v for k,v in inv.items() if k!='inventory_sha256'}), 'contrastive/inventory_hash/'+label)
    check(inv['rows']==wanted and inv['training_rows_sha256']==digest(ctx['rows']['train'])
        and inv['training_references_sha256']==digest([{k:r[k] for k in ('id','source_text','source_sha256','target','clause_count')} for r in ctx['corpus']['train']]) and inv['training_contexts_sha256']==digest(ctx['contexts']['train'])
        and inv['codec_sha256']==digest(ctx['donor']['codec']) and inv['dimension']==ctx['dimension'], 'contrastive/exact_training_only_inventory/'+label)
    check(inv['unique_training_clauses']==113 and inv['training_clause_occurrences']==180 and inv['validation_rows_used'] is False
        and inv['reference_documents_passed_to_model'] is False,'contrastive/inventory_scope/'+label)
    return inv


def contrastive_receipt(receipt,ids,inventory,label):
    unique=[];indices={};occurrences=0
    for key in ids:
        for slot,entry in enumerate(inventory['rows'][key]['clauses']):
            occurrences+=1;source=entry['source_sha256'];site=dict(row_id=key,slot=slot)
            if source in indices:unique[indices[source]]['occurrences'].append(site)
            else:indices[source]=len(unique);unique.append(dict(entry,first_site=site,occurrences=[site]))
    pairs=[]
    for i,a in enumerate(unique):
        pos=[j for j,b in enumerate(unique) if j!=i and b['action_token_id']==a['action_token_id'] and b['actor_token_id']!=a['actor_token_id']]
        neg=[j for j,b in enumerate(unique) if j!=i and b['action_token_id']!=a['action_token_id']]
        pairs.append(dict(anchor=i,positive_indices=pos,negative_indices=neg,eligible=bool(pos and neg)))
    active=[p for p in pairs if p['eligible']]
    check(receipt['schema']=='training-action-contrastive/v1' and receipt['inventory_sha256']==inventory['inventory_sha256']
        and receipt['row_ids']==ids and receipt['unique_clauses']==unique,'contrastive/exact_source_dedup_first_occurrence/'+label)
    check([{k:v for k,v in p.items() if k!='loss'} for p in receipt['pair_sets']]==pairs,'contrastive/authored_pair_policy/'+label)
    check(receipt['clause_occurrences']==occurrences and receipt['unique_clause_count']==len(unique)
        and receipt['duplicate_clause_occurrences']==occurrences-len(unique) and receipt['active_anchor_count']==len(active)
        and receipt['directed_positive_pairs']==sum(len(p['positive_indices']) for p in active)
        and receipt['directed_negative_pairs']==sum(len(p['negative_indices']) for p in active),'contrastive/pair_exposure_counts/'+label)
    check(receipt['temperature']==.1 and receipt['normalization_epsilon']==1e-12 and receipt['feature_dimension']==64
        and receipt['temperature_scope']=='contrastive_loss_only_not_generation' and receipt['weight']==.05
        and receipt['aggregation']=='mean_positive_negative_log_probability_then_mean_active_anchor'
        and receipt['reference_documents_passed_to_model'] is False and receipt['validation_rows_used'] is False
        and receipt['used_for_selection'] is False,'contrastive/fixed_loss_and_authority_scope/'+label)
    totals=dict(active_updates=int(bool(active)),unique_clauses=len(unique),clause_occurrences=occurrences,
        active_anchors=len(active),positive_pairs=sum(len(p['positive_indices']) for p in active),negative_pairs=sum(len(p['negative_indices']) for p in active))
    if not active:
        check(receipt['feature_forward_executed'] is False and all(receipt[k] is None for k in ('loss','normalized_features','unnormalized_feature_norms','weighted_feature_gradient_norm')),'contrastive/no_anchor_no_feature_graph/'+label)
        return totals,0.
    z=receipt['normalized_features'];norms=receipt['unnormalized_feature_norms']
    check(receipt['feature_forward_executed'] is True and len(z)==len(norms)==len(unique)
        and all(len(v)==64 and all(math.isfinite(x) for x in v) for v in z)
        and all(math.isfinite(n) and n>=0 for n in norms),'contrastive/finite_saved_source_features/'+label)
    check(all(close(math.fsum(x*x for x in row),1. if n>=1e-12 else (n/1e-12)**2,5e-6) for row,n in zip(z,norms)), 'contrastive/normalization_norms/'+label)
    losses=[];grads=[[0.]*64 for _ in z]
    for pair in active:
        i=pair['anchor'];pos=pair['positive_indices'];js=pos+pair['negative_indices'];scores=[math.fsum(a*b for a,b in zip(z[i],z[j]))/.1 for j in js]
        normalizer=prior.lse(scores);loss=normalizer-math.fsum(scores[:len(pos)])/len(pos);losses.append(loss)
        check(close(loss,receipt['pair_sets'][i]['loss'],5e-5),'contrastive/independent_per_anchor_CE/'+label+'/'+str(i))
        for k,j in enumerate(js):
            coefficient=(math.exp(scores[k]-normalizer)-(1/len(pos) if k<len(pos) else 0.))/len(active)/.1
            for axis in range(64):grads[i][axis]+=coefficient*z[j][axis];grads[j][axis]+=coefficient*z[i][axis]
    squared=0.
    for g,q,n in zip(grads,z,norms):
        dot=math.fsum(a*b for a,b in zip(g,q))
        squared+=math.fsum(((a-dot*b)/n if n>=1e-12 else a/1e-12)**2 for a,b in zip(g,q))
    gradient=.05*math.sqrt(squared);loss=math.fsum(losses)/len(losses)
    check(close(loss,receipt['loss'],5e-5),'contrastive/independent_mean_CE/'+label)
    check(receipt['weighted_feature_gradient_norm_scope']=='unique_raw_action_features_contrastive_branch_only_before_parameter_clipping'
        and close(gradient,receipt['weighted_feature_gradient_norm'],2e-4),'contrastive/independent_analytic_feature_gradient_norm/'+label)
    totals['loss_sum']=loss;totals['weighted_feature_gradient_norm_sum']=gradient
    return totals,loss


def training(run,ctx):
    report=run['training'];label=run['arm'];weight=run['recipe']['action_contrastive_weight'];clean=deepcopy(run);totals=Counter()
    if weight:
        inv=contrastive_inventory(report,ctx,label)
        check(report['action_contrastive_weight']==.05 and report['action_contrastive_temperature']==.1
            and report['action_contrastive_used_for_selection'] is False,'contrastive/report_scope/'+label)
        for update,copy in zip(report['committed_updates'],clean['training']['committed_updates']):
            values,loss=contrastive_receipt(update['action_contrastive'],update['decoder_row_ids'],inv,label+'/'+str(update['optimizer_step']));totals.update(values)
            copy['objective']-=weight*loss
        check(report['action_contrastive_active_updates']==totals['active_updates']
            and report['action_contrastive_skipped_updates']==340-totals['active_updates'],'contrastive/reported_active_updates/'+label)
    else:
        check(not any(k.startswith('action_contrastive') for k in report)
            and all('action_contrastive' not in u for u in report['committed_updates']), 'contrastive/disabled_exact_no_graph_report/'+label)
    inherited=prior.training(clean,ctx)
    inherited['contrastive']=dict(totals)
    check(all(u['raw_reconstruction_mse']==0 for u in report['committed_updates']), 'training/identity_MSE_not_learned/'+label)
    return inherited


def baseline_replay(run,states,panels,ctx,label):
    old=ctx['baseline'][str(run['dimension'])+'-clauses-'+str(run['seed'])];a=run['training'];b=old['training']
    check(set(a)==set(b),'baseline/report_inventory/'+label)
    for key in set(a)|set(b):
        if key!='elapsed_seconds':check(a.get(key)==b.get(key),'baseline/exact_training_field/'+label+'/'+key)
    for role,state in states.items():
        original=read(O/'training-r1/results'/old['arm']/(role+'-state.json'))
        check(state['tensor_sha256']==original['tensor_sha256'] and state['model_state']==original['model_state'], 'baseline/exact_state/'+label+'/'+role)
    for role in ('selected','last-attempt'):
        for name,_,_ in CONTROLS:
            expected=old['postfit'][role][name]
            check(panels[role][name]['predictions']==expected['predictions'],'baseline/exact_full_predictions/'+label+'/'+role+'/'+name)
    check(run['baseline_replay']['complete'] and run['baseline_replay']['timing_equality_claimed'] is False,'baseline/runner_replay_receipt/'+label)


def results(args,ctx):
    root=args.results;summary=read(root/'summary.json');prior.authority(summary,'summary')
    expected=[str(d)+'-'+r['name']+'-'+str(s) for d in (8,384,768) for s in (1729,2718) for r in ARMS]
    check(summary['schema']=='action-binding-source-training-comparison/v1' and summary['complete'] is True
        and [r['arm'] for r in summary['runs']]==expected,'results/18_complete_registered_fits')
    check(summary['dimensions_actually_trained']==[8,384,768] and summary['all_six_original_clause_baselines_replayed'] is True
        and summary['historical_linguistic_teacher_modified'] is False and summary['identity_projection_is_not_learned_reconstruction'] is True
        and summary['encoder_executed'] is False and summary['downloads_performed'] is False,'results/scope')
    for path,h in summary['source_dependencies'].items():pin(path,h)
    lanes={d:native.lane_preparation(root,ctx,d) for d in (8,384,768)};out={};cache=set()
    for run in summary['runs']:
        label=run['arm'];lane=lanes[run['dimension']];folder=root/label;report=read(folder/'training.json')
        check(report==run['training'] and run['recipe'] in ARMS and run['seed'] in (1729,2718), 'training/exact_report_recipe/'+label)
        detail=training(run,lane)
        initial_old=read(O/'training-r1/results'/(str(run['dimension'])+'-clauses-'+str(run['seed']))/'initial-state.json')
        states={};initial=None
        for role in ('initial','selected','last-attempt'):
            states[role]=state_check(folder/(role+'-state.json'),report,role,initial,initial_old,lane,label+'/'+role)
            if role=='initial':initial=states[role]
        check(run['trainable_parameter_count']==states['last-attempt']['_audited_trainable_count'],'state/reported_parameter_count/'+label)
        parity=read(folder/'initial-parity.json');old=ctx['baseline'][str(run['dimension'])+'-clauses-'+str(run['seed'])]
        check(parity==run['initial_parity'] and parity['complete'] and parity['predictions']==old['initial_parity']['predictions']
            and parity['inherited_initial_tensors_equal'] and parity['initial_scalar_logits_equal'] and parity['prior_initial_generation_equal']
            and parity['parameter_delta']==(64*(run['dimension']+1) if run['recipe']['factorized'] else 0), 'initial/full_inventory_scalar_and_greedy_parity/'+label)
        panels={};rawpanels={}
        for role in ('selected','last-attempt'):
            panels[role]={};rawpanels[role]={}
            for name,split,kind in CONTROLS:
                value=read(folder/role/('evaluation-'+name+'.json'));rawpanels[role][name]=value
                observed=clause.panel_check(value,split,kind,states[role],lane,label+'/'+role+'/'+name,cache)
                observed['actions']=action_metrics(value,lane,split,label+'/'+role+'/'+name);panels[role][name]=observed
                if name=='validation':
                    target=report['selected'] if role=='selected' else report['last_complete_attempt']
                    check(value['report']['metrics']==target['numerical'], 'postfit/unchanged_selection_metric_binding/'+label+'/'+role)
        if run['recipe']['name']=='clauses':baseline_replay(run,states,rawpanels,lane,label)
        else:check(run['baseline_replay'] is None,'baseline/no_false_candidate_replay_claim/'+label)
        out[label]=dict(dimension=run['dimension'],seed=run['seed'],recipe=run['recipe'],training=detail,controls=panels,
            selected_epoch=report['selected_epoch'],trainable_parameter_count=run['trainable_parameter_count'],
            fit_elapsed_seconds=run['training_call_elapsed_seconds'])
    return dict(runs=out,expected_states=54,expected_panels=288,distinct_fidelity_panels_audited=len(cache),coverage=ctx['coverage'],
        limits=['Saved-data arithmetic only; no full optimizer update replay or independent neural autoregressive execution.',
        'Contrastive feature gradients are independently reconstructed from saved normalized features and norms; this does not establish the intermediate model weights.',
        'The validation cohort is already exposed. No fresh holdout, global convergence, Lake admission or production promotion follows.',
        '8D uses preserved linguistic feature hashing, not the historical sparse teacher checkpoint; all three models are new private formula sidecars.',
        'Identity projection reconstruction MSE is fixed and is not learned semantic reconstruction.'])


def main():
    parser=argparse.ArgumentParser()
    for name in ('source','manifest','plan','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--results',type=Path);args=parser.parse_args()
    for key in vars(args):
        if getattr(args,key) is not None:setattr(args,key,getattr(args,key).resolve())
    ctx=common(args)
    test_path=R/'tests-scoped.xml'
    if test_path.exists():
        tree=ET.parse(pin(test_path));suites=list(tree.iter('testsuite'))
        check(bool(suites) and all(int(x.attrib.get('errors',0))==int(x.attrib.get('failures',0))==0 for x in suites),'tests/frozen_suite_clean')
    else:check(False,'tests/frozen_suite_receipt_required')
    diagnosis=read(O/'source-preparation-static-review.json')
    old_xml=ET.parse(pin(O/'tests-frozen.xml'));old_suites=list(old_xml.iter('testsuite'))
    check(diagnosis['passed'] and len(diagnosis['fixture_diagnosis']['failed_nodes'])==16
        and sum(int(x.attrib.get('errors',0)) for x in old_suites)==16,'tests/explicit_historical_unused_fixture_exclusion')
    analysis=results(args,ctx) if args.results else dict(coverage=ctx['coverage'])
    analysis['test_scope']=dict(current_suite='tests-scoped.xml',historical_full_suite_errors=16,
        excluded_fixture='unused Legal v2 release package source/core binding setup',
        historical_failure_diagnosis_sha256=sha(O/'source-preparation-static-review.json'),
        historical_full_suite_rerun=False,current_failures_ignored=False)
    check('torch' not in sys.modules and 'transformers' not in sys.modules,'auditor/no_model_imports')
    pin(__file__)
    result=dict(schema='action-binding-source-training-independent-audit/v1',phase='results' if args.results else 'readiness',
        passed=not findings,complete=not findings,checks=checks,finding_count=len(findings),findings=findings,artifacts=artifacts,
        source_path=str(Path(__file__).resolve()),source_sha256=sha(__file__),manifest_path=str(args.manifest),manifest_sha256=sha(args.manifest),
        plan_path=str(args.plan),plan_sha256=sha(args.plan),analysis=analysis,created_at_utc=datetime.now(timezone.utc).isoformat(),
        models_executed=False,training_executed=False,encoder_executed=False,qualified=False,admitted=False,lake_executed=False,fresh_holdout=False)
    if not args.results:
        started=bool(list(R.glob('training-*/results')));result.update(pre_execution=not started,
            timing_scope='post_execution_plan_and_input_review' if started else 'pre_execution_plan_and_input_review')
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(passed=result['passed'],checks=checks,findings=len(findings),output=str(args.output))))
    if findings:sys.exit(1)

if __name__=='__main__':main()
