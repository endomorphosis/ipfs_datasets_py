"""Stage append-only Security evidence after the successful finite-state run.

No checkpoint weights, training rows or defaults are uploaded. A closed archive
retains one original tuning inference, separately authored controls, exact native
receipts and reproducers. Saved receipts remain evidence, never live authority.
"""
import argparse
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys


HERE = Path(__file__).resolve().parent
HELPERS = HERE / "_publication_helpers.py"
if not HELPERS.exists():
    HELPERS = HERE.parent / "distributed384-richer-semantics-20261001/publish_evidence.py"
spec = importlib.util.spec_from_file_location("publication_helpers", HELPERS)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
require, raw, sha, ref = helper.require, helper.raw, helper.sha, helper.ref
read_json, false_fields, identifier = helper.read_json, helper.false_fields, helper.identifier

REPOSITORY = "Publicus/security-ir-autoencoder"
CHECKPOINT = "2ca38dfcc05536315fc3e2c0647b710b930ef4066b474061a7b4e5bfb9a258c5"
CHECKPOINT_REVISION = "84ea9a8877989d9bde21e0cee5868c936fc184a9"
SOURCE = "def derive(capacity: int, threshold: int) -> int:\n    return capacity + threshold\n"
OPERATORS = ("+", "-", "*", "<", "<=", ">", ">=", "==", "!=")
AUTHORITY = ("source_semantics_verified", "proof_authority", "execution_authority", "completion_authority",
    "source_executed", "security_specification_inferred")
NATIVE_FALSE = (*AUTHORITY, "mutation_authority", "whole_program_semantics_verified",
    "normative_compliance_verified", "admitted", "qualified", "claim_proved", "promotion_performed", "model_checker_executed")


def expected_files():
    names = {"summary.json", "checkpoint-source-inputs.json", "checkpoint-state-rows.json",
        "supervisor-config.json", "supervisor-advice.json", "source-provenance.json",
        "published-checkpoint-reference.json", "producer-sources.json"}
    for prefix, count in (("checkpoint-native", 1), ("controls/direct/native", 9), ("controls/temporary/native", 9)):
        names.update((prefix + "/receipt.json", prefix + "/SecuritySourceStates.lean"))
        names.update(prefix + "/state-" + str(i) + ".tla" for i in range(count))
    names.update("controls/" + name + "/inputs.json" for name in ("direct", "temporary"))
    return names


def compact(receipt):
    return dict(status=receipt["status"], candidates=receipt["count"], supported_candidates=receipt["supported_count"],
        cases=sum(row.get("case_count", 0) for row in receipt["rows"]),
        all_candidates_checked=receipt["all_candidates_checked"],
        finite_correspondence_kernel_checked=receipt["finite_correspondence_kernel_checked"],
        lake_passed=sum(row["lake_status"] == "passed" for row in receipt["rows"]),
        sany_passed=sum(row["sany_status"] == "passed" for row in receipt["rows"]),
        source_semantics_verified=False, proof_authority=False, model_checker_executed=False)


def verify_compatibility(advice, config, captured):
    """Check exact checkpoint bytes and all three observed compatibility receipts."""
    from ipfs_datasets_py.logic.formalization.autoencoder import source_program_runtime_384_v2 as compatibility
    from ipfs_datasets_py.optimizers.logic_theorem_optimizer.autoencoder_schema_lake import _pin_imported_module
    entries = {row["module"]: row for row in captured["modules"] if row["repository"] == "datasets"}
    require(compatibility.__name__ in entries, "tested compatibility verifier source was not captured")
    # Pin the actual code loaded for this offline replay, then check it against
    # the run capture. validate_commits later joins those same hashes to Git.
    checked = set()
    def check_loaded():
        for name, row in entries.items():
            module = sys.modules.get(name)
            if module is None or name in checked:
                continue
            _pin_imported_module(module)
            path = Path(module.__file__).resolve()
            require(path.as_posix().endswith("/" + row["path"]) and sha(path.read_bytes()) == row["sha256"],
                "offline compatibility replay producer differs from tested source: " + name)
            checked.add(name)
    check_loaded()
    receipt = advice["checkpoint_compatibility"]
    require(receipt == advice["runtime"]["checkpoint_compatibility"] == advice["inference"]["checkpoint_compatibility"],
        "supervisor/runtime/inference compatibility receipts differ")
    expected_delta = [dict(path=["shared_runtime", "native", "dependencies", "ipfs_datasets_py.logic.ui_ux_ir.decoder"],
        before="d7be6bff3a1f1464d4783567b90942258ef718bc1c2b7e02938698ed4e619e57",
        after="21e8315b0054f7755512212d610d4e3f5f4ac86387f3b27edb9632fa8ca68bc3")]
    require(receipt["mode"] == "known_unrelated_ui_decoder_pin" and receipt["applied"] is True
        and receipt["changed_pins"] == expected_delta, "unexpected checkpoint compatibility transition")
    verified = compatibility.verify_checkpoint_compatibility(receipt, config["checkpoint_path"], CHECKPOINT)
    require(verified == receipt, "artifact-backed compatibility replay differs")
    check_loaded()
    require(advice["runtime"]["head_sha256"] == verified["unchanged_component_sha256"]["head_state"]
        and advice["runtime"]["projection_sha256"] == verified["unchanged_component_sha256"]["projection_state"]
        and all(row["head_sha256"] == advice["runtime"]["head_sha256"]
            and row["projection_sha256"] == advice["runtime"]["projection_sha256"] for row in advice["inference"]["rows"]),
        "observed runtime/inference numerical components differ from immutable checkpoint")
    return verified


def validate_native(report, rows, files=None, prefix=None, *, sany=True):
    false_fields(report, NATIVE_FALSE, "native receipt")
    require(report["schema"] == "source-state-384-lake/v1" and report["status"] == "passed"
        and report["all_candidates_checked"] is True and report["finite_correspondence_kernel_checked"] is True
        and report["backend_executed"] is True and report["source_replay_passed"] is True,
        "native finite correspondence incomplete")
    require(report["input_sha256"] == sha(raw(rows)) and report["count"] == report["supported_count"] == len(rows)
        and len(report["rows"]) == len(rows), "native candidate set changed")
    require(report["training_steps"] == report["provider_calls"] == report["download_calls"] == 0,
        "unexpected native training/provider/download activity")
    false_fields(report, ("input_domains_inferred", "candidate_repaired", "model_inference_performed"), "native scope")
    execution = report["execution"]
    require(execution["status"] == "passed" and execution["backend_executed"] is True
        and execution["returncode"] == 0 and not execution["timed_out"]
        and not execution["output_truncated"] and not execution["workspace_limit_exceeded"], "native execution incomplete")
    lean = report["lean_source"].encode()
    require(sha(lean) == report["lean_source_sha256"]
        == execution["input_files_sha256"]["SecuritySourceStates.lean"], "native Lean source binding changed")
    if files is not None:
        require(files[prefix + "/SecuritySourceStates.lean"] == lean, "archived Lean differs")
    for index, (result, supplied) in enumerate(zip(report["rows"], rows)):
        false_fields(result, NATIVE_FALSE, "native candidate")
        require(result["id"] == supplied["id"] and result["source_sha256"] == sha(supplied["source_text"].encode())
            and result["candidate_sha256"] == sha(raw(supplied["candidate_ir"]))
            and result["input_domains_sha256"] == sha(raw(supplied["input_domains"])), "native source/candidate/domains differ")
        require(result["status"] == result["lake_status"] == "passed"
            and result["semantic_lowering_supported"] is True and result["finite_correspondence_kernel_checked"] is True
            and result["case_count"] == 9, "native candidate proof coverage differs")
        model = result["model"]
        require(model["source_text"] == supplied["source_text"] and model["candidate_ir"] == supplied["candidate_ir"]
            and model["input_domains"] == supplied["input_domains"] and model["case_count"] == len(model["cases"]) == 9,
            "derived model input binding differs")
        require(model["report_sha256"] == sha(raw({k: v for k, v in model.items() if k != "report_sha256"})),
            "derived model identity differs")
        false_fields(model, (*AUTHORITY, "candidate_rewritten", "candidate_repaired", "model_inference_executed",
            "qualified", "admitted", "model_checker_executed", "liveness_proved"), "derived model")
        require({"all_finite_cases_match", "all_finite_cases_initial", "parameter_domain_covered",
            "every_transition_matches_program", "every_bounded_transition_matches_program",
            "returned_states_are_terminal", "returned_bounded_states_are_terminal"}
            <= set(result["lowering"]["theorems"]), "initial/terminal/correspondence proof missing")
        bounded = result["lowering"]["bounded_tla"]
        require(bounded["native_document"] == model["state_model"] and bounded["max_steps"] == 1,
            "TLA native model or finite bound differs")
        if files is not None:
            require(files[prefix + "/state-" + str(index) + ".tla"] == bounded["model_text"].encode(), "archived TLA differs")
        if sany:
            syntax = result["syntax_check"]
            require(report["sany_requested"] is True and result["sany_status"] == syntax["status"] == "passed"
                and syntax["executed"] is True and syntax["returncode"] == 0
                and syntax["matching_module_parse_observed"] is True
                and syntax["matching_module_semantic_processing_observed"] is True
                and syntax["level_checking_enabled"] is True, "SANY semantic-level check incomplete")
    return compact(report)


def validate_run(root, run):
    files = helper.snapshot(root / run, expected_files())
    get = lambda name: json.loads(files[name])
    summary = get("summary.json")
    require(summary["schema"] == "source-derived-finite-state-development-evidence/v1", "unexpected summary schema")
    false_fields(summary, ("training_executed", "weights_changed", "new_holdout_evaluation", "terminal_bench_executed",
        "source_executed", "source_semantics_verified", "proof_authority", "admitted", "qualified"), "run summary")
    require(summary["provider_calls"] == 0, "provider calls are outside this evidence scope")
    sources = get("checkpoint-source-inputs.json")
    require(sources == [dict(id="checkpoint-source.py", source_text=SOURCE, source_sha256=sha(SOURCE.encode()))],
        "unreviewed checkpoint input source")
    provenance = get("source-provenance.json")
    require(provenance["redistribution_allowed"] is True
        and provenance["source_path"] == "tests/fixtures/logic/source_reconstruction_v3.py"
        and provenance["source_repository"] == "https://github.com/endomorphosis/ipfs_datasets_py"
        and identifier(provenance["source_revision"], 40) and "Authored" in provenance["description"]
        and "no test/canary rows" in provenance["provenance_review"], "unreviewed source redistribution provenance")
    config, advice = get("supervisor-config.json"), get("supervisor-advice.json")
    require(advice["checkpoint_selection"] == config and config["checkpoint_sha256"] == CHECKPOINT,
        "supervisor checkpoint selection differs")
    false_fields(advice, (*AUTHORITY, "mutation_authority", "claim_proved", "default_model_promoted"), "supervisor")
    require(advice["continue_planning"] is True and advice["provider_calls"] == advice["training_steps"] == advice["download_calls"] == 0,
        "supervisor execution scope differs")
    inference = advice["inference"]
    require(inference["checkpoint_sha256"] == CHECKPOINT and inference["domain_id"] == "security_ir"
        and len(inference["rows"]) == 1, "missing original checkpoint inference")
    verify_compatibility(advice, config, get("producer-sources.json"))
    prediction = inference["rows"][0]
    false_fields(prediction, ("proof_authority", "target_access", "teacher_forcing"), "checkpoint prediction")
    rows = get("checkpoint-state-rows.json")
    domains = {name: dict(lower=-1, upper=1) for name in ("capacity", "threshold")}
    require(rows == [dict(id=prediction["id"], source_text=SOURCE, candidate_ir=prediction["candidate_ir"], input_domains=domains)]
        and prediction["source_sha256"] == sha(SOURCE.encode()), "checkpoint native input is not the actual prediction")
    require(advice["source_state"]["live_build_verified"] is True, "supervisor live state verification absent")
    validate_native(advice["source_state"]["native"], rows, sany=False)
    checkpoint_summary = validate_native(get("checkpoint-native/receipt.json"), rows, files, "checkpoint-native")
    require(all(summary["checkpoint"][key] == value for key, value in checkpoint_summary.items()), "checkpoint summary differs")
    require(summary["checkpoint"]["checkpoint_sha256"] == CHECKPOINT
        and summary["checkpoint"]["checkpoint_loaded"] is True and summary["checkpoint"]["supervisor_used"] is True,
        "checkpoint summary lacks actual consumer use")
    for index, name in enumerate(("direct", "temporary")):
        control_rows = get("controls/" + name + "/inputs.json")
        require(len(control_rows) == 9, "expected every authored scalar operator")
        for row, operator in zip(control_rows, OPERATORS):
            boolean = operator not in ("+", "-", "*")
            source = "def compute(left: int, right: int) -> " + ("bool" if boolean else "int") + ":\n"
            body = "left " + operator + " right"
            source += "    answer = " + body + "\n    return answer\n" if name == "temporary" else "    return " + body + "\n"
            require(set(row) == {"id", "source_text", "candidate_ir", "input_domains"}
                and row["id"] == name + ":" + operator and row["source_text"] == source
                and row["input_domains"] == {key: dict(lower=-1, upper=1) for key in ("left", "right")},
                "unreviewed authored control input")
        prefix = "controls/" + name + "/native"
        result = validate_native(get(prefix + "/receipt.json"), control_rows, files, prefix)
        require(summary["authored_controls"][index] == dict(name=name, learned_candidates=False, **result),
            "authored control summary differs")
    require(len(summary["authored_controls"]) == 2, "unexpected authored control batch")
    published = get("published-checkpoint-reference.json")
    require(published["repository_id"] == REPOSITORY and published["repo_type"] == "model"
        and published["kind"] == "checkpoint" and published["revision"] == CHECKPOINT_REVISION
        and published["binding"]["domain_id"] == "security_ir" and identifier(published["binding"]["plan_id"], 64)
        and identifier(published["manifest_sha256"], 64), "immutable original checkpoint reference changed")
    path = Path(config["checkpoint_path"])
    require(path.is_file() and not path.is_symlink(), "original local checkpoint missing or linked")
    checkpoint = ref(path.read_bytes())
    require(checkpoint["sha256"] == CHECKPOINT, "original checkpoint bytes changed")
    manifest_path = path.parent.parent / "bundles/checkpoints" / published["manifest_sha256"] / "manifest.json"
    manifest_bytes = manifest_path.read_bytes(); manifest = json.loads(manifest_bytes)
    require(sha(manifest_bytes) == published["manifest_sha256"] and manifest["binding"] == published["binding"]
        and manifest["result"] == checkpoint, "local immutable publication manifest differs")
    files["published-checkpoint-manifest.json"] = manifest_bytes
    files["reproduce.py"] = (root / "reproduce.py").read_bytes()
    files["publish_evidence.py"] = Path(__file__).read_bytes()
    files["_publication_helpers.py"] = HELPERS.read_bytes()
    return summary, files, published, checkpoint


def git_file(checkout, commit, relative):
    require(helper.safe_name(relative), "unsafe tested producer path")
    data = subprocess.run(["git", "-C", str(checkout), "show", commit + ":" + relative],
        check=True, capture_output=True).stdout
    return data


def validate_commits(files, datasets_commit, accelerate_commit, datasets_checkout, accelerate_checkout):
    require(identifier(datasets_commit, 40) and identifier(accelerate_commit, 40), "two immutable tested Git commits required")
    captured = json.loads(files["producer-sources.json"])
    require(captured["schema"] == "source-state-replay-producer-sources/v1"
        and captured["reproducer_sha256"] == sha(files["reproduce.py"]), "tested reproducer changed")
    # The successful run captures this map from actually imported module files.
    require(type(captured["modules"]) is list and captured["modules"], "captured imported modules required")
    pins = {"datasets": {}, "accelerate": {}}
    for row in captured["modules"]:
        require(set(row) == {"repository", "module", "path", "sha256"} and row["repository"] in pins,
            "closed tested-module capture required")
        entries = pins[row["repository"]]
        require(row["path"] not in entries, "duplicate captured producer path")
        entries[row["path"]] = row["sha256"]
    native_reports = [json.loads(files[prefix + "/receipt.json"])
        for prefix in ("checkpoint-native", "controls/direct/native", "controls/temporary/native")]
    native_reports.append(json.loads(files["supervisor-advice.json"])["source_state"]["native"])
    for report in native_reports:
        for path, checksum in report["producer"].items():
            parts = Path(path).parts
            require("ipfs_datasets_py" in parts, "native producer is outside datasets package")
            relative = PurePosixPath(*parts[parts.index("ipfs_datasets_py"):]).as_posix()
            require(relative not in pins["datasets"] or pins["datasets"][relative] == checksum,
                "producer changed within completed run")
            pins["datasets"][relative] = checksum
    normalized = {}
    for domain, commit, checkout in (("datasets", datasets_commit, datasets_checkout),
            ("accelerate", accelerate_commit, accelerate_checkout)):
        values = pins[domain]
        require(type(values) is dict and values, "empty producer module capture")
        normalized[domain] = {}
        for relative, checksum in values.items():
            require(identifier(checksum, 64), "invalid captured producer digest")
            expected_part = "ipfs_datasets_py" if domain == "datasets" else "ipfs_accelerate_py"
            require(helper.safe_name(relative) and PurePosixPath(relative).parts[0] == expected_part,
                "wrong producer repository root")
            data = git_file(checkout, commit, relative)
            require(sha(data) == checksum, "tested producer not in requested commit: " + relative)
            normalized[domain][relative] = checksum
    return normalized


def prepare_package(summary, files, published, checkpoint, datasets_commit, accelerate_commit,
        datasets_checkout, accelerate_checkout):
    producers = validate_commits(files, datasets_commit, accelerate_commit, datasets_checkout, accelerate_checkout)
    manifest = dict(schema="source-derived-finite-state-development-evidence/v1", domain_id="security_ir",
        checkpoint=checkpoint, published_checkpoint=published,
        code=dict(datasets=dict(repository="https://github.com/endomorphosis/ipfs_datasets_py", commit=datasets_commit),
            accelerate=dict(repository="https://github.com/endomorphosis/ipfs_accelerate_py", commit=accelerate_commit)),
        tested_producer_files=producers, result=summary,
        scope="one unchanged existing tuning prediction through supervisor plus 18 separately authored scalar controls",
        proof_scope="kernel-checked finite ProgramIR/state correspondence, initial witnesses and return terminality under explicit source integer assumptions",
        source_provenance="redistributable authored repository controls; not CVEfixes corpus, a new holdout, or Terminal Bench",
        weights_included=False, weights_changed=False, training_executed=False, training_target_rows_included=False,
        saved_evidence_is_live_authority=False, model_source_semantic_fidelity_verified=False,
        source_semantics_verified=False, proof_authority=False, admitted=False, qualified=False, promotion_performed=False,
        files=[dict(path=name, **ref(data)) for name, data in sorted(files.items())])
    archive = helper.bundle_files(files)
    manifest["archive"] = dict(path="evidence.tar.gz", **ref(archive))
    helper.verify_archive(archive, manifest)
    manifest_bytes = raw(manifest); identity = sha(manifest_bytes)
    prefix = "training/structured384/" + published["binding"]["plan_id"] + "/source-state-checks/" + identity
    return dict(prefix=prefix, manifest=manifest, published=published, checkpoint=checkpoint,
        desired={prefix + "/manifest.json": manifest_bytes, prefix + "/evidence.tar.gz": archive},
        receipt=dict(repository_id=REPOSITORY, repo_type="model", path=prefix, manifest_sha256=identity,
            archive_sha256=sha(archive), archive_bytes=len(archive), uploaded=False))


def upload_package(package):
    from huggingface_hub import CommitOperationAdd, HfApi, hf_hub_download
    helper.verify_published_checkpoint(package, hf_hub_download)
    api = HfApi(); info = api.model_info(REPOSITORY)
    require(identifier(info.sha, 40), "immutable repository parent required")
    desired = package["desired"]; existing = {row.rfilename for row in info.siblings}
    if set(desired) & existing:
        require(set(desired) <= existing, "partial evidence publication requires investigation")
        revision = info.sha
    else:
        revision = api.create_commit(repo_id=REPOSITORY, repo_type="model", parent_commit=info.sha,
            operations=[CommitOperationAdd(path_in_repo=name, path_or_fileobj=io.BytesIO(data)) for name, data in desired.items()],
            commit_message="Archive bounded source-derived state correspondence evidence").oid
    require(identifier(revision, 40), "immutable publication revision required")
    downloaded = {}
    for name, data in desired.items():
        remote = Path(hf_hub_download(repo_id=REPOSITORY, repo_type="model", filename=name, revision=revision)).read_bytes()
        require(remote == data, "uploaded evidence differs")
        downloaded[PurePosixPath(name).name] = remote
    helper.verify_archive(downloaded["evidence.tar.gz"], json.loads(downloaded["manifest.json"]))
    return dict(package["receipt"], uploaded=True, revision=revision, download_verified=True,
        immutable_checkpoint_reference_download_verified=True,
        url="https://huggingface.co/" + REPOSITORY + "/blob/" + revision + "/" + package["prefix"] + "/manifest.json")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=HERE)
    parser.add_argument("--run", default="run-02")
    parser.add_argument("--datasets-commit")
    parser.add_argument("--accelerate-commit")
    parser.add_argument("--datasets-checkout", type=Path, default=Path("/tmp/ir-release-datasets-20261001"))
    parser.add_argument("--accelerate-checkout", type=Path, default=Path("/tmp/ir-release-accelerate-20261001"))
    parser.add_argument("--upload", action="store_true")
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args(argv)
    require(helper.safe_name(args.run) and len(PurePosixPath(args.run).parts) == 1, "single run directory name required")
    require(not (args.validate_only and args.upload), "validation-only cannot upload")
    sys.path.insert(0, str(args.datasets_checkout.resolve()))
    summary, files, published, checkpoint = validate_run(args.root, args.run)
    if args.validate_only:
        print(json.dumps(dict(validated=True, staged=False, uploaded=False, files=len(files))))
        return
    package = prepare_package(summary, files, published, checkpoint, args.datasets_commit, args.accelerate_commit,
        args.datasets_checkout, args.accelerate_checkout)
    stage = args.root / "publication" / package["receipt"]["manifest_sha256"]
    for name, data in package["desired"].items():
        helper.bounded_snapshot(stage / PurePosixPath(name).name, data)
    receipt = upload_package(package) if args.upload else package["receipt"]
    path = stage / "receipt.json"
    if path.exists() and not args.upload:
        previous = read_json(path)
        require(all(previous[key] == receipt[key] for key in receipt if key != "uploaded"), "existing publication receipt differs")
        receipt = previous
    path.write_bytes(raw(receipt))
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
