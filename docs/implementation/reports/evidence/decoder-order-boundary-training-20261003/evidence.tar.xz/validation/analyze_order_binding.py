"""Posthoc saved-token/argmax joint-binding analysis; no model executions."""
from pathlib import Path
from collections import Counter
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('_bound_audit',R/'independent_audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
artifacts={}
def read(path):
    data=Path(path).read_bytes();artifacts[str(Path(path).resolve())]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data));return json.loads(data)
def decode(tokens,vocab):
    try:
        d=json.loads(''.join(vocab[i] for i in tokens),object_pairs_hook=audit.unique)
        return d['rules'] if type(d) is dict and set(d)=={'rules'} and type(d['rules']) is list and all(audit.valid_rule(r) for r in d['rules']) else []
    except (ValueError,TypeError):return []
def pair_count(gold,actual):return sum(i<len(actual) and all(actual[i].get(k)==r[k] for k in ('actor','action')) for i,r in enumerate(gold))
m=read(R/'training-manifest.json');donor=read(m['donor']);prep=read(m['order_preparation']);original=set(prep['original_ids']);refs={r['id']:r for r in prep['rows']};vocab=donor['codec']['target_vocabulary'];root=R/'training-r1/results';s=read(root/'summary.json');models={}
for run in s['runs']:
 arm=run['arm'];obs=read(root/arm/'last-attempt/order-observations.json');panel=read(root/arm/'last-attempt/order-pairs.json');grows={r['id']:r for r in panel['generated']['rows']};hrows={r['id']:r for r in panel['scalars']['rows']};groups={'original_training':Counter(),'changed_order_training_components':Counter()}
 for p in obs['predictions']:
  key=p['id'];gold=refs[key]['target']['rules'];actual=decode(p['token_ids'],vocab);gp=pair_count(gold,actual);scores=obs['scalar_logits'][key];head=[]
  for slot in scores:
   values={}
   for f,logits in zip(('actor','action','modality','object'),slot):
    token=max(range(len(logits)),key=logits.__getitem__)
    try:v=json.loads(vocab[token]) if token>=3 else None
    except ValueError:v=None
    values[f]=v if type(v) is str else None
   head.append(values)
  hp=pair_count(gold,head);assert grows[key]['actor_action_pairs_correct']==gp and hrows[key]['actor_action_pairs_correct']==hp
  group=groups['original_training' if key in original else 'changed_order_training_components'];group['rows']+=1;group['expected_pair_slots']+=len(gold);group['generated_pair_correct']+=gp;group['raw_head_pair_correct']+=hp
  group['exact_with_eos']+=bool(p['eos_reached'] and actual==gold)
 values={}
 for mode in ('generated','scalars'):
  rows=panel[mode]['pairs'];values[mode]={k:sum(r['equivariance']['actor_action'][k] for r in rows) for k in ('informative_slots','informative_comparable_slots','informative_matches_fixed','informative_matches_permuted')}
 scalar=panel['scalars']['pairs'];closer=sum(r['full_logit_fixed_slot_distance']['l2']<r['full_logit_permuted_slot_distance']['l2'] for r in scalar)
 models[arm]=dict(groups={k:dict(v) for k,v in groups.items()},changed_reference_actor_action_equivariance=values,full_logits_closer_to_fixed_positions=closer,order_pairs=60,permutations_used_for_training=run['recipe']['order_augmentation'])
artifacts[str(Path(__file__).resolve())]=dict(sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),bytes=Path(__file__).stat().st_size)
artifacts[str(R/'independent_audit.py')]=dict(sha256=audit.sha(R/'independent_audit.py'),bytes=(R/'independent_audit.py').stat().st_size)
receipt=dict(schema='order-boundary-training-joint-binding-analysis/v1',passed=True,models=models,artifacts=artifacts,models_executed=False,training_executed=False,qualified=False,admitted=False,fresh_holdout=False,
 interpretation='Order/both arms have trained on these exact training-only permutations; original validation is separate. Correct marginal values or pair counts do not establish complete ordered reconstruction.')
(R/'order-binding-analysis.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps(models))
