"""Freeze training-only interventions and authenticated prior source/input closure."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
O=P/'workspace/test-logs/decoder-order-boundary-diagnostic-20261003'
BASE=json.loads((R/'base.json').read_bytes())['base']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):(R/name).write_text(json.dumps(obj,indent=2)+'\n')
def gitbytes(rel):return subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)
if __name__=='__main__':
 assert not (R/'experiment-source').exists()
 runner='scripts/ops/autoencoder/benchmark_order_boundary_source_training.py'
 rootfiles=['ipfs_datasets_py/logic/formalization/autoencoder/long_span_source_value_training.py',runner,
  'tests/unit/logic/formalization/autoencoder/test_order_boundary_training_integration.py',
  'tests/unit/logic/formalization/autoencoder/test_benchmark_order_boundary_source_training.py']
 save('runner-ready.json',dict(ready=True,files={rel:sha(P/rel) for rel in rootfiles},
  focused_tests_before_final_replay_guard=61,full_frozen_suite_required=True,models_executed=False))
 additions={}
 for name in ('order-ready.json','boundary-ready.json','runner-ready.json'):
  ready=json.loads((R/name).read_bytes());assert ready['ready'] is True
  for rel,digest in ready['files'].items():assert sha(P/rel)==digest,rel
  additions.update(ready['files'])
 pins=json.loads((O/'frozen-extensions.json').read_bytes());tests=json.loads((O/'validated-test-source.json').read_bytes())
 helpers=json.loads((O/'test-helper-sources.json').read_bytes())
 for rel,digest in {**pins,**tests,**helpers}.items():
  assert sha(O/'experiment-source'/rel)==digest,rel
  assert hashlib.sha256(gitbytes(rel)).hexdigest()==digest,rel
 for rel,digest in additions.items():(tests if rel.startswith('tests/') else pins)[rel]=digest
 for rel,digest in {**pins,**tests,**helpers}.items():
  source=P/rel if rel in additions else O/'experiment-source'/rel
  target=R/'experiment-source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(source,target);assert sha(target)==digest
 save('frozen-extensions.json',pins);save('validated-test-source.json',tests);save('test-helper-sources.json',helpers)
 save('test-files.json',list(tests));save('code-files.json',list(additions)+['docs/autoencoders/decoder_length_distillation.md'])
 spec=importlib.util.spec_from_file_location('_freeze_order_training',R/'experiment-source'/runner)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 old=json.loads((O/'diagnostic-manifest.json').read_bytes())
 manifest={k:old[k] for k in ('donor','paragraphs','embeddings','curriculum','curriculum_inputs','parent_preprocessing',
  'shared_public_manifest','shared_public_results','shared_summary')}
 E=P/'docs/implementation/reports/evidence/decoder-order-boundary-diagnostic-20261003'
 manifest.update(order_public_manifest=str(E/'manifest.json'),order_public_results=str(E/'results.json'),
  order_preparation=str(O/'diagnostic-r1/results/order-preparation.json'),order_embeddings=str(O/'diagnostic-r1/results/embedding-observations.json'))
 paths=list(manifest.values());manifest['extensions']=pins;manifest['inputs']={p:sha(p) for p in paths}
 for key in ['shared_public_manifest','shared_public_results','order_public_manifest','order_public_results']:
  assert Path(manifest[key]).read_bytes()==gitbytes(str(Path(manifest[key]).relative_to(P))),key
 diagnostic=module.load_helper(R/'experiment-source',pins,'scripts/ops/autoencoder/benchmark_decoder_order_boundaries.py','_freeze_order_inputs')
 shared_pub=json.loads(Path(manifest['shared_public_manifest']).read_bytes());order_pub=json.loads(Path(manifest['order_public_manifest']).read_bytes())
 for key in ['donor','paragraphs','embeddings','curriculum','curriculum_inputs','parent_preprocessing','shared_summary']:
  diagnostic.read_published(manifest[key],manifest,shared_pub)
 for key in ['order_preparation','order_embeddings']:diagnostic.read_published(manifest[key],manifest,order_pub)
 save('training-plan.json',dict(module.FIXED,input_sha256=manifest['inputs']))
 manifest['plan_sha256']=sha(R/'training-plan.json');save('training-manifest.json',manifest)
 (R/'run_frozen_tests.py').write_bytes((O/'run_frozen_tests.py').read_bytes())
 guardian=(O/'run_diagnostic_reserved.py').read_text()
 for a,b in [("choices=('diagnostic',)","choices=('training',)"),('benchmark_decoder_order_boundaries.py','benchmark_order_boundary_source_training.py'),
  ('run_diagnostic_reserved.py','run_training_reserved.py'),('owned diagnostic child','owned training child'),('read-only diagnostics only','bounded numerical training only'),
  ('time.monotonic()-child_started > 900','time.monotonic()-child_started > 3000')]:guardian=guardian.replace(a,b)
 (R/'run_training_reserved.py').write_text(guardian)
 print(json.dumps(dict(extensions=len(pins),test_files=len(tests),inputs=len(paths))))
