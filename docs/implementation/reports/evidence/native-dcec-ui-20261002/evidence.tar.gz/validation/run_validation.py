"""Run the final frozen regression; prior snapshots and outputs stay immutable."""
import json, os, subprocess, sys
from pathlib import Path
RUN=Path(__file__).resolve().parent
SOURCE=RUN/'validation-source'
env=dict(os.environ, PYTHONPATH=str(SOURCE), PYTHONDONTWRITEBYTECODE='1',
    HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1',
    IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI='0', CUDA_VISIBLE_DEVICES='',
    OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
mode=sys.argv[1]
if mode=='tests':
    cmd=[sys.executable,'-m','pytest','-q', '-o','cache_dir='+str(RUN/'pytest-cache'),
         '--junitxml='+str(RUN/'validation-tests-r2.xml'),
         *json.loads((RUN/'test-selection.json').read_text())]
    output=RUN/'validation-tests-r2.log'
elif mode=='native':
    cmd=[sys.executable,str(SOURCE/'scripts/ops/autoencoder/check_native_dcec_ui.py'),
        '--comparison', str(RUN.parent/'intent-ui-coverage-20261002/comparison-r1'),
        '--sampling-plan',str(RUN.parent/'intent-ui-coverage-20261002/native-followup-plan.json'),
        '--output',str(RUN/'native-r2')]
    output=RUN/'native-r2.log'
else:raise ValueError(mode)
with output.open('xb') as stream:
    result=subprocess.run(cmd,cwd=SOURCE,env=env,stdout=stream,stderr=subprocess.STDOUT)
print(json.dumps({'mode':mode,'exit_code':result.returncode,'log':str(output)}),flush=True)
print(output.read_text()[-5000:],flush=True)
raise SystemExit(result.returncode)
