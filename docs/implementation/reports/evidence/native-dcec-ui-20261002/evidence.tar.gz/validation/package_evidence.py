"""Package completed regression evidence; never train, build, or publish.

Keep exact loaded/pinned producer code and full manifests, not the whole source
export or static-asset inventory. Six old checkpoint weights remain local.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path("/home/barberb/lift_coding/external/ipfs_datasets")
RUN = Path(__file__).resolve().parent
SOURCE = RUN / "validation-source"
NATIVE = RUN / "native-r2"
PRIOR = RUN.parent / "intent-ui-coverage-20261002"
COMPARISON = PRIOR / "comparison-r1"
OUT = ROOT / "docs/implementation/reports/evidence/native-dcec-ui-20261002"
DOCUMENT = "docs/autoencoders/native_dcec_interpretation_validation_v6.md"
SHA = re.compile(r"[0-9a-f]{64}\Z")
CACHES = {".git", ".lake", "__pycache__", ".pytest_cache"}
EVIDENCE_SUFFIXES = {".json", ".xml", ".log", ".py", ".lean", ".toml", ".txt", ".md", ".tla", ".cfg"}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def read(path):
    return json.loads(Path(path).read_bytes())


def dump(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def describe(path):
    return {"sha256": sha(path), "bytes": path.stat().st_size}


def relative(name):
    path = Path(name)
    require(not path.is_absolute() and ".." not in path.parts and path.as_posix() == name,
            "unsafe archive-relative path: " + name)
    return name


def main():
    owned = read(RUN / "candidate-files.json")
    require(type(owned) is list and owned and len(set(owned)) == len(owned), "unique candidate list required")
    if DOCUMENT not in owned:
        owned.append(DOCUMENT)
    frozen_candidates = read(RUN / "frozen-candidates.json")
    require(set(frozen_candidates) == {name for name in owned if name.endswith(".py")},
            "owned code/test list differs from frozen validation candidates")
    for name, digest in frozen_candidates.items():
        relative(name)
        require(sha(SOURCE / name) == sha(ROOT / name) == digest, "frozen candidate changed: " + name)
    base = read(RUN / "base.json")["base"]
    native = read(NATIVE / "summary.json")
    require(native["attempt_count"] == len(native["attempts"]) and native["attempt_count"] > 29,
            "old attempts and additional guard/intention fixtures required")
    identities = [row["attempt_id"] for row in native["attempts"]]
    require(len(set(identities)) == native["attempt_count"], "duplicate regression attempt identity")
    origins = Counter(row["strategy"] for row in native["attempts"])
    require(origins["v1"] == 12 and origins["ridge"] == 6 and origins["authored_fixture"] == native["attempt_count"] - 18, "18 learned attempts plus all authored attempts required")
    require(native["fresh_holdout"] is False and native["prior_test_panel_already_exposed"] is True
            and native["no_success_filtering"] is True and native["all_source_and_input_files_unchanged"] is True,
            "regression provenance differs")
    for key in ("training_executed", "weights_modified", "prediction_repaired", "gold_source_replaced",
                "qualified", "admitted", "formalized", "proof_authority", "source_semantics_verified",
                "production_promotion_performed"):
        require(native[key] is False, "regression changed a forbidden authority or model flag: " + key)
    require(native["sampling_plan_sha256"] == sha(PRIOR / "native-followup-plan.json"), "sampling plan changed")

    xml = ET.parse(RUN / "validation-tests-final.xml").getroot()
    suites = [xml] if xml.tag == "testsuite" else list(xml.iter("testsuite"))
    totals = {key: sum(int(row.attrib.get(key, 0)) for row in suites)
              for key in ("tests", "failures", "errors", "skipped")}
    require(totals["tests"] > 0 and totals["failures"] == totals["errors"] == 0, "final regression suite failed")
    passed = totals["tests"] - totals["skipped"]

    source_manifest = read(NATIVE / "source-manifest.json")
    require(source_manifest["root"] == str(SOURCE), "native source is not the final validation export")
    catalog = {row["path"]: row["sha256"] for row in source_manifest["files"]}
    require(len(catalog) == len(source_manifest["files"]), "duplicate source manifest entries")
    for name, digest in catalog.items():
        relative(name)
        require(SHA.fullmatch(digest), "invalid frozen source digest")
    members, metadata, pins, pin_origins, weights = {}, {}, {}, {}, {}

    def add(path, name):
        path = Path(path)
        relative(name)
        require(path.is_file() and not path.is_symlink(), "regular archive member required: " + str(path))
        require(not CACHES.intersection(Path(name).parts), "cache in archive")
        require(path.name != "checkpoint.json" and not path.name.endswith("-weights.json"), "weights must remain local")
        item = describe(path)
        require(name not in metadata or metadata[name] == item, "archive collision: " + name)
        members[name], metadata[name] = path, item

    def producer(path, expected=None, *, scope="loaded_or_explicitly_pinned", unlisted_test=False):
        path = Path(path)
        require(path.is_relative_to(SOURCE), "producer outside final validation source: " + str(path))
        name = path.relative_to(SOURCE).as_posix()
        require(path.suffix == ".py", "static asset is not executable producer source: " + name)
        recorded = catalog.get(name)
        require(recorded is not None or unlisted_test and name.startswith("tests/"),
                "producer absent from source manifest: " + name)
        actual = sha(path)
        require((recorded is None or actual == recorded) and (expected is None or actual == expected),
                "producer changed: " + name)
        require(name not in pins or pins[name] == actual, "inconsistent producer pin: " + name)
        pins[name] = actual
        pin_origins.setdefault(name, set()).add(scope)
        add(path, "source/" + name)

    def collect(value):
        if isinstance(value, list):
            for child in value:
                collect(child)
        elif isinstance(value, dict):
            for key, child in value.items():
                if type(child) is str and SHA.fullmatch(child):
                    path = Path(key)
                    if path.is_absolute() and path.is_relative_to(SOURCE) and path.suffix == ".py":
                        producer(path, child)
                if key == "producer_pins" and isinstance(child, dict):
                    for module, digest in child.items():
                        if not module.startswith("ipfs_datasets_py.") or type(digest) is not str:
                            continue
                        stem = SOURCE / module.replace(".", "/")
                        path = stem.with_suffix(".py")
                        if not path.is_file():
                            path = stem / "__init__.py"
                        producer(path, digest)
                collect(child)

    loaded = read(NATIVE / "loaded-modules.json")
    for module, row in loaded.items():
        require(module.startswith("ipfs_datasets_py"), "unexpected loaded producer namespace")
        producer(row["path"], row["sha256"], scope="native_loaded_modules")
    # Full inventories bind static assets too. Retain them, but do not walk
    # those inventories as though every guarded asset were a loaded producer.
    for path in sorted(NATIVE.rglob("*")):
        if not path.is_file() or CACHES.intersection(path.parts):
            continue
        require(path.suffix in EVIDENCE_SUFFIXES or path.name == "lean-toolchain",
                "unexpected native evidence asset: " + str(path))
        add(path, "validation/native-r2/" + path.relative_to(NATIVE).as_posix())
        if path.suffix == ".json" and path.name not in {"source-manifest.json", "input-provenance.json", "loaded-modules.json"}:
            collect(read(path))
    first_native = RUN / "native-r1"
    first_summary = read(first_native / "summary.json")
    first_receipt = read(first_native / "parallel-receipt.json")
    first_timeouts = [row for row in first_receipt["jobs"] if row.get("status") == "failed"]
    require(len(first_timeouts) == 6 and all(row["reason"] == "timed out waiting for a resource lease"
            for row in first_timeouts), "retain exact first-invocation resource failures")
    for path in sorted(first_native.rglob("*")):
        if path.is_file() and not CACHES.intersection(path.parts):
            require(path.suffix in EVIDENCE_SUFFIXES or path.name == "lean-toolchain",
                    "unexpected first-invocation evidence asset")
            add(path, "validation/native-r1/" + path.relative_to(first_native).as_posix())
    native_plan = read(NATIVE / "plan.json")
    producer(SOURCE / "scripts/ops/autoencoder/check_native_dcec_ui.py", native_plan["script_sha256"], scope="native_driver")
    producer(SOURCE / "tests/fixtures/logic/intent_ui_projection_gaps_v1/cases.py",
             native_plan["fixture_sha256"], scope="authored_adapter_fixture")
    producer(SOURCE / "tests/fixtures/logic/native_dcec_ui_v1/guard_cases.py",
             native_plan["guard_fixture_sha256"], scope="explicit_UI_guard_fixture")
    for name in ("scripts/ops/autoencoder/benchmark_intent_ui_candidate_coverage.py",
                 "scripts/ops/autoencoder/benchmark_source384_fidelity.py",
                 "tests/fixtures/logic/intent_ui_source_compositions_v1/panel.py"):
        producer(SOURCE / name, scope="replayed_benchmark_driver_and_fixture")

    for name in owned:
        relative(name)
        current = ROOT / name
        if current.suffix == ".py":
            producer(SOURCE / name, sha(current), scope="owned_candidate",
                     unlisted_test=name.startswith("tests/"))
        else:
            add(current, "source/" + name)
    # JUnit class names identify the exercised existing test modules. Tests are
    # not covered by the production-only native manifest; archive exact frozen
    # test files with this narrower, explicit scope.
    for case in xml.iter("testcase"):
        pieces = case.attrib.get("classname", "").split(".")
        while pieces:
            path = SOURCE / ("/".join(pieces) + ".py")
            if path.is_file() and path.relative_to(SOURCE).as_posix().startswith("tests/"):
                producer(path, scope="final_xml_test_module_in_frozen_export", unlisted_test=True)
                break
            pieces.pop()

    prior_summary = read(COMPARISON / "summary.json")
    freeze, plan = read(COMPARISON / "freeze.json"), read(COMPARISON / "plan.json")
    require(prior_summary["actual_fit_count"] == len(freeze["fits"]) == 6, "six prior model identities required")
    expected = {(domain, strategy, seed) for domain in ("intent_ir", "ui_ux_ir")
                for strategy, seed in (("v1", 3517), ("v1", 3518), ("ridge", None))}
    require({(fit["domain"], fit["strategy"], fit["seed"]) for fit in freeze["fits"]} == expected,
            "prior fit identities differ")
    require(plan["temperature"] == 0 and plan["max_target_tokens"] == 64 and plan["downloads_performed"] is False,
            "prior representation policy differs")
    require(freeze["plan_sha256"] == sha(COMPARISON / "plan.json")
            and freeze["source_manifest_sha256"] == sha(COMPARISON / "source-manifest.json"), "prior freeze differs")
    for name, expected_sha in freeze["pre_exposure_artifact_sha256"].items():
        require(sha(COMPARISON / relative(name)) == expected_sha, "previously frozen artifact changed: " + name)
    for name in ("summary.json", "plan.json", "freeze.json", "test-exposure.json", "source-manifest.json",
                 "input-hashes.json", "started.json"):
        add(COMPARISON / name, "replay-inputs/prior-comparison/" + name)
    add(PRIOR / "native-followup-plan.json", "replay-inputs/prior-native-followup-plan.json")
    for domain in ("intent_ir", "ui_ux_ir"):
        add(COMPARISON / domain / "test.json", "replay-inputs/prior-comparison/" + domain + "/test.json")
    for fit in freeze["fits"]:
        descriptor = fit["checkpoint"]
        path = Path(descriptor["path"])
        require(path.is_relative_to(COMPARISON) and describe(path) == {key: descriptor[key] for key in ("sha256", "bytes")},
                "unchanged checkpoint descriptor differs")
        weights[str(path)] = {"domain": fit["domain"], "strategy": fit["strategy"], "seed": fit["seed"], **describe(path)}
        relative(fit["directory"])
        prediction = COMPARISON / fit["directory"] / "test-conditioned-inference.json"
        add(prediction, "replay-inputs/prior-comparison/" + fit["directory"] + "/test-conditioned-inference.json")
    parent = {**plan["parent"], **describe(Path(plan["parent"]["path"]))}
    require(parent["sha256"] == plan["parent"]["sha256"], "parent checkpoint differs")
    for path in sorted(RUN.iterdir()):
        if path.is_file() and path.suffix in EVIDENCE_SUFFIXES and path.name not in {
                "publication.json", "owned-files.json", "publish.py", "commit-message.txt"}:
            add(path, "validation/" + path.name)

    provenance = read(NATIVE / "input-provenance.json")
    require(provenance["all_inputs_unchanged"] is True, "native input provenance failed")
    # Verify every guarded input in place without bundling the entire inventory.
    for path, digest in provenance["files"].items():
        require(sha(Path(path)) == digest, "native guarded input changed: " + path)

    builds = []
    for path in sorted(list(NATIVE.rglob("receipt.json")) + list(first_native.rglob("receipt.json"))):
        invocation_root = NATIVE if path.is_relative_to(NATIVE) else first_native
        invocation_name = invocation_root.name
        receipt = read(path)
        execution = receipt.get("execution", {})
        if not isinstance(execution, dict) or not execution.get("backend_executed"):
            continue
        library = receipt["library"]
        require(execution["command"][1:] == ["build", library], "native command is not Lake build")
        texts = {library + ".lean": receipt["lean_source"], "lean-toolchain": execution["toolchain"] + "\n",
            "lakefile.toml": 'name = "native_family_' + library.lower()
                + '"\nversion = "0.1.0"\n\n[[lean_lib]]\nname = "' + library + '"\n'}
        require(set(texts) == set(execution["input_files_sha256"]), "native build input inventory differs")
        prefix = "validation/" + invocation_name + "/" + path.parent.relative_to(invocation_root).as_posix() + "/"
        for filename, content in texts.items():
            content = content.encode()
            item = {"sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content)}
            require(item["sha256"] == execution["input_files_sha256"][filename], "native recorded bytes/hash differ")
            name = prefix + filename
            require(name not in metadata or metadata[name] == item, "native source member collision")
            members[name], metadata[name] = content, item
        builds.append({"receipt": "validation/" + invocation_name + "/" + path.relative_to(invocation_root).as_posix(),
            "invocation": invocation_name, "job_id": path.parent.name,
            "execution_status": execution["status"], "coverage_status": receipt["status"],
            "command": execution["command"], "returncode": execution["returncode"],
            "toolchain": execution["toolchain"], "executable_sha256": execution["executable_sha256"],
            "input_files_sha256": execution["input_files_sha256"],
            "workspace_inputs_recovered_from_recorded_bytes_and_hashes": True})
    require(builds, "actual Lake receipts required")
    reported = sum(row["actual_lake_status"] != "not_run" for summary in (native, first_summary) for row in summary["attempts"])
    require(len(builds) == reported, "actual receipt count differs from attempt summary")
    results = {"schema": "native-dcec-ui-evidence/v1", "tested_base_revision": base,
        "candidate_sha256": {name: sha(ROOT / name) for name in owned},
        "tests": {"passed": passed, **{key: totals[key] for key in ("skipped", "failures", "errors")},
            "suites": [dict(suite.attrib) for suite in suites], "focused_subsets_not_counted_twice": True},
        "native_regression": native, "native_builds": builds,
        "test_invocations": read(RUN / "test-invocations.json"),
        "prior_native_invocation": {"attempt_count": first_summary["attempt_count"],
            "elapsed_seconds": first_summary["elapsed_seconds"],
            "resource_lease_timeouts": first_timeouts,
            "successful_lake_build_count": sum(row["actual_lake_status"] == "passed" for row in first_summary["attempts"]),
            "complete_unfiltered_receipts_archived": True,
            "source_unchanged": first_summary["all_source_and_input_files_unchanged"],
            "concurrent_workload": "broad pytest regression; repeated unchanged after tests completed"},
        "actual_lake_execution_count": len(builds),
        "actual_lake_execution_count_scope": "native regression invocations; excludes separate installed-tool unit checks",
        "distinct_prepared_jobs_with_successful_lake": len({row["job_id"] for row in builds if row["execution_status"] == "passed"}),
        "native_invocation_count": 2,
        "native_timeouts_remain_visible_not_counted_as_success": True,
        "lake_execution_status_counts": dict(Counter(row["execution_status"] for row in builds)),
        "native_coverage_status_counts": dict(Counter(row["coverage_status"] for row in builds)),
        "attempt_strategy_counts": dict(origins),
        "comparative_analysis": read(RUN / "comparative-analysis.json"),
        "execution_environment": read(RUN / "execution-environment.json"),
        "publication_compatibility": read(RUN / "publication-compatibility.json"),
        "unchanged_local_checkpoints_excluded_from_archive": weights,
        "local_parent_checkpoint_excluded_from_archive": parent,
        "local_embedding_assets_excluded_from_archive": plan["embedding_assets"],
        "replay_scope": "unchanged six previously fitted checkpoints and exposed test rows; authored Intent and explicitly declared UI guard fixtures",
        "source_provenance": {"archive_scope": "exact loaded and explicitly pinned producer code plus candidate and exercised test files",
            "single_final_validation_export": str(SOURCE), "complete_guard_manifests_retained": True,
            "static_assets_not_misreported_as_loaded_producers": True,
            "native_inputs_and_six_existing_checkpoints_rehashed": True},
        "training_executed": False, "training_scope": "native regression; temporary synthetic unit fixtures are not campaign training or convergence evidence",
        "fresh_holdout": False, "weights_modified": False,
        "candidate_rewritten": False, "qualified": False, "admitted": False, "formalized": False,
        "source_semantics_verified": False, "proof_authority": False, "execution_authority": False,
        "production_promotion_performed": False, "constitution_formalized": False,
        "convergence_guarantee": False, "evidence_archive": "evidence.tar.gz"}
    OUT.mkdir(parents=True, exist_ok=True)
    dump(OUT / "results.json", results)
    add(OUT / "results.json", "results.json")
    archive_path = OUT / "evidence.tar.gz"
    with tarfile.open(archive_path, "w:gz", dereference=True) as archive:
        for name, item in sorted(members.items()):
            if isinstance(item, bytes):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(item), 0o644, 0
                archive.addfile(info, io.BytesIO(item))
            else:
                require(describe(item) == metadata[name], "archive input changed: " + name)
                archive.add(item, arcname=name, recursive=False)
    require(archive_path.stat().st_size < 90_000_000, "archive too large; inspect accidental assets")
    with tarfile.open(archive_path, "r:gz") as archive:
        require({row.name for row in archive.getmembers()} == set(metadata), "archive member set differs")
        for member in archive:
            require(member.isfile(), "only regular archive members allowed")
            content = archive.extractfile(member).read()
            require({"sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content)} == metadata[member.name],
                    "archive digest differs: " + member.name)
    manifest = {"schema": "native-dcec-ui-manifest/v1", "tested_base_revision": base,
        "archive": {"path": "evidence.tar.gz", **describe(archive_path)},
        "validated_producer_source_sha256": dict(sorted(pins.items())),
        "validated_producer_source_exports": {name: ["validation-source"] for name in sorted(pins)},
        "validated_producer_source_scopes": {name: sorted(scopes) for name, scopes in sorted(pin_origins.items())},
        "members": dict(sorted(metadata.items()))}
    dump(OUT / "manifest.json", manifest)
    dump(RUN / "owned-files.json", owned + [(OUT / name).relative_to(ROOT).as_posix()
        for name in ("results.json", "manifest.json", "evidence.tar.gz")])
    print(json.dumps({"archive_bytes": manifest["archive"]["bytes"], "members": len(members),
        "producer_files": len(pins), "existing_weight_artifacts_excluded": len(weights),
        "passed": passed, "skipped": totals["skipped"], "actual_lake_executions": len(builds),
        "native_coverage_status_counts": results["native_coverage_status_counts"]}, sort_keys=True))


if __name__ == "__main__":
    main()
