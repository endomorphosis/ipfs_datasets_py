"""Compare all old attempts, including failures; count only actual native passes."""
from collections import Counter
import hashlib, json, platform, sys, xml.etree.ElementTree as ET
from pathlib import Path
RUN=Path(__file__).resolve().parent
OLD=RUN.parent/'intent-ui-gap-repair-20261002/native-r1'
NEW=RUN/'native-r2'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def families(rows):return sorted({r['logic_family'] for r in rows if r['parser_status']=='passed' and r['lake_status']=='passed'})
old,new=read(OLD/'summary.json'),read(NEW/'summary.json')
a={r['attempt_id']:r for r in old['attempts']};b={r['attempt_id']:r for r in new['attempts']}
first=read(RUN/'native-r1/summary.json')
first_rows={r['attempt_id']:r for r in first['attempts']}
selected_paths={identity:NEW/identity/'result.json' for identity in b}
for identity,row in list(b.items()):
    p1=RUN/'native-r1'/identity/'result.json';p2=selected_paths[identity]
    one,two=read(p1),read(p2)
    assert one.get('family_report')==two.get('family_report'),(identity,'report differs between invocations')
    assert one['source_text']==two['source_text'] and one['status']==two['status']
    if row['actual_lake_status']!='passed' and first_rows[identity]['actual_lake_status']=='passed':
        b[identity]=first_rows[identity];selected_paths[identity]=p1

assert len(a)==29 and len(b)==35 and set(a)<set(b)
changes=[];originals=[];inputs={}
for identity,left in a.items():
    right=b[identity]
    lp,rp=OLD/identity/'result.json',selected_paths[identity]
    inputs[str(lp)]=sha(lp);inputs[str(rp)]=sha(rp)
    l,r=read(lp),read(rp)
    assert l['source_text']==r['source_text'] and l['strategy']==r['strategy'] and l['status']==r['status'],identity
    for key in ('replayed_prediction','candidate','reference_target'):
        assert l.get(key)==r.get(key),(identity,key)
    assert l.get('family_report')==r.get('family_report'),(identity,'source-bound report changed')
    before={x['projection_id']:x for x in left['per_projection']}
    after={x['projection_id']:x for x in right['per_projection']}
    assert before.keys()==after.keys(),identity
    for key in before:
        assert before[key]['payload_sha256']==after[key]['payload_sha256'],(identity,key,'payload changed')
        for field in ('parser_status','lake_status','semantic_lowering_supported'):
            if before[key][field]!=after[key][field]:
                changes.append({'attempt_id':identity,'projection_id':key,'field':field,
                    'before':before[key][field],'after':after[key][field]})
    originals.append({'attempt_id':identity,'original_prediction_and_target_unchanged':True,
        'original_report_and_payloads_unchanged':True,'preparation_status':right['preparation_status'],
        'native_observation_path':str(selected_paths[identity].relative_to(RUN)),
        'native_passing_families_before':families(left['per_projection']),
        'native_passing_families_after':families(right['per_projection'])})
expected={'fixture-intent-'+k for k in ('if','if-negative','and','or')}
assert {r['attempt_id'] for r in changes}==expected and len(changes)==12
assert all(r['projection_id']=='rich-intent/dcec/v1' for r in changes)
assert all(b[k]['actual_lake_status']=='passed' and len(families(b[k]['per_projection']))==4 for k in expected)
extra=[]
for identity in sorted(set(b)-set(a)):
    row=b[identity];path=selected_paths[identity];packet=read(path)
    inputs[str(path)]=sha(path)
    ready=sorted({r['logic_family'] for r in packet.get('family_report',{}).get('projections',[]) if r['ready_for_training']})
    extra.append({'attempt_id':identity,'status':row['preparation_status'],'reason':row['reason'],
        'actual_lake_status':row['actual_lake_status'],'prepared_families':ready,
        'native_observation_path':str(path.relative_to(RUN)),
        'native_passing_families':families(row['per_projection']),
        'guard_truth_table_rows':packet.get('source_audit',{}).get('guarded_truth_table_rows'),
        'enabled_edge_count':packet.get('source_audit',{}).get('guarded_enabled_edges'),
        'reachable_nonterminal_deadlocks':packet.get('source_audit',{}).get('reachable_nonterminal_deadlocks'),
        'blocked_projections':[{'projection_id':r['projection_id'],'reason':r['reason']} for r in row['per_projection'] if r['lake_status']!='passed']})
probes=[]
for identity in b:
    p=read(selected_paths[identity])
    probe=p.get('native_check',{}).get('strict_training_gate_probe')
    if probe:
        assert not probe['strict_training_allowed']
        probes.append(identity)
assert len(probes)==new['prepared_native_job_count']==21
result={'schema':'native-dcec-ui-comparison/v1','old_attempt_count':len(a),'new_attempt_count':len(b),
    'old_attempts_retained_unchanged':True,'original_attempts':originals,'changed_projection_statuses':changes,
    'additional_authored_fixtures':extra,'strict_training_probes_rejected':len(probes),
    'prepared_and_native_counts_are_separate':True,'inputs_sha256':inputs,
    'native_scope':'distinct unchanged targets observed across two invocations; every resource timeout retained; no archived receipt used as live training authority',
    'invocation_status_counts':{name:dict(Counter(row['actual_lake_status'] for row in summary['attempts'])) for name,summary in [('native-r1',first),('native-r2',new)]},
    'training_executed':False,'fresh_holdout':False,'qualification_granted':False,'constitution_formalized':False}
dump(RUN/'comparative-analysis.json',result)
xml=ET.parse(RUN/'validation-tests-final.xml').getroot();suites=list(xml.iter('testsuite'))
counts={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ('tests','skipped','failures','errors')}
assert counts['failures']==counts['errors']==0
plan=read(NEW/'plan.json')
dump(RUN/'execution-environment.json',{'schema':'native-dcec-ui-execution-environment/v1',
    'python':sys.version,'platform':platform.platform(),'source_tree':str(RUN/'validation-source'),
    'logic_tree_pin':plan['logic_tree_pin'],'device':'cpu','cuda_visible_devices':'','torch_num_threads':1,
    'offline':True,'weights_downloaded':False,'temperature':0,'max_target_tokens':64,
    'tests':{'passed':counts['tests']-counts['skipped'],**counts,'seconds':sum(float(s.attrib.get('time',0)) for s in suites)},
    'native_tools':plan['tools'],'native_sampling_plan':plan['sampling_plan'],
    'native_seconds':new['elapsed_seconds'],'max_rss_kib':new['max_rss_kib'],
    'rss_scope':new['rss_scope'],'bridge_on_legal_ir_evaluation_performed':False,
    'external_solver_diagnostics_executed':False,'fresh_holdout':False,'training_executed':False,
    'qualification_granted':False,'cache_scope':'warm model replay followed by source audit/preparation; native builds use fresh workspaces',
    'test_invocations':read(RUN/'test-invocations.json'),
    'resource_pressure_observation':read(RUN/'live-resource-observation.json'),
    'native_success_scope':'21 distinct prepared targets across two unchanged invocations; failed leases remain reported'})
print(json.dumps({'tests':counts,'native_seconds':new['elapsed_seconds'],'old_attempts_unchanged':29,
    'DCEC_boolean_cases_fixed':4,'extra':extra,'strict_training_probes_rejected':len(probes)},indent=2))
