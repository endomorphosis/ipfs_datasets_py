"""Freeze additive candidates without mutating hard-linked source snapshots."""
import hashlib, json, os, shutil, subprocess
from pathlib import Path
ROOT = Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN = Path(__file__).resolve().parent
names = [
'ipfs_datasets_py/logic/formalization/autoencoder/strict_dcec_functional.py',
'ipfs_datasets_py/logic/formalization/autoencoder/native_family_lean_emitters_v6.py',
'ipfs_datasets_py/logic/formalization/autoencoder/native_family_lake_v6.py',
'ipfs_datasets_py/logic/formalization/autoencoder/projection_validation_contract_v6.py',
'ipfs_datasets_py/logic/formalization/autoencoder/parallel_projection_checks_v2.py',
'ipfs_datasets_py/logic/formalization/autoencoder/native_ui_guarded_lean.py',
'ipfs_datasets_py/logic/formalization/autoencoder/ui_source_contract_384_v4.py',
'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_family_training_validated_v6.py',
'scripts/ops/autoencoder/check_native_dcec_ui.py',
 'tests/fixtures/logic/native_dcec_ui_v1/guard_cases.py',
]
for stem in ('strict_dcec_functional','native_family_lean_emitters_v6','native_family_validation_v6',
             'parallel_projection_checks_v2','ui_source_contract_384_v4'):
    p='tests/unit/logic/formalization/autoencoder/test_'+stem+'.py'
    assert (ROOT/p).is_file(),p
    names.append(p)
for p in ('tests/unit/optimizers/logic_theorem_optimizer/test_autoencoder_family_training_validated_v6.py',):
    if (ROOT/p).exists():names.append(p)
assert len(names)==len(set(names))
source=RUN/'validation-source'
assert not source.exists()
shutil.copytree(RUN/'source',source,copy_function=os.link,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
frozen={}
for name in names:
    data=(ROOT/name).read_bytes()
    target=source/name;target.parent.mkdir(parents=True,exist_ok=True)
    target.unlink(missing_ok=True)
    target.write_bytes(data)
    frozen[name]=hashlib.sha256(data).hexdigest()
subprocess.check_call(['git','init','-q'],cwd=source)
(RUN/'candidate-files.json').write_text(json.dumps(names,indent=2)+'\n')
(RUN/'frozen-candidates.json').write_text(json.dumps(frozen,indent=2)+'\n')
print(json.dumps({'source':str(source),'files':len(names)}))
