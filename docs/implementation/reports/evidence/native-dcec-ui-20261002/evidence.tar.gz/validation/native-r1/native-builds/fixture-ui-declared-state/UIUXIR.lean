-- Actual native interpretation declarations; no source truth asserted.

namespace UIUXIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_0
def declaredStates : List String := ["closed", "open"]
def declaredEdges : List (String × String × String) := [("close_event", "open", "closed")]
def declaredInitiates : List (String × String) := [("close_event", "closed")]
def declaredTerminates : List (String × String) := [("close_event", "open")]
def step (event beforeState afterState : String) : Prop := (event, beforeState, afterState) ∈ declaredEdges
def initiates (event state : String) : Prop := (event, state) ∈ declaredInitiates
def terminates (event state : String) : Prop := (event, state) ∈ declaredTerminates
def sourceReferences : List (List String) := [[], [], [], [], []]
theorem declared_edge_0 : step "close_event" "open" "closed" := by simp [step, declaredEdges]
end Projection_0

namespace Projection_1
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ((fun t => ((fun t => ((fun t => ((fun t => ((fun t => i.atom "UIAccessibleDescriptionRef" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_accessible_description_ref:v")] t) t) ∧ ((fun t => ((fun t => i.atom "UIAccessibleDescriptionRef" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_accessible_description_ref:v")] t) t) ∧ ((fun t => i.atom "UIAccessibleDescriptionRef" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_accessible_description_ref:v")] t) t)) t)) t) ∧ ((fun t => ((fun t => i.atom "UIAccessibleNameRef" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_accessible_name_ref:v")] t) t) ∧ ((fun t => ((fun t => i.atom "UIAccessibleNameRef" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_accessible_name_ref:v")] t) t) ∧ ((fun t => i.atom "UIAccessibleNameRef" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_accessible_name_ref:v")] t) t)) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIChildAt" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_list_position:v30"), (i.constant "ui_component:v625f6368696c64")] t) t) ∧ ((fun t => ((fun t => i.atom "UIChildAt" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_list_position:v31"), (i.constant "ui_component:v615f6368696c64")] t) t) ∧ ((fun t => i.atom "UIChildListLength" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_list_length:v30")] t) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIChildListLength" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_list_length:v30")] t) t) ∧ ((fun t => i.atom "UIChildListLength" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_list_length:v32")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIComponent" [(i.constant "ui_component:v615f6368696c64")] t) t) ∧ ((fun t => i.atom "UIComponent" [(i.constant "ui_component:v625f6368696c64")] t) t)) t)) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => ((fun t => i.atom "UIComponent" [(i.constant "ui_component:v726f6f74")] t) t) ∧ ((fun t => ((fun t => i.atom "UICompositionEdge" [(i.constant "ui_composition_edge:v736c6f745f65646765"), (i.constant "ui_edge_kind:v736c6f74"), (i.constant "ui_component:v726f6f74"), (i.constant "ui_component:v615f6368696c64")] t) t) ∧ ((fun t => i.atom "UICompositionEdgeSetSize" [(i.constant "ui_document:v7569"), (i.constant "ui_set_size:v31")] t) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIDataBindingSetSize" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => i.atom "UIDataBindingSetSize" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_set_size:v30")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIDataBindingSetSize" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => i.atom "UIDeclaredComponentSetSize" [(i.constant "ui_document:v7569"), (i.constant "ui_set_size:v33")] t) t)) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIDocumentComponent" [(i.constant "ui_document:v7569"), (i.constant "ui_component:v615f6368696c64")] t) t) ∧ ((fun t => ((fun t => i.atom "UIDocumentComponent" [(i.constant "ui_document:v7569"), (i.constant "ui_component:v625f6368696c64")] t) t) ∧ ((fun t => i.atom "UIDocumentComponent" [(i.constant "ui_document:v7569"), (i.constant "ui_component:v726f6f74")] t) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIDocumentEdge" [(i.constant "ui_document:v7569"), (i.constant "ui_composition_edge:v736c6f745f65646765")] t) t) ∧ ((fun t => i.atom "UIEdgeSlot" [(i.constant "ui_composition_edge:v736c6f745f65646765"), (i.constant "ui_slot_name:v6d61696e")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIEdgeSourceRefSetSize" [(i.constant "ui_composition_edge:v736c6f745f65646765"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => i.atom "UIEmptyParentField" [(i.constant "ui_component:v726f6f74")] t) t)) t)) t)) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => ((fun t => ((fun t => i.atom "UIEntryComponent" [(i.constant "ui_document:v7569"), (i.constant "ui_component:v726f6f74")] t) t) ∧ ((fun t => ((fun t => i.atom "UIEntrySetSize" [(i.constant "ui_document:v7569"), (i.constant "ui_set_size:v31")] t) t) ∧ ((fun t => i.atom "UIFeedbackSetSize" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_set_size:v30")] t) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIFeedbackSetSize" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => i.atom "UIFeedbackSetSize" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_set_size:v30")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIModalityBindingSetSize" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => i.atom "UIModalityBindingSetSize" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_set_size:v30")] t) t)) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIModalityBindingSetSize" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => ((fun t => i.atom "UIParent" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_component:v726f6f74")] t) t) ∧ ((fun t => i.atom "UIParent" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_component:v726f6f74")] t) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIPresentation" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_presentation:v696e746572616374697665")] t) t) ∧ ((fun t => i.atom "UIPresentation" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_presentation:v696e746572616374697665")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIPresentation" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_presentation:v696e746572616374697665")] t) t) ∧ ((fun t => i.atom "UIPrivacy" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_privacy:v6e6f6e65")] t) t)) t)) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => ((fun t => i.atom "UIPrivacy" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_privacy:v6e6f6e65")] t) t) ∧ ((fun t => ((fun t => i.atom "UIPrivacy" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_privacy:v6e6f6e65")] t) t) ∧ ((fun t => i.atom "UIProgramBindingSetSize" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_set_size:v30")] t) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIProgramBindingSetSize" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => i.atom "UIProgramBindingSetSize" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_set_size:v30")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIPurposeText" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_purpose:v")] t) t) ∧ ((fun t => i.atom "UIPurposeText" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_purpose:v")] t) t)) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIPurposeText" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_purpose:v")] t) t) ∧ ((fun t => ((fun t => i.atom "UIRole" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_role:v627574746f6e")] t) t) ∧ ((fun t => i.atom "UIRole" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_role:v74657874626f78")] t) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIRole" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_role:v67726f7570")] t) t) ∧ ((fun t => i.atom "UISourceRefSetSize" [(i.constant "ui_component:v615f6368696c64"), (i.constant "ui_set_size:v30")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UISourceRefSetSize" [(i.constant "ui_component:v625f6368696c64"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => i.atom "UISourceRefSetSize" [(i.constant "ui_component:v726f6f74"), (i.constant "ui_set_size:v30")] t) t)) t)) t)) t)) t)) t))
end Projection_1

namespace Projection_2
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "a_child") "ui_component" (i.constant "button")
def frame_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "b_child") "ui_component" (i.constant "textbox")
def frame_2 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "root") "ui_component" (i.constant "group")
def frame_3 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "root") "ui_contains" (i.constant "a_child")
def frame_4 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "root") "ui_contains" (i.constant "b_child")
def frame_5 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "root") "ui_parent" (i.constant "a_child")
def frame_6 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "root") "ui_parent" (i.constant "b_child")
def frame_7 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "root") "ui_rel_slot" (i.constant "a_child")
end Projection_2

namespace Projection_3
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["state_0", "state_1"])
def predicate_0 (s : State) : Prop := (s.v0 = "state_1")
def predicate_1 (s : State) : Prop := (s.v0 = "state_1")
def predicate_2 (s : State) : Prop := (s.v0 = "state_0")
def initial (s : State) : Prop := typeOK s ∧ (predicate_1 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:ui-state"].contains variableName
example : ["var:ui-state"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_2 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:ui:0" ∧ action_0 s t)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
def sourceVariableAliases : List (String × String) := [("var:ui-state", "v0"), ("ui_state", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := [("action:ui:0", "close", "close_event")]
def syntheticActionOrigins : List (String × String) := []
def sourceUIDocument : String := "ui-candidate:ea5f7c5a8f7edc6b5b14fa44b009271b413476ee200c3581ac312ac82e83d831"
def sourceUIModel : String := "declared_behavior"
def sourceUISHA256 : String := "23c20f5bd84f2002662f323f57a952808cecfd29a1e9e5778f71a6ac31f4ed57"
def uiStateMap : List (String × String) := [("closed", "state_0"), ("open", "state_1")]
def uiTerminalStates : List String := ["state_0"]
def uiTerminal (s : State) : Prop := s.v0 ∈ uiTerminalStates
def uiDeclaredCancelable (action : String) : Bool := ["action:ui:0"].contains action
def cancellationExecutionModeled : Bool := false
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 64
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:ui:0"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

end Projection_3

namespace Projection_4
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["state_0", "state_1"])
def predicate_0 (s : State) : Prop := (s.v0 = "state_1")
def predicate_1 (s : State) : Prop := (s.v0 = "state_1")
def predicate_2 (s : State) : Prop := (s.v0 = "state_0")
def initial (s : State) : Prop := typeOK s ∧ (predicate_1 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:ui-state"].contains variableName
example : ["var:ui-state"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_2 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:ui:0" ∧ action_0 s t)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
end Projection_4

end UIUXIR

