"""Retain every invocation; report each final test outcome once after isolation."""
import json, xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path
RUN=Path(__file__).resolve().parent
paths=[RUN/'validation-tests-r2.xml',RUN/'validation-legacy-isolated.xml',RUN/'validation-native-tool-tests.xml']
rows={};history=[]
for path in paths:
    root=ET.parse(path).getroot()
    cases=list(root.iter('testcase'))
    history.append({'path':path.name,'tests':len(cases),
        'failed':sum(c.find('failure') is not None for c in cases),
        'errors':sum(c.find('error') is not None for c in cases),
        'skipped':sum(c.find('skipped') is not None for c in cases)})
    for row in cases:
        key=(row.attrib['classname'],row.attrib['name'])
        if path!=paths[0]:assert key in rows,('unexpected retry test',key)
        rows[key]=deepcopy(row)
assert len(rows)==919
assert all(all(row.find(k) is None for k in ('failure','error','skipped')) for row in rows.values())
out=ET.Element('testsuites')
suite=ET.SubElement(out,'testsuite',name='deduplicated_final_isolated_outcomes',tests=str(len(rows)),errors='0',failures='0',skipped='0',time=str(sum(float(r.attrib.get('time',0)) for r in rows.values())))
for _,row in sorted(rows.items()):suite.append(row)
ET.ElementTree(out).write(RUN/'validation-tests-final.xml',encoding='utf-8',xml_declaration=True)
(RUN/'test-invocations.json').write_text(json.dumps({'schema':'native-dcec-ui-test-outcomes/v1',
    'unique_final_passed':len(rows),'invocations':history,
    'initial_harness_configuration_error':'validation-tests-r1.log: required repository cache provider disabled',
    'isolation_reason':'Earlier suite pinned the old v2 owner before legacy tests replaced its _execute function. Isolated legacy tests pass without weakening source-provenance checks.',
    'real_tool_retry_reason':'Eight installed-tool checks require explicit Lake executable; all eight run and passed with installed local tool.',
    'deduplicated':True,'production_source_changed_for_test_retries':False},indent=2)+'\n')
print(json.dumps(history))
