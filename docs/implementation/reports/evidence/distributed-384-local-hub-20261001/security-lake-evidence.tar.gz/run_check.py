"""Reproduce source-bound Lake checks of the actually merged Security weights."""
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import time

from ipfs_datasets_py.logic.formalization.autoencoder.source_program_runtime_384 import (
    load_source_program_decoder_384, build_decoded_source_program_lake,
)
from ipfs_datasets_py.logic.formalization.autoencoder.source_program_lake_384 import (
    prepare_source_program_lean, verify_source_program_lake,
)

ROOT = Path('/home/barberb/lift_coding/artifacts/distributed384-20261001/run-01')
OUT = ROOT / 'security-lake'
LAKE = '/home/barberb/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake'


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def reference(path):
    value = Path(path).read_bytes()
    return dict(path=str(Path(path).resolve()), sha256=sha(value), bytes=len(value))


def save(name, value):
    path = OUT / name
    with path.open('xb') as stream:
        stream.write(raw(value))
    return reference(path)


def main():
    started = time.perf_counter()
    merged_path = ROOT / 'security_ir/merged-result.json'
    validation_path = ROOT / 'security_ir/coordinator/validation.json'
    plan_path = ROOT / 'security_ir/coordinator/plan.json'
    merged = json.loads(merged_path.read_bytes())
    checkpoint_path = Path(merged['checkpoint_path'])
    watched = [merged_path, validation_path, plan_path, checkpoint_path, Path(__file__)]
    before = [reference(path) for path in watched]
    # Select only closed inference fields before the runtime is invoked. There
    # is no target, split, group ID, tuning label or projection in this input.
    source_inputs = [{key: row[key] for key in ('id', 'source_text', 'embedding')}
                     for row in json.loads(validation_path.read_bytes())]
    assert len(source_inputs) == 120
    input_artifact = save('inference-inputs.json', source_inputs)
    print(json.dumps(dict(phase='loading_real_checkpoint', rows=len(source_inputs),
                         checkpoint=reference(checkpoint_path))), flush=True)
    runtime = load_source_program_decoder_384(checkpoint_path,
        expected_sha256=reference(checkpoint_path)['sha256'], decoder='structured')
    inference_started = time.perf_counter()
    report = runtime.infer(source_inputs)
    inference_seconds = time.perf_counter() - inference_started
    inference_artifact = save('inference-report.json', report)
    source_rows = [{key: row[key] for key in ('id', 'source_text')} for row in source_inputs]
    by_id = {row['id']: row for row in source_rows}
    gate_inputs = [dict(id=row['id'], source_text=by_id[row['id']]['source_text'],
                        candidate_ir=deepcopy(row['candidate_ir'])) for row in report['rows']]
    candidate_artifact = save('decoded-source-candidates.json', gate_inputs)
    before_candidates = sha(raw(gate_inputs))
    prepared = prepare_source_program_lean(gate_inputs)
    prepared_artifact = save('prepared.json', prepared)
    print(json.dumps(dict(phase='running_native_lake', supported=sum(
        row['semantic_lowering_supported'] for row in prepared['rows']),
        lean_source_bytes=len(prepared['lean_source'].encode()),
        qualifications=dict(Counter(row['source_qualification']['status'] for row in prepared['rows'])))), flush=True)
    lake_started = time.perf_counter()
    execution = build_decoded_source_program_lake(report, source_rows, lake_executable=LAKE,
        timeout_seconds=60, output_directory=OUT / 'lake-build')
    verified = verify_source_program_lake(execution, gate_inputs)
    lake_seconds = time.perf_counter() - lake_started
    verification_artifact = save('verified-live-receipt.json', verified)
    assert before_candidates == sha(raw(gate_inputs)), 'candidates changed during build'
    for actual, decoded in zip(verified['rows'], report['rows']):
        assert actual['id'] == decoded['id']
        assert actual['source_qualification'] == decoded['source_contract']

    # An explicit source-drift negative control keeps the decoded candidate
    # fixed. It is an input-contract check and does not execute source Python.
    changed = deepcopy(gate_inputs[0])
    assert ' + ' in changed['source_text']
    changed['source_text'] = changed['source_text'].replace(' + ', ' - ', 1)
    negative = prepare_source_program_lean([changed])
    assert negative['rows'][0]['source_qualification']['status'] == 'mismatch'
    assert negative['rows'][0]['semantic_lowering_supported'] is False
    assert negative['backend_executed'] is False
    negative_artifact = save('source-drift-negative-control.json', negative)

    after = [reference(path) for path in watched]
    assert before == after, 'input or producer file changed'
    family_counts = merged['report']['projection_evidence']['family_counts']
    summary = dict(schema='distributed384-security-source-lake-check/v1',
        status=verified['status'], count=verified['count'], supported_count=verified['supported_count'],
        lake_passed_count=sum(row['lake_status'] == 'passed' for row in verified['rows']),
        source_qualification_counts=dict(Counter(row['source_qualification']['status'] for row in verified['rows'])),
        backend_executed=verified['backend_executed'], live_issued_handle_verified=True,
        all_candidates_compiled=verified['all_candidates_compiled'],
        checkpoint=reference(checkpoint_path), checkpoint_runtime=runtime.describe(),
        plan_id=merged['plan_id'], evaluation_split='validation_used_for_ridge_selection',
        embedding_source='existing pinned coordinator validation vectors; embedding inference not rerun',
        inference_input_fields=['id', 'source_text', 'embedding'], target_access=False,
        source_python_executed=False, candidate_rewritten=False, source_replay_matches_decoder_qualification=True,
        inferred_operator_counts=dict(Counter(row['candidate_ir']['document']['operator'] for row in report['rows'])),
        execution=verified['execution'], tool_binary_sha256=verified['tool_binary_sha256'],
        program_scope=verified['scope'], assumptions=verified['assumptions'],
        other_family_gaps={family: values for family, values in family_counts.items() if family != 'program'},
        all_security_families_checked=False, negative_control_source_status='mismatch',
        negative_control_lowering_supported=False,
        inference_seconds=inference_seconds, lake_build_and_live_verification_seconds=lake_seconds,
        total_seconds=time.perf_counter()-started, input_artifacts_before=before, input_artifacts_after=after,
        artifacts=dict(inputs=input_artifact, inference=inference_artifact, candidates=candidate_artifact,
                       prepared=prepared_artifact, verified=verification_artifact, negative_control=negative_artifact),
        proof_authority=False, source_semantics_verified=False, whole_program_semantics_verified=False,
        security_specification_proved=False, execution_authority=False, admitted=False, promotion_performed=False)
    save('summary.json', summary)
    print(json.dumps({key: summary[key] for key in ('status', 'count', 'supported_count', 'lake_passed_count',
        'backend_executed', 'all_candidates_compiled', 'inference_seconds',
        'lake_build_and_live_verification_seconds', 'total_seconds')}), flush=True)
    return 0 if verified['all_candidates_compiled'] else 2


if __name__ == '__main__':
    sys.exit(main())
