namespace SecuritySourcePrograms

namespace Candidate_0
def sourceEvidenceOriginalProgramSHA256 : String := "cb9b1ab45424a220cd762c7673ca5406960fcef8d25958edb7a4af558526baa8"

def sourceEvidenceOperationalViewSHA256 : String := "1d5cdff70b17b2551e3831cbd9dfdd9a8913d48db09227eceaacafd6884498a3"

def sourceEvidenceSourceSHA256 : String := "0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicnoxhe32s2zzvuy2f3b76ts4zvc2snocwhrn6gszb2cdij66c62q\",\"base_program_sha256\":\"3c3fcad37486fe9c2dc95e5416a5d6c946a327669d8bb9ad9b4dca74ea9caa4d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":82,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicnoxhe32s2zzvuy2f3b76ts4zvc2snocwhrn6gszb2cdij66c62q\",\"base_program_sha256\":\"3c3fcad37486fe9c2dc95e5416a5d6c946a327669d8bb9ad9b4dca74ea9caa4d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_0

namespace Candidate_1
def sourceEvidenceOriginalProgramSHA256 : String := "f7af0e841bc0d52d34a772dda6c9d54d83dc817e9c174bd2112fa9fa02b45000"

def sourceEvidenceOperationalViewSHA256 : String := "c270ec6bebaed9c622c5e5576f99b22938585fee2a31d5273c6c66d16e3676ca"

def sourceEvidenceSourceSHA256 : String := "985ff78e77e1d7e873453f0f71c90cc65aef1178aa8e11ce7e6fd309c774984d"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreih5auskl45phnxvpkbspn62vfwxx4gaxixmloxljl47rzboxflx44\",\"base_program_sha256\":\"de46cd70c2870231eaf2c73d6f03a4d696ed6f77ffd35bd30be52767da5ef24b\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"985ff78e77e1d7e873453f0f71c90cc65aef1178aa8e11ce7e6fd309c774984d\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"985ff78e77e1d7e873453f0f71c90cc65aef1178aa8e11ce7e6fd309c774984d\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":82,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreih5auskl45phnxvpkbspn62vfwxx4gaxixmloxljl47rzboxflx44\",\"base_program_sha256\":\"de46cd70c2870231eaf2c73d6f03a4d696ed6f77ffd35bd30be52767da5ef24b\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_1

namespace Candidate_2
def sourceEvidenceOriginalProgramSHA256 : String := "abbe5639ba559a9805310205d8b8af4e38711d1542ef9b1c11f5ea3e64bf232a"

def sourceEvidenceOperationalViewSHA256 : String := "5ec502bb24e065718298673dcc3b606f7ac07a0640f563fe4be6dde0439e8f68"

def sourceEvidenceSourceSHA256 : String := "b0a6b80524dc313a3d671b85c51314097063536b3ee84e5d0de948fe43d91165"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiauwh3qpueugpkuoz273kbob2ovzyij5iype7jsf37kdfomwc6cwi\",\"base_program_sha256\":\"4f92f03d708c922a65d23100ae8c67c4e3c8879c0e8d1cd2e56d501e04f73181\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"b0a6b80524dc313a3d671b85c51314097063536b3ee84e5d0de948fe43d91165\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"b0a6b80524dc313a3d671b85c51314097063536b3ee84e5d0de948fe43d91165\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":83,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiauwh3qpueugpkuoz273kbob2ovzyij5iype7jsf37kdfomwc6cwi\",\"base_program_sha256\":\"4f92f03d708c922a65d23100ae8c67c4e3c8879c0e8d1cd2e56d501e04f73181\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_2

namespace Candidate_3
def sourceEvidenceOriginalProgramSHA256 : String := "6ed6145736aa4cd912fc76c4b0e71c3bb0677a6adc26fba29da083940fa92c1a"

def sourceEvidenceOperationalViewSHA256 : String := "c5e0d8f823031e9d656fd71edcee58e1d9d0e7aebcf95805ac320860f29da25f"

def sourceEvidenceSourceSHA256 : String := "4c304b2034397b686dff882ff00607a4433c93ce9100ae49635bb2eb59facea4"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreig5pvdznwdy5fwjhfctilugygcu5tuimauaxaxpm6q4id5usnqr2e\",\"base_program_sha256\":\"9a1d83c6e07fc5c6bf1b1b073f69062aafb033434f9465fcf7d816018798a8a3\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"4c304b2034397b686dff882ff00607a4433c93ce9100ae49635bb2eb59facea4\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"4c304b2034397b686dff882ff00607a4433c93ce9100ae49635bb2eb59facea4\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":82,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreig5pvdznwdy5fwjhfctilugygcu5tuimauaxaxpm6q4id5usnqr2e\",\"base_program_sha256\":\"9a1d83c6e07fc5c6bf1b1b073f69062aafb033434f9465fcf7d816018798a8a3\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 - current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_3

namespace Candidate_4
def sourceEvidenceOriginalProgramSHA256 : String := "454312064f28bbe60dfcaf28e7ebe8e48c031ca4ce7635ba31db671b38be8635"

def sourceEvidenceOperationalViewSHA256 : String := "0da888956ecc32c01f7652d91ebf2924f882307f9f7921d46efeaf631eeffc5f"

def sourceEvidenceSourceSHA256 : String := "f606583b7c4894a6dd1a7e59e2213156c922b2121456a33a96a2f5105497034a"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihswggvhd6httbymlwqlekb5ky6w4wrsticnz2ubmwjhval7etala\",\"base_program_sha256\":\"f04ccec039ca9d444e311f7cceee85014a47ca76c80fdda736570091f0589517\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"f606583b7c4894a6dd1a7e59e2213156c922b2121456a33a96a2f5105497034a\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"f606583b7c4894a6dd1a7e59e2213156c922b2121456a33a96a2f5105497034a\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":82,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihswggvhd6httbymlwqlekb5ky6w4wrsticnz2ubmwjhval7etala\",\"base_program_sha256\":\"f04ccec039ca9d444e311f7cceee85014a47ca76c80fdda736570091f0589517\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 - current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_4

namespace Candidate_5
def sourceEvidenceOriginalProgramSHA256 : String := "2d502d35b6abca53a8b2c1c4113461af0339fbf3495f9da7a0747a34996f5dac"

def sourceEvidenceOperationalViewSHA256 : String := "804a345daa2757dd9a372b9ec0431f0d93770e21526dd0073e7d3e956f325a0d"

def sourceEvidenceSourceSHA256 : String := "c9eb5dfc7a86d0c3740d24d44d8e213dc113c359ab5095aa8c2c665ee82c1079"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihxdoyzmwkhoek4bgw6irn4vq7gendpwoqowcrekdkye63adhkk2u\",\"base_program_sha256\":\"cbad65a6cb6ec86c20b5dc0dd7bb1918af315da9077bf2f3fd15407b7a913b7c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"c9eb5dfc7a86d0c3740d24d44d8e213dc113c359ab5095aa8c2c665ee82c1079\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"c9eb5dfc7a86d0c3740d24d44d8e213dc113c359ab5095aa8c2c665ee82c1079\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":83,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihxdoyzmwkhoek4bgw6irn4vq7gendpwoqowcrekdkye63adhkk2u\",\"base_program_sha256\":\"cbad65a6cb6ec86c20b5dc0dd7bb1918af315da9077bf2f3fd15407b7a913b7c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 - current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_5

namespace Candidate_6
def sourceEvidenceOriginalProgramSHA256 : String := "7d35cffb991cfba7779583a84b856cd0cf1ab2389242ba5e34b0290dcf19ae83"

def sourceEvidenceOperationalViewSHA256 : String := "28143778319d39cf766dadd91bb3860758fcc5ada4c58c4c3d8fd8da3214bd30"

def sourceEvidenceSourceSHA256 : String := "8a568232d82ab7e9a08afd62e7bd9f7a00f41815858eefc8cee12b359c4e285f"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihkst6in2ux4hiqw7ufqjrw5gnbua5d37ngmyzxypblzmt4dat7gi\",\"base_program_sha256\":\"3b197a57bd50a367dd8c4c70260898288a5ddbf3481784cd17a28789265cc0b9\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"8a568232d82ab7e9a08afd62e7bd9f7a00f41815858eefc8cee12b359c4e285f\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"8a568232d82ab7e9a08afd62e7bd9f7a00f41815858eefc8cee12b359c4e285f\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":125,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihkst6in2ux4hiqw7ufqjrw5gnbua5d37ngmyzxypblzmt4dat7gi\",\"base_program_sha256\":\"3b197a57bd50a367dd8c4c70260898288a5ddbf3481784cd17a28789265cc0b9\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_6

namespace Candidate_7
def sourceEvidenceOriginalProgramSHA256 : String := "e0818182f94d6508622eafdbf002b0ee552d2585987faae108c3cbcb211faa9e"

def sourceEvidenceOperationalViewSHA256 : String := "08050a4ce65ae76a1a3842f691d12d2823a201722a35fe42f408a1f23c9e39bf"

def sourceEvidenceSourceSHA256 : String := "61139883357b9b2ddcaa05247aacb75e063fe50dbd2a6b97dbb4cd26ed64b68e"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreigt4ofbq3cstsv6hbttcevp6coygb6glzd4gm3srhttmb6ydx7uge\",\"base_program_sha256\":\"1d40aaf4718c009208b88da676d5ba1f1d8e5b7786aa9356c13580ec1a7a13bf\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"61139883357b9b2ddcaa05247aacb75e063fe50dbd2a6b97dbb4cd26ed64b68e\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"61139883357b9b2ddcaa05247aacb75e063fe50dbd2a6b97dbb4cd26ed64b68e\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":125,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreigt4ofbq3cstsv6hbttcevp6coygb6glzd4gm3srhttmb6ydx7uge\",\"base_program_sha256\":\"1d40aaf4718c009208b88da676d5ba1f1d8e5b7786aa9356c13580ec1a7a13bf\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_7

namespace Candidate_8
def sourceEvidenceOriginalProgramSHA256 : String := "cdd71fcc5cb645b73384b4ddf44a31e884184b84f833cee1c566a0c9bb5c9f0b"

def sourceEvidenceOperationalViewSHA256 : String := "7b8ca126c3cdda05e8d597db5b127fe99c2b0aa047da425843ac7625fc7e89ae"

def sourceEvidenceSourceSHA256 : String := "6f7e79945b8e463a10ceeee8bd04fe414ca63ffd244d6bee4cf952800bf8dfc6"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreigy5eacbcvwbbxzlv2sgdofvypswvddc2pbfyxzlzaog6pgcgrlxm\",\"base_program_sha256\":\"2cab7ca72489b543fbca7818e6a0143f5e36706df0455952923e16393522a3d5\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"6f7e79945b8e463a10ceeee8bd04fe414ca63ffd244d6bee4cf952800bf8dfc6\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"6f7e79945b8e463a10ceeee8bd04fe414ca63ffd244d6bee4cf952800bf8dfc6\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":126,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreigy5eacbcvwbbxzlv2sgdofvypswvddc2pbfyxzlzaog6pgcgrlxm\",\"base_program_sha256\":\"2cab7ca72489b543fbca7818e6a0143f5e36706df0455952923e16393522a3d5\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_8

namespace Candidate_9
def sourceEvidenceOriginalProgramSHA256 : String := "cab42a5ec00f414f5eb56523c6fa159e95af1f8c98ac2db155045bfaf4cc5e9c"

def sourceEvidenceOperationalViewSHA256 : String := "23d0c4c90d62238c1f51e5edd4cfefc3600a5d5726d820d65a1104140c3d4c42"

def sourceEvidenceSourceSHA256 : String := "46c0e98a860b71107492293333c3045b89015af4bed6f35f48fec2c35640481a"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreieziprdghv4xrjsb6qg6ivvlsbxwoztiftf2kg7g6zbctjryo77ea\",\"base_program_sha256\":\"416f6cdbbd2dea99fabac5f4b97ab065e287ba7e28ab0ebaba0daf286e119a27\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"46c0e98a860b71107492293333c3045b89015af4bed6f35f48fec2c35640481a\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"46c0e98a860b71107492293333c3045b89015af4bed6f35f48fec2c35640481a\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":125,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreieziprdghv4xrjsb6qg6ivvlsbxwoztiftf2kg7g6zbctjryo77ea\",\"base_program_sha256\":\"416f6cdbbd2dea99fabac5f4b97ab065e287ba7e28ab0ebaba0daf286e119a27\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 - current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_9

namespace Candidate_10
def sourceEvidenceOriginalProgramSHA256 : String := "4b6f3981c3a7539a9eaf5958e93345bb64868a4ef968e5728cc7bd9d428b0498"

def sourceEvidenceOperationalViewSHA256 : String := "2a72a500820acddc30610ba30cc949eb2a29b9c15b15448721e5bad16c098635"

def sourceEvidenceSourceSHA256 : String := "cce339405a3724c9a1b3a76cd11e7ae97cdee52f314df2ebb3bf7361209c96ce"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicwntufv67rj74csoukfbxdqb7occdqetaebwfbgpyhxlhozwzkqa\",\"base_program_sha256\":\"17ef6d01f5a03647321df44aac3d31620829aab95eb4d139536be9d94ece49ba\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"cce339405a3724c9a1b3a76cd11e7ae97cdee52f314df2ebb3bf7361209c96ce\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"cce339405a3724c9a1b3a76cd11e7ae97cdee52f314df2ebb3bf7361209c96ce\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":125,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicwntufv67rj74csoukfbxdqb7occdqetaebwfbgpyhxlhozwzkqa\",\"base_program_sha256\":\"17ef6d01f5a03647321df44aac3d31620829aab95eb4d139536be9d94ece49ba\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 - current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_10

namespace Candidate_11
def sourceEvidenceOriginalProgramSHA256 : String := "4f175d65fd7e8f6efc71f58b92d149fd3e62f59248c2eb99c919b5c0f9cd5281"

def sourceEvidenceOperationalViewSHA256 : String := "a97c66778a4294ae298e27ec4e95f50bc8ae269b1f94995c4b92c585e657ef55"

def sourceEvidenceSourceSHA256 : String := "2376ba723e199b679a8501f5ed6cd12a0d602930602974c290207dd7249e3bbc"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreienmigwstmfvbeqzhgxmdfxehjm6ask3ppwd7dfe44qkq33mcepge\",\"base_program_sha256\":\"e3ee7e0c657064978e69ab5d0bf4347b01f26fc5b023204094176c449902f33a\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"2376ba723e199b679a8501f5ed6cd12a0d602930602974c290207dd7249e3bbc\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"2376ba723e199b679a8501f5ed6cd12a0d602930602974c290207dd7249e3bbc\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":126,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreienmigwstmfvbeqzhgxmdfxehjm6ask3ppwd7dfe44qkq33mcepge\",\"base_program_sha256\":\"e3ee7e0c657064978e69ab5d0bf4347b01f26fc5b023204094176c449902f33a\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 - current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_11

namespace Candidate_12
def sourceEvidenceOriginalProgramSHA256 : String := "7826c9b6cc51fb726e9b1b90a9b689ee9f33c357548add95ab3f9685fb300ea2"

def sourceEvidenceOperationalViewSHA256 : String := "beea3dfa6df20b5d121d1445192f1dcbe349d9467e5574cb0a9fa16f84179b4e"

def sourceEvidenceSourceSHA256 : String := "8364d356f4594c839cbcfb5811c71e8c384220c5f21f400952f99a4312f0342a"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiaeondxhmun3ci7a27hjnzede74g7wp7foebydxirgip5u4o55hja\",\"base_program_sha256\":\"15e3cfca80bb2abcc3cf1a782e9c448f53c9c31fdac95baebb1b34f9dc9482ca\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"8364d356f4594c839cbcfb5811c71e8c384220c5f21f400952f99a4312f0342a\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"8364d356f4594c839cbcfb5811c71e8c384220c5f21f400952f99a4312f0342a\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":104,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiaeondxhmun3ci7a27hjnzede74g7wp7foebydxirgip5u4o55hja\",\"base_program_sha256\":\"15e3cfca80bb2abcc3cf1a782e9c448f53c9c31fdac95baebb1b34f9dc9482ca\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v1

def expression_2 (initial current : Store) (returned : Int) : Int := current.v0

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.outcome.local"].contains symbol

example : (["symbol:derive.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_12

namespace Candidate_13
def sourceEvidenceOriginalProgramSHA256 : String := "b85371b5ab64ee689aa36168e9bda76545da851be26e9eb953a8e40fe283071d"

def sourceEvidenceOperationalViewSHA256 : String := "08799b5f05bb4b86e236ceba7c79e25ebff3acca6640cb609a742948211fa0c9"

def sourceEvidenceSourceSHA256 : String := "f0522dadb68086a7c144190815ee20c1bc15f0badba7e518b11f08e563fcac2d"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreih2so5cpirwlpcj2beq5tnqogvwsg57x5ag2kjnrldlscsass2meu\",\"base_program_sha256\":\"75275ca94b46ef67967883ac7e1f3688a1496cabe6ffe942fba715f5c5a39964\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"f0522dadb68086a7c144190815ee20c1bc15f0badba7e518b11f08e563fcac2d\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"f0522dadb68086a7c144190815ee20c1bc15f0badba7e518b11f08e563fcac2d\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":104,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreih2so5cpirwlpcj2beq5tnqogvwsg57x5ag2kjnrldlscsass2meu\",\"base_program_sha256\":\"75275ca94b46ef67967883ac7e1f3688a1496cabe6ffe942fba715f5c5a39964\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.capacity.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v1

def expression_2 (initial current : Store) (returned : Int) : Int := current.v0

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.capacity.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.capacity.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.outcome.local"].contains symbol

example : (["symbol:assess.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_13

namespace Candidate_14
def sourceEvidenceOriginalProgramSHA256 : String := "9f2b2ea8bc85ed9d67f8d6e687e75f7fc90d763db92ec553b368932501e5fc11"

def sourceEvidenceOperationalViewSHA256 : String := "e49324517c6352c49467af6a5c2c58b96fb3e441d099ae5c479633d5cb8981d2"

def sourceEvidenceSourceSHA256 : String := "524ad0dbea2bcc77b4bceaf9e8a41f4b6d4c6ddb397e000ff6f817ccaa61b524"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihdm33eew7lczm3qaa3lebdtkh6tosokzcd3enbiyk7bye4ask2ne\",\"base_program_sha256\":\"f3dc3ad2d64ebdfb10260264698204daa04ad07bbda8bcb0137710e9862a7b18\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"524ad0dbea2bcc77b4bceaf9e8a41f4b6d4c6ddb397e000ff6f817ccaa61b524\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"524ad0dbea2bcc77b4bceaf9e8a41f4b6d4c6ddb397e000ff6f817ccaa61b524\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":105,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihdm33eew7lczm3qaa3lebdtkh6tosokzcd3enbiyk7bye4ask2ne\",\"base_program_sha256\":\"f3dc3ad2d64ebdfb10260264698204daa04ad07bbda8bcb0137710e9862a7b18\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.capacity.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v1

def expression_2 (initial current : Store) (returned : Int) : Int := current.v0

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.capacity.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.capacity.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.outcome.local"].contains symbol

example : (["symbol:resolve.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_14

namespace Candidate_15
def sourceEvidenceOriginalProgramSHA256 : String := "719bd62fcc0193efcb23f33290f6e70ca51fa5c1c37f15ff1976c121221dcb4b"

def sourceEvidenceOperationalViewSHA256 : String := "ec05a4451220388eebb66c5e1efceb84ffc6b555a34b58098e05ca39ce145853"

def sourceEvidenceSourceSHA256 : String := "b71965ef05bac5a73c476734c6279e9d692df2ef39b29e7c1ab75fdc72ea3adf"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreieg6hcjbxqqq6kbj3ibgs55s375gxohxgtlp5lltfgbjpgkf7tlj4\",\"base_program_sha256\":\"1e2f771d7d0f696f5e27885e7e15d1b88917a5e2be3cd3261ae4f82d4a1b8532\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"b71965ef05bac5a73c476734c6279e9d692df2ef39b29e7c1ab75fdc72ea3adf\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"b71965ef05bac5a73c476734c6279e9d692df2ef39b29e7c1ab75fdc72ea3adf\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":104,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreieg6hcjbxqqq6kbj3ibgs55s375gxohxgtlp5lltfgbjpgkf7tlj4\",\"base_program_sha256\":\"1e2f771d7d0f696f5e27885e7e15d1b88917a5e2be3cd3261ae4f82d4a1b8532\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 - current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v1

def expression_2 (initial current : Store) (returned : Int) : Int := current.v0

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.outcome.local"].contains symbol

example : (["symbol:derive.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_15

namespace Candidate_16
def sourceEvidenceOriginalProgramSHA256 : String := "f55c8d3b057b18b217aae3570b41bc761be2d23334565bc226f5f7c89580ce44"

def sourceEvidenceOperationalViewSHA256 : String := "c81657752baa66f66eb7056e9ed733e287bbe98d727591f24f7d9f6aa22267d1"

def sourceEvidenceSourceSHA256 : String := "596c00ebf4ef64e4ca1fdffab09485483604e2e997bf71c9eeabc222114bf866"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiaomwqcx6gugzkcobeiz7ch3bckodjxr7efk3a3hmtfz7zfosckdm\",\"base_program_sha256\":\"0fedf965de4cdcdd5d92c1e3eab5f5e058c55a7b056263ec4144ffcb44956975\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"596c00ebf4ef64e4ca1fdffab09485483604e2e997bf71c9eeabc222114bf866\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"596c00ebf4ef64e4ca1fdffab09485483604e2e997bf71c9eeabc222114bf866\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":104,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiaomwqcx6gugzkcobeiz7ch3bckodjxr7efk3a3hmtfz7zfosckdm\",\"base_program_sha256\":\"0fedf965de4cdcdd5d92c1e3eab5f5e058c55a7b056263ec4144ffcb44956975\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.capacity.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 - current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v1

def expression_2 (initial current : Store) (returned : Int) : Int := current.v0

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.capacity.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.capacity.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.outcome.local"].contains symbol

example : (["symbol:assess.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_16

namespace Candidate_17
def sourceEvidenceOriginalProgramSHA256 : String := "62991a6cfc25918168a1b46998901f518de891d5c321de6e93aad60373892b42"

def sourceEvidenceOperationalViewSHA256 : String := "9a8972e6511c9fe384a422b459e9cde7790b8b4efb2f4eceb4be8ce980da2d06"

def sourceEvidenceSourceSHA256 : String := "508cf50c0cbb71cb560579e0bcf059dbc33da58cf84b541735f98abbfa862e27"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiengok3qx5tbjlnm2sqtvvq4mo5h5kgfgbhgecaskprerjiut4v64\",\"base_program_sha256\":\"1ae28c2fa2965c51094861c68fb7b58ae02c08290b58cfde6f03b95c9a58679e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"508cf50c0cbb71cb560579e0bcf059dbc33da58cf84b541735f98abbfa862e27\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"508cf50c0cbb71cb560579e0bcf059dbc33da58cf84b541735f98abbfa862e27\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":105,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiengok3qx5tbjlnm2sqtvvq4mo5h5kgfgbhgecaskprerjiut4v64\",\"base_program_sha256\":\"1ae28c2fa2965c51094861c68fb7b58ae02c08290b58cfde6f03b95c9a58679e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.capacity.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 - current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v1

def expression_2 (initial current : Store) (returned : Int) : Int := current.v0

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.capacity.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.capacity.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.outcome.local"].contains symbol

example : (["symbol:resolve.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_17

namespace Candidate_18
def sourceEvidenceOriginalProgramSHA256 : String := "e3d70841532f3fa4163d9d8db4dd3416c497d56dbec7534fc89847b45e043fa7"

def sourceEvidenceOperationalViewSHA256 : String := "8b5ec6494d3d1cfb5e05cce96bb9fef7383fdf90b08dbec98f778bbbe296891d"

def sourceEvidenceSourceSHA256 : String := "3423067370d8e507b957bd0dd63e63269334fc77a8c21d2d7afd53adb1f3f087"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidqjfysza3tqaciil4bwvpua5p7lu7ijakvdw4go4xrvl2gkoky3a\",\"base_program_sha256\":\"00614eab58812db018902f8bdd0b0600285b53c6beb20b5bb69de3ad95df903a\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"3423067370d8e507b957bd0dd63e63269334fc77a8c21d2d7afd53adb1f3f087\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"3423067370d8e507b957bd0dd63e63269334fc77a8c21d2d7afd53adb1f3f087\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":135,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidqjfysza3tqaciil4bwvpua5p7lu7ijakvdw4go4xrvl2gkoky3a\",\"base_program_sha256\":\"00614eab58812db018902f8bdd0b0600285b53c6beb20b5bb69de3ad95df903a\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.answer.local", "symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v1 + current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.answer.local", "symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.answer.local", "symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.answer.local"].contains symbol

example : (["symbol:derive.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_18

namespace Candidate_19
def sourceEvidenceOriginalProgramSHA256 : String := "ae32b6ff0238f539451ce47ac3e5934344b0bb956d782572d2bfaaf843684ca6"

def sourceEvidenceOperationalViewSHA256 : String := "9c456645056d6c6fef25ae1908b9b9681ceb9802d71308a7d3cdb19d58586bf3"

def sourceEvidenceSourceSHA256 : String := "a8f069f46e178289718d2344487714381e59926532a0115b29d60cf835a62e36"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibr76skt2bub2flabqrpgcg3yxijdwwhjabbxqtosovdin3ekcqp4\",\"base_program_sha256\":\"3c4ec936633bdefb3c58ebd34471440e85b638a72da9449b776fe32be54a63cc\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"a8f069f46e178289718d2344487714381e59926532a0115b29d60cf835a62e36\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"a8f069f46e178289718d2344487714381e59926532a0115b29d60cf835a62e36\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":135,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibr76skt2bub2flabqrpgcg3yxijdwwhjabbxqtosovdin3ekcqp4\",\"base_program_sha256\":\"3c4ec936633bdefb3c58ebd34471440e85b638a72da9449b776fe32be54a63cc\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.answer.local", "symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v1 + current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.answer.local", "symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.answer.local", "symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.answer.local"].contains symbol

example : (["symbol:assess.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_19

namespace Candidate_20
def sourceEvidenceOriginalProgramSHA256 : String := "5db1f66a3bac90739aad2f90a0596774cdcd68cb9732ad1eb49e2aff3fc2cd6e"

def sourceEvidenceOperationalViewSHA256 : String := "59d0d2734eed865baa9c8b009451de49a99ab16c75c8aa707b0b968ba024eabe"

def sourceEvidenceSourceSHA256 : String := "ea8981f9e637d7e2d8bd25331aead406212aa16f0f8f68bee4478b3fa404c0b7"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibtqozbsdiwpnas2wmzordgydn7i7at7y7gokl75pmyf7gofzp5uu\",\"base_program_sha256\":\"c57e35eaecebe24215a1be9157d8f0f8926deaf008bfad2faae8fcd2a82ee895\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"ea8981f9e637d7e2d8bd25331aead406212aa16f0f8f68bee4478b3fa404c0b7\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"ea8981f9e637d7e2d8bd25331aead406212aa16f0f8f68bee4478b3fa404c0b7\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":136,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibtqozbsdiwpnas2wmzordgydn7i7at7y7gokl75pmyf7gofzp5uu\",\"base_program_sha256\":\"c57e35eaecebe24215a1be9157d8f0f8926deaf008bfad2faae8fcd2a82ee895\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local", "symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v1 + current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.answer.local", "symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.answer.local", "symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.answer.local"].contains symbol

example : (["symbol:resolve.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_20

namespace Candidate_21
def sourceEvidenceOriginalProgramSHA256 : String := "8062e56612fcda75e82486093cb92ef8ecbb622817fa7095ff1bb2f616f9ae35"

def sourceEvidenceOperationalViewSHA256 : String := "cd490d480a3e11db27cd452300554a57f8a536a9e3f0421c0535186c42e1c2ff"

def sourceEvidenceSourceSHA256 : String := "b55445b029c8fbfa1ddc701cfbf891e8e81d66606703862ae6b65152e082af8d"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiggqutyakhhw65pmi55wohxq4xdiwcqbamqszx3dvnfa2hmj3pnji\",\"base_program_sha256\":\"354f52e67552ee02bc917195821d9921574a54ae1d53a7162bab1298648d494e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"b55445b029c8fbfa1ddc701cfbf891e8e81d66606703862ae6b65152e082af8d\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"b55445b029c8fbfa1ddc701cfbf891e8e81d66606703862ae6b65152e082af8d\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":135,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiggqutyakhhw65pmi55wohxq4xdiwcqbamqszx3dvnfa2hmj3pnji\",\"base_program_sha256\":\"354f52e67552ee02bc917195821d9921574a54ae1d53a7162bab1298648d494e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.answer.local", "symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v1 - current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.answer.local", "symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.answer.local", "symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.answer.local"].contains symbol

example : (["symbol:derive.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_21

namespace Candidate_22
def sourceEvidenceOriginalProgramSHA256 : String := "0e7b696428a60ec0fdfb6202532e3116dd82a3689c6f418865132c9a1dc661da"

def sourceEvidenceOperationalViewSHA256 : String := "6581d93bcda0ce1d3e68b1b376aff2da66e6b59045b5060c95867f7aeb5a4349"

def sourceEvidenceSourceSHA256 : String := "8a279797eaf771918698615b8c28d468f077ac689dd24cacd84078dd16c208a9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreic7dtbjppqlsk5op5bjw6rc6ey7rwoohzqzm3fbrphjcwehwsg74m\",\"base_program_sha256\":\"6a1625d25f54450f37196941f0f43eec060883b9983ac075a281fc0aa3703ab5\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"8a279797eaf771918698615b8c28d468f077ac689dd24cacd84078dd16c208a9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"8a279797eaf771918698615b8c28d468f077ac689dd24cacd84078dd16c208a9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":135,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreic7dtbjppqlsk5op5bjw6rc6ey7rwoohzqzm3fbrphjcwehwsg74m\",\"base_program_sha256\":\"6a1625d25f54450f37196941f0f43eec060883b9983ac075a281fc0aa3703ab5\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.capacity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.answer.local", "symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v1 - current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.answer.local", "symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.answer.local", "symbol:assess.capacity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.answer.local"].contains symbol

example : (["symbol:assess.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_22

namespace Candidate_23
def sourceEvidenceOriginalProgramSHA256 : String := "21bdc1c3d241532c13b0fea18b8d067c5572f9b54b9291529b36eee5d19ff17c"

def sourceEvidenceOperationalViewSHA256 : String := "badd2267b25685aa2426c2174002eaddb1628820305cc28b89333ee3e00adc00"

def sourceEvidenceSourceSHA256 : String := "190a61de754ca644e4eb35e415a32e04d7e0b774b88f12c2fd15c34fbf93d510"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibwj7ayok7k2vzoz2kkcr2obiy75dvfdwuttnwpcfcoexbxhky77u\",\"base_program_sha256\":\"9d1cb75ecc28ac9ae0d4987de3e92ba8a24f423e4dafa39c345b69c6ebe5c722\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"190a61de754ca644e4eb35e415a32e04d7e0b774b88f12c2fd15c34fbf93d510\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"190a61de754ca644e4eb35e415a32e04d7e0b774b88f12c2fd15c34fbf93d510\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":136,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibwj7ayok7k2vzoz2kkcr2obiy75dvfdwuttnwpcfcoexbxhky77u\",\"base_program_sha256\":\"9d1cb75ecc28ac9ae0d4987de3e92ba8a24f423e4dafa39c345b69c6ebe5c722\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.capacity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local", "symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v1 - current.v3)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def expression_3 (initial current : Store) (returned : Int) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.answer.local", "symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.answer.local", "symbol:resolve.capacity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.answer.local"].contains symbol

example : (["symbol:resolve.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_23

namespace Candidate_24
def sourceEvidenceOriginalProgramSHA256 : String := "92ddd59c6d24a249854224c6d83b04399c76dfd732f640333ec173b7c86820ca"

def sourceEvidenceOperationalViewSHA256 : String := "54c1a4e9facf0bf5fdf3b8b8081d70686ddaf293fc964b8101cf17f62000787f"

def sourceEvidenceSourceSHA256 : String := "4233c000ebe970a171e402a33e0946a4ec31839cd20c507ee7f2381283bf5cc3"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibfs6ey3zqxyolxzfuriq2hb2rxk5rjukphxb5yudd4cflihhpwze\",\"base_program_sha256\":\"101c100de94adc8016eb0b53d3cc5bfe82ab6a5a8c1fad170568fc33d254112b\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"4233c000ebe970a171e402a33e0946a4ec31839cd20c507ee7f2381283bf5cc3\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"4233c000ebe970a171e402a33e0946a4ec31839cd20c507ee7f2381283bf5cc3\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":78,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibfs6ey3zqxyolxzfuriq2hb2rxk5rjukphxb5yudd4cflihhpwze\",\"base_program_sha256\":\"101c100de94adc8016eb0b53d3cc5bfe82ab6a5a8c1fad170568fc33d254112b\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"].contains symbol

example : (["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_24

namespace Candidate_25
def sourceEvidenceOriginalProgramSHA256 : String := "4596ede31a51e6eba25f8e468e096b0724c96fa141580c9365eb15eedc01f2a1"

def sourceEvidenceOperationalViewSHA256 : String := "21bae98ef2f2005cc1f949e2680dcbd0a8b7db5f950a938d062f5fe570770079"

def sourceEvidenceSourceSHA256 : String := "9b0251b79d43ab6319f4f288d6ef64d7010b2878b77e9d9f404a781518d67198"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihf7nb7p653fysmdxiw4rmlf2ijc742batdkwm4pwxydauqyfobka\",\"base_program_sha256\":\"ebc8d369deb327611e4660fd8489f7ae1d698a1ecfe870eea1c0d83042eae011\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"9b0251b79d43ab6319f4f288d6ef64d7010b2878b77e9d9f404a781518d67198\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"9b0251b79d43ab6319f4f288d6ef64d7010b2878b77e9d9f404a781518d67198\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":78,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihf7nb7p653fysmdxiw4rmlf2ijc742batdkwm4pwxydauqyfobka\",\"base_program_sha256\":\"ebc8d369deb327611e4660fd8489f7ae1d698a1ecfe870eea1c0d83042eae011\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"].contains symbol

example : (["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_25

namespace Candidate_26
def sourceEvidenceOriginalProgramSHA256 : String := "e1b779da01ebac1d24d1612b3e5fbd37b20cfb733efa7855b9e7c47ee82cd17e"

def sourceEvidenceOperationalViewSHA256 : String := "d5281376270ab526cdb682b3f23cbdb42037e3c1c28739a948f090acd6dc5049"

def sourceEvidenceSourceSHA256 : String := "8212988eaa638799a47a1f8f7e09a0bb996deb6f270cb5a3f6d280f61a45f8c3"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidresytmkybohm6swk6y66cek7xbhdja6uim2agp7tbydxqrvjj3a\",\"base_program_sha256\":\"2e1be942f8ee006067ab03c9b8b9c25e8632d86f6890f6acf790705b18f06788\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"8212988eaa638799a47a1f8f7e09a0bb996deb6f270cb5a3f6d280f61a45f8c3\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"8212988eaa638799a47a1f8f7e09a0bb996deb6f270cb5a3f6d280f61a45f8c3\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":79,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidresytmkybohm6swk6y66cek7xbhdja6uim2agp7tbydxqrvjj3a\",\"base_program_sha256\":\"2e1be942f8ee006067ab03c9b8b9c25e8632d86f6890f6acf790705b18f06788\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"].contains symbol

example : (["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_26

namespace Candidate_27
def sourceEvidenceOriginalProgramSHA256 : String := "4752d13788147471f4babd08de2c510bb497dad0058a54b849a701b6023c8fc8"

def sourceEvidenceOperationalViewSHA256 : String := "56fdd4b0fd840c175992b5e090af07eff49f91efc7ecaa474335d53129baba02"

def sourceEvidenceSourceSHA256 : String := "bb1bad3e90f6c96478aff6791c0620c821a747df1c905f60468b5d4d9149d373"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreib3uyr5l4mkorbochcn3ykweowixe2aw3cwzf6qcs6dbg2vcwpfpm\",\"base_program_sha256\":\"6ebdee7d74168a28fffcbe97b5ffba7d9593454342c898dff7a42c79766bbd38\",\"commands\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:calculate\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"bb1bad3e90f6c96478aff6791c0620c821a747df1c905f60468b5d4d9149d373\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"bb1bad3e90f6c96478aff6791c0620c821a747df1c905f60468b5d4d9149d373\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":81,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreib3uyr5l4mkorbochcn3ykweowixe2aw3cwzf6qcs6dbg2vcwpfpm\",\"base_program_sha256\":\"6ebdee7d74168a28fffcbe97b5ffba7d9593454342c898dff7a42c79766bbd38\",\"commands\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:calculate\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:calculate", ["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:calculate", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"].contains symbol

example : (["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_27

namespace Candidate_28
def sourceEvidenceOriginalProgramSHA256 : String := "33abd81af1b1297008a85ae079d47e1ea627ba66565149520f99f5f021a4106a"

def sourceEvidenceOperationalViewSHA256 : String := "6f409ce4ead48ec57e053f19c0c8b2e05dbcb67a876a464d9c38a87f03a8be5a"

def sourceEvidenceSourceSHA256 : String := "874735f5ad64768cd98917edd80e44067391283ebf94aa55be2cada3304e584c"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreigsn2i2vtzzpkzhnbrrzprwlnupduursoz2yhpqezfr6t55esja4a\",\"base_program_sha256\":\"d44d920b43de0e55756e3f2042d49780cb2dc3236378ebc29c4fea69e174d1a6\",\"commands\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:process\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"874735f5ad64768cd98917edd80e44067391283ebf94aa55be2cada3304e584c\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"874735f5ad64768cd98917edd80e44067391283ebf94aa55be2cada3304e584c\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":79,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreigsn2i2vtzzpkzhnbrrzprwlnupduursoz2yhpqezfr6t55esja4a\",\"base_program_sha256\":\"d44d920b43de0e55756e3f2042d49780cb2dc3236378ebc29c4fea69e174d1a6\",\"commands\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:process\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:process.threshold.parameter", "symbol:process.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:process", ["symbol:process.threshold.parameter", "symbol:process.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:process", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:process.threshold.parameter", "symbol:process.volume.parameter"].contains symbol

example : (["symbol:process.threshold.parameter", "symbol:process.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_28

namespace Candidate_29
def sourceEvidenceOriginalProgramSHA256 : String := "52161a2e91cf4782b2b4a8cff1936151e88b2557fb136ca01e0c0141ee48a1f0"

def sourceEvidenceOperationalViewSHA256 : String := "8a499578d1e29d0e9cd92427f324e2e056925009b427b9119344e5e0e105cd24"

def sourceEvidenceSourceSHA256 : String := "60563f91acf3661a0d26ba90ef1b15af55a2b33371b27d21c3ec92511be4953d"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicuzuzyaayly7tbkgldzrffyr3cg3g2futvqwzepvdqtrtygwfus4\",\"base_program_sha256\":\"6cfb785726942c3d1f051f19e14e91a6ea9e7a26c483a141f9fcf5c3c6a10c4c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:measure\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"60563f91acf3661a0d26ba90ef1b15af55a2b33371b27d21c3ec92511be4953d\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"60563f91acf3661a0d26ba90ef1b15af55a2b33371b27d21c3ec92511be4953d\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":79,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicuzuzyaayly7tbkgldzrffyr3cg3g2futvqwzepvdqtrtygwfus4\",\"base_program_sha256\":\"6cfb785726942c3d1f051f19e14e91a6ea9e7a26c483a141f9fcf5c3c6a10c4c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:measure\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:measure", ["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:measure", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"].contains symbol

example : (["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_29

namespace Candidate_30
def sourceEvidenceOriginalProgramSHA256 : String := "8010d676166bba2a641337435e143095e5a31dce95e7c8ffda8574e9fbe89a03"

def sourceEvidenceOperationalViewSHA256 : String := "fa69073bd54cae1204934d4035f3a285905f0a6f4775ce0db58215f25d8d0d42"

def sourceEvidenceSourceSHA256 : String := "6833c4907a012d61a0674e8545fd3ab73200244d47f53cb929875acf8954c16a"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreih4hjdyp7uuz7h3d6dxf264wwyecig4ltfs2mxt4dit5xq2eb4yym\",\"base_program_sha256\":\"bf8f18469369156b58583db1de5bb3eacec8933f705ce989378902c7efe2dd96\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"6833c4907a012d61a0674e8545fd3ab73200244d47f53cb929875acf8954c16a\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"6833c4907a012d61a0674e8545fd3ab73200244d47f53cb929875acf8954c16a\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":121,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreih4hjdyp7uuz7h3d6dxf264wwyecig4ltfs2mxt4dit5xq2eb4yym\",\"base_program_sha256\":\"bf8f18469369156b58583db1de5bb3eacec8933f705ce989378902c7efe2dd96\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"].contains symbol

example : (["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_30

namespace Candidate_31
def sourceEvidenceOriginalProgramSHA256 : String := "4b55723270b63e043f0ed73f18be0a73eaa2281f434b8484b1f9240565153d3e"

def sourceEvidenceOperationalViewSHA256 : String := "08480c8e49137e30094b0cc6c1bdcdae3d7275f31e7fb45a3a7f367caa708249"

def sourceEvidenceSourceSHA256 : String := "21461b64db04f1cc29dfd01e833656b42d0bad57df200a9eff67c395ac21b969"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiacqkmyqdluvvuanq2oix7p4hpdnheqqsmygcarss7unzox7xnblm\",\"base_program_sha256\":\"455c24302e5cf47caa957e5c91cf87cdce612961e88cbc233ef87a2ed17a05e3\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"21461b64db04f1cc29dfd01e833656b42d0bad57df200a9eff67c395ac21b969\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"21461b64db04f1cc29dfd01e833656b42d0bad57df200a9eff67c395ac21b969\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":121,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiacqkmyqdluvvuanq2oix7p4hpdnheqqsmygcarss7unzox7xnblm\",\"base_program_sha256\":\"455c24302e5cf47caa957e5c91cf87cdce612961e88cbc233ef87a2ed17a05e3\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"].contains symbol

example : (["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_31

namespace Candidate_32
def sourceEvidenceOriginalProgramSHA256 : String := "65a7d42880904df635c8bd59882b7c6116052b05780f20bd712a017b85353365"

def sourceEvidenceOperationalViewSHA256 : String := "eb0b5b6a55f928ec0e12ce66185534681f2f2e31dadc2bb47941d1e122d81477"

def sourceEvidenceSourceSHA256 : String := "4ffe2a6c18001efacac22e247302f51c792d5bc6e75b58bf655ec0c4261c794a"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicsd3eyjmeyxhzebcsbmrlmy7bdec4otkhilroobzucdlg6msgixe\",\"base_program_sha256\":\"345a03e88cebf8747ad6ecd04a81b300e21ffe914a732fbce47aa0b49aa36da8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"4ffe2a6c18001efacac22e247302f51c792d5bc6e75b58bf655ec0c4261c794a\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"4ffe2a6c18001efacac22e247302f51c792d5bc6e75b58bf655ec0c4261c794a\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":122,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicsd3eyjmeyxhzebcsbmrlmy7bdec4otkhilroobzucdlg6msgixe\",\"base_program_sha256\":\"345a03e88cebf8747ad6ecd04a81b300e21ffe914a732fbce47aa0b49aa36da8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"].contains symbol

example : (["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_32

namespace Candidate_33
def sourceEvidenceOriginalProgramSHA256 : String := "4d97e40b74efb9ce09d63a0a4d5fa77539f77c2372cd45dfcb457a663254b519"

def sourceEvidenceOperationalViewSHA256 : String := "7b59d878848ce8125561fb6bdc5534a043dde6ca7433bb1c70ca58094834b01a"

def sourceEvidenceSourceSHA256 : String := "ed5837eff1863ca7f755a46a64562873537bca33426b8a86029b9223b849f91c"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidbv66elnhuupstyaxyjn7yhyopqcqhzbnwszw2gzmyo4tqrhyg3u\",\"base_program_sha256\":\"fef3e4833dc26fe161a307832c0ff90c88a80fd17b6dc6a4c89169506a55fc0c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:calculate\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"ed5837eff1863ca7f755a46a64562873537bca33426b8a86029b9223b849f91c\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"ed5837eff1863ca7f755a46a64562873537bca33426b8a86029b9223b849f91c\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":124,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidbv66elnhuupstyaxyjn7yhyopqcqhzbnwszw2gzmyo4tqrhyg3u\",\"base_program_sha256\":\"fef3e4833dc26fe161a307832c0ff90c88a80fd17b6dc6a4c89169506a55fc0c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:calculate\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:calculate", ["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:calculate", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"].contains symbol

example : (["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_33

namespace Candidate_34
def sourceEvidenceOriginalProgramSHA256 : String := "445aa66e0250fb64047026fa4c4269b2d260f2c27514e826e0b6e789766825af"

def sourceEvidenceOperationalViewSHA256 : String := "db8ccdbe27c8ed86b8b02e34308c356a5e51a98c9a36f3e65c951e7283b7346a"

def sourceEvidenceSourceSHA256 : String := "46e2c34c0e5ce3b1f8cb953df1cecdbb23486cf422359115fa5a235c39ee2110"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreigcegdolex2xw3czrpblgulydqtdb3f2ls7oq35baqdx23b7qmh4y\",\"base_program_sha256\":\"e318ce6089dcf48560cd12e1076f24b1c966db3023192bdd5f4fe9d7a31d3823\",\"commands\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:process\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"46e2c34c0e5ce3b1f8cb953df1cecdbb23486cf422359115fa5a235c39ee2110\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"46e2c34c0e5ce3b1f8cb953df1cecdbb23486cf422359115fa5a235c39ee2110\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":122,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreigcegdolex2xw3czrpblgulydqtdb3f2ls7oq35baqdx23b7qmh4y\",\"base_program_sha256\":\"e318ce6089dcf48560cd12e1076f24b1c966db3023192bdd5f4fe9d7a31d3823\",\"commands\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:process\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:process.threshold.parameter", "symbol:process.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:process", ["symbol:process.threshold.parameter", "symbol:process.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:process", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:process.threshold.parameter", "symbol:process.volume.parameter"].contains symbol

example : (["symbol:process.threshold.parameter", "symbol:process.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_34

namespace Candidate_35
def sourceEvidenceOriginalProgramSHA256 : String := "f8ade60d37770ce32dd6113f0588fc5a24ee34cfac7983c4ecd64e5e64b0ac94"

def sourceEvidenceOperationalViewSHA256 : String := "c3be4d63f83282e646110fdd58fda0d97a039e64f5bf865515ea11e0d1591d8c"

def sourceEvidenceSourceSHA256 : String := "7cd19731665e4aa335b467eb7612bc0dc7d45b8d06c1a51e9c2fb282f8d5d093"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihpvcqv7fbhwoc5fesmeg2bofn3cf76djoticuohcnksfpwrbc4xy\",\"base_program_sha256\":\"ecd0a97440fe3e349dda95396ffa208e103e351b5e60d0f40e3f190370229a31\",\"commands\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:measure\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"7cd19731665e4aa335b467eb7612bc0dc7d45b8d06c1a51e9c2fb282f8d5d093\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"7cd19731665e4aa335b467eb7612bc0dc7d45b8d06c1a51e9c2fb282f8d5d093\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":122,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihpvcqv7fbhwoc5fesmeg2bofn3cf76djoticuohcnksfpwrbc4xy\",\"base_program_sha256\":\"ecd0a97440fe3e349dda95396ffa208e103e351b5e60d0f40e3f190370229a31\",\"commands\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[]},\"function_id\":\"function:measure\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:measure", ["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:measure", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v2 * current.v1)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v2

def expression_2 (initial current : Store) (returned : Int) : Int := current.v1

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"].contains symbol

example : (["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_35

namespace Candidate_36
def sourceEvidenceOriginalProgramSHA256 : String := "3905f24fa03224508fabe8ac2ec8940e943212a9fce6fff3ba18e637230e0549"

def sourceEvidenceOperationalViewSHA256 : String := "36d38a156e5a7d48bf4ad3ebf8ab9372561a67c8dc3cb0bfd178c0bc568a1441"

def sourceEvidenceSourceSHA256 : String := "a7c55dee302f229cba8da1efd07cf40b488e4ccad2bbec2feed714dc09396ada"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihz2sypyi3t3yaluagastn4frqihrhv3ueocgcvoqgdbq7ezgve3i\",\"base_program_sha256\":\"78ffcb601ceb8cdafcd875d346da2124f8f719ef108a00352dd6f32b48242bba\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"a7c55dee302f229cba8da1efd07cf40b488e4ccad2bbec2feed714dc09396ada\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"a7c55dee302f229cba8da1efd07cf40b488e4ccad2bbec2feed714dc09396ada\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":100,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihz2sypyi3t3yaluagastn4frqihrhv3ueocgcvoqgdbq7ezgve3i\",\"base_program_sha256\":\"78ffcb601ceb8cdafcd875d346da2124f8f719ef108a00352dd6f32b48242bba\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"]), ("command:15", ["symbol:derive.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local", "symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.outcome.local", "symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"].contains symbol

example : (["symbol:derive.outcome.local", "symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.outcome.local"].contains symbol

example : (["symbol:derive.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_36

namespace Candidate_37
def sourceEvidenceOriginalProgramSHA256 : String := "bc0b811e1def01fb68cb72a5db71d3d2e30c9362654e2adfc68934c8dd94461f"

def sourceEvidenceOperationalViewSHA256 : String := "f11c27d583d6fa38800f1d910eae21d860d41fe77f7b56d42e5ea5cfb38a04b3"

def sourceEvidenceSourceSHA256 : String := "4545790e553f74ee69d3204656f82a621737f156bc536d100e147e5324c8961b"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreigdjzuyxtkrjfudlcjwgxvbvwdqbeyurryn6jftjxvqcrorq7bagq\",\"base_program_sha256\":\"722a23d327813301f5f15ad6c9e0c1d02099bc52af326bc1cf246f49e58f83bb\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"4545790e553f74ee69d3204656f82a621737f156bc536d100e147e5324c8961b\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"4545790e553f74ee69d3204656f82a621737f156bc536d100e147e5324c8961b\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":100,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreigdjzuyxtkrjfudlcjwgxvbvwdqbeyurryn6jftjxvqcrorq7bagq\",\"base_program_sha256\":\"722a23d327813301f5f15ad6c9e0c1d02099bc52af326bc1cf246f49e58f83bb\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"]), ("command:15", ["symbol:assess.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local", "symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.outcome.local", "symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"].contains symbol

example : (["symbol:assess.outcome.local", "symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.outcome.local"].contains symbol

example : (["symbol:assess.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_37

namespace Candidate_38
def sourceEvidenceOriginalProgramSHA256 : String := "55a559f31dd928e3dedafab0adebe5826f1aeb8f707a4ed518a24de1334327d2"

def sourceEvidenceOperationalViewSHA256 : String := "8a7a49095b6611bf29ef0ad78172530a5d28d4b77706d579b0ece13b7364e8aa"

def sourceEvidenceSourceSHA256 : String := "042d2671543740376c109dda786fc52bc41abccdd7d2903fe126ec88b561d260"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidozeturehg7pxkpxxnqhmdjs7hw5t4d4gi65jtkoiw5c76mxqp6m\",\"base_program_sha256\":\"5ba4cae19dd475711cb45f88a8cd4826fc67fd6c889910f6df0c12af1736446e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"042d2671543740376c109dda786fc52bc41abccdd7d2903fe126ec88b561d260\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"042d2671543740376c109dda786fc52bc41abccdd7d2903fe126ec88b561d260\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":101,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidozeturehg7pxkpxxnqhmdjs7hw5t4d4gi65jtkoiw5c76mxqp6m\",\"base_program_sha256\":\"5ba4cae19dd475711cb45f88a8cd4826fc67fd6c889910f6df0c12af1736446e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"]), ("command:15", ["symbol:resolve.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"].contains symbol

example : (["symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.outcome.local"].contains symbol

example : (["symbol:resolve.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_38

namespace Candidate_39
def sourceEvidenceOriginalProgramSHA256 : String := "1aea59ac69670825edc71b777e482899d190a7e89df6eeb96d3958ac5f509ec7"

def sourceEvidenceOperationalViewSHA256 : String := "be76d5687d22cd2db642225d4e92da054f72bf5fc15de4794e5b447d13a8be1c"

def sourceEvidenceSourceSHA256 : String := "cddd5a0880ecfab7c203eae294f26a940b1b20ae22e6979fa4eb0f80e6aee3db"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreig7ih2in2uwaeyg2g4edix3p25crny5mstkic43tvja4ey5skrcfy\",\"base_program_sha256\":\"18b98f409c0be70e633c3ca78d67007a99bc17f80fae2e042d6cb2e9febf3958\",\"commands\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:calculate.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:calculate.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:calculate.outcome.local\",\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.outcome.local\"]},\"before\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.outcome.local\"]},\"function_id\":\"function:calculate\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"cddd5a0880ecfab7c203eae294f26a940b1b20ae22e6979fa4eb0f80e6aee3db\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"cddd5a0880ecfab7c203eae294f26a940b1b20ae22e6979fa4eb0f80e6aee3db\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":103,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreig7ih2in2uwaeyg2g4edix3p25crny5mstkic43tvja4ey5skrcfy\",\"base_program_sha256\":\"18b98f409c0be70e633c3ca78d67007a99bc17f80fae2e042d6cb2e9febf3958\",\"commands\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:calculate.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:calculate.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:calculate.outcome.local\",\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.outcome.local\"]},\"before\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.outcome.local\"]},\"function_id\":\"function:calculate\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"]), ("command:15", ["symbol:calculate.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:calculate.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:calculate", ["symbol:calculate.outcome.local", "symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:calculate", ["symbol:calculate.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:calculate.outcome.local", "symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"].contains symbol

example : (["symbol:calculate.outcome.local", "symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:calculate.outcome.local"].contains symbol

example : (["symbol:calculate.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_39

namespace Candidate_40
def sourceEvidenceOriginalProgramSHA256 : String := "3f0dabfe3d54ae99f07ad28b57142492ecf76b9ce4e32aa395e51b0b48c5509c"

def sourceEvidenceOperationalViewSHA256 : String := "3abda2b36035f79a2a959eb0098a973a88b5874f64c6651b45364998837355b8"

def sourceEvidenceSourceSHA256 : String := "e195f2c7a3624e68e030aa315792d2052b0fa2e353e6a051d1efb864eaa5c9d5"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidbbipqb3jpgxdtqvogk7w3ibfhyuihsrluruck3r5rjnb7dqs3pm\",\"base_program_sha256\":\"833f27e6fcf566d6ed3c507e19d161d90bcff18102484696fa2c571837db5612\",\"commands\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:process.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:process.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:process.outcome.local\",\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.outcome.local\"]},\"before\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.outcome.local\"]},\"function_id\":\"function:process\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"e195f2c7a3624e68e030aa315792d2052b0fa2e353e6a051d1efb864eaa5c9d5\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"e195f2c7a3624e68e030aa315792d2052b0fa2e353e6a051d1efb864eaa5c9d5\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":101,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidbbipqb3jpgxdtqvogk7w3ibfhyuihsrluruck3r5rjnb7dqs3pm\",\"base_program_sha256\":\"833f27e6fcf566d6ed3c507e19d161d90bcff18102484696fa2c571837db5612\",\"commands\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:process.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:process.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:process.outcome.local\",\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.outcome.local\"]},\"before\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.outcome.local\"]},\"function_id\":\"function:process\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:process.threshold.parameter", "symbol:process.volume.parameter"]), ("command:15", ["symbol:process.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:process.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:process", ["symbol:process.outcome.local", "symbol:process.threshold.parameter", "symbol:process.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:process", ["symbol:process.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:process.outcome.local", "symbol:process.threshold.parameter", "symbol:process.volume.parameter"].contains symbol

example : (["symbol:process.outcome.local", "symbol:process.threshold.parameter", "symbol:process.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:process.outcome.local"].contains symbol

example : (["symbol:process.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_40

namespace Candidate_41
def sourceEvidenceOriginalProgramSHA256 : String := "38b097734df04b130cb37170c22efb7f3edd0ac595ae0adb12377753513ca007"

def sourceEvidenceOperationalViewSHA256 : String := "e7faa7f139eeea7dbce6425e05a72a7981143decff3db7493c759ff123966fa5"

def sourceEvidenceSourceSHA256 : String := "ba40bf8afc7dac97c49ab0639291aec8ca53c03c6dc74514fabcfb1907d646ba"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreid7mzesbaw5h6rcfyhtlurujq7ul3pu6d56jsrvjs3ummon5o6hr4\",\"base_program_sha256\":\"d7f97a8d8e5e9cd64ce2b7cce825181a512c1e5b6674204e7df1d39d927a360b\",\"commands\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:measure.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:measure.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:measure.outcome.local\",\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.outcome.local\"]},\"before\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.outcome.local\"]},\"function_id\":\"function:measure\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"ba40bf8afc7dac97c49ab0639291aec8ca53c03c6dc74514fabcfb1907d646ba\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"ba40bf8afc7dac97c49ab0639291aec8ca53c03c6dc74514fabcfb1907d646ba\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":101,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreid7mzesbaw5h6rcfyhtlurujq7ul3pu6d56jsrvjs3ummon5o6hr4\",\"base_program_sha256\":\"d7f97a8d8e5e9cd64ce2b7cce825181a512c1e5b6674204e7df1d39d927a360b\",\"commands\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:measure.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:measure.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:measure.outcome.local\",\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.outcome.local\"]},\"before\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.outcome.local\"]},\"function_id\":\"function:measure\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"]), ("command:15", ["symbol:measure.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:measure.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:measure", ["symbol:measure.outcome.local", "symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:measure", ["symbol:measure.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:measure.outcome.local", "symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"].contains symbol

example : (["symbol:measure.outcome.local", "symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:measure.outcome.local"].contains symbol

example : (["symbol:measure.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_41

namespace Candidate_42
def sourceEvidenceOriginalProgramSHA256 : String := "ae7b6d93d17b974903be9e636d3def1b3a9b97f9b3d803268e90a48b9d6b8932"

def sourceEvidenceOperationalViewSHA256 : String := "0979061deb18a99a8d5ec7c1c12f912b26d97799421e1534ddedfb13a2ec2a70"

def sourceEvidenceSourceSHA256 : String := "d7937ff3705ec00ae4fb84b5c8035bb8f310cbf43aefb694337992a01113e79a"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreie6cdwquj2xvmaytftaefikovn3n2ct6mkfwz6hsqtcn34mibevfe\",\"base_program_sha256\":\"27e96703906cd29f169605ba75bee6e57bcaee58d95478586d47dc16409d6805\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"d7937ff3705ec00ae4fb84b5c8035bb8f310cbf43aefb694337992a01113e79a\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"d7937ff3705ec00ae4fb84b5c8035bb8f310cbf43aefb694337992a01113e79a\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":131,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreie6cdwquj2xvmaytftaefikovn3n2ct6mkfwz6hsqtcn34mibevfe\",\"base_program_sha256\":\"27e96703906cd29f169605ba75bee6e57bcaee58d95478586d47dc16409d6805\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.threshold.parameter\",\"symbol:derive.volume.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"]), ("command:15", ["symbol:derive.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.answer.local", "symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.answer.local", "symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"].contains symbol

example : (["symbol:derive.answer.local", "symbol:derive.threshold.parameter", "symbol:derive.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.answer.local"].contains symbol

example : (["symbol:derive.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_42

namespace Candidate_43
def sourceEvidenceOriginalProgramSHA256 : String := "6abaaa52bc100fb8cfa0642c13c51fe11f123d533230b90c47f661d5fd83e713"

def sourceEvidenceOperationalViewSHA256 : String := "4275f19174f2691f981e682d1a429ac2205d83ebfe839e531e24d4986918dc2e"

def sourceEvidenceSourceSHA256 : String := "a1679f2932fca5fc90383c6750f99cb12199f6d0b8baa179c3b83c2b3866cab5"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreieej3blxvprvjjpmx57dkyea7ghrkx5snkbonaqfzlhvmbvhmpmv4\",\"base_program_sha256\":\"2bd8002d37b8dbf898bcab3a38b22fa2353a18e7bd228bde62898a7353fcf5b8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"a1679f2932fca5fc90383c6750f99cb12199f6d0b8baa179c3b83c2b3866cab5\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"a1679f2932fca5fc90383c6750f99cb12199f6d0b8baa179c3b83c2b3866cab5\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":131,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreieej3blxvprvjjpmx57dkyea7ghrkx5snkbonaqfzlhvmbvhmpmv4\",\"base_program_sha256\":\"2bd8002d37b8dbf898bcab3a38b22fa2353a18e7bd228bde62898a7353fcf5b8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.threshold.parameter\",\"symbol:assess.volume.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"]), ("command:15", ["symbol:assess.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.answer.local", "symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:assess.answer.local", "symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"].contains symbol

example : (["symbol:assess.answer.local", "symbol:assess.threshold.parameter", "symbol:assess.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.answer.local"].contains symbol

example : (["symbol:assess.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_43

namespace Candidate_44
def sourceEvidenceOriginalProgramSHA256 : String := "c2486b455db86a086662252d1154643522075d9a9da19667b9732fdb04cfcf6d"

def sourceEvidenceOperationalViewSHA256 : String := "d67ba21dfd3323902c3cc0d7873abe03a5f77eee2f68bab10f7b30da6988308d"

def sourceEvidenceSourceSHA256 : String := "19acf97591dce5f1a9adaa1673c59c015260cd38160d3e0dac20049f718f1b10"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiafjegkhknws5ujn7x5wkgdu4nix6xmehdhltf5ri2qwramyoqamm\",\"base_program_sha256\":\"358d9866f78c233c1c57c2324fb9a46595547671477e96208e44351860c3837d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"19acf97591dce5f1a9adaa1673c59c015260cd38160d3e0dac20049f718f1b10\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"19acf97591dce5f1a9adaa1673c59c015260cd38160d3e0dac20049f718f1b10\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":132,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiafjegkhknws5ujn7x5wkgdu4nix6xmehdhltf5ri2qwramyoqamm\",\"base_program_sha256\":\"358d9866f78c233c1c57c2324fb9a46595547671477e96208e44351860c3837d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.threshold.parameter\",\"symbol:resolve.volume.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"]), ("command:15", ["symbol:resolve.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local", "symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:resolve.answer.local", "symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"].contains symbol

example : (["symbol:resolve.answer.local", "symbol:resolve.threshold.parameter", "symbol:resolve.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.answer.local"].contains symbol

example : (["symbol:resolve.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_44

namespace Candidate_45
def sourceEvidenceOriginalProgramSHA256 : String := "c1e4f3f7544586d6c943baa34671c02fc0375cb74ed0bb7861c8aedc6678b3f3"

def sourceEvidenceOperationalViewSHA256 : String := "4fcf109a96d56b9db60fcae8a8b661cfe947fb680c8a5245f5781a78010d5be4"

def sourceEvidenceSourceSHA256 : String := "1bf5d542143b984813a86d16524ab68ce29d22610cbab06cae769cd2b10207b6"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibygoaiaesyvc7zgldglg2u4qwourgyuxaz6mqco2qmqw457glbzq\",\"base_program_sha256\":\"316a4929b604af74091bd21d35d3d3efd8eae663bff3e64f1f13db453b0a8cd0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:calculate.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:calculate.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:calculate.answer.local\",\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.answer.local\"]},\"before\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.answer.local\"]},\"function_id\":\"function:calculate\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"1bf5d542143b984813a86d16524ab68ce29d22610cbab06cae769cd2b10207b6\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"1bf5d542143b984813a86d16524ab68ce29d22610cbab06cae769cd2b10207b6\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":134,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibygoaiaesyvc7zgldglg2u4qwourgyuxaz6mqco2qmqw457glbzq\",\"base_program_sha256\":\"316a4929b604af74091bd21d35d3d3efd8eae663bff3e64f1f13db453b0a8cd0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:calculate.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:calculate.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:calculate.answer.local\",\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.answer.local\"]},\"before\":{\"reads\":[\"symbol:calculate.threshold.parameter\",\"symbol:calculate.volume.parameter\"],\"writes\":[\"symbol:calculate.answer.local\"]},\"function_id\":\"function:calculate\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"]), ("command:15", ["symbol:calculate.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:calculate.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:calculate", ["symbol:calculate.answer.local", "symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:calculate", ["symbol:calculate.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:calculate.answer.local", "symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"].contains symbol

example : (["symbol:calculate.answer.local", "symbol:calculate.threshold.parameter", "symbol:calculate.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:calculate.answer.local"].contains symbol

example : (["symbol:calculate.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_45

namespace Candidate_46
def sourceEvidenceOriginalProgramSHA256 : String := "92fe60b8997e4c214e6edc26485490a61a9c355935d4aa78c2a64fbbe1f00fef"

def sourceEvidenceOperationalViewSHA256 : String := "54ac74e625181ffbb564a4f87371bd21dbc82d9de7bde1da63a66f6d5d6ceda9"

def sourceEvidenceSourceSHA256 : String := "194cd3c312d41fd7a5dcd01e7cf9aae7deda3903ccf925f9dc4f69a4be550744"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicmmi6lazu25o5wlxglzemjk6txatne6uc7u67tysfogzpi7t3c5y\",\"base_program_sha256\":\"19b7b97b90137f0cd98ff20a20b3b4681719403f7e9417157ac88c2246cf18a6\",\"commands\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:process.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:process.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:process.answer.local\",\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.answer.local\"]},\"before\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.answer.local\"]},\"function_id\":\"function:process\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"194cd3c312d41fd7a5dcd01e7cf9aae7deda3903ccf925f9dc4f69a4be550744\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"194cd3c312d41fd7a5dcd01e7cf9aae7deda3903ccf925f9dc4f69a4be550744\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":132,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicmmi6lazu25o5wlxglzemjk6txatne6uc7u67tysfogzpi7t3c5y\",\"base_program_sha256\":\"19b7b97b90137f0cd98ff20a20b3b4681719403f7e9417157ac88c2246cf18a6\",\"commands\":[{\"after\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:process.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:process.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:process.answer.local\",\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.answer.local\"]},\"before\":{\"reads\":[\"symbol:process.threshold.parameter\",\"symbol:process.volume.parameter\"],\"writes\":[\"symbol:process.answer.local\"]},\"function_id\":\"function:process\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:process.threshold.parameter", "symbol:process.volume.parameter"]), ("command:15", ["symbol:process.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:process.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:process", ["symbol:process.answer.local", "symbol:process.threshold.parameter", "symbol:process.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:process", ["symbol:process.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:process.answer.local", "symbol:process.threshold.parameter", "symbol:process.volume.parameter"].contains symbol

example : (["symbol:process.answer.local", "symbol:process.threshold.parameter", "symbol:process.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:process.answer.local"].contains symbol

example : (["symbol:process.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_46

namespace Candidate_47
def sourceEvidenceOriginalProgramSHA256 : String := "e4e4311ed26cd78abadad33b1960509ff0cfeeed09952e7ed860a7fdeb193bae"

def sourceEvidenceOperationalViewSHA256 : String := "36d114436fd3e823f932bf8262c55eb637c4305b11d52cadf2983e21c9c11e6a"

def sourceEvidenceSourceSHA256 : String := "b21e06f8be11e536bfe939b0245afdd92ca788ad9193750fcb08e7004b46e7e6"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiertqhmwzgjjrmkoibvwqozbx5sjo5ihk6rpvazjbnjlnuzsoqogu\",\"base_program_sha256\":\"bfe2f02b8a83a8574b838299bfc2b1e2251693a557393c168f7df9a2a84596a7\",\"commands\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:measure.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:measure.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:measure.answer.local\",\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.answer.local\"]},\"before\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.answer.local\"]},\"function_id\":\"function:measure\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"b21e06f8be11e536bfe939b0245afdd92ca788ad9193750fcb08e7004b46e7e6\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"b21e06f8be11e536bfe939b0245afdd92ca788ad9193750fcb08e7004b46e7e6\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":132,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiertqhmwzgjjrmkoibvwqozbx5sjo5ihk6rpvazjbnjlnuzsoqogu\",\"base_program_sha256\":\"bfe2f02b8a83a8574b838299bfc2b1e2251693a557393c168f7df9a2a84596a7\",\"commands\":[{\"after\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:measure.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:measure.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:measure.answer.local\",\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.answer.local\"]},\"before\":{\"reads\":[\"symbol:measure.threshold.parameter\",\"symbol:measure.volume.parameter\"],\"writes\":[\"symbol:measure.answer.local\"]},\"function_id\":\"function:measure\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"]), ("command:15", ["symbol:measure.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:measure.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:measure", ["symbol:measure.answer.local", "symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:measure", ["symbol:measure.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v3 * current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v3

def expression_3 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current (0 : Int) };
  Outcome.returned current (expression_1 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:measure.answer.local", "symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"].contains symbol

example : (["symbol:measure.answer.local", "symbol:measure.threshold.parameter", "symbol:measure.volume.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:measure.answer.local"].contains symbol

example : (["symbol:measure.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_47

namespace Candidate_48
def sourceEvidenceOriginalProgramSHA256 : String := "e55181f7af4c43adb13318addc2fc4b311f88da33ea6c6f3f2579bb3b9a85783"

def sourceEvidenceOperationalViewSHA256 : String := "a389bf1f9e80feb37c96af323831c11f272c4ea7b94da905dc2c79f5a0fba8d7"

def sourceEvidenceSourceSHA256 : String := "a5419e430f92530a5f6650cce0a45733108e7e4938aeb820653944fc7d02d3b9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibif2ebloqb3i33yan6f5mhx23v4h5vxttb5vz6acekf4rorzafmy\",\"base_program_sha256\":\"c867f5cd00ab2dc1cf9e648c984f2975d1eea1ba225d0038ada59c4e13a478b0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"a5419e430f92530a5f6650cce0a45733108e7e4938aeb820653944fc7d02d3b9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"a5419e430f92530a5f6650cce0a45733108e7e4938aeb820653944fc7d02d3b9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":83,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibif2ebloqb3i33yan6f5mhx23v4h5vxttb5vz6acekf4rorzafmy\",\"base_program_sha256\":\"c867f5cd00ab2dc1cf9e648c984f2975d1eea1ba225d0038ada59c4e13a478b0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 < current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_48

namespace Candidate_49
def sourceEvidenceOriginalProgramSHA256 : String := "ccb2a11897f9254c42fa6bbc52cc676a6a8e5b134844f4a2bbb78fcc0536ee75"

def sourceEvidenceOperationalViewSHA256 : String := "46e05ee32abae8a4a7deb8aa53303288639bd32b89eb4966631305074e2c8d87"

def sourceEvidenceSourceSHA256 : String := "23da70a14e760f6af926589d64441e9594e9032cabe6ce15bd1b508160478d8e"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreigccnlqb4ap5otr7h2df5t6fxm4qgcgglfnpa7vrhcqolbytra7zm\",\"base_program_sha256\":\"1e462770f59b6725024c3bde277a52b04d52daa68b9faf0da7b6ffc1703e521e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"23da70a14e760f6af926589d64441e9594e9032cabe6ce15bd1b508160478d8e\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"23da70a14e760f6af926589d64441e9594e9032cabe6ce15bd1b508160478d8e\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":83,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreigccnlqb4ap5otr7h2df5t6fxm4qgcgglfnpa7vrhcqolbytra7zm\",\"base_program_sha256\":\"1e462770f59b6725024c3bde277a52b04d52daa68b9faf0da7b6ffc1703e521e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 < current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_49

namespace Candidate_50
def sourceEvidenceOriginalProgramSHA256 : String := "dcdd8784b57a7b74526f5ef9ad871d08ad5b9c6dc7af3ea7a96a7ed96a8aeec0"

def sourceEvidenceOperationalViewSHA256 : String := "35a75ceeea9ffe1fc8b400310278c550011779ab2a483d877dfc84990efac7bb"

def sourceEvidenceSourceSHA256 : String := "377b171fd20aada5e8e97916ebf772928ee6a05af35b8b6ea239fce7b427939d"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreia2wrlomgy43fkz2zjya3edc6xbn2vkonf3khd7uvdmil5tp5ws3m\",\"base_program_sha256\":\"109cbf26f014dc59c78feb7f306d7e8b2bff7c92c2232a287ea610bd29a49ce3\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"377b171fd20aada5e8e97916ebf772928ee6a05af35b8b6ea239fce7b427939d\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"377b171fd20aada5e8e97916ebf772928ee6a05af35b8b6ea239fce7b427939d\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":84,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreia2wrlomgy43fkz2zjya3edc6xbn2vkonf3khd7uvdmil5tp5ws3m\",\"base_program_sha256\":\"109cbf26f014dc59c78feb7f306d7e8b2bff7c92c2232a287ea610bd29a49ce3\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 < current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_50

namespace Candidate_51
def sourceEvidenceOriginalProgramSHA256 : String := "fd1dfc0f3d02e2e095fd23e7d32a32f53293501099c5f366b9003d430c15dbc1"

def sourceEvidenceOperationalViewSHA256 : String := "010be4588b2fc653ab17bb9d0f108a1899fd29da4efd1e69c4adb019d1b93551"

def sourceEvidenceSourceSHA256 : String := "2a96d38becb84fff2311f65f72ab649aab4d068d2a853ccfe8de7b4a64a0b52c"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicjdc66qriltrxxoecjoquav3jsa2yuzjrvjonluvcbmlhrqye764\",\"base_program_sha256\":\"8222cd6e9d5b2b6b5ed428bf1ece1c29bec170e76473a14c2cd8dafee6191689\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"2a96d38becb84fff2311f65f72ab649aab4d068d2a853ccfe8de7b4a64a0b52c\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"2a96d38becb84fff2311f65f72ab649aab4d068d2a853ccfe8de7b4a64a0b52c\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":84,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicjdc66qriltrxxoecjoquav3jsa2yuzjrvjonluvcbmlhrqye764\",\"base_program_sha256\":\"8222cd6e9d5b2b6b5ed428bf1ece1c29bec170e76473a14c2cd8dafee6191689\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≤ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_51

namespace Candidate_52
def sourceEvidenceOriginalProgramSHA256 : String := "5b13a0b2908918912554d52dbd6069f41f2244f9c58e47cb8439fddc24324e99"

def sourceEvidenceOperationalViewSHA256 : String := "a6ae360aa49607b54713990503308f0246ac10fabc9f69e1e92799ff3cc00178"

def sourceEvidenceSourceSHA256 : String := "3cf1ef5a1ac96b4d748e8966241351a73c52f15a95bf0e0ab7c3c25695c7de87"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiflje5dzi333qo5msddxclfkezmim7wqv6w2fcrpufhgnj55fa4r4\",\"base_program_sha256\":\"011f176a1eaafc33adabaac65e755525f87b27572da593903634a540739df574\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"3cf1ef5a1ac96b4d748e8966241351a73c52f15a95bf0e0ab7c3c25695c7de87\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"3cf1ef5a1ac96b4d748e8966241351a73c52f15a95bf0e0ab7c3c25695c7de87\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":84,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiflje5dzi333qo5msddxclfkezmim7wqv6w2fcrpufhgnj55fa4r4\",\"base_program_sha256\":\"011f176a1eaafc33adabaac65e755525f87b27572da593903634a540739df574\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≤ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_52

namespace Candidate_53
def sourceEvidenceOriginalProgramSHA256 : String := "87d81461cbde6b3f35383c35e8e40650872c285c403da8f7817d4d13bf790779"

def sourceEvidenceOperationalViewSHA256 : String := "19305a4eae6373d57ec722713a27910a209947267d807fe45fb83e7146776855"

def sourceEvidenceSourceSHA256 : String := "c3ebfcaac2c9081db11fb72e0f48795a30202c8097cd7cf02da3b6e380d95662"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreief7vshts3ur4isx2znu2cpgiufnd2slxtsciwmlt36j4irmz7smq\",\"base_program_sha256\":\"97f31a7e57af7403052923b9ba175ac7adf3b855d00b53388aea8034a5e68678\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"c3ebfcaac2c9081db11fb72e0f48795a30202c8097cd7cf02da3b6e380d95662\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"c3ebfcaac2c9081db11fb72e0f48795a30202c8097cd7cf02da3b6e380d95662\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":85,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreief7vshts3ur4isx2znu2cpgiufnd2slxtsciwmlt36j4irmz7smq\",\"base_program_sha256\":\"97f31a7e57af7403052923b9ba175ac7adf3b855d00b53388aea8034a5e68678\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≤ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_53

namespace Candidate_54
def sourceEvidenceOriginalProgramSHA256 : String := "e8623093b1a4d2cdd8e709c73c86b15710d3fe5cdf16e46f2a11559a19466dd3"

def sourceEvidenceOperationalViewSHA256 : String := "58d00feccc19ea6804ee17746b29a3e002d62d041965110044c8f8e26fd5e472"

def sourceEvidenceSourceSHA256 : String := "1c38cd9430f5f61a381eda6104c159a924dca2ee5f0e3a5d054cf3ba20494491"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreifdb3rpyym7ct2jlnijribz5iiwuhc6jkp7g7f4ook2ywidtuxftq\",\"base_program_sha256\":\"c26c38334ddd36b7dd9308d8b0fd80af5a16bda4d6f7cdcdb622a2d3ca386123\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"1c38cd9430f5f61a381eda6104c159a924dca2ee5f0e3a5d054cf3ba20494491\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"1c38cd9430f5f61a381eda6104c159a924dca2ee5f0e3a5d054cf3ba20494491\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":126,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreifdb3rpyym7ct2jlnijribz5iiwuhc6jkp7g7f4ook2ywidtuxftq\",\"base_program_sha256\":\"c26c38334ddd36b7dd9308d8b0fd80af5a16bda4d6f7cdcdb622a2d3ca386123\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 < current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_54

namespace Candidate_55
def sourceEvidenceOriginalProgramSHA256 : String := "55a3e30ef1272695e4e5d0a43238eda20b3cf554d990d1f68219e0092c3d4fa6"

def sourceEvidenceOperationalViewSHA256 : String := "a20575ea3c34150856484a3515aab7715c01013a8cf0bba27dc968a32d9424c8"

def sourceEvidenceSourceSHA256 : String := "785f6a7792a7e9879c122505fb69a48c5292afac962fd6dfd99b53f52b6eeb12"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidcpiqntrrhsbizvhxyyhga7zdxs3tceku6sviu7cy4rymibxv7eu\",\"base_program_sha256\":\"771c20a57f3305b7fca614409333ed18e544889d634231753d15300fbce130e6\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"785f6a7792a7e9879c122505fb69a48c5292afac962fd6dfd99b53f52b6eeb12\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"785f6a7792a7e9879c122505fb69a48c5292afac962fd6dfd99b53f52b6eeb12\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":126,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidcpiqntrrhsbizvhxyyhga7zdxs3tceku6sviu7cy4rymibxv7eu\",\"base_program_sha256\":\"771c20a57f3305b7fca614409333ed18e544889d634231753d15300fbce130e6\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 < current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_55

namespace Candidate_56
def sourceEvidenceOriginalProgramSHA256 : String := "3ac941beccf46ec1ffda0ba3cf9a78349b1e2c6e61253a27199ce4bcf5ae6152"

def sourceEvidenceOperationalViewSHA256 : String := "53230b077856624ed7488d2516d11ab4cec7629824bb836a29daf3353a08655b"

def sourceEvidenceSourceSHA256 : String := "86e94c2dd6f40f03415f31d50751c657beeefbae316975539572cfc1a9fee0f4"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiambdhgoelryd52splflvayspyixpy7pllolnmdhw7z3l6eucjuta\",\"base_program_sha256\":\"f131b8e1bc37771a28f13db29f60c6fe0af3c52874e0d1e23c5bf0493c052826\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"86e94c2dd6f40f03415f31d50751c657beeefbae316975539572cfc1a9fee0f4\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"86e94c2dd6f40f03415f31d50751c657beeefbae316975539572cfc1a9fee0f4\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":127,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiambdhgoelryd52splflvayspyixpy7pllolnmdhw7z3l6eucjuta\",\"base_program_sha256\":\"f131b8e1bc37771a28f13db29f60c6fe0af3c52874e0d1e23c5bf0493c052826\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 < current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_56

namespace Candidate_57
def sourceEvidenceOriginalProgramSHA256 : String := "e609fa3ee0038c1357159fb8aa64a1140404afede4a448c418e9896472f3547d"

def sourceEvidenceOperationalViewSHA256 : String := "1916b30d8538878e94cd8352e3b17674cc313cc21a3173c7e62156e7ac294b77"

def sourceEvidenceSourceSHA256 : String := "6ff5b9801da7f8db99a59e778185deedf67656d44e3abd9eb3c2f975e9ec8b47"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreigxexuwortv3aj7tvic3qdv4ffzjhid5c5mzugeckhq2fqunwpwza\",\"base_program_sha256\":\"146d9d0b363bc022a1ce6c738066e26efd894c3e3fb8bcc4871e7a3e6eaf9fad\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"6ff5b9801da7f8db99a59e778185deedf67656d44e3abd9eb3c2f975e9ec8b47\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"6ff5b9801da7f8db99a59e778185deedf67656d44e3abd9eb3c2f975e9ec8b47\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":127,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreigxexuwortv3aj7tvic3qdv4ffzjhid5c5mzugeckhq2fqunwpwza\",\"base_program_sha256\":\"146d9d0b363bc022a1ce6c738066e26efd894c3e3fb8bcc4871e7a3e6eaf9fad\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≤ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_57

namespace Candidate_58
def sourceEvidenceOriginalProgramSHA256 : String := "b7b8350e14bc6833bc32ed4d14db3efd7b946f244a80dddf6d8dc749bae979c0"

def sourceEvidenceOperationalViewSHA256 : String := "19594dcd35b7e577bcdb886750e0de2c677064dabe260c0fc061040d12085a02"

def sourceEvidenceSourceSHA256 : String := "9c79820fa7565baf6a1f45ec45c01102b77a667de45908fe8f486246957ef731"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreialtnjv64yjzomgre73gsxxv2mbeevafr3ju6fgojd5cp3ufyzdui\",\"base_program_sha256\":\"e2f8941a0181a83fc10d624b0e29026c5b119ad61b1343b2e36a31efa480605e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"9c79820fa7565baf6a1f45ec45c01102b77a667de45908fe8f486246957ef731\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"9c79820fa7565baf6a1f45ec45c01102b77a667de45908fe8f486246957ef731\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":127,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreialtnjv64yjzomgre73gsxxv2mbeevafr3ju6fgojd5cp3ufyzdui\",\"base_program_sha256\":\"e2f8941a0181a83fc10d624b0e29026c5b119ad61b1343b2e36a31efa480605e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≤ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_58

namespace Candidate_59
def sourceEvidenceOriginalProgramSHA256 : String := "63e7bfe964147aaee06b7383f8d77abea701e8b2712d90f5caccf37937cc1c5d"

def sourceEvidenceOperationalViewSHA256 : String := "0e8be964d75f6c3ecaf77eac39ea59467b7d5a697bdbd86131a4d4355d552059"

def sourceEvidenceSourceSHA256 : String := "20bb75db5ecb40c682ec56d43ddd66f29a836f72e763c8a22d2ac9a4126c8f76"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreifc5xu7agksz53pa7a4xaqjb7azuc7bmz3tbibapfvf6g27tv7szy\",\"base_program_sha256\":\"dd7f5e49e6f7f80dc12dba4e1b00e6766a8e6dc9f3485f94f7a5ac1fbca56f15\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"20bb75db5ecb40c682ec56d43ddd66f29a836f72e763c8a22d2ac9a4126c8f76\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"20bb75db5ecb40c682ec56d43ddd66f29a836f72e763c8a22d2ac9a4126c8f76\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":128,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreifc5xu7agksz53pa7a4xaqjb7azuc7bmz3tbibapfvf6g27tv7szy\",\"base_program_sha256\":\"dd7f5e49e6f7f80dc12dba4e1b00e6766a8e6dc9f3485f94f7a5ac1fbca56f15\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≤ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_59

namespace Candidate_60
def sourceEvidenceOriginalProgramSHA256 : String := "ad8ebf6febd4c77ac7808ea9a55dd636dc6e201d5d7ea94866f2088a9be24351"

def sourceEvidenceOperationalViewSHA256 : String := "cea805aecf5db7d2d06ac41156978efafaae227770ab75c8cb476091b9597f5e"

def sourceEvidenceSourceSHA256 : String := "63f40eab6003a5572647c161339a0c4d307cc379c458cde3862aa7ce981f31b4"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreifgfz6benyk4c7n7du2kethimm2jqlnairfnzjkfkql5mnb6bf2ly\",\"base_program_sha256\":\"619db87c1bcbf30d06a58a028e89c3fd2f79a1445b941a870088fff870eb06ae\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"63f40eab6003a5572647c161339a0c4d307cc379c458cde3862aa7ce981f31b4\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"63f40eab6003a5572647c161339a0c4d307cc379c458cde3862aa7ce981f31b4\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":105,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreifgfz6benyk4c7n7du2kethimm2jqlnairfnzjkfkql5mnb6bf2ly\",\"base_program_sha256\":\"619db87c1bcbf30d06a58a028e89c3fd2f79a1445b941a870088fff870eb06ae\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 < current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.outcome.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.outcome.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.outcome.local"].contains symbol

example : (["symbol:derive.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_60

namespace Candidate_61
def sourceEvidenceOriginalProgramSHA256 : String := "1fc68be4709f6095cd48a2a99c4c6ddf4f2a0ef7812268a575d3b515a6fe08f6"

def sourceEvidenceOperationalViewSHA256 : String := "b06dc4412981231f7e93d968e21b5668bb376c60e72087c8ab838497093893b6"

def sourceEvidenceSourceSHA256 : String := "39b33e7ef98ddf522ed569e0503e7d6ef9af219a6b7faac8d4df4ab545fc4f09"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreieukcbrfkortv4txuq77x5ro2teihzmed3pzjhkml64c33o6gcvsa\",\"base_program_sha256\":\"1370ef9d7049109b6a743ad7fbfd5b41d36db7966af785b6f3f470f21df60d52\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"39b33e7ef98ddf522ed569e0503e7d6ef9af219a6b7faac8d4df4ab545fc4f09\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"39b33e7ef98ddf522ed569e0503e7d6ef9af219a6b7faac8d4df4ab545fc4f09\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":105,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreieukcbrfkortv4txuq77x5ro2teihzmed3pzjhkml64c33o6gcvsa\",\"base_program_sha256\":\"1370ef9d7049109b6a743ad7fbfd5b41d36db7966af785b6f3f470f21df60d52\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 < current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.outcome.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.outcome.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.outcome.local"].contains symbol

example : (["symbol:assess.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_61

namespace Candidate_62
def sourceEvidenceOriginalProgramSHA256 : String := "4cd6a30bc47559077a55a759f53c74230ca443ebf8ecc697fdb8b384b619ffa9"

def sourceEvidenceOperationalViewSHA256 : String := "efa315a49d9f0a92e49ca4e0a7fe80542caef5cede603308893ee868dce2c020"

def sourceEvidenceSourceSHA256 : String := "95e7cdc985ac2e7396a0e3aaad3fede53c25d9a1a09bce6b294e4fa814ffbf86"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreig23xfby5u36ggzucazeoofxmhqgd3un4pwhxlm342jfh5mrn5mo4\",\"base_program_sha256\":\"fa029b5ff20884ec71c28cc4e2ee81d16c37364e53e3af9c9943919631f07f9c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"95e7cdc985ac2e7396a0e3aaad3fede53c25d9a1a09bce6b294e4fa814ffbf86\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"95e7cdc985ac2e7396a0e3aaad3fede53c25d9a1a09bce6b294e4fa814ffbf86\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":106,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreig23xfby5u36ggzucazeoofxmhqgd3un4pwhxlm342jfh5mrn5mo4\",\"base_program_sha256\":\"fa029b5ff20884ec71c28cc4e2ee81d16c37364e53e3af9c9943919631f07f9c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 < current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.outcome.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.outcome.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.outcome.local"].contains symbol

example : (["symbol:resolve.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_62

namespace Candidate_63
def sourceEvidenceOriginalProgramSHA256 : String := "aa8e11b9d11cf3bb93cd4fe38b0ce8c09ed0a8a6b8a6da8c18a9d95e376c7252"

def sourceEvidenceOperationalViewSHA256 : String := "26a822e3b97ce5a091e061177dae32e9abc1de71ea111e9d4753750c55a15838"

def sourceEvidenceSourceSHA256 : String := "335109e78ce90065a19e550cfc8077f5494481d50d54a0d24a2c5e9d83f9b30e"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreieissbyjncnk3flk6rjdwmpch6o7t6qtnknbawm6hx4tnzzfpurv4\",\"base_program_sha256\":\"dd0c7a270d10c17f5430164f6eff8e0308b103cb819b61c42024f305d070edb6\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"335109e78ce90065a19e550cfc8077f5494481d50d54a0d24a2c5e9d83f9b30e\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"335109e78ce90065a19e550cfc8077f5494481d50d54a0d24a2c5e9d83f9b30e\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":106,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreieissbyjncnk3flk6rjdwmpch6o7t6qtnknbawm6hx4tnzzfpurv4\",\"base_program_sha256\":\"dd0c7a270d10c17f5430164f6eff8e0308b103cb819b61c42024f305d070edb6\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≤ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.outcome.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.outcome.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.outcome.local"].contains symbol

example : (["symbol:derive.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_63

namespace Candidate_64
def sourceEvidenceOriginalProgramSHA256 : String := "f47894911ff3e9d8a451b60f6bf642728d43b6de05953c135a9060d187e1e4db"

def sourceEvidenceOperationalViewSHA256 : String := "ea17df34503419a130c5f501814650f2d5d442793009d9fe6a7189a9743b6419"

def sourceEvidenceSourceSHA256 : String := "91bfcc0f64116b62fc9aa5d26e3c72842f8dffaa598e85a614f62552d356c2ba"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreif2m73v4pcodst2jj65jzo5zk6cee2rzljf7vqryujcadfgfoubem\",\"base_program_sha256\":\"0bdb6f605044414b5b98defd88ad9c00eaabfbf6953eeae2f60e2729a66647c7\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"91bfcc0f64116b62fc9aa5d26e3c72842f8dffaa598e85a614f62552d356c2ba\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"91bfcc0f64116b62fc9aa5d26e3c72842f8dffaa598e85a614f62552d356c2ba\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":106,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreif2m73v4pcodst2jj65jzo5zk6cee2rzljf7vqryujcadfgfoubem\",\"base_program_sha256\":\"0bdb6f605044414b5b98defd88ad9c00eaabfbf6953eeae2f60e2729a66647c7\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≤ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.outcome.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.outcome.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.outcome.local"].contains symbol

example : (["symbol:assess.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_64

namespace Candidate_65
def sourceEvidenceOriginalProgramSHA256 : String := "b85d35048ed7c7b55ea047f5160d69f93d2f683563a5e011e0e1663ec4c657a1"

def sourceEvidenceOperationalViewSHA256 : String := "8890982a7373521c8b8b1b7bb2c2b2280b6db060e827e25e564c5c795444364e"

def sourceEvidenceSourceSHA256 : String := "8a777a5125116538a65edfaded225248b1c0efde69378552ccd613715d5e780b"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibh7nldh7xteobd4gxdg7f3pocq2q4v7suw6cbvbulteenvgi3yga\",\"base_program_sha256\":\"78a46d89d3f722eb549a7edd7a44509cacea886c7945a794e60726f7f78d66c8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"8a777a5125116538a65edfaded225248b1c0efde69378552ccd613715d5e780b\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"8a777a5125116538a65edfaded225248b1c0efde69378552ccd613715d5e780b\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":107,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibh7nldh7xteobd4gxdg7f3pocq2q4v7suw6cbvbulteenvgi3yga\",\"base_program_sha256\":\"78a46d89d3f722eb549a7edd7a44509cacea886c7945a794e60726f7f78d66c8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≤ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.outcome.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.outcome.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.outcome.local"].contains symbol

example : (["symbol:resolve.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_65

namespace Candidate_66
def sourceEvidenceOriginalProgramSHA256 : String := "4f9237d65499a62221c2c50329ab0faf55fe7497a64169d233675a72ab4ebf1c"

def sourceEvidenceOperationalViewSHA256 : String := "8c9674008875ea2398fa35c25ca7d38fb981a3b629aa11c2a961d7b8d37a6401"

def sourceEvidenceSourceSHA256 : String := "a01e39dd8c10c586c22b3e6919befabdbf03f3a9dd984cfa553254e3a65867a1"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihew7owy4ahqqn5j443qtnw247evrwd3d2ccqw54wttevi4jnzatu\",\"base_program_sha256\":\"3c23a21fee64b1b677cadd0b9054c1f0abb2599a80351457a01f527a97b965eb\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"a01e39dd8c10c586c22b3e6919befabdbf03f3a9dd984cfa553254e3a65867a1\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"a01e39dd8c10c586c22b3e6919befabdbf03f3a9dd984cfa553254e3a65867a1\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":136,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihew7owy4ahqqn5j443qtnw247evrwd3d2ccqw54wttevi4jnzatu\",\"base_program_sha256\":\"3c23a21fee64b1b677cadd0b9054c1f0abb2599a80351457a01f527a97b965eb\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.answer.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 < current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.answer.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.answer.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.answer.local"].contains symbol

example : (["symbol:derive.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_66

namespace Candidate_67
def sourceEvidenceOriginalProgramSHA256 : String := "aadd283a7a661e524f4fa879ce4168283acea7fb274a2f73e6b25bb21fdf0b51"

def sourceEvidenceOperationalViewSHA256 : String := "be0d02fb502186d6b17c2d65e7313d2e5e741083d1cd04ee24f3bea7f93ee6ab"

def sourceEvidenceSourceSHA256 : String := "79aedafdee3e718e11c1b85ee32a15d6435da086011b05df862e365e31fdd98d"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidhabb22vsjleehprytdgjraywtgshmdhtnm2bovjbppjz7cytblm\",\"base_program_sha256\":\"c53d698191bbcbe3222406f8f0eba8f6dfc4be8467b03b2fd9ae18b7582d698e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"79aedafdee3e718e11c1b85ee32a15d6435da086011b05df862e365e31fdd98d\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"79aedafdee3e718e11c1b85ee32a15d6435da086011b05df862e365e31fdd98d\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":136,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidhabb22vsjleehprytdgjraywtgshmdhtnm2bovjbppjz7cytblm\",\"base_program_sha256\":\"c53d698191bbcbe3222406f8f0eba8f6dfc4be8467b03b2fd9ae18b7582d698e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.answer.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 < current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.answer.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.answer.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.answer.local"].contains symbol

example : (["symbol:assess.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_67

namespace Candidate_68
def sourceEvidenceOriginalProgramSHA256 : String := "dc63136ffc706642c4849cc5dc1180361b375cf391163d1981577ab495c9565e"

def sourceEvidenceOperationalViewSHA256 : String := "575136da2b762811bdcd50b2f4063b020f514dfaf84368aa0c5a3819fd608166"

def sourceEvidenceSourceSHA256 : String := "c7d260de5f4568529ef738b4f0b4c88927eab021e8d558f0048fcb9cd63a13df"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihldlcnt2qfiaqjgoevw7qbb3ozz3xcmcp6p6a6jb3hwwwigiqbbe\",\"base_program_sha256\":\"dbb9e6cee43e33b92056aeb05f7e132752c8ea2902ee1b2f768538ff073e553a\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"c7d260de5f4568529ef738b4f0b4c88927eab021e8d558f0048fcb9cd63a13df\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"c7d260de5f4568529ef738b4f0b4c88927eab021e8d558f0048fcb9cd63a13df\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":137,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihldlcnt2qfiaqjgoevw7qbb3ozz3xcmcp6p6a6jb3hwwwigiqbbe\",\"base_program_sha256\":\"dbb9e6cee43e33b92056aeb05f7e132752c8ea2902ee1b2f768538ff073e553a\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 < current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.answer.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.answer.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.answer.local"].contains symbol

example : (["symbol:resolve.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_68

namespace Candidate_69
def sourceEvidenceOriginalProgramSHA256 : String := "4d46d2a21b1d3f470ee6bafb2f4a7c196a01c89d16dfcadab9f756818c0a07ad"

def sourceEvidenceOperationalViewSHA256 : String := "b64a2201bbedc54a394ba9d507dbe6564e9bcf378ce92e830f56ba9bd2446805"

def sourceEvidenceSourceSHA256 : String := "541f5fe055ec35824773894eb5b4533ec89443041db719fe038215ac7c219da9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiemrteh3glwh4xdehimgs7mtgr2wk2w3le3nnn2p4wizrwctxqppe\",\"base_program_sha256\":\"0996bcd7a855056e886ae6d70139748704eddc498561dfc40b2fe85968dd5481\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"541f5fe055ec35824773894eb5b4533ec89443041db719fe038215ac7c219da9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"541f5fe055ec35824773894eb5b4533ec89443041db719fe038215ac7c219da9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":137,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiemrteh3glwh4xdehimgs7mtgr2wk2w3le3nnn2p4wizrwctxqppe\",\"base_program_sha256\":\"0996bcd7a855056e886ae6d70139748704eddc498561dfc40b2fe85968dd5481\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.position.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.position.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.answer.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≤ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.answer.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.answer.local", "symbol:derive.position.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.answer.local"].contains symbol

example : (["symbol:derive.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_69

namespace Candidate_70
def sourceEvidenceOriginalProgramSHA256 : String := "b803739dad193588ca7cd483a9e4134aa925b22061d1130db5e2dd29f9d7083d"

def sourceEvidenceOperationalViewSHA256 : String := "f7d8fa78412b251a863b901f02339622b31bed389f010f22ca72081179854b3d"

def sourceEvidenceSourceSHA256 : String := "973fb3e88bf6a6fd1c29383e8c6cd56fa22bc0eb842c6ba147934f46d3c1390a"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibc4hijyflawtyxnqtxnlm7phd2wisycym6a7d7sgeg4htuweigdi\",\"base_program_sha256\":\"933be4e56e964c82c6d1f9c0d21470b56f3c4fc31a967405f587b7ab3cdea05e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"973fb3e88bf6a6fd1c29383e8c6cd56fa22bc0eb842c6ba147934f46d3c1390a\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"973fb3e88bf6a6fd1c29383e8c6cd56fa22bc0eb842c6ba147934f46d3c1390a\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":137,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibc4hijyflawtyxnqtxnlm7phd2wisycym6a7d7sgeg4htuweigdi\",\"base_program_sha256\":\"933be4e56e964c82c6d1f9c0d21470b56f3c4fc31a967405f587b7ab3cdea05e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.position.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.position.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.answer.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≤ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.answer.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.answer.local", "symbol:assess.position.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.answer.local"].contains symbol

example : (["symbol:assess.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_70

namespace Candidate_71
def sourceEvidenceOriginalProgramSHA256 : String := "699ab810b4dbba55c3997e11eb1ea8c18144b795e704cf6b6e965562c483970e"

def sourceEvidenceOperationalViewSHA256 : String := "6524d51ae5ba1ed8345597439bee3713d523d8d612e3a0cb28570fed1eb2ec65"

def sourceEvidenceSourceSHA256 : String := "ac9088eaaca78f6bf65b1ba11f25cb46f8bda9a097cf323090fa7fea13d23115"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibfs4git5ijjkvobalrqi6smiipgh4lb7xetdlugn4bfiqbwndx6m\",\"base_program_sha256\":\"8c8b838691516a9dbd04455cb4f5c2c4f6d18493a72d29224530c147ac21bf9f\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"ac9088eaaca78f6bf65b1ba11f25cb46f8bda9a097cf323090fa7fea13d23115\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"ac9088eaaca78f6bf65b1ba11f25cb46f8bda9a097cf323090fa7fea13d23115\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":138,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibfs4git5ijjkvobalrqi6smiipgh4lb7xetdlugn4bfiqbwndx6m\",\"base_program_sha256\":\"8c8b838691516a9dbd04455cb4f5c2c4f6d18493a72d29224530c147ac21bf9f\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.position.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≤ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.answer.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.answer.local", "symbol:resolve.position.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.answer.local"].contains symbol

example : (["symbol:resolve.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_71

namespace Candidate_72
def sourceEvidenceOriginalProgramSHA256 : String := "5de9f17ebbee64791e14cdb2180c92f705bc448daa5fc05961ec0f6a568c1e39"

def sourceEvidenceOperationalViewSHA256 : String := "f41d08923952b7e6ad13c40fd1216757bc23177f92bf0dba095e2e1425bf93bd"

def sourceEvidenceSourceSHA256 : String := "64038dd5e97d3c5cc39ca28ed29cd6a6e532902e3c6592fe2e52fddfd006fbf9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreifqspiss4htk4pa53x2p4vkwimqspe424r6hidmpx5gixaxypkxrm\",\"base_program_sha256\":\"9b32542a7d8e15e194997a0943eda951bed76b2695accd2320fbd2acb37d2cba\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"64038dd5e97d3c5cc39ca28ed29cd6a6e532902e3c6592fe2e52fddfd006fbf9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"64038dd5e97d3c5cc39ca28ed29cd6a6e532902e3c6592fe2e52fddfd006fbf9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":79,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreifqspiss4htk4pa53x2p4vkwimqspe424r6hidmpx5gixaxypkxrm\",\"base_program_sha256\":\"9b32542a7d8e15e194997a0943eda951bed76b2695accd2320fbd2acb37d2cba\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 > current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_72

namespace Candidate_73
def sourceEvidenceOriginalProgramSHA256 : String := "dabc6ef1cc877e42e5ffacbc71ea338dd96a6bf0813b51b865c2fa90f6ed1df9"

def sourceEvidenceOperationalViewSHA256 : String := "a51b31ccde3f81467ec612459688905e57cb5fa89f01866ef53cf72ac784b32b"

def sourceEvidenceSourceSHA256 : String := "5bb6a2affc29f16e557231f6bd3afc848d1b3f02f24e4fd00b57dcbb8c9f2db5"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibofzmzjliq6yv6mkjxwo7iwba7haom3xinn6qgoef4zk3335p4ti\",\"base_program_sha256\":\"d408a98d737b17fb2712c4c206838bd421df9d0ff528db3b2c7fb62200dbe5c2\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"5bb6a2affc29f16e557231f6bd3afc848d1b3f02f24e4fd00b57dcbb8c9f2db5\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"5bb6a2affc29f16e557231f6bd3afc848d1b3f02f24e4fd00b57dcbb8c9f2db5\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":79,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibofzmzjliq6yv6mkjxwo7iwba7haom3xinn6qgoef4zk3335p4ti\",\"base_program_sha256\":\"d408a98d737b17fb2712c4c206838bd421df9d0ff528db3b2c7fb62200dbe5c2\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 > current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_73

namespace Candidate_74
def sourceEvidenceOriginalProgramSHA256 : String := "7b0c82ad518bd5492870885fb5f6299736a88d275219a505520f378f92b001e3"

def sourceEvidenceOperationalViewSHA256 : String := "e0a845f114085d42d17f5ba7282c049ad2b9e6a57a405599b7f93935f700f470"

def sourceEvidenceSourceSHA256 : String := "b6ebac04c9f31c6b09b73aa169b38783a17448050acaea40ef8a4940377f562d"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreia2pa6lj56o7ffqfbhrkaooo25dqsuw6kdfywhc43bgnvae3j547y\",\"base_program_sha256\":\"57d3c72bd257f92fd561f9637291bc99be5ea34634de696eb9d322038aba6f4a\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"b6ebac04c9f31c6b09b73aa169b38783a17448050acaea40ef8a4940377f562d\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"b6ebac04c9f31c6b09b73aa169b38783a17448050acaea40ef8a4940377f562d\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":80,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreia2pa6lj56o7ffqfbhrkaooo25dqsuw6kdfywhc43bgnvae3j547y\",\"base_program_sha256\":\"57d3c72bd257f92fd561f9637291bc99be5ea34634de696eb9d322038aba6f4a\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 > current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_74

namespace Candidate_75
def sourceEvidenceOriginalProgramSHA256 : String := "a2779045fd6f5bd2a2c437638ed207db29fe6a21fb3aa09ba3089628e537d4e3"

def sourceEvidenceOperationalViewSHA256 : String := "d83da6a4b2b38d1248319be19f3c0bcfeda12f4c83f0719fe32846f8f3375ac6"

def sourceEvidenceSourceSHA256 : String := "2fd3642a2b8dda58579c3b07751298c58c77ac5a72a9b1bf7ff477e6ddd2e187"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiczxow2difwspv2kjebq7ls4kddozvfzujkq2vyaoxx5hezjqjqiq\",\"base_program_sha256\":\"fe32b3c15dc2975c06278187ed09d682b2169799055d0c5c0f47b3d912169f10\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"2fd3642a2b8dda58579c3b07751298c58c77ac5a72a9b1bf7ff477e6ddd2e187\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"2fd3642a2b8dda58579c3b07751298c58c77ac5a72a9b1bf7ff477e6ddd2e187\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":80,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiczxow2difwspv2kjebq7ls4kddozvfzujkq2vyaoxx5hezjqjqiq\",\"base_program_sha256\":\"fe32b3c15dc2975c06278187ed09d682b2169799055d0c5c0f47b3d912169f10\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≥ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_75

namespace Candidate_76
def sourceEvidenceOriginalProgramSHA256 : String := "45bb278f639659fb080a3b0dd2fd7a7d9347fb56d25d5703fed058e1ba86bfd1"

def sourceEvidenceOperationalViewSHA256 : String := "10f8bbe61e3ca485fda120f4d6e3b139d0c8310904be39e76d0b2ade6932f706"

def sourceEvidenceSourceSHA256 : String := "cffc438a6a3b02af565a58ee7830c1f70099c4b38eabc959d47fa1b86bf53356"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicta6wrfv3cnozxhl4inbbzbvvrepm5kwdo2mjrsi4t4244luhnse\",\"base_program_sha256\":\"50466551b35b1ba05e05fc48bc0e38f3d0d010df1aecca0f93f954e874d43809\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"cffc438a6a3b02af565a58ee7830c1f70099c4b38eabc959d47fa1b86bf53356\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"cffc438a6a3b02af565a58ee7830c1f70099c4b38eabc959d47fa1b86bf53356\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":80,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicta6wrfv3cnozxhl4inbbzbvvrepm5kwdo2mjrsi4t4244luhnse\",\"base_program_sha256\":\"50466551b35b1ba05e05fc48bc0e38f3d0d010df1aecca0f93f954e874d43809\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≥ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_76

namespace Candidate_77
def sourceEvidenceOriginalProgramSHA256 : String := "f9e9fb9eee13918067e460d863936c776b9e4187322f54cfb384676037156462"

def sourceEvidenceOperationalViewSHA256 : String := "105fae0a9660b4d0da6fb0120056d13ad5d576dbd05f76bf896edf0c8c3012b3"

def sourceEvidenceSourceSHA256 : String := "832928dd9b7605092d89ca77928d8be61c1edcc9c9d167fd54367e56b6a703cb"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibeb2ympvoeje6vpizqycnodld6empawrlrkdhkewwrv46kmw62lm\",\"base_program_sha256\":\"02de82b9e8a7a4561bc022293d65d6a779555f96e92bf51f881c41b0c79e46b5\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"832928dd9b7605092d89ca77928d8be61c1edcc9c9d167fd54367e56b6a703cb\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"832928dd9b7605092d89ca77928d8be61c1edcc9c9d167fd54367e56b6a703cb\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":81,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibeb2ympvoeje6vpizqycnodld6empawrlrkdhkewwrv46kmw62lm\",\"base_program_sha256\":\"02de82b9e8a7a4561bc022293d65d6a779555f96e92bf51f881c41b0c79e46b5\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≥ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_77

namespace Candidate_78
def sourceEvidenceOriginalProgramSHA256 : String := "29ee5305757cc0a539556e1d43cf1d59dbf0c753b9b5facfb629c55682bd8877"

def sourceEvidenceOperationalViewSHA256 : String := "ff6a63c55704dab0e94f3bc921b4e603f47ee77240482b992585ebc40876e7b4"

def sourceEvidenceSourceSHA256 : String := "7e0797ad55b1f99a0b84e5319fb0d325bd7050b4c4e1a3a47fa4c6ff3049f88c"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreic3zmejqlvi72gi45uqnfow3qqgdssfgztyq6eyefapjvytkcja5a\",\"base_program_sha256\":\"071de8c913f5a543795249174406019fef809d21e710ab568f45abe3c7203e6c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"7e0797ad55b1f99a0b84e5319fb0d325bd7050b4c4e1a3a47fa4c6ff3049f88c\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"7e0797ad55b1f99a0b84e5319fb0d325bd7050b4c4e1a3a47fa4c6ff3049f88c\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":122,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreic3zmejqlvi72gi45uqnfow3qqgdssfgztyq6eyefapjvytkcja5a\",\"base_program_sha256\":\"071de8c913f5a543795249174406019fef809d21e710ab568f45abe3c7203e6c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 > current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_78

namespace Candidate_79
def sourceEvidenceOriginalProgramSHA256 : String := "0189ebbbec579c8ffb7183996dcf61f162b95edfbb199e81746aa96a22d6ede5"

def sourceEvidenceOperationalViewSHA256 : String := "fc8e3e5b906159f4635f8e1b3ac81f79a55ae0a1c80d21876652924840a1a8bb"

def sourceEvidenceSourceSHA256 : String := "dac76ec4d3b9f23b048f7369a57b262e7664cc25b6c33dbdff44a6efaf9c26cd"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreifsez7olqjx45x5ylpdw26foe7nrc5pnsxeyppd7jbl2tif5ltmpa\",\"base_program_sha256\":\"c9aff133005385f40cc1fd9570a51cdaee709f3e848c8e4c23a7b924f7fbf9a7\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"dac76ec4d3b9f23b048f7369a57b262e7664cc25b6c33dbdff44a6efaf9c26cd\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"dac76ec4d3b9f23b048f7369a57b262e7664cc25b6c33dbdff44a6efaf9c26cd\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":122,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreifsez7olqjx45x5ylpdw26foe7nrc5pnsxeyppd7jbl2tif5ltmpa\",\"base_program_sha256\":\"c9aff133005385f40cc1fd9570a51cdaee709f3e848c8e4c23a7b924f7fbf9a7\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 > current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_79

namespace Candidate_80
def sourceEvidenceOriginalProgramSHA256 : String := "fc5b56ad9b49241ecfa21d2e52e6e67a1b87ab69458174808f2794ac4a16cb65"

def sourceEvidenceOperationalViewSHA256 : String := "1c9e6afaeac419474c9220c5af5bb2f7fb9bbcb7911e71ab9a788d05098cc79a"

def sourceEvidenceSourceSHA256 : String := "17a5ff9c0d59281cbc7e33addc6970d7d98f4b803411734d071878bb90ce5367"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibd4hru4eep7t3i6cl4ykbgq7oa4hyaowaapgyqvyk35jkktacdsy\",\"base_program_sha256\":\"7d643eb977d7aaa29adc5505f24797338e0710e67a013121ec193fc67d7a08db\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"17a5ff9c0d59281cbc7e33addc6970d7d98f4b803411734d071878bb90ce5367\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"17a5ff9c0d59281cbc7e33addc6970d7d98f4b803411734d071878bb90ce5367\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":123,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibd4hru4eep7t3i6cl4ykbgq7oa4hyaowaapgyqvyk35jkktacdsy\",\"base_program_sha256\":\"7d643eb977d7aaa29adc5505f24797338e0710e67a013121ec193fc67d7a08db\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 > current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_80

namespace Candidate_81
def sourceEvidenceOriginalProgramSHA256 : String := "df28c33d16f153c61a8df84392ae6b90da0dea5eacfa303ed352e821747061be"

def sourceEvidenceOperationalViewSHA256 : String := "22c09e602f42a1e46047b11c1acb0214a1c09767e60ffa99ec1b92a3269f8f27"

def sourceEvidenceSourceSHA256 : String := "96e1d03c29aaf3fbb1c46825c94f461b29ffe87f64892be6ad35d2a0514d862e"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibyovvq7aus7qovlk6iqpnd6iosdnus33koej7t6ussdneezbtwoy\",\"base_program_sha256\":\"13377cc1cf9808dc000ced242f6ffdafd81ead420735300d719a4210fbe6568d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"96e1d03c29aaf3fbb1c46825c94f461b29ffe87f64892be6ad35d2a0514d862e\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"96e1d03c29aaf3fbb1c46825c94f461b29ffe87f64892be6ad35d2a0514d862e\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":123,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibyovvq7aus7qovlk6iqpnd6iosdnus33koej7t6ussdneezbtwoy\",\"base_program_sha256\":\"13377cc1cf9808dc000ced242f6ffdafd81ead420735300d719a4210fbe6568d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≥ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_81

namespace Candidate_82
def sourceEvidenceOriginalProgramSHA256 : String := "1349effdd33cfa47b67476a24e1d2f79441a08764b91f74120fad09209a98784"

def sourceEvidenceOperationalViewSHA256 : String := "214bd290e4cc7877797b91c1706255219809fe0e2f05582d0cb719b1f27a41d7"

def sourceEvidenceSourceSHA256 : String := "3ec017e367af0cb453023b138a3672d40548533940c9ad1fe5f41ba49fa17f56"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreifmd6d7l4qcd6ljcqfuziaz5qnmbu6druuoo4gkcorkao5jq4dn2e\",\"base_program_sha256\":\"f463078417fe7745d46dc154312659ef2013997b1ae7dd5a3d9b5955b36a0eff\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"3ec017e367af0cb453023b138a3672d40548533940c9ad1fe5f41ba49fa17f56\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"3ec017e367af0cb453023b138a3672d40548533940c9ad1fe5f41ba49fa17f56\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":123,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreifmd6d7l4qcd6ljcqfuziaz5qnmbu6druuoo4gkcorkao5jq4dn2e\",\"base_program_sha256\":\"f463078417fe7745d46dc154312659ef2013997b1ae7dd5a3d9b5955b36a0eff\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≥ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_82

namespace Candidate_83
def sourceEvidenceOriginalProgramSHA256 : String := "4033403b1326cbe1874d8aaed3a3e871cf1db9abc6dc2c0ebe217ddb21c531f7"

def sourceEvidenceOperationalViewSHA256 : String := "19bd555df429c73217bba6c6a674e3f41040e5c7b1694517da5498e8b108a70f"

def sourceEvidenceSourceSHA256 : String := "2d26134083953b380af4d55b0fbe462f2fc9e3b377079ebc0d8be3235f4aab21"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreie6iqxmkmfmmrsyqjglobv4kumc4w7wuwvocycms3wbgze6ulqyle\",\"base_program_sha256\":\"7a4142c80017486f564c5aa46f8c218aac778c2221708c6a8c07dab4b5e76ed0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"2d26134083953b380af4d55b0fbe462f2fc9e3b377079ebc0d8be3235f4aab21\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"2d26134083953b380af4d55b0fbe462f2fc9e3b377079ebc0d8be3235f4aab21\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":124,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreie6iqxmkmfmmrsyqjglobv4kumc4w7wuwvocycms3wbgze6ulqyle\",\"base_program_sha256\":\"7a4142c80017486f564c5aa46f8c218aac778c2221708c6a8c07dab4b5e76ed0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≥ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_83

namespace Candidate_84
def sourceEvidenceOriginalProgramSHA256 : String := "6266caa68eb070743e6079026924b21c0abe99d176591dfa56c93e86818b3d67"

def sourceEvidenceOperationalViewSHA256 : String := "4e1f0fdf2042500110f70183aa6359a74a59da208288d3cb88c96bf0db1f7ad7"

def sourceEvidenceSourceSHA256 : String := "e6e0b373a598196df958a1ce50ef07480d7ebc2bdf44362e00b0fd7cd092ba3c"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreig65pnjgsyszjtgxxttrwawl7po7kj25zcf4l3mxeec5yvzkgjgna\",\"base_program_sha256\":\"23c5461c0d5f2d0828f9891d9f2268587ebacb144073264a3bda9f8b044e70f4\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"e6e0b373a598196df958a1ce50ef07480d7ebc2bdf44362e00b0fd7cd092ba3c\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"e6e0b373a598196df958a1ce50ef07480d7ebc2bdf44362e00b0fd7cd092ba3c\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":101,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreig65pnjgsyszjtgxxttrwawl7po7kj25zcf4l3mxeec5yvzkgjgna\",\"base_program_sha256\":\"23c5461c0d5f2d0828f9891d9f2268587ebacb144073264a3bda9f8b044e70f4\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.length.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 > current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v1

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.length.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.length.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.outcome.local"].contains symbol

example : (["symbol:derive.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_84

namespace Candidate_85
def sourceEvidenceOriginalProgramSHA256 : String := "5053e12af84f97b898d7771685b08614fb10e61c379066ff95530d0c221a1446"

def sourceEvidenceOperationalViewSHA256 : String := "ab55fef75cbdecf357486ac456d27e604e4f6bb6306c70bb2cdc6c0eb8ead4df"

def sourceEvidenceSourceSHA256 : String := "e8e033dcba579c4be23e55e50910cb4a349a624e0b1da1d230a44b55b2467ef7"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiak3vzzaztwdngz7r57d5ue3w2s2bdxl7jv36ia5oecgsjd7eawua\",\"base_program_sha256\":\"6f2bfd4b3101aeb15766e2eab1856564de5f007bc5d22488f02fcc8b42aab412\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"e8e033dcba579c4be23e55e50910cb4a349a624e0b1da1d230a44b55b2467ef7\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"e8e033dcba579c4be23e55e50910cb4a349a624e0b1da1d230a44b55b2467ef7\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":101,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiak3vzzaztwdngz7r57d5ue3w2s2bdxl7jv36ia5oecgsjd7eawua\",\"base_program_sha256\":\"6f2bfd4b3101aeb15766e2eab1856564de5f007bc5d22488f02fcc8b42aab412\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.length.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 > current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v1

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.length.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.length.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.outcome.local"].contains symbol

example : (["symbol:assess.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_85

namespace Candidate_86
def sourceEvidenceOriginalProgramSHA256 : String := "73f2a4d3d1ca32a40d65362784a8a876627a52105ad208e4c9ca97b1215820d2"

def sourceEvidenceOperationalViewSHA256 : String := "5d3a2a944e68944c42e98ba7290d5896206d5aa8baac027af3f272287ffea898"

def sourceEvidenceSourceSHA256 : String := "b208e6c3f3c70b2b45be21cb2cc1c89515974bcb16bc1774f789aaf56ef4df67"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreic64iltgeqwjefacbdwfp6fsxr6mo6kvj5bxxjryulr2kfyfxeama\",\"base_program_sha256\":\"4ecd7520955efb8fe4093f57f0ce53008b8147cbaa2f5580e8c5936363e3bf36\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"b208e6c3f3c70b2b45be21cb2cc1c89515974bcb16bc1774f789aaf56ef4df67\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"b208e6c3f3c70b2b45be21cb2cc1c89515974bcb16bc1774f789aaf56ef4df67\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":102,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreic64iltgeqwjefacbdwfp6fsxr6mo6kvj5bxxjryulr2kfyfxeama\",\"base_program_sha256\":\"4ecd7520955efb8fe4093f57f0ce53008b8147cbaa2f5580e8c5936363e3bf36\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.length.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 > current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v1

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.length.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.length.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.outcome.local"].contains symbol

example : (["symbol:resolve.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_86

namespace Candidate_87
def sourceEvidenceOriginalProgramSHA256 : String := "0d7d97bd15ff62ce580bb803b73d3eef33adc42d1fcd657c89e23319b60ee21c"

def sourceEvidenceOperationalViewSHA256 : String := "18bb4a47576f3abf49b1ec09288f9cc7c60db2b44bb2555b5648336d5fa1c124"

def sourceEvidenceSourceSHA256 : String := "46899885196f754aa8838c004a6f9177d7aed68bccd391a1865c38552db16fba"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreia2wzse24hzvgkb4uvibpesngospl5ya5juurmyctjkxv6m3rv7ti\",\"base_program_sha256\":\"a0e52aff0f7e662f80dc3f689cdac7f4db9d05ada838342a5083dc6abc7f4fd1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"46899885196f754aa8838c004a6f9177d7aed68bccd391a1865c38552db16fba\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"46899885196f754aa8838c004a6f9177d7aed68bccd391a1865c38552db16fba\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":102,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreia2wzse24hzvgkb4uvibpesngospl5ya5juurmyctjkxv6m3rv7ti\",\"base_program_sha256\":\"a0e52aff0f7e662f80dc3f689cdac7f4db9d05ada838342a5083dc6abc7f4fd1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.outcome.local\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.length.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≥ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v1

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.length.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.length.parameter", "symbol:derive.outcome.local", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.outcome.local"].contains symbol

example : (["symbol:derive.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_87

namespace Candidate_88
def sourceEvidenceOriginalProgramSHA256 : String := "958fbdd4633cce795f9d2500689ac6c572d09df644551566514aa521f56d58cd"

def sourceEvidenceOperationalViewSHA256 : String := "0967735c2b8aef2b8cec2a952160c74c4ffa91e4b4e81d29dd39641ac1c41d58"

def sourceEvidenceSourceSHA256 : String := "b5a4cfcecb98d1036704ed917a5a50ad4ef7c175d5f8e35a7327c55b1f0ad8f8"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihw5fmdjq5757nklkiuemsxbckorwprp6te52s3xvegssemuyq26i\",\"base_program_sha256\":\"5d21904eb87d933d1b00becc1d8e48ed035b60d87d183b1b99367b2a6cdd257c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"b5a4cfcecb98d1036704ed917a5a50ad4ef7c175d5f8e35a7327c55b1f0ad8f8\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"b5a4cfcecb98d1036704ed917a5a50ad4ef7c175d5f8e35a7327c55b1f0ad8f8\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":102,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihw5fmdjq5757nklkiuemsxbckorwprp6te52s3xvegssemuyq26i\",\"base_program_sha256\":\"5d21904eb87d933d1b00becc1d8e48ed035b60d87d183b1b99367b2a6cdd257c\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.outcome.local\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.length.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≥ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v1

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.length.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.length.parameter", "symbol:assess.outcome.local", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.outcome.local"].contains symbol

example : (["symbol:assess.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_88

namespace Candidate_89
def sourceEvidenceOriginalProgramSHA256 : String := "92e0039dbc10ddabe4c8a06af78d5980186e9335c4c142956ef2d6ac00947a53"

def sourceEvidenceOperationalViewSHA256 : String := "6cee4cd27be529973c04819d9f86d0d5d0e54ac75afa8f822b2f4fab83de3c58"

def sourceEvidenceSourceSHA256 : String := "dcfee3e90c340784cfd8e0f01f5ac70d20ef01b6a8311317f166a4935c555acb"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiez5aqyohzod3n5hbgfellp5sklrtbu67dxjyw3eg2numexuppv5u\",\"base_program_sha256\":\"9b5addab1248d7201597ab87cf626109004feed39c0c7eb28d24bbd545159cd4\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"dcfee3e90c340784cfd8e0f01f5ac70d20ef01b6a8311317f166a4935c555acb\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"dcfee3e90c340784cfd8e0f01f5ac70d20ef01b6a8311317f166a4935c555acb\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":103,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiez5aqyohzod3n5hbgfellp5sklrtbu67dxjyw3eg2numexuppv5u\",\"base_program_sha256\":\"9b5addab1248d7201597ab87cf626109004feed39c0c7eb28d24bbd545159cd4\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.outcome.local\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.length.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≥ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v1

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v1 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.length.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.length.parameter", "symbol:resolve.outcome.local", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.outcome.local"].contains symbol

example : (["symbol:resolve.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_89

namespace Candidate_90
def sourceEvidenceOriginalProgramSHA256 : String := "b08f1516c7ca181a473278708bd6080332768aa4f45d80ff2a9bf9f7fe46be44"

def sourceEvidenceOperationalViewSHA256 : String := "d0b3491f4aac22b9e049488831726a25ba3edcad6bb2a7e91679784f26d60ff8"

def sourceEvidenceSourceSHA256 : String := "f64ee0d0b05a1f2a9de72a313199eba28bedcde23cf2d3e047518c1629476d8b"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreieflhd4cvhmnogtqbnvu3kpcu3nkwo6z4ksfsgapsbiqap4e43fr4\",\"base_program_sha256\":\"f0444d84cba786b776510554c6ba2a8d786e2c505412a47c1c4734c70008a820\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"f64ee0d0b05a1f2a9de72a313199eba28bedcde23cf2d3e047518c1629476d8b\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"f64ee0d0b05a1f2a9de72a313199eba28bedcde23cf2d3e047518c1629476d8b\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":132,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreieflhd4cvhmnogtqbnvu3kpcu3nkwo6z4ksfsgapsbiqap4e43fr4\",\"base_program_sha256\":\"f0444d84cba786b776510554c6ba2a8d786e2c505412a47c1c4734c70008a820\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.answer.local", "symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 > current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.answer.local", "symbol:derive.length.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.answer.local", "symbol:derive.length.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.answer.local"].contains symbol

example : (["symbol:derive.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_90

namespace Candidate_91
def sourceEvidenceOriginalProgramSHA256 : String := "94bb9841ed558159a5d3df02f081484775652ddd7d366805e61351e3c3813b0c"

def sourceEvidenceOperationalViewSHA256 : String := "783c8d4403024727d33002cc5b68692fa317dc745b1d1274b363eca55b0b592e"

def sourceEvidenceSourceSHA256 : String := "ff73677de7abc187867926ff0c0e5e3d62b88ca29722193902c3c5ad56c5fca1"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreigd2e26obfhftn552cg6xppir4dpoqnvpe76d4jk5noauo2t33lv4\",\"base_program_sha256\":\"bf7d6dee824f97531f5f4672c3de5b4f7d0787b946dd0e3296a592a625df7943\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"ff73677de7abc187867926ff0c0e5e3d62b88ca29722193902c3c5ad56c5fca1\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"ff73677de7abc187867926ff0c0e5e3d62b88ca29722193902c3c5ad56c5fca1\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":132,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreigd2e26obfhftn552cg6xppir4dpoqnvpe76d4jk5noauo2t33lv4\",\"base_program_sha256\":\"bf7d6dee824f97531f5f4672c3de5b4f7d0787b946dd0e3296a592a625df7943\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.answer.local", "symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 > current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.answer.local", "symbol:assess.length.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.answer.local", "symbol:assess.length.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.answer.local"].contains symbol

example : (["symbol:assess.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_91

namespace Candidate_92
def sourceEvidenceOriginalProgramSHA256 : String := "ac981fd63e1ff6fcf878888cb675a27bc8534e738df1a918b7a4cdefd8a97602"

def sourceEvidenceOperationalViewSHA256 : String := "697008da614e6c65548678e3739e01e3048e87017e88225d2840e8ee898d127b"

def sourceEvidenceSourceSHA256 : String := "27b5df2de858483cc209e994dcc673bc026f211d3857a3902b181cb9abce5162"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiciqveyrjw4uko4qr2fqmldbzpfu3mdaxhmtw74bosso2t6jlmvpy\",\"base_program_sha256\":\"9fd6d2fd4fda5c72b28b7444ddc5365d977480d1141f5920b00f1b82f1c0b1dd\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"27b5df2de858483cc209e994dcc673bc026f211d3857a3902b181cb9abce5162\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"27b5df2de858483cc209e994dcc673bc026f211d3857a3902b181cb9abce5162\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":133,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiciqveyrjw4uko4qr2fqmldbzpfu3mdaxhmtw74bosso2t6jlmvpy\",\"base_program_sha256\":\"9fd6d2fd4fda5c72b28b7444ddc5365d977480d1141f5920b00f1b82f1c0b1dd\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local", "symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 > current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.answer.local", "symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.answer.local", "symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.answer.local"].contains symbol

example : (["symbol:resolve.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_92

namespace Candidate_93
def sourceEvidenceOriginalProgramSHA256 : String := "68b86b4e8443d530f47ce8f330a2fab45619233692d681c3cd61ec7cbc690e1e"

def sourceEvidenceOperationalViewSHA256 : String := "00690759f2d23d66b2e2f25f0c41ab98cb3c76cba09dafc994e7c3699e1306af"

def sourceEvidenceSourceSHA256 : String := "d4f262154b2adadafe41646afb6fd3b22d4d4156a8028ab6619247d88a6c928f"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidevwhkrxcref7j3ke3pln4kj7zusvqigyzfnojnkheo2rydcsssi\",\"base_program_sha256\":\"101047fdaf4e536411e8ffa4ce4357a30fb6369502e0f332d7d777b6c76b16d1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"d4f262154b2adadafe41646afb6fd3b22d4d4156a8028ab6619247d88a6c928f\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"d4f262154b2adadafe41646afb6fd3b22d4d4156a8028ab6619247d88a6c928f\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":133,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidevwhkrxcref7j3ke3pln4kj7zusvqigyzfnojnkheo2rydcsssi\",\"base_program_sha256\":\"101047fdaf4e536411e8ffa4ce4357a30fb6369502e0f332d7d777b6c76b16d1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.length.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.length.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.answer.local", "symbol:derive.length.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≥ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.answer.local", "symbol:derive.length.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.answer.local", "symbol:derive.length.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.answer.local"].contains symbol

example : (["symbol:derive.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_93

namespace Candidate_94
def sourceEvidenceOriginalProgramSHA256 : String := "b76b766f83090588092e3fd549051dd53914d576f00f14308b3f584d960f71b8"

def sourceEvidenceOperationalViewSHA256 : String := "437189256f74b7d7abf660a9e64d2e4cbc89f818008dd876a71fe2bfe9e6677f"

def sourceEvidenceSourceSHA256 : String := "972709db89e0b2cb1ac4ff844782565503fac9c472e7f591517dc70d1b54cb08"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiexhx6wdaoayhbmol7ovbzppgcyckigmzyh4z2dkr6367ba4pwvoq\",\"base_program_sha256\":\"e0d786700bc4eff1726c3e382f1dce00ed190e5928db2614b20ff437f48e251b\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"972709db89e0b2cb1ac4ff844782565503fac9c472e7f591517dc70d1b54cb08\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"972709db89e0b2cb1ac4ff844782565503fac9c472e7f591517dc70d1b54cb08\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":133,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiexhx6wdaoayhbmol7ovbzppgcyckigmzyh4z2dkr6367ba4pwvoq\",\"base_program_sha256\":\"e0d786700bc4eff1726c3e382f1dce00ed190e5928db2614b20ff437f48e251b\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.length.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.length.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.answer.local", "symbol:assess.length.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≥ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.answer.local", "symbol:assess.length.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.answer.local", "symbol:assess.length.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.answer.local"].contains symbol

example : (["symbol:assess.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_94

namespace Candidate_95
def sourceEvidenceOriginalProgramSHA256 : String := "33db6fe3becc3abc3e0d28eab633f7a00f9a10c39c520c78ac1c59751bfe3133"

def sourceEvidenceOperationalViewSHA256 : String := "e1e0bb84f10083e1457692054e0300ae083207f6ad8dd3592815d62a6b838f99"

def sourceEvidenceSourceSHA256 : String := "0da7c10adeba28fc654ff8c98dd0298a32fbf65ea83c2ee9e82b25f45b5a0983"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreifu7vjbz6rlpe4bx6licxhk77p7lbayouxeah746ouyaplja6wah4\",\"base_program_sha256\":\"798285d8af54805613f7a958a3613017db9e0dcbeba2284ef6fe73b8297132da\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0da7c10adeba28fc654ff8c98dd0298a32fbf65ea83c2ee9e82b25f45b5a0983\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"0da7c10adeba28fc654ff8c98dd0298a32fbf65ea83c2ee9e82b25f45b5a0983\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":134,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreifu7vjbz6rlpe4bx6licxhk77p7lbayouxeah746ouyaplja6wah4\",\"base_program_sha256\":\"798285d8af54805613f7a958a3613017db9e0dcbeba2284ef6fe73b8297132da\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.length.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local", "symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≥ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.answer.local", "symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.answer.local", "symbol:resolve.length.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.answer.local"].contains symbol

example : (["symbol:resolve.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_95

namespace Candidate_96
def sourceEvidenceOriginalProgramSHA256 : String := "7c87509795b1cfd10c5d687cf2cb682cfcb87203b77b618ef47bfab1afb9c605"

def sourceEvidenceOperationalViewSHA256 : String := "a777297b6258e37a049c02996708392c04ec7f09c0a5880903f14d3f0e1232ab"

def sourceEvidenceSourceSHA256 : String := "cba5b604f273ff8419e3b759ab55de4227a2a41c24cdbbe517f8b310875ec493"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiehdpkwf3yqyylq52oo4yxrwgc3gqivcatqkptee2puga3paldeiy\",\"base_program_sha256\":\"b34325fab7640f44aa5feb4d5c9a74e5ce52362ee5c1be1dea8e903b914738cb\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"cba5b604f273ff8419e3b759ab55de4227a2a41c24cdbbe517f8b310875ec493\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"cba5b604f273ff8419e3b759ab55de4227a2a41c24cdbbe517f8b310875ec493\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":84,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiehdpkwf3yqyylq52oo4yxrwgc3gqivcatqkptee2puga3paldeiy\",\"base_program_sha256\":\"b34325fab7640f44aa5feb4d5c9a74e5ce52362ee5c1be1dea8e903b914738cb\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 = current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_96

namespace Candidate_97
def sourceEvidenceOriginalProgramSHA256 : String := "0433e443835200a98cb18dcd28f1a12f5aedbd1e232f8840d51d1eeeabf67240"

def sourceEvidenceOperationalViewSHA256 : String := "dc735ac1369098bc66db9e19892945f03b93c5edb18882763b4a84776a6a703d"

def sourceEvidenceSourceSHA256 : String := "87495a2efb926b4b8ff1ce5721dfda4ffd4b419d4b4273a8e6f93c090f82c15e"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiatgpundskbpshnrvjhtpq7wmcr6ed3qd56e2zuceyycogcykhydi\",\"base_program_sha256\":\"3d393670ee3b0539af64b5cc1195cac922b4d75f8e1fdbaf25b10aafad29aad4\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"87495a2efb926b4b8ff1ce5721dfda4ffd4b419d4b4273a8e6f93c090f82c15e\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"87495a2efb926b4b8ff1ce5721dfda4ffd4b419d4b4273a8e6f93c090f82c15e\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":84,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiatgpundskbpshnrvjhtpq7wmcr6ed3qd56e2zuceyycogcykhydi\",\"base_program_sha256\":\"3d393670ee3b0539af64b5cc1195cac922b4d75f8e1fdbaf25b10aafad29aad4\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 = current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_97

namespace Candidate_98
def sourceEvidenceOriginalProgramSHA256 : String := "82a4e546fa72fd74300850ce1bed51b6b3174dffeac9081e4b1fd29e9988e677"

def sourceEvidenceOperationalViewSHA256 : String := "1f00e884dbe164ec7e9ed8ced50b1347eec190d83bcbce4637947d0692cd0514"

def sourceEvidenceSourceSHA256 : String := "5e2d93dcd85d456f129434dcb01341626546e4613756f6ddfe69ead6edf5c881"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreifn4wceytpjrqxd24c4beafg7l2oe3w7g26k5xpwmazwhbktfwx7a\",\"base_program_sha256\":\"074bebf17a0df8dc50f43d6c2f88f1181a3cbb8a7388b27d3b7860a6f1278fcb\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"5e2d93dcd85d456f129434dcb01341626546e4613756f6ddfe69ead6edf5c881\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"5e2d93dcd85d456f129434dcb01341626546e4613756f6ddfe69ead6edf5c881\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":85,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreifn4wceytpjrqxd24c4beafg7l2oe3w7g26k5xpwmazwhbktfwx7a\",\"base_program_sha256\":\"074bebf17a0df8dc50f43d6c2f88f1181a3cbb8a7388b27d3b7860a6f1278fcb\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 = current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_98

namespace Candidate_99
def sourceEvidenceOriginalProgramSHA256 : String := "8dde9747701057d7ed753d81ab74ce08433e0741d6f3e26f24011f9211868502"

def sourceEvidenceOperationalViewSHA256 : String := "d498bc4639192c5bb4c8d09250d36c37c64853841fe4dfb775f564a934aaf831"

def sourceEvidenceSourceSHA256 : String := "a191a8c27a66784383fb7a41d3f8e4f1b82390ab013bc4d6411844b4e2a9ad4d"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicvwzo37kiqrr5me3b5isao3oa2cvdv46g4bolcfa363nc4r37xmu\",\"base_program_sha256\":\"37e133654e105c3a545805ba058019040b87a6bbd827e1cd3688d50d8a14b54e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"a191a8c27a66784383fb7a41d3f8e4f1b82390ab013bc4d6411844b4e2a9ad4d\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"a191a8c27a66784383fb7a41d3f8e4f1b82390ab013bc4d6411844b4e2a9ad4d\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":84,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicvwzo37kiqrr5me3b5isao3oa2cvdv46g4bolcfa363nc4r37xmu\",\"base_program_sha256\":\"37e133654e105c3a545805ba058019040b87a6bbd827e1cd3688d50d8a14b54e\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≠ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_99

namespace Candidate_100
def sourceEvidenceOriginalProgramSHA256 : String := "c7ea4e9c81e6250c7c5edf9d71d9470fe1702a8c1e165af0f5ce984e878b76ab"

def sourceEvidenceOperationalViewSHA256 : String := "ce0303cff38674960d5459ab65ca0f5107cd73709396e012f6d87bbf0b3fc56d"

def sourceEvidenceSourceSHA256 : String := "58b8b0bbe7c87db965ccd97f8c329fb34d90d10dc3c654d6b3d263f192fe974e"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiaqs4wp4qn6qvnippbxc3g7yfud7rtpvzpdr5nozw34pqnk3exdii\",\"base_program_sha256\":\"afc616211a74bb4f183cbbf329ee465a5d1e87a1545475b6278217c4d4f9c605\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"58b8b0bbe7c87db965ccd97f8c329fb34d90d10dc3c654d6b3d263f192fe974e\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"58b8b0bbe7c87db965ccd97f8c329fb34d90d10dc3c654d6b3d263f192fe974e\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":84,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiaqs4wp4qn6qvnippbxc3g7yfud7rtpvzpdr5nozw34pqnk3exdii\",\"base_program_sha256\":\"afc616211a74bb4f183cbbf329ee465a5d1e87a1545475b6278217c4d4f9c605\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≠ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_100

namespace Candidate_101
def sourceEvidenceOriginalProgramSHA256 : String := "caf64ec25064453b924eebdaf86fdf0fa4f3e6e1173cc8554e911c69916ed428"

def sourceEvidenceOperationalViewSHA256 : String := "953759a3a8efa398b210d10402609278e6cbc1111ff780cdab222307f11bb97e"

def sourceEvidenceSourceSHA256 : String := "88f77bb8b8c1cce11ae5b121a672beec870e3e1d3db2d14793333ece103ff11b"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibqsx4tdfhqntafxry3qh5qwuihjbos775azsgira3ss57vumltzi\",\"base_program_sha256\":\"6b500b1a5a8bacea3119eae17bda675a0b2e92d54580adda1d09b3acfe3bfec0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"88f77bb8b8c1cce11ae5b121a672beec870e3e1d3db2d14793333ece103ff11b\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"88f77bb8b8c1cce11ae5b121a672beec870e3e1d3db2d14793333ece103ff11b\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":85,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibqsx4tdfhqntafxry3qh5qwuihjbos775azsgira3ss57vumltzi\",\"base_program_sha256\":\"6b500b1a5a8bacea3119eae17bda675a0b2e92d54580adda1d09b3acfe3bfec0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≠ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_101

namespace Candidate_102
def sourceEvidenceOriginalProgramSHA256 : String := "43571049d22fef66f9626eb9e889bfa776312638e25b051fa05530fcee54c1ab"

def sourceEvidenceOperationalViewSHA256 : String := "c314bcc5dda790869a7eec0160c06b98551f8cdab9a81ffe50c5f95d61377a39"

def sourceEvidenceSourceSHA256 : String := "3af66f4542b82b62e30bf16764a245d465b6dfd63a2b0d537b7bc2baa78b2d68"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiehijvcsdbshft2kuv3dxdcq5zme3iefj2r4uvqzrbczify7ktfoy\",\"base_program_sha256\":\"8fb8001cb85f4ace80c4739d87cfe005e6ec1d875591429742980cb08c3e40f8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"3af66f4542b82b62e30bf16764a245d465b6dfd63a2b0d537b7bc2baa78b2d68\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"3af66f4542b82b62e30bf16764a245d465b6dfd63a2b0d537b7bc2baa78b2d68\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":127,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiehijvcsdbshft2kuv3dxdcq5zme3iefj2r4uvqzrbczify7ktfoy\",\"base_program_sha256\":\"8fb8001cb85f4ace80c4739d87cfe005e6ec1d875591429742980cb08c3e40f8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 = current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_102

namespace Candidate_103
def sourceEvidenceOriginalProgramSHA256 : String := "99e1eeb35ce318df1392883af1c02348d60af6c23cf5cdb75a64c3c762773cad"

def sourceEvidenceOperationalViewSHA256 : String := "7e68b88d71fcd9fa20105392d46a0da026f8c127008de3cf636c0780a6ffda37"

def sourceEvidenceSourceSHA256 : String := "5fe08d78d310eca9d8f8e8c1c081b2dd5ff5f98846d1019c0ae58ebd6a8a54bb"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidrkkkpnx7gu7s6ut3ovbzn2ripmi2x42o2d7x5kru74vkaebs5hu\",\"base_program_sha256\":\"d31453342b57f7c27b3c0844dda9b3756de5a2d06366706b24b8f1d71c2c9dd4\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"5fe08d78d310eca9d8f8e8c1c081b2dd5ff5f98846d1019c0ae58ebd6a8a54bb\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"5fe08d78d310eca9d8f8e8c1c081b2dd5ff5f98846d1019c0ae58ebd6a8a54bb\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":127,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidrkkkpnx7gu7s6ut3ovbzn2ripmi2x42o2d7x5kru74vkaebs5hu\",\"base_program_sha256\":\"d31453342b57f7c27b3c0844dda9b3756de5a2d06366706b24b8f1d71c2c9dd4\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 = current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_103

namespace Candidate_104
def sourceEvidenceOriginalProgramSHA256 : String := "fe902fd22dd1001ce9d8722bfced7b244d7e0e8c2a345156be96e963c124fa62"

def sourceEvidenceOperationalViewSHA256 : String := "ab9d63dfb17fbf17e780336d81d6e5435a62f483d179b98748d604fdb83a8f27"

def sourceEvidenceSourceSHA256 : String := "bea73994054a46f7734149a3d04e8cd73d8b271be9ea5457192bdfdfe6d589d5"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreigoo4zwgpmzh2exoeabcyp26fuxrrwfmbw3x37utwvapj2yckbofy\",\"base_program_sha256\":\"feff80670eaa6a52b556fb0c790d97e227ad91f448edd036543c85899760b8b8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"bea73994054a46f7734149a3d04e8cd73d8b271be9ea5457192bdfdfe6d589d5\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"bea73994054a46f7734149a3d04e8cd73d8b271be9ea5457192bdfdfe6d589d5\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":128,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreigoo4zwgpmzh2exoeabcyp26fuxrrwfmbw3x37utwvapj2yckbofy\",\"base_program_sha256\":\"feff80670eaa6a52b556fb0c790d97e227ad91f448edd036543c85899760b8b8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 = current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_104

namespace Candidate_105
def sourceEvidenceOriginalProgramSHA256 : String := "fbbc27367c635d52e9f5c44335487fff927c6164d5775ab44f268531105f4c02"

def sourceEvidenceOperationalViewSHA256 : String := "154d448c18556e1e815c35315801086c053d2d7a95205b6d8f245f02d4492800"

def sourceEvidenceSourceSHA256 : String := "b534693e4d54103ef9e93d3498b0be7572430e0cc63e55f6d6efa68417ba67eb"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreieaxtvgxq6furvzfsqwf7td5gyj4bhhlrpevezgdiqysovednnahm\",\"base_program_sha256\":\"0185c2943e09415c166968089a727af3c68f092689b921a2a4493974d53ec5a0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"b534693e4d54103ef9e93d3498b0be7572430e0cc63e55f6d6efa68417ba67eb\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"b534693e4d54103ef9e93d3498b0be7572430e0cc63e55f6d6efa68417ba67eb\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":127,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreieaxtvgxq6furvzfsqwf7td5gyj4bhhlrpevezgdiqysovednnahm\",\"base_program_sha256\":\"0185c2943e09415c166968089a727af3c68f092689b921a2a4493974d53ec5a0\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≠ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_105

namespace Candidate_106
def sourceEvidenceOriginalProgramSHA256 : String := "629943b81f6169671813f51b2e996943367aa44dd91a0777afd2c16f2cc7d5a4"

def sourceEvidenceOperationalViewSHA256 : String := "503b67c6153689d7300e0523eec34e6a1bbbcfa9dde2c51f751b6ded3e40afab"

def sourceEvidenceSourceSHA256 : String := "83f58296675443911a67a69c9b442ace7597c60662339be26f5089de9f35104b"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibfuyvrmfno2do2mzb6artfgcudfs7e2fayafprvnazetfidmzzsm\",\"base_program_sha256\":\"7bb0f2026754add289426cb546a06f8f15e853fa870a6147d854fee51a9ac046\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"83f58296675443911a67a69c9b442ace7597c60662339be26f5089de9f35104b\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"83f58296675443911a67a69c9b442ace7597c60662339be26f5089de9f35104b\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":127,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibfuyvrmfno2do2mzb6artfgcudfs7e2fayafprvnazetfidmzzsm\",\"base_program_sha256\":\"7bb0f2026754add289426cb546a06f8f15e853fa870a6147d854fee51a9ac046\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:assess\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≠ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_106

namespace Candidate_107
def sourceEvidenceOriginalProgramSHA256 : String := "26e731a1b69f839040ad9f8610d8fb6af7d77919078fc42b28c49267c0283a32"

def sourceEvidenceOperationalViewSHA256 : String := "3acc1b35560437e6fd6811c0f5f5d3d7c815929206d3b23cbd66b760d4a45f97"

def sourceEvidenceSourceSHA256 : String := "77bc22fdc68068315ff9f405df32eba2f0b2d1ba6aea00e0cc9e9cc2f0439cd2"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreiejqiwqxucz7g7gndd6eoei4xxcwvebmxjnqxt3mvoyrrkxm7pdqq\",\"base_program_sha256\":\"ff4ccaf77521b14f592f72fad25529785f11ccb47d8dba583543110ad62bedf2\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"77bc22fdc68068315ff9f405df32eba2f0b2d1ba6aea00e0cc9e9cc2f0439cd2\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"77bc22fdc68068315ff9f405df32eba2f0b2d1ba6aea00e0cc9e9cc2f0439cd2\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":128,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreiejqiwqxucz7g7gndd6eoei4xxcwvebmxjnqxt3mvoyrrkxm7pdqq\",\"base_program_sha256\":\"ff4ccaf77521b14f592f72fad25529785f11ccb47d8dba583543110ad62bedf2\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:resolve\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 ≠ current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Candidate_107

namespace Candidate_108
def sourceEvidenceOriginalProgramSHA256 : String := "f78ae5d58626123c3c5312fde005492cb0d2e208a0b547ecc162d440e4f31946"

def sourceEvidenceOperationalViewSHA256 : String := "4bca821e25a9cc53addd5c0940c5d59dce41d8876b735974d097eb6ee98849f3"

def sourceEvidenceSourceSHA256 : String := "5bd0760fc58df13e7ee5b1d3b677a653fc91302d149ea288380cbf21c65bbd4d"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihvy5hvoyn3w2wsjkaivoau6hbzwbzmwl4ppkguvha54dlvp3kqta\",\"base_program_sha256\":\"1c6248dd73aefe1da8f4789fff0ffcdd35ead432eab357d60e0738035460bee1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"5bd0760fc58df13e7ee5b1d3b677a653fc91302d149ea288380cbf21c65bbd4d\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"5bd0760fc58df13e7ee5b1d3b677a653fc91302d149ea288380cbf21c65bbd4d\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":106,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihvy5hvoyn3w2wsjkaivoau6hbzwbzmwl4ppkguvha54dlvp3kqta\",\"base_program_sha256\":\"1c6248dd73aefe1da8f4789fff0ffcdd35ead432eab357d60e0738035460bee1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 = current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.outcome.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.outcome.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.outcome.local"].contains symbol

example : (["symbol:derive.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_108

namespace Candidate_109
def sourceEvidenceOriginalProgramSHA256 : String := "96758bc969c5dadb919bdee8061e6e55dfc2ed15d52feab4b650654738a2ac8a"

def sourceEvidenceOperationalViewSHA256 : String := "94977be70ced983954c4582fa1346f6228df256d4aef81ff00bde3c47c220534"

def sourceEvidenceSourceSHA256 : String := "805bb957f1bcf2fa8ed71d0e32b1d6b26778c07b65d39ccf998d55dd7a11c2bd"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreig4lhnxs2hy5rzjh4xoplo2bz3lnj2oxofbqzgezrvlemiyy4fote\",\"base_program_sha256\":\"f069926f7306396d40b8af949511f013431e96bcd89d2e5aaafd448baec6bfd1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"805bb957f1bcf2fa8ed71d0e32b1d6b26778c07b65d39ccf998d55dd7a11c2bd\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"805bb957f1bcf2fa8ed71d0e32b1d6b26778c07b65d39ccf998d55dd7a11c2bd\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":106,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreig4lhnxs2hy5rzjh4xoplo2bz3lnj2oxofbqzgezrvlemiyy4fote\",\"base_program_sha256\":\"f069926f7306396d40b8af949511f013431e96bcd89d2e5aaafd448baec6bfd1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 = current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.outcome.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.outcome.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.outcome.local"].contains symbol

example : (["symbol:assess.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_109

namespace Candidate_110
def sourceEvidenceOriginalProgramSHA256 : String := "9aa44eb22204b3ace43b19d390c685ac7ea5123e49091edba2eec02cbdaf6eea"

def sourceEvidenceOperationalViewSHA256 : String := "c0a902b35210da1db8d53ef2bb6d29f8f78324a2f99594607595d6daffd7d9b1"

def sourceEvidenceSourceSHA256 : String := "7f1db1312c5ab58dbcb7c90086f86e8504a1fecce4cb6e587f63aef5f7fb0987"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibk73nwj5vzq4wwnj73gnsfxs7osmaday3cmvvlbf3wmhp6n5cvhi\",\"base_program_sha256\":\"1b82de4c6e982045c03a255a48e06f55bc8956cdf89c0b8261202bef38208a20\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"7f1db1312c5ab58dbcb7c90086f86e8504a1fecce4cb6e587f63aef5f7fb0987\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"7f1db1312c5ab58dbcb7c90086f86e8504a1fecce4cb6e587f63aef5f7fb0987\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":107,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibk73nwj5vzq4wwnj73gnsfxs7osmaday3cmvvlbf3wmhp6n5cvhi\",\"base_program_sha256\":\"1b82de4c6e982045c03a255a48e06f55bc8956cdf89c0b8261202bef38208a20\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 = current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.outcome.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.outcome.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.outcome.local"].contains symbol

example : (["symbol:resolve.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_110

namespace Candidate_111
def sourceEvidenceOriginalProgramSHA256 : String := "9275a6990193909ba7a6f3d753adec53a9c371ea62d3d84575c685c901a51dc1"

def sourceEvidenceOperationalViewSHA256 : String := "9d371d54aabbf69d1960bdab6bca79c45fcf9aefda90ed62076f7ded1ff0c96b"

def sourceEvidenceSourceSHA256 : String := "a456cdfc384c3869aae9f95efc4850e427ebffafbb1ebb57fa25fbcabd80dfa9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreieogv4i7f6e3wvxzddwxf7phfdfgyxwbrarnauvrsre6vify4rk7i\",\"base_program_sha256\":\"9378aa408163e8bf33d9274cc99f9ef1a9c5d6976149594c86aea193cc7f5db3\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"a456cdfc384c3869aae9f95efc4850e427ebffafbb1ebb57fa25fbcabd80dfa9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"a456cdfc384c3869aae9f95efc4850e427ebffafbb1ebb57fa25fbcabd80dfa9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":106,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreieogv4i7f6e3wvxzddwxf7phfdfgyxwbrarnauvrsre6vify4rk7i\",\"base_program_sha256\":\"9378aa408163e8bf33d9274cc99f9ef1a9c5d6976149594c86aea193cc7f5db3\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.outcome.local\",\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.outcome.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≠ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.outcome.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.outcome.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.outcome.local"].contains symbol

example : (["symbol:derive.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_111

namespace Candidate_112
def sourceEvidenceOriginalProgramSHA256 : String := "e6b37898c0e5b48634434cea0f90c85129aadb12aebd872a3340eaeee21b1d61"

def sourceEvidenceOperationalViewSHA256 : String := "a4d0838bdb945f3e96a0c6e3bad7f4742393b177bce7584df9210f8e7a99b59c"

def sourceEvidenceSourceSHA256 : String := "ea6c3148630e2dec28b40552988e5bb6e3c9e501b2c8c77578146bdde4d6479e"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreihgnq73y5lg2my4cfnwj6anb62qsflgeuezvykhypek3lclbfdugq\",\"base_program_sha256\":\"016dcfe82fbfe4877d46ad2c0b96136f41442e9a2ba87d1055ce38ebab62e6ed\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"ea6c3148630e2dec28b40552988e5bb6e3c9e501b2c8c77578146bdde4d6479e\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"ea6c3148630e2dec28b40552988e5bb6e3c9e501b2c8c77578146bdde4d6479e\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":106,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreihgnq73y5lg2my4cfnwj6anb62qsflgeuezvykhypek3lclbfdugq\",\"base_program_sha256\":\"016dcfe82fbfe4877d46ad2c0b96136f41442e9a2ba87d1055ce38ebab62e6ed\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.outcome.local\",\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.outcome.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≠ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.outcome.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.outcome.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.outcome.local"].contains symbol

example : (["symbol:assess.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_112

namespace Candidate_113
def sourceEvidenceOriginalProgramSHA256 : String := "84d836aaf95bbbfdd82095a1df5f40612774ee01f8c71e5188c5e0de09e53ec0"

def sourceEvidenceOperationalViewSHA256 : String := "46776e3372aaf1c42d9cf7b8455d5c647df4360a4fe6c78562b9bba14b6146f3"

def sourceEvidenceSourceSHA256 : String := "26dcd3918b48f26d6fe7e51f06396e9e704151eba19136f65885e652fb30b76f"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreibxrnmrhrjhpbsa7h6pjwtpethgndq4df6ecnndwiamgnhizpwrxm\",\"base_program_sha256\":\"8f819e3a76ab6f4dbf5ee9f9e57207d0a11a85062196a70e3ee44ec230d24bf8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"26dcd3918b48f26d6fe7e51f06396e9e704151eba19136f65885e652fb30b76f\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"26dcd3918b48f26d6fe7e51f06396e9e704151eba19136f65885e652fb30b76f\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":107,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreibxrnmrhrjhpbsa7h6pjwtpethgndq4df6ecnndwiamgnhizpwrxm\",\"base_program_sha256\":\"8f819e3a76ab6f4dbf5ee9f9e57207d0a11a85062196a70e3ee44ec230d24bf8\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.outcome.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.outcome.local\",\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.outcome.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.outcome.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.outcome.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.outcome.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≠ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.outcome.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.outcome.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.outcome.local"].contains symbol

example : (["symbol:resolve.outcome.local"] : List String).all declaredWrites = true := by decide
end Candidate_113

namespace Candidate_114
def sourceEvidenceOriginalProgramSHA256 : String := "108c094e96f3e6b0f2bc002c52f3f17c43d7dec6b468e35853b42ef6474915de"

def sourceEvidenceOperationalViewSHA256 : String := "011dc8c13f82460e3213ffa1ea7113db4de7767bf9a67b31370b25092c0c67df"

def sourceEvidenceSourceSHA256 : String := "379a624995c345fd4bdc4d23172f123265c6993884a0d63dbbb68441e65c6ba1"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreidcurdicjnsrxxrwgezgfuyrhvpp4wmczypygetffhy2axzybmxbu\",\"base_program_sha256\":\"4d602a9cb2dadfdff0109d1866319b6ae38166fe0fc232f7d8b7e13c9be74ff9\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"379a624995c345fd4bdc4d23172f123265c6993884a0d63dbbb68441e65c6ba1\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"379a624995c345fd4bdc4d23172f123265c6993884a0d63dbbb68441e65c6ba1\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":137,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreidcurdicjnsrxxrwgezgfuyrhvpp4wmczypygetffhy2axzybmxbu\",\"base_program_sha256\":\"4d602a9cb2dadfdff0109d1866319b6ae38166fe0fc232f7d8b7e13c9be74ff9\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.answer.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 = current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.answer.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.answer.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.answer.local"].contains symbol

example : (["symbol:derive.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_114

namespace Candidate_115
def sourceEvidenceOriginalProgramSHA256 : String := "0e868dbe9cbb8bde3df43e9d6fe2c8c43169a869311e8c51f9debf2f248b5e63"

def sourceEvidenceOperationalViewSHA256 : String := "9f8801d796fafe35ad713ce7c40fabede2c872cec07d6bc93266c7297c991f2c"

def sourceEvidenceSourceSHA256 : String := "bf3d3984974a1999000caa8997547fd90f69d41caeac15d619037e4caffd6a62"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicgtflvkozyfh7mlsd5ypat3scx7i7esw7cckzkijlxcyty5z3ewi\",\"base_program_sha256\":\"4451311df2e4e7f3862db1bdf9588a2c1e43ce9f7918a0e9ec437289b9937960\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"bf3d3984974a1999000caa8997547fd90f69d41caeac15d619037e4caffd6a62\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"bf3d3984974a1999000caa8997547fd90f69d41caeac15d619037e4caffd6a62\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":137,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicgtflvkozyfh7mlsd5ypat3scx7i7esw7cckzkijlxcyty5z3ewi\",\"base_program_sha256\":\"4451311df2e4e7f3862db1bdf9588a2c1e43ce9f7918a0e9ec437289b9937960\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.answer.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 = current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.answer.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.answer.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.answer.local"].contains symbol

example : (["symbol:assess.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_115

namespace Candidate_116
def sourceEvidenceOriginalProgramSHA256 : String := "a23868e062ae0c3984ebbf0202170d94b8ff1df5dcab478db45261cb1109df69"

def sourceEvidenceOperationalViewSHA256 : String := "a90f6a50e13b0a7982767bd30f931e4087335451238e6197c5501a311e3b5257"

def sourceEvidenceSourceSHA256 : String := "57f8e87638597e56f7c5024dbc33001b2cc65e1020c6eb3dbe5d6628c9c4cd53"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreifo25nhlwycihfbpcu6zaukt3mx46ek6xcp3tnbp5ckzxhu2ckygi\",\"base_program_sha256\":\"c3fe1d537deffa8a3134ff6dfdc54c9d776b02eece306486cf5c236381bf188d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"57f8e87638597e56f7c5024dbc33001b2cc65e1020c6eb3dbe5d6628c9c4cd53\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"57f8e87638597e56f7c5024dbc33001b2cc65e1020c6eb3dbe5d6628c9c4cd53\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":138,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreifo25nhlwycihfbpcu6zaukt3mx46ek6xcp3tnbp5ckzxhu2ckygi\",\"base_program_sha256\":\"c3fe1d537deffa8a3134ff6dfdc54c9d776b02eece306486cf5c236381bf188d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 = current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.answer.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.answer.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.answer.local"].contains symbol

example : (["symbol:resolve.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_116

namespace Candidate_117
def sourceEvidenceOriginalProgramSHA256 : String := "652d9beb58a0b3b38bf4f037f2daeec8765ebc6a6e05f0647df4e689bfbcfb3d"

def sourceEvidenceOperationalViewSHA256 : String := "f7f9f57efa7f96c1ea291413bf55221e05f2975334c7db43121462d9e373858b"

def sourceEvidenceSourceSHA256 : String := "381d274203954d9e024c7f2203cc4f6eb20eaf519327bfe2f6506d04bb375917"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreido4gs3h647gj6ts3zhkeg3b4yv7d3qe5ymcdan3qjwxxb2dmccoa\",\"base_program_sha256\":\"8e7a8cd0b1052ebb555e4b36bf204da95b6623a1342328b942ee9bb6b7cb5209\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"381d274203954d9e024c7f2203cc4f6eb20eaf519327bfe2f6506d04bb375917\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"381d274203954d9e024c7f2203cc4f6eb20eaf519327bfe2f6506d04bb375917\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":137,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreido4gs3h647gj6ts3zhkeg3b4yv7d3qe5ymcdan3qjwxxb2dmccoa\",\"base_program_sha256\":\"8e7a8cd0b1052ebb555e4b36bf204da95b6623a1342328b942ee9bb6b7cb5209\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:derive.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:derive.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.answer.local\",\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"before\":{\"reads\":[\"symbol:derive.quantity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[\"symbol:derive.answer.local\"]},\"function_id\":\"function:derive\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"]), ("command:15", ["symbol:derive.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:derive.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.answer.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", ["symbol:derive.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≠ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.answer.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.answer.local", "symbol:derive.quantity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:derive.answer.local"].contains symbol

example : (["symbol:derive.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_117

namespace Candidate_118
def sourceEvidenceOriginalProgramSHA256 : String := "5584549d86629a3e7b3dae446952946d7913fb6e4f78e0d9bd936accf1bb92a7"

def sourceEvidenceOperationalViewSHA256 : String := "54a14e6eee5cdf8ecf5b68e0f12609c499bc9d23b78ad6d636773c9cc6b82504"

def sourceEvidenceSourceSHA256 : String := "a678709d2f75ea7b9dce48ef7a4c04785a10056ea453393b2d61287010851e9c"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreig73zin75wqfti4a7omrvbbjonx5umbmoykwgndlfbasqp4jkgfqe\",\"base_program_sha256\":\"6841b2aefc59820f0a506bf2302f70822d93f458118472fba10c4e05ca00a8fc\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"a678709d2f75ea7b9dce48ef7a4c04785a10056ea453393b2d61287010851e9c\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"a678709d2f75ea7b9dce48ef7a4c04785a10056ea453393b2d61287010851e9c\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":137,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreig73zin75wqfti4a7omrvbbjonx5umbmoykwgndlfbasqp4jkgfqe\",\"base_program_sha256\":\"6841b2aefc59820f0a506bf2302f70822d93f458118472fba10c4e05ca00a8fc\",\"commands\":[{\"after\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:assess.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:assess.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:assess.answer.local\",\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"before\":{\"reads\":[\"symbol:assess.quantity.parameter\",\"symbol:assess.threshold.parameter\"],\"writes\":[\"symbol:assess.answer.local\"]},\"function_id\":\"function:assess\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"]), ("command:15", ["symbol:assess.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:assess.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:assess", ["symbol:assess.answer.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:assess", ["symbol:assess.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≠ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:assess.answer.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"].contains symbol

example : (["symbol:assess.answer.local", "symbol:assess.quantity.parameter", "symbol:assess.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:assess.answer.local"].contains symbol

example : (["symbol:assess.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_118

namespace Candidate_119
def sourceEvidenceOriginalProgramSHA256 : String := "b30ed9aabbd421ea95b3b285794dc8d112473f3276440cbaf3d461b8dacb49ab"

def sourceEvidenceOperationalViewSHA256 : String := "ecc621f385fa6cf4240cd01314ad81a6c69f4dbfeaec7b32f52b60551d61f8fa"

def sourceEvidenceSourceSHA256 : String := "31da7080dee16a315a0687d92534bbcf0e6b094007db6dd30ec9afa203ded65b"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreif6pzhfakaf5ikpsa2pgbpuglxdrybiqwxxqi2zekyks5pponj4hy\",\"base_program_sha256\":\"d5a2225de57da27f2a49c66782be7174eead71f58ffd238e1c23d06ee66b1600\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"31da7080dee16a315a0687d92534bbcf0e6b094007db6dd30ec9afa203ded65b\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"31da7080dee16a315a0687d92534bbcf0e6b094007db6dd30ec9afa203ded65b\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":138,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreif6pzhfakaf5ikpsa2pgbpuglxdrybiqwxxqi2zekyks5pponj4hy\",\"base_program_sha256\":\"d5a2225de57da27f2a49c66782be7174eead71f58ffd238e1c23d06ee66b1600\",\"commands\":[{\"after\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[],\"writes\":[\"symbol:resolve.answer.local\"]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}},{\"after\":{\"reads\":[\"symbol:resolve.answer.local\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:15\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:resolve.answer.local\",\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"before\":{\"reads\":[\"symbol:resolve.quantity.parameter\",\"symbol:resolve.threshold.parameter\"],\"writes\":[\"symbol:resolve.answer.local\"]},\"function_id\":\"function:resolve\",\"purity\":\"impure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"]), ("command:15", ["symbol:resolve.answer.local"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", ["symbol:resolve.answer.local"]), ("command:15", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:resolve", ["symbol:resolve.answer.local"])]

set_option linter.unusedVariables false

structure Store where

  v0 : Bool

  v1 : Int

  v2 : Bool

  v3 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v1 ≠ current.v3))

def expression_1 (initial current : Store) (returned : Bool) : Bool := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v1

def expression_3 (initial current : Store) (returned : Bool) : Int := current.v3

def run (initial : Store) : Outcome :=
  let current := initial;
  let current := { current with v0 := expression_0 initial current false };
  Outcome.returned current (expression_1 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:resolve.answer.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"].contains symbol

example : (["symbol:resolve.answer.local", "symbol:resolve.quantity.parameter", "symbol:resolve.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := ["symbol:resolve.answer.local"].contains symbol

example : (["symbol:resolve.answer.local"] : List String).all declaredWrites = true := by decide
end Candidate_119

end SecuritySourcePrograms
