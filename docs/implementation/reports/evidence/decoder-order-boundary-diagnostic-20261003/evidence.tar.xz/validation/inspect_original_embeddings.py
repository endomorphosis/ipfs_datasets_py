"""Read-only provenance inspection; does not import Torch or execute an encoder."""
import hashlib
import json
import math
from pathlib import Path

ROOT=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=ROOT/'workspace/test-logs/decoder-order-boundary-diagnostic-20261003'
PREVIOUS=ROOT/'workspace/test-logs/decoder-shared-slot-source-20261003/training-r2-manifest.json'


def binding(path):
    path=Path(path);data=path.read_bytes()
    return {'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}


def run():
    manifest=json.loads(PREVIOUS.read_bytes());paths={k:Path(manifest[k]) for k in ('embeddings','paragraphs')}
    for path in paths.values():assert binding(path)['sha256']==manifest['inputs'][str(path)]
    embeddings=json.loads(paths['embeddings'].read_bytes());paragraphs=json.loads(paths['paragraphs'].read_bytes())
    producer=embeddings['producer'];assert producer['dimension']==384 and producer['encoder_context_tokens']==512
    assert producer['actual_forward_tokens_checked'] and producer['normalized'] and producer['dtype']=='float32'
    rows={row['input_id']:row for row in embeddings['rows']};lengths={};norms=[]
    for split in ('train','validation'):
        assert len(paragraphs[split])==48
        for row in paragraphs[split]:
            assert hashlib.sha256(row['source_text'].encode()).hexdigest()==row['source_sha256']
            observed=rows[row['id']];assert observed['status']=='embedded'
            tokens=observed['tokens'];count=len(tokens['input_ids'])
            assert count<=512 and tokens['attention_mask']==[1]*count
            assert len(tokens['token_type_ids'])==count
            vector=observed['vector'];assert len(vector)==384 and all(math.isfinite(v) for v in vector)
            norms.append(math.sqrt(sum(v*v for v in vector)))
            lengths.setdefault(split+':'+str(row['clause_count']),[]).append(count)
    assert len(rows)==96
    snapshot=Path('/home/barberb/.cache/huggingface/hub/models--thenlper--gte-small/snapshots')/producer['revision']
    assets=[]
    for entry in producer['asset_manifest']:
        observed=binding(snapshot/entry['name'])
        assert observed['sha256']==entry['sha256'] and observed['bytes']==entry['bytes']
        assets.append(observed)
    return dict(schema='original-order-panel-embedding-provenance-review/v1',complete=True,
        artifacts=[binding(PREVIOUS),binding(__file__),*[binding(p) for p in paths.values()]],
        model_id=producer['model_id'],revision=producer['revision'],local_snapshot=str(snapshot),local_assets=assets,
        rows=96,dimension=384,context=512,cached_vector_norm_range=[min(norms),max(norms)],
        actual_forward_token_ranges={k:{'rows':len(v),'min':min(v),'max':max(v)} for k,v in lengths.items()},
        interpretation='Cached source inputs are far below the fixed token ceiling; this does not establish semantic source authentication or order recoverability.',
        model_executed=False,encoder_executed=False,training_executed=False,downloads_performed=False,
        qualified=False,admitted=False,source_semantics_verified=False,native_executed=False,fresh_holdout=False)


if __name__=='__main__':
    receipt=run();(R/'original-embedding-review.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'complete':receipt['complete'],'asset_count':len(receipt['local_assets']),
        'token_ranges':receipt['actual_forward_token_ranges']}))
