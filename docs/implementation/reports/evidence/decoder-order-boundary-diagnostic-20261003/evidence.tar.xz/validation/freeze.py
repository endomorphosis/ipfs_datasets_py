"""Freeze reviewed diagnostics, exact prior sources and all input identities."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
O=P/'workspace/test-logs/decoder-shared-slot-source-20261003'
E=P/'docs/implementation/reports/evidence/decoder-shared-slot-source-20261003'
BASE=json.loads((R/'base.json').read_bytes())['base']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):(R/name).write_text(json.dumps(obj,indent=2)+'\n')
def gitbytes(rel):return subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)
if __name__=='__main__':
 assert not (R/'experiment-source').exists()
 runner='scripts/ops/autoencoder/benchmark_decoder_order_boundaries.py'
 run_test='tests/unit/logic/formalization/autoencoder/test_benchmark_decoder_order_boundaries.py'
 save('runner-ready.json',dict(ready=True,files={runner:sha(P/runner),run_test:sha(P/run_test)},focused_tests_passed=37,trained=False))
 additions={}
 for name in ('order-ready.json','boundary-ready.json','runner-ready.json'):
  ready=json.loads((R/name).read_bytes());assert ready['ready'] is True
  for rel,digest in ready['files'].items():assert sha(P/rel)==digest,rel
  additions.update(ready['files'])
 pins=json.loads((O/'frozen-extensions-r2.json').read_bytes())
 tests=json.loads((O/'validated-test-source-r2.json').read_bytes())
 helpers=json.loads((O/'test-helper-sources.json').read_bytes())
 for rel,digest in {**pins,**tests,**helpers}.items():
  assert sha(O/'experiment-source-r2'/rel)==digest,rel
  assert hashlib.sha256(gitbytes(rel)).hexdigest()==digest,rel
 for rel,digest in additions.items():
  (tests if rel.startswith('tests/') else pins)[rel]=digest
 for rel,digest in {**pins,**tests,**helpers}.items():
  source=P/rel if rel in additions else O/'experiment-source-r2'/rel
  target=R/'experiment-source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(source,target);assert sha(target)==digest
 save('frozen-extensions.json',pins);save('validated-test-source.json',tests);save('test-helper-sources.json',helpers)
 save('test-files.json',list(tests));save('code-files.json',list(additions)+['docs/autoencoders/decoder_length_distillation.md'])
 spec=importlib.util.spec_from_file_location('_freeze_diagnostic',R/'experiment-source'/runner)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 old=json.loads((O/'training-r2-manifest.json').read_bytes())
 manifest={k:old[k] for k in ('donor','paragraphs','embeddings','curriculum','curriculum_inputs','parent_preprocessing')}
 manifest.update(shared_public_manifest=str(E/'manifest.json'),shared_public_results=str(E/'results.json'),shared_summary=str(O/'training-r1/results/summary.json'),extensions=pins)
 for name in ('manifest.json','results.json'):assert (E/name).read_bytes()==gitbytes(str((E/name).relative_to(P)))
 manifest['state_catalog']=module.expected_catalog(manifest['shared_summary'])
 paths=[manifest[k] for k in ('donor','paragraphs','embeddings','curriculum','curriculum_inputs','parent_preprocessing','shared_public_manifest','shared_public_results','shared_summary')]
 for cat in manifest['state_catalog']:paths += [cat['state_path'],*cat['panels'].values()]
 manifest['inputs']={p:sha(p) for p in paths}
 public=json.loads((E/'manifest.json').read_bytes())
 for p in paths:
  if p not in (manifest['shared_public_manifest'],manifest['shared_public_results']):module.read_published(p,manifest,public)
 plan=dict(module.FIXED,input_sha256=manifest['inputs']);save('diagnostic-plan.json',plan)
 manifest['plan_sha256']=sha(R/'diagnostic-plan.json');save('diagnostic-manifest.json',manifest)
 harness=(O/'run_frozen_r2_tests.py').read_text()
 for a,b in [('frozen-extensions-r2.json','frozen-extensions.json'),('validated-test-source-r2.json','validated-test-source.json'),('experiment-source-r2','experiment-source'),('tests-frozen-r2.xml','tests-frozen.xml'),('test-import-provenance-r2.json','test-import-provenance.json'),('pytest-cache-r2','pytest-cache')]:harness=harness.replace(a,b)
 (R/'run_frozen_tests.py').write_text(harness)
 guardian=(O/'run_training_r2_reserved.py').read_text()
 for a,b in [("choices=('training',)","choices=('diagnostic',)"),('experiment-source-r2','experiment-source'),("args.phase+'-r2-manifest.json'","args.phase+'-manifest.json'"),('benchmark_shared_slot_source_reconstruction.py','benchmark_decoder_order_boundaries.py'),('run_training_r2_reserved.py','run_diagnostic_reserved.py'),('owned training child','owned diagnostic child'),('numerical development only','read-only diagnostics only')]:guardian=guardian.replace(a,b)
 (R/'run_diagnostic_reserved.py').write_text(guardian)
 print(json.dumps(dict(extensions=len(pins),test_files=len(tests),inputs=len(paths))))
