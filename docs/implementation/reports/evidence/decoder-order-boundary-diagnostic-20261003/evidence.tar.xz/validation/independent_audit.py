"""Independent arithmetic/provenance audit of saved diagnostics. No model imports.

The auditor never runs Torch, an encoder, a decoder or a prover. Floating-point
readouts are independently reconstructed with stdlib affine/tanh arithmetic;
actual recurrent logits are observed evidence, not independently rerun here.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import argparse
import ast
import hashlib
import json
import math
import statistics
import struct
import sys

sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
P=R.parents[2]
PREVIOUS=P/'workspace/test-logs/decoder-shared-slot-source-20261003'
AUTO='ipfs_datasets_py/logic/formalization/autoencoder/'
ARMS=['independent-1729','shared-1729','independent-2718','shared-2718']
FIELDS=('actor','action','modality','object')
RULE_FIELDS=set(FIELDS)|{'conditions','exceptions','temporal'}
findings=[];artifacts={};checks=0


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def digest(value):return hashlib.sha256(raw(value)).hexdigest()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    path=Path(path);data=path.read_bytes();artifacts[str(path)]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
    return json.loads(data)
def check(value,label,detail=None):
    global checks
    checks+=1
    if not value:findings.append(dict(label=label,detail=detail))
def close(a,b,tol=3e-5):
    if type(a) is dict and type(b) is dict:return a.keys()==b.keys() and all(close(a[k],b[k],tol) for k in a)
    if type(a) is list and type(b) is list:return len(a)==len(b) and all(close(x,y,tol) for x,y in zip(a,b))
    if type(a) in (int,float) and type(b) in (int,float):return math.isfinite(a) and math.isfinite(b) and math.isclose(a,b,rel_tol=tol,abs_tol=tol)
    return type(a) is type(b) and a==b

def f32(value):return struct.unpack('<f',struct.pack('<f',value))[0]
def flat(value):
    if type(value) is list:
        for row in value:yield from flat(row)
    else:yield value

def affine(w,b,x):return [f32(math.fsum(a*v for a,v in zip(row,x))+bias) for row,bias in zip(w,b)]
def canonical(state):
    result={}
    for name,value in state['model_state'].items():
        while name.startswith('body.'):name=name[5:]
        if name in result:raise ValueError('duplicate canonical parameter')
        result[name]=value
    return result

def project(vector,donor):
    p=donor['model_state'];t=donor['input_transform']
    x=[f32(f32(f32(v)-f32(m))/t['scale']) for v,m in zip(vector,t['mean'])]
    h=affine(p['projection_down.weight'],p['projection_down.bias'],x)
    y=affine(p['projection_up.weight'],p['projection_up.bias'],[f32(math.tanh(v)) for v in h])
    return [f32(a+b) for a,b in zip(x,y)]

def heads(p,x,scalar=True):
    x=[f32(f32(a-b)/p['source_scale']) for a,b in zip(x,p['source_mean'])]
    count=[f32(a+b) for a,b in zip(affine(p['count_head.weight'],p['count_head.bias'],x),p['count_prior_logits'])]
    if not scalar:return None,count
    if 'source_value_head.slot_embeddings' in p:
        x=affine(p['source_value_head.source_projection.weight'],p['source_value_head.source_projection.bias'],x);out=[]
        for slot in p['source_value_head.slot_embeddings']:
            hidden=[f32(math.tanh(f32(a+b))) for a,b in zip(x,slot)]
            out.extend(affine(p['source_value_head.field_readout.weight'],p['source_value_head.field_readout.bias'],hidden))
    else:out=affine(p['source_value_head.weight'],p['source_value_head.bias'],x)
    return out,count

def distance(a,b):
    an=math.sqrt(math.fsum(v*v for v in a));bn=math.sqrt(math.fsum(v*v for v in b));d=[x-y for x,y in zip(a,b)]
    co=max(-1.,min(1.,math.fsum((x/an)*(y/bn) for x,y in zip(a,b)))) if an and bn else None
    return dict(l2=math.sqrt(math.fsum(v*v for v in d)),max_abs_delta=max(map(abs,d)),mean_abs_delta=math.fsum(map(abs,d))/len(d),
        left_norm=an,right_norm=bn,cosine_distance=None if co is None else 1.-co,
        normalized_l2=None if co is None else math.sqrt(math.fsum((x/an-y/bn)**2 for x,y in zip(a,b))),
        zero_norm_present=not bool(an and bn),exact_values_equal=a==b)

def authority(value,label):
    for key in ('qualified','admitted','proof_authority','source_semantics_verified','checkpoint_promoted','formalized','roundtrip_ok','fresh_holdout','training_executed','weight_selection_performed','lake_executed'):
        if key in value:check(value[key] is False,label+'/no_authority/'+key)

def common(args):
    manifest=read(args.manifest);plan=read(args.plan);prior=read(PREVIOUS/'training-r2-manifest.json')
    check(sha(args.plan)==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'],'sealed_plan')
    for path,expected in manifest['inputs'].items():
        check(sha(path)==expected,'input/'+path);artifacts[path]=dict(sha256=expected,bytes=Path(path).stat().st_size)
    for rel,expected in manifest['extensions'].items():
        path=args.source/rel;check(sha(path)==expected,'source/'+rel);artifacts[str(path)]=dict(sha256=expected,bytes=path.stat().st_size)
        if rel in prior['extensions']:check(expected==prior['extensions'][rel],'unchanged_prior_source/'+rel)
    for key,value in dict(state_order=ARMS,representation_dimension=384,original_rows=48,requested_order_rows=120,unique_order_rows=108,
        permutation_pairs=60,duplicate_variant_aliases=12,repeat_batch_sizes=[8,4],total_encoder_row_observations=204,
        boundary_rows_per_model=96,fixed_encoder_context_tokens=512,fixed_decoder_output_limit=512,temperature=0,
        decoder_batch_size=8,no_downloads=True,generation_reference_count_access=False,generation_reference_prefix_access=False,
        trained_weights_unchanged=True,native_qualification=False,production_promotion_allowed=False,observation_thresholds_confer_success=False).items():
        check(plan.get(key)==value,'plan/'+key)
    for filename in ('benchmark_decoder_order_boundaries.py',):
        tree=ast.parse((args.source/'scripts/ops/autoencoder'/filename).read_text())
        calls=[ast.unparse(node.func) for node in ast.walk(tree) if isinstance(node,ast.Call)]
        check(not any(name.endswith(('.train','.backward','.step')) for name in calls),'read_only_runner/no_training_calls')
    corpus=read(manifest['paragraphs']);donor=read(manifest['donor']);cached=read(manifest['embeddings'])
    public=read(manifest['shared_public_manifest']);read(manifest['shared_public_results'])
    for item in manifest['state_catalog']:
        for path in (item['state_path'],*item['panels'].values()):
            member=public['original_artifact_archive_paths'].get(path)
            pin=public['members'].get(member) if member else public.get('referenced_artifacts',{}).get(path)
            check(pin is not None and pin['sha256']==manifest['inputs'][path] and pin['bytes']==Path(path).stat().st_size,'published_prior/'+path)
    return dict(manifest=manifest,plan=plan,corpus=corpus,donor=donor,cached={row['input_id']:row for row in cached['rows']})


def preparation_check(pre,ctx):
    check(pre['preparation_sha256']==digest({k:v for k,v in pre.items() if k!='preparation_sha256'}),'preparation/seal')
    check(len(pre['rows'])==108 and len(pre['requests'])==120 and len(pre['aliases'])==12 and len(pre['pairs'])==60,'preparation/inventory')
    train={row['id']:row for row in ctx['corpus']['train']};rows={row['id']:row for row in pre['rows']}
    check(pre['original_ids']==list(train) and list(rows)[:48]==list(train),'preparation/original_first')
    check(pre['validation_unchanged_sha256']==digest(ctx['corpus']['validation']),'preparation/validation_untouched')
    for request in pre['requests']:
        p=train[request['parent_id']];n=p['clause_count'];variant=request['variant']
        permutation={'original':list(range(n)),'reverse':list(reversed(range(n))),'rotate_left_one':list(range(1,n))+[0]}[variant]
        check(request['permutation']==permutation and request['inverse_permutation']==[permutation.index(i) for i in range(n)],'preparation/permutation/'+request['request_id'])
        r=rows[request['id']];parts=[p['source_text'][c['char_start']:c['char_end']] for c in p['components']]
        source='\n\n'.join(parts[i] for i in permutation);target={'rules':[p['target']['rules'][i] for i in permutation]}
        check(r['source_text']==source and r['target']==target and r['source_sha256']==hashlib.sha256(source.encode()).hexdigest(),'preparation/exact_components/'+request['request_id'])
        check(request['clause_bag_sha256']==digest(sorted((c['id'],c['source_sha256'],c['target_sha256']) for c in p['components'])),'preparation/bag/'+request['request_id'])
        if request['alias_of_request'] is not None:check(n==2 and variant=='rotate_left_one' and request['independent_observation'] is False,'preparation/alias/'+request['request_id'])
    check(not {r['source_sha256'] for r in rows.values()}&{r['source_sha256'] for r in ctx['corpus']['validation']},'preparation/no_validation_overlap')
    return rows


def vector_panel(panel,pre,vectors,repeats,label):
    byid={r['id']:r for r in pre['rows']};check(len(panel['pairs'])==60 and len(panel['different_parent_pairs'])==48,'vectors/panel_count/'+label)
    for pair in panel['pairs']:
        expected=distance(vectors[pair['parent_id']],vectors[pair['id']]);check(close(pair['distance'],expected,1e-10),'vectors/change/'+label+'/'+pair['id'])
    for pair in panel['different_parent_pairs']:
        group=[key for key in pre['original_ids'] if byid[key]['clause_count']==pair['clause_count']];i=group.index(pair['id'])
        other=next(group[(i+j)%len(group)] for j in range(1,len(group)) if byid[group[(i+j)%len(group)]]['order_diagnostic']['clause_bag_sha256']!=byid[pair['id']]['order_diagnostic']['clause_bag_sha256'])
        check(other==pair['other_id'] and close(pair['distance'],distance(vectors[pair['id']],vectors[other]),1e-10),'vectors/baseline/'+label+'/'+pair['id'])
    check(len(panel['repeat_pairs'])==(48 if repeats is not None else 0),'vectors/repeat_count/'+label)
    for pair in panel['repeat_pairs']:check(close(pair['distance'],distance(vectors[pair['id']],repeats[pair['id']]),1e-10),'vectors/repeat/'+label+'/'+pair['id'])
    for n,value in panel['by_length'].items():
        for key,origin in [('order_change','pairs'),('different_parent','different_parent_pairs'),('same_text_repeat','repeat_pairs')]:
            subset=[row['distance'] for row in panel[origin] if str(row['clause_count'])==n]
            check(value[key]['count']==len(subset) and value[key]['exactly_equal']==sum(row['exact_values_equal'] for row in subset),'vectors/aggregate_count/'+label+'/'+n+'/'+key)
            for field in ('l2','max_abs_delta','mean_abs_delta','cosine_distance','normalized_l2'):
                values=[row[field] for row in subset if row[field] is not None]
                expected=dict(count=len(values),minimum=min(values) if values else None,maximum=max(values) if values else None,mean=statistics.fmean(values) if values else None,median=statistics.median(values) if values else None)
                check(close(value[key][field],expected,1e-10),'vectors/aggregate/'+label+'/'+n+'/'+key+'/'+field)
        for label2,den in [('different_parent','different_parent'),('same_text_repeat','same_text_repeat')]:
            for field in ('l2','normalized_l2','cosine_distance'):
                a=value['order_change'][field]['mean'];b=value[den][field]['mean'];expected=a/b if a is not None and b not in (None,0) else None
                check(close(value['mean_distance_ratios'][label2][field],expected,1e-10),'vectors/ratio/'+label+'/'+n+'/'+label2+'/'+field)


def unique(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate JSON key')
        result[key]=value
    return result

def valid_rule(r):
    return type(r) is dict and set(r)==RULE_FIELDS and all(type(r[f]) is str and r[f] for f in FIELDS) and r['modality'] in ('O','P','F') and all(type(r[f]) is list and len(r[f])<=4 and all(type(v) is str and v for v in r[f]) and r[f]==sorted(set(r[f])) for f in ('conditions','exceptions','temporal'))

def decode(tokens,vocab,suffix=''):
    try:
        doc=json.loads(''.join(vocab[i] for i in tokens)+suffix,object_pairs_hook=unique)
        return doc['rules'] if type(doc) is dict and set(doc)=={'rules'} and type(doc['rules']) is list and len(doc['rules'])<=32 and all(valid_rule(r) for r in doc['rules']) else None
    except (ValueError,TypeError,IndexError):return None

def scored(reference,rules):
    expected=reference['target']['rules']
    facets={f:sum(i<len(rules) and rules[i].get(f)==r[f] for i,r in enumerate(expected)) for f in FIELDS}
    return dict(expected_rules=len(expected),generated_rules=len(rules),scalar_correct=facets,
        actor_action_pairs_correct=sum(i<len(rules) and all(rules[i].get(f)==r[f] for f in ('actor','action')) for i,r in enumerate(expected)))

def equivariance(parent,row,original,changed,permutation):
    out={}
    for label,fields in [(f,(f,)) for f in FIELDS]+[('actor_action',('actor','action'))]:
        c=dict(slots=0,informative_slots=0,comparable_slots=0,matches_fixed=0,matches_permuted=0,informative_comparable_slots=0,informative_matches_fixed=0,informative_matches_permuted=0)
        for i,j in enumerate(permutation):
            info=any(parent['target']['rules'][i][f]!=row['target']['rules'][i][f] for f in fields);c['slots']+=1;c['informative_slots']+=info
            def value(values,k):
                if k>=len(values):return None
                result=tuple(values[k].get(f) for f in fields)
                return result if all(type(v) is str for v in result) else None
            actual,fixed,moved=value(changed,i),value(original,i),value(original,j)
            if any(v is None for v in (actual,fixed,moved)):continue
            c['comparable_slots']+=1;c['matches_fixed']+=actual==fixed;c['matches_permuted']+=actual==moved
            if info:c['informative_comparable_slots']+=1;c['informative_matches_fixed']+=actual==fixed;c['informative_matches_permuted']+=actual==moved
        out[label]=c
    return out


def order_scores(observations,panel,rows,pre,vocab,label):
    predictions={r['id']:r for r in observations['predictions']};decoded={};head_values={};summary={}
    for r in panel['generated']['rows']:
        key=r['id'];rules=decode(predictions[key]['token_ids'],vocab);decoded[key]=rules or []
        check(r['syntax_valid']==(rules is not None) and r['eos_reached']==predictions[key]['eos_reached'],'order/generated_syntax/'+label+'/'+key)
        expected=scored(rows[key],rules or []);expected.update(ordered_rules_correct=sum(i<len(rules or []) and rules[i]==rule for i,rule in enumerate(rows[key]['target']['rules'])),ordered_document_exact=(rules or [])==rows[key]['target']['rules'])
        check(all(r[k]==v for k,v in expected.items()),'order/generated_scores/'+label+'/'+key)
        check(r['exact_target_with_eos']==(rules is not None and predictions[key]['eos_reached'] and rules==rows[key]['target']['rules']),'order/generated_exact/'+label+'/'+key)
    for r in panel['scalars']['rows']:
        key=r['id'];scores=observations['scalar_logits'][key];ids=[[max(range(len(f)),key=f.__getitem__) for f in slot] for slot in scores]
        vals=[]
        for slot in ids:
            d={}
            for field,token in zip(FIELDS,slot):
                try:v=json.loads(vocab[token]) if token>=3 else None
                except ValueError:v=None
                d[field]=v if type(v) is str else None
            vals.append(d)
        head_values[key]=vals
        check(r['predicted_token_ids']==ids and all(r[k]==v for k,v in scored(rows[key],vals[:rows[key]['clause_count']]).items()),'order/raw_head_scores/'+label+'/'+key)
    for mode,values in [('generated',decoded),('scalars',head_values)]:
        for pair in panel[mode]['pairs']:
            source=next(x for x in pre['pairs'] if x['id']==pair['id']);key=pair['id'];parent=pair['parent_id'];perm=source['permutation'];n=source['clause_count']
            check(pair['equivariance']==equivariance(rows[parent],rows[key],values[parent],values[key],perm),'order/changed_slot_equivariance/'+label+'/'+mode+'/'+key)
            if mode=='scalars':
                actual=list(flat(observations['scalar_logits'][key][:n]));old=observations['scalar_logits'][parent]
                check(close(pair['full_logit_fixed_slot_distance'],distance(actual,list(flat(old[:n]))),1e-10) and close(pair['full_logit_permuted_slot_distance'],distance(actual,list(flat([old[i] for i in perm]))),1e-10),'order/full_logit_alignment/'+label+'/'+key)
        summary[mode]={}
        for count in (1,2,4,8):
            rs=[r for r in panel[mode]['rows'] if r['clause_count']==count]
            ps=[r for r in panel[mode]['pairs'] if r['clause_count']==count]
            summary[mode][str(count)]=dict(rows=len(rs),scalar_correct=sum(sum(r['scalar_correct'].values()) for r in rs),actor_action_pairs_correct=sum(r['actor_action_pairs_correct'] for r in rs),expected_rules=sum(r['expected_rules'] for r in rs),
                changed_actor_action={k:sum(r['equivariance']['actor_action'][k] for r in ps) for k in ('informative_slots','informative_comparable_slots','informative_matches_fixed','informative_matches_permuted')})
            if mode=='generated':summary[mode][str(count)].update(exact=sum(r['exact_target_with_eos'] for r in rs),syntax=sum(r['syntax_valid'] for r in rs),eos=sum(r['eos_reached'] for r in rs))
    return summary


def logsumexp(x):
    m=max(x);return m+math.log(math.fsum(math.exp(v-m) for v in x))

def boundaries(panel,archived,references,cached,donor,state,vocab,label):
    predictions=panel['predictions'];keys=('id','token_ids','generation_status','eos_reached')
    check(predictions==[{k:r[k] for k in keys} for r in archived['predictions']],'boundary/exact_saved_replay/'+label)
    check([r['id'] for r in predictions]==[r['id'] for r in references] and len(panel['rows'])==48,'boundary/inventory/'+label)
    check(panel['reference_documents_passed_to_model'] is False and panel['target_tokens_passed_to_model'] is False and panel['reference_count_passed_to_model'] is False and panel['optimizer_steps']==0 and panel['logits_addition_replay_exact'] is True and panel['caller_tensors_modes_gradients_rng_preserved'] is True,'boundary/causal_observation_contract/'+label)
    authority(panel,label);p=canonical(state);counts=Counter();byref=defaultdict(Counter);partition=defaultdict(Counter)
    for row,pred,ref in zip(panel['rows'],predictions,references):
        key=row['id'];x=project(cached[key]['vector'],donor);_,expectedcounts=heads(p,x,False)
        check(row['input_sha256']==digest(cached[key]['vector']) and close(row['count_logits'],expectedcounts),'boundary/source_count/'+label+'/'+key)
        check(row['frozen_prior_logits']==p['count_prior_logits'],'boundary/frozen_prior/'+label+'/'+key)
        logits=row['count_logits'];mx=max(logits);exp=[math.exp(v-mx) for v in logits];probs=[v/sum(exp) for v in exp]
        check(close(probs,row['count_probabilities'],2e-6) and row['predicted_count']==1+max(range(32),key=logits.__getitem__),'boundary/count_softmax/'+label+'/'+key)
        tokens=pred['token_ids'];expected_events=[]
        consumed=len(tokens) if pred['generation_status']!='output_limit' else len(tokens)-1
        for j in range(consumed):
            if vocab[tokens[j]]!='}':continue
            rules=decode(tokens[:j+1],vocab,']}')
            if rules:expected_events.append((j+2,len(rules)))
        check([(e['consumed_prefix_length'],e['completed_rules']) for e in row['boundaries']]==expected_events,'boundary/independent_prefix_inventory/'+label+'/'+key)
        counts['rows']+=1;counts['count_correct']+=row['predicted_count']==ref['clause_count'];counts['no_boundary_rows']+=not row['boundaries'];counts['invalid_prefix_rows']+=row['first_invalid_prefix_position'] is not None
        counts['eos_rows']+=pred['eos_reached'];counts['output_limit_rows']+=pred['generation_status']=='output_limit';counts['duplicate_generated_rules']+=row['syntactic_duplicate_rule_count'] or 0
        byref[str(ref['clause_count'])]['rows']+=1;byref[str(ref['clause_count'])]['count_correct']+=row['predicted_count']==ref['clause_count']
        for e in row['boundaries']:
            n=e['consumed_prefix_length'];k=e['completed_rules'];rawlog=e['recurrent_logits'];final=e['final_logits'];stop=e['stop_token_id'];cont=e['continue_token_id'];prior=row['frozen_prior_logits']
            check(e['consumed_prefix_sha256']==digest([1]+tokens[:n-1]) and e['consumed_token_id']==tokens[n-2] and vocab[stop]==']' and vocab[cont]==',','boundary/prefix_identity/'+label+'/'+key+'/'+str(n))
            delta=logsumexp([v-prior[k-1] for v in prior[k:]])-logsumexp([v-logits[k-1] for v in logits[k:]]) if k<32 else 0.
            check(close(delta,e['count_correction']) and e['count_correction_active']==(k<32),'boundary/prior_centered_odds/'+label+'/'+key+'/'+str(n))
            check(e['scalar_guidance_overlap'] is None and e['scalar_guidance_active'] is False and len(rawlog)==len(final)==len(vocab),'boundary/full_vocabulary_no_scalar_overlap/'+label+'/'+key+'/'+str(n))
            check(all(final[i]==rawlog[i] for i in range(len(vocab)) if i!=stop) and close(final[stop],f32(rawlog[stop]+e['count_correction']),1e-7),'boundary/only_close_adjusted/'+label+'/'+key+'/'+str(n))
            a=max(range(len(vocab)),key=rawlog.__getitem__);b=max(range(len(vocab)),key=final.__getitem__)
            following=tokens[n-1] if n-1<len(tokens) else (2 if pred['eos_reached'] else e['actual_next_token_id'])
            check(e['actual_next_token_id']==e['final_argmax_token_id']==b==following and e['recurrent_argmax_token_id']==a and e['local_argmax_changed']==(a!=b),'boundary/actual_greedy_argmax/'+label+'/'+key+'/'+str(n))
            for prefix,values in [('recurrent',rawlog),('final',final)]:
                check(close(e[prefix+'_stop_minus_continue'],values[stop]-values[cont],1e-10) and close(e[prefix+'_stop_minus_best_other'],values[stop]-max(v for i,v in enumerate(values) if i!=stop),1e-10),'boundary/margins/'+label+'/'+key+'/'+str(n)+'/'+prefix)
            relation='before_reference_count' if k<ref['clause_count'] else 'at_reference_count' if k==ref['clause_count'] else 'after_reference_count'
            group=partition[relation];group['events']+=1;group['count_top1_correct']+=row['predicted_count']==ref['clause_count'];group['guided_close']+=b==stop;group['raw_close']+=a==stop;group['local_argmax_changed']+=a!=b;group['positive_correction']+=delta>0;group['guided_continue']+=b==cont;group['guided_other']+=b not in (stop,cont)
            counts['events']+=1
    check(counts['events']==panel['boundary_event_count'],'boundary/event_count/'+label)
    return dict(overall=dict(counts),by_reference_count={k:dict(v) for k,v in byref.items()},observed_boundaries={k:dict(v) for k,v in partition.items()},reference_count_access='posthoc auditor scoring only; no alternative rollouts')


def results(args,ctx):
    root=args.results;summary=read(root/'summary.json');pre=read(root/'order-preparation.json');rows=preparation_check(pre,ctx)
    check(summary['complete'] is True and [r['arm'] for r in summary['runs']]==ARMS and summary['encoder_row_observations']==204,'results/completeness');authority(summary,'summary')
    encoded=read(root/'embedding-observations.json');observed=encoded['observations'];vectors={r['input_id']:r['vector'] for r in observed['main']};ranges={}
    check([r['input_id'] for r in observed['main']]==list(rows),'embedding/main_order')
    for label,items in observed.items():
        expected=list(rows) if label=='main' else pre['original_ids'];check([r['input_id'] for r in items]==expected,'embedding/row_inventory/'+label)
        lengths=[]
        for row in items:
            tokens=row['tokens'];n=len(tokens['input_ids']);lengths.append(n)
            check(row['status']=='embedded' and 0<n<=512 and tokens['attention_mask']==[1]*n and len(tokens['token_type_ids'])==n and len(row['vector'])==384 and all(math.isfinite(v) for v in row['vector']),'embedding/finite_captured_forward/'+label+'/'+row['input_id'])
            check(abs(math.sqrt(sum(v*v for v in row['vector']))-1.)<2e-6,'embedding/unit_norm/'+label+'/'+row['input_id'])
            if label!='main':check(tokens==next(r['tokens'] for r in observed['main'] if r['input_id']==row['input_id']),'embedding/repeat_tokens/'+label+'/'+row['input_id'])
        ranges[label]=dict(rows=len(items),minimum=min(lengths),maximum=max(lengths))
        check(encoded['vectors_sha256'][label]==digest(items),'embedding/capture_digest/'+label)
    check(encoded['observations_count']==204 and encoded['producer']['downloads_performed'] is False,'embedding/no_downloads_and_count')
    for entry in encoded['producer']['asset_manifest']:
        path=Path(encoded['producer']['snapshot_path'])/entry['name'];check(sha(path)==entry['sha256'] and path.stat().st_size==entry['bytes'],'embedding/local_asset/'+entry['name'])
    em=read(root/'embedding-pairs.json')
    for label in em:
        repeat={k:r['vector'] for k,r in ctx['cached'].items() if k in pre['original_ids']} if label=='cached_originals' else {r['input_id']:r['vector'] for r in observed[label]}
        vector_panel(em[label],pre,vectors,repeat,'embedding/'+label)
    projections={key:project(value,ctx['donor']) for key,value in vectors.items()};result={}
    for catalog in ctx['manifest']['state_catalog']:
        arm=catalog['arm'];state=read(catalog['state_path']);authority(state,arm+'/state');p=canonical(state)
        observation=read(root/arm/'order-observations.json');pairs=read(root/arm/'order-pairs.json')
        check(observation['model_tensor_sha256']==state['tensor_sha256'] and observation['rows']==108,'order/model_and_count/'+arm)
        maxerror=0.
        for key in rows:
            check(close(observation['projected_vectors'][key],projections[key]),'order/frozen_projection/'+arm+'/'+key)
            scalar,count=heads(p,observation['projected_vectors'][key]);actual=list(flat(observation['scalar_logits'][key]));maxerror=max(maxerror,max(abs(a-b) for a,b in zip(actual,scalar)))
            check(close(scalar,actual) and close(count,observation['count_logits'][key]),'order/independent_head_arithmetic/'+arm+'/'+key)
        vector_panel(pairs['projection'],pre,observation['projected_vectors'],None,arm+'/projection')
        scores=order_scores(observation,pairs,rows,pre,ctx['donor']['codec']['target_vocabulary'],arm)
        replay={}
        for split in ('train','validation'):
            panel=read(root/arm/('boundary-'+split+'.json'));archived=read(catalog['panels'][split])
            replay[split]=boundaries(panel,archived,ctx['corpus'][split],ctx['cached'],ctx['donor'],state,ctx['donor']['codec']['target_vocabulary'],arm+'/'+split)
        result[arm]=dict(order=scores,boundaries=replay,maximum_scalar_head_absolute_error=maxerror)
    return dict(token_ranges=ranges,embedding_distances={k:v['by_length'] for k,v in em.items()},models=result,
        interpretation_limits=['Different order distances above repeat noise are observed responsiveness, not proven recoverable order.',
        'Scalar slot potentials are not actual visited-generation sites; joint binding and full fidelity are separate.',
        'Boundary raw/guided argmax comparisons are local to actual visited prefixes, not counterfactual full rollouts.',
        'Permutation probes use training components only; exposed validation is replayed, not a fresh holdout.',
        'Actual recurrent logits are hook observations authenticated by exact archived greedy replay; the auditor does not rerun recurrence.'])


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--manifest',type=Path,required=True);parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--results',type=Path);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();ctx=common(args);analysis=results(args,ctx) if args.results else None
    if args.results:check('torch' not in sys.modules and 'transformers' not in sys.modules,'auditor/no_model_imports')
    artifacts[str(Path(__file__).resolve())]=dict(sha256=sha(__file__),bytes=Path(__file__).stat().st_size)
    receipt=dict(schema='decoder-order-boundary-independent-audit/v1',created_at_utc=datetime.now(timezone.utc).isoformat(),phase='results' if args.results else 'readiness',passed=not findings,
        checks=checks,finding_count=len(findings),findings=findings,artifacts=artifacts,analysis=analysis,
        manifest_sha256=sha(args.manifest),plan_sha256=sha(args.plan),models_executed=False,encoder_executed=False,
        training_executed=False,qualified=False,admitted=False,lake_executed=False,fresh_holdout=False)
    args.output.write_text(json.dumps(receipt,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(passed=receipt['passed'],checks=checks,finding_count=len(findings),output=str(args.output))))
    if findings:sys.exit(1)

if __name__=='__main__':main()
