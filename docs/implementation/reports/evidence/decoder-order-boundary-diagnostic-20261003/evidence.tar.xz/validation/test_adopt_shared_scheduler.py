"""Synthetic scheduler adoption tests; every state file is private to pytest."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import pytest

RUN=Path(__file__).resolve().parent
SOURCE=RUN.parent/'ui-modal-coverage-20261002/validation-source-r2'
helper_spec=importlib.util.spec_from_file_location('_adopt_shared_scheduler_test',RUN/'adopt_shared_scheduler.py')
helper=importlib.util.module_from_spec(helper_spec);helper_spec.loader.exec_module(helper)
name='ipfs_datasets_py.optimizers.logic_theorem_optimizer._adoption_scheduler_test'
spec=importlib.util.spec_from_file_location(name,SOURCE/helper.SCHEDULER_RELATIVE)
scheduler=importlib.util.module_from_spec(spec);sys.modules[name]=scheduler;spec.loader.exec_module(scheduler)
assert hashlib.sha256(Path(scheduler.__file__).read_bytes()).hexdigest()==helper.SCHEDULER_SHA256


def setup(tmp_path,active=False):
    path=tmp_path/'scheduler.json'
    config=scheduler.ResourceSchedulerConfig(total_cpu_slots=4,total_memory_mb=9830,
        total_child_process_slots=4,reserved_memory_mb=0,reserved_gpu_memory_mb=0,
        lane_reservations={'validation':{'cpu_slots':1,'memory_mb':0}},state_path=path,
        proof_safety_enabled=True,proof_memory_headroom_mb=2458,
        proof_memory_stall_percent=2.,proof_cpu_stall_percent=50.,proof_io_stall_percent=10.,
        proof_backoff_seconds=2.,max_waiting_requests=256,auto_renew_leases=False)
    state=dict(schema_version=scheduler.RESOURCE_SCHEDULER_SCHEMA_VERSION,config=config.persisted_dict(),
        leases={'foreign':{'opaque_foreign_lease':'retained byte for byte'}} if active else {},
        waiters={'foreign-waiter':{'opaque_foreign_waiter':'retained byte for byte'}} if active else {},
        metrics={'counter':42},next_sequence=19,proof_backoff={'foreign':123.})
    path.write_bytes(helper.raw(state))
    return path,config,state


@pytest.mark.parametrize('active',[False,True])
def test_exact_config_adoption_preserves_entire_idle_or_active_state(tmp_path,active):
    path,_,state=setup(tmp_path,active)
    value,_=helper.read_existing(path)
    config=helper.validated_config(scheduler,value,path)
    before=path.read_bytes()
    client=helper.exact_existing_client(scheduler,config)
    assert path.read_bytes()==before
    assert json.loads(path.read_bytes())==state
    assert client.config.proof_safety_enabled and client.config.proof_memory_headroom_mb==2458
    assert client.config.persisted_dict()==state['config']
    assert client.config.reservations()['validation'].cpu_slots==1


@pytest.mark.parametrize('active',[False,True])
def test_configuration_race_refuses_idle_and_active_reset(tmp_path,active):
    path,config,state=setup(tmp_path,active)
    adopted=helper.validated_config(scheduler,state,path)
    state['config']['total_cpu_slots']=5
    path.write_bytes(helper.raw(state));before=path.read_bytes()
    with pytest.raises(scheduler.ResourceConfigurationError,match='fail-closed adoption refuses reset'):
        helper.exact_existing_client(scheduler,adopted)
    assert path.read_bytes()==before


@pytest.mark.parametrize('missing',['deleted','empty'])
def test_disappearing_state_never_initializes_new_scheduler(tmp_path,missing):
    path,config,state=setup(tmp_path)
    if missing=='deleted':path.unlink()
    else:path.write_bytes(b'')
    with pytest.raises(scheduler.ResourceConfigurationError,match='never initializes or resets'):
        helper.exact_existing_client(scheduler,config)
    assert not path.exists() if missing=='deleted' else path.read_bytes()==b''


@pytest.mark.parametrize('key,value',[
    ('total_cpu_slots',True),('total_memory_mb','9830'),('total_child_process_slots',0),
    ('reserved_memory_mb',-1),('reserved_gpu_memory_mb',False),('proof_memory_headroom_mb',-1),
    ('total_gpu_memory_mb',0),('total_unified_memory_mb',False),('max_waiting_requests',False),
    ('proof_safety_enabled',1),('require_known_gpu_for_gpu_work','true'),
    ('proof_memory_stall_percent',float('nan')),('proof_cpu_stall_percent',101.),
    ('proof_io_stall_percent','10'),('proof_backoff_seconds',-1.),
    ('max_memory_percent',True),('max_swap_percent',float('inf')),('max_gpu_memory_percent','90'),
    ('lane_reservations',{'validation':{'cpu_slots':True,'memory_mb':0}}),
    ('lane_reservations',{'validation':{'cpu_slots':1,'memory_mb':0,'callback':'ignored'}}),
    ('lane_reservations',{' validation':{'cpu_slots':1,'memory_mb':0}}),
])
def test_all_persisted_field_types_and_constraints_are_checked(tmp_path,key,value):
    path,_,state=setup(tmp_path);state['config'][key]=value
    with pytest.raises((ValueError,scheduler.ResourceConfigurationError)):
        helper.validated_config(scheduler,state,path)


@pytest.mark.parametrize('change',['missing','callable','state_path','auto_renew'])
def test_unknown_or_missing_configuration_never_reaches_constructor(tmp_path,change):
    path,_,state=setup(tmp_path)
    if change=='missing':del state['config']['proof_safety_enabled']
    elif change=='callable':state['config']['proof_resource_sampler']='module.function'
    elif change=='state_path':state['config']['state_path']='/tmp/something-else'
    else:state['config']['auto_renew_leases']=False
    with pytest.raises(ValueError,match='complete persisted scheduler configuration'):
        helper.validated_config(scheduler,state,path)


def test_exact_numeric_types_not_just_python_equality_under_lock(tmp_path):
    path,config,state=setup(tmp_path)
    state['config']['total_cpu_slots']=4.0
    path.write_bytes(helper.raw(state));before=path.read_bytes()
    with pytest.raises(scheduler.ResourceConfigurationError,match='fail-closed'):
        helper.exact_existing_client(scheduler,config)
    assert path.read_bytes()==before


def test_duplicate_json_keys_are_rejected(tmp_path):
    path=tmp_path/'duplicate.json';path.write_text('{"config":{},"config":{}}')
    with pytest.raises(ValueError,match='duplicate scheduler JSON key'):helper.read_existing(path)


def test_live_owner_adapter_uses_explicit_client_only_in_guardian_module(tmp_path,monkeypatch):
    path,_,state=setup(tmp_path,True)
    owner=SimpleNamespace(__file__=str(SOURCE/helper.OWNER_RELATIVE),
        __package__='ipfs_datasets_py.optimizers.logic_theorem_optimizer',
        get_global_resource_scheduler=lambda:'original-default-getter')
    monkeypatch.setattr(helper.importlib,'import_module',lambda name:scheduler)
    monkeypatch.setattr(scheduler,'default_scheduler_state_path',lambda:path)
    monkeypatch.setattr(scheduler,'default_resource_scheduler_config',lambda:scheduler.ResourceSchedulerConfig(
        total_cpu_slots=20,total_memory_mb=20000,lane_reservations={},state_path=path))
    before=path.read_bytes();cache=dict(scheduler._GLOBAL_SCHEDULERS)
    receipt=helper.adopt_for_owner(owner,source_root=SOURCE,receipt_path=tmp_path/'receipt.json')
    assert path.read_bytes()==before and scheduler._GLOBAL_SCHEDULERS==cache
    assert owner.get_global_resource_scheduler().config.persisted_dict()==state['config']
    assert receipt['complete'] and receipt['shared_config']==state['config']
    assert receipt['differing_default_fields']['total_cpu_slots']=={'default':20,'adopted':4}
    assert receipt['observed_before_claims_sha256']==receipt['observed_after_claims_sha256']
    assert receipt['leases_released_by_adoption']==receipt['leases_acquired_by_adoption']==0
    assert not receipt['model_or_training_started']
