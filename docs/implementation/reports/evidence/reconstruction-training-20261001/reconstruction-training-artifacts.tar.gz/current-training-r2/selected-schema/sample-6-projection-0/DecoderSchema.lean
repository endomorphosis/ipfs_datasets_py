namespace DecoderSchema

inductive AbsentValue where | null

inductive EmptyElement where

structure ExactFloat64 where
  bits : UInt64

inductive LegalModality where | obligation | permission | prohibition

structure Record0 where
  field0 : String
  field1 : String
  field2 : List String
  field3 : List String
  field4 : LegalModality
  field5 : String
  field6 : List String

structure Record1 where
  field0 : List (Record0)

def decodedInstance : Record1 :=
  ({ field0 := [({ field0 := (String.ofList [Char.ofNat 115, Char.ofNat 117, Char.ofNat 98, Char.ofNat 109, Char.ofNat 105, Char.ofNat 116]), field1 := (String.ofList [Char.ofNat 98, Char.ofNat 111, Char.ofNat 97, Char.ofNat 114, Char.ofNat 100]), field2 := [], field3 := [(String.ofList [Char.ofNat 101, Char.ofNat 109, Char.ofNat 101, Char.ofNat 114, Char.ofNat 103, Char.ofNat 101, Char.ofNat 110, Char.ofNat 99, Char.ofNat 121])], field4 := LegalModality.obligation, field5 := (String.ofList [Char.ofNat 98, Char.ofNat 97, Char.ofNat 99, Char.ofNat 107, Char.ofNat 117, Char.ofNat 112, Char.ofNat 32, Char.ofNat 114, Char.ofNat 101, Char.ofNat 112, Char.ofNat 111, Char.ofNat 114, Char.ofNat 116]), field6 := [(String.ofList [Char.ofNat 119, Char.ofNat 105, Char.ofNat 116, Char.ofNat 104, Char.ofNat 105, Char.ofNat 110, Char.ofNat 32, Char.ofNat 49, Char.ofNat 48, Char.ofNat 32, Char.ofNat 100, Char.ofNat 97, Char.ofNat 121, Char.ofNat 115])] } : Record0)] } : Record1)

end DecoderSchema
