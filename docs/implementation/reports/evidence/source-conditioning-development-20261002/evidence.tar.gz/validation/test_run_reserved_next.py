"""Subprocess-only controls; never call the benchmark or claim resource release."""
import importlib.util
import os
from pathlib import Path
import signal
import subprocess
import sys

import pytest

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('reserved_next_under_test', ROOT/'run_reserved_next.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)


@pytest.fixture(scope='module')
def resources():
    return driver.resource_owner()


def stop_for_test(child):
    try: os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError: pass
    child.wait(timeout=3)


def test_cleanup_surviving_descendant_after_direct_leader_exit(resources):
    code = ('import subprocess,sys; '
            'p=subprocess.Popen([sys.executable,"-c","import time; time.sleep(60)"],'
            'stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); '
            'print(p.pid,flush=True); sys.stdin.readline()')
    child = subprocess.Popen([sys.executable, '-c', code], stdin=subprocess.PIPE,
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, start_new_session=True)
    try:
        identity = driver.capture_owned_child(child, resources)
        descendant = int(child.stdout.readline())
        child.stdin.write('exit\n'); child.stdin.flush()
        assert child.wait(timeout=3) == 0
        assert resources._group_usage(identity)['live_processes'] >= 1
        receipt = driver.cleanup_owned_group(child, identity, resources,
            grace_seconds=.5, kill_seconds=2)
        assert receipt['leader_reaped'] and receipt['leader_returncode'] == 0
        assert receipt['initial_live_processes'] >= 1 and receipt['live_group_processes'] == 0
        observation = resources._process(descendant)
        assert observation is None or observation['state'] == 'Z'
    finally:
        stop_for_test(child)
        child.stdin.close(); child.stdout.close()


def test_group_exit_between_inspection_and_signal_is_benign(resources, monkeypatch):
    child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    original = os.killpg
    try:
        identity = driver.capture_owned_child(child, resources)
        def raced(group, requested_signal):
            original(group, signal.SIGKILL)
            child.wait(timeout=3)
            raise ProcessLookupError('group exited immediately before signal delivery')
        with monkeypatch.context() as patch:
            patch.setattr(driver.os, 'killpg', raced)
            receipt = driver.cleanup_owned_group(child, identity, resources,
                grace_seconds=.5, kill_seconds=2)
        assert receipt['signals'][0]['status'] == 'group_already_exited'
        assert receipt['leader_reaped'] and receipt['live_group_processes'] == 0
    finally:
        stop_for_test(child)


def test_reused_leader_identity_refuses_signal(resources, monkeypatch):
    child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    lookup = resources._process
    try:
        identity = driver.capture_owned_child(child, resources)
        def reused(pid):
            result = lookup(pid)
            return {**result, 'birth': str(int(result['birth']) + 1)} if pid == child.pid else result
        with monkeypatch.context() as patch:
            patch.setattr(resources, '_process', reused)
            patch.setattr(driver.os, 'killpg', lambda *args: pytest.fail('must not signal a reused PID'))
            with pytest.raises(resources.DaemonResourceError, match='reused'):
                driver.cleanup_owned_group(child, identity, resources, grace_seconds=.5, kill_seconds=2)
        assert child.poll() is None
    finally:
        stop_for_test(child)


def test_cleanup_already_reaped_group_needs_no_signal(resources, monkeypatch):
    child = subprocess.Popen([sys.executable, '-c', 'import sys; sys.stdin.readline()'],
        stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        text=True, start_new_session=True)
    try:
        identity = driver.capture_owned_child(child, resources)
        child.stdin.write('exit\n'); child.stdin.flush(); child.wait(timeout=3)
        with monkeypatch.context() as patch:
            patch.setattr(driver.os, 'killpg', lambda *args: pytest.fail('dead group needs no signal'))
            receipt = driver.cleanup_owned_group(child, identity, resources, grace_seconds=.5, kill_seconds=2)
        assert receipt['signals'] == [] and receipt['live_group_processes'] == 0
        assert receipt['leader_reaped']
    finally:
        stop_for_test(child)
        child.stdin.close()
