import copy,hashlib,importlib.util,json,os,sys
from collections import Counter
from pathlib import Path
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'validation-source'));sys.dont_write_bytecode=True
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_daemon_resources as new
oldpath=R/'source/ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(oldpath)=='15fcce3aba498e502b3c98122e33a748028d6e042795ac101f65a2c5ec3b0475'
spec=importlib.util.spec_from_file_location('ipfs_datasets_py.optimizers.logic_theorem_optimizer._resource_policy_90gb_baseline',oldpath)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
roots=[P/'workspace/test-logs',P/'workspace/todo-queues',P/'docs/implementation/reports/evidence',Path('/tmp/pytest-of-barberb')]
ledger=roots[0]/'federal-corpus-audits/owned-daemon-resource-control/disk-reservations.json'
args=dict(roots=roots,storage_bytes=1,memory_mb=1,ledger_lock_timeout_seconds=60)
a=old.DaemonResourceReservation(ledger,**args);b=new.DaemonResourceReservation(ledger,**args)
receipt=R/'storage-migration.json';backup=R/'storage-ledger-before-140gb.json'
assert not receipt.exists() and not backup.exists()
def durable(path,data):
 with path.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
with a._locked():
 before=a._read();rawbefore=ledger.read_bytes()
 assert sha(ledger)=='48b13ee2d5f78e02085f610e97dc226eff72d110e2eb35952556188f00c2e77b'
 assert before['limit_bytes']==90_000_000_000 and new.MAX_STORAGE_BYTES==140_000_000_000
 assert a.root_identities==b.root_identities
 assert not any(v['status'] in ('reserved','active') for v in before['reservations'].values())
 after=copy.deepcopy(before);after['limit_bytes']=new.MAX_STORAGE_BYTES
 account=b._account(after,additional=750_000_000)
 durable(backup,rawbefore)
 b._write(after)
 actual=b._read();rawafter=ledger.read_bytes()
 assert actual==after and actual['reservations']==before['reservations']
 assert rawbefore.replace(b'{"limit_bytes":90000000000,',b'{"limit_bytes":140000000000,',1)==rawafter
 try:a._read()
 except old.DaemonResourceError as e:assert str(e)=='disk ledger storage scope differs'
 else:raise AssertionError('old owner accepted incompatible cap')
 result={'schema':'campaign-storage-explicit-migration/v1','ledger':str(ledger),'before_sha256':hashlib.sha256(rawbefore).hexdigest(),'after_sha256':hashlib.sha256(rawafter).hexdigest(),'backup':{'path':str(backup),'sha256':sha(backup)},'old_source_sha256':sha(oldpath),'new_source_sha256':sha(new.__file__),'only_changed_field':'limit_bytes','before_limit_bytes':90_000_000_000,'after_limit_bytes':140_000_000_000,'before_entry_bound':old.MAX_INVENTORY_ENTRIES,'after_entry_bound':new.MAX_INVENTORY_ENTRIES,'all_reservations_preserved':True,'all_root_identities_preserved':True,'status_counts':dict(Counter(v['status'] for v in after['reservations'].values())),'full_nonreleased_claims_bytes':sum(v['storage_bytes'] for v in after['reservations'].values() if v['status']!='released'),'admission_performed':False,'released_reservations':0,'per_worker_storage_limit_unchanged_bytes':50_000_000_000,'live_accounting_with_prospective_750mb':account,'old_owner_refuses_new_cap':True}
 durable(receipt,(json.dumps(result,sort_keys=True,indent=2)+'\n').encode())
 print(json.dumps(result),flush=True)
