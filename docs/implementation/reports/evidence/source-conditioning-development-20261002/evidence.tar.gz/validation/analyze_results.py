#!/usr/bin/env python3
"""Read an existing development summary; never train or open split inputs.

Replays v2/v3 selection ordering, including failures hidden by the first
reported rejection. Output is analysis of existing receipts, not qualification.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def critical(generated):
    # These two authored schemas use /kind and /document/kind as constant tags.
    return {path: row for path, row in generated["per_field"].items()
            if path not in {"/kind", "/document/kind"}}


def rank(metrics):
    generated = metrics["generated"]
    return generated["exact_count"], generated["field_accuracy"], -metrics["objective"]


def candidate(metrics):
    return {"epoch": metrics.get("epoch", 0),
            "exact_count": metrics["generated"]["exact_count"],
            "critical_correct": sum(row["correct"] for row in critical(metrics["generated"]).values()),
            "embedding_mse": metrics["embedding_mse"],
            "token_cross_entropy": metrics["token_cross_entropy"],
            "selection_reason": metrics.get("selection_reason", "initialization")}


def analyze(summary, summary_path, raw):
    require(summary["schema"] == "source-conditioning-development-results/v1", "unexpected summary schema")
    require(summary["test_data_read"] is False and summary["fresh_holdout"] is False,
            "analysis is scoped to exposed development evidence")
    fits, comparisons = summary["fits"], summary["comparisons"]
    require(len(fits) == len(comparisons) == 8, "expected all eight sealed comparisons")
    by_comparison = {row["identity"]: row for row in comparisons}
    require(len(by_comparison) == 8 and len({f["identity"] for f in fits}) == 8, "duplicate identities")
    analyzed, totals, logged = [], Counter(), Counter()
    for fit in fits:
        training = fit["training"]
        initial = training["before_validation"]
        incumbent = initial
        overlap, reasons, fields = Counter(), Counter(), Counter()
        exact_regressions = native_regressions = selected_count = 0
        history = training["history"]
        for observation in history:
            left, right = observation["generated"], incumbent["generated"]
            require(set(left["per_field"]) == set(right["per_field"]), "field coverage changed")
            regressions = [path for path, row in left["per_field"].items()
                           if row["total"] != right["per_field"][path]["total"]
                           or row["correct"] < right["per_field"][path]["correct"]]
            exact = left["exact_count"] < right["exact_count"]
            native = left["native_valid_count"] < right["native_valid_count"]
            field_failure = bool(regressions) or exact or native
            embedding_failure = (fit["config"]["embedding_nonregression"]
                                 and observation["embedding_mse"] > initial["embedding_mse"] + 1e-12)
            gate = ("both" if field_failure and embedding_failure else "field_only" if field_failure
                    else "embedding_only" if embedding_failure else "neither")
            overlap[gate] += 1
            fields.update(regressions)
            exact_regressions += int(exact)
            native_regressions += int(native)
            expected = ("generated_field_regression" if field_failure else
                        "embedding_regression_against_initialization" if embedding_failure else
                        "generated_fidelity_then_loss" if rank(observation) > rank(incumbent) else
                        "no_selection_improvement")
            require(observation["selection_reason"] == expected, "selection-reason replay differs")
            require(observation["selected"] == (expected == "generated_fidelity_then_loss"),
                    "selection-state replay differs")
            reasons[expected] += 1
            if observation["selected"]:
                incumbent = observation
                selected_count += 1
        require(incumbent["generated"] == training["selected_validation"]["generated"]
                == fit["evaluations"]["tuning"], "saved selected metrics differ")
        require(incumbent.get("epoch", 0) == training["selected_epoch"], "selected epoch differs")
        for key in ("objective", "embedding_mse", "token_cross_entropy", "weighted_token_cross_entropy"):
            require(incumbent[key] == training["selected_validation"][key], "selected numeric metric differs")
        train_count = fit["evaluations"]["train"]["count"]
        examples_rate = training["examples_seen"] / training["optimizer_seconds"]
        tokens_rate = training["training_tokens"] / training["optimizer_seconds"]
        require(math.isclose(examples_rate, fit["training_examples_per_optimizer_second"], rel_tol=1e-12),
                "example throughput differs")
        require(math.isclose(tokens_rate, fit["training_tokens_per_optimizer_second"], rel_tol=1e-12),
                "token throughput differs")
        selected = training["selected_validation"]
        generated = selected["generated"]
        comparison = by_comparison[fit["identity"]]
        require(comparison["tuning_fidelity"] == generated, "comparison fidelity differs")
        best = max(history, key=lambda row: (row["generated"]["exact_count"],
                                             row["generated"]["scalar_correct"]))
        analyzed.append({"identity": fit["identity"], "domain": fit["domain"], "seed": fit["seed"],
            "mode": fit["mode"], "checkpoint_sha256": fit["checkpoint"]["sha256"],
            "selected_epoch": training["selected_epoch"], "completed_epochs": history[-1]["epoch"],
            "stopped_reason": training["stopped_reason"], "tuning_count": generated["count"],
            "tuning_exact_count": generated["exact_count"], "tuning_native_valid_count": generated["native_valid_count"],
            "critical_fields": critical(generated),
            "critical_correct": sum(v["correct"] for v in critical(generated).values()),
            "critical_total": sum(v["total"] for v in critical(generated).values()),
            "training_exact_count": fit["evaluations"]["train"]["exact_count"],
            "initial_embedding_mse": initial["embedding_mse"], "selected_embedding_mse": selected["embedding_mse"],
            "selected_token_cross_entropy": selected["token_cross_entropy"],
            "overlapping_gate_failures": dict(overlap), "logged_selection_reasons": dict(reasons),
            "regressing_scalar_paths": dict(fields), "exact_regression_evaluations": exact_regressions,
            "native_regression_evaluations": native_regressions, "evaluation_count": len(history),
            "accepted_evaluation_count": selected_count,
            "continuous_candidate_progress_evaluations": sum(h["candidate_learning_progress"] for h in history),
            "best_observed_candidate_diagnostic_only": candidate(best),
            "final_candidate_diagnostic_only": candidate(history[-1]),
            "learning_rate_reductions": [{"epoch": h["epoch"], "next_learning_rate": h["next_learning_rate"]}
                                         for h in history if h["next_learning_rate"] < h["learning_rate"]],
            "timing": {"optimizer_seconds": training["optimizer_seconds"],
                "generated_validation_seconds": training["validation_seconds"],
                "full_training_call_seconds": fit["full_training_call_seconds"],
                "optimizer_steps": training["optimizer_steps"], "unique_training_spans": train_count,
                "example_presentations": training["examples_seen"], "predicted_training_tokens": training["training_tokens"],
                "repeated_examples_per_optimizer_second": examples_rate,
                "training_tokens_per_optimizer_second": tokens_rate,
                "unique_spans_per_full_training_call_second": train_count / fit["full_training_call_seconds"],
                "full_training_call_seconds_per_unique_span": fit["full_training_call_seconds"] / train_count,
                "public_inference": comparison["inference"]},
            "ablations": {mode: {"exact_count": result["exact_count"], "count": result["count"],
                         "native_valid_count": result["native_valid_count"], "critical_fields": critical(result)}
                          for mode, result in comparison["ablations"].items()},
            "source_audit_dispositions": comparison["source_audit_dispositions"]})
        totals.update(overlap)
        logged.update(reasons)
    pairs, aggregate = [], []
    for domain in ("intent_ir", "ui_ux_ir"):
        for seed in (3517, 3518):
            a, b = [next(f for f in fits if (f["domain"], f["seed"], f["mode"]) == (domain, seed, mode))
                    for mode in ("initial_only", "every_step")]
            require(a["lineage"]["inherited_initial_state_sha256"] == b["lineage"]["inherited_initial_state_sha256"],
                    "paired initialization differs")
            require(a["training"]["before_validation"] == b["training"]["before_validation"],
                    "paired initial measured behavior differs")
            ia, ib = [by_comparison[f["identity"]]["inference"]["seconds_per_span"] for f in (a, b)]
            pairs.append({"domain": domain, "seed": seed,
                "inherited_initial_state_sha256": a["lineage"]["inherited_initial_state_sha256"],
                "identical_before_validation_metrics": True,
                "candidate_added_parameter_count": b["runtime"]["decoder_spec"]["additional_parameter_count"],
                "additional_parameter_initialization": b["lineage"]["additional_parameter_initialization"],
                "optimizer_time_candidate_over_control": b["training"]["optimizer_seconds"] / a["training"]["optimizer_seconds"],
                "full_call_time_candidate_over_control": b["full_training_call_seconds"] / a["full_training_call_seconds"],
                "inference_time_candidate_over_control": ib / ia})
        for mode in ("initial_only", "every_step"):
            subset = [f for f in analyzed if f["domain"] == domain and f["mode"] == mode]
            aggregate.append({"domain": domain, "mode": mode,
                **{key: sum(row[key] for row in subset) for key in
                   ("tuning_exact_count", "tuning_count", "critical_correct", "critical_total")},
                "optimizer_seconds": sum(row["timing"]["optimizer_seconds"] for row in subset),
                "full_training_call_seconds": sum(row["timing"]["full_training_call_seconds"] for row in subset)})
    return {"schema": "source-conditioning-development-diagnostic-analysis/v1",
        "summary": {"path": str(summary_path), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)},
        "analysis_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "read_only_replay_of_exposed_train_tuning_receipts; no split files read",
        "qualified": False, "admitted": False, "formalized": False, "fresh_holdout": False,
        "causal_improvement_claim": False, "global_convergence_proven": False, "training_performed_by_analysis": False,
        "test_inputs_or_outputs_read": False, "checkpoint_promotion_performed": False,
        "fits": analyzed, "pairs": pairs, "domain_mode_aggregates": aggregate,
        "gate_totals": {**dict(totals), "evaluations": sum(totals.values()),
            "embedding_failure_including_overlap": totals["embedding_only"] + totals["both"],
            "field_failure_including_overlap": totals["field_only"] + totals["both"]},
        "logged_selection_reason_totals": dict(logged),
        "run": {key: summary[key] for key in ("elapsed_seconds", "max_rss_kib", "rss_scope",
            "native_attempt_count", "native_prepared_count", "native_receipt", "strict_training_gate_count",
            "all_inputs_unchanged", "parent_unchanged", "checkpoints_sealed")},
        "interpretation_limits": [
            "No consistent selected-fidelity improvement supports promoting every_step conditioning.",
            "Gate failures overlap; logged field rejection can hide simultaneous embedding regression.",
            "Both seeds inherit the same initial parameters per domain; they vary minibatch order.",
            "Repeated example presentations are not throughput for fresh corpus spans.",
            "Three warm inference timings include native candidate validation, exclude embeddings, source audit, Lake and bridges.",
            "Zeroing and shuffled-input ablations establish path dependence, not independent source fidelity.",
            "No prepared native jobs means no actual Lake build result from this development run.",
            "Exposed authored tuning semantic groups overlap training; this is not fresh grouped generalization evidence."],
        "future_recipe_proposal_not_executed": {
            "scope": "future development experiment before any fresh heldout configuration freeze",
            "design": "2 domains x 2 minibatch-order seeds x 2 conditioning modes x 2 projection-update policies = 16 fits",
            "projection_update_policies": ["joint", "frozen_parent_residual"],
            "intervention": "Freeze only inherited projection_down/up in frozen policy; train condition, GRU, token embedding and output heads.",
            "rationale": "Frozen residual projection preserves initialized embedding reconstruction while testing decoder learnability; existing MSE gate still runs.",
            "unchanged": ["parent", "local verified embeddings", "64-token cap", "temperature 0", "scalar weight 8",
                "numerical budgets and scheduler", "every per-field and embedding gate", "source agreement", "all requested families", "actual Lake requirement"],
            "no_guarantee": "Does not imply that role/path nonregression gates will pass or that global convergence is achieved."}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parent
    parser.add_argument("--summary", type=Path, default=root / "development-r1/results/summary.json")
    parser.add_argument("--output", type=Path, default=root / "diagnostic-analysis.json")
    args = parser.parse_args()
    require(args.summary.stat().st_size <= 16 * 1024 * 1024, "summary exceeds analysis bound")
    raw = args.summary.read_bytes()
    result = analyze(json.loads(raw), args.summary.resolve(), raw)
    encoded = (json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    with args.output.open("xb") as stream:
        stream.write(encoded)
    print(json.dumps({"output": str(args.output.resolve()), "sha256": hashlib.sha256(encoded).hexdigest(),
                      "bytes": len(encoded), "gate_totals": result["gate_totals"]}, sort_keys=True))


if __name__ == "__main__":
    main()
