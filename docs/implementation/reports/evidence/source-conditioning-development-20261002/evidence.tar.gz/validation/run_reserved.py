"""Own the existing campaign ledger while running one frozen development child."""
import json, os, signal, subprocess, sys, time
from pathlib import Path

PACKAGE=Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN=Path(__file__).resolve().parent
SOURCE=RUN/'validation-source'
ATTEMPT=RUN/'development-r1'
assert not ATTEMPT.exists()
sys.path.insert(0,str(SOURCE))
sys.dont_write_bytecode=True
from ipfs_datasets_py.optimizers.logic_theorem_optimizer.autoencoder_daemon_resources import DaemonResourceReservation
roots=[PACKAGE/'workspace/test-logs',PACKAGE/'workspace/todo-queues',PACKAGE/'docs/implementation/reports/evidence',Path('/tmp/pytest-of-barberb')]
ledger=roots[0]/'federal-corpus-audits/owned-daemon-resource-control/disk-reservations.json'
owner=DaemonResourceReservation(ledger, roots=roots, storage_bytes=250_000_000, memory_mb=4096,
    cpu_slots=1, child_process_slots=5, timeout_seconds=60, ledger_lock_timeout_seconds=60)
command=[sys.executable,str(SOURCE/'scripts/ops/autoencoder/benchmark_source_conditioning_development.py'),
    '--development-data',str(roots[0]/'intent-ui-coverage-20261002/comparison-r1'),
    '--parent',str(roots[0]/'holdout-throughput-release-20261001/current-holdout-r1/1729-original32-head.json'),
    '--output',str(ATTEMPT/'results')]

def save(name,data):
    p=ATTEMPT/name
    with p.open('w') as f:
        json.dump(data,f,sort_keys=True,indent=2); f.write('\n');f.flush();os.fsync(f.fileno())

def sync_tree():
    for p in ATTEMPT.rglob('*'):
        if p.is_file() and not p.is_symlink():
            with p.open('rb') as f: os.fsync(f.fileno())
    for p in sorted([ATTEMPT]+[p for p in ATTEMPT.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):
        fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY)
        try: os.fsync(fd)
        finally: os.close(fd)

child=None
started=time.monotonic()
try:
    with owner:
        ATTEMPT.mkdir()
        save('command.json',{'command':command,'cwd':str(SOURCE),'scheduler_scope':'outer owner plus conservative additional inner numerical/native leases','outer_cpu_slots':1,'outer_memory_mb':4096,'outer_child_process_slots':5,'storage_bytes':250_000_000})
        with (ATTEMPT/'child.log').open('w') as log:
            env=dict(os.environ,PYTHONPATH=str(SOURCE),PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI='0',CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
            child=subprocess.Popen(command,cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            usage=owner.check_usage(ATTEMPT,child.pid)
            save('resources-start.json',owner.to_dict())
            observations=[usage]
            while child.poll() is None:
                time.sleep(5)
                if child.poll() is None:
                    observations.append(owner.check_usage(ATTEMPT,child.pid))
                    save('resource-observations.json',observations)
            code=child.wait()
            log.flush();os.fsync(log.fileno())
        save('child-exit.json',{'returncode':code,'elapsed_seconds':time.monotonic()-started,'child_reaped':True})
        if code: raise RuntimeError(f'development child failed: {code}')
        assert (ATTEMPT/'results/summary.json').is_file()
        sync_tree()
        released=owner.finalize(ATTEMPT,artifacts_durable=True)
        save('resources-final.json',released)
        print(json.dumps({'status':'complete','returncode':code,'elapsed_seconds':time.monotonic()-started,'resources':released}),flush=True)
except BaseException as exc:
    if child is not None and child.poll() is None:
        os.killpg(child.pid,signal.SIGINT)
        try: child.wait(timeout=60)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait()
    if ATTEMPT.exists():
        save('failure.json',{'error':repr(exc),'elapsed_seconds':time.monotonic()-started,'resources':owner.to_dict(),'child_reaped':child is None or child.poll() is not None})
        sync_tree()
    raise
