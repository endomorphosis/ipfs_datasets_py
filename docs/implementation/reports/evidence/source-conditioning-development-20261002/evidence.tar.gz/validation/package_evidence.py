"""Seal the exposed-data comparison, including unsuccessful candidates."""
import hashlib,io,json,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
S=R/'validation-source';A=R/'development-r1';D=A/'results'
O=P/'docs/implementation/reports/evidence/source-conditioning-development-20261002'
DOC='docs/autoencoders/source_conditioned_decoder_v3.md'
read=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n')
summary=read(D/'summary.json'); release=read(A/'resources-final.json')
assert release['status']=='released' and release['record']['artifacts_durable_asserted'] is True
assert read(A/'child-exit.json')['returncode']==0
assert len(summary['fits'])==len(summary['comparisons'])==8
assert all(summary[k] is False for k in ('admitted','qualified','formalized','fresh_holdout','test_data_read','production_promotion_performed','downloads_performed','global_convergence_proven'))
assert summary['development_training_executed'] and summary['checkpoints_sealed'] and summary['all_inputs_unchanged']
assert summary['native_attempt_count']==24
pins=read(R/'candidate-sha256.json')
for rel,h in pins.items(): assert sha(S/rel)==sha(P/rel)==h,rel
manifest=read(R/'source-manifest.json')
for row in manifest['files']:assert sha(S/row['path'])==row['sha256'],row['path']
xml=ET.parse(R/'validation-tests.xml').getroot()
totals={k:sum(int(s.attrib.get(k,0)) for s in xml.iter('testsuite')) for k in ('tests','failures','errors','skipped')}
assert totals==dict(tests=266,failures=0,errors=0,skipped=0),totals
cleanup_xml=ET.parse(R/'guardian-cleanup-tests.xml').getroot()
cleanup_totals={k:sum(int(s.attrib.get(k,0)) for s in cleanup_xml.iter('testsuite')) for k in ('tests','failures','errors','skipped')}
assert cleanup_totals==dict(tests=4,failures=0,errors=0,skipped=0),cleanup_totals
diagnostic=read(R/'diagnostic-analysis.json')
assert not O.exists();O.mkdir(parents=True)
files={};metadata={};producers={};weights={}
def add(p,name):
 p=Path(p);assert p.is_file() and not p.is_symlink(),p
 assert name not in files and not Path(name).is_absolute() and '..' not in Path(name).parts
 files[name]=p;metadata[name]={'sha256':sha(p),'bytes':p.stat().st_size}
def producer(p):
 p=Path(p);rel=p.relative_to(S).as_posix();h=sha(p)
 assert producers.get(rel,h)==h
 producers[rel]=h
 if 'source/'+rel not in files:add(p,'source/'+rel)
for v in read(D/'loaded-modules.json').values():
 assert sha(v['path'])==v['sha256'];producer(v['path'])
for rel in read(R/'candidate-files.json'):producer(S/rel)
for f in ('test_domain_384_autoencoder.py','test_domain_384_autoencoder_v2.py','test_domain_384_fidelity.py'):
 producer(S/'tests/unit/optimizers/logic_theorem_optimizer'/f)
producer(S/'tests/unit/logic/formalization/autoencoder/test_intent_ui_candidate_pipeline_v2.py')
for fit in summary['fits']:
 desc=fit['checkpoint'];p=Path(desc['path']);assert sha(p)==desc['sha256'] and p.stat().st_size==desc['bytes']
 weights[fit['identity']]=desc
for p in sorted(A.rglob('*')):
 if not p.is_file() or p.is_symlink() or {'.lake','.git','__pycache__','.pytest_cache'}.intersection(p.parts):continue
 if p.name=='checkpoint.json':continue
 add(p,'validation/'+p.relative_to(R).as_posix())
for name in ('base.json','candidate-files.json','candidate-sha256.json','source-manifest.json','provenance-audit.json','prospective-census-2m.json','storage-migration.json','storage-migration.log','migrate_storage.py','run_reserved.py','validation-tests.xml','validation-tests.log','v3-unit-r1.xml','v3-unit-r1.log'):
 add(R/name,'validation/'+name)
for name in ('run_reserved_next.py','test_run_reserved_next.py','guardian-cleanup-tests.log','guardian-cleanup-tests.xml','guardian-next-review.json','analyze_results.py','diagnostic-analysis.json'):
 if (R/name).is_file():add(R/name,'validation/'+name)
for domain in ('intent_ir','ui_ux_ir'):
 for split in ('train','tuning'):
  for suffix in ('.json','-embedding-evidence.json'):
   p=P/'workspace/test-logs/intent-ui-coverage-20261002/comparison-r1'/domain/(split+suffix)
   add(p,'inputs/'+domain+'/'+p.name)
add(P/DOC,'source/'+DOC)
add(P/'docs/autoencoders/source_conditioning_fidelity_ablation.md','source/docs/autoencoders/source_conditioning_fidelity_ablation.md')
add(Path(__file__),'validation/package_evidence.py')
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as out:
 for name,p in sorted(files.items()):
  b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==metadata[name]['sha256']
  ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=0o644;ti.mtime=0;out.addfile(ti,io.BytesIO(b))
rows=[]
for fit,comp in zip(summary['fits'],summary['comparisons']):
 assert fit['identity']==comp['identity'];m=fit['training'];before=m['before_validation'];selected=m['selected_validation']
 rows.append({'identity':fit['identity'],'domain':fit['domain'],'seed':fit['seed'],'mode':fit['mode'],'train_fidelity':fit['evaluations']['train'],'tuning_fidelity':fit['evaluations']['tuning'],'selected_epoch':m['selected_epoch'],'optimizer_steps':m['optimizer_steps'],'stop':m['stopped_reason'],'before_embedding_mse':before['embedding_mse'],'selected_embedding_mse':selected['embedding_mse'],'before_weighted_ce':before['weighted_token_cross_entropy'],'selected_weighted_ce':selected['weighted_token_cross_entropy'],'training_call_seconds':fit['full_training_call_seconds'],'fit_wall_seconds_per_unique_training_span':fit['fit_wall_seconds_per_unique_training_span'],'optimizer_examples_per_second':fit['training_examples_per_optimizer_second'],'optimizer_tokens_per_second':fit['training_tokens_per_optimizer_second'],'inference':comp['inference'],'ablations':comp['ablations'],'source_audit_dispositions':comp['source_audit_dispositions']})
result={'schema':'source-conditioning-development-release/v1','validated_base':read(R/'base.json')['base'],'candidate_sha256':pins,'tests':totals,'separate_guardian_cleanup_tests':cleanup_totals,'diagnostic_analysis':diagnostic,'development':rows,'native_attempt_count':summary['native_attempt_count'],'native_prepared_count':summary['native_prepared_count'],'native_receipt':summary['native_receipt'],'strict_training_gates':read(D/'native-strict-gates.json'),'elapsed_seconds':summary['elapsed_seconds'],'max_rss_kib':summary['max_rss_kib'],'resource_release':release,'storage_migration':read(R/'storage-migration.json'),'weights_local_only':weights,'artifact_count':len(files),'archive':{'sha256':sha(archive),'bytes':archive.stat().st_size},'all_frozen_producer_files_unchanged':True,'all_original_inputs_unchanged':True,'scope':'exposed_authored_train_tuning_compositions; all24 tuning semantic groups overlap training per domain','temperature':0,'max_target_tokens':64,'training_workers':1,'torch_threads':1,'bridge_on_evaluation_ran':False,'qualified':False,'admitted':False,'formalized':False,'test_data_read':False,'fresh_holdout':False,'downloads_performed':False,'production_promotion_performed':False,'global_convergence_proven':False}
save(O/'results.json',result)
save(O/'manifest.json',{'schema':'source-conditioning-development-evidence/v1','tested_base_revision':read(R/'base.json')['base'],'archive':result['archive'],'members':metadata,'validated_producer_source_sha256':producers,'weights_local_only':weights})
owned=read(R/'candidate-files.json')+[DOC,'docs/autoencoders/source_conditioning_fidelity_ablation.md']+[p.relative_to(P).as_posix() for p in sorted(O.iterdir())]
save(R/'owned-files.json',owned)
print(json.dumps({'owned_files':len(owned),'artifacts':len(files),'archive':result['archive'],'tests':totals}))
