import cProfile,hashlib,json,pstats,time,os
from pathlib import Path
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_family_training_v2 as api
from ipfs_datasets_py.logic.formalization.autoencoder.family_training import prepare_family_training_targets
from ipfs_datasets_py.logic.intent_ir.formalize.rich_grammar import parse_instruction
root=Path(__file__).resolve().parent
texts=['The '+actor+' '+modal+' '+action+' the '+obj+'.' for actor in ('agent','reviewer','officer') for modal,action in (('must','save'),('may','view')) for obj in ('amber record','cobalt report','ivory file','silver message')]
train=[prepare_family_training_targets('intent_ir',document=parse_instruction(t),source_text=t,requested_families=['deontic','dcec','tdfol','frame_logic']) for t in texts]
valid=[prepare_family_training_targets('intent_ir',document=parse_instruction(t),source_text=t,requested_families=['deontic','dcec','tdfol','frame_logic']) for t in ['The auditor must save the copper record.','The examiner may view the golden report.']]
(root/'inputs.json').write_text(json.dumps({'training':train,'validation':valid},sort_keys=True))
options=dict(epochs=32,latent_width=8,learning_rate=.001,minibatch_size=6,denoising=.05,ridge=.001,patience=32,seed=1729,max_seconds=120)
api.train_family_projection_autoencoder_v2(train,valid,output_dir=root/'warmup',**{**options,'epochs':1})
p=cProfile.Profile();started=time.monotonic();p.enable();result=api.train_family_projection_autoencoder_v2(train,valid,output_dir=root/'profiled',**options);p.disable();elapsed=time.monotonic()-started
p.dump_stats(str(root/'profile.pstats'))
with (root/'profile.txt').open('w') as stream: pstats.Stats(p,stream=stream).sort_stats('cumulative').print_stats(60)
(root/'profile-report.json').write_text(json.dumps({'wall_seconds':elapsed,'report':result['report'],'options':options,'environment':{k:os.environ.get(k) for k in ('CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS')}},indent=2))
print(json.dumps({'wall_seconds':elapsed,'steps':result['report']['optimizer_steps'],'inputs_sha256':hashlib.sha256((root/'inputs.json').read_bytes()).hexdigest()}))
