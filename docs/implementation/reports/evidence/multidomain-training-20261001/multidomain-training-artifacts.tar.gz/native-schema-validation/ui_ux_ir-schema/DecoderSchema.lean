namespace DecoderSchema

inductive AbsentValue where | null

inductive EmptyElement where

structure ExactFloat64 where
  bits : UInt64

inductive LegalModality where | obligation | permission | prohibition

structure Record0 where
  field0 : List (String)
  field1 : String
  field2 : List (String)

structure Record1 where
  field0 : List (Record0)

structure Record2 where
  field0 : Record1
  field1 : String
  field2 : String
  field3 : String
  field4 : String
  field5 : List EmptyElement
  field6 : String
  field7 : String

def decodedInstance : Record2 :=
  ({ field0 := ({ field0 := [({ field0 := [(String.ofList [Char.ofNat 99, Char.ofNat 111, Char.ofNat 109, Char.ofNat 112, Char.ofNat 111, Char.ofNat 110, Char.ofNat 101, Char.ofNat 110, Char.ofNat 116, Char.ofNat 58, Char.ofNat 100, Char.ofNat 101, Char.ofNat 108, Char.ofNat 101, Char.ofNat 116, Char.ofNat 101]), (String.ofList [Char.ofNat 97, Char.ofNat 114, Char.ofNat 105, Char.ofNat 97, Char.ofNat 58, Char.ofNat 98, Char.ofNat 117, Char.ofNat 116, Char.ofNat 116, Char.ofNat 111, Char.ofNat 110])], field1 := (String.ofList [Char.ofNat 117, Char.ofNat 105, Char.ofNat 95, Char.ofNat 99, Char.ofNat 111, Char.ofNat 109, Char.ofNat 112, Char.ofNat 111, Char.ofNat 110, Char.ofNat 101, Char.ofNat 110, Char.ofNat 116]), field2 := [(String.ofList [Char.ofNat 115, Char.ofNat 111, Char.ofNat 117, Char.ofNat 114, Char.ofNat 99, Char.ofNat 101, Char.ofNat 58, Char.ofNat 100, Char.ofNat 111, Char.ofNat 109, Char.ofNat 45, Char.ofNat 97, Char.ofNat 114, Char.ofNat 105, Char.ofNat 97, Char.ofNat 58, Char.ofNat 100, Char.ofNat 111, Char.ofNat 99, Char.ofNat 117, Char.ofNat 109, Char.ofNat 101, Char.ofNat 110, Char.ofNat 116, Char.ofNat 58, Char.ofNat 48])] } : Record0)] } : Record1), field1 := (String.ofList [Char.ofNat 102, Char.ofNat 114, Char.ofNat 97, Char.ofNat 109, Char.ofNat 101, Char.ofNat 95, Char.ofNat 108, Char.ofNat 111, Char.ofNat 103, Char.ofNat 105, Char.ofNat 99]), field2 := (String.ofList [Char.ofNat 117, Char.ofNat 105, Char.ofNat 45, Char.ofNat 117, Char.ofNat 120, Char.ofNat 45, Char.ofNat 105, Char.ofNat 114, Char.ofNat 47, Char.ofNat 102, Char.ofNat 108, Char.ofNat 111, Char.ofNat 103, Char.ofNat 105, Char.ofNat 99, Char.ofNat 64, Char.ofNat 49]), field3 := (String.ofList [Char.ofNat 117, Char.ofNat 105, Char.ofNat 45, Char.ofNat 102, Char.ofNat 108, Char.ofNat 111, Char.ofNat 103, Char.ofNat 105, Char.ofNat 99, Char.ofNat 45, Char.ofNat 99, Char.ofNat 111, Char.ofNat 109, Char.ofNat 112, Char.ofNat 105, Char.ofNat 108, Char.ofNat 97, Char.ofNat 116, Char.ofNat 105, Char.ofNat 111, Char.ofNat 110, Char.ofNat 47, Char.ofNat 118, Char.ofNat 49]), field4 := (String.ofList [Char.ofNat 117, Char.ofNat 105, Char.ofNat 95, Char.ofNat 117, Char.ofNat 120, Char.ofNat 95, Char.ofNat 105, Char.ofNat 114, Char.ofNat 58, Char.ofNat 102, Char.ofNat 108, Char.ofNat 111, Char.ofNat 103, Char.ofNat 105, Char.ofNat 99]), field5 := ([] : List EmptyElement), field6 := (String.ofList [Char.ofNat 100, Char.ofNat 111, Char.ofNat 109, Char.ofNat 97, Char.ofNat 105, Char.ofNat 110, Char.ofNat 95, Char.ofNat 115, Char.ofNat 116, Char.ofNat 114, Char.ofNat 117, Char.ofNat 99, Char.ofNat 116, Char.ofNat 117, Char.ofNat 114, Char.ofNat 101, Char.ofNat 100, Char.ofNat 95, Char.ofNat 102, Char.ofNat 111, Char.ofNat 114, Char.ofNat 109, Char.ofNat 117, Char.ofNat 108, Char.ofNat 97]), field7 := (String.ofList [Char.ofNat 115, Char.ofNat 116, Char.ofNat 114, Char.ofNat 117, Char.ofNat 99, Char.ofNat 116, Char.ofNat 117, Char.ofNat 114, Char.ofNat 97, Char.ofNat 108, Char.ofNat 95, Char.ofNat 99, Char.ofNat 111, Char.ofNat 109, Char.ofNat 112, Char.ofNat 111, Char.ofNat 110, Char.ofNat 101, Char.ofNat 110, Char.ofNat 116, Char.ofNat 115]) } : Record2)

end DecoderSchema
