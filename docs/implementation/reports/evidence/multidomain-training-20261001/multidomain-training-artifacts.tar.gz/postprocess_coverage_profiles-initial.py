"""Audit existing four-domain receipts without executing any model or target producer."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from ipfs_datasets_py.logic.formalization.autoencoder import family_coverage_audit as coverage
from ipfs_datasets_py.logic.families import profiles, namespaces, canonical_catalog
from ipfs_datasets_py.logic.legal_ir import typed_adapter

FALSE = {"admitted": False, "qualified": False, "formalized": False,
         "roundtrip_ok": False, "source_semantics_verified": False,
         "independent_legal_gold": False, "training_executed": False,
         "inference_executed": False, "heldout_regenerated": False,
         "lake_executed": False, "checkpoint_loaded": False}


def _raw(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _file(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
    return {"sha256": h.hexdigest(), "bytes": path.stat().st_size}


def run(campaign, output):
    campaign, output = campaign.resolve(), output.resolve()
    if output.exists():
        raise ValueError("fresh postprocessing output required")
    sources = {str(Path(module.__file__).resolve()): _file(Path(module.__file__)) for module in
               (coverage, coverage.native, coverage.native_v2, profiles, namespaces, canonical_catalog, typed_adapter)}
    sources[str(Path(__file__).resolve())] = _file(Path(__file__))
    inputs = {}

    def read(path):
        path = path.resolve()
        value = path.read_bytes()
        observed = {"sha256": _sha(value), "bytes": len(value)}
        if str(path) in inputs and inputs[str(path)] != observed:
            raise ValueError("input changed during postprocessing")
        inputs[str(path)] = observed
        return json.loads(value)

    report = read(campaign / "report.json")
    fits = read(campaign / "fits.json")
    freeze = read(campaign / "freeze.json")
    if inputs[str(campaign / "freeze.json")]["sha256"] != report["freeze_sha256"]:
        raise ValueError("campaign report names a different freeze")
    summaries, audits = {}, {}
    for domain in coverage.native.DOMAINS:
        development = read(campaign / domain / "development.json")
        heldout = read(campaign / domain / "heldout-targets.json")
        inferred = read(campaign / domain / "prepared-1729-heldout.json")
        selected = [row for row in fits if (row["domain_id"], row["backend"], row["seed"]) == (domain, "prepared", 1729)]
        if len(selected) != 1:
            raise ValueError("one prepared seed-1729 receipt per domain required")
        fit = selected[0]
        checkpoint = Path(fit["descriptor"]["path"])
        identity = _file(checkpoint)
        inputs[str(checkpoint)] = identity
        if (identity["sha256"] != fit["descriptor"]["sha256"]
                or inferred["checkpoint_sha256"] != identity["sha256"]
                or freeze["files"].get(str(checkpoint.relative_to(campaign))) != identity["sha256"]):
            raise ValueError("stored inference differs from frozen checkpoint receipt")
        required = {row["family_id"] for row in coverage.native_v2.family_training_catalog_v2(domain)["family_inventory"]
                    if row["projection_adapter_available"]}
        if domain == "legal_ir":
            required.update(("first_order", "deontic", "temporal", "tdfol", "event_calculus", "dcec", "frame_logic", "propositional"))
        required_profiles = [{"family_id": "tdfol", "profile": "temporal_first_order"}] if domain == "legal_ir" else [
            {"family_id": "transition_system", "profile": "tla_plus"}]
        audited = coverage.audit_family_training_coverage(domain, training_reports=development["train"],
            tuning_reports=development["validation"], heldout_reports=heldout,
            required_families=sorted(required), required_profiles=required_profiles,
            numerical_training_report=fit["report"], numerical_heldout_report=inferred)
        audits[domain] = audited
        families = {row["family_id"]: row for row in audited["family_inventory"]}
        exact_profiles = {(row["family_id"], row["profile"]): row for row in audited["profile_inventory"]}

        def ready(item):
            return item is not None and all(row["ready_source_count"] > 0 and row["numerically_covered_source_count"]
                for row in item["splits"].values()) and item.get("reported_as_numerically_trained", True) is not False

        named_requirements = [
            {"requested_logic": "first_order_logic", "canonical_family": "first_order", "profile": None,
             "structural_coverage_satisfied": bool(ready(families["first_order"])), "semantic_floor_verified": False},
            {"requested_logic": "deontic_first_order_logic", "canonical_family": None, "profile": None,
             "related_canonical_families": ["deontic", "first_order"],
             "status": "no_exact_DFOL_projection_composition_in_native_domain_adapters",
             "reason": "two family names do not establish quantifier_scope_inside_normative_operators",
             "structural_coverage_satisfied": False, "semantic_floor_verified": False},
            {"requested_logic": "temporal_first_order_logic", "canonical_family": "tdfol", "profile": "temporal_first_order",
             "status": "retained_tdfol_profile_composition_not_an_independent_tfol_family",
             "structural_coverage_satisfied": bool(ready(exact_profiles.get(("tdfol", "temporal_first_order")))),
             "reason": "profile_label_and_structural_view_do_not_verify_temporal_quantifier_or_source_semantics",
             "semantic_floor_verified": False},
            {"requested_logic": "temporal_deontic_first_order_logic", "canonical_family": "tdfol", "profile": None,
             "structural_coverage_satisfied": bool(ready(families["tdfol"])), "semantic_floor_verified": False},
            {"requested_logic": "cognitive_event_calculus", "canonical_family": None, "profile": None,
             "related_canonical_families": ["event_calculus", "dcec"],
             "status": "cognitive_CEC_requirement_not_verified_by_lifecycle_event_calculus_view",
             "reason": "legacy_cec_or_dcec_alias_to_event_calculus_cannot_establish_cognitive_operators",
             "structural_coverage_satisfied": False, "semantic_floor_verified": False},
            {"requested_logic": "deontic_cognitive_event_calculus", "canonical_family": "dcec", "profile": None,
             "structural_coverage_satisfied": bool(ready(families["dcec"])),
             "reason": "requires_exact_dcec_family_never_legacy_alias_event_calculus",
             "semantic_floor_verified": False},
            {"requested_logic": "frame_logic", "canonical_family": "frame_logic", "profile": None,
             "structural_coverage_satisfied": bool(ready(families["frame_logic"])), "semantic_floor_verified": False},
            {"requested_logic": "propositional_logic", "canonical_family": "propositional", "profile": None,
             "structural_coverage_satisfied": bool(ready(families["propositional"])), "semantic_floor_verified": False},
        ]
        if domain != "legal_ir":
            named_requirements.extend([
                {"requested_logic": "state_logic", "canonical_family": "transition_system", "profile": None,
                 "structural_coverage_satisfied": bool(ready(families["transition_system"])), "semantic_floor_verified": False},
                {"requested_logic": "TLA+", "canonical_family": "transition_system", "profile": "tla_plus",
                 "structural_coverage_satisfied": bool(ready(exact_profiles.get(("transition_system", "tla_plus")))),
                 "reason": "generated_TLA_projection_is_not_a_TLC_run_or_semantic_proof", "semantic_floor_verified": False}])
        totals = {}
        for split, numeric, feature_panel in (
            ("training", fit["report"]["training_coverage"], fit["report"]["effective_feature_panels"]["training"]),
            ("tuning", fit["report"]["validation_coverage"], fit["report"]["effective_feature_panels"]["validation"]),
            ("heldout", inferred["coverage"], report["results"][domain]["initial"]["effective_feature_panel"]),
        ):
            rows = numeric["projections"]
            known, unknown = (sum(row[key] for row in rows) for key in ("known_atoms", "unknown_atoms"))
            totals[split] = {"known_atom_occurrences": known, "unknown_atom_occurrences": unknown,
                "unknown_occurrence_fraction": unknown / (known + unknown) if known + unknown else None,
                "covered_projection_rows": sum(row["has_coverage"] for row in rows),
                "reported_projection_rows": len(rows), "untrained_projection_ids": numeric["untrained_projection_ids"],
                "effective_feature_panel": feature_panel,
                "scope": "summed_native_projection_atom_occurrences_not_unique_tokens_or_semantic_propositions"}
        summaries[domain] = {"family_floor_satisfied": audited["floor_satisfied"],
            "required_profile_floor": [row for row in audited["required_floor"] if row["profile"]],
            "missing_required_families": [row["family_id"] for row in audited["required_floor"] if not row["profile"] and not row["floor_satisfied"]],
            "named_logic_requirements": named_requirements, "feature_coverage": totals,
            "selected_receipt": {"backend": "prepared", "seed": 1729, "checkpoint_sha256": identity["sha256"]}, **FALSE}
    # Recheck all read bytes and source producers before publishing new files.
    for file, digest in {**inputs, **sources}.items():
        if _file(Path(file)) != digest:
            raise ValueError("source or evidence changed during postprocessing: " + file)
    output.mkdir()
    artifacts = {}
    for domain, audited in audits.items():
        path = output / (domain + "-coverage.json")
        with path.open("xb") as stream:
            stream.write(_raw(audited))
        artifacts[path.name] = _file(path)
    result = {"schema": "multidomain-existing-profile-coverage/v1", "campaign": str(campaign),
        "source_files": sources, "input_files": inputs, "coverage_files": artifacts,
        "domains": summaries, "test_data_already_exposed": True,
        "scope": "posthoc_coverage_audit_of_stored_receipts_not_candidate_selection_or_new_execution",
        "profile_floor_predeclared_before_original_training": False,
        "all_applicable_requirements_inferred": False, "constitution_formalized": False, **FALSE}
    with (output / "summary.json").open("xb") as stream:
        stream.write(_raw(result))
    print(json.dumps({"summary": str(output / "summary.json"), "domains": {
        domain: {"floor": value["family_floor_satisfied"],
            "profile_floor": value["required_profile_floor"],
            "heldout_features": value["feature_coverage"]["heldout"]} for domain, value in summaries.items()}}, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    run(arguments.campaign, arguments.output)
