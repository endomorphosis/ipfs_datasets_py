"""Separate native declaration Lake checks; no learned checkpoint is exercised."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent / "source"
OUTPUT = Path(__file__).resolve().parent / "native-schema-validation"
JEVOPS = Path("/home/barberb/lift_coding/JevOps")


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def write(path, value):
    with path.open("xb") as stream:
        stream.write(raw(value))


def load(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    from ipfs_datasets_py.logic.autoformal.tree_pin import require_workspace_logic_tree
    from ipfs_datasets_py.logic.formalization.autoencoder.domain_targets import prepare_intent_targets
    from ipfs_datasets_py.logic.formalization.autoencoder.ui_training_inputs import prepare_ui_training_row
    from ipfs_datasets_py.logic.intent_ir.decoder import decode_intent_ir
    from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_schema_lake as lake
    paths = require_workspace_logic_tree()
    if any(not Path(path).is_relative_to(ROOT) for path in paths.values()):
        raise RuntimeError("validation must use clean release export")
    OUTPUT.mkdir()
    start = time.perf_counter()
    gates_module = load("_native_schema_gates", "scripts/ops/legal_ir/smoke_legacy_linguistic_autoencoder.py")
    teacher_module = load("_native_schema_minimum", "scripts/ops/legal_ir/validate_legacy_linguistic_teacher.py")
    fixture_module = load("_native_schema_fixtures", "tests/unit/optimizers/logic_theorem_optimizer/test_autoencoder_projection_features.py")
    ui_module = load("_native_schema_ui", "tests/unit/logic/formalization/autoencoder/test_ui_training_inputs.py")
    gates = gates_module._typed_gates(JEVOPS)
    write(OUTPUT / "canonical-gates.json", gates)
    legal_build = teacher_module._lake_minimum(gates, OUTPUT / "canonical-minimum", JEVOPS)
    minimum_rule = {key: value for key, value in gates["rows"][2]["rule_with_parser_sidecars"].items()
                    if key != "temporal_records"}
    intent_fixture = ROOT / "tests/fixtures/intent_ir/admissibility/intents/benign_skill.json"
    intent_source = intent_fixture.read_text()
    intent_target = prepare_intent_targets(decode_intent_ir(json.loads(intent_source))).to_dict()
    ui_input = ui_module.native_row(0)
    ui_target = prepare_ui_training_row(ui_input).target.to_dict()
    declarations = {
        "legal_ir": (gates["rows"][2]["source_text"], {"rules": [minimum_rule]}, "canonical_user_minimum_gate"),
        "intent_ir": (intent_source, intent_target, "existing_authored_native_IntentIR_declaration"),
        "security_ir": ("def one():\n    return 1\n", fixture_module._security(1).to_dict(), "authored_ProgramIR_with_exact_source_bytes"),
        "ui_ux_ir": (raw(ui_input).decode(), ui_target, "authored_UI_IDL_declaration_with_synthetic_event"),
    }
    selected = {"intent_ir": "intent-route/norms/v1", "security_ir": "program.program_ir/v1", "ui_ux_ir": "ui_ux_ir:flogic"}
    results = {}
    for domain, (source, declaration, origin) in declarations.items():
        if domain == "legal_ir":
            output = declaration
        else:
            row = next(row for row in declaration["projections"] if row["projection_id"] == selected[domain])
            output = {key: row[key] for key in ("projection_id", "expression", *lake.DESCRIPTOR_FIELDS)}
        fixture = {"domain": domain, "source_text": source, "native_declaration": declaration, "output": output}
        digest = sha(raw(fixture))
        write(OUTPUT / (domain + "-input.json"), fixture)
        execution = lake.validate_schema_output(domain, output, source_text=source,
            checkpoint_sha256=digest, output_directory=OUTPUT / (domain + "-schema"), timeout_seconds=60)
        result = lake.verify_schema_execution(execution, domain, output, source_text=source, checkpoint_sha256=digest)
        if not result["schema_instance_typecheck_passed"]:
            raise RuntimeError("schema Lake check failed for " + domain)
        results[domain] = {"native_fixture_origin": origin, "binding_digest_kind": "authored_fixture_identity_not_model_checkpoint",
            "checkpoint_loaded": False, "learned_output": False, "execution": result}
    producers = {}
    for name, module in list(sys.modules.items()):
        if not name.startswith("ipfs_datasets_py"):
            continue
        file = getattr(module, "__file__", None)
        if file and Path(file).is_file() and Path(file).is_relative_to(ROOT):
            producers[str(Path(file).relative_to(ROOT))] = sha(Path(file).read_bytes())
    report = {"schema": "multidomain-separate-native-schema-checks/v1", "base_commit": "4425e503ab8550ec8ae0388bc88e54d63c1eb317",
        "source_tree": str(ROOT), "logic_tree_pin": paths, "producer_sources": producers,
        "validation_script_sha256": sha(Path(__file__).read_bytes()), "canonical_gates": gates,
        "canonical_legal_build": legal_build, "schema_checks": results, "actual_schema_builds": 4,
        "actual_canonical_legal_builds": 1, "elapsed_seconds": time.perf_counter() - start,
        "native_targets_not_learned_outputs": True, "feature_head_decoder_validation": False,
        "all_family_syntax_verified": False, "source_semantics_verified": False,
        "admitted": False, "qualified": False, "formalized": False, "roundtrip_ok": False,
        "constitution_formalized": False, "temperature": 0,
        "bridge_names": [], "legal_ir_target_count": 0, "legal_ir_evaluate_provers": False,
        "metric_disk_cache": False, "legal_ir_parallel_workers": 1, "use_sample_memory": False,
        "parser_timing_scope": "first_gate_cold_process_then_warm_imports;three_authored_gates_only"}
    write(OUTPUT / "report.json", report)
    print(json.dumps({"schema_builds": 4, "canonical_legal_builds": 1, "typed_gates": 3,
                      "elapsed_seconds": report["elapsed_seconds"], "report": str(OUTPUT / "report.json")}))


if __name__ == "__main__":
    main()
