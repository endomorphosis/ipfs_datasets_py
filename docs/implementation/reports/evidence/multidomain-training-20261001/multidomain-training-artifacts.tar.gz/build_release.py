from pathlib import Path
import hashlib
import json
import statistics
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
RUN = Path(__file__).resolve().parent
OUT = ROOT / 'docs/implementation/reports/evidence/multidomain-training-20261001'
OWNED = [
 'ipfs_datasets_py/logic/formalization/autoencoder/family_coverage_audit.py',
 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_family_training_prepared.py',
 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/domain_family_training_prepared.py',
 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/domain_reconstruction_panel.py',
 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/intent_family_training_v2.py',
 'scripts/ops/autoencoder/benchmark_domain_reconstruction.py',
 'scripts/ops/autoencoder/benchmark_domain_training_throughput.py',
 'scripts/ops/legal_ir/benchmark_prepared_family_training.py',
 'tests/unit/logic/formalization/autoencoder/test_family_coverage_audit.py',
 'tests/unit/logic/formalization/autoencoder/test_intent_family_training_v2.py',
 'tests/unit/logic/test_benchmark_domain_reconstruction.py',
 'tests/unit/logic/test_benchmark_domain_training_throughput.py',
 'tests/unit/logic/test_benchmark_prepared_family_training.py',
 'tests/unit/optimizers/logic_theorem_optimizer/test_autoencoder_family_training_prepared.py',
 'tests/unit/optimizers/logic_theorem_optimizer/test_domain_reconstruction_panel.py',
]

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block)
 return h.hexdigest()

def read(name):return json.loads((RUN/name).read_bytes())
def write(name,value):(OUT/name).write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n')

OUT.mkdir(parents=True,exist_ok=False)
pins={}
for name in OWNED:
 assert sha(ROOT/name)==sha(RUN/'source'/name),name
 pins[name]=sha(ROOT/name)
write('release-tree.json',dict(base_commit='4425e503ab8550ec8ae0388bc88e54d63c1eb317',files=pins,
 source_scope='clean git export plus only listed new files; concurrent dirty source excluded'))
short=read('four-domain-r1/report.json')
long=read('domain-throughput-r1/report.json')
profiles=read('profile-coverage-postprocess-r2/summary.json')
schema=read('native-schema-validation/report.json')
summary={
 'schema':'multidomain-training-release/v1',
 'measurement_scope':'auxiliary native structural reconstruction, not learned source/formula decoding',
 'base_commit':'4425e503ab8550ec8ae0388bc88e54d63c1eb317',
 'short_freeze_sha256':short['freeze_sha256'],
 'training_samples_per_domain':24,'tuning_samples_per_domain':8,'heldout_samples_per_domain':8,
 'heldout_groups_per_domain':4,'seeds':[1729,1730,1731],
 'heldouts_fixed_before_exposure':True,'heldouts_now_exposed':True,
 'long_run_heldout_used':False,'all_reference_prepared_exact':long['all_exact'],
 'domains':{},'qualified':False,'admitted':False,'formalized':False,'constitution_formalized':False,
 'roundtrip_ok':False,'source_decoder_trained':False,'source_semantics_verified':False,
 'all_logic_families_supported':False,'lake_validated_learned_outputs':False,
 'actual_native_schema_builds':schema['actual_schema_builds'],
 'actual_canonical_legal_builds':schema['actual_canonical_legal_builds'],
 'bridge_names':[],'legal_ir_target_count':0,'legal_ir_evaluate_provers':False,
 'metric_disk_cache':False,'use_sample_memory':False,'workers':1,'temperature':0,
 'weights_downloaded':False,'CUDA_visible_devices':'','OMP_MKL_OPENBLAS_threads':1,
 'performance_scope':'warm shared CPU; complete numerical train calls with target preparation separately reported; not bridge-on evaluate',
 'long_run_peak_rss_bytes':long['peak_rss_bytes'],
 'short_evaluation_peak_rss_bytes':short['peak_rss_bytes'],
 'known_limits':['Security eight heldout rows collapse to two retained feature vectors',
  'Feature budget excludes many known training atoms, especially Intent; loss does not reconstruct omitted atoms',
  'Short Intent prepared training is slower; explicit backend selection and v2 default remain',
  'Intent/Security/UI selected ridge calibration; subsequent equal-budget Adam proposals were not selected',
  'Native full-family coverage and source-decoder fidelity are not established',
  'Four existing aligned-source tests require a local development parent absent from the export',
  'Structural optimizer continuation starts fresh Adam and max_seconds excludes preparation'],
}
for domain,short_row in short['results'].items():
 after=[r for r in short_row['outcomes'] if r['backend']=='prepared']
 objective=statistics.mean(r['objective'] for r in after)
 summary['domains'][domain]={
  'heldout_initial_objective':short_row['initial']['objective'],
  'heldout_trained_objectives':[r['objective'] for r in after],
  'heldout_objective_mean':objective,
  'heldout_relative_reduction':1-objective/short_row['initial']['objective'],
  'heldout_regressed_families':[r['regressed_families_against_initializer'] for r in after],
  'heldout_effective_feature_panel':short_row['initial']['effective_feature_panel'],
  'short_training_rows_per_second':short_row['mean_training_rows_per_second'],
  'short_wall_ratio_reference_over_prepared':short_row['wall_ratio_reference_over_prepared'],
  'long_training':long['domains'][domain]['timing'],
  'long_wall_ratio_reference_over_prepared':long['domains'][domain]['ratio_of_mean_training_wall_times'],
  'trained_families':short_row['trained_logic_families'],
  'missing_required_families':short_row['missing_required_families'],
  'required_profile_floor':profiles['domains'][domain]['required_profile_floor'],
  'feature_coverage':profiles['domains'][domain]['feature_coverage'],
 }
x=ET.parse(RUN/'final-tests.xml').getroot()
suites=list(x.iter('testsuite'))
tests={key:sum(int(s.attrib.get(key,0)) for s in suites) for key in ('tests','failures','errors','skipped')}
tests['passed']=tests['tests']-tests['failures']-tests['errors']-tests['skipped']
tests['skip_reason']='four existing aligned Intent tests require a local legal-initialized development checkpoint'
summary['tests']=tests
write('summary.json',summary)
write('tests.json',tests)
for source,dest in [('four-domain-r1/report.json','short-heldout-report.json'),
 ('domain-throughput-r1/report.json','long-throughput-report.json'),
 ('profile-coverage-postprocess-r2/summary.json','profile-coverage.json'),
 ('native-schema-validation/report.json','native-schema-validation.json')]:
 (OUT/dest).write_bytes((RUN/source).read_bytes())

selected={}
for directory in ('four-domain-r1','domain-throughput-r1','prepared-throughput-r1','prepared-throughput-r2',
 'current-profile','native-schema-validation','profile-coverage-postprocess','profile-coverage-postprocess-r2'):
 for path in (RUN/directory).rglob('*'):
  if path.is_file() and not path.is_symlink() and '.lake' not in path.parts and '__pycache__' not in path.parts:
   selected[str(path.relative_to(RUN))]=path
for path in RUN.iterdir():
 if path.is_file() and path.suffix in ('.py','.json','.xml','.log','.txt'):
  selected[path.name]=path
for name in OWNED:selected['captured-source/'+name]=RUN/'source'/name
manifest=[]
archive=OUT/'multidomain-training-artifacts.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 seen={}
 for name,path in sorted(selected.items()):
  digest=sha(path); info=tar.gettarinfo(str(path),arcname=name)
  if digest in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[digest];info.size=0;tar.addfile(info)
  else:
   with path.open('rb') as stream:tar.addfile(info,stream)
   seen[digest]=name
  manifest.append(dict(path=name,sha256=digest,bytes=path.stat().st_size))
with tarfile.open(archive,'r:gz') as tar:
 for row in manifest:
  h=hashlib.sha256()
  with tar.extractfile(row['path']) as stream:
   for block in iter(lambda:stream.read(1048576),b''):h.update(block)
  assert h.hexdigest()==row['sha256'],row['path']
write('artifact-manifest.json',dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,
 members=manifest,exclusions=['preexisting model/embedding weights','source export except changed files','.lake compiled build cache']))
(OUT/'README.md').write_text('''# Four-domain reconstruction evidence

`summary.json` contains the measured outcomes and limits; the adjacent raw
reports retain the source-bound observations. The archive contains native
targets, all frozen numerical heads, loss histories, predictions, exact profile
audits, test results, source captures and actual Lake source/log receipts.
`artifact-manifest.json` verifies every archived payload and the archive itself.
Failed early test/harness attempts remain alongside their final successful runs.

The quality comparison is trained structural features versus a training-only
initializer. Prepared and reference execution have identical retained weights.
This is not learned source-formula fidelity, full logic-family qualification,
Constitution formalization, or a bridge-on legal-IR timing. The later long run
used development targets only. The eight heldout rows are now exposed.

Receipts retain original absolute artifact paths. They are historical evidence,
not a portable checkpoint registry manifest. Reproduce with a fresh experiment
from the recorded base commit plus captured sources and explicit PYTHONPATH.
No preexisting teacher or semantic embedding weights are included.
''')
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),
 members=len(manifest),tests=tests),sort_keys=True))
