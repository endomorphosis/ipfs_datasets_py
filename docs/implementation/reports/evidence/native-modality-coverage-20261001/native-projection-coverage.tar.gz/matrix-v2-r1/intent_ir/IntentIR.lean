-- Actual native interpretation declarations; no source truth asserted.

namespace IntentIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_1
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.function "S8ee42eb01dbe10b532e9bc36bed0c7c2efea4960881bdcad7f14097caf3758b8" []), (i.function "S3d6216d1d5c00166efb44c16dc9a85d17f171a2ced8bd9c9b9a99e9517102c29" [])] t))
end Projection_1

namespace Projection_2
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t)))
end Projection_2

namespace Projection_3
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S46dfabb49da2ecf53a423a29a7a2f60ddb5eb0c8b82f7de99b9ba6289a1e72a6" [(i.function "Scc978d3047ffb2256ca7e7023a944e38642b8f55b205bb2beab7d7b77b1c94b6" []), (i.function "S4033315eb7d6dc419b66e78f0d9cfc51bd1bbf9a434c9a9ec648f5c97431587a" [])] t))
end Projection_3

namespace Projection_4
def norm_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "custodian"), (i.constant "record")] t)
end Projection_4

namespace Projection_5
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Reports" [v0] t)) t)
end Projection_5

namespace Projection_6
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t))
end Projection_6

namespace Projection_8
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Person" [v0] t) t) → ((fun t => i.atom "Reports" [v0] t) t)) t)
end Projection_8

namespace Projection_9
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_d6730607f32f834e68d4810a1dbc57d9f843ebdbe4e90016461e7a3309ed7791") "/document_id" (i.constant "\"intent-rich:ae8d034dd5b64facd9cc600ab18c401f3fa118b1d231d3c02a01fefe413ebfe3\"")
def frame_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_d6730607f32f834e68d4810a1dbc57d9f843ebdbe4e90016461e7a3309ed7791") "/entry_action_ids/0" (i.constant "\"action:0\"")
def frame_2 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_d6730607f32f834e68d4810a1dbc57d9f843ebdbe4e90016461e7a3309ed7791") "/intent_kind" (i.constant "\"declarative\"")
def frame_3 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_d6730607f32f834e68d4810a1dbc57d9f843ebdbe4e90016461e7a3309ed7791") "/schema_version" (i.constant "\"intent-ir/v1\"")
def frame_4 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_d6730607f32f834e68d4810a1dbc57d9f843ebdbe4e90016461e7a3309ed7791") "/tags/0" (i.constant "\"learned-candidate\"")
def frame_5 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_d6730607f32f834e68d4810a1dbc57d9f843ebdbe4e90016461e7a3309ed7791") "/terminal_action_ids/0" (i.constant "\"action:0\"")
def frame_6 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_d6730607f32f834e68d4810a1dbc57d9f843ebdbe4e90016461e7a3309ed7791") "/title" (i.constant "\"Rich candidate action/workflow view\"")
def frame_7 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_sha256" (i.constant "\"\"")
def frame_8 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_uri" (i.constant "\"\"")
def frame_9 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_cid" (i.constant "\"\"")
def frame_10 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_sha256" (i.constant "\"ae8d034dd5b64facd9cc600ab18c401f3fa118b1d231d3c02a01fefe413ebfe3\"")
def frame_11 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/license_expression" (i.constant "\"\"")
def frame_12 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/ref_id" (i.constant "\"source\"")
def frame_13 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/review_status" (i.constant "\"machine_extracted\"")
def frame_14 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_id" (i.constant "\"ae8d034dd5b64facd9cc600ab18c401f3fa118b1d231d3c02a01fefe413ebfe3\"")
def frame_15 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_revision" (i.constant "\"ae8d034dd5b64facd9cc600ab18c401f3fa118b1d231d3c02a01fefe413ebfe3\"")
def frame_16 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_uri" (i.constant "\"instruction:learned-rich-intent\"")
def frame_17 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span/end_char" (i.constant "30")
def frame_18 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span/start_char" (i.constant "0")
def frame_19 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/arguments/0" (i.constant "\"custodian\"")
def frame_20 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/arguments/1" (i.constant "\"record\"")
def frame_21 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/confidence" (i.constant "0.0")
def frame_22 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/grounding" (i.constant "\"inferred\"")
def frame_23 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/kind" (i.constant "\"goal\"")
def frame_24 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/modality" (i.constant "\"required\"")
def frame_25 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/normalized_text" (i.constant "\"custodian must publish record.\"")
def frame_26 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/predicate" (i.constant "\"publish\"")
def frame_27 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/review_status" (i.constant "\"machine_extracted\"")
def frame_28 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_29 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/statement_id" (i.constant "\"goal:0\"")
def frame_30 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/action_id" (i.constant "\"action:0\"")
def frame_31 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/actor" (i.constant "\"custodian\"")
def frame_32 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/effect_ids" (i.constant "[]")
def frame_33 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/grounding" (i.constant "\"inferred\"")
def frame_34 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/input_refs" (i.constant "[]")
def frame_35 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/object_refs/0" (i.constant "\"record\"")
def frame_36 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/output_refs" (i.constant "[]")
def frame_37 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/precondition_ids" (i.constant "[]")
def frame_38 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_39 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/tool_refs" (i.constant "[]")
def frame_40 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/verb" (i.constant "\"publish\"")
def frame_41 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/verification_ids" (i.constant "[]")
end Projection_9

namespace Projection_10
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"alice\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"officer\"}"))
end Projection_10

namespace Projection_11
-- Generated candidate embedding. No semantic axioms or program proofs are asserted.
namespace IntentProjection

structure Interpretation where
  atom : String → List String → Prop
  intended : Prop → Prop
  required : Prop → Prop
  prohibited : Prop → Prop
  permitted : Prop → Prop
  recommended : Prop → Prop

def statement_2160ce67377bde48d2c07b770e67164c3d9f9695c3d12602386c3c58bb64aacb (i : Interpretation) : Prop :=
  i.required (i.atom "publish" ["custodian", "record"])

end IntentProjection

end Projection_11

namespace Projection_12
-- Parameterized syntax fixture; referents and modal operators are arbitrary inputs.
namespace TypedSlotFixture
set_option autoImplicit false
def formula (T0 : Type) (T1 : Type) (v0 : T0) (v1 : T1) (p0 : T0 → T1 → Prop) (m0 : Prop → Prop) : Prop := (m0 (p0 v0 v1))
end TypedSlotFixture

end Projection_12

namespace Projection_14
structure IntentActionInterpretation (World Entity : Type) where
  constant : String → Entity
  atom : String → List Entity → World → Prop
  step : String → Entity → String → List Entity → World → World → Prop
def actionContract_0 {World Entity : Type} (i : IntentActionInterpretation World Entity) : Prop :=
  ∀ s t, (True) → (i.step "action:0" (i.constant "custodian") "publish" [(i.constant "record")] s t) → (True)
end Projection_14

namespace Projection_15
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "p" [] t) ∧ (i.atom "q" [] t))
end Projection_15

namespace Projection_16
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.constant "entity:8ee42eb01dbe10b532e9bc36bed0c7c2efea4960881bdcad7f14097caf3758b8"), (i.constant "entity:3d6216d1d5c00166efb44c16dc9a85d17f171a2ced8bd9c9b9a99e9517102c29")] t))
end Projection_16

namespace Projection_17
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Reports" [v0] t))) t)
end Projection_17

namespace Projection_18
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S46dfabb49da2ecf53a423a29a7a2f60ddb5eb0c8b82f7de99b9ba6289a1e72a6" [(i.constant "entity:Scc978d3047ffb2256ca7e7023a944e38642b8f55b205bb2beab7d7b77b1c94b6"), (i.constant "entity:S4033315eb7d6dc419b66e78f0d9cfc51bd1bbf9a434c9a9ec648f5c97431587a")] t))
end Projection_18

namespace Projection_19
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["position_0", "done"])
def predicate_0 (s : State) : Prop := (s.v0 = "done")
def predicate_1 (s : State) : Prop := (s.v0 = "done")
def predicate_2 (s : State) : Prop := (s.v0 = "position_0")
def predicate_3 (s : State) : Prop := (s.v0 = "position_0")
def predicate_4 (s : State) : Prop := (s.v0 = "done")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:abstract:0" ∧ action_0 s t) ∨ (label = "action:done" ∧ action_1 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_0 s) : action_1 s s := by
  simpa [action_1, predicate_0, predicate_1] using And.intro h h
def declaredMaxSteps : Nat := 64
def boundedControlRun (trace : Nat → State) (labels : Nat → String) : Prop :=
  initial (trace 0) ∧ ∀ k, k < declaredMaxSteps → next (labels k) (trace k) (trace (k + 1))
def intentActionOrigins : List (String × String) := [("action:abstract:0", "action:0")]
def completeDeclaredActionSequence (labels : List String) : Prop := labels = ["action:0"]

end Projection_19

namespace Projection_20
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Reports" [v0] t)) t)
end Projection_20

namespace Projection_21
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["position_0", "done"])
def predicate_0 (s : State) : Prop := (s.v0 = "done")
def predicate_1 (s : State) : Prop := (s.v0 = "done")
def predicate_2 (s : State) : Prop := (s.v0 = "position_0")
def predicate_3 (s : State) : Prop := (s.v0 = "position_0")
def predicate_4 (s : State) : Prop := (s.v0 = "done")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:abstract:0" ∧ action_0 s t) ∨ (label = "action:done" ∧ action_1 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_0 s) : action_1 s s := by
  simpa [action_1, predicate_0, predicate_1] using And.intro h h
def declaredMaxSteps : Nat := 64
def boundedControlRun (trace : Nat → State) (labels : Nat → String) : Prop :=
  initial (trace 0) ∧ ∀ k, k < declaredMaxSteps → next (labels k) (trace k) (trace (k + 1))
def intentActionOrigins : List (String × String) := [("action:abstract:0", "action:0")]

end Projection_21

namespace Projection_22
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["position_0", "done"])
def predicate_0 (s : State) : Prop := (s.v0 = "done")
def predicate_1 (s : State) : Prop := (s.v0 = "done")
def predicate_2 (s : State) : Prop := (s.v0 = "position_0")
def predicate_3 (s : State) : Prop := (s.v0 = "position_0")
def predicate_4 (s : State) : Prop := (s.v0 = "done")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:abstract:0" ∧ action_0 s t) ∨ (label = "action:done" ∧ action_1 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_0 s) : action_1 s s := by
  simp_all [action_1, predicate_0, predicate_1]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := [("action:abstract:0", "action:0")]
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := [("action:done", "adapter_generated_terminal_self_loop")]
def stateAbstraction : String := "abstract_intent_control_flow"
def sourceIntentDocument : String := "intent-rich:ae8d034dd5b64facd9cc600ab18c401f3fa118b1d231d3c02a01fefe413ebfe3"
def sourceIntentIRSHA256 : String := "9efed08e3ce177d508e6a14e5a8b0a4a6e75b3267bb4f2ae96c879fd02814577"
def intentPositionMap : List (String × String × String × String) := [("action:abstract:0", "action:0", "position_0", "done")]
def codeEffectsModeled : Bool := false
def normativeComplianceModeled : Bool := false
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 64
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:abstract:0", "action:done"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

end Projection_22

end IntentIR

