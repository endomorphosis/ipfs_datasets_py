-- Actual native interpretation declarations; no source truth asserted.

namespace UIUXIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_0
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t)))
end Projection_0

namespace Projection_1
def cognitive_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.cognitive "observes" (i.agent "user") (fun t => i.atom "activate" [i.constant "component:action"] t)
def sources_0 : List String := []
end Projection_1

namespace Projection_2
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Reports" [v0] t)) t)
end Projection_2

namespace Projection_3
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t))
end Projection_3

namespace Projection_4
def declaredStates : List String := ["finished", "pending"]
def declaredEdges : List (String × String × String) := [("event:activate", "pending", "finished")]
def declaredInitiates : List (String × String) := [("event:activate", "finished")]
def declaredTerminates : List (String × String) := [("event:activate", "pending")]
def step (event beforeState afterState : String) : Prop := (event, beforeState, afterState) ∈ declaredEdges
def initiates (event state : String) : Prop := (event, state) ∈ declaredInitiates
def terminates (event state : String) : Prop := (event, state) ∈ declaredTerminates
def sourceReferences : List (List String) := [[], [], [], [], []]
theorem declared_edge_0 : step "event:activate" "pending" "finished" := by simp [step, declaredEdges]
end Projection_4

namespace Projection_5
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Person" [v0] t) t) → ((fun t => i.atom "Reports" [v0] t) t)) t)
end Projection_5

namespace Projection_6
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"alice\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"officer\"}"))
end Projection_6

namespace Projection_7
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "component:action") "ui_component" (i.constant "aria:button")
end Projection_7

namespace Projection_8
structure Input0 where
  f0 : String
def Input0FieldNames : List String := ["record_id"]
structure Output0 where
  f0 : Bool
def Output0FieldNames : List String := ["complete"]
structure Binding0 where
  binding_id : String
  action_id : String
  component_id : String
  dom_action : String
  interface_cid : String
  method_name : String
  risk_class : String
  confirmation_class : String
  idempotency : String
def declaredBinding0 : Binding0 := { binding_id := "binding:action", action_id := "publish_ledger", component_id := "component:action", dom_action := "activate", interface_cid := "bafkreiautsbf4ksjvkfweeudnsw55kkmq7af6fn7gzihnwrqkul7seimai", method_name := "publish_ledger", risk_class := "high", confirmation_class := "confirm", idempotency := "non_idempotent" }
def bindingMatches0 (b : Binding0) : Prop := b.binding_id = "binding:action" ∧ b.action_id = "publish_ledger" ∧ b.component_id = "component:action" ∧ b.dom_action = "activate" ∧ b.interface_cid = "bafkreiautsbf4ksjvkfweeudnsw55kkmq7af6fn7gzihnwrqkul7seimai" ∧ b.method_name = "publish_ledger" ∧ b.risk_class = "high" ∧ b.confirmation_class = "confirm" ∧ b.idempotency = "non_idempotent"
structure Contract0 where
  invoke : Input0 → Output0 → Prop
def boundInvocation0 (c : Contract0) (b : Binding0) (request : Input0) (result : Output0) : Prop := bindingMatches0 b ∧ c.invoke request result
theorem declared_binding_matches_0 : bindingMatches0 declaredBinding0 := by simp [bindingMatches0, declaredBinding0]
end Projection_8

namespace Projection_9
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "p" [] t) ∧ (i.atom "q" [] t))
end Projection_9

namespace Projection_10
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Reports" [v0] t))) t)
end Projection_10

namespace Projection_12
structure UIClock where
  identifier : String
  domain : String
  unit : String
  epoch : String
  numerator : Nat
  denominator : Nat
structure UIEvent where
  identifier : String
  eventType : String
  clock : String
  numerator : Nat
  denominator : Nat
  trueAtoms : List String
  falseAtoms : List String
  payload : String
  sourceRefs : List String
def declaredClocks : List UIClock := [{ identifier := "clock:ui-ms", domain := "discrete", unit := "millisecond", epoch := "", numerator := 1, denominator := 1 }]
def observedEvents : List UIEvent := [{ identifier := "event:ui:0", eventType := "activate", clock := "clock:ui-ms", numerator := 1, denominator := 1, trueAtoms := [], falseAtoms := [], payload := "{\"supplied_UI_event\":{\"capability_id\":\"pointer_mouse\",\"confidence\":null,\"consent_ok\":true,\"event_id\":\"event:activate\",\"kind\":\"activate\",\"provenance\":\"synthetic\",\"raw_payload\":{},\"schema_version\":\"ui-runtime-event/v1\",\"sequence\":0,\"source_adapter\":\"authored-structural-panel\",\"target_component_id\":\"component:action\",\"timestamp_ms\":1}}", sourceRefs := ["source:ui_ux_ir:5f34201d88a0ca82514f4d1f50817bd974bdc8ea5be42d5da8a583694039a2d7"] }]
def primaryClock : String := "clock:ui-ms"
def traceKind : String := "finite_prefix"
def completeWorkflowAsserted : Bool := false
def traceMetadata : String := "{\"UI_document_id\":\"ui_ux_ir:pair:0:2:0\",\"complete_workflow_asserted\":false,\"event_order\":\"supplied_tuple_order\",\"independently_attested\":false,\"source_sha256\":\"5f34201d88a0ca82514f4d1f50817bd974bdc8ea5be42d5da8a583694039a2d7\"}"
def observationPolicy : String := "explicit"
def observationPolicyId : String := "policy:ui-observed-only"
def visibleAtoms : List String := []
def eventAt (position : Nat) : Option UIEvent := observedEvents[position]?
def observation (position : Nat) (atom : String) : Option Bool :=
  match eventAt position with
  | none => none
  | some event =>
    if atom ∈ event.trueAtoms then some true
    else if atom ∈ event.falseAtoms then some false
    else none
def atOrBefore (left right : UIEvent) : Prop := left.clock = right.clock ∧ left.numerator * right.denominator ≤ right.numerator * left.denominator
theorem boundary_is_unknown (atom : String) : observation 1 atom = none := by simp [observation, eventAt, observedEvents]
end Projection_12

namespace Projection_13
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Reports" [v0] t)) t)
end Projection_13

namespace Projection_14
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["state_0", "state_1"])
def predicate_0 (s : State) : Prop := (s.v0 = "state_1")
def predicate_1 (s : State) : Prop := (s.v0 = "state_1")
def predicate_2 (s : State) : Prop := (s.v0 = "state_0")
def initial (s : State) : Prop := typeOK s ∧ (predicate_1 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:ui-state"].contains variableName
example : ["var:ui-state"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_2 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:ui:0" ∧ action_0 s t)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
end Projection_14

end UIUXIR

