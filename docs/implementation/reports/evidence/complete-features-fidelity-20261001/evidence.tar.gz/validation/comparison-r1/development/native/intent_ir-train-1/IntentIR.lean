-- Actual native interpretation declarations; no source truth asserted.

namespace IntentIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_0
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.cognitive "I" (i.agent "curator") (fun t => i.atom "publish" [(i.constant "curator"), (i.constant "request")] t)
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "curator"), (i.constant "request")] t)
def programSatisfaction {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := (formula_0 i t) ∧ (formula_1 i t)
end Projection_0

namespace Projection_1
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.function "Se87bec296bc61b77e2ba7e08f7fecb2cb14ab69bc02fe15d7ae67793f097fbd4" []), (i.function "S7fa6731177a15f47237da389fbdc08b60e14282cb824ff60789946b106fa9a8b" [])] t))
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "I" (i.agent "Se87bec296bc61b77e2ba7e08f7fecb2cb14ab69bc02fe15d7ae67793f097fbd4") (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.function "Se87bec296bc61b77e2ba7e08f7fecb2cb14ab69bc02fe15d7ae67793f097fbd4" []), (i.function "S7fa6731177a15f47237da389fbdc08b60e14282cb824ff60789946b106fa9a8b" [])] t))
end Projection_1

namespace Projection_2
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Curator") (fun t => i.atom "Happens" [(i.function "Publish" []), (i.function "Time" [])] t)))
end Projection_2

namespace Projection_3
def norm_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "curator"), (i.constant "request")] t)
end Projection_3

namespace Projection_4
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Publish" [v0] t)) t)
end Projection_4

namespace Projection_5
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "curator"), (i.constant "request")] t)
end Projection_5

namespace Projection_6
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Curator") (fun t => i.atom "Happens" [(i.function "Publish" []), (i.function "Time" [])] t))
end Projection_6

namespace Projection_7
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Curator" [v0] t) t) → ((fun t => i.atom "Publish" [v0] t) t)) t)
end Projection_7

namespace Projection_8
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_36bb809251348c8209c0842f232cd74ac68b99fd7eeac3e1c9572f638d8f0fd9") "/document_id" (i.constant "\"complete-features-v2:intent_ir:0:1\"")
def frame_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_36bb809251348c8209c0842f232cd74ac68b99fd7eeac3e1c9572f638d8f0fd9") "/entry_action_ids/0" (i.constant "\"action:declared\"")
def frame_2 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_36bb809251348c8209c0842f232cd74ac68b99fd7eeac3e1c9572f638d8f0fd9") "/intent_kind" (i.constant "\"procedure\"")
def frame_3 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_36bb809251348c8209c0842f232cd74ac68b99fd7eeac3e1c9572f638d8f0fd9") "/schema_version" (i.constant "\"intent-ir/v1\"")
def frame_4 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_36bb809251348c8209c0842f232cd74ac68b99fd7eeac3e1c9572f638d8f0fd9") "/tags" (i.constant "[]")
def frame_5 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_36bb809251348c8209c0842f232cd74ac68b99fd7eeac3e1c9572f638d8f0fd9") "/terminal_action_ids/0" (i.constant "\"action:declared\"")
def frame_6 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_36bb809251348c8209c0842f232cd74ac68b99fd7eeac3e1c9572f638d8f0fd9") "/title" (i.constant "\"Authored family-safe guarded Intent premise\"")
def frame_7 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_sha256" (i.constant "\"\"")
def frame_8 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_uri" (i.constant "\"\"")
def frame_9 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_cid" (i.constant "\"\"")
def frame_10 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_sha256" (i.constant "\"8c01fc6b9e9687bab6ad677074ad43f4f424f51cc9f7c75213128e74b501d146\"")
def frame_11 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/license_expression" (i.constant "\"\"")
def frame_12 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/ref_id" (i.constant "\"source\"")
def frame_13 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/review_status" (i.constant "\"unreviewed\"")
def frame_14 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_id" (i.constant "\"complete-features-v2:intent_ir:0:1\"")
def frame_15 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_revision" (i.constant "\"authored-complete-feature-panel/v2\"")
def frame_16 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_uri" (i.constant "\"urn:complete-features-v2:intent_ir:0:1\"")
def frame_17 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span" (i.constant "null")
def frame_18 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/arguments/0" (i.constant "\"request\"")
def frame_19 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/confidence" (i.constant "1.0")
def frame_20 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/grounding" (i.constant "\"grounded\"")
def frame_21 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/kind" (i.constant "\"effect\"")
def frame_22 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/modality" (i.constant "\"asserted\"")
def frame_23 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/normalized_text" (i.constant "\"request operation is complete.\"")
def frame_24 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/predicate" (i.constant "\"complete\"")
def frame_25 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/review_status" (i.constant "\"machine_extracted\"")
def frame_26 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_27 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/statement_id" (i.constant "\"effect\"")
def frame_28 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/arguments/0" (i.constant "\"curator\"")
def frame_29 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/arguments/1" (i.constant "\"request\"")
def frame_30 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/confidence" (i.constant "1.0")
def frame_31 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/grounding" (i.constant "\"grounded\"")
def frame_32 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/kind" (i.constant "\"goal\"")
def frame_33 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/modality" (i.constant "\"asserted\"")
def frame_34 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/normalized_text" (i.constant "\"curator intends to publish request.\"")
def frame_35 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/predicate" (i.constant "\"publish\"")
def frame_36 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/review_status" (i.constant "\"machine_extracted\"")
def frame_37 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_38 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/statement_id" (i.constant "\"goal:intended\"")
def frame_39 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/arguments/0" (i.constant "\"curator\"")
def frame_40 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/arguments/1" (i.constant "\"request\"")
def frame_41 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/confidence" (i.constant "1.0")
def frame_42 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/grounding" (i.constant "\"grounded\"")
def frame_43 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/kind" (i.constant "\"goal\"")
def frame_44 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/modality" (i.constant "\"required\"")
def frame_45 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/normalized_text" (i.constant "\"curator must publish request.\"")
def frame_46 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/predicate" (i.constant "\"publish\"")
def frame_47 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/review_status" (i.constant "\"machine_extracted\"")
def frame_48 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_49 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/statement_id" (i.constant "\"goal:required\"")
def frame_50 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/arguments/0" (i.constant "\"request\"")
def frame_51 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/confidence" (i.constant "1.0")
def frame_52 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/grounding" (i.constant "\"grounded\"")
def frame_53 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/kind" (i.constant "\"precondition\"")
def frame_54 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/modality" (i.constant "\"asserted\"")
def frame_55 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/normalized_text" (i.constant "\"request is ready.\"")
def frame_56 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/predicate" (i.constant "\"ready\"")
def frame_57 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/review_status" (i.constant "\"machine_extracted\"")
def frame_58 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_59 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/statement_id" (i.constant "\"pre\"")
def frame_60 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/action_id" (i.constant "\"action:declared\"")
def frame_61 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/actor" (i.constant "\"curator\"")
def frame_62 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/effect_ids/0" (i.constant "\"effect\"")
def frame_63 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/grounding" (i.constant "\"grounded\"")
def frame_64 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/input_refs" (i.constant "[]")
def frame_65 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/object_refs/0" (i.constant "\"request\"")
def frame_66 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/output_refs" (i.constant "[]")
def frame_67 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/precondition_ids/0" (i.constant "\"pre\"")
def frame_68 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_69 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/tool_refs" (i.constant "[]")
def frame_70 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/verb" (i.constant "\"publish\"")
def frame_71 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/verification_ids" (i.constant "[]")
end Projection_8

namespace Projection_9
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"curator\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"publish\"}"))
end Projection_9

namespace Projection_10
-- Generated candidate embedding. No semantic axioms or program proofs are asserted.
namespace IntentProjection

structure Interpretation where
  atom : String → List String → Prop
  intended : Prop → Prop
  required : Prop → Prop
  prohibited : Prop → Prop
  permitted : Prop → Prop
  recommended : Prop → Prop

def statement_11869691d490163b6656395be0479bda069f67b889bd9efa3afc89aae1a5398e (i : Interpretation) : Prop :=
  i.required (i.atom "publish" ["curator", "request"])

def statement_bfb50fc3afbac668f963c2faa8eeaddfa3504d64bba2767b0b7b5f142c6d74cc (i : Interpretation) : Prop :=
  i.intended (i.atom "publish" ["curator", "request"])

def statement_695252f664b93b2375fc1738693a32a19e8c722fe14e81a3d80cc5b85a923da0 (i : Interpretation) : Prop :=
  i.atom "ready" ["request"]

def statement_dcb576426a17b7df13907007cb02a1f1dfc12fc6c69f603717abca59d03b888e (i : Interpretation) : Prop :=
  i.atom "complete" ["request"]

end IntentProjection

end Projection_10

namespace Projection_11
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.cognitive "I" (i.agent "curator") (fun t => i.atom "publish" [(i.constant "curator"), (i.constant "request")] t)
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "curator"), (i.constant "request")] t)
def programSatisfaction {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := (formula_0 i t) ∧ (formula_1 i t)
end Projection_11

namespace Projection_12
def norm_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.cognitive "I" (i.agent "curator") (fun t => i.atom "publish" [(i.constant "curator"), (i.constant "request")] t)
end Projection_12

namespace Projection_13
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.cognitive "I" (i.agent "curator") (fun t => i.atom "publish" [(i.constant "curator"), (i.constant "request")] t)
end Projection_13

namespace Projection_14
structure IntentActionInterpretation (World Entity : Type) where
  constant : String → Entity
  atom : String → List Entity → World → Prop
  step : String → Entity → String → List Entity → World → World → Prop
def actionContract_0 {World Entity : Type} (i : IntentActionInterpretation World Entity) : Prop :=
  ∀ s t, ((i.atom "ready" [(i.constant "request")] s)) → (i.step "action:declared" (i.constant "curator") "publish" [(i.constant "request")] s t) → ((i.atom "complete" [(i.constant "request")] t))
end Projection_14

namespace Projection_15
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 4
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:declared", [("completed", (.boolean false)), ("ready", (.boolean true))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:declared", [("completed", (.boolean true)), ("ready", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def condition0 (values : Values) : Bool := (lookup values "completed" == some (.boolean true))
def condition0Source : String × String × List String := ("effect", "complete", ["request"])
def condition1 (values : Values) : Bool := (lookup values "ready" == some (.boolean true))
def condition1Source : String × String × List String := ("pre", "ready", ["request"])
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:declared")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("completed", (.boolean true))])) && ((configuration2.phase == "done")) && (condition1 configuration1.values) && (condition0 configuration2.values)
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:declared")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean true)].contains (lookup configuration1.values "ready"))) && (([some (.boolean false)].contains (lookup configuration1.values "completed")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:declared"]
def enabledActions : List String := ["action:declared"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_15

namespace Projection_16
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "curator" [] t) ∧ (i.atom "publish" [] t))
end Projection_16

namespace Projection_17
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.constant "entity:e87bec296bc61b77e2ba7e08f7fecb2cb14ab69bc02fe15d7ae67793f097fbd4"), (i.constant "entity:7fa6731177a15f47237da389fbdc08b60e14282cb824ff60789946b106fa9a8b")] t))
end Projection_17

namespace Projection_18
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Publish" [v0] t))) t)
end Projection_18

namespace Projection_19
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 4
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:declared", [("completed", (.boolean false)), ("ready", (.boolean true))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:declared", [("completed", (.boolean true)), ("ready", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def condition0 (values : Values) : Bool := (lookup values "completed" == some (.boolean true))
def condition0Source : String × String × List String := ("effect", "complete", ["request"])
def condition1 (values : Values) : Bool := (lookup values "ready" == some (.boolean true))
def condition1Source : String × String × List String := ("pre", "ready", ["request"])
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:declared")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("completed", (.boolean true))])) && ((configuration2.phase == "done")) && (condition1 configuration1.values) && (condition0 configuration2.values)
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:declared")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean true)].contains (lookup configuration1.values "ready"))) && (([some (.boolean false)].contains (lookup configuration1.values "completed")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:declared"]
def enabledActions : List String := ["action:declared"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_19

namespace Projection_20
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Publish" [v0] t)) t)
end Projection_20

namespace Projection_21
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 4
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:declared", [("completed", (.boolean false)), ("ready", (.boolean true))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:declared", [("completed", (.boolean true)), ("ready", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def condition0 (values : Values) : Bool := (lookup values "completed" == some (.boolean true))
def condition0Source : String × String × List String := ("effect", "complete", ["request"])
def condition1 (values : Values) : Bool := (lookup values "ready" == some (.boolean true))
def condition1Source : String × String × List String := ("pre", "ready", ["request"])
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:declared")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("completed", (.boolean true))])) && ((configuration2.phase == "done")) && (condition1 configuration1.values) && (condition0 configuration2.values)
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:declared")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean true)].contains (lookup configuration1.values "ready"))) && (([some (.boolean false)].contains (lookup configuration1.values "completed")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:declared"]
def enabledActions : List String := ["action:declared"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_21

namespace Projection_22
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 4
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:declared", [("completed", (.boolean false)), ("ready", (.boolean true))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:declared", [("completed", (.boolean true)), ("ready", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def condition0 (values : Values) : Bool := (lookup values "completed" == some (.boolean true))
def condition0Source : String × String × List String := ("effect", "complete", ["request"])
def condition1 (values : Values) : Bool := (lookup values "ready" == some (.boolean true))
def condition1Source : String × String × List String := ("pre", "ready", ["request"])
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:declared")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("completed", (.boolean true))])) && ((configuration2.phase == "done")) && (condition1 configuration1.values) && (condition0 configuration2.values)
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:declared")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean true)].contains (lookup configuration1.values "ready"))) && (([some (.boolean false)].contains (lookup configuration1.values "completed")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:declared"]
def enabledActions : List String := ["action:declared"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_22

end IntentIR

