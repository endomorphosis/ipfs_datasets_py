#!/usr/bin/env python3
"""Reproduce an exposed-panel source384 regression without mutating source/parents.

Run from any directory with PYTHONDONTWRITEBYTECODE=1 and an unused --output.
Only the already exposed train/validation development files are opened.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import resource
import sys
import time

HERE = Path(__file__).resolve().parent
DEFAULT_SOURCE = HERE.parent / "source"
DEFAULT_DATA = Path("/home/barberb/lift_coding/artifacts/source-reconstruction-v2-20261001/run-01")
FALSE = dict(qualified=False, admitted=False, proof_authority=False,
             source_semantics_verified=False, publication_performed=False,
             production_promotion_performed=False, lake_executed=False)


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode()


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    with path.open("xb") as f:
        f.write(raw(value) + b"\n")
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


def source_manifest(source):
    # These generated caches are not execution source and may be created by the
    # simultaneous native benchmark. This process disables bytecode generation.
    excluded = {".git", "__pycache__", ".pytest_cache"}
    result = []
    for root, dirs, files in os.walk(source):
        dirs[:] = sorted(d for d in dirs if d not in excluded)
        for name in sorted(files):
            path = Path(root) / name
            if path.suffix in {".pyc", ".pyo"} or not path.is_file():
                continue
            result.append({"path": str(path.relative_to(source)),
                           "sha256": sha(path), "bytes": path.stat().st_size,
                           "symlink": path.is_symlink()})
    return result


def typed_diff(expected, actual, path="$", result=None):
    if result is None:
        result = []
    if type(expected) is not type(actual):
        result.append({"path": path, "kind": "type", "expected": expected,
                       "actual": actual})
    elif isinstance(expected, dict):
        for k in sorted(set(expected) | set(actual)):
            if k not in expected or k not in actual:
                result.append({"path": path + "." + k, "kind": "missing_or_extra",
                               "expected_present": k in expected,
                               "actual_present": k in actual,
                               "expected": expected.get(k), "actual": actual.get(k)})
            else:
                typed_diff(expected[k], actual[k], path + "." + k, result)
    elif isinstance(expected, list):
        if len(expected) != len(actual):
            result.append({"path": path, "kind": "array_length",
                           "expected": len(expected), "actual": len(actual)})
        for i, (a, b) in enumerate(zip(expected, actual)):
            typed_diff(a, b, path + "[" + str(i) + "]", result)
    elif expected != actual:
        result.append({"path": path, "kind": "value", "expected": expected,
                       "actual": actual})
    return result


def fidelity(inferred, gold):
    rows = []
    assert len(inferred["rows"]) == len(gold)
    for actual, reference in zip(inferred["rows"], gold):
        assert actual["id"] == reference["id"]
        assert actual["target_access"] is False
        assert actual["teacher_forcing"] is False
        differences = typed_diff(reference["target"], actual["candidate_ir"])
        a, b = reference["embedding"], actual["reconstructed_embedding"]
        cosine = sum(x*y for x,y in zip(a,b)) / math.sqrt(sum(x*x for x in a)*sum(y*y for y in b))
        rows.append({"id": actual["id"], "reference_target": reference["target"],
                     "candidate_ir": actual["candidate_ir"],
                     "native_valid": actual["candidate_ir"] is not None,
                     "exact_target": not differences, "typed_differences": differences,
                     "status": actual["status"], "reason": actual["reason"],
                     "ended": actual["ended"],
                     "embedding_cosine": cosine,
                     "embedding_mse": sum((x-y)**2 for x,y in zip(a,b))/len(a), **FALSE})
    return {"rows": rows, "count": len(rows),
            "native_valid_count": sum(r["native_valid"] for r in rows),
            "exact_target_count": sum(r["exact_target"] for r in rows),
            "mean_embedding_cosine": sum(r["embedding_cosine"] for r in rows)/len(rows),
            "mean_embedding_mse": sum(r["embedding_mse"] for r in rows)/len(rows),
            "evaluation_scope": "previously_exposed_authored_regression_fragments",
            "new_holdout": False, **FALSE}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args()
    source, data, out = args.source.resolve(), args.data.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / "started.json").exists():
        raise SystemExit("Use a fresh output directory; existing evidence is immutable")
    sys.dont_write_bytecode = True
    os.environ.update(PYTHONDONTWRITEBYTECODE="1", HF_HUB_OFFLINE="1",
                      HF_DATASETS_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                      HF_HUB_DISABLE_TELEMETRY="1", CUDA_VISIBLE_DEVICES="",
                      OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    sys.path.insert(0, str(source))
    start = time.perf_counter()
    save(out / "started.json", {"script_sha256": sha(Path(__file__)),
                                "source": str(source), "data": str(data), **FALSE})
    prep_path = data / "preparation.json"
    prep = json.loads(prep_path.read_text())
    manifest = source_manifest(source)
    source_receipt = save(out / "source-manifest.json", {
        "source": str(source), "files": manifest,
        "excluded_generated_directories": [".git", "__pycache__", ".pytest_cache"],
        "manifest_sha256": hashlib.sha256(raw(manifest)).hexdigest()})
    save(out / "preparation-original.json", prep)
    from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_embedding_runtime as embeddings
    with embeddings._offline_guard():
        from ipfs_datasets_py.optimizers.logic_theorem_optimizer import domain_384_autoencoder as ae
        from ipfs_datasets_py.optimizers.logic_theorem_optimizer import modal_latent_formula as numerical
        from ipfs_datasets_py.logic.autoformal.tree_pin import require_workspace_logic_tree
        import torch
        torch.set_num_threads(1)
        loaded_tree = require_workspace_logic_tree()
        for module in (embeddings, ae, numerical):
            assert Path(module.__file__).resolve().is_relative_to(source)
        asset_path, assets = embeddings._snapshot_assets(embeddings.DEFAULT_SNAPSHOT_PATH)
        assert assets == prep["source_embeddings"]["assets"]
        parent_path = Path(prep["parent"]["path"])
        assert sha(parent_path) == prep["parent"]["sha256"]
        parent = json.loads(parent_path.read_text())
        numerical.validate_checkpoint(parent)
        assert parent["config"]["max_target_tokens"] == 64
        config = {"epochs": 1000, "batch_size": 4, "max_seconds": 30,
                  "learning_rate": .003, "patience": 120, "seed": 1729,
                  "reconstruction_weight": .1, "max_target_tokens": 64,
                  "embedding_provenance": prep["source_embeddings"]}
        provenance = {"source_manifest": source_receipt,
            "frozen_base": json.loads((source.parent / "base.json").read_text()),
            "frozen_candidate_files": json.loads((source.parent / "candidate-files.json").read_text()),
            "loaded_logic_tree": loaded_tree, "parent": prep["parent"],
            "parent_progress": parent["progress"], "parent_binding": parent["binding"],
            "parent_config": parent["config"], "embedding_asset_path": str(asset_path),
            "verified_assets": assets, "embedding_recomputed": False,
            "embedding_evidence_scope": "cached_vectors_bound_to_prior_producer_and_verified_local_asset_bytes",
            "preparation": {"path": str(prep_path), "sha256": sha(prep_path)},
            "script_sha256": sha(Path(__file__)), "configuration": config,
            "python": sys.version, "platform": platform.platform(),
            "packages": {name: importlib.metadata.version(name) for name in ("torch", "numpy")},
            "device": "cpu", "dtype": "float32", "torch_threads": torch.get_num_threads(),
            "temperature": 0, "downloads_performed": False,
            "training_indices": [0,1,2,84], "validation_indices": [0,1],
            "selection_note": "Index 84 supplies tuning-visible verify/link vocabulary from training; selection is disclosed and fixed before this run.",
            "new_holdout": False, "test_or_canary_files_opened": False, **FALSE}
        save(out / "provenance.json", provenance)
        summaries = {}
        for domain in ("intent_ir", "ui_ux_ir"):
            print("starting", domain, flush=True)
            domain_start = time.perf_counter()
            domain_out = out / domain
            domain_out.mkdir()
            selected, data_sources = {}, {}
            for split, indices in (("train", [0,1,2,84]), ("validation", [0,1])):
                file = data / domain / (split + ".json")
                file_sha = sha(file)
                assert file_sha == prep["development_files"][domain + "/" + split + ".json"]
                packet = json.loads(file.read_text())
                rows = [packet["rows"][i] for i in indices]
                for row in rows:
                    assert hashlib.sha256(row["source_text"].encode()).hexdigest() == row["source_sha256"]
                    assert ae.digest(row["embedding"]) == row["embedding_sha256"]
                    assert len(row["embedding"]) == 384
                    ae.validate_target(domain, row["target"])
                data_sources[split] = {"path": str(file), "sha256": file_sha,
                    "source_row_count": len(packet["rows"]), "selected_indices": indices}
                save(domain_out / (split + "-selected-original.json"), {"rows": rows,
                    "source_embeddings": packet["source_embeddings"]})
                selected[split] = [{k: row[k] for k in ("id", "source_text", "embedding", "target")} for row in rows]
                save(domain_out / (split + ".json"), selected[split])
            save(domain_out / "data-provenance.json", data_sources)
            training_start = time.perf_counter()
            result = ae.train(domain, selected["train"], selected["validation"],
                              parent_projection=prep["parent"], config=config)
            train_wall = time.perf_counter() - training_start
            checkpoint_receipt = save(domain_out / "checkpoint.json", result["checkpoint"])
            save(domain_out / "learning-curve.json", result["metrics"])
            reopen_start = time.perf_counter()
            reopened = ae.load_checkpoint(domain_out / "checkpoint.json",
                expected_sha256=checkpoint_receipt["sha256"], expected_domain=domain)
            runtime = reopened
            reopen_seconds = time.perf_counter() - reopen_start
            save(domain_out / "runtime-description.json", runtime.describe())
            evaluations, infer_times = {}, {}
            for split, rows in selected.items():
                inputs = [{k: row[k] for k in ("id", "source_text", "embedding")} for row in rows]
                assert all(set(row) == {"id", "source_text", "embedding"} for row in inputs)
                save(domain_out / (split + "-inference-input.json"), inputs)
                infer_start = time.perf_counter()
                inferred = runtime.infer(inputs)
                infer_times[split] = time.perf_counter() - infer_start
                save(domain_out / (split + "-inference.json"), inferred)
                evaluations[split] = fidelity(inferred, rows)
                save(domain_out / (split + "-fidelity.json"), evaluations[split])
            metrics = result["metrics"]
            summary = {"domain": domain, "train_count": 4, "validation_count": 2,
                "checkpoint": checkpoint_receipt,
                "before_validation": metrics["before_validation"],
                "selected_validation": metrics["selected_validation"],
                "validation_objective_delta": metrics["selected_validation"]["objective"] - metrics["before_validation"]["objective"],
                "selected_epoch": metrics["selected_epoch"], "optimizer_steps": metrics["optimizer_steps"],
                "stopped_reason": metrics["stopped_reason"],
                "training_call_wall_seconds": train_wall, "fit_seconds": metrics["fit_seconds"],
                "optimizer_seconds": metrics["optimizer_seconds"], "reopen_seconds": reopen_seconds,
                "inference_seconds": infer_times,
                "inference_rows_per_second": {split: len(selected[split])/seconds for split,seconds in infer_times.items()},
                "optimizer_examples_per_second": metrics["optimizer_examples_per_second"],
                "optimizer_tokens_per_second": metrics["optimizer_tokens_per_second"],
                "fit_tokens_per_second": metrics["fit_tokens_per_second"],
                "fidelity": {split: {k:v for k,v in report.items() if k != "rows"} for split,report in evaluations.items()},
                "domain_wall_seconds": time.perf_counter() - domain_start,
                "new_holdout": False, "target_free_inference": True, **FALSE}
            summaries[domain] = summary
            save(domain_out / "summary.json", summary)
            print(json.dumps(summary, sort_keys=True), flush=True)
        assert sha(parent_path) == prep["parent"]["sha256"]
        _, final_assets = embeddings._snapshot_assets(embeddings.DEFAULT_SNAPSHOT_PATH)
        assert final_assets == assets
        final_manifest = source_manifest(source)
        assert final_manifest == manifest, "frozen source manifest changed during execution"
        loaded_modules = {name: str(Path(mod.__file__).resolve()) for name,mod in tuple(sys.modules.items())
                          if name.startswith("ipfs_datasets_py") and getattr(mod,"__file__",None)}
        assert all(Path(path).is_relative_to(source) for path in loaded_modules.values())
        save(out / "loaded-modules.json", loaded_modules)
        save(out / "summary.json", {"schema": "bounded-source384-regression/v1", "domains": summaries,
            "elapsed_seconds": time.perf_counter() - start,
            "max_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            "source_unchanged": True, "parent_unchanged": True, "assets_unchanged": True,
            "scope": "actual_trained_source_embedding_conditioned_native_fragment_decoder",
            "new_holdout": False, "all_inference_target_free": True,
            "source_fidelity_claim": False, "convergence_guarantee": False, **FALSE})


if __name__ == "__main__":
    main()
