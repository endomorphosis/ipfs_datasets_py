"""Archive the exact frozen comparison, tests and supplemental regressions."""
import hashlib
import json
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN = Path(__file__).resolve().parent
SOURCE = RUN / 'source'
OUT = ROOT / 'docs/implementation/reports/evidence/complete-features-fidelity-20261001'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


owned = json.loads((RUN / 'candidate-files.json').read_text())
base = json.loads((RUN / 'base.json').read_text())['base']
summary = json.loads((RUN / 'comparison-r1/summary.json').read_text())
assert summary['actual_lake_builds'] == 20
assert not summary['admitted'] and not summary['models_promoted']
assert summary['development']['portfolio_diagnostics']['actual_attempts'] == 4
suites = [ET.parse(RUN / name).getroot().find('testsuite')
          for name in ('tests-r2.xml', 'downstream-tests.xml')]
assert sum(int(s.attrib['tests']) for s in suites) == 258
assert all(s.attrib[key] == '0' for s in suites for key in ('failures', 'errors', 'skipped'))
members, pins, weights = {}, {}, {}


def add(path, name):
    assert path.is_file() and not path.is_symlink(), path
    if name in members:
        assert sha(members[name]) == sha(path), name
    members[name] = path


def collect(value):
    if isinstance(value, list):
        for item in value:
            collect(item)
    elif isinstance(value, dict):
        for key, val in value.items():
            if isinstance(val, str) and len(val) == 64 and key.startswith(str(SOURCE) + '/'):
                path = Path(key)
                assert sha(path) == val, key
                rel = path.relative_to(SOURCE).as_posix()
                pins[rel] = val
                add(path, 'source/' + rel)
            elif key == 'producer_pins' and isinstance(val, dict):
                for module, digest in val.items():
                    if not module.startswith('ipfs_datasets_py.'):
                        continue
                    stem = SOURCE / module.replace('.', '/')
                    path = stem.with_suffix('.py')
                    if not path.is_file():
                        path = stem / '__init__.py'
                    assert sha(path) == digest, module
                    rel = path.relative_to(SOURCE).as_posix()
                    pins[rel] = digest
                    add(path, 'source/' + rel)
            collect(val)


for rel in owned:
    if rel.endswith('.py'):
        assert (ROOT / rel).read_bytes() == (SOURCE / rel).read_bytes(), rel
        add(SOURCE / rel, 'source/' + rel)
        pins[rel] = sha(SOURCE / rel)
    else:
        add(ROOT / rel, 'source/' + rel)
for path in RUN.iterdir():
    if path.is_file() and path.suffix in ('.log', '.xml', '.json', '.py') and path.name not in (
            'publication.json', 'owned-files.json'):
        add(path, 'validation/' + path.name)
for path in (RUN / 'comparison-r1').rglob('*'):
    if not path.is_file() or any(part in ('.lake', '.git', '__pycache__') for part in path.parts):
        continue
    rel = path.relative_to(RUN).as_posix()
    if 'checkpoint' in path.relative_to(RUN).parts:
        weights[rel] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    else:
        add(path, 'validation/' + rel)
    if path.suffix == '.json':
        collect(json.loads(path.read_text()))
for dirname in ('ui-decoder-fidelity-20261001', 'adaptive-family-development-20261001'):
    for path in (RUN.parent / dirname).iterdir():
        if path.is_file() and path.suffix in ('.json', '.xml', '.log', '.py'):
            add(path, 'supplemental/' + dirname + '/' + path.name)
for path in (RUN / 'pre-reporting-fix-source').rglob('*'):
    if path.is_file():
        add(path, 'validation/' + path.relative_to(RUN).as_posix())
source_regressions = {}
for dirname in ('source384-regression-r1', 'source384-regression-r2', 'source384-regression-r3'):
    folder = RUN / dirname
    for path in folder.rglob('*'):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        rel = path.relative_to(RUN).as_posix()
        if path.name == 'checkpoint.json':
            weights[rel] = {'sha256': sha(path), 'bytes': path.stat().st_size}
        else:
            add(path, 'validation/' + rel)
    summary_path = folder / 'summary.json'
    if summary_path.exists():
        regression = json.loads(summary_path.read_text())
        assert regression['all_inference_target_free'] and regression['source_unchanged']
        assert regression['parent_unchanged'] and regression['assets_unchanged']
        assert not regression['new_holdout'] and not regression['admitted']
        source_regressions[dirname] = regression
        executed = {item['path']: item['sha256'] for item in
                    json.loads((folder / 'source-manifest.json').read_text())['files']}
        for name, filename in json.loads((folder / 'loaded-modules.json').read_text()).items():
            path = Path(filename)
            rel = path.relative_to(SOURCE).as_posix()
            assert sha(path) == executed[rel], ('loaded_source_drift', dirname, rel)
            pins[rel] = executed[rel]
            add(path, 'source/' + rel)
for stem in ('autoencoder_family_training', 'autoencoder_family_training_prepared',
             'autoencoder_family_training_validated_v5', 'autoencoder_family_decoder_refinement',
             'resource_scheduler', 'domain_384_autoencoder', 'modal_latent_formula'):
    rel = 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/' + stem + '.py'
    pins[rel] = sha(SOURCE / rel)
    add(SOURCE / rel, 'source/' + rel)

native = []
for phase in ('development', 'heldout'):
    receipt = json.loads((RUN / 'comparison-r1' / phase / 'parallel-receipt.json').read_text())
    assert receipt['all_jobs_completed'] and receipt['scheduler_after']['active_lease_count'] == 0
    native.extend(row['native'] for row in receipt['jobs'] if 'native' in row)
sany = [check for row in native for projection in row['per_projection']
        for check in projection.get('additional_syntax_checks', [])]
assert all(check['executed'] and check['returncode'] == 0 for check in sany)
OUT.mkdir(parents=True, exist_ok=True)
results = {'schema': 'complete-feature-and-ui-fidelity-evidence/v1', 'tested_base_revision': base,
    'candidate_sha256': {rel: sha(ROOT / rel) for rel in owned},
    'tests': {'total': 258, 'suites': [dict(s.attrib) for s in suites]},
    'comparison': summary, 'actual_SANY_checks': len(sany),
    'execution_environment': json.loads((RUN / 'execution-environment.json').read_text()),
    'ui_wire_fidelity': json.loads((RUN.parent / 'ui-decoder-fidelity-20261001/before-after.json').read_text()),
    'common_support_coverage': json.loads((RUN / 'coverage-analysis.json').read_text()),
    'learned_source384_exposed_regressions': source_regressions,
    'source384_failed_attempt': json.loads((RUN / 'source384-retry.json').read_text()),
    'source384_extended_plan': json.loads((RUN / 'source384-extended-plan.json').read_text()),
    'local_generated_checkpoints_not_in_archive': weights,
    'native_checks_parallelized': True, 'numerical_fits_parallelized': False,
    'structural_experiment_source_decoder_trained': False,
    'admitted': False, 'constitution_formalized': False,
    'evidence_archive': 'evidence.tar.gz'}
dump(OUT / 'results.json', results)
add(OUT / 'results.json', 'results.json')
with tarfile.open(OUT / 'evidence.tar.gz', 'w:gz') as archive:
    for name, path in sorted(members.items()):
        archive.add(path, arcname=name, recursive=False)
manifest = {'schema': 'complete-feature-and-ui-fidelity-manifest/v1', 'tested_base_revision': base,
    'archive': {'path': 'evidence.tar.gz', 'sha256': sha(OUT / 'evidence.tar.gz'), 'bytes': (OUT / 'evidence.tar.gz').stat().st_size},
    'validated_producer_source_sha256': pins,
    'members': {name: {'sha256': sha(path), 'bytes': path.stat().st_size} for name, path in sorted(members.items())}}
dump(OUT / 'manifest.json', manifest)
dump(RUN / 'owned-files.json', owned + [(OUT / name).relative_to(ROOT).as_posix()
     for name in ('results.json', 'manifest.json', 'evidence.tar.gz')])
print(json.dumps({'archive_bytes': manifest['archive']['bytes'], 'members': len(members), 'producer_files': len(pins)}))
