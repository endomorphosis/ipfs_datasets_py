"""Independent saved-source/token arithmetic only; never imports model code."""
from pathlib import Path
import hashlib,json,math
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
O=R/'preparation-r2/results';artifacts={};checks=0
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def digest(value,ascii=False):return sha(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=ascii,allow_nan=False).encode())
def pin(path):
 path=Path(path).resolve();raw=path.read_bytes();artifacts[str(path)]={'sha256':sha(raw),'bytes':len(raw)};return raw
def load(path):return json.loads(pin(path))
def check(value,message):
 global checks
 checks+=1
 if not value:raise ValueError(message)
plan=load(O/'source-plan.json');hist=load(O/'historical8-production.json');new=load(O/'bounded768-production.json')
inputs=load(O/'dimension-inputs.json');summary=load(O/'summary.json');recipe=load(O/'sealed-recipe.json')
check(plan['plan_sha256']==digest({k:v for k,v in plan.items() if k!='plan_sha256'}),'plan content digest')
check(inputs['inputs_sha256']==digest({k:v for k,v in inputs.items() if k!='inputs_sha256'}),'complete input content digest')
check(inputs['plan_sha256']==hist['plan_sha256']==new['plan_sha256']==plan['plan_sha256'],'one unchanged plan')
check(inputs['historical8_production_sha256']==digest(hist) and inputs['bounded768_production_sha256']==digest(new),'production content pins')
check(plan['unique_sources']==239 and plan['cached768_sources']==167 and plan['missing768_sources']==72,'registered source reuse counts')
check(plan['paragraph_counts']=={'train':48,'validation':48} and plan['clause_counts']=={'train':113,'validation':54},'registered paragraph and clause splits')
check(len(plan['source_rows'])==239 and len({r['id'] for r in plan['source_rows']})==239,'unique source IDs')
for row in plan['source_rows']:check(set(row)=={'id','source_text'} and row['id']=='source:'+sha(row['source_text'].encode()),'source-only source-derived identity')
for path,wanted in hist['bundle']['producer_pins'].items():check(sha(pin(path))==wanted,'actual historical producer pin')
check(hist['bundle']['bundle_sha256']==digest({k:v for k,v in hist['bundle'].items() if k!='bundle_sha256'},True),'historical bundle content hash')
historical={}
for row,source,validated in zip(hist['bundle']['rows'],plan['source_rows'],hist['validated_rows']):
 check(row['id']==source['id']==validated['id'] and row['source_sha256']==sha(source['source_text'].encode()),'historical source binding')
 entry=row['stages']['historical_linguistic_features8'];receipt=entry['receipt'];vector=entry['vector']
 check(receipt['vector_sha256']==digest(vector,True) and receipt['receipt_sha256']==digest({k:v for k,v in receipt.items() if k!='receipt_sha256'},True),'historical vector and receipt hashes')
 check(receipt['evidence']['profile_id']=='legacy-linguistic-features-8d/v1' and receipt['evidence']['learned_reconstruction_checkpoint_used'] is False,'preserved source feature profile without teacher reconstruction')
 check(validated['vector']==vector and validated['receipt_sha256']==receipt['receipt_sha256'],'validated historical vectors')
 historical[row['id']]=vector
check(len(historical)==239 and len({digest(v) for v in historical.values()})==239,'all historical source vectors are distinct')
cache=load(plan['native768_report']['path']);check(artifacts[plan['native768_report']['path']]=={k:plan['native768_report'][k] for k in ('sha256','bytes')},'cached producer file pin')
check(new['implementation']==cache['implementation'],'cached and executed native producer bytes match')
for name,file in [('complete_loader','source_embeddings_768_complete.py'),('reference_producer','source_embeddings_768.py'),('asset_profile','gte_multilingual_profile.py')]:
 check(sha(pin(R/'experiment-source/ipfs_datasets_py/logic/formalization/autoencoder'/file))==new['implementation'][name],'native producer source '+name)
check(new['experiment_token_limit']==512 and new['historical_profile_token_limit']==8192 and new['cached_profile_relabelled'] is False,'current512 policy does not relabel historical8192 profile')
check(new['complete_checkpoint_loading']['tensor_count']==138 and new['complete_checkpoint_loading']['architecture']=='NewForTokenClassification','complete encoder/classifier loading')
check(all(new['complete_checkpoint_loading'][k]==[] for k in ('missing_keys','unexpected_keys','mismatched_keys','error_msgs')),'no ignored or missing tensors')
check(new['dense_path_verification']['encoder_and_complete_hidden_states_bitwise_equal'] is True,'retained first-source dense path probe')
source_rows=new['source_rows'];tokens=new['token_rows'];events=new['forward_observations'];schedule=[('complete',[0]),('encoder',[0])]+[('complete',list(range(i,min(i+4,72)))) for i in range(0,72,4)]
check(source_rows==plan['missing768_rows'] and len(tokens)==72 and len(events)==20,'complete new source and forward inventory')
for i,(event,(role,indices)) in enumerate(zip(events,schedule)):
 width=max(len(tokens[j]['input_ids']) for j in indices)
 check(event['index']==i and event['path']==role and event['batch_size']==len(indices) and event['padded_width']==width<=512,'actual complete/bare/batch schedule')
 for pos,j in enumerate(indices):
  expected=tokens[j]['input_ids'];source=source_rows[j]
  check(tokens[j]['attention_mask']==[1]*len(expected),'complete admitted token mask')
  check(event['attention_mask'][pos]==[1]*len(expected)+[0]*(width-len(expected)) and event['input_ids'][pos][:len(expected)]==expected,'actual forward active IDs and right-padding mask')
  check(event['sources'][pos]==dict(id=source['id'],source_sha256=sha(source['source_text'].encode()),active_token_count=len(expected),token_input_sha256=digest(expected)),'actual forward source/token pin')
native={identity:r['embedding'] for identity,r in plan['cached768'].items()}
for row,token,receipt in zip(source_rows,tokens,new['receipts']):
 check(receipt['id']==row['id'] and receipt['source_sha256']==sha(row['source_text'].encode()) and receipt['token_input_sha256']==digest(token['input_ids']),'new native receipt source/token binding')
 native[row['id']]=receipt['embedding']
check(set(native)==set(historical),'all dimensions have identical unique source inventory')
collisions={}
for dimension in (8,384,768):
 lane=inputs['dimensions'][str(dimension)];vectors_by_split={}
 check(lane['representation']['dimension']==dimension,'actual lane dimension')
 for split in ('train','validation'):
  check(len(lane[split])==48 and len(lane['clause_cache'][split])==(113 if split=='train' else 54),'lane paragraph/clause coverage')
  vectors_by_split[split]=set()
  for group,oldgroup in [(lane[split],plan['paragraph_rows384'][split]),(lane['clause_cache'][split],plan['clause_cache384'][split])]:
   for row,old in zip(group,oldgroup):
    check(set(row)=={'id','source_text','input'} and row['id']==old['id'] and row['source_text']==old['source_text'],'no targets and exact original row identities')
    vector=row['input'];expected=old['input'] if dimension==384 else (historical if dimension==8 else native)['source:'+sha(row['source_text'].encode())]
    check(vector==expected and len(vector)==dimension and all(type(v) is float and math.isfinite(v) for v in vector),'native dimension source vector exact')
    check(abs(math.fsum(v*v for v in vector)-1.)<=1e-4,'source vector native normalization retained')
    vectors_by_split[split].add(digest(vector))
  for row in lane[split]:
   desc=lane['source_contexts'][split][row['id']];segments=desc['segments']
   check(desc['source_sha256']==sha(row['source_text'].encode()) and '\n\n'.join(s['source_text'] for s in segments)==row['source_text'],'explicit source context order and hash')
   for segment in segments:check(segment['embedding_sha256']==digest(segment['vector']) and len(segment['vector'])==dimension,'clause vector hash and native dimension')
 collisions[str(dimension)]=len(vectors_by_split['train']&vectors_by_split['validation'])
 check(collisions[str(dimension)]==0,'no exact crosssplit vector collisions')
check(summary['complete'] is inputs['complete'] is True and summary['encoder_rows_executed']==72 and summary['historical_feature_rows_executed']==239,'complete execution summary')
for key in ('qualified','admitted','formalized','roundtrip_ok'):check(summary[key] is inputs[key] is False,'no authority from source production '+key)
pin(__file__)
result=dict(schema='dimension-source-preparation-observation-review/v1',complete=True,passed=True,check_count=checks,finding_count=0,findings=[],artifacts=artifacts,
 source_path=str(Path(__file__).resolve()),source_sha256=sha(Path(__file__).read_bytes()),
 measurements=dict(unique_sources=239,paragraphs=96,unique_clauses=167,cached_native768_sources=167,new_native768_sources=72,historical8_sources=239,
  native768_forward_calls=20,native768_sample_observations=74,native768_token_range=[min(len(t['input_ids']) for t in tokens),max(len(t['input_ids']) for t in tokens)],
  crosssplit_exact_vector_collisions=collisions,preparation_elapsed_seconds=summary['elapsed_seconds'],native768_producer_seconds=new['elapsed_seconds'],historical8_producer_seconds=hist['elapsed_seconds']),
 authority=dict(model_execution_by_review=False,encoder_execution_by_review=False,training_execution=False,qualified=False,admitted=False,lake_executed=False),
 scope='Saved byte/source/token arithmetic, not independent rerun of embedding numerics or semantic qualification')
(R/'source-preparation-observation-review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':True,'checks':checks,'receipt_sha256':sha((R/'source-preparation-observation-review.json').read_bytes())}))
