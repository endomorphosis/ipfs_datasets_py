"""Check the native-dimension study's claims against saved evidence; no model calls."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

R = Path(__file__).resolve().parent
P = R.parents[2]
DOC = P / 'docs/autoencoders/decoder_length_distillation.md'
HEADING = '## Native 8D, 384D and 768D formula sidecars (2026-10-03)'
artifacts, checks = {}, []


def bind(path):
    path = Path(path); raw = path.read_bytes()
    artifacts[str(path)] = dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
    return raw


def read(path):
    return json.loads(bind(path))


def check(name, value):
    checks.append(dict(name=name,passed=bool(value)))


raw = bind(DOC); full = raw.decode(); section = full.split(HEADING)[-1]
check('one appended study heading', full.count(HEADING)==1)
outcome = read(R/'training-outcome-review.json')
check('clean independent outcome review', outcome['passed'] is True and outcome['findings']==[])
runs = {r['arm']:r for r in outcome['runs']}
for dimension in (8,384,768):
    for seed in (1729,2718):
        pair=[runs[f'{dimension}-{name}-{seed}'] for name in ('pooled','clauses')]
        values=[x['roles']['last-attempt']['validation'] for x in pair]
        row=(f"| {dimension} | {seed} | {values[0]['sequence_cross_entropy']:.6f} → {values[1]['sequence_cross_entropy']:.6f} | "
            f"{values[0]['generated_scalar_matches']} → {values[1]['generated_scalar_matches']} | "
            f"{values[0]['generated']['ordered_exact']} → {values[1]['generated']['ordered_exact']} |")
        check(f'quality table {dimension}/{seed}', row in section)
        row=(f"| {dimension} | {seed} | {pair[0]['fit_call_wall_seconds']:.3f} → {pair[1]['fit_call_wall_seconds']:.3f} | "
            f"{values[0]['numerical_evaluation_seconds_per_span']:.6f} → {values[1]['numerical_evaluation_seconds_per_span']:.6f} |")
        check(f'timing table {dimension}/{seed}', row in section)
        check(f'paired direction {dimension}/{seed}', values[1]['sequence_cross_entropy']<values[0]['sequence_cross_entropy']
            and values[1]['generated_scalar_matches']>values[0]['generated_scalar_matches'])
check('all twelve epoch0, no multiple-clause exact', all(r['selected_epoch']==0 and
    all(r['roles']['last-attempt']['validation']['by_length'][str(n)]['generated']['ordered_exact']==0 for n in (2,4,8))
    for r in runs.values()))
best=runs['768-clauses-2718']['roles']['last-attempt']; validation=best['validation']
check('best exact, raw auxiliary and unequal fields', validation['generated_scalar_matches']==528
    and validation['raw_auxiliary_scalar_matches']==536 and validation['generated']['ordered_exact']==2
    and best['training']['generated']['ordered_exact']==34
    and [validation['generated_scalar_fields'][k]['correct'] for k in ('actor','action','modality','object')]==[144,44,167,173])
check('best actual negative controls', [best[k]['generated_scalar_matches'] for k in
    ('source-shuffle','context-only-shuffle','context-reverse','context-rotate','zero-condition')]==[220,222,207,215,155])
check('best remaining whole-rule defects', [validation['generated'][k] for k in
    ('whole_rules_missing','whole_rules_extra','duplicate_rules')]==[154,179,27])
panel=read(R/'training-r1/results/768-clauses-2718/last-attempt/evaluation-validation.json')
eight=[r for r in panel['source_fidelity']['rows'] if r['clause_count']==8]
check('each eight-clause generated count/syntax and ordered actions', len(eight)==12
    and all(r['counts']['generated_rules']==8 and r['counts']['syntax_valid']==1 for r in eight)
    and sum(r['by_facet']['action']['correct'] for r in eight)==23)
learning={}; first_reduced_update={}
for arm in runs:
    report=read(R/'training-r1/results'/arm/'training.json')
    learning[arm]=sorted({h['learning_rate'] for h in report['history']})
    reduced=next((u for u in report['committed_updates'] if u['learning_rate']==.0005),None)
    if reduced is not None:
        first_reduced_update[arm]={k:reduced[k] for k in ('epoch','optimizer_step','learning_rate')}
check('adaptive learning rate correctly disclosed', 'learning rate remains 0.001' not in section
    and '0.0005' in section and '0.001' in section
    and sum(values==[.0005,.001] for values in learning.values())==6)
check('reduced rate first used in committed epoch21', 'after epoch 20' in section and 'epoch 21' in section
    and len(first_reduced_update)==6
    and all(v==dict(epoch=21,optimizer_step=41,learning_rate=.0005) for v in first_reduced_update.values()))
check('epoch0 is not presented as a usable fallback', 'epoch 0' in section
    and 'zero syntax-valid documents and zero' in section
    and 'does not yield a usable' in section and '48' in section)
for dimension in (8,384,768):
    counts=[runs[f'{dimension}-{name}-1729']['trainable_parameter_count'] for name in ('pooled','clauses')]
    check(f'parameter counts {dimension}', f'{counts[0]:,}/{counts[1]:,}' in section)
manifest=read(R/'training-manifest.json')
prep=read(manifest['preparation_summary']);native=read(manifest['bounded768_report']);historical=read(manifest['historical8_report'])
check('preparation rounded timing claims', all(f'{value:.3f}' in section for value in
    (prep['elapsed_seconds'],native['elapsed_seconds'],historical['elapsed_seconds'])))
check('native actual token and dense probe observations',
    (min(len(r['input_ids']) for r in native['token_rows']),max(len(r['input_ids']) for r in native['token_rows']))==(19,87)
    and native['complete_checkpoint_loading']['tensor_count']==138
    and native['dense_path_verification']['encoder_and_complete_hidden_states_bitwise_equal'] is True)
for attempt,memory,storage in [('preparation-r2',8192,500000000),('training-r1',4096,1500000000)]:
    resource=read(R/attempt/'resources-final.json')['record']
    check(attempt+'/resource policy and release', resource['status']=='released' and resource['memory_mb']==memory
        and resource['storage_bytes']==storage and resource['cpu_slots']==resource['child_process_slots']==1
        and resource['final_accounting']['limit_bytes']==140000000000)
test_counts={}
for name in ('tests-frozen.xml','tests-scoped.xml'):
    root=ET.fromstring(bind(R/name))
    test_counts[name]={k:sum(int(x.get(k,0)) for x in root.iter('testsuite')) for k in ('tests','errors','failures','skipped')}
check('retained full attempt and passing scoped counts', test_counts=={
    'tests-frozen.xml':dict(tests=2135,errors=16,failures=0,skipped=0),
    'tests-scoped.xml':dict(tests=2119,errors=0,failures=0,skipped=0)})
audit=read(R/'independent-audit.json')
check('independent full saved audit clean',audit['passed'] is True and audit['findings']==[] and audit['checks']==110764)
bind(R/'write_documentation.py');bind(R/'documentation-edit.json');bind(Path(__file__))
findings=[x['name'] for x in checks if not x['passed']]
receipt=dict(schema='native-dimension-documentation-review/v1',complete=True,passed=not findings,
    findings=findings,finding_count=len(findings),document_sha256=hashlib.sha256(raw).hexdigest(),
    document_path=str(DOC),reviewed_heading=HEADING,checks=checks,artifacts=artifacts,
    observed_learning_rates=learning,first_reduced_committed_update=first_reduced_update,test_counts=test_counts,
    manual_review=['Generated quality and teacher-forced auxiliary scores are distinguished; all192controls and36states are described without admission authority.',
        'Native8 linguistic feature sidecar is separated from the preserved sparse teacher; source resets and identity projection prevent learned-reconstruction or dimension-only claims.',
        'Fresh holdouts, convergence, Lake, logic-family and Constitution success are explicitly unclaimed.',
        'Timing scopes identify cached decoder inputs, separate local encoder work, one CPU worker, no bridges/provers, and whole-fit/evaluation overhead.',
        'The full16-error fixture attempt remains visible; the scoped rerun does not claim to repair or validate that unused package path.',
        'Published artifact links target the prepared evidence location; packaging and remote publication are later separate actions.'],
    model_executed=False,training_executed=False,encoder_executed=False,admitted=False,qualified=False,lake_executed=False)
(R/'documentation-review.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=not findings,checks=len(checks),findings=findings,document_sha256=receipt['document_sha256'])))
raise SystemExit(bool(findings))
