"""Read-only source/preparation review; no package imports or model execution."""
from pathlib import Path
import ast,hashlib,json,subprocess,xml.etree.ElementTree as ET
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
F=R/'experiment-source'
artifacts={};checks=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
 path=Path(path).resolve();raw=path.read_bytes();artifacts[str(path)]={'sha256':sha(raw),'bytes':len(raw)};return raw
def check(condition,label):
 checks.append({'check':label,'passed':bool(condition)})
 if not condition:raise ValueError(label)
def load(path):return json.loads(pin(path))
base=load(R/'base.json')['base']
ready=load(R/'source-preparation-ready.json')
for rel,digest in ready['files'].items():
 check(sha(pin(P/rel))==sha(pin(F/rel))==digest,'source owner frozen and unchanged '+rel)
prep='scripts/ops/autoencoder/prepare_native_dimension_source_inputs.py'
manifest=load(R/'preparation-manifest.json');plan=load(R/'preparation-plan.json')
check(sha(pin(F/prep))==manifest['extensions'][prep],'preparation runner frozen hash')
check(sha(pin(R/'preparation-plan.json'))==manifest['plan_sha256'],'preparation plan hash')
check(plan['dimensions']==[8,384,768] and type(plan['max_tokens']) is int and plan['max_tokens']==512
 and plan['max_seconds']==600 and plan['batch_size']==4 and plan['weight_downloads'] is False
 and plan['source_only'] is True,'closed experiment policy remains source-only and bounded')
for key in ('parent_manifest','parent_plan','native768_report','asset_manifest'):
 path=Path(manifest[key]);check(sha(pin(path))==manifest['inputs'][str(path)],'exact alias '+key)
# Every dependency used by historical_features is already the frozen published source.
names=['autoencoder_embedding_production','autoencoder_embedding_runtime','legal_samples','legal_modal_parser',
 'modal_ir','frame_bm25_selector','modal_joint_formula','modal_latent_formula']
rels=['ipfs_datasets_py/optimizers/logic_theorem_optimizer/'+name+'.py' for name in names]
rels+=['ipfs_datasets_py/logic/formalization/autoencoder/legal_384_package.py',
 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_lineages/legacy_v1/linguistic.py',
 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_lineages/legacy_v1/__init__.py',
 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_lineages/_contract.py']
legacy=Path('ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_lineages/legacy_v1')
for sub in ('_snapshot','_linguistic_snapshot'):
 rels += [str(f.relative_to(S)) for f in sorted((S/legacy/sub).glob('*')) if f.suffix in ('.py','.json')]
for rel in rels:
 actual=pin(S/rel);published=subprocess.check_output(['git','show',base+':'+rel],cwd=P)
 check(actual==published,'frozen historical dependency equals publication base '+rel)
check(len(rels)==40,'complete direct and snapshot historical closure')
profile=ast.parse((S/legacy/'linguistic.py').read_text())
profiles=[ast.literal_eval(node.value) for node in profile.body if isinstance(node,ast.Assign)
 and any(isinstance(target,ast.Name) and target.id=='PROFILE_ID' for target in node.targets)]
check(profiles==['legacy-linguistic-features-8d/v1'],'literal historical8 profile is exact')
native=load(manifest['native768_report']);expected={}
for name,filename in [('complete_loader','source_embeddings_768_complete.py'),('reference_producer','source_embeddings_768.py'),('asset_profile','gte_multilingual_profile.py')]:
 rel='ipfs_datasets_py/logic/formalization/autoencoder/'+filename
 expected[name]=sha(pin(F/rel));check(expected[name]==manifest['extensions'][rel],'frozen native producer '+name)
check(native['implementation']==expected,'cached native production uses exact unchanged producers')
# Observe the prior suite failure exactly; no old package mutation/rebinding or test weakening.
full=ET.fromstring(pin(R/'tests-frozen.xml'));scoped=ET.fromstring(pin(R/'tests-scoped.xml'))
failed=[n for n in full.iter('testcase') if n.find('error') is not None or n.find('failure') is not None]
passed_full=[n for n in full.iter('testcase') if n.find('error') is None and n.find('failure') is None and n.find('skipped') is None]
check(len(failed)==16 and len(passed_full)==2119,'original suite retains2119 passes and16 setup errors')
check(all(n.find('error') is not None and 'Legal package core/source binding differs' in n.find('error').text for n in failed),
 'all16 errors have same strict retained384 fixture binding rejection')
check(all('test_legal_native_conditioning' in n.attrib.get('classname','') for n in failed),'all setup errors are scoped to unused retained384 fixture')
scoped_cases=list(scoped.iter('testcase'))
check(len(scoped_cases)==2119 and not any(n.find('error') is not None or n.find('failure') is not None for n in scoped_cases),
 'explicit study test scope2119 passes')
check(any(n.attrib['name']=='test_historical8_uses_real_feature_profile_without_reconstruction' for n in scoped_cases),
 'actual preserved historical8 source producer tested')
fixture_path=F/'tests/unit/logic/test_legal_native_conditioning.py';pin(fixture_path)
package_path=Path('/home/barberb/lift_coding/artifacts/ir-384-hub-release-20261002/packages/legal_ir/checkpoint.json')
package=load(package_path)
check(artifacts[str(package_path)]['sha256']=='26cb6d77947b5b8e1e6c08e68ff8c6ce1c8f23002d56bfc1ebbd024c55a0c2da','original retained384 package remains exact pinned bytes')
check(package['core_binding']['core_sha256']=='856a5e18c70745d9a5fe7c13f5bf29b9f3a5423384d4980bd6000ec07dc74eb5',
 'historical retained384 expected source/state/config binding')
core_sources={}
for rel in ['modal_autoencoder.py','modal_joint_formula.py','autoencoder_lineages/_contract.py','autoencoder_lineages/current_v2/__init__.py']:
 path=S/'ipfs_datasets_py/optimizers/logic_theorem_optimizer'/rel
 core_sources[rel]=sha(pin(path))
 check(pin(path)==subprocess.check_output(['git','show',base+':'+str(path.relative_to(S))],cwd=P),'actual retained384 core source equals validated base '+rel)
pin(R/'test-import-provenance.json');pin(R/'test-import-provenance-scoped.json');pin(R/'run_frozen_tests.py')
pin(F/'ipfs_datasets_py/logic/formalization/autoencoder/legal_native_conditioning.py')
pin(__file__)
result=dict(schema='dimension-source-preparation-static-review/v1',complete=True,passed=True,
 check_count=len(checks),finding_count=0,findings=[],checks=checks,artifacts=artifacts,
 source_path=str(Path(__file__).resolve()),source_sha256=sha(Path(__file__).read_bytes()),
 historical_dependency_files=40,expected_native_producer_hashes=expected,
 fixture_diagnosis=dict(full_suite_passed=2119,full_suite_setup_errors=16,scoped_suite_passed=2119,
  failed_nodes=[n.attrib['name'] for n in failed],retained_checkpoint=str(package_path),
  expected_core_binding=package['core_binding'],frozen_core_source_sha256=core_sources,
  observed_failure='Saved aggregate core state/configuration/source binding differs under frozen runtime; guard rejects before projection.',
  constituent_cause_isolated=False,actual_aggregate_digest_captured=False,
  scope='retained384 vectorize tests are outside this study; historical8_features path neither loads this package nor invokes vectorize',
  original_test_source_changed=False,original_checkpoint_changed=False,guard_weakened=False,
  numerical_native384_package_compatibility_claimed=False),
 authority=dict(model_execution=False,encoder_execution=False,training_execution=False,
  downloads=False,qualified=False,admitted=False,lake_executed=False),
 scope='Static source/receipt review and observation of existing test evidence; no new model execution')
(R/'source-preparation-static-review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':True,'checks':len(checks),'receipt_sha256':sha((R/'source-preparation-static-review.json').read_bytes()),'source_sha256':result['source_sha256']}))
