"""Freeze bounded native-source preparation and the matched twelve-fit experiment."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
O=P/'workspace/test-logs/decoder-clause-context-training-20261003'
BASE=json.loads((R/'base.json').read_bytes())['base']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):(R/name).write_text(json.dumps(obj,indent=2)+'\n')
def gitbytes(rel):return subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)
def mod(path):
 spec=importlib.util.spec_from_file_location('_native_freeze_'+path.stem,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
if __name__=='__main__':
 assert not (R/'experiment-source').exists()
 auto='ipfs_datasets_py/logic/formalization/autoencoder/'
 changes=[auto+n+'.py' for n in ('dimension_source_inputs','dimension_native_decoder_experiment',
  'legal_native_conditioning','source_embeddings_768','source_embeddings_768_complete','gte_multilingual_profile')]
 changes += ['scripts/ops/autoencoder/'+n+'.py' for n in ('benchmark_native_dimension_source_training','prepare_native_dimension_source_inputs')]
 changes += ['tests/unit/logic/formalization/autoencoder/test_'+n+'.py' for n in
  ('dimension_source_inputs','dimension_native_decoder_experiment','native_dimension_source_training_runner',
   'source_embeddings_768','source_embeddings_768_complete','gte_multilingual_profile')]
 changes += ['tests/unit/logic/test_legal_native_conditioning.py']
 additions={rel:sha(P/rel) for rel in changes}
 pins=json.loads((O/'frozen-extensions.json').read_bytes());tests=json.loads((O/'validated-test-source.json').read_bytes())
 helpers=json.loads((O/'test-helper-sources.json').read_bytes())
 for rel,digest in {**pins,**tests,**helpers}.items():
  assert sha(O/'experiment-source'/rel)==digest,rel
  assert hashlib.sha256(gitbytes(rel)).hexdigest()==digest,rel
 for rel,digest in additions.items():(tests if rel.startswith('tests/') else pins)[rel]=digest
 for rel,digest in {**pins,**tests,**helpers}.items():
  source=P/rel if rel in additions else O/'experiment-source'/rel
  target=R/'experiment-source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(source,target);assert sha(target)==digest
 save('frozen-extensions.json',pins);save('validated-test-source.json',tests);save('test-helper-sources.json',helpers)
 save('test-files.json',list(tests));save('code-files.json',changes+['configs/autoencoders/gte_multilingual_local_assets_v1.json','docs/autoencoders/decoder_length_distillation.md'])
 manifest=json.loads((O/'training-manifest.json').read_bytes())
 for path,digest in manifest['inputs'].items():assert sha(path)==digest,path
 native=Path('/home/barberb/lift_coding/artifacts/legal-decoder-native-conditioning-20261002/native768')
 paths=dict(parent_manifest=O/'training-manifest.json',parent_plan=O/'training-plan.json',
  native768_report=native/'embeddings-complete/producer-report.json',asset_manifest=P/'configs/autoencoders/gte_multilingual_local_assets_v1.json')
 for key,path in paths.items():
  manifest[key]=str(path);manifest['inputs'][str(path)]=sha(path)
 assets=json.loads(paths['asset_manifest'].read_bytes())
 manifest['model_directory']=str(native/'assets/model');manifest['code_directory']=str(native/'assets/code')
 for asset in assets['files']:
  path=native/'assets'/asset['relative_to']/asset['path']
  assert path.stat().st_size==asset['bytes'] and sha(path)==asset['sha256']
  manifest['inputs'][str(path)]=asset['sha256']
 manifest['extensions']=pins
 module=mod(R/'experiment-source/scripts/ops/autoencoder/prepare_native_dimension_source_inputs.py')
 save('preparation-plan.json',dict(module.FIXED,input_sha256=manifest['inputs']))
 manifest['plan_sha256']=sha(R/'preparation-plan.json');save('preparation-manifest.json',manifest)
 (R/'run_frozen_tests.py').write_bytes((O/'run_frozen_tests.py').read_bytes())
 guardian=(O/'run_training_reserved.py').read_text().replace("choices=('training',)","choices=('preparation','training')")
 guardian=guardian.replace('storage_bytes=800_000_000,\n        memory_mb=4096','storage_bytes=storage_bytes,\n        memory_mb=memory_mb')
 guardian=guardian.replace('    owner = resources.DaemonResourceReservation',"    storage_bytes=500_000_000 if args.phase=='preparation' else 1_500_000_000\n    memory_mb=8192 if args.phase=='preparation' else 4096\n    owner = resources.DaemonResourceReservation")
 guardian=guardian.replace("RUN/'experiment-source/scripts/ops/autoencoder/benchmark_clause_context_source_training.py'", "RUN/'experiment-source/scripts/ops/autoencoder'/('prepare_native_dimension_source_inputs.py' if args.phase=='preparation' else 'benchmark_native_dimension_source_training.py')")
 guardian=guardian.replace("'outer_memory_mb': 4096", "'outer_memory_mb': memory_mb").replace("'storage_bytes': 800_000_000", "'storage_bytes': storage_bytes")
 guardian=guardian.replace('bounded numerical training only; no native admission','bounded local preparation or numerical training; no qualification authority')
 (R/'run_training_reserved.py').write_text(guardian)
 (R/'adopt_shared_scheduler.py').write_bytes((O/'adopt_shared_scheduler.py').read_bytes())
 print(json.dumps(dict(extensions=len(pins),test_files=len(tests),inputs=len(manifest['inputs']))))
