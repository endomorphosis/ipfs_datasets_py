"""Final training source closure; no models, mutation of earlier receipts or Git writes."""
from pathlib import Path
import hashlib,json,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2';F=R/'experiment-source'
artifacts={};checks=0;findings=[]
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def pin(path):
 path=Path(path).resolve();raw=path.read_bytes();artifacts[str(path)]={'sha256':sha(raw),'bytes':len(raw)};return raw
def load(path):return json.loads(pin(path))
def check(value,label):
 global checks
 checks+=1
 if not value:findings.append(label)
def git(*args):return subprocess.run(['git',*args],cwd=P,capture_output=True)
old=load(R/'source-publication-compatibility.json');static=load(R/'source-preparation-static-review.json')
summary=load(R/'training-r1/results/summary.json');audit=load(R/'independent-audit.json')
base=old['publication_base'];union=dict(old['validated_producer_source_sha256']);extras={}
check(old['passed'] is True and old['finding_count']==0,'earlier preparation/publication source review passed')
check(summary['complete'] is True and len(summary['runs'])==12,'all twelve training fits complete')
check(audit['passed'] is True and audit['finding_count']==0 and audit['checks']==110764,'final numerical audit passed')
for scoped,digest in summary['source_dependencies'].items():
 scope,sep,rel=scoped.partition(':');check(sep==':' and scope in ('extension','dependency'),'known training provenance '+scoped)
 check(union.get(rel)==digest,'training producer already in reviewed source union '+rel)
 check(sha(pin((F if scope=='extension' else S)/rel))==digest,'actual frozen training producer unchanged '+rel)
for name,expected in static['artifacts'].items():
 path=Path(name)
 if not path.is_relative_to(S):continue
 rel=path.relative_to(S).as_posix();check(sha(pin(path))==expected['sha256'],'retained historical static dependency unchanged '+rel)
 check(rel not in union or union[rel]==expected['sha256'],'consistent historical source pin '+rel)
 if rel not in union:extras[rel]=expected['sha256']
 union[rel]=expected['sha256']
comparisons={};differences=[]
for rel,digest in sorted(union.items()):
 before=git('show',base+':'+rel);oldsha=None if before.returncode else sha(before.stdout)
 status='absent_from_base' if oldsha is None else 'identical' if oldsha==digest else 'different_from_base'
 comparisons[rel]=dict(expected_sha256=digest,base_sha256=oldsha,status=status)
 if status!='identical':differences.append(rel)
 check(status=='identical' or rel in old['intentional_unpublished_producers'],'only intended publication source changes '+rel)
check(set(differences)==set(old['intentional_unpublished_producers']),'unchanged eight intentional new producer paths')
check(len(union)==165 and len(extras)==15,'complete publication closure count including frozen historical manifests')
# Preserve final audit bindings; don't claim metadata export or upload has occurred.
pin(__file__)
result=dict(schema='native-dimension-training-source-publication-review/v1',complete=True,passed=not findings,
 checks=checks,finding_count=len(findings),findings=findings,publication_base=base,
 prior_review_producers=150,actual_training_producer_count=len(summary['source_dependencies']),
 new_training_producers=[],changed_training_producers=[],additional_historical_closure_sha256=extras,
 final_expected_producer_count=len(union),existing_base_identical_count=len(union)-len(differences),
 intentional_unpublished_producers=sorted(differences),unrelated_producer_changes=[],
 validated_producer_source_sha256=dict(sorted(union.items())),base_comparisons=comparisons,
 artifacts=artifacts,source_path=str(Path(__file__).resolve()),source_sha256=sha(Path(__file__).read_bytes()),
 sealed_manifest_observed=False,publication_performed=False,remote_fetched=False,
 scope='Final training import union plus complete historical source closure. Exact future sealed manifest must equal these165pins; remote currentness belongs to root publication review.',
 model_execution=False,source_edits=False,qualified=False,admitted=False)
(R/'source-publication-training-review.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'passed':not findings,'checks':checks,'source_count':len(union),'receipt_sha256':sha((R/'source-publication-training-review.json').read_bytes())}))
if findings:raise SystemExit(1)
