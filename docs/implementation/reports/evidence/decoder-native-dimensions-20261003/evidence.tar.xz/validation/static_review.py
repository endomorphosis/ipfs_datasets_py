"""Read-only native-dimension integration/guardian review; never execute models."""
import ast
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

R = Path(__file__).resolve().parent
P = R.parents[2]
OLD = P / 'workspace/test-logs/decoder-clause-context-training-20261003'
SOURCE = R / 'experiment-source'
S = P / 'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
AUTO = 'ipfs_datasets_py/logic/formalization/autoencoder/'
artifacts, checks = {}, []


def bind(path):
    path = Path(path)
    raw = path.read_bytes()
    artifacts[str(path)] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
    return raw


def check(name, condition):
    checks.append(dict(name=name, passed=bool(condition)))


pins = json.loads(bind(R / 'frozen-extensions.json'))
tests = json.loads(bind(R / 'validated-test-source.json'))
helpers = json.loads(bind(R / 'test-helper-sources.json'))
for rel, digest in {**pins, **tests, **helpers}.items():
    check('frozen bytes: ' + rel, hashlib.sha256(bind(SOURCE / rel)).hexdigest() == digest)

protected = ['decoder_distillation_experiment', 'decoder_distillation_experiment_v2',
    'long_span_source_value_training', 'long_span_count_exposure_training', 'decoder_source_fidelity',
    'clause_source_controls', 'clause_source_context', 'clause_source_decoder_experiment',
    'projected_source_decoder_experiment', 'shared_slot_source_decoder_experiment']
for module in protected:
    rel = AUTO + module + '.py'
    check('entire prior source unchanged: ' + module,
        bind(SOURCE / rel) == bind(OLD / 'experiment-source' / rel))
rel = 'scripts/ops/autoencoder/benchmark_clause_context_source_training.py'
check('entire reused trainer/control runner unchanged', bind(SOURCE / rel) == bind(OLD / 'experiment-source' / rel))

for rel in [AUTO+'dimension_native_decoder_experiment.py', AUTO+'dimension_source_inputs.py',
    'scripts/ops/autoencoder/benchmark_native_dimension_source_training.py',
    'scripts/ops/autoencoder/prepare_native_dimension_source_inputs.py',
    'tests/unit/logic/formalization/autoencoder/test_native_dimension_source_training_runner.py']:
    check('reviewed live/frozen bytes equal: '+rel, bind(P / rel) == bind(SOURCE / rel))

# This is the complete, explicitly reviewed guardian delta, not a permissive AST mask.
old_guard = bind(OLD / 'run_training_reserved.py').decode()
expected = old_guard.replace("choices=('training',)", "choices=('preparation','training')")
expected = expected.replace('storage_bytes=800_000_000,\n        memory_mb=4096',
    'storage_bytes=storage_bytes,\n        memory_mb=memory_mb')
expected = expected.replace('    owner = resources.DaemonResourceReservation',
    "    storage_bytes=500_000_000 if args.phase=='preparation' else 1_500_000_000\n"
    "    memory_mb=8192 if args.phase=='preparation' else 4096\n"
    '    owner = resources.DaemonResourceReservation')
expected = expected.replace("RUN/'experiment-source/scripts/ops/autoencoder/benchmark_clause_context_source_training.py'",
    "RUN/'experiment-source/scripts/ops/autoencoder'/('prepare_native_dimension_source_inputs.py' if args.phase=='preparation' else 'benchmark_native_dimension_source_training.py')")
expected = expected.replace("'outer_memory_mb': 4096", "'outer_memory_mb': memory_mb")
expected = expected.replace("'storage_bytes': 800_000_000", "'storage_bytes': storage_bytes")
expected = expected.replace('bounded numerical training only; no native admission',
    'bounded local preparation or numerical training; no qualification authority')
check('guardian differs only in two phases, exact reservations, script and truthful scope',
    bind(R / 'run_training_reserved.py').decode() == expected)
check('unchanged shared-scheduler adoption helper', bind(R / 'adopt_shared_scheduler.py') == bind(OLD / 'adopt_shared_scheduler.py'))
harness = bind(OLD / 'run_frozen_tests.py').decode()
harness = harness.replace("args=[str(R/'experiment-source'/name) for name in tests]",
    "scoped='--scoped' in sys.argv\n"
    "args=[str(R/'experiment-source'/name)+(\n"
    "    '::test_historical8_uses_real_feature_profile_without_reconstruction'\n"
    "    if scoped and name=='tests/unit/logic/test_legal_native_conditioning.py' else '') for name in tests]")
harness = harness.replace("str(R/'tests-frozen.xml')", "str(R/('tests-scoped.xml' if scoped else 'tests-frozen.xml'))")
harness = harness.replace("(R/'test-import-provenance.json')", "(R/('test-import-provenance-scoped.json' if scoped else 'test-import-provenance.json'))")
check('test harness changes only explicit legacy fixture test scope and output filenames',
    bind(R / 'run_frozen_tests.py').decode() == harness)
resource_source = bind(S / 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py')
resource_ast = ast.parse(resource_source)
cap = [node.value.value for node in resource_ast.body if isinstance(node, ast.Assign)
    and any(isinstance(target, ast.Name) and target.id == 'MAX_STORAGE_BYTES' for target in node.targets)]
check('existing 140GB campaign cap retained', cap == [140_000_000_000])

manifest = json.loads(bind(R / 'preparation-manifest.json'))
plan_raw = bind(R / 'preparation-plan.json')
plan = json.loads(plan_raw)
check('preparation plan hash and complete input inventory bound',
    hashlib.sha256(plan_raw).hexdigest() == manifest['plan_sha256'] and plan['input_sha256'] == manifest['inputs'])
check('preparation aliases point to exact bound paths', all(str(Path(manifest[key]).resolve()) in manifest['inputs']
    for key in ('parent_manifest', 'parent_plan', 'native768_report', 'asset_manifest')))
check('preparation retains 512-token local-only source policy', plan['max_tokens'] == 512
    and plan['max_seconds'] == 600 and plan['batch_size'] == 4 and plan['weight_downloads'] is False
    and plan['source_only'] is True and plan['dimensions'] == [8, 384, 768])

for path in [R / 'freeze.py', R / 'native-model-ready.json', R / 'source-preparation-ready.json',
    R / 'scheduler-read-only-compatibility.json', Path(__file__)]:
    bind(path)
xml = ET.fromstring(bind(R / 'runner-contract-tests.xml'))
counts = {field: sum(int(suite.attrib.get(field, 0)) for suite in xml.iter('testsuite'))
    for field in ('tests', 'failures', 'errors', 'skipped')}
check('all seventy synthetic runner contracts pass', counts == dict(tests=70, failures=0, errors=0, skipped=0))
findings = [item['name'] for item in checks if not item['passed']]
receipt = dict(schema='native-dimension-static-review/v1', complete=True, passed=not findings,
    finding_count=len(findings), findings=findings, checks=checks, artifacts=artifacts,
    synthetic_tests=counts, full_suite_scope='separate frozen-suite receipt; not counted or executed by this review',
    reused_scheduler_tests_scope='historical unchanged helper verification plus current read-only configuration validation; no new scheduler test execution claimed',
    manual_review=[
        'The complete core, optimizer, loss, deadline-before-step, exposure accounting, strict selection and fidelity/control implementation bytes match the published clause experiment.',
        'All twelve candidates use native8/384/768 input and projected widths; the learned linguistic8 teacher is untouched. The8D lane is a new learned-formula sidecar using the preserved source-only feature producer.',
        'The new raw body copies source-independent GRU, token embeddings and output tensors/trainability; source conditioning starts at zero. Persistent source injection and both scalar readouts start source-neutral.',
        'Frozen zero projection-up makes reconstruction identity by construction; every public recipe states this is not learned reconstruction. Different input producers and source resets prevent a dimension-only causal claim.',
        'Both paired heads share initial parameters after explicit renaming; only the512 slot-embedding parameters are absent from the clause head. Inherited buffers and full96-source initial greedy outputs are checked for each candidate and across all12.',
        'Count prior, raw source normalization, projected paragraph normalization and113unique clause normalization use training sources only; validation54clauses are exclusions. Exact vector/source split collisions abort; no perturbation or repair is allowed.',
        'Generated inputs remain source-only; target attachment occurs after producer output validation. All eight controls reuse the reviewed explicit paragraph/context assignment implementation and original recipient reference labels.',
        'Existing native768 cache retains its historical8192-capacity profile, while reused receipt lengths and every new actual complete/bare/batch forward are admitted at512tokens. Saved token IDs/masks and schedule are independently replayable.',
        'The source producer loads already-local authenticated complete768assets, checks all state keys and classifier tensors, preserves original384views, and records all239historical feature inputs. No downloads or new context window are requested.',
        'Aliases and exact source bytes are hash-bound before loading. State reload first preflights the raw native frozen projection, then restores typed wrapper buffers and checks tensor digest; postfit state digests must match trainer reports.',
        'Guardian retains owner identity/group cleanup, disk accounting, cooperative child limits and failure retention. Only explicit preparation500MB/8GiB and training1.5GB/4GiB reservations differ;1CPU,1child,300second admission and3000second outer deadline remain.',
        'The first preparation attempt refused a transient scheduler-key mismatch before reservation/model creation. Current read-only validation confirms exact existing19-key configuration; the fail-closed helper is unchanged and no shared state migration/reset was attempted.',
        'Full frozen test results retain16 setup errors for an unavailable legacy384 package fixture. The explicitly scoped rerun selects only the historical8 source producer test in that one file; all other frozen tests and protected import checks remain enabled. It does not claim those16 fixture tests passed.',
    ], model_executed=False, training_executed=False, encoder_executed=False,
    qualified=False, admitted=False, lake_executed=False, convergence_proven=False)
(R / 'static-review.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps(dict(passed=receipt['passed'], check_count=len(checks), findings=findings, synthetic_tests=counts)))
raise SystemExit(bool(findings))
