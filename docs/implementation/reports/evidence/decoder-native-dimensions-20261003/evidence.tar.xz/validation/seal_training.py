"""Seal successful exact-source preparation into the unchanged comparison budget."""
from pathlib import Path
import hashlib,importlib.util,json,sys
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):
 path=R/name
 assert not path.exists(),path
 path.write_text(json.dumps(obj,indent=2)+'\n')
attempt=R/(sys.argv[1] if len(sys.argv)>1 else 'preparation-r1')
assert json.loads((attempt/'child-exit.json').read_bytes())['returncode']==0
prep=json.loads((attempt/'results/summary.json').read_bytes());assert prep['complete'] is True
m=json.loads((R/'preparation-manifest.json').read_bytes())
paths=dict(source_plan=attempt/'results/source-plan.json',historical8_report=attempt/'results/historical8-production.json',
 bounded768_report=attempt/'results/bounded768-production.json',dimension_inputs=attempt/'results/dimension-inputs.json',
 preparation_summary=attempt/'results/summary.json',preparation_resources=attempt/'resources-final.json')
for key,path in paths.items():m[key]=str(path);m['inputs'][str(path)]=sha(path)
runner=R/'experiment-source/scripts/ops/autoencoder/benchmark_native_dimension_source_training.py'
spec=importlib.util.spec_from_file_location('_seal_native_training',runner);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
save('training-plan.json',dict(module.FIXED,input_sha256=m['inputs']))
m['plan_sha256']=sha(R/'training-plan.json');save('training-manifest.json',m)
print(json.dumps(dict(sealed=True,inputs=len(m['inputs']))))
