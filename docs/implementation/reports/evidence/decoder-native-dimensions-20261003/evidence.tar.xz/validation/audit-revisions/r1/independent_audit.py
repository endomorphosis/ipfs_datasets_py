"""Saved-evidence audit of native-width formula sidecars; stdlib only.

The inherited fidelity/selection arithmetic is authenticated and reused. This
checks source joins, normalization, actual tensor dimensions, common initialized
language decoder, learned source heads and all control panels without executing
models, encoders, optimizers or provers. Identity MSE is not learned fidelity.
"""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
import math
import sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
P=R.parents[2]
checks=0;findings=[];artifacts={}

def sha(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
    return value.hexdigest()
def raw(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def digest(v):return hashlib.sha256(raw(v)).hexdigest()
def check(value,label,detail=None):
    global checks
    checks+=1
    if not value:findings.append(dict(label=label,detail=detail))
def pin(path,expected=None):
    path=Path(path).resolve();value=sha(path)
    if expected is not None:check(value==expected,'pin/'+str(path))
    artifacts[str(path)]=dict(sha256=value,bytes=path.stat().st_size)
    return path
def read(path):return json.loads(pin(path).read_bytes())

PINS={'clause_audit_arithmetic.py':'ec3ac052e7dbc326d9385d80a1ddc9a63511ecbc5ae65f26dd65364614275094',
    'prior_training_arithmetic.py':'459eed5588f46b88550ae8568e756c11160303c1e74ee736d36e56594c6d793c',
    'audit_leaf_arithmetic.py':'ea440ebb1fc7b978da165329c864a69631be88048f2b694690522674cdc98c47'}
for name,h in PINS.items():pin(R/name,h)
spec=importlib.util.spec_from_file_location('_native_saved_clause_arithmetic',R/'clause_audit_arithmetic.py')
clause=importlib.util.module_from_spec(spec);spec.loader.exec_module(clause)
clause.check=check;clause.read=read
prior=clause.prior;prior.check=check;prior.read=read;prior.leaf.check=check
close=prior.close;f32=clause.f32
FIELDS=clause.FIELDS;CONTROLS=clause.CONTROLS
CORE_NAMES={'projection_down.weight','projection_down.bias','projection_up.weight','projection_up.bias',
    'condition.weight','condition.bias','target_embedding.weight','decoder.weight_ih_l0','decoder.weight_hh_l0',
    'decoder.bias_ih_l0','decoder.bias_hh_l0','output.weight','output.bias'}
COPIED={n for n in CORE_NAMES if n.startswith(('target_embedding.','decoder.','output.'))}
PROJECTION={n for n in CORE_NAMES if n.startswith('projection_')}


def descriptor(text,bytext):
    segments=[];char=byte=0
    for piece in text.split('\n\n'):
        vector=bytext[piece];dimension=len(vector)
        check(dimension in (8,384,768) and all(math.isfinite(x) for x in vector)
            and abs(math.fsum(x*x for x in vector)-1)<1e-4,'source/unit_native_vector/'+clause.textsha(piece))
        segments.append(dict(source_text=piece,source_sha256=clause.textsha(piece),embedding_sha256=digest(vector),
            vector=vector,char_start=char,char_end=char+len(piece),byte_start=byte,byte_end=byte+len(piece.encode())))
        char+=len(piece)+2;byte+=len(piece.encode())+2
    return dict(source_sha256=clause.textsha(text),segments=segments)
clause.descriptor=descriptor


def input_preparation(manifest,parent,source_root):
    prepared=read(manifest['dimension_inputs'])
    check(prepared['schema']=='matched-dimension-source-inputs/v1' and prepared['complete'] is True
        and prepared['inputs_sha256']==digest({k:v for k,v in prepared.items() if k!='inputs_sha256'}),'inputs/complete_sealed_payload')
    check(set(prepared['dimensions'])=={'8','384','768'} and prepared['targets_attached'] is False
        and prepared['target_access'] is False and prepared['teacher_checkpoint_loaded'] is False
        and prepared['encoder_context_increased'] is False and prepared['downloads_performed'] is False,'inputs/three_true_source_spaces_no_targets')
    plan=read(manifest['source_plan']);historical=read(manifest['historical8_report']);native=read(manifest['bounded768_report'])
    check(plan['plan_sha256']==digest({k:v for k,v in plan.items() if k!='plan_sha256'})
        and prepared['plan_sha256']==historical['plan_sha256']==native['plan_sha256']==plan['plan_sha256'],'inputs/preparation_plan_bindings')
    check(prepared['historical8_production_sha256']==digest(historical)
        and prepared['bounded768_production_sha256']==digest(native),'inputs/producer_receipt_bindings')
    check(plan['unique_sources']==239 and plan['cached768_sources']==167 and plan['missing768_sources']==72
        and len(plan['source_rows'])==239 and plan['cache_admission_token_limit']==512
        and plan['historical_native768_profile_token_limit']==8192 and plan['cached_profile_relabelled'] is False,'inputs/exact_reuse_and_missing_inventory')
    bundle=historical['bundle'];check(bundle['bundle_sha256']==digest({k:v for k,v in bundle.items() if k!='bundle_sha256'})
        and bundle['package'] is None and bundle['encoder_inference_executed'] is False
        and historical['legacy_sparse_reconstruction_used'] is False and historical['neural_semantic_embeddings'] is False,
        'inputs/historical_feature_producer_not_teacher_reconstruction')
    index8={};sources={r['id']:r for r in plan['source_rows']}
    for row in bundle['rows']:
        key=row['id'];entry=row['stages']['historical_linguistic_features8'];receipt=entry['receipt'];evidence=receipt['evidence']
        check(receipt['id']==key and row['source_sha256']==receipt['source_sha256']==clause.textsha(sources[key]['source_text'])
            and receipt['dimension']==8 and receipt['vector_sha256']==digest(entry['vector'])
            and receipt['receipt_sha256']==digest({k:v for k,v in receipt.items() if k!='receipt_sha256'}),'inputs/source_bound_historical_vector/'+key)
        check(evidence['kind']=='deterministic_linguistic_feature_hash' and evidence['profile_id']=='legacy-linguistic-features-8d/v1'
            and evidence['learned_reconstruction_checkpoint_used'] is False and evidence['pretrained_semantic_encoder_used'] is False
            and evidence['linguistic_identity_sha256']==digest(evidence['linguistic_identity']),'inputs/historical_identity/'+key)
        index8[key]=entry['vector']
    for path,h in bundle['producer_pins'].items():pin(path,h)
    cached=read(plan['native768_report']['path']);check(sha(plan['native768_report']['path'])==plan['native768_report']['sha256'],'inputs/cached_native_report_pin')
    cache_index={r['source_sha256']:r for r in cached['receipts']}
    index768={}
    for key,receipt in plan['cached768'].items():
        check(receipt==cache_index[clause.textsha(sources[key]['source_text'])]
            and 1<=receipt['token_count_including_special_tokens']<=512 and receipt['truncated'] is False,'inputs/exact_cached_native_receipt/'+key)
        index768[key]=receipt['embedding']
    check(native['schema']=='bounded-native768-source-production/v1' and native['status']=='completed'
        and native['experiment_token_limit']==512 and native['historical_profile_token_limit']==8192
        and native['all_actual_forward_tokens_checked'] is True and native['cached_profile_relabelled'] is False
        and native['source_rows']==plan['missing768_rows'],'inputs/bounded_actual_native_forward_scope')
    for row,tokens,receipt in zip(native['source_rows'],native['token_rows'],native['receipts']):
        check(receipt['id']==row['id'] and receipt['source_sha256']==clause.textsha(row['source_text'])
            and receipt['dimension']==768 and len(receipt['embedding'])==768 and receipt['truncated'] is False
            and receipt['token_count_including_special_tokens']==len(tokens['input_ids'])<=512
            and receipt['token_input_sha256']==digest(tokens['input_ids']) and tokens['attention_mask']==[1]*len(tokens['input_ids']),
            'inputs/new_native_receipt/'+row['id'])
        index768[row['id']]=receipt['embedding']
    check(len(native['receipts'])==len(native['token_rows'])==len(native['source_rows'])==72,'inputs/complete_missing768')
    loading=native['complete_checkpoint_loading'];dense=native['dense_path_verification']
    check(loading['classifier_loaded'] is True and loading['classifier_logits_used_for_dense_embedding'] is False
        and all(loading[k]==[] for k in ('missing_keys','unexpected_keys','mismatched_keys','error_msgs'))
        and loading['tensor_count']==len(loading['tensor_names']) and len(set(loading['tensor_names']))==loading['tensor_count']
        and dense['encoder_and_complete_hidden_states_bitwise_equal'] is True and dense['evaluation_mode'] is True,
        'inputs/complete_weights_and_dense_encoder_path')
    implementation={'asset_profile':'gte_multilingual_profile.py','complete_loader':'source_embeddings_768_complete.py',
        'reference_producer':'source_embeddings_768.py'}
    check(native['implementation']==cached['implementation'] and set(native['implementation'])==set(implementation),
        'inputs/reused_and_actual_native_implementation_identical')
    for key,name in implementation.items():pin(source_root/'ipfs_datasets_py/logic/formalization/autoencoder'/name,native['implementation'][key])
    events=native['forward_observations'];batch=native['execution_profile']['batch_size']
    schedule=[('complete',[0]),('encoder',[0])]+[('complete',list(range(i,min(i+batch,72)))) for i in range(0,72,batch)]
    check(len(events)==len(schedule),'inputs/all_actual_forward_events')
    for number,(event,(path,indices)) in enumerate(zip(events,schedule)):
        wanted=[native['token_rows'][i]['input_ids'] for i in indices];width=max(map(len,wanted))
        check(event['index']==number and event['path']==path and event['actual_forward_checked'] is True and event['padded_width']==width<=512
            and event['batch_size']==len(indices) and event['attention_mask']==[[1]*len(t)+[0]*(width-len(t)) for t in wanted]
            and len(event['input_ids'])==len(indices) and all(len(ids)==width and all(type(v) is int and v>=0 for v in ids)
                and ids[:len(t)]==t for ids,t in zip(event['input_ids'],wanted)),'inputs/actual_forward_tokens/'+str(event['index']))
        identities=[dict(id=native['source_rows'][i]['id'],source_sha256=clause.textsha(native['source_rows'][i]['source_text']),
            active_token_count=len(native['token_rows'][i]['input_ids']),token_input_sha256=digest(native['token_rows'][i]['input_ids'])) for i in indices]
        check(event['sources']==identities,'inputs/actual_forward_source_identities/'+str(number))
    validation=native['forward_validation']
    check(validation['forward_count']==len(schedule) and validation['sample_forward_observations']==74
        and validation['maximum_forward_width']==max(e['padded_width'] for e in events)
        and validation['token_limit']==512 and validation['complete_and_bare_encoder_checked'] is True,'inputs/forward_validation_recomputed')
    assets=native['assets'];check(assets==plan['native768_assets']==cached['assets'],'inputs/shared_native_assets')
    for item in assets['files']:
        path=Path(assets[item['relative_to']+'_directory'])/item['path'];pin(path,item['sha256'])
        check(path.stat().st_size==item['bytes'],'inputs/asset_size/'+item['path'])
    for producer in (native['bounded_owner'],):pin(producer['path'],producer['sha256'])
    check(set(index8)==set(index768)==set(sources),'inputs/exact_all_producer_coverage')
    originalvectors={r['input_id']:r['vector'] for r in read(parent['embeddings'])['rows']}
    corpus=read(parent['paragraphs']);lanes={}
    expectedkinds={'8':'historical_linguistic_feature_hash','384':'native_gte_small_semantic_embedding','768':'native_gte_multilingual_semantic_embedding'}
    check(prepared['representation_kinds']==expectedkinds,'inputs/honest_distinct_representation_labels')
    for dim in (8,384,768):
        lane=prepared['dimensions'][str(dim)];contexts={};unique={};vectors={};rows={}
        for split in ('train','validation'):
            check(len(lane[split])==48 and [r['id'] for r in lane[split]]==[r['id'] for r in corpus[split]],'inputs/common_ordered_sources/'+str(dim)+'/'+split)
            bytext={r['source_text']:r['input'] for r in lane['clause_cache'][split]};contexts[split]={};unique[split]={};rows[split]=[]
            for source,reference in zip(lane[split],corpus[split]):
                check(set(source)=={'id','source_text','input'} and source['source_text']==reference['source_text']
                    and len(source['input'])==dim,'inputs/closed_exact_source/'+str(dim)+'/'+source['id'])
                wanted=originalvectors[source['id']] if dim==384 else (index8 if dim==8 else index768)['source:'+clause.textsha(source['source_text'])]
                check(source['input']==wanted,'inputs/exact_native_paragraph_vector/'+str(dim)+'/'+source['id'])
                vectors[source['id']]=source['input'];contexts[split][source['id']]=descriptor(source['source_text'],bytext)
                rows[split].append(dict(source,target_ids=reference['target_ids']))
                for segment in contexts[split][source['id']]['segments']:unique[split].setdefault(segment['source_sha256'],segment)
            for source in lane['clause_cache'][split]:
                wanted=(next(r['input'] for r in plan['clause_cache384'][split] if r['source_text']==source['source_text']) if dim==384 else (index8 if dim==8 else index768)['source:'+clause.textsha(source['source_text'])])
                check(source['input']==wanted and len(source['input'])==dim,'inputs/exact_native_clause_vector/'+str(dim)+'/'+source['id'])
            check(len(unique[split])==(113 if split=='train' else 54),'inputs/unique_clause_inventory/'+str(dim)+'/'+split)
        for view,trainvectors,valvectors in [('paragraph',[r['input'] for r in lane['train']],[r['input'] for r in lane['validation']]),
                ('clause',[r['vector'] for r in unique['train'].values()],[r['vector'] for r in unique['validation'].values()])]:
            check(not {digest(v) for v in trainvectors}&{digest(v) for v in valvectors},'inputs/no_cross_split_vector_collisions/'+str(dim)+'/'+view)
        check(contexts==lane['source_contexts'],'inputs/exact_context_offsets_and_vectors/'+str(dim))
        lanes[dim]=dict(dimension=dim,contexts=contexts,unique=unique,vectors=vectors,rows=rows,input_lane=lane)
    return dict(assembled_inputs=prepared,source_plan=plan,lanes=lanes,corpus=corpus)


def common(args):
    manifest=read(args.manifest);plan=read(args.plan)
    check(sha(args.plan)==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'],'pins/plan_inputs')
    for path,h in manifest['inputs'].items():pin(path,h)
    for rel,h in manifest['extensions'].items():pin(args.source/rel,h)
    parent=read(manifest['parent_manifest']);parentplan=read(manifest['parent_plan'])
    check(sha(manifest['parent_plan'])==parent['plan_sha256'] and parentplan['input_sha256']==parent['inputs'],'pins/parent_inputs')
    for path,h in parent['inputs'].items():pin(path,h)
    static=read(R/'static-review.json');check(static['passed'] and static['findings']==[],'peer/static_review')
    for path,item in static['artifacts'].items():pin(path,item['sha256'] if isinstance(item,dict) else item)
    fixed=dict(schema='native-dimension-source-training-plan/v1',dimensions=[8,384,768],seed_order=[1729,2718],fit_count=12,
        source_seed=1729,historical_linguistic_teacher_modified=False,source_routes_reset=True,
        identity_projection_frozen=True,identity_mse_is_not_learned_reconstruction=True,
        source_independent_donor_tensors_copied=True,dimension_only_ablation=False,teacher_distillation_used=False,
        learning_rate=.001,batch_size=8,max_seconds_per_arm=180,expected_optimizer_steps_per_arm=340,
        expected_training_token_presentations_per_arm=225840,expected_source_value_presentations_per_arm=25600,
        expected_row_presentations_per_arm=2440,expected_count_presentations_per_arm=2440,
        fixed_encoder_context_tokens=512,fixed_decoder_output_limit=512,temperature=0,
        selection_unchanged=True,full_vocabulary_retained=True,syntax_forced=False,closure_forced=False,
        production_promotion_allowed=False,generation_reference_count_access=False)
    for key,value in fixed.items():check(plan.get(key)==value,'plan/'+key)
    check(plan['arms']==[dict(name=n,head_kind=n,order_augmentation=False,generated_boundary_weight=0.) for n in ('pooled','clauses')],'plan/fixed_paired_arms')
    prepared=input_preparation(manifest,parent,args.source);donor=read(parent['donor']);previous=read(parent['shared_summary']);prep=read(parent['order_preparation'])
    original={r['id']:r for r in prepared['corpus']['train']};byid={r['id']:r for r in prep['rows']};variants={k:[] for k in original}
    for row in prep['rows']:variants[row['order_diagnostic']['parent_id']].append(row['id'])
    return dict(**prepared,manifest=manifest,plan=plan,parent=parent,donor=donor,original=original,prepared=byid,
        variants=variants,prior={r['arm']:r for r in previous['runs']})


HEADS={};PROJECTIONS={}

def projected(vector,state,ctx):
    transform=ctx['donor']['input_transform'];key=(ctx['dimension'],digest(vector),digest(transform))
    if key not in PROJECTIONS:PROJECTIONS[key]=[f32(f32(f32(v)-f32(m))/f32(transform['scale'])) for v,m in zip(vector,transform['mean'])]
    return PROJECTIONS[key]


def head_scores(state,ctx,vector,descriptor_value,zero=False):
    candidate=state['recipe']['head_kind']=='clauses';values=prior.canonical(state);size=len(ctx['donor']['codec']['target_vocabulary']);dimension=ctx['dimension']
    prefix='clause_head.' if candidate else 'source_value_head.'
    W=values[prefix+'source_projection.weight'];b=values[prefix+'source_projection.bias']
    RW=values[prefix+'field_readout.weight'];RB=values[prefix+'field_readout.bias'];result=[]
    for slot in range(8):
        if candidate and not zero and slot>=len(descriptor_value['segments']):result.append([[0.]*size for _ in FIELDS]);continue
        source=(descriptor_value['segments'][slot]['vector'] if candidate else vector) if not zero else None
        key=(state['tensor_sha256'],None if zero else digest(source),None if candidate else slot)
        if key not in HEADS:
            mean=values['clause_source_mean' if candidate else 'source_mean'];scale=values['clause_source_scale' if candidate else 'source_scale']
            x=[0.]*dimension if zero else [(v-m)/scale for v,m in zip(projected(source,state,ctx),mean)]
            hidden=clause.affine(x,W,b)
            if not candidate:hidden=[v+e for v,e in zip(hidden,values['source_value_head.slot_embeddings'][slot])]
            scores=clause.affine([math.tanh(v) for v in hidden],RW,RB);HEADS[key]=[scores[i*size:(i+1)*size] for i in range(4)]
        result.append(HEADS[key])
    return result
clause.projected=projected;clause.head_scores=head_scores


def norm_check(receipt,features,inventory,forbidden,rows,label):
    check(receipt['receipt_sha256']==digest({k:v for k,v in receipt.items() if k!='receipt_sha256'})
        and receipt['training_feature_rows_sha256']==digest(features) and receipt['training_rows_sha256']==digest(rows), 'normalization/complete_bindings/'+label)
    check(receipt['training_inventory']==inventory and receipt['expected_training_ids']==[r['id'] for r in inventory]
        and receipt['forbidden_validation_ids']==forbidden and receipt['fitted_rows']==len(inventory)
        and len(features)==len(inventory) and receipt['validation_rows_used_for_fitting']==0,'normalization/exact_training_inventory/'+label)
    for feature,identity in zip(features,inventory):check({k:feature[k] for k in ('id','source_sha256')}==identity,'normalization/feature_source/'+label+'/'+identity['id'])
    dim=len(features[0]['features']);means=[math.fsum(r['features'][i] for r in features)/len(features) for i in range(dim)]
    energy=math.fsum((v-means[i])**2 for r in features for i,v in enumerate(r['features']))/len(features)
    check(receipt['dimension']==dim and close(receipt['mean'],means,1e-12)
        and close(receipt['fitted_training_centered_row_squared_norm'],energy,1e-12)
        and close(receipt['scale'],math.sqrt(energy) if energy else 1.,1e-12),'normalization/independent_mean_RMS/'+label)


def lane_preparation(root,ctx,dimension):
    lane=dict(ctx);lane.update(ctx['lanes'][dimension]);data=read(root/str(dimension)/'preprocessing.json')
    contexts=read(root/str(dimension)/'source-contexts.json');rows=read(root/str(dimension)/'training-rows.json')
    check(contexts==lane['contexts'] and rows==lane['rows'],'preparation/exact_source_contexts_and_targets/'+str(dimension))
    transform=data['input_transform'];sources=rows['train'];means=[math.fsum(r['input'][i] for r in sources)/48 for i in range(dimension)]
    rms=math.sqrt(math.fsum((v-means[i])**2 for r in sources for i,v in enumerate(r['input']))/48)
    check(transform['mode']=='center_rms' and transform['origin']=='training_only' and close(transform['mean'],means,1e-6)
        and close(transform['scale'],max(rms,.01),1e-6),'preparation/paragraph_float32_training_transform/'+str(dimension))
    lane['donor']=deepcopy(ctx['donor']);lane['donor']['input_transform']=transform
    inventory=[dict(id=r['id'],source_sha256=clause.textsha(r['source_text'])) for r in sources]
    norm_check(data['paragraph_normalization'],data['paragraph_features'],inventory,[r['id'] for r in rows['validation']],sources,str(dimension)+'/paragraph')
    unique=list(lane['unique']['train'].items());inventory=[dict(id='clause:'+k,source_sha256=k) for k,_ in unique]
    norm_check(data['clause_normalization'],data['clause_features'],inventory,['clause:'+k for k in lane['unique']['validation']],sources,str(dimension)+'/clause')
    check(data['clause_normalization']['training_contexts_sha256']==digest(contexts['train']),'preparation/clause_vector_digest/'+str(dimension))
    for source,feature in zip(sources,data['paragraph_features']):check(feature['features']==projected(source['input'],None,lane),'preparation/exact_identity_paragraph_features/'+str(dimension)+'/'+source['id'])
    for (key,source),feature in zip(unique,data['clause_features']):check(feature['features']==projected(source['vector'],None,lane),'preparation/exact_identity_clause_features/'+str(dimension)+'/'+key)
    prior_count=data['count_prior'];counts=[12 if n in (1,2,4,8) else 0 for n in range(1,33)];prob=[(n+1/32)/49 for n in counts]
    check(prior_count['receipt_sha256']==digest({k:v for k,v in prior_count.items() if k!='receipt_sha256'})
        and prior_count['class_counts']==counts and prior_count['alpha_per_class']==1/32 and prior_count['total_pseudocount']==1
        and close(prior_count['probabilities'],prob,1e-12) and prior_count['log_prior']==[f32(math.log(v)) for v in prob]
        and prior_count['training_rows_sha256']==digest(sources),'preparation/all32_positive_training_count_prior/'+str(dimension))
    lane['preparation_saved']=data
    return lane


def zeros(value):return all(v==0 for v in prior.leaf.flat(value))
def state_check(path,report,role,initial,ctx,label):
    state=read(path);prior.authority(state,label);dim=ctx['dimension'];values=state['model_state'];v=prior.canonical(state)
    receipt=state['initializer_receipt'];rawvalues={k:v[k] for k in CORE_NAMES};architecture=state['architecture'];candidate=state['recipe']['head_kind']=='clauses'
    check(state['schema']=='private-native-dimension-source-state/v1' and state['dimension']==dim and state['role']==role
        and state['codec']==ctx['donor']['codec'] and state['input_transform']==ctx['donor']['input_transform'],'state/closed_native_identity/'+label)
    check(state['weights_sha256']==digest(values) and state['tensor_sha256']==clause.tensor_digest(values),'state/exact_typed_hash/'+label)
    expected=report['initial_weights_sha256'] if role=='initial' else report['selected_weights_sha256'] if role=='selected' else report['last_complete_attempt_weights_sha256']
    check(state['tensor_sha256']==expected,'state/report_weights_binding/'+label)
    check(receipt==ctx['preparation_saved']['initializer'] and receipt['schema']=='dimension-native-raw-decoder-development/v1'
        and receipt['receipt_sha256']==digest({k:x for k,x in receipt.items() if k!='receipt_sha256'})
        and receipt['input_dimension']==receipt['projected_output_dimension']==receipt['dimension']==dim
        and receipt['historical_8d_linguistic_teacher'] is False and receipt['learned_projection_reconstruction'] is False,'state/native_not_teacher_identity_projection_receipt/'+label)
    shapes={k:prior.leaf.shape(x) for k,x in v.items()}
    h=receipt['hidden_width'];tw=receipt['token_embedding_width'];width=receipt['projection_width'];vocab=receipt['vocabulary_size']
    expected_shapes={'condition.weight':[h,dim],'condition.bias':[h],'projection_down.weight':[width,dim],
        'projection_down.bias':[width],'projection_up.weight':[dim,width],'projection_up.bias':[dim],
        'source_to_embedding.weight':[tw,dim],'count_head.weight':[32,dim],'count_head.bias':[32]}
    head='clause_head.' if candidate else 'source_value_head.'
    expected_shapes.update({head+'source_projection.weight':[64,dim],head+'source_projection.bias':[64],head+'field_readout.weight':[4*vocab,64],head+'field_readout.bias':[4*vocab]})
    check(all(shapes[k]==s for k,s in expected_shapes.items()),'state/real_native_source_tensor_dimensions/'+label)
    expected_names=CORE_NAMES|{'source_to_embedding.weight','count_head.weight','count_head.bias','count_prior_logits','source_mean','source_scale','head_initialization_seed'}|set(k for k in expected_shapes if k.startswith(head))
    expected_names|={'clause_source_mean','clause_source_scale'} if candidate else {'source_value_head.slot_embeddings'}
    check(set(v)==expected_names,'state/no_hidden_or_dead_parameters/'+label)
    check(zeros(v['projection_up.weight']) and zeros(v['projection_up.bias']), 'state/frozen_projection_is_identity/'+label)
    if initial is not None:
        iv=prior.canonical(initial);frozen=PROJECTION|{'source_mean','source_scale','count_prior_logits','head_initialization_seed'}|({'clause_source_mean','clause_source_scale'} if candidate else set())
        check(all(v[k]==iv[k] for k in frozen) and architecture==initial['architecture'],'state/all_frozen_tensors_and_architecture_unchanged/'+label)
    else:
        check(all(rawvalues[k]==ctx['donor']['model_state'][k] for k in COPIED),'initial/common_transferred_GRU_embedding_output/'+label)
        check(receipt['donor_tensor_sha256']==clause.tensor_digest(ctx['donor']['model_state'])
            and receipt['initial_tensor_sha256']==clause.tensor_digest(rawvalues),'initial/donor_and_reset_tensor_hashes/'+label)
        check(zeros(v['condition.weight']) and zeros(v['condition.bias']) and zeros(v['source_to_embedding.weight'])
            and zeros(v['count_head.weight']) and v['count_head.bias']==v['count_prior_logits']
            and zeros(v[head+'field_readout.weight']) and zeros(v[head+'field_readout.bias']),'initial/all_source_generation_routes_neutral/'+label)
    norm=ctx['preparation_saved']['paragraph_normalization'];cp=ctx['preparation_saved']['count_prior']
    check(v['source_mean']==[f32(x) for x in norm['mean']] and v['source_scale']==f32(norm['scale'])
        and v['count_prior_logits']==cp['log_prior'] and architecture['normalization']==norm and architecture['count_prior']==cp,'state/exact_frozen_preprocessing/'+label)
    if candidate:
        cn=ctx['preparation_saved']['clause_normalization']
        check(architecture['clause_normalization']==cn and v['clause_source_mean']==[f32(x) for x in cn['mean']]
            and v['clause_source_scale']==f32(cn['scale']),'state/exact_frozen_clause_preprocessing/'+label)
    frozen=PROJECTION|{'source_mean','source_scale','count_prior_logits','head_initialization_seed'}|({'clause_source_mean','clause_source_scale'} if candidate else set())
    state['_audited_trainable_count']=sum(math.prod(prior.leaf.shape(x)) for k,x in v.items() if k not in frozen)
    return state


def results(args,ctx):
    root=args.results;summary=read(root/'summary.json');prior.authority(summary,'summary')
    names=[str(d)+'-'+n+'-'+str(s) for d in (8,384,768) for s in (1729,2718) for n in ('pooled','clauses')]
    check(summary['complete'] and [r['arm'] for r in summary['runs']]==names and summary['dimensions_actually_trained']==[8,384,768],'results/12_complete_native_fits')
    check(summary['initial_generation_equal_across_all_arms'] and summary['historical_linguistic_teacher_modified'] is False
        and summary['identity_projection_is_not_learned_reconstruction'] is True and summary['dimension_only_ablation'] is False
        and summary['encoder_executed'] is False and summary['downloads_performed'] is False,'results/honest_scope')
    lanes={d:lane_preparation(root,ctx,d) for d in (8,384,768)};out={};cache=set();initials={};first_predictions=None
    for run in summary['runs']:
        label=run['arm'];dim=run['dimension'];lane=lanes[dim];folder=root/label;report=read(folder/'training.json')
        check(report==run['training'],'training/exact_saved_report/'+label);detail=prior.training(run,lane)
        check(all(u['raw_reconstruction_mse']==0 for u in report['committed_updates'])
            and report['selected']['numerical']['reconstructed_input_mse']==report['last_complete_attempt']['numerical']['reconstructed_input_mse']==0,
            'training/identity_MSE_is_constant_not_learned/'+label)
        states={};initial=None
        for role in ('initial','selected','last-attempt'):
            states[role]=state_check(folder/(role+'-state.json'),report,role,initial,lane,label+'/'+role)
            if role=='initial':initial=states[role]
        initials[label]=initial;parity=read(folder/'initial-parity.json')
        if first_predictions is None:first_predictions=parity['predictions']
        check(parity==run['initial_parity'] and parity['complete'] and parity['initial_parameters_equal_after_head_rename']
            and parity['inherited_buffers_equal'] and parity['predictions']==first_predictions
            and [p['split'] for p in parity['predictions']]==['train','validation']
            and all(len(p['predictions'])==48 for p in parity['predictions']),'initial/all12_full_generation_and_inputs_parity/'+label)
        check(run['trainable_parameter_count']==states['last-attempt']['_audited_trainable_count']==parity['trainable_parameters'], 'state/true_trainable_parameter_count/'+label)
        if run['recipe']['head_kind']=='clauses':
            pooled=initials[str(dim)+'-pooled-'+str(run['seed'])];pv=prior.canonical(pooled);cv=prior.canonical(initial)
            mapped={k.replace('clause_head.','source_value_head.',1) if k.startswith('clause_head.') else k:v for k,v in cv.items() if k not in ('clause_source_mean','clause_source_scale')}
            check(set(mapped)==set(pv)-{'source_value_head.slot_embeddings'} and all(v==pv[k] for k,v in mapped.items()),'initial/matched_pooled_clause_values/'+label)
            check(parity['trainable_parameters']==parity['baseline_trainable_parameters']-512,'parameters/paired_512_slot_parameter_difference/'+label)
            check(report['source_contexts_sha256']==digest(lane['contexts']) and report['source_context_target_access'] is False,'training/explicit_source_context/'+label)
        panels={};rawpanels={}
        for role in ('selected','last-attempt'):
            panels[role]={};rawpanels[role]={}
            for name,split,kind in CONTROLS:
                value=read(folder/role/('evaluation-'+name+'.json'));rawpanels[role][name]=value
                panels[role][name]=clause.panel_check(value,split,kind,states[role],lane,label+'/'+role+'/'+name,cache)
                check(value['report']['metrics']['reconstructed_input_mse']==0,'evaluation/identity_MSE_disclosed/'+label+'/'+role+'/'+name)
                if name=='validation':
                    expected=report['selected'] if role=='selected' else report['last_complete_attempt']
                    check(value['report']['metrics']==expected['numerical'],'evaluation/selection_metric_binding/'+label+'/'+role)
            if run['recipe']['head_kind']=='pooled':
                for name,_,_ in CONTROLS[5:]:check(rawpanels[role][name]['predictions']==rawpanels[role]['validation']['predictions'],'evaluation/pooled_clause_control_invariance/'+label+'/'+role+'/'+name)
        out[label]=dict(dimension=dim,training=detail,controls=panels,selected_epoch=report['selected_epoch'],
            fit_elapsed_seconds=run['training_call_elapsed_seconds'],trainable_parameter_count=run['trainable_parameter_count'],
            final_teacher_forced_CE=rawpanels['last-attempt']['validation']['report']['metrics']['token_cross_entropy'],
            identity_mse_is_not_learned_reconstruction=True)
    return dict(runs=out,distinct_fidelity_panels_audited=len(cache),expected_panels=192,expected_states=36,limits=[
        'No model, encoder, optimizer, gradient replay, proof or Lake execution occurs in this auditor.',
        'The8D historical feature hash is not a pretrained semantic representation or the preserved sparse teacher.',
        'These are new formula sidecars with reset source conditioning; they are not old checkpoint continuations.',
        'The frozen identity projection has zero MSE by construction; only generated formula fidelity measures reconstruction learning here.',
        'Cross-dimension comparisons include different source producers and parameter counts; within-dimension pooled/clause pairs share inputs.',
        'The validation cohort is already exposed; no fresh holdout, global convergence, production promotion or semantic qualification follows.'])



def main():
    parser=argparse.ArgumentParser()
    for name in ('source','manifest','plan','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--results',type=Path);args=parser.parse_args()
    for name in ('source','manifest','plan','output','results'):
        value=getattr(args,name)
        if value is not None:setattr(args,name,value.resolve())
    ctx=common(args);analysis=results(args,ctx) if args.results else None
    check('torch' not in sys.modules and 'transformers' not in sys.modules,'auditor/no_model_imports')
    pin(__file__)
    output=dict(schema='native-dimension-source-training-independent-audit/v1',phase='results' if args.results else 'readiness',
        created_at_utc=datetime.now(timezone.utc).isoformat(),passed=not findings,checks=checks,finding_count=len(findings),
        findings=findings,artifacts=artifacts,analysis=analysis,manifest_sha256=sha(args.manifest),plan_sha256=sha(args.plan),
        models_executed=False,training_executed=False,encoder_executed=False,qualified=False,admitted=False,
        lake_executed=False,fresh_holdout=False,identity_mse_is_not_learned_reconstruction=True)
    if not args.results:
        started=bool(list(R.glob('training-*/results')))
        output.update(pre_execution=not started,timing_scope='post_execution_plan_and_input_review' if started else 'pre_execution_plan_and_input_review')
    args.output.write_text(json.dumps(output,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(passed=output['passed'],checks=checks,findings=len(findings),output=str(args.output))))
    if findings:sys.exit(1)

if __name__=='__main__':main()
