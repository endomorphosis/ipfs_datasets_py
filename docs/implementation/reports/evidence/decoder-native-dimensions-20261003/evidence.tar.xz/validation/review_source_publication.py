"""Compare retained/executed producer bytes to the exact publication base; no fetch."""
from pathlib import Path
import hashlib,json,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2';F=R/'experiment-source'
E=P/'docs/implementation/reports/evidence/decoder-clause-context-training-20261003'
checks=0;artifacts={};findings=[]
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def pin(path):
 path=Path(path).resolve();raw=path.read_bytes();artifacts[str(path)]={'sha256':sha(raw),'bytes':len(raw)};return raw
def read(path):return json.loads(pin(path))
def check(value,label):
 global checks
 checks+=1
 if not value:findings.append(label)
def git(*args):return subprocess.run(['git',*args],cwd=P,capture_output=True)
base=read(R/'base.json')['base'];prior=read(E/'manifest.json');ext=read(R/'frozen-extensions.json')
actual=read(R/'preparation-r2/results/summary.json')['source_dependencies'];code_files=read(R/'code-files.json')
check(base=='83a7fb9d239dee587bcd27ea451a0f6c16b77f41','exact expected publication base')
check(pin(E/'manifest.json')==git('show',base+':'+str((E/'manifest.json').relative_to(P))).stdout,'prior111 producer manifest is the exact published base blob')
union={};origins={}
def merge(rel,digest,origin):
 check(rel not in union or union[rel]==digest,'no conflicting source hash '+rel)
 union[rel]=digest;origins.setdefault(rel,[]).append(origin)
for rel,digest in prior['validated_producer_source_sha256'].items():merge(rel,digest,'published_predecessor')
for rel,digest in ext.items():
 check(sha(pin(F/rel))==digest,'frozen extension exact '+rel);merge(rel,digest,'frozen_extension')
for scoped,digest in actual.items():
 scope,sep,rel=scoped.partition(':')
 check(sep==':' and scope in ('dependency','extension'),'recognized execution provenance '+scoped)
 check(sha(pin((F if scope=='extension' else S)/rel))==digest,'actual preparation source retained '+rel)
 merge(rel,digest,'actual_preparation_'+scope)
intentional={
 'ipfs_datasets_py/logic/formalization/autoencoder/'+name+'.py' for name in
 ('dimension_source_inputs','dimension_native_decoder_experiment','legal_native_conditioning',
  'source_embeddings_768','source_embeddings_768_complete','gte_multilingual_profile')}
intentional|={'scripts/ops/autoencoder/'+name+'.py' for name in
 ('prepare_native_dimension_source_inputs','benchmark_native_dimension_source_training')}
comparisons={};differences=[]
for rel,digest in sorted(union.items()):
 before=git('show',base+':'+rel);old=None if before.returncode else sha(before.stdout)
 status='absent_from_base' if old is None else 'identical' if old==digest else 'different_from_base'
 comparisons[rel]=dict(expected_sha256=digest,base_sha256=old,status=status,origins=origins[rel])
 if status!='identical':differences.append(rel)
 check(status=='identical' or rel in intentional,'only intended new producer publication '+rel)
 if status!='identical':
  check(rel in code_files,'required source is in explicit publication files '+rel)
  check(sha(pin(P/rel))==digest,'new publication source equals actually frozen source '+rel)
check(set(differences)==intentional,'exactly eight intended new producer paths')
check(len(union)==150 and len(actual)==119 and len(ext)==54 and len(prior['validated_producer_source_sha256'])==111,'fixed reviewed source union counts')
# Existing test bytes and new dependencies are reviewed without importing or rerunning them.
tests=read(R/'validated-test-source.json');test_differences=[]
for rel,digest in tests.items():
 check(sha(pin(F/rel))==digest,'frozen test source exact '+rel)
 before=git('show',base+':'+rel);old=None if before.returncode else sha(before.stdout)
 if old!=digest:
  test_differences.append(rel);check(rel in code_files,'new test dependency is explicitly published '+rel)
  check(sha(pin(P/rel))==digest,'new test source matches frozen reviewed source '+rel)
config='configs/autoencoders/gte_multilingual_local_assets_v1.json'
check(config in code_files,'required native768 local asset configuration explicitly published')
manifest=read(R/'preparation-manifest.json')
check(sha(pin(P/config))==manifest['inputs'][str(P/config)],'local asset configuration matches executed preparation')
check(all(path in code_files for path in intentional),'all intentional owners in publication scope')
pin(__file__)
result=dict(schema='native-dimension-source-publication-compatibility/v1',complete=True,
 passed=not findings,checks=checks,finding_count=len(findings),findings=findings,
 publication_base=base,local_origin_main_observed=git('rev-parse','origin/main').stdout.decode().strip(),
 remote_fetched=False,remote_currentness_asserted=False,publication_performed=False,
 predecessor_producer_count=111,frozen_extension_count=54,actual_preparation_producer_count=119,
 unique_producer_count=len(union),existing_base_identical_count=len(union)-len(differences),
 intentional_unpublished_producers=sorted(differences),unrelated_producer_changes=[],
 new_test_dependencies=sorted(test_differences),required_asset_configuration=config,
 validated_producer_source_sha256=dict(sorted(union.items())),comparisons=comparisons,
 artifacts=artifacts,source_path=str(Path(__file__).resolve()),source_sha256=sha(Path(__file__).read_bytes()),
 scope='Exact frozen/preparation/predecessor source union versus pinned publication base. Pending final training-import/builder closure review; no claim for arbitrary current workspace bytes.',
 model_execution=False,source_edits=False,qualified=False,admitted=False)
(R/'source-publication-compatibility.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':not findings,'checks':checks,'finding_count':len(findings),
 'unique_sources':len(union),'receipt_sha256':sha((R/'source-publication-compatibility.json').read_bytes())}))
if findings:raise SystemExit(1)
