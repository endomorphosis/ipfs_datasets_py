"""Summarize complete saved native-width outcomes using only the standard library.

This checks reported aggregate/row consistency; the separate independent audit
reconstructs numerics and gates. No Torch, model, encoder or training code runs.
"""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path

R = Path(__file__).resolve().parent
RESULTS = R / 'training-r1/results'
SCALARS = ('actor', 'action', 'modality', 'object')
CONTROLS = ('validation', 'training', 'zero-condition', 'source-shuffle', 'cross-length-shuffle',
    'context-only-shuffle', 'context-reverse', 'context-rotate')
artifacts, checks = {}, []


def read(path):
    path = Path(path)
    raw = path.read_bytes()
    artifacts[str(path)] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
    return json.loads(raw)


def check(name, condition):
    checks.append(dict(name=name, passed=bool(condition)))


def compact(panel, name):
    fidelity, numerical = panel['source_fidelity'], panel['report']
    count, auxiliary = panel['source_count'], panel['source_values']
    rows, predictions = fidelity['rows'], panel['predictions']
    check(name+'/complete48', numerical['complete'] is True and fidelity['complete_evaluation'] is True
        and numerical['sample_count'] == len(rows) == len(predictions) == 48)
    check(name+'/row_order', [r['id'] for r in rows] == [r['id'] for r in predictions])
    check(name+'/aggregate_counts', all(value == sum(r['counts'][key] for r in rows)
        for key, value in fidelity['metrics'].items()))
    check(name+'/aggregate_facets', all(fidelity['by_facet'][field][key]
        == sum(r['by_facet'][field][key] for r in rows)
        for field in fidelity['by_facet'] for key in ('correct', 'total', 'unordered_correct')))
    check(name+'/eos_and_exact', numerical['metrics']['eos_count'] == fidelity['metrics']['eos_count']
        and sum(p['eos_reached'] for p in predictions) == fidelity['metrics']['eos_count']
        and numerical['metrics']['exact_targets'] == fidelity['metrics']['ordered_exact'])
    check(name+'/raw_source_head_separate', auxiliary['source_only_head'] is True
        and auxiliary['references_passed_to_model'] is False and auxiliary['used_for_selection'] is False
        and count['source_only_head'] is True and count['reference_count_supplied_to_generation'] is False
        and count['used_for_selection'] is False and auxiliary['present_values'] == 720)
    generated = sum(fidelity['by_facet'][field]['correct'] for field in SCALARS)
    lengths = {}
    for length, entry in fidelity['by_length'].items():
        group = [r for r in rows if r['clause_count'] == int(length)]
        check(name+'/length='+length, len(group) == 12 and entry['metrics']['rows'] == 12
            and all(value == sum(r['counts'][key] for r in group) for key, value in entry['metrics'].items()))
        lengths[length] = dict(generated=entry['metrics'],
            generated_scalar_matches=sum(entry['by_facet'][field]['correct'] for field in SCALARS),
            scalar_positions=4*12*int(length), raw_auxiliary=auxiliary['by_length'][length],
            source_count=count['by_length'][length])
    elapsed = numerical['elapsed_seconds']
    check(name+'/timing', type(elapsed) in (float, int) and math.isfinite(elapsed) and elapsed > 0
        and math.isclose(numerical['spans_per_wall_second'], 48/elapsed, rel_tol=1e-12)
        and math.isclose(numerical['wall_seconds_per_span'], elapsed/48, rel_tol=1e-12))
    return dict(generated=fidelity['metrics'], generated_scalar_matches=generated, scalar_positions=720,
        generated_scalar_fields={field:fidelity['by_facet'][field] for field in SCALARS},
        raw_auxiliary_scalar_matches=auxiliary['correct'], raw_auxiliary_cross_entropy=auxiliary['cross_entropy'],
        source_count_correct=count['correct'], sequence_cross_entropy=numerical['metrics']['token_cross_entropy'],
        identity_projection_mse=numerical['metrics']['reconstructed_input_mse'], by_length=lengths,
        numerical_evaluation_seconds=elapsed, numerical_evaluation_seconds_per_span=elapsed/48,
        numerical_evaluation_spans_per_second=48/elapsed, timing_scope=numerical['timing_scope'],
        identity_projection_mse_is_not_learned_reconstruction=True)


def main():
    summary = read(RESULTS / 'summary.json')
    if summary.get('complete') is not True or len(summary.get('runs', [])) != 12:
        raise ValueError('all twelve completed runs are required; no partial result receipt is written')
    final_resource = read(R / 'training-r1/resources-final.json')
    check('released_guardian', final_resource['status'] == final_resource['record']['status'] == 'released')
    check('actual_native_dimensions', summary['dimensions_actually_trained'] == [8,384,768]
        and summary['historical_linguistic_teacher_modified'] is False and summary['dimension_only_ablation'] is False)
    check('no_promotion_authority', all(summary[key] is False for key in
        ('qualified','admitted','convergence_proven','fresh_holdout','lake_executed','formalized','roundtrip_ok','checkpoint_promoted')))
    records = []
    for run in summary['runs']:
        folder = RESULTS / run['arm']; training = read(folder / 'training.json')
        check(run['arm']+'/exact_report', training == run['training'])
        check(run['arm']+'/matched_exposure', training['stopped_reason'] == 'epochs_completed'
            and training['optimizer_steps'] == 340 and training['row_presentations'] == 2440
            and training['valid_target_token_presentations'] == 225840
            and training['source_value_presentations'] == 25600 and training['count_training_row_presentations'] == 2440)
        check(run['arm']+'/unchanged_selection_label', training['selection']
            == 'per_length_nonregression_then_fidelity_progress_then_reference_ce')
        roles = {}
        for role in ('selected','last-attempt'):
            roles[role] = {label:compact(read(folder / role / ('evaluation-'+label+'.json')), run['arm']+'/'+role+'/'+label)
                for label in CONTROLS}
        accepted = [e['epoch'] for e in training['history'] if e['accepted']]
        check(run['arm']+'/selected_epoch', training['selected_epoch'] == (max(accepted) if accepted else 0))
        rejected = Counter(reason for e in training['history'] for reason in e['rejection_reasons'])
        baseline = training['baseline']['numerical']['token_cross_entropy']
        final = roles['last-attempt']['validation']
        records.append(dict(arm=run['arm'],dimension=run['dimension'],seed=run['seed'],head=run['recipe']['name'],
            selected_epoch=training['selected_epoch'],accepted_epochs=accepted,rejection_reason_counts=dict(rejected),
            fit_call_wall_seconds=run['training_call_elapsed_seconds'],arm_wall_seconds=run['elapsed_seconds'],
            decoder_row_presentations_per_fit_call_second=2440/run['training_call_elapsed_seconds'],
            target_token_presentations_per_fit_call_second=225840/run['training_call_elapsed_seconds'],
            fit_call_scope='includes trainer baseline/evaluations, bookkeeping and optimizer; not pure optimizer throughput',
            baseline_sequence_cross_entropy=baseline,final_sequence_cross_entropy_delta=final['sequence_cross_entropy']-baseline,
            trainable_parameter_count=run['trainable_parameter_count'],roles=roles))
    pairs = []
    for dimension in (8,384,768):
        for seed in (1729,2718):
            pair = {r['head']:r for r in records if r['dimension']==dimension and r['seed']==seed}
            pooled, clauses = (pair[key]['roles']['last-attempt']['validation'] for key in ('pooled','clauses'))
            check(str(dimension)+'/'+str(seed)+'/paired_parameter_delta',
                pair['pooled']['trainable_parameter_count']-pair['clauses']['trainable_parameter_count']==512)
            pairs.append(dict(dimension=dimension,seed=seed,
                clauses_minus_pooled_generated_scalars=clauses['generated_scalar_matches']-pooled['generated_scalar_matches'],
                clauses_minus_pooled_raw_auxiliary_scalars=clauses['raw_auxiliary_scalar_matches']-pooled['raw_auxiliary_scalar_matches'],
                clauses_minus_pooled_sequence_cross_entropy=clauses['sequence_cross_entropy']-pooled['sequence_cross_entropy'],
                clauses_over_pooled_fit_wall_ratio=pair['clauses']['fit_call_wall_seconds']/pair['pooled']['fit_call_wall_seconds']))
    content = Path(__file__).read_bytes()
    artifacts[str(Path(__file__))] = dict(sha256=hashlib.sha256(content).hexdigest(),bytes=len(content))
    findings = [check['name'] for check in checks if not check['passed']]
    receipt = dict(schema='native-dimension-training-outcome-review/v1',complete=True,passed=not findings,
        finding_count=len(findings),findings=findings,check_count=len(checks),artifacts=artifacts,runs=records,paired_validation=pairs,
        strict_selection=dict(selected_epochs=[r['selected_epoch'] for r in records],
            any_trained_state_selected=any(r['selected_epoch']>0 for r in records),selection_recomputed_by_separate_independent_audit=True),
        telemetry=dict(device='cpu',workers=1,bridge_names=[],legal_ir_evaluate_provers=False,
            metric_disk_cache_used=False,legal_ir_bridge_evaluation_performed=False,bridge_on_evaluate_seconds=None,
            input_cache='all decoder fit inputs cached; separate preparation used167cached768sources and72new local encodes',
            sample_count_per_panel=48,runner_elapsed_seconds=summary['elapsed_seconds'],
            fit_call_wall_seconds_total=sum(r['fit_call_wall_seconds'] for r in records)),
        limitations=['Exposed authored development validation is not a fresh holdout.',
            'Generated scalar matches and raw auxiliary slot scores are distinct from exact formula reconstruction.',
            'Cross-dimension systems differ in source producers and parameter counts; paired head comparisons share inputs.',
            'Frozen identity MSE is a construction property, not learned autoencoder reconstruction.',
            'Timing is a single observed CPU run including declared evaluation work, not an isolated inference or bridge-on benchmark.',
            'Strict selection and all negative controls are retained; no result grants Lean or family qualification.'],
        model_executed=False,training_executed=False,encoder_executed=False,qualified=False,admitted=False,lake_executed=False)
    (R / 'training-outcome-review.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(passed=not findings,check_count=len(checks),findings=findings,
        arms=[dict(arm=r['arm'],selected_epoch=r['selected_epoch'],fit_seconds=r['fit_call_wall_seconds'],
            exact=r['roles']['last-attempt']['validation']['generated']['ordered_exact'],
            scalars=r['roles']['last-attempt']['validation']['generated_scalar_matches'],
            raw_scalars=r['roles']['last-attempt']['validation']['raw_auxiliary_scalar_matches']) for r in records])))
    raise SystemExit(bool(findings))


if __name__ == '__main__':
    main()
