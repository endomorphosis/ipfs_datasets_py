import gzip,hashlib,io,json,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=P/'workspace/test-logs/decoder-count-exposure-20261002'
PREV=P/'workspace/test-logs/decoder-cardinality-20261002'
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
E=P/'docs/implementation/reports/evidence/decoder-count-exposure-20261002'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
false=dict(qualified=False,admitted=False,proof_authority=False,source_semantics_verified=False,convergence_proven=False,
 fresh_holdout=False,lake_executed=False,formalized=False,roundtrip_ok=False,checkpoint_promoted=False)
code=read(R/'code-files.json');manifest=read(R/'manifest.json');data=read(R/'smoke-r2/results/summary.json');audit=read(R/'independent-audit.json')
assert data['complete'] and audit['complete'] and not audit['findings']
assert all(sha(P/rel)==digest for rel,digest in manifest['extensions'].items())
corpus=read(Path(manifest['paragraphs']));vocab=corpus['codec']['target_vocabulary']
chosen=[next(row for row in corpus['validation'] if row['clause_count']==n) for n in [1,2,4,8]]
def compact_phase(value):
 return {**value,'source_count':{k:v for k,v in value['source_count'].items() if k!='predictions'}}
samples=[];arms=[]
for x in data['runs']:
 t=x['training'];last={v['id']:v for v in read(R/'smoke-r2/results'/x['arm']/'last-attempt-predictions.json')}
 for row in chosen:
  pred=last[row['id']];text=''.join(vocab[i] for i in pred['token_ids'])
  try: document=json.loads(text)
  except ValueError:document=None
  samples.append(dict(arm=x['arm'],id=row['id'],clause_count=row['clause_count'],source_text=row['source_text'],
   expected_target=row['target'],last_attempt_output_text=text,last_attempt_parsed_document=document,
   generation_status=pred['generation_status'],selected=False,**false))
 arms.append(dict(arm=x['arm'],recipe=x['recipe'],seed=x['seed'],optimizer_steps=t['optimizer_steps'],
  valid_target_token_presentations=t['valid_target_token_presentations'],row_presentations=t['row_presentations'],
  count_training_presentations_by_class=t['count_training_presentations_by_class'],count_mean_loss_exposure_by_class=t['count_mean_loss_exposure_by_class'],
  gradient_norms=t['gradient_norms'],trainable_parameter_count=x['trainable_parameter_count'],fit_seconds=t['elapsed_seconds'],
  whole_arm_elapsed_seconds=x['elapsed_seconds'],postfit_elapsed_seconds=x['postfit_elapsed_seconds'],
  selected_epoch=t['selected_epoch'],selected=compact_phase(t['selected']),last_attempt=compact_phase(t['last_complete_attempt']),
  postfit={role:{label:dict(source_count={k:v for k,v in value['source_count'].items() if k!='predictions'},source_fidelity=value['source_fidelity'],
    numerical=value['numerical'],timing=value['timing']) for label,value in values.items()} for role,values in x['postfit'].items()}))
(R/'sampled-outputs.json').write_text(json.dumps(dict(selection='first archived validation row in each clause-count bin, all four final arms',rows=samples,**false),indent=2)+'\n')
files={}
for rel in set(code)|set(manifest['extensions']):files['source/'+rel]=P/rel
for path in R.iterdir():
 if path.is_file() and path.suffix in ('.json','.log','.xml','.py') and path.name!='publication.json':files['validation/'+path.name]=path
for name in ['smoke-r2','experiment-source']:
 for path in (R/name).rglob('*'):
  if path.is_file():files['validation/'+str(path.relative_to(R))]=path
for path,expected in manifest['inputs'].items():
 q=Path(path);assert sha(q)==expected;files['inputs/'+expected+'/'+q.name]=q
# Exact prior control artifacts needed to reproduce cross-owner parity checks.
for seed in [1729,2718]:
 folder=PREV/'training-r2/results'/('aux_count-'+str(seed))
 for path in folder.rglob('*'):
  if path.is_file():files['prior-control/'+str(path.relative_to(PREV))]=path
for name in ['audit.py','resource-owner-compatibility.json']:
 files['prior-control/'+name]=PREV/name
files['prior-control/cardinality-training-summary.json']=PREV/'training-r2/results/summary.json'
files['prior-control/cardinality-public-manifest.json']=P/'docs/implementation/reports/evidence/decoder-cardinality-20261002/manifest.json'
files['prior-control/source-fidelity-public-manifest.json']=P/'docs/implementation/reports/evidence/decoder-source-fidelity-20261002/manifest.json'
files['prior-control/source-fidelity-manifest-r3.json']=P/'workspace/test-logs/decoder-source-fidelity-20261002/manifest-r3.json'
for rel in ['ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py','ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py']:
 files['historical/dependency-source/'+rel]=S/rel
producers={key.split(':',1)[1]:digest for key,digest in data['source_dependencies'].items()};producers.update(manifest['extensions'])
E.mkdir(parents=True,exist_ok=True);members={};archive=E/'evidence.tar.gz'
with archive.open('xb') as target:
 with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as bundle:
   for name,path in sorted(files.items()):
    content=path.read_bytes();members[name]=dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
    info=tarfile.TarInfo(name);info.size=len(content);info.mtime=0;info.mode=0o644;bundle.addfile(info,io.BytesIO(content))
archive_info=dict(sha256=sha(archive),bytes=archive.stat().st_size)
(E/'manifest.json').write_text(json.dumps(dict(schema='decoder-count-exposure-archive/v1',archive=archive_info,members=members,validated_producer_source_sha256=producers,**false),indent=2)+'\n')
tests={key:0 for key in ['tests','failures','errors','skipped']}
for suite in ET.parse(R/'tests-frozen.xml').getroot().iter('testsuite'):
 for key in tests:tests[key]+=int(suite.get(key,'0'))
assert tests['failures']==tests['errors']==0
record=read(R/'smoke-r2/resources-final.json')['record'];guardian=read(R/'smoke-r2-guardian.log');child=read(R/'smoke-r2/child-exit.json')
obs_path=R/'smoke-r2/resource-observations.json';obs=read(obs_path) if obs_path.exists() else[]
results=dict(schema='decoder-count-exposure-results/v1',scope='exposed authored Legal development only',complete=True,
 dimensions_actually_trained=[384],historical_8d_teacher_modified=False,actual_768d_training_performed=False,
 training_rows=48,validation_rows=48,clauses_per_paragraph=[1,2,4,8],source_token_range=[9,72],target_token_lengths=[40,73,139,271],
 encoder_context_tokens=512,decoder_output_limit=512,generation_temperature=0,guidance_enabled=False,
 numerical_fit_arms=arms,selected_checkpoint_epochs=[x['training']['selected_epoch'] for x in data['runs']],
 selected_quality_gain=any(x['training']['selected_epoch']>0 for x in data['runs']),
 original_donor_sha256=manifest['inputs'][manifest['donor']],frozen_manifest_sha256=sha(R/'manifest.json'),plan_sha256=sha(R/'plan.json'),
 candidate_sha256={rel:sha(P/rel) for rel in code},independent_audit_sha256=sha(R/'independent-audit.json'),
 tests={**tests,'junit_sha256':sha(R/'tests-frozen.xml')},
 telemetry=dict(device='cpu',workers=1,bridge_names=[],legal_ir_evaluate_provers=False,legal_ir_bridge_evaluation_performed=False,
 metric_disk_cache_used=False,paragraph_embedding_cache_used=True,encoder_executed=False,use_sample_memory=False,
 unique_validation_samples=48,fit_seconds_total=sum(x['training']['elapsed_seconds'] for x in data['runs']),
 guardian_elapsed_seconds=guardian['elapsed_seconds'],guardian_elapsed_through_child_exit_seconds=child['guardian_elapsed_through_child_exit_seconds'],
 launch_return_through_reap_wall_seconds=child['launch_return_through_reap_wall_seconds'],child_time_scope=child['child_time_scope'],isolated_child_execution_seconds=None,
 owned_output_bytes=record['final_attempt_bytes'],reservation_bytes=100000000,reservation_released=record['status']=='released',
 observed_peak_child_rss_bytes=max((x['group_rss']['rss_bytes'] for x in obs),default=None),storage_cap_unchanged=True,
 wall_seconds_per_span_scope='numerical evaluator: teacherforced CE plus greedy generation plus copy/integrity; total postfit time including numerical readout and posterior/fidelity/hypothetical scoring recorded separately'),
 limitations=['Previously exposed authored development; no fresh holdout or natural-statute benchmark',
 'Auxiliary balanced exposure updates shared source conditioning as well as count head',
 'Matched labeled-row/update budgets do not equalize wall compute; balanced arm additionally projects count sources',
 'Within-length shuffle preserves count class; hypothetical boundary corrections never applied to generation',
 'Empty qualifier targets do not establish nonempty-qualifier coverage',
 'No native family or Lake validation, checkpoint promotion, or distillation-teacher authority',
 '8D teacher unchanged; local verified768D inputs absent'],archive=archive_info,**false)
(E/'results.json').write_text(json.dumps(results,indent=2)+'\n');(R/'owned-files.json').write_text(json.dumps(code+[str((E/name).relative_to(P)) for name in ['results.json','manifest.json','evidence.tar.gz']],indent=2)+'\n')
print(json.dumps(dict(archive=archive_info,members=len(members),tests=tests)))
