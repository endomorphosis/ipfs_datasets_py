"""Read-only evidence audit for the paired count-exposure experiment.

Only standard-library arithmetic and a SHA-pinned prior audit helper are used.
No Torch import, model generation, training, native parser or prover execution.
Writes one fresh report after durable results exist; never repairs input records.
"""
from collections import Counter
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import math
import random
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
ROOT = Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN = Path(__file__).resolve().parent
PRIOR = ROOT/'workspace/test-logs/decoder-cardinality-20261002'
HELPER = PRIOR/'audit.py'
HELPER_SHA = 'ea440ebb1fc7b978da165329c864a69631be88048f2b694690522674cdc98c47'
FLOAT32_POSTERIOR_SUM_ATOL = 32 * 2**-23
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA:
    raise ValueError('independent arithmetic helper differs from reviewed bytes')
spec = importlib.util.spec_from_file_location('_count_exposure_arithmetic_audit', HELPER)
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
read, check, sha, digest, raw = old.read, old.check, old.sha, old.digest, old.raw
checks, findings, artifacts = old.checks, old.findings, old.artifacts
artifacts[str(HELPER)] = dict(sha256=HELPER_SHA, bytes=HELPER.stat().st_size)
LABELS = [('validation', 'validation', 'conditioned'), ('training', 'train', 'conditioned'),
    ('zero-condition', 'validation', 'zero_condition'), ('source-shuffle', 'validation', 'source_shuffle'),
    ('training-source-shuffle', 'train', 'source_shuffle')]


def subset_equal(candidate, reference):
    if type(reference) is dict:
        return type(candidate) is dict and all(key in candidate and subset_equal(candidate[key], value)
            for key, value in reference.items())
    if type(reference) is list:
        return type(candidate) is list and len(candidate) == len(reference) and all(subset_equal(a, b) for a, b in zip(candidate, reference))
    return type(candidate) is type(reference) and candidate == reference


def probabilities(count, hypothetical, refs, label):
    old.audit_counts(count, refs, label)
    expected = {row['id']: row['clause_count'] for row in refs}
    matrix = {str(value): {str(i): 0 for i in range(1, 33)} for value in sorted(set(expected.values()))}
    log_losses, entropies, confidence = [], [], []
    by_id = {row['id']: row for row in count['predictions']}
    for row in count['predictions']:
        logits, probs = row['logits'], row['probabilities']
        check(len(logits) == len(probs) == 32 and all(type(x) in (int, float) and math.isfinite(x) for x in logits)
            and all(type(x) in (int, float) and math.isfinite(x) and 0 <= x <= 1 for x in probs), label+'/'+row['id']+'/bounded_posterior')
        peak = max(logits); normalizer = sum(math.exp(x-peak) for x in logits)
        normalized = [math.exp(x-peak)/normalizer for x in logits]
        check(all(math.isclose(a, b, rel_tol=3e-6, abs_tol=3e-7) for a, b in zip(probs, normalized))
            and math.isclose(sum(probs), 1., rel_tol=0., abs_tol=FLOAT32_POSTERIOR_SUM_ATOL), label+'/'+row['id']+'/softmax_from_recorded_logits')
        entropy = -sum(p*math.log(p) for p in probs if p > 0)
        check(math.isclose(entropy, row['predictive_entropy'], rel_tol=3e-6, abs_tol=3e-6)
            and 0 <= row['predictive_entropy'] <= math.log(32)+3e-6
            and row['predicted'] == logits.index(peak)+1, label+'/'+row['id']+'/entropy_and_argmax')
        matrix[str(expected[row['id']])][str(row['predicted'])] += 1
        log_losses.append(math.log(normalizer)+peak-logits[expected[row['id']]-1])
        entropies.append(row['predictive_entropy']); confidence.append(max(probs))
    check(matrix == count['confusion_matrix'] and count['confusion_axes'] == 'expected_then_predicted_count', label+'/confusion_matrix')
    check(math.isclose(sum(log_losses)/len(refs), count['cross_entropy'], rel_tol=3e-6, abs_tol=3e-6)
        and sum(entropies)/len(refs) == count['mean_predictive_entropy']
        and sum(confidence)/len(refs) == count['mean_max_probability'], label+'/count_loss_entropy_confidence_means')
    check(hypothetical['guidance_enabled'] is False and hypothetical['applied_to_generation'] is False
        and hypothetical['observed_generation_boundaries'] is False and hypothetical['reference_clause_count_used'] is False
        and hypothetical['uniform_reference_count_classes'] == 32, label+'/hypothetical_not_applied_guidance')
    check(len(hypothetical['rows']) == len(refs) and {row['id'] for row in hypothetical['rows']} == set(expected), label+'/all_hypothetical_rows')
    for row in hypothetical['rows']:
        probs = by_id[row['id']]['probabilities']; values = {}
        for k in (1, 2, 4, 8):
            chosen, tail = probs[k-1], sum(probs[k:]); finite = chosen > 0 and tail > 0
            values[str(k)] = dict(stop_probability=chosen, continuation_probability=tail,
                hypothetical_logit_correction=math.log(chosen)-math.log(tail)+math.log(32-k) if finite else None,
                finite=finite, undefined_reason=None if finite else 'zero probability from numerical support')
        check(values == row['boundaries'], label+'/'+row['id']+'/hypothetical_boundary_arithmetic')


class SelectorReplay:
    """Independent replay of the documented Python RNG stream, never a model."""
    def __init__(self, rows, seed):
        self.seed = seed; self.rng = random.Random(seed)
        self.classes = sorted({row['clause_count'] for row in rows})
        self.order = {value: [row['id'] for row in rows if row['clause_count'] == value] for value in self.classes}
        for items in self.order.values(): self.rng.shuffle(items)
        self.positions = dict.fromkeys(self.classes, 0); self.cycles = dict.fromkeys(self.classes, 0)
        self.cursor = self.draws = 0

    def take(self, count):
        ids = []
        for _ in range(count):
            value = self.classes[self.cursor]; self.cursor = (self.cursor+1) % len(self.classes)
            if self.positions[value] == len(self.order[value]):
                self.rng.shuffle(self.order[value]); self.positions[value] = 0; self.cycles[value] += 1
            ids.append(self.order[value][self.positions[value]])
            self.positions[value] += 1; self.draws += 1
        return ids

    def snapshot(self):
        return dict(schema='training-only-count-round-robin/v1', seed=self.seed, classes=self.classes,
            next_class_index=self.cursor, drawn_rows=self.draws,
            row_order={str(key): value[:] for key, value in self.order.items()},
            row_positions={str(key): value for key, value in self.positions.items()},
            completed_cycles={str(key): value for key, value in self.cycles.items()},
            rng_state_sha256=digest(self.rng.getstate()), replay='original_ordered_training_inventory_plus_seed_and_drawn_rows',
            validation_rows_available=False, decoder_rng_shared=False, state_is_diagnostic_not_optimizer_resume=True)


def exposure(report, corpus, vectors, label):
    rows = corpus['train']; lookup = {row['id']: row for row in rows}
    inventory = [dict(id=row['id'], input=vectors[row['id']], source_text=row['source_text'], count=row['clause_count']) for row in rows]
    check(digest(inventory) == report['count_training_inventory_sha256']
        and report['count_reference_documents_passed_to_model'] is False and report['count_validation_rows_used_for_training'] is False,
        label+'/exact_training_only_source_inventory')
    check(report['count_training_row_presentations'] == report['row_presentations'] == 2440
        and report['count_metrics_used_for_selection'] is False and report['cardinality_weight'] == .25,
        label+'/matched_count_budget_and_scope')
    gradient = report['gradient_norms']
    check(gradient['optimizer_steps'] == report['optimizer_steps'] == 340
        and 0 <= gradient['norm_exceeded_limit_steps'] <= 340 and math.isfinite(gradient['mean_preclip_norm'])
        and math.isfinite(gradient['max_preclip_norm']) and 0 <= gradient['mean_preclip_norm'] <= gradient['max_preclip_norm']
        and gradient['limit'] == report['config']['max_grad_norm'], label+'/bounded_observed_gradient_summary')
    check(report['count_mean_loss_exposure_definition'] == 'sum_over_committed_rows(1/count_batch_size)', label+'/declared_mean_loss_denominator')
    if report['count_exposure'] == 'current_stage':
        expected = Counter()
        for stage in report['curriculum']:
            for identity in stage['training_ids']: expected[str(lookup[identity]['clause_count'])] += stage['epochs']
        check(dict(expected) == report['count_training_presentations_by_class']
            and report['count_selector_initial'] is None and report['count_selector_final'] is None,
            label+'/original_curriculum_count_classes')
        check(sum(report['count_mean_loss_exposure_by_class'].values()) == 340., label+'/mean_loss_weights_sum_to_updates')
        return dict(mode='current_stage', presentations_by_class=dict(expected),
            selector_replay='No separate selector; exact full inherited trajectory comparison verifies parity. Torch minibatch ID digest is recorded but not independently regenerated by this standard-library audit.')
    sampler = SelectorReplay(rows, report['config']['seed'])
    check(sampler.snapshot() == report['count_selector_initial'], label+'/balanced_initial_selector')
    count = Counter({str(k): 0 for k in sampler.classes}); weighted = {str(k): 0. for k in sampler.classes}
    stream = hashlib.sha256(); draws = 0; stage_records = []
    for stage, receipt in zip(report['curriculum'], report['stage_reports']):
        check(sampler.snapshot() == receipt['count_selector_start'] and draws == receipt['count_presentations_start']
            and dict(count) == receipt['count_by_class_start'] and weighted == receipt['count_mean_loss_exposure_start'],
            label+'/'+stage['name']+'/continuous_selector_start')
        for _ in range(stage['epochs']):
            for start in range(0, len(stage['training_ids']), report['config']['batch_size']):
                size = min(report['config']['batch_size'], len(stage['training_ids'])-start)
                ids = sampler.take(size); stream.update(raw(ids)); draws += size
                check(all(identity in lookup for identity in ids), label+'/balanced_train_only_batch/'+str(draws))
                for identity in ids:
                    key = str(lookup[identity]['clause_count']); count[key] += 1; weighted[key] += 1/size
                check(max(count.values())-min(count.values()) <= 1, label+'/round_robin_prefix_balance/'+str(draws))
        check(sampler.snapshot() == receipt['count_selector_end'] and draws == receipt['count_presentations_end']
            and dict(count) == receipt['count_by_class_end'] and weighted == receipt['count_mean_loss_exposure_end'],
            label+'/'+stage['name']+'/continuous_selector_end')
        stage_records.append(dict(stage=stage['name'], total=draws, by_class=dict(count), inverse_batch_weight=dict(weighted)))
    check(draws == 2440 and dict(count) == {str(k): 610 for k in (1, 2, 4, 8)}
        and weighted == {str(k): 85. for k in (1, 2, 4, 8)}, label+'/exact_class_and_mean_loss_balance')
    check(dict(count) == report['count_training_presentations_by_class'] and weighted == report['count_mean_loss_exposure_by_class']
        and stream.hexdigest() == report['committed_count_batch_ids_sha256']
        and sampler.snapshot() == report['count_selector_final'], label+'/every_committed_count_id_digest_and_final_selector')
    return dict(mode='balanced_all', presentations_by_class=dict(count), inverse_batch_weight=weighted,
        all_committed_count_batch_ids_replayed=True, committed_count_batch_ids_sha256=stream.hexdigest(), stages=stage_records)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', default='smoke-r2')
    parser.add_argument('--output', type=Path, default=RUN/'independent-audit.json')
    parser.add_argument('--published-main', default='ace690e14442ba0ec45b886a660a2aa0fb3d186c')
    args = parser.parse_args(); attempt = RUN/args.attempt; results = attempt/'results'
    if not all((attempt/item).is_file() for item in ('results/summary.json', 'resources-final.json', 'command.json', 'child-exit.json')):
        print(json.dumps(dict(status='waiting_for_complete_durable_results'))); return 3
    if args.output.exists(): raise FileExistsError('audit output must be fresh')
    source_sha = sha(__file__)
    command = read(attempt/'command.json'); argv = command['command']
    argument = lambda name: Path(argv[argv.index('--'+name)+1])
    manifest = read(argument('manifest')); plan = read(argument('plan')); source = argument('extension-root'); dependency = argument('dependency-root')
    summary = read(results/'summary.json'); sealed = read(results/'sealed-recipe.json')
    check(sealed['plan'] == plan and sealed['manifest'] == manifest and sha(argument('plan')) == manifest['plan_sha256'], 'pins/sealed_recipe')
    for relative, expected in manifest['extensions'].items(): check(sha(source/relative) == expected, 'pins/extension/'+relative)
    for path, expected in manifest['inputs'].items(): check(sha(path) == expected, 'pins/input/'+path)
    for scoped, expected in summary['source_dependencies'].items():
        scope, relative = scoped.split(':', 1)
        check(scope in ('dependency', 'extension') and sha((dependency if scope == 'dependency' else source)/relative) == expected,
            'pins/loaded_producer/'+scoped)
    prior_archive_relative = 'docs/implementation/reports/evidence/decoder-cardinality-20261002/manifest.json'
    prior_archive = read(ROOT/prior_archive_relative)
    published_prior_archive = subprocess.check_output(['git', 'show', '8e8da5597:'+prior_archive_relative], cwd=ROOT)
    check(sha(ROOT/prior_archive_relative) == hashlib.sha256(published_prior_archive).hexdigest(),
        'pins/immediately_prior_cardinality_archive_bound_to_published_commit')
    ancestor_archive = ROOT/'docs/implementation/reports/evidence/decoder-source-fidelity-20261002/manifest.json'
    read(ancestor_archive)
    check(sha(ancestor_archive) == manifest['source_run_archive_manifest_sha256']
        and sha(ROOT/'workspace/test-logs/decoder-source-fidelity-20261002/manifest-r3.json') == manifest['source_run_manifest_sha256'],
        'pins/inherited_original_source_fidelity_archive_and_run_binding')
    def previous(path):
        path = Path(path); member = 'validation/'+str(path.relative_to(PRIOR)); record = prior_archive['members'][member]
        check(sha(path) == record['sha256'] and path.stat().st_size == record['bytes'], 'pins/prior_published_artifact/'+member)
        return read(path)
    check(prior_archive['members']['validation/audit.py']['sha256'] == HELPER_SHA, 'pins/arithmetic_helper_published_binding')
    prior_summary = previous(PRIOR/'training-r2/results/summary.json'); prior_runs = {row['arm']: row for row in prior_summary['runs']}
    corpus = read(manifest['paragraphs']); donor = read(manifest['donor']); embeddings = read(manifest['embeddings'])
    vectors = {row['input_id']: row['vector'] for row in embeddings['rows']}
    resource = read(attempt/'resources-final.json'); exited = read(attempt/'child-exit.json')
    record = resource['record']
    interrupted = read(RUN/'pre-admission-interruption.json')
    check(interrupted['guardian_exit_verified'] is True and interrupted['owned_reservations_found'] == []
        and interrupted['attempt_directory_created'] is False and interrupted['ledger_mutated_by_recovery'] is False
        and not (RUN/'smoke-r1').exists() and sha(RUN/'smoke-r1-guardian.log') == interrupted['log_sha256'],
        'resources/prior_pre_admission_interruption_preserved')
    check(resource['status'] == 'released' and record['artifacts_durable_asserted'] is True
        and exited['returncode'] == 0 and exited['leader_reaped'] is True
        and record['last_usage']['group_rss']['live_processes'] == 0, 'resources/durable_success_and_release')
    check(record['cpu_slots'] == record['child_process_slots'] == 1 and record['memory_mb'] == 4096
        and record['final_accounting']['limit_bytes'] == 140000000000
        and record['final_accounting']['charged_bytes'] <= 140000000000 and record['attempt_exceeded_reservation'] is False,
        'resources/unchanged_caps_and_one_process')
    old.authority(summary, 'summary')
    check(summary['complete'] is True and len(summary['runs']) == 4 and summary['dimensions_actually_trained'] == [384]
        and summary['encoder_executed'] is False and summary['encoder_context_changed'] is False
        and summary['output_limit_changed'] is False and summary['downloads_performed'] is False
        and summary['bridge_names'] == [] and summary['legal_ir_evaluate_provers'] is False, 'scope/complete_four_exposed_384_arms_no_native')
    expected_arms = {recipe['name']+'-'+str(seed) for recipe in plan['arms'] for seed in plan['seed_order']}
    check({row['arm'] for row in summary['runs']} == expected_arms, 'scope/all_predeclared_arms')
    arm_results = []; parity = []; initial = set(); capacities = set()
    for run in summary['runs']:
        arm = run['arm']; folder = results/arm; report = read(folder/'training.json'); recipe = run['recipe']
        check(report == run['training'] and report['count_exposure'] == recipe['count_exposure']
            and report['config']['max_target_tokens'] == 512 and recipe['guide_boundary'] is False
            and (report['optimizer_steps'], report['valid_target_token_presentations'], report['row_presentations']) == (340, 225840, 2440)
            and report['stopped_reason'] == 'epochs_completed' and run['budget_completed'] is True, arm+'/complete_matched_budget')
        initial.add(report['initial_weights_sha256']); capacities.add(run['trainable_parameter_count'])
        check(report['optimizer_instance_count'] == 1 and report['optimizer_reinitialized_between_stages'] is False, arm+'/one_optimizer')
        for first, second in zip(report['stage_reports'], report['stage_reports'][1:]):
            check(first['optimizer_state_end'] == second['optimizer_state_start']
                and first['optimizer_step_end'] == second['optimizer_step_start'], arm+'/adam_state_continuity/'+second['name'])
        selection = old.audit_selection(report, arm); count_exposure = exposure(report, corpus, vectors, arm)
        state_records = {}; values_by_role = {}
        for role in ('selected', 'last-attempt'):
            state = read(folder/(role+'-state.json')); state_records[role] = state
            expected_hash = report['selected_weights_sha256'] if role == 'selected' else report['last_complete_attempt_weights_sha256']
            check(state['schema'] == 'private-count-exposure-state/v1' and state['role'] == role and state['recipe'] == recipe
                and state['weights_sha256'] == digest(state['model_state'])
                and state['tensor_sha256'] == old.tensor_digest(state['model_state']) == expected_hash, arm+'/'+role+'/strict_state_role_digests')
            check(state['selected'] == (role == 'selected' or report['last_complete_attempt_is_selected'])
                and state['optimizer_resumable'] is False and state['architecture']['guide_boundary'] is False
                and state['architecture']['decoder_reference_count_access'] is False, arm+'/'+role+'/not_promoted_no_count_labels_at_generation')
            old.audit_projections(state['model_state'], donor, report['frozen_parameter_names'], arm+'/'+role)
            old.authority(state, arm+'/'+role)
            original_predictions = read(folder/('selected-predictions.json' if role == 'selected' else 'last-attempt-predictions.json'))
            stored = report['selected'] if role == 'selected' else report['last_complete_attempt']
            values = {}
            for label, split, kind in LABELS:
                value = read(folder/role/('evaluation-'+label+'.json')); refs = corpus[split]
                old.audit_execution(value, refs, vectors, arm+'/'+role+'/'+label, kind)
                old.audit_fidelity(value['source_fidelity'], refs, value['predictions'], donor['codec'], arm+'/'+role+'/'+label)
                probabilities(value['source_count'], value['hypothetical_boundary_diagnostics'], refs, arm+'/'+role+'/'+label)
                compact = dict(numerical=value['report'], source_count=value['source_count'], timing=value['timing'],
                    execution=value['execution'], hypothetical_boundary_diagnostics=value['hypothetical_boundary_diagnostics'],
                    source_fidelity={key: item for key, item in value['source_fidelity'].items() if key != 'rows'})
                check(compact == run['postfit'][role][label], arm+'/'+role+'/'+label+'/complete_summary_binding')
                if label == 'validation':
                    check(value['predictions'] == original_predictions and value['report']['metrics'] == stored['numerical']
                        and compact['source_fidelity'] == stored['fidelity'] and value['source_count'] == stored['source_count'],
                        arm+'/'+role+'/validation_replay_exact')
                values[label] = value
            zero_logits = [row['logits'] for row in values['zero-condition']['source_count']['predictions']]
            check(all(row == zero_logits[0] for row in zero_logits), arm+'/'+role+'/zero_source_count_is_global_bias_only')
            for label, baseline in [('source-shuffle', 'validation'), ('training-source-shuffle', 'training')]:
                original = {row['id']: row['logits'] for row in values[baseline]['source_count']['predictions']}
                assignment = values[label]['execution']['source_assignment']
                check(all(row['logits'] == original[assignment[row['id']]] for row in values[label]['source_count']['predictions']),
                    arm+'/'+role+'/'+label+'/count_predictions_follow_actual_donor_source')
            values_by_role[role] = values
        if recipe['count_exposure'] == 'current_stage':
            prior_arm = 'aux_count-'+str(run['seed']); prior_folder = PRIOR/'training-r2/results'/prior_arm
            prior_report = previous(prior_folder/'training.json')
            old_run = prior_runs[prior_arm]
            keys = ('config', 'initial_weights_sha256', 'selected_weights_sha256', 'last_complete_attempt_weights_sha256',
                'selected_epoch', 'row_presentations', 'valid_target_token_presentations', 'optimizer_steps', 'curriculum',
                'training_rows_sha256', 'validation_rows_sha256', 'training_references_sha256', 'validation_references_sha256',
                'codec_sha256', 'frozen_parameter_names', 'baseline', 'selected', 'last_complete_attempt', 'history', 'stage_reports')
            check(all(subset_equal(report[key], prior_report[key]) for key in keys), arm+'/every_original_metric_history_and_adam_trajectory_exact')
            for role, state in state_records.items():
                original = previous(prior_folder/(role+'-state.json'))
                equal = set(state['model_state']) == set(original['model_state']) and all(old.tensor_bytes(value)
                    == old.tensor_bytes(original['model_state'][key]) for key, value in state['model_state'].items())
                check(equal and state['tensor_sha256'] == original['tensor_sha256'], arm+'/'+role+'/all_inherited_and_count_tensor_bytes_exact')
                for label in ('validation', 'training', 'zero-condition', 'source-shuffle'):
                    prior_value = previous(prior_folder/role/('evaluation-'+label+'.json')); current = values_by_role[role][label]
                    check(current['predictions'] == prior_value['predictions']
                        and current['report']['metrics'] == prior_value['report']['metrics']
                        and current['source_fidelity'] == prior_value['source_fidelity']
                        and subset_equal(current['source_count'], prior_value['source_count']), arm+'/'+role+'/'+label+'/original_control_replay_exact')
                parity.append(dict(arm=arm, previous_arm=prior_arm, role=role, all_tensor_bytes_exact=equal))
        def compact_observation(value):
            return dict(numerical=value['numerical'],
                fidelity={key: value['fidelity'][key] for key in ('metrics', 'by_length', 'by_facet', 'report_sha256')},
                source_count={key: item for key, item in value['source_count'].items() if key != 'predictions'})
        arm_results.append(dict(arm=arm, count_exposure=count_exposure, selection=selection, selected_epoch=report['selected_epoch'],
            selected=compact_observation(report['selected']), last_attempt=compact_observation(report['last_complete_attempt']),
            training_call_seconds=report['elapsed_seconds'], whole_arm_seconds=run['elapsed_seconds'],
            gradient_norms=report['gradient_norms']))
    check(len(initial) == len(capacities) == 1, 'paired_arms/identical_initial_tensors_and_capacity')
    # Inspect publication compatibility without fetching or touching the shared checkout.
    prior_revision = '8e8da5597'
    changed = set(subprocess.check_output(['git', 'diff', '--name-only', prior_revision, args.published_main], cwd=ROOT, text=True).splitlines())
    loaded_paths = {key.split(':', 1)[1] for key in summary['source_dependencies']}
    resource_paths = {'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py',
        'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py'}
    check(not changed & (loaded_paths | resource_paths), 'publication/disjoint_remote_changes')
    compatibility = previous(PRIOR/'resource-owner-compatibility.json')
    current_compatibility = read(RUN/'resource-compatibility.json')
    check(current_compatibility['prior_resource_audit_sha256'] == sha(PRIOR/'resource-owner-compatibility.json')
        and current_compatibility['nested_lease_exercised'] is False
        and current_compatibility['ledger_mutated'] is False, 'resources/previous_root_path_compatibility_bound')
    scheduler_path = resource_paths - {'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py'}
    resource_hashes = {}
    for relative in resource_paths:
        frozen = dependency/relative; old_hash = sha(frozen)
        published = subprocess.check_output(['git', 'show', args.published_main+':'+relative], cwd=ROOT)
        resource_hashes[relative] = dict(executed_sha256=old_hash, published_sha256=hashlib.sha256(published).hexdigest(),
            executed_owner_is_published_owner=old_hash == hashlib.sha256(published).hexdigest())
        check(resource_hashes[relative]['published_sha256'] == current_compatibility['published_owner_sha256'][relative],
            'resources/published_owner_binding/'+relative)
    check(resource_hashes['ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py']['executed_sha256']
        == current_compatibility['executed_historical_owner']['sha256'], 'resources/executed_historical_owner_binding')
    check(resource_hashes[next(iter(scheduler_path))]['executed_sha256'] == compatibility['scheduler']['sha256'], 'resources/historical_scheduler_unchanged')
    test_suites = []
    for path in sorted(RUN.glob('*tests*.xml')):
        tree = ET.parse(path).getroot(); suites = list(tree.iter('testsuite'))
        counts = {key: sum(int(item.attrib.get(key, 0)) for item in suites) for key in ('tests', 'failures', 'errors', 'skipped')}
        test_suites.append(dict(path=str(path), sha256=sha(path), **counts))
    check(test_suites and all(row['failures'] == row['errors'] == 0 for row in test_suites), 'tests/recorded_suites_pass')
    check(sha(__file__) == source_sha and sha(HELPER) == HELPER_SHA, 'pins/audit_owners_unchanged')
    groups = {}
    for item in checks:
        bucket = groups.setdefault(item['check'].split('/', 1)[0], dict(passed=0, failed=0))
        bucket['passed' if item['passed'] else 'failed'] += 1
    result = dict(schema='independent-decoder-count-exposure-audit/v1', complete=True,
        created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        verdict='blocking_findings' if findings else 'no_blocking_correctness_issue_found', findings=findings,
        checked_count=len(checks), failed_check_count=len(findings), checks=groups,
        check_detail_policy='Pass counts grouped to avoid repeated evidence; every failed check retained verbatim in findings. Exact audit program and input hashes permit replay.',
        all_pins_match=all(row['passed'] for row in checks if row['check'].startswith('pins/')),
        arms=arm_results, current_stage_parity=parity, tests=test_suites,
        test_count_note='Receipts may overlap; do not add their test counts.', resource_status=resource['status'],
        posterior_audit_precision=dict(sum_absolute_tolerance=FLOAT32_POSTERIOR_SUM_ATOL,
            sum_tolerance_basis='32 float32 components times 2^-23; audit arithmetic only, no training/selection gate change',
            component_relative_tolerance=3e-6, component_absolute_tolerance=3e-7),
        publication_compatibility=dict(tested_base=prior_revision, inspected_main=args.published_main,
            changed_path_count=len(changed), loaded_or_resource_overlap=sorted(changed & (loaded_paths | resource_paths))),
        resource_owner_comparison=resource_hashes, historical_nested_lease_validation_performed=False,
        preserved_pre_admission_interruption=interrupted,
        artifacts=artifacts, audit_source_sha256=source_sha, audit_helper_sha256=HELPER_SHA,
        limitations=['Previously exposed authored train/validation, no fresh holdout or natural-statute quality claim.',
            'Count metrics and reference agreement grant no native, Lake, semantic, or production-checkpoint authority.',
            'Balanced count labels come only from training but their gradients also reach shared source conditioning.',
            'Balanced count batches require extra source projection; equal steps/presentations do not imply equal wall compute.',
            'Standard-library audit exactly replays balanced sampler IDs; current-stage Torch randperm ID order is not independently regenerated.',
            'Current-stage full actual tensors/Adam and numerical trajectories are compared to the published previous auxiliary-count run.',
            'Rule validity decisions come from recorded canonical checks; the auditor checks arithmetic without rerunning parsers or models.',
            'Same-count shuffle cannot test count generalization; boundary corrections here are hypothetical and never applied.',
            'Historical resource owner is disclosed separately from published optional nested-lease support.',
            '8D linguistic teacher/768D lineage are unchanged; fixed384D cached vectors only.'],
        model_executed_by_auditor=False, native_executed_by_auditor=False, **{key: False for key in old.AUTHORITY})
    with args.output.open('xb') as stream:
        stream.write(json.dumps(result, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False).encode()+b'\n')
    print(json.dumps(dict(path=str(args.output), sha256=sha(args.output), bytes=args.output.stat().st_size,
        verdict=result['verdict'], checks=len(checks), findings=findings)))
    return int(bool(findings))


if __name__ == '__main__':
    raise SystemExit(main())
