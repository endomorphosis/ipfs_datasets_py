"""Long source-span decoder guardian: stop the owned group before retaining failure.

Adapted from the reviewed prior run_reserved_next.py. Importing it never starts
the benchmark or creates a resource reservation. A new explicit attempt name is
required when intentionally executing the benchmark later.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

PACKAGE = Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN = Path(__file__).resolve().parent
SOURCE = PACKAGE / 'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'


def resource_owner():
    sys.path.insert(0, str(SOURCE))
    sys.dont_write_bytecode = True
    from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_daemon_resources
    if not Path(autoencoder_daemon_resources.__file__).resolve().is_relative_to(SOURCE):
        raise RuntimeError('resource owner loaded outside the frozen validation tree')
    return autoencoder_daemon_resources


def capture_owned_child(child, resources):
    """Capture PID birth before poll/wait can reap a short-lived leader."""
    identity = resources._process(child.pid)
    if (identity is None or identity['parent_pid'] != os.getpid()
            or identity['group_pid'] != child.pid):
        raise RuntimeError('new child is not an owned isolated process-group leader')
    return {key: identity[key] for key in ('pid', 'birth')}


def cleanup_owned_group(child, identity, resources, *, grace_seconds=60., kill_seconds=5.):
    """Stop surviving descendants even after their leader has exited.

    The existing owner's group inspector checks the recorded leader birth and
    refuses PID reuse. Never infer group death from Popen.poll alone. Group exit
    between inspection and signaling is benign; an unverified identity or a
    surviving live process remains an error. Reap the direct child only; orphan
    zombies are their new parent's responsibility and are not live processes.
    """
    for value in (grace_seconds, kill_seconds):
        if type(value) not in (int, float) or not math.isfinite(value) or not 0 < value <= 60:
            raise ValueError('cleanup waits must be finite and at most sixty seconds')
    if child is None:
        return {'child_created': False, 'leader_reaped': True, 'live_group_processes': 0}
    if (type(identity) is not dict or set(identity) != {'pid', 'birth'}
            or identity['pid'] != child.pid or type(identity['birth']) is not str):
        raise ValueError('exact captured child identity required for cleanup')
    initial = resources._group_usage(identity)
    events = []

    def signal_if_alive(value):
        # Recheck identity immediately before every signal, including SIGKILL.
        usage = resources._group_usage(identity)
        if not usage['live_processes']:
            return
        record = {'signal': signal.Signals(value).name,
                  'observed_live_processes': usage['live_processes']}
        try:
            os.killpg(identity['pid'], value)
            record['status'] = 'sent'
        except ProcessLookupError:
            record['status'] = 'group_already_exited'
        events.append(record)

    def wait_group(seconds):
        deadline = time.monotonic() + seconds
        while True:
            usage = resources._group_usage(identity)
            child.poll()  # Reap the direct leader without waiting for descendants.
            if not usage['live_processes'] or time.monotonic() >= deadline:
                return usage
            time.sleep(min(.05, max(0., deadline - time.monotonic())))

    signal_if_alive(signal.SIGINT)
    final = wait_group(grace_seconds)
    if final['live_processes']:
        signal_if_alive(signal.SIGKILL)
        final = wait_group(kill_seconds)
    if final['live_processes']:
        raise RuntimeError('owned process group remains alive after bounded cleanup')
    try:
        code = child.wait(timeout=kill_seconds)
    except subprocess.TimeoutExpired as error:
        raise RuntimeError('direct child was not reaped after group cleanup') from error
    final = resources._group_usage(identity)
    if final['live_processes']:
        raise RuntimeError('owned group became live again during cleanup')
    return {'child_created': True, 'identity': dict(identity),
            'initial_live_processes': initial['live_processes'], 'signals': events,
            'leader_reaped': True, 'leader_returncode': code,
            'live_group_processes': 0, 'final_group_usage': final,
            'scope': 'direct_child_reaped; surviving_group_members_stopped; orphan_zombies_not_reaped_here'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', required=True,
                        help='fresh directory name under this evidence folder; never development-r1')
    args = parser.parse_args()
    if (not args.attempt or Path(args.attempt).name != args.attempt
            or args.attempt in ('.', '..', 'development-r1')):
        raise ValueError('fresh single-component attempt name required')
    attempt = RUN / args.attempt
    if attempt.exists():
        raise ValueError('attempt already exists; completed evidence is immutable')
    # Refuse an incomplete or altered freeze before acquiring any reservation.
    manifest = json.loads((RUN/'manifest.json').read_bytes())
    def sha(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()
    if sha(RUN/'plan.json') != manifest['plan_sha256']:
        raise ValueError('sealed plan changed before admission')
    for relative, expected in manifest['extensions'].items():
        if sha(RUN/'experiment-source'/relative) != expected:
            raise ValueError('frozen extension changed before admission: '+relative)
    for path, expected in manifest['inputs'].items():
        if sha(Path(path)) != expected:
            raise ValueError('sealed input changed before admission: '+path)
    resources = resource_owner()
    roots = [PACKAGE/'workspace/test-logs', PACKAGE/'workspace/todo-queues',
             PACKAGE/'docs/implementation/reports/evidence', Path('/tmp/pytest-of-barberb')]
    ledger = roots[0]/'federal-corpus-audits/owned-daemon-resource-control/disk-reservations.json'
    owner = resources.DaemonResourceReservation(ledger, roots=roots, storage_bytes=100_000_000,
        memory_mb=4096, cpu_slots=1, child_process_slots=1, timeout_seconds=300,
        ledger_lock_timeout_seconds=60)
    command = [sys.executable, str(RUN/'experiment-source/scripts/ops/autoencoder/benchmark_decoder_count_exposure.py'),
        '--dependency-root', str(SOURCE), '--extension-root', str(RUN/'experiment-source'),
        '--manifest', str(RUN/'manifest.json'), '--plan', str(RUN/'plan.json'),
        '--output', str(attempt/'results')]

    def save(name, data):
        with (attempt/name).open('w') as stream:
            json.dump(data, stream, sort_keys=True, indent=2)
            stream.write('\n'); stream.flush(); os.fsync(stream.fileno())

    def sync_tree():
        for path in attempt.rglob('*'):
            if path.is_file() and not path.is_symlink():
                with path.open('rb') as stream:
                    os.fsync(stream.fileno())
        directories = [attempt] + [p for p in attempt.rglob('*') if p.is_dir()]
        for path in sorted(directories, key=lambda p: len(p.parts), reverse=True):
            fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
            try: os.fsync(fd)
            finally: os.close(fd)

    child = identity = cleanup = None
    started = time.monotonic()
    try:
        with owner:
            try:
                attempt.mkdir()
                save('command.json', {'command': command, 'cwd': str(SOURCE),
                    'scheduler_scope': 'one reserved CPU, numerical development only; no native admission',
                    'outer_cpu_slots': 1, 'outer_memory_mb': 4096,
                    'outer_child_process_slots': 1, 'storage_bytes': 100_000_000,
                    'guardian_revision': 'run_reserved.py',
                    'outer_admission_timeout_seconds': 300})
                with (attempt/'child.log').open('w') as log:
                    env = dict(os.environ, PYTHONPATH=str(SOURCE), PYTHONDONTWRITEBYTECODE='1',
                        HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1',
                        IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI='0', IPFS_DATASETS_LEGAL_IR_METRIC_DISK_CACHE='0', CUDA_VISIBLE_DEVICES='',
                        OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
                    child = subprocess.Popen(command, cwd=SOURCE, env=env, stdout=log,
                        stderr=subprocess.STDOUT, start_new_session=True)
                    child_started = time.monotonic()
                    identity = capture_owned_child(child, resources)
                    save('child-identity.json', identity)
                    observations = [owner.check_usage(attempt, child.pid)]
                    save('resources-start.json', owner.to_dict())
                    while child.poll() is None:
                        time.sleep(5)
                        if child.poll() is None:
                            if time.monotonic()-child_started > 600:
                                raise TimeoutError('owned training child exceeded campaign deadline')
                            observations.append(owner.check_usage(attempt, child.pid))
                            save('resource-observations.json', observations)
                    code = child.wait()
                    log.flush(); os.fsync(log.fileno())
                save('child-exit.json', {'returncode': code,
                    'guardian_elapsed_through_child_exit_seconds': time.monotonic()-started,
                    'launch_return_through_reap_wall_seconds': time.monotonic()-child_started,
                    'child_time_scope': 'includes monitoring and accounting before reap; excludes initial admission',
                    'isolated_child_execution_seconds': None, 'leader_reaped': True})
                if code:
                    raise RuntimeError(f'development child failed: {code}')
                if not (attempt/'results/summary.json').is_file():
                    raise RuntimeError('successful child did not produce summary')
                sync_tree()
                released = owner.finalize(attempt, artifacts_durable=True)
                save('resources-final.json', released)
                sync_tree()
                print(json.dumps({'status': 'complete', 'returncode': code,
                    'elapsed_seconds': time.monotonic()-started, 'resources': released}), flush=True)
            except BaseException as error:
                # Stop the entire group BEFORE owner.__exit__ retains the disk
                # claim and decides whether its scheduler lease can be released.
                try:
                    cleanup = cleanup_owned_group(child, identity, resources)
                except BaseException as cleanup_error:
                    cleanup = {'error': repr(cleanup_error), 'cleanup_verified': False}
                    error.add_note('Owned-group cleanup failed: ' + repr(cleanup_error))
                raise
    except BaseException as error:
        if child is None and owner._entered:
            attempt.mkdir(exist_ok=True)
            save('admission-failure.json', {'error': repr(error), 'model_started': False,
                'owner_pid': os.getpid(), 'resources': owner.to_dict()})
            owner.check_usage(attempt)
            sync_tree()
            save('unused-reservation-final.json', owner.finalize(attempt, artifacts_durable=True))
            sync_tree()
        if attempt.exists():
            try:
                save('failure.json', {'error': repr(error), 'cleanup': cleanup,
                    'elapsed_seconds': time.monotonic()-started, 'resources': owner.to_dict(),
                    'leader_reaped': child is None or child.poll() is not None})
                sync_tree()
            except BaseException as evidence_error:
                error.add_note('Failure evidence write failed: ' + repr(evidence_error))
        raise


if __name__ == '__main__':
    main()
