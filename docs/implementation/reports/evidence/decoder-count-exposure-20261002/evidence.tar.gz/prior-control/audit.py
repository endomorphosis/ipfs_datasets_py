"""Independent persisted-evidence arithmetic audit; no model/native imports.

Execute only after the requested attempt summaries and resource-final receipts
exist. This never repairs evidence or promotes a saved state. Its one output is
a fresh audit JSON file; reruns require another explicit --output filename.
"""
from collections import Counter
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import math
import re
import struct
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
ROOT = Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN = Path(__file__).resolve().parent
FACETS = ('modality', 'actor', 'action', 'object', 'conditions', 'exceptions', 'temporal')
ROLES = (*FACETS, 'continue', 'stop', 'eos', 'structure')
MAXIMIZE = ('ordered_exact', 'all_rules_preserved', 'eos_count', 'syntax_valid')
MINIMIZE = ('whole_rules_missing', 'whole_rules_extra', 'invalid_rule_count', 'invalid_rows',
    'unscorable_generation_rows', 'prediction_missing_rows')
AUTHORITY = ('qualified', 'admitted', 'proof_authority', 'source_semantics_verified', 'fresh_holdout',
    'convergence_proven', 'checkpoint_promoted', 'lake_executed', 'formalized', 'roundtrip_ok')
checks, findings, artifacts = [], [], {}


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(raw(value)).hexdigest()


def read(path):
    path = Path(path)
    def unique(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError('duplicate persisted JSON key')
            value[key] = item
        return value
    def invalid(value):
        raise ValueError('nonfinite JSON constant: '+value)
    result = json.loads(path.read_bytes(), object_pairs_hook=unique, parse_constant=invalid)
    artifacts[str(path)] = dict(sha256=sha(path), bytes=path.stat().st_size)
    return result


def check(condition, label, detail=None):
    checks.append(dict(check=label, passed=bool(condition)))
    if not condition:
        findings.append(dict(priority='blocking', finding=label, detail=detail))


def approx(left, right):
    if type(left) is dict and type(right) is dict:
        return set(left) == set(right) and all(approx(value, right[key]) for key, value in left.items())
    if type(left) is list and type(right) is list:
        return len(left) == len(right) and all(approx(a, b) for a, b in zip(left, right))
    if type(left) is float or type(right) is float:
        return type(left) in (int, float) and type(right) in (int, float) and math.isclose(left, right, rel_tol=1e-10, abs_tol=1e-10)
    return type(left) is type(right) and left == right


def shape(value):
    if type(value) is not list:
        if type(value) not in (int, float) or not math.isfinite(value):
            raise ValueError('nonfinite or nonnumeric tensor')
        return []
    child = shape(value[0]) if value else []
    if any(shape(item) != child for item in value):
        raise ValueError('ragged tensor')
    return [len(value)] + child


def flat(value):
    if type(value) is list:
        for child in value:
            yield from flat(child)
    else:
        yield value


def tensor_bytes(value):
    shape(value)
    return b''.join(struct.pack('<f', item) for item in flat(value))


def tensor_digest(values):
    result = hashlib.sha256()
    for name, value in sorted(values.items()):
        result.update(raw([name, 'torch.float32', shape(value)]))
        result.update(tensor_bytes(value))
    return result.hexdigest()


def authority(value, label):
    failures = []
    def visit(item, path):
        if type(item) is dict:
            for key, child in item.items():
                if key in AUTHORITY and child is not False:
                    failures.append('/'.join((*path, key)))
                visit(child, (*path, key))
        elif type(item) is list:
            for index, child in enumerate(item):
                visit(child, (*path, str(index)))
    visit(value, ())
    check(not failures, label+'/false_authority', failures)


def begin_attempt(name):
    path = RUN/name
    command = read(path/'command.json')
    argv = command['command']
    argument = lambda name: Path(argv[argv.index('--'+name)+1])
    manifest = read(argument('manifest')); plan = read(argument('plan'))
    source = argument('extension-root'); dependency = argument('dependency-root')
    results = path/'results'; summary = read(results/'summary.json')
    sealed = read(results/'sealed-recipe.json')
    check(sealed['plan'] == plan and sealed['manifest'] == manifest, name+'/sealed_recipe_identity')
    check(sha(argument('plan')) == manifest['plan_sha256'], name+'/pin/recipe')
    for relative, expected in manifest['extensions'].items():
        check(sha(source/relative) == expected, name+'/pin/extension/'+relative)
    for filename, expected in manifest['inputs'].items():
        check(Path(filename).is_absolute() and sha(filename) == expected, name+'/pin/input/'+filename)
    for scoped, expected in summary['source_dependencies'].items():
        scope, relative = scoped.split(':', 1)
        check(scope in ('dependency', 'extension'), name+'/producer_scope/'+scoped)
        check(sha((dependency if scope == 'dependency' else source)/relative) == expected, name+'/pin/producer/'+scoped)
    resource = read(path/'resources-final.json'); exit_receipt = read(path/'child-exit.json')
    check(resource['status'] == 'released' and resource['record']['artifacts_durable_asserted'] is True
        and exit_receipt['returncode'] == 0 and exit_receipt['leader_reaped'] is True, name+'/durable_success_and_release')
    record = resource['record']
    check(record['cpu_slots'] == record['child_process_slots'] == 1 and record['memory_mb'] == 4096,
        name+'/one_reserved_process_cpu_and_4gib')
    check(record['final_accounting']['limit_bytes'] == 140000000000
        and record['final_accounting']['charged_bytes'] <= 140000000000
        and record['last_usage']['group_rss']['live_processes'] == 0
        and record['attempt_exceeded_reservation'] is False, name+'/unchanged_storage_cap_and_dead_child')
    check(summary['complete'] is True and summary['encoder_executed'] is False
        and summary['encoder_context_changed'] is False and summary['downloads_performed'] is False
        and summary['bridge_names'] == [] and summary['legal_ir_evaluate_provers'] is False,
        name+'/complete_exposed_cached_no_native_scope')
    authority(summary, name+'/summary')
    corpus = read(manifest['paragraphs']); donor = read(manifest['donor']); embeddings = read(manifest['embeddings'])
    return dict(name=name, path=path, results=results, manifest=manifest, plan=plan, source=source,
        dependency=dependency, summary=summary, resource=resource, corpus=corpus, donor=donor,
        vectors={row['input_id']: row['vector'] for row in embeddings['rows']}, exit=exit_receipt)


def audit_fidelity(doc, refs, predictions, codec, label):
    check(doc['report_sha256'] == digest({key: value for key, value in doc.items() if key != 'report_sha256'}), label+'/fidelity_hash')
    lookup = {row['id']: row for row in refs}; pred = {row['id']: row for row in predictions}
    check(len(doc['rows']) == len(refs) == len(predictions) == len(pred)
        and set(pred) == set(lookup), label+'/all_reference_and_prediction_ids')
    counters = tuple(doc['metrics']); totals = dict.fromkeys(counters, 0)
    facets = {key: dict(correct=0, total=0, unordered_correct=0) for key in FACETS}; lengths = {}
    for row in doc['rows']:
        identity = row['id']; ref = lookup[identity]; prediction = pred[identity]
        gold = ref['target']['rules']; actual = row['generated_ir']
        check(row['expected_ir'] == ref['target'] and row['target_sha256'] == digest(ref['target'])
            and row['generated_token_ids'] == prediction['token_ids'], label+'/'+identity+'/exact_input_output_bindings')
        if actual is not None:
            check(json.loads(''.join(codec['target_vocabulary'][i] for i in prediction['token_ids'])) == actual,
                label+'/'+identity+'/generated_token_decode')
        generated = actual['rules'] if type(actual) is dict and set(actual) == {'rules'} and type(actual['rules']) is list else []
        bad = {int(match.group(1)) for error in row['errors'] for match in [re.match(r'rule\[(\d+)\]:', error)] if match}
        valid = {i: item for i, item in enumerate(generated) if i not in bad}
        expected = Counter(raw(rule) for rule in gold); observed = Counter(raw(rule) for rule in valid.values())
        matched = sum((expected & observed).values())
        check(row['counts']['whole_rules_missing'] == len(gold)-matched
            and row['counts']['whole_rules_extra'] == len(generated)-matched
            and bool(row['counts']['ordered_exact']) == (prediction['eos_reached'] and not row['errors'] and actual == ref['target']),
            label+'/'+identity+'/multiplicity_and_order')
        expected_facets = {}
        for field in FACETS:
            expected_facets[field] = dict(correct=sum(i in valid and valid[i][field] == item[field] for i, item in enumerate(gold)),
                total=len(gold), unordered_correct=sum((Counter(raw(item[field]) for item in gold)
                    & Counter(raw(item[field]) for item in valid.values())).values()))
        check(expected_facets == row['by_facet'], label+'/'+identity+'/seven_facets')
        bucket = lengths.setdefault(str(ref['clause_count']), dict(metrics=dict.fromkeys(counters, 0),
            by_facet={key: dict(correct=0, total=0, unordered_correct=0) for key in FACETS}))
        for key in counters:
            totals[key] += row['counts'][key]; bucket['metrics'][key] += row['counts'][key]
        for field in FACETS:
            for key in facets[field]:
                facets[field][key] += row['by_facet'][field][key]
                bucket['by_facet'][field][key] += row['by_facet'][field][key]
    check(totals == doc['metrics'] and lengths == doc['by_length'] and facets == doc['by_facet'], label+'/complete_aggregates')
    authority(doc, label+'/fidelity')


def audit_execution(evaluation, refs, vectors, label, expected_kind):
    report = evaluation['report']; execution = evaluation['execution']; predictions = evaluation['predictions']
    assignment = execution['source_assignment']; lookup = {row['id']: row for row in refs}
    check(report['complete'] and report['optimizer_steps'] == 0 and report['weight_selection_performed'] is False
        and execution['training_performed'] is False and execution['selection_performed'] is False
        and report['generation_target_access'] is False and report['generation_temperature'] == 0
        and report['max_target_tokens'] == 512 and report['input_dimension'] == 384, label+'/fixed_weights_target_free_generation')
    check(execution['kind'] == expected_kind and set(assignment) == set(assignment.values()) == set(lookup), label+'/control_identities')
    if expected_kind == 'source_shuffle':
        check(all(k != v and lookup[k]['clause_count'] == lookup[v]['clause_count'] for k, v in assignment.items()), label+'/same_length_derangement')
        expected = {k: dict(original_input_sha256=digest(vectors[k]), substituted_input_sha256=digest(vectors[v])) for k, v in assignment.items()}
        check(expected == execution['input_substitutions'] and all(vectors[k] != vectors[v] for k, v in assignment.items()), label+'/real_changed_source_vectors')
    else:
        check(all(k == v for k, v in assignment.items()), label+'/original_source_assignment')
    metrics = report['metrics']
    check(metrics['count'] == len(refs) == len(predictions)
        and metrics['target_token_count'] == sum(len(row['target_ids'])-1 for row in refs)
        and metrics['eos_count'] == sum(row['eos_reached'] for row in predictions)
        and metrics['exact_targets'] == sum(row['exact_target'] for row in predictions)
        and metrics['output_limit_count'] == sum(row['generation_status'] == 'output_limit' for row in predictions), label+'/numerical_generation_counts')
    authority(evaluation, label+'/evaluation')


def expected_roles(reference, codec):
    """Separate lexical/index audit of seven-facet reference token roles."""
    wire = json.dumps(reference['target'], sort_keys=True, separators=(',', ':'), ensure_ascii=True)
    tokens = re.findall(r'"(?:\\.|[^"\\])*"|[{}\[\],:]', wire)
    if ''.join(tokens) != wire:
        raise ValueError('reference outside reviewed scalar/list token fragment')
    roles = ['structure']*len(tokens)
    depth = 0
    for i, token in enumerate(tokens):
        if token == '{': depth += 1
        elif token == '}':
            depth -= 1
            if depth == 1:
                if tokens[i+1] == ',': roles[i+1] = 'continue'
                elif tokens[i+1] == ']': roles[i+1] = 'stop'
        if token.startswith('"') and i+1 < len(tokens) and tokens[i+1] == ':':
            field = json.loads(token)
            if field not in FACETS: continue
            at = i+2
            if tokens[at] != '[': roles[at] = field
            elif tokens[at+1] == ']': roles[at] = roles[at+1] = field
            else:
                at += 1
                while tokens[at] != ']':
                    if tokens[at].startswith('"'): roles[at] = field
                    at += 1
    lookup = {value: i for i, value in enumerate(codec['target_vocabulary'])}
    if [1]+[lookup[token] for token in tokens]+[2] != reference['target_ids']:
        raise ValueError('independent reference lexical encoder differs')
    return roles+['eos']


def audit_nll(evaluation, refs, codec, label):
    nll = evaluation['teacher_forced_nll']; lookup = {row['id']: row for row in refs}
    new_bins = lambda: {role: dict(nll_sum=0., token_count=0, mean_nll=None) for role in ROLES}
    finish = lambda bins: {role: {**value, 'mean_nll': value['nll_sum']/value['token_count'] if value['token_count'] else None}
        for role, value in bins.items()}
    overall, lengths = new_bins(), {}
    check(nll['complete'] is True and nll['teacher_forced'] is True and nll['generation_metrics'] is False
        and nll['training_performed'] is False and nll['selection_performed'] is False, label+'/separate_fixed_prefix_diagnostic')
    check(len(nll['rows']) == len(refs) and {r['id'] for r in nll['rows']} == set(lookup), label+'/nll_all_rows')
    for row in nll['rows']:
        reference = lookup[row['id']]; expected = expected_roles(reference, codec)
        check(row['token_roles'] == expected and len(row['token_nll']) == len(expected)
            and all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in row['token_nll']),
            label+'/'+row['id']+'/full_prefix_and_role_binding')
        local = new_bins(); bucket = lengths.setdefault(str(reference['clause_count']), new_bins())
        for role, loss in zip(row['token_roles'], row['token_nll']):
            for bins in (local, bucket, overall):
                bins[role]['nll_sum'] += loss; bins[role]['token_count'] += 1
        check(approx(finish(local), row['by_role']), label+'/'+row['id']+'/nll_sums')
    check(approx(finish(overall), nll['by_role'])
        and approx({key: finish(value) for key, value in lengths.items()}, nll['by_length']), label+'/nll_aggregates')
    total = sum(value['token_count'] for value in overall.values()); mean = sum(value['nll_sum'] for value in overall.values())/total
    check(total == nll['target_token_count'] == evaluation['report']['metrics']['target_token_count']
        and math.isclose(mean, nll['mean_nll'], rel_tol=1e-12, abs_tol=1e-12)
        and math.isclose(mean, evaluation['report']['metrics']['token_cross_entropy'], rel_tol=1e-6, abs_tol=1e-7), label+'/nll_reconciles_original_ce')


def audit_comparison(comparison, baseline, negative, label):
    left = {row['id']: row for row in baseline['predictions']}; right = {row['id']: row for row in negative['predictions']}
    changed = [identity for identity in left if left[identity]['token_ids'] != right[identity]['token_ids']
        or left[identity]['generation_status'] != right[identity]['generation_status']]
    check(comparison['predictions']['changed_ids'] == changed and comparison['predictions']['row_count'] == len(left)
        and comparison['predictions']['generated_sequence_or_status_changed'] == len(changed), label+'/generated_sequence_changes')
    a, b = baseline['teacher_forced_nll'], negative['teacher_forced_nll']; gap = comparison['teacher_forced_nll']
    check(gap['mean_counterfactual_minus_conditioned'] == b['mean_nll']-a['mean_nll'], label+'/ce_gap')
    pairs = [(gap['by_role'], a['by_role'], b['by_role'])]
    pairs += [(gap['by_length'][length], value, b['by_length'][length]) for length, value in a['by_length'].items()]
    for index, (reported, first, second) in enumerate(pairs):
        expected = {role: dict(token_count=first[role]['token_count'], conditioned_mean_nll=first[role]['mean_nll'],
            counterfactual_mean_nll=second[role]['mean_nll'], counterfactual_minus_conditioned=None
                if not first[role]['token_count'] else second[role]['mean_nll']-first[role]['mean_nll']) for role in ROLES}
        check(expected == reported and all(first[role]['token_count'] == second[role]['token_count'] for role in ROLES),
            label+'/role_and_length_gap/'+str(index))


def audit_projections(values, donor, names, label):
    check(len(names) == 4 and len(set(names)) == 4, label+'/exact_four_frozen_tensors')
    for name in names:
        parent_name = name
        while parent_name.startswith('body.'): parent_name = parent_name[5:]
        check(parent_name.startswith(('projection_down.', 'projection_up.'))
            and tensor_bytes(values[name]) == tensor_bytes(donor['model_state'][parent_name]), label+'/parent_projection_bytes/'+name)


def audit_controls(ctx):
    summary, manifest, folder = ctx['summary'], ctx['manifest'], ctx['results']
    original = read(manifest['source_run_summary']); old = {row['arm']: row for row in original['runs']}
    check(len(summary['runs']) == 8 and {row['arm'] for row in summary['runs']} == set(old), 'controls/all_eight_archived_arms')
    check(summary['optimizer_steps'] == 0 and summary['training_performed'] is False and summary['selection_performed'] is False,
        'controls/no_training_or_selection')
    results = []
    for run in summary['runs']:
        arm = run['arm']; pointers = manifest['rejected_states'][arm]
        state = read(pointers['state']); training = read(pointers['training']); predictions = read(pointers['predictions'])
        check(old[arm]['training'] == training and digest(state['model_state']) == state['weights_sha256']
            and run['saved_state_sha256'] == sha(pointers['state'])
            and tensor_digest(state['model_state']) == run['tensor_weights_sha256'], arm+'/original_unselected_state_role_and_hash')
        check(state['selected'] is False and run['candidate_was_selected'] is False
            and training['last_complete_attempt_is_selected'] is False
            and run['original_selected_epoch'] == training['selected_epoch'], arm+'/unselected_role_preserved')
        check(run['architecture_specification']['conditioning'] == state['architecture']
            and run['architecture_specification']['model_weights_sha256'] == run['tensor_weights_sha256'], arm+'/architecture_mode_and_tensor_identity')
        authority(state, arm+'/saved_state'); audit_projections(state['model_state'], ctx['donor'], run['frozen_parameter_names'], arm)
        evaluations = {}
        for label, split, kind in [('validation', 'validation', 'conditioned'), ('training', 'train', 'conditioned'),
                ('zero-condition', 'validation', 'zero_condition'), ('source-shuffle', 'validation', 'source_shuffle'),
                ('training-source-shuffle', 'train', 'source_shuffle')]:
            path = folder/arm/('evaluation-'+label+'.json'); value = read(path); refs = ctx['corpus'][split]
            check(run['evaluations'][label] == dict(path=str(path), sha256=sha(path), bytes=path.stat().st_size), arm+'/'+label+'/artifact_binding')
            audit_execution(value, refs, ctx['vectors'], arm+'/'+label, kind)
            audit_fidelity(value['source_fidelity'], refs, value['predictions'], ctx['donor']['codec'], arm+'/'+label)
            audit_nll(value, refs, ctx['donor']['codec'], arm+'/'+label)
            check(run['numerical'][label] == value['report']['metrics']
                and run['fidelity'][label] == {key: item for key, item in value['source_fidelity'].items() if key != 'rows'}, arm+'/'+label+'/summary_exact')
            evaluations[label] = value
            if label == 'validation':
                check(value['predictions'] == predictions and value['report']['metrics'] == training['last_complete_attempt']['numerical']
                    and run['fidelity'][label] == training['last_complete_attempt']['fidelity']
                    and run['conditioned_validation_replay_exact'] is True, arm+'/actual_rejected_generation_and_all_scores_replay_exactly')
        for label, baseline in [('zero-condition', 'validation'), ('source-shuffle', 'validation'), ('training-source-shuffle', 'training')]:
            audit_comparison(run['comparisons'][label], evaluations[baseline], evaluations[label], arm+'/'+label)
        results.append(dict(arm=arm, validation=run['fidelity']['validation']['metrics'], training=run['fidelity']['training']['metrics'],
            source_shuffle_validation=run['comparisons']['source-shuffle'], source_shuffle_training=run['comparisons']['training-source-shuffle'],
            zero_source=run['comparisons']['zero-condition']))
    return results


def compare_fidelity(candidate, reference, label):
    reasons = []; progress = False
    if set(candidate['by_length']) != set(reference['by_length']): raise ValueError('selection lengths differ')
    for length, bucket in candidate['by_length'].items():
        old = reference['by_length'][length]
        if any(bucket['metrics'][key] != old['metrics'][key] for key in ('rows', 'expected_rules')):
            raise ValueError('selection denominators differ')
        for key in MAXIMIZE+MINIMIZE:
            a, b = bucket['metrics'][key], old['metrics'][key]
            if a < b if key in MAXIMIZE else a > b:
                reasons.append(label+'/length='+length+'/'+key+' regressed')
            progress |= a > b if key in MAXIMIZE else a < b
        for key in FACETS:
            a, b = bucket['by_facet'][key], old['by_facet'][key]
            if a['total'] != b['total']: raise ValueError('facet denominator differs')
            if a['correct'] < b['correct']: reasons.append(label+'/length='+length+'/'+key+' regressed')
            progress |= a['correct'] > b['correct']
    return reasons, bool(progress and not reasons)


def audit_selection(report, label):
    incumbent = report['baseline']; epoch = 0; accepted = 0; evaluations = 0; reasons_seen = Counter()
    for row in report['history']:
        if row['source_fidelity'] is not None:
            evaluations += 1
            a, _ = compare_fidelity(row['source_fidelity'], report['baseline']['fidelity'], 'baseline')
            b, progress = compare_fidelity(row['source_fidelity'], incumbent['fidelity'], 'incumbent')
            reasons = a+b
            limit = report['baseline']['numerical']['reconstructed_input_mse']*(1+report['config']['reconstruction_relative_tolerance'])+report['config']['reconstruction_absolute_tolerance']
            if row['numerical']['reconstructed_input_mse'] > limit: reasons.append('initial_reconstruction_regression')
            if not (progress or row['numerical']['token_cross_entropy'] < incumbent['numerical']['token_cross_entropy']):
                reasons.append('no_fidelity_or_reference_ce_progress')
            recorded = row['rejection_reasons']
            check(recorded == reasons or (not reasons and recorded == ['deadline_before_selection_commit']), label+'/guard_reasons/'+str(row['epoch']))
            check(row['accepted'] is (not recorded), label+'/acceptance/'+str(row['epoch']))
            reasons_seen.update(recorded)
        else:
            check(row['accepted'] is False, label+'/no_acceptance_without_complete_evaluation/'+str(row['epoch']))
        if row['accepted']:
            incumbent = dict(numerical=row['numerical'], fidelity=row['source_fidelity'])
            epoch = row['epoch']; accepted += 1
        check(row['selected_epoch'] == epoch, label+'/selected_epoch/'+str(row['epoch']))
    check(report['selected_epoch'] == epoch and report['selected']['numerical'] == incumbent['numerical']
        and report['selected']['fidelity'] == incumbent['fidelity'], label+'/final_selection_matches_history')
    return dict(completed_evaluations=evaluations, accepted_evaluations=accepted, rejection_reasons=dict(reasons_seen))


def audit_counts(counts, refs, label):
    expected = {row['id']: row['clause_count'] for row in refs}; totals = {}
    check(counts['source_only_head'] is True and counts['used_for_selection'] is False
        and counts['reference_count_supplied_to_generation'] is False, label+'/source_only_count_scope')
    check(len(counts['predictions']) == len(expected) and {row['id'] for row in counts['predictions']} == set(expected), label+'/all_count_rows')
    for row in counts['predictions']:
        check(row['expected'] == expected[row['id']] and type(row['predicted']) is int and 1 <= row['predicted'] <= 32,
            label+'/'+row['id']+'/count_identity_bounds')
        bucket = totals.setdefault(str(row['expected']), dict(rows=0, correct=0, absolute_error=0))
        bucket['rows'] += 1; bucket['correct'] += int(row['expected'] == row['predicted'])
        bucket['absolute_error'] += abs(row['expected']-row['predicted'])
    check(counts['by_length'] == totals and counts['rows'] == len(expected)
        and counts['correct'] == sum(value['correct'] for value in totals.values())
        and math.isfinite(counts['cross_entropy']) and counts['cross_entropy'] >= 0, label+'/count_arithmetic')


def audit_training(ctx, controls):
    summary, folder, plan = ctx['summary'], ctx['results'], ctx['plan']
    original_manifest = controls['manifest']; prior = read(original_manifest['source_run_summary'])
    old_runs = {row['arm']: row for row in prior['runs']}
    source_plan = read(ctx['manifest']['curriculum'])
    rows = {row['id']: row for row in ctx['corpus']['train']}; stages = []; previous = set()
    for stage in source_plan['stages']:
        ids = stage['training_ids']
        if ids and set(ids) != previous:
            stages.append(ids); previous = set(ids)
    steps = sum(math.ceil(len(ids)/plan['batch_size'])*plan['epochs_per_source_stage'] for ids in stages)
    presentations = sum(len(ids)*plan['epochs_per_source_stage'] for ids in stages)
    tokens = sum(sum(len(rows[identity]['target_ids'])-1 for identity in ids)*plan['epochs_per_source_stage'] for ids in stages)
    check((steps, tokens, presentations) == (340, 225840, 2440), 'training/independent_full_cumulative_budget')
    expected = {arm['name']+'-'+str(seed) for seed in plan['seed_order'] for arm in plan['arms']}
    check(len(summary['runs']) == 6 and {row['arm'] for row in summary['runs']} == expected, 'training/exact_six_predeclared_arms')
    initial = set(); capacities = set(); results = []; parity = []
    for run in summary['runs']:
        arm = run['arm']; report = read(folder/arm/'training.json'); recipe = run['recipe']
        check(report == run['training'] and run['budget_completed'] is True
            and (report['optimizer_steps'], report['valid_target_token_presentations'], report['row_presentations']) == (steps, tokens, presentations)
            and report['stopped_reason'] == 'epochs_completed', arm+'/actual_complete_work_budget')
        check(report['cardinality_weight'] == recipe['cardinality_weight'] and report['count_metrics_used_for_selection'] is False
            and report['count_target_access'] == 'training_and_evaluation_loss_only'
            and report['generation_temperature'] == 0 and report['full_targets_truncated'] is False
            and report['config']['max_target_tokens'] == 512 and report['teacher_distillation_used'] is False, arm+'/count_and_decoder_scope')
        initial.add(report['initial_weights_sha256']); capacities.add(run['trainable_parameter_count'])
        check(report['optimizer_instance_count'] == 1 and report['optimizer_reinitialized_between_stages'] is False, arm+'/continuous_optimizer')
        for first, second in zip(report['stage_reports'], report['stage_reports'][1:]):
            check(first['optimizer_state_end'] == second['optimizer_state_start']
                and first['optimizer_step_end'] == second['optimizer_step_start'], arm+'/actual_adam_state_continuity/'+second['name'])
        selected = audit_selection(report, arm)
        states = {}
        for role in ('selected', 'last-attempt'):
            state = read(folder/arm/(role+'-state.json')); states[role] = state
            expected_hash = report['selected_weights_sha256'] if role == 'selected' else report['last_complete_attempt_weights_sha256']
            check(state['schema'] == 'private-cardinality-state/v1' and state['role'] == role
                and state['recipe'] == recipe and state['weights_sha256'] == digest(state['model_state'])
                and state['tensor_sha256'] == tensor_digest(state['model_state']) == expected_hash, arm+'/'+role+'/actual_tensor_role_digest')
            check(state['selected'] == (role == 'selected' or report['last_complete_attempt_is_selected'])
                and state['optimizer_resumable'] is False, arm+'/'+role+'/selected_vs_rejected_role')
            architecture = state['architecture']
            check(architecture['guide_boundary'] is recipe['guide_boundary'] and architecture['inherited_conditioning'] == 'every_step'
                and architecture['count_classes'] == list(range(1, 33))
                and architecture['count_features'] == 'inherited_source_initial_hidden'
                and architecture['decoder_reference_count_access'] is False and architecture['guidance_forces_closure'] is False,
                arm+'/'+role+'/source_only_architecture')
            audit_projections(state['model_state'], ctx['donor'], report['frozen_parameter_names'], arm+'/'+role)
            authority(state, arm+'/'+role)
            previous_predictions = read(folder/arm/('selected-predictions.json' if role == 'selected' else 'last-attempt-predictions.json'))
            stored = report['selected'] if role == 'selected' else report['last_complete_attempt']
            for label, split, kind in [('validation', 'validation', 'conditioned'), ('training', 'train', 'conditioned'),
                    ('zero-condition', 'validation', 'zero_condition'), ('source-shuffle', 'validation', 'source_shuffle')]:
                evaluation = read(folder/arm/role/('evaluation-'+label+'.json')); refs = ctx['corpus'][split]
                audit_execution(evaluation, refs, ctx['vectors'], arm+'/'+role+'/'+label, kind)
                audit_fidelity(evaluation['source_fidelity'], refs, evaluation['predictions'], ctx['donor']['codec'], arm+'/'+role+'/'+label)
                audit_counts(evaluation['source_count'], refs, arm+'/'+role+'/'+label)
                compact = dict(numerical=evaluation['report'], source_count=evaluation['source_count'],
                    timing=evaluation['timing'], execution=evaluation['execution'],
                    source_fidelity={key: value for key, value in evaluation['source_fidelity'].items() if key != 'rows'})
                check(compact == run['postfit'][role][label], arm+'/'+role+'/'+label+'/summary_identity')
                timing = evaluation['timing']
                check(timing['postfit_evaluation_elapsed_seconds'] >= timing['numerical_api_elapsed_seconds'] > 0
                    and timing['numerical_api_elapsed_seconds'] == evaluation['report']['elapsed_seconds'],
                    arm+'/'+role+'/'+label+'/explicit_readout_timing_scope')
                if label == 'validation':
                    check(evaluation['predictions'] == previous_predictions and evaluation['report']['metrics'] == stored['numerical']
                        and compact['source_fidelity'] == stored['fidelity'] and evaluation['source_count'] == stored['source_count'],
                        arm+'/'+role+'/saved_state_complete_replay')
        if recipe['name'] == 'no_count':
            previous_arm = 'every_step-semantic_fields-'+str(run['seed'])
            previous_run = old_runs[previous_arm]; binding = original_manifest['rejected_states'][previous_arm]
            old_last = read(binding['state']); old_report = read(binding['training'])
            old_selected = read(Path(binding['training']).parent/'private-state.json')
            for role, original in [('last-attempt', old_last), ('selected', old_selected)]:
                values = states[role]['model_state']
                inherited = {key.removeprefix('body.'): value for key, value in values.items() if key.startswith('body.')}
                equal = set(inherited) == set(original['model_state']) and all(tensor_bytes(value) == tensor_bytes(original['model_state'][key]) for key, value in inherited.items())
                check(equal, arm+'/'+role+'/real_previous_no_count_tensor_parity')
                check(all(value == 0 for key in ('count_head.weight', 'count_head.bias') for value in flat(values[key])), arm+'/'+role+'/zero_count_head')
                parity.append(dict(arm=arm, role=role, previous_arm=previous_arm, inherited_tensor_bytes_equal=equal))
            for current, old in zip(report['history'], old_report['history']):
                fields = ('epoch', 'stage', 'stage_epoch', 'complete_epoch', 'optimizer_steps', 'learning_rate',
                    'mean_minibatch_ce', 'mean_minibatch_weighted_ce', 'mean_minibatch_raw_reconstruction_mse',
                    'numerical', 'source_fidelity', 'accepted', 'rejection_reasons', 'selected_epoch')
                check(all(current[key] == old[key] for key in fields), arm+'/previous_no_count_epoch_parity/'+str(current['epoch']))
            check(len(report['history']) == len(old_report['history']) and report['selected_epoch'] == old_report['selected_epoch'], arm+'/previous_no_count_all_epochs')
            for label in ('validation', 'training', 'zero-condition', 'source-shuffle'):
                current = run['postfit']['selected'][label]; old = previous_run['postfit'][label]
                check(current['numerical']['metrics'] == old['numerical']['metrics'] and current['source_fidelity'] == old['source_fidelity'],
                    arm+'/previous_selected_control_parity/'+label)
        results.append(dict(arm=arm, selected_epoch=report['selected_epoch'], steps=report['optimizer_steps'],
            training_call_seconds=report['elapsed_seconds'], selected_metrics=report['selected']['fidelity']['metrics'],
            last_metrics=report['last_complete_attempt']['fidelity']['metrics'], last_count=report['last_complete_attempt']['source_count'],
            selection_audit=selected))
    check(len(initial) == len(capacities) == 1, 'training/matched_initial_weight_bytes_and_capacity')
    return dict(arms=results, no_count_real_parity=parity, cumulative_stage_sizes=[len(ids) for ids in stages],
        expected_steps_per_arm=steps, expected_target_tokens_per_arm=tokens, expected_row_presentations_per_arm=presentations)


def audit_superseded(ctx, final, controls):
    """Preserve an actual failed comparability test; never convert it to success."""
    check(ctx['plan'] == final['plan'] and ctx['manifest']['inputs'] == final['manifest']['inputs'],
        'superseded_r1/recipe_and_inputs_unchanged_for_retry')
    changed = [path for path, value in final['manifest']['extensions'].items()
        if ctx['manifest']['extensions'].get(path) != value]
    allowed = {'ipfs_datasets_py/logic/formalization/autoencoder/long_span_cardinality_training.py',
        'tests/unit/logic/formalization/autoencoder/test_long_span_cardinality_training.py'}
    check(set(changed) <= allowed and 'ipfs_datasets_py/logic/formalization/autoencoder/long_span_cardinality_training.py' in changed,
        'superseded_r1/only_zero_coefficient_optimizer_fix_for_retry', changed)
    observations = []
    for seed in (1729, 2718):
        arm = 'no_count-'+str(seed); previous = 'every_step-semantic_fields-'+str(seed)
        original_binding = controls['manifest']['rejected_states'][previous]
        original_state = read(original_binding['state']); original_report = read(original_binding['training'])
        candidate = read(ctx['results']/arm/'last-attempt-state.json'); report = read(ctx['results']/arm/'training.json')
        inherited = {key.removeprefix('body.'): value for key, value in candidate['model_state'].items() if key.startswith('body.')}
        equal = set(inherited) == set(original_state['model_state']) and all(tensor_bytes(value)
            == tensor_bytes(original_state['model_state'][key]) for key, value in inherited.items())
        old_ce = original_report['last_complete_attempt']['numerical']['token_cross_entropy']
        candidate_ce = report['last_complete_attempt']['numerical']['token_cross_entropy']
        check(not equal and candidate_ce != old_ce, 'superseded_r1/'+arm+'/actual_baseline_parity_failure_preserved')
        check(candidate['weights_sha256'] == digest(candidate['model_state'])
            and candidate['tensor_sha256'] == tensor_digest(candidate['model_state']), 'superseded_r1/'+arm+'/saved_state_integrity')
        observations.append(dict(arm=arm, previous_arm=previous, inherited_tensor_bytes_equal=equal,
            recorded_previous_reference_ce=old_ce, recorded_superseded_reference_ce=candidate_ce,
            status='failed_baseline_comparability; superseded_for_comparison_not_deleted'))
    return dict(attempt=ctx['name'], resource_status=ctx['resource']['status'], changed_extensions=changed,
        status='preserved_failed_baseline_comparability', observations=observations,
        cause='Zero-weight count loss created zero count-head gradients, changing the floating-point global clip-norm reduction.',
        correction_scope='Skip adding a zero-coefficient term to autograd; continue measuring count CE; unchanged recipe/gates/inputs.',
        training_success_claim=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--controls-attempt', default='controls-r1')
    parser.add_argument('--training-attempt', default='training-r1')
    parser.add_argument('--superseded-training-attempt')
    parser.add_argument('--phase', choices=('controls', 'all'), default='all')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    names = [args.controls_attempt] + ([args.training_attempt] if args.phase == 'all' else [])
    if args.phase == 'all' and args.superseded_training_attempt:
        names.append(args.superseded_training_attempt)
    for name in names:
        if not all((RUN/name/item).is_file() for item in ('results/summary.json', 'resources-final.json', 'command.json', 'child-exit.json')):
            print(json.dumps(dict(status='waiting_for_durable_results', attempt=name))); return 3
    output = args.output or RUN/('independent-audit.json' if args.phase == 'all' else 'independent-controls-audit.json')
    if output.exists(): raise FileExistsError('immutable audit output already exists')
    source_hash = sha(__file__)
    controls = begin_attempt(args.controls_attempt); control_results = audit_controls(controls)
    training = begin_attempt(args.training_attempt) if args.phase == 'all' else None
    training_results = audit_training(training, controls) if training else None
    old = begin_attempt(args.superseded_training_attempt) if training and args.superseded_training_attempt else None
    superseded = audit_superseded(old, training, controls) if old else None
    test_suites = []
    for path in sorted(RUN.glob('*tests*.xml')):
        tree = ET.parse(path).getroot(); suites = [tree] if tree.tag == 'testsuite' else tree.findall('testsuite')
        counts = {key: sum(int(item.attrib.get(key, 0)) for item in suites) for key in ('tests', 'failures', 'errors', 'skipped')}
        test_suites.append(dict(path=str(path), sha256=sha(path), **counts))
    check(sha(__file__) == source_hash, 'audit_owner_unchanged')
    result = dict(schema='independent-decoder-cardinality-audit/v1', created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        phase=args.phase, complete=True, verdict='blocking_findings' if findings else 'no_blocking_correctness_issue_found',
        all_pins_match=all(row['passed'] for row in checks if '/pin/' in row['check']),
        checked_count=len(checks), failed_check_count=len(findings), findings=findings, checks=checks,
        controls=control_results, cardinality_training=training_results, superseded_training=superseded, test_suites=test_suites,
        test_count_note='Separate XML receipts may contain overlapping tests; never sum them as independent coverage.',
        artifacts=artifacts, audit_source_sha256=source_hash,
        resource_status={ctx['name']: ctx['resource']['status'] for ctx in [controls]+([training] if training else [])+([old] if old else [])},
        limitations=['Exposed authored train/validation compositions; no fresh holdout, natural statute coverage or global-convergence claim.',
            'Same-length source shuffling tests lexical/source dependence within a fixed clause count; it cannot test count sensitivity.',
            'Token-role NLL uses the complete reference prefix and is separate from target-free generation.',
            'Fidelity arithmetic checks recorded rule-validity decisions; no independent canonical parser, neural inference or native tool is run here.',
            'Source-only architecture claims bind inspected source hashes and persisted config, not mathematical proof of learned grounding.',
            'Reference agreement and source-count accuracy grant no Lake/proof authority.',
            'Tensor memory estimates exclude allocator/Python/RSS; deadlines are cooperative.',
            'Only384D cached semantic vectors are evaluated;8D linguistic teacher and768D lineage remain unchanged.'],
        model_executed_by_auditor=False, native_executed_by_auditor=False,
        **{key: False for key in AUTHORITY})
    with output.open('xb') as stream:
        stream.write(json.dumps(result, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False).encode()+b'\n')
    print(json.dumps(dict(path=str(output), sha256=sha(output), bytes=output.stat().st_size,
        verdict=result['verdict'], checks=len(checks), findings=findings)))
    return int(bool(findings))


if __name__ == '__main__':
    raise SystemExit(main())
