"""Export closed probe inputs from authenticated training-only saved rows; no model execution."""
import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
import sys

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
BASE='64bc5734dc82db72e955f2e809b770127e9b6cfc'
FIELDS=['actor','modality','object']
CHECKS=0


def require(value,message):
    global CHECKS
    CHECKS+=1
    if not value:raise ValueError(message)


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(value):return hashlib.sha256(raw(value)).hexdigest()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def f32(value):return struct.unpack('<f',struct.pack('<f',value))[0]
def artifact(path):return dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)


def save(path,value):
    require(not path.exists(),'refusing to overwrite '+str(path))
    data=json.dumps(value,indent=2,sort_keys=True,allow_nan=False).encode()+b'\n'
    require(len(data)<4*1024*1024,'bounded adapter output required')
    path.write_bytes(data)
    return dict(artifact(path),contents_sha256=digest(value))


def main():
    source_path=R/'training-object-inputs.json'
    geometry_path=R/'training-object-geometry.json'
    geometry=json.loads(geometry_path.read_bytes())
    require(geometry['passed'] and geometry['complete'],'completed geometry required')
    source_ref=geometry['training_only_probe_inputs']
    require(source_ref==artifact(source_path),'geometry/raw-export binding differs')
    source=json.loads(source_path.read_bytes())
    require(source['contents_sha256']==digest({k:v for k,v in source.items() if k!='contents_sha256'}),'raw export digest differs')
    require(source['publication_git_commit']==BASE and source['dimension']==8
        and source['validation_entries_present'] is False and source['fields']==['actor','action','modality','object'],
        'exact training-only8D export required')
    manifest_path=P/'docs/implementation/reports/evidence/decoder-generated-field-training-r2-20261003/manifest.json'
    manifest_bytes=subprocess.check_output(['git','show',BASE+':'+str(manifest_path.relative_to(P))],cwd=P)
    require(hashlib.sha256(manifest_bytes).hexdigest()==sha(manifest_path)==source['publication_manifest_sha256'],
        'published manifest binding differs')
    manifest=json.loads(manifest_bytes)
    for path,record in geometry['artifacts'].items():
        require(sha(path)==record['sha256'],'original diagnostic input changed')
    transform=source['input_transform'];norm=source['float32_model_buffers']
    mean=[f32(x) for x in transform['mean']];scale=f32(transform['scale'])
    clause_mean=norm['clause_source_mean'];clause_scale=norm['clause_source_scale']
    require(all(x==f32(x) for x in clause_mean) and clause_scale==f32(clause_scale),'clause buffers are not exact float32')
    rows=[];operations=[];seen=set()
    for index,occurrence in enumerate(source['occurrences']):
        require(occurrence['span_id'].startswith('authored-paragraph:train:') and type(occurrence['slot']) is int,
            'nontraining or nonpositioned clause occurrence')
        identity=occurrence['span_id']+':slot:'+str(occurrence['slot'])
        require(identity not in seen,'duplicate occurrence identifier');seen.add(identity)
        cast=[f32(x) for x in occurrence['raw_vector']]
        centered=[f32(x-m) for x,m in zip(cast,mean)]
        transformed=[f32(x/scale) for x in centered]
        projected=list(transformed)
        head_centered=[f32(x-m) for x,m in zip(projected,clause_mean)]
        features=[f32(x/clause_scale) for x in head_centered]
        require(len(features)==8 and all(math.isfinite(x) for x in features),'finite8D features required')
        labels=occurrence['target_token_ids']
        require(set(labels)==set(source['fields']) and all(type(x) is int and 3<=x<32 for x in labels.values()),
            'full-vocabulary original targets required')
        rows.append(dict(id=identity,source_sha256=occurrence['source_sha256'],input=features,
            labels={field:labels[field] for field in FIELDS}))
        operations.append(dict(id=identity,source_occurrence_index=index,span_id=occurrence['span_id'],slot=occurrence['slot'],
            dedup_id=occurrence['dedup_id'],source_sha256=occurrence['source_sha256'],
            all_four_target_token_ids=labels,raw_float32=cast,input_centered_float32=centered,
            input_transformed_float32=transformed,frozen_identity_projected_float32=projected,
            head_centered_float32=head_centered,head_normalized_float32=features))
    require(len(rows)==180 and len({x['source_sha256'] for x in rows})==113,'training exposure inventory differs')
    training=dict(schema='source-field-readout-probe-training/v1',split='train',dimension=8,
        vocabulary_size=32,fields=FIELDS,rows=rows)
    refs={'training':save(R/'probe-training-8d.json',training)}
    states={}
    for seed in (1729,2718):
        ref=source['initial_baseline_states'][str(seed)];path=Path(ref['path'])
        member=manifest['original_artifact_archive_paths'][str(path)]
        require(manifest['members'][member]['sha256']==sha(path)==ref['sha256'],'published initial state binding differs')
        state=json.loads(path.read_bytes());require(state['role']=='initial' and state['dimension']==8
            and state['tensor_sha256']==ref['tensor_sha256'],'initial state role/identity differs')
        names=['source_projection.weight','source_projection.bias','field_readout.weight','field_readout.bias']
        parameters={name:state['model_state']['non_action_head.'+name] for name in names}
        def shape(value):return [] if not isinstance(value,list) else [len(value)]+shape(value[0])
        require([shape(parameters[name]) for name in names]==[[64,8],[64],[96,64],[96]],'initial head geometry differs')
        require(all(value==0. for row in parameters['field_readout.weight'] for value in row)
            and all(value==0. for value in parameters['field_readout.bias']),'fresh zero readout required')
        initial=dict(schema='source-field-readout-probe-initial-head/v1',dimension=8,vocabulary_size=32,
            hidden_width=64,fields=FIELDS,parameters=parameters)
        refs['initial_head_'+str(seed)]=save(R/('probe-initial-head-8d-'+str(seed)+'.json'),initial)
        states[str(seed)]=dict(ref,archive_member=member,parameter_prefix='non_action_head.',
            action_head_not_exported=True,all_original_full_state_parameters_unchanged=True)
    require(not any(name.startswith(('torch','ipfs_datasets_py')) for name in sys.modules),'adapter imported model/runtime')
    receipt=dict(schema='training-object-readout-probe-adapter/v1',complete=True,passed=True,findings=[],
        published_base=BASE,publication_manifest=artifact(manifest_path),
        raw_training_export=artifact(source_path),geometry_receipt=artifact(geometry_path),
        inputs=refs,initial_full_states=states,training_occurrences=180,unique_training_clauses=113,
        probe_fields=FIELDS,all_four_targets_retained_in_raw_export_and_operations=True,
        operations=dict(arithmetic='IEEE754 round-to-float32 after each cast/subtraction/division; no learned affine/tanh evaluated',
            input_mean_float32=mean,input_scale_float32=scale,clause_mean_float32=clause_mean,
            clause_scale_float32=clause_scale,rows=operations),
        original_published_inputs=geometry['artifacts'],script_sha256=sha(__file__),checks=CHECKS,
        model_executed=False,model_imported=False,training_executed=False,validation_entries_present=False,
        validation_labels_used=False,validation_vectors_used=False,weights_changed=False,qualified=False,admitted=False,
        lake_executed=False,checkpoint_promoted=False)
    save(R/'probe-adapter-receipt.json',receipt)
    print(json.dumps(dict(complete=True,checks=CHECKS,exports=refs),sort_keys=True))


if __name__=='__main__':main()
