"""Check the new guide against sealed probe evidence and the actual trainer API.

This is a documentation review, not another numerical training run. Full decoder
outcomes deliberately remain pending and are not read by this reviewer.
"""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET


P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
D = Path(__file__).resolve().parent
R = P/'workspace/test-logs/decoder-source-head-lr-20261003'
SOURCE_DOC = P/'docs/autoencoders/source_head_training.md'
DOC = D/'draft-source-head-training.md'
OUT = D/'probe-doc-review.json'
checks, findings, artifacts = 0, [], {}


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1048576), b''):
            result.update(part)
    return result.hexdigest()


def check(value, description):
    global checks
    checks += 1
    if not value:
        findings.append(description)


def pin(path):
    path = Path(path).resolve()
    artifacts[str(path)] = dict(sha256=sha(path), bytes=path.stat().st_size)
    return path


def read(path):
    return json.loads(pin(path).read_bytes())


def verify_artifacts(receipt):
    for name, expected in receipt.get('artifacts', {}).items():
        path = pin(name)
        check(sha(path) == expected['sha256'], 'source artifact SHA: '+name)
        if 'bytes' in expected:
            check(path.stat().st_size == expected['bytes'], 'source artifact bytes: '+name)


def xml_count(path):
    tree = ET.parse(pin(path))
    suites = list(tree.iter('testsuite'))
    count = sum(int(s.get('tests', '0')) for s in suites)
    check(all(int(s.get(k, '0')) == 0 for s in suites for k in ('errors', 'failures', 'skipped')),
          'clean frozen test XML: '+str(path))
    return count, sum(float(s.get('time', '0')) for s in suites)


def main():
    if OUT.exists():
        raise ValueError('preserve prior documentation review before rerunning')
    doc = pin(DOC).read_text()
    outcomes = read(D/'outcomes.json')
    audit = read(D/'independent-audit.json')
    geometry = read(D/'training-object-geometry.json')
    adapter = read(D/'probe-adapter-receipt.json')
    summary = read(D/'probe-r1/results/summary.json')
    training = read(D/'probe-training-8d.json')
    plan = read(D/'training-plan.json')
    rplan = read(R/'training-plan.json')
    rmanifest = read(R/'training-manifest.json')
    verify_artifacts(outcomes)
    verify_artifacts(audit)
    check(outcomes['passed'] and outcomes['complete'] and not outcomes['findings'], 'completed clean outcomes')
    check(audit['passed'] and audit['checks'] == 47070 and not audit['findings'], 'independent numerical audit count')
    check(audit['checkpoint_affine_tanh_softmax_reconstructed'] and audit['checkpoint_gradient_arithmetic_reconstructed'],
          'independent saved arithmetic performed')
    check(audit['optimizer_trajectory_replayed'] is False and audit['model_executed'] is False,
          'audit limits are accurate')
    check(plan['fit_count'] == 8 and len(outcomes['runs']) == 8 and audit['analysis']['checkpoint_count'] == 56,
          'eight probe fits and 56 checkpoints')
    check(len(training['rows']) == 180 and len({row['source_sha256'] for row in training['rows']}) == 113,
          'occurrence and unique-clause denominators')
    check(Counter(row['labels']['object'] for row in training['rows']) == {9:90,16:90}, 'balanced object majority')
    check(summary['source_paragraph_count'] == 48 and plan['training_paragraphs'] == 48, 'source paragraph count')
    check(geometry['geometry']['head_normalized_float32']['unique_vectors'] == 113
          and not geometry['geometry']['head_normalized_float32']['contradictory_label_collision_groups'],
          'float32 normalized vectors have no contradictory collisions')
    pairs = geometry['field_contrasts']['object']['literal_pair_distances']['head_normalized_float32']
    check(pairs['count'] == 34 and f"{pairs['mean']:.6f}" == '0.025529', 'literal object geometry figure')
    for seed in plan['seeds']:
        for mode in plan['modes']:
            for lr in plan['learning_rates']:
                name = f'{seed}-{mode}-lr{lr}'
                run = outcomes['runs'][name]
                endpoints = {item['step']:item for item in run['checkpoints']}
                check(list(endpoints) == plan['checkpoints'], 'all prescribed checkpoints: '+name)
                left, right = [endpoints[step]['fields']['object'] for step in (340,1000)]
                row = (f'| {seed} | {mode} | {lr} | {left["correct"]}/180 | {right["correct"]}/180 | '
                       f'{left["full_vocabulary_ce"]:.6f} | {right["full_vocabulary_ce"]:.6f} | {run["call_seconds"]:.3f} |')
                check(row in doc, 'exact measured table row: '+name)
                check(run['completed_updates'] == 1000 and run['clipped_updates'] == 0,
                      'full unclipped bounded fit: '+name)
                check(run['clause_occurrence_presentations'] == 180000
                      and endpoints[340]['clause_occurrence_presentations'] == 61200,
                      'full-batch exposure: '+name)
                check(all(endpoint['fields']['object']['rows'] == 180 for endpoint in endpoints.values()),
                      'all checkpoint denominators: '+name)
                check(all(endpoint['fields']['object']['field_coefficient'] == .0625 for endpoint in endpoints.values()),
                      'matched coefficient: '+name)
                check(all(run[key] is False for key in ('admitted','qualified','convergence_proven','fresh_holdout',
                    'checkpoint_promoted','best_checkpoint_selected','decoder_executed','validation_access')),
                    'diagnostic authority: '+name)
    for seed, expected_modality in [(1729,(154,180)), (2718,(151,179))]:
        records = [next(c for c in outcomes['runs'][f'{seed}-shared_non_action-lr{rate}']['checkpoints']
                        if c['step'] == 340)['fields'] for rate in (.001,.01)]
        check(tuple(r['actor']['correct'] for r in records) == (167,180), 'actor secondary improvement')
        check(tuple(r['modality']['correct'] for r in records) == expected_modality, 'modality secondary improvement')
    for value, rendered in [(outcomes['comparison_elapsed_seconds'],'7.149'),
                            (outcomes['total_call_seconds'],'5.819'),
                            (outcomes['guardian_exit']['wrapper_elapsed_seconds'],'65.930')]:
        check(f'{value:.3f}' == rendered and rendered in doc, 'separate measured timing: '+rendered)
    resource = audit['analysis']
    for key, value in [('peak_rss_measured',False), ('live_rss_observation_count',1),
            ('rss_observation_count',2), ('periodic_rss_log_present',False),
            ('maximum_observed_rss',115986432), ('final_attempt_bytes',40518693),
            ('continuous_memory_enforcement',False)]:
        check(resource[key] == value, 'memory evidence scope: '+key)
    check(outcomes['resource_finalization_status'] == 'released', 'resource owner released')
    check(adapter['published_base'] == '64bc5734dc82db72e955f2e809b770127e9b6cfc', 'original published state identity')
    probe_count, _ = xml_count(D/'tests-frozen.xml')
    full_count, full_seconds = xml_count(R/'tests-scoped.xml')
    check(probe_count == 72 and full_count == 2708, 'separate frozen test counts')
    full_log = pin(R/'tests-scoped.log').read_text()
    check('2708 passed in 54.66s' in full_log, 'pytest reported elapsed time distinct from XML suite duration')
    focused = pin(D/'head-lr-tests-attempt3.log').read_text()
    failed = pin(D/'head-lr-tests-attempt2.log').read_text()
    check('166 passed in 10.07s' in focused, 'focused regression pass retained')
    check('12 failed, 154 passed' in failed and 'CUDA error: out of memory' in failed,
          'failed CUDA environment attempt retained')
    trainer_path = P/'ipfs_datasets_py/logic/formalization/autoencoder/long_span_source_value_training.py'
    trainer = pin(trainer_path).read_text()
    tree = ast.parse(trainer)
    train = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name == 'train')
    defaults = dict(zip([arg.arg for arg in train.args.kwonlyargs], train.args.kw_defaults))
    check(ast.literal_eval(defaults['non_action_learning_rate_multiplier']) == 1.0, 'documented actual API default')
    relative = str(trainer_path.relative_to(P))
    check(sha(trainer_path) == rmanifest['extensions'][relative], 'trainer matches frozen comparison source')
    for literal in ('optimizer_parameter_groups', 'optimizer_group_learning_rates',
            'optimizer_scheduler_epsilon', 'non_action_learning_rate_used_for_selection'):
        check(literal in trainer, 'documented enabled receipt: '+literal)
    check('min_lr=[item["minimum_learning_rate"] for item in group_inventory], eps=0.' in trainer,
          'enabled scheduler floor and epsilon')
    check('same_coefficient_in_both_groups; per_step_shrinkage_is_learning_rate_times_weight_decay' in trainer,
          'AdamW decay coupling disclosed by producer')
    check(rplan['fit_count'] == 12 and rplan['dimensions'] == [8,384,768]
          and rplan['seed_order'] == [1729,2718] and rplan['learning_rate'] == .001,
          'pending full-decoder fixed plan')
    check(all(arm['generated_field_weight'] == 0. and arm['action_contrastive_weight'] == .05
          and arm['generated_boundary_weight'] == .05 for arm in rplan['arms']), 'pending recipes unchanged')
    check('Full-decoder comparison: results pending' in doc and 'Full-decoder results and an independent results audit are pending.' in doc,
          'no guessed full-decoder outcomes')
    for required in ('Peak RSS was not measured', 'training occurrences out of 180', 'not a\nfresh holdout',
            'The historical 8D linguistic teacher remains unchanged', 'Lake `lake build <Lib>`',
            'The Constitution is not formalized', 'No logits are masked', 'global optimum'):
        check(required in doc, 'scope statement: '+required)
    for link in re.findall(r'\]\(([^)]+)\)', doc):
        if not link.startswith(('https://','http://','#')):
            path = SOURCE_DOC.parent / link.split('#',1)[0]
            check(path.exists(), 'resolving repository documentation link: '+link)
    for relative in ('scripts/ops/autoencoder/benchmark_source_field_readout_probe.py',
                     'scripts/ops/autoencoder/benchmark_source_head_learning_rate.py'):
        source = pin(P/relative).read_text()
        check(all(arg in source for arg in ('dependency-root','extension-root','manifest','plan','output','--phase')),
              'documented runner flags: '+relative)
    pin(__file__)
    for path in sorted((D/'probe-doc-review-revisions').iterdir()):
        pin(path)
    receipt = dict(schema='source-head-training-documentation-review/v1', passed=not findings,
        complete=True, checks=checks, findings=findings, document=str(DOC), document_sha256=sha(DOC),
        original_document_destination=str(SOURCE_DOC), partial_document_review=True,
        artifacts=artifacts, reviewed_at=datetime.now(timezone.utc).isoformat(),
        scope='probe diagnosis/results, API/optimizer semantics, runner invocation and pending full-decoder plan',
        full_decoder_results_read=False, model_execution=False, training_execution=False,
        qualified=False, admitted=False, lake_executed=False)
    OUT.write_text(json.dumps(receipt,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(passed=receipt['passed'],checks=checks,findings=findings,document_sha256=receipt['document_sha256'])))
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()
