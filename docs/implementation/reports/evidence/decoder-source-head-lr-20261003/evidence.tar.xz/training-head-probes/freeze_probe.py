"""Seal the isolated probe and its authenticated training-only inputs."""
from pathlib import Path
import hashlib, importlib.util, json, shutil

P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
RUNNER='scripts/ops/autoencoder/benchmark_source_field_readout_probe.py'
HELPER='ipfs_datasets_py/logic/formalization/autoencoder/source_field_readout_probe.py'
TESTS=['tests/unit/logic/formalization/autoencoder/test_source_field_readout_probe.py',
       'tests/unit/logic/formalization/autoencoder/test_source_field_readout_probe_runner.py']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def save(p,value):
 with p.open('x') as f:json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
assert not (R/'experiment-source').exists()
extensions={}; tests={}
for rel in [HELPER,RUNNER,*TESTS]:
 dst=R/'experiment-source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/rel,dst)
 (tests if rel in TESTS else extensions)[rel]=sha(dst)
spec=importlib.util.spec_from_file_location('_probe_plan_definition',R/'experiment-source'/RUNNER)
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
inputs={}
def bind(p,expected=None):
 p=Path(p).resolve();actual=sha(p)
 assert expected is None or actual==expected,str(p)
 assert str(p) not in inputs or inputs[str(p)]==actual
 inputs[str(p)]=actual
def refs(value):
 if type(value) is dict:
  if 'path' in value and 'sha256' in value and type(value['path']) is str and Path(value['path']).is_absolute():
   bind(value['path'],value['sha256'])
  for key,item in value.items():
   if type(key) is str and key.startswith('/') and type(item) is dict and 'sha256' in item:bind(key,item['sha256'])
   refs(item)
 elif type(value) is list:
  for item in value:refs(item)
for name in ['base.json','training-object-geometry.json','training-object-inputs.json','probe-adapter-receipt.json',
 'training_object_geometry.py','prepare_probe_adapter_inputs.py']:
 if (R/name).exists():
  bind(R/name)
  if name.endswith('.json'):refs(read(R/name))
adapter=read(R/'probe-adapter-receipt.json');assert adapter['passed'] and not adapter['findings']
plan=dict(runner.FIXED,input_sha256=inputs);runner.validate_plan(plan);save(R/'training-plan.json',plan)
manifest=dict(schema='source-field-head-probe-manifest/v1',plan_sha256=sha(R/'training-plan.json'),
 inputs=inputs,extensions=extensions,training_input=adapter['inputs']['training']['path'],
 initial_heads={str(s):adapter['inputs']['initial_head_'+str(s)]['path'] for s in runner.FIXED['seeds']},
 geometry_receipt=str(R/'training-object-geometry.json'),adapter_receipt=str(R/'probe-adapter-receipt.json'),
 published_base=read(R/'base.json')['base'])
save(R/'training-manifest.json',manifest);save(R/'frozen-test-source.json',tests)
save(R/'owned-code-files.json',[HELPER,RUNNER,*TESTS])
print(json.dumps(dict(extensions=extensions,tests=tests,input_count=len(inputs))))
