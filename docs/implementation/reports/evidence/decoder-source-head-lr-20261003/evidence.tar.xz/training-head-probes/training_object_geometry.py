"""Bounded training-only saved-data geometry and raw-readout arithmetic; no model imports."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import statistics
import struct
import subprocess
import sys

P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
R = Path(__file__).resolve().parent
PRIOR = P/'workspace/test-logs/decoder-generated-field-training-r2-20261003'
BASE = '64bc5734dc82db72e955f2e809b770127e9b6cfc'
MANIFEST = 'docs/implementation/reports/evidence/decoder-generated-field-training-r2-20261003/manifest.json'
AUTO = 'ipfs_datasets_py/logic/formalization/autoencoder/'
SOURCE_FILES = [AUTO+name+'.py' for name in ('clause_source_context', 'dimension_native_decoder_experiment',
    'clause_source_decoder_experiment', 'action_factorized_clause_decoder_experiment',
    'ordered_clause_recurrent_decoder_experiment', 'long_span_source_value_training',
    'decoder_distillation_experiment')]
FIELDS = ('actor','action','modality','object')
ARTIFACTS = {}
CHECKS = 0
MAX_FILE = 16*1024*1024
FALSE = dict(model_executed=False, model_imported=False, encoder_executed=False,
    training_executed=False, weights_changed=False, qualified=False, admitted=False,
    checkpoint_promoted=False, lake_executed=False, convergence_proven=False,
    validation_labels_used=False, validation_vectors_used=False, historical_teacher_changed=False)


def require(value, message):
    global CHECKS
    CHECKS += 1
    if not value: raise ValueError(message)


def raw(value): return json.dumps(value, sort_keys=True, separators=(',',':'), ensure_ascii=False, allow_nan=False).encode()
def digest(value): return hashlib.sha256(raw(value)).hexdigest()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def f32(value): return struct.unpack('<f',struct.pack('<f',value))[0]
def l2(a,b): return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))


def stats(values):
    return dict(count=len(values), minimum=min(values), median=statistics.median(values),
        maximum=max(values), mean=statistics.fmean(values)) if values else dict(count=0)


def save(path,value):
    require(not path.exists(),'refusing to overwrite diagnostic: '+str(path))
    data=json.dumps(value,indent=2,sort_keys=True,allow_nan=False).encode()+b'\n'
    require(len(data) < MAX_FILE,'bounded diagnostic output required')
    path.write_bytes(data)
    return dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))


def main():
    base=json.loads((R/'base.json').read_bytes())['base']
    require(base == BASE,'published baseline differs')
    published=subprocess.check_output(['git','show',BASE+':'+MANIFEST],cwd=P)
    require(hashlib.sha256(published).hexdigest()==sha(P/MANIFEST),'published evidence manifest differs')
    manifest=json.loads(published)
    ARTIFACTS[str(P/MANIFEST)]={'sha256':sha(P/MANIFEST),'bytes':len(published),'git_commit':BASE}

    def read(path):
        path=Path(path).resolve();require(path.stat().st_size<MAX_FILE,'input exceeds diagnostic bound')
        member=manifest['original_artifact_archive_paths'].get(str(path))
        require(member in manifest['members'],'input absent from published archive inventory: '+str(path))
        record=manifest['members'][member];data=path.read_bytes()
        require(record['sha256']==hashlib.sha256(data).hexdigest() and record['bytes']==len(data),
            'published input hash differs: '+str(path))
        ARTIFACTS[str(path)]=dict(record,archive_member=member)
        return json.loads(data)

    sources={}
    for relative in SOURCE_FILES:
        file=PRIOR/'experiment-source'/relative
        git_bytes=subprocess.check_output(['git','show',BASE+':'+relative],cwd=P)
        require(file.read_bytes()==git_bytes,'published/frozen source differs: '+relative)
        sources[relative]=dict(path=str(file),sha256=sha(file),git_commit=BASE)
    prep=read(PRIOR/'training-r1/results/8/preprocessing.json')
    # This authenticated source-only envelope also contains validation vectors.
    # Only the train branch is selected, traversed or used in arithmetic.
    envelope=read(PRIOR/'training-r1/results/8/source-contexts.json')
    contexts=envelope['train'];del envelope
    require(len(contexts)==48 and all(key.startswith('authored-paragraph:train:') for key in contexts),
        'exact training context split required')
    transform=prep['input_transform'];norm=prep['clause_normalization']
    require(norm['validation_rows_used_for_fitting']==0 and norm['training_contexts_sha256']==digest(contexts),
        'training normalization is not bound to selected contexts')
    require(prep['representation']['kind']=='historical_linguistic_feature_hash'
        and prep['representation']['semantic_embedding'] is False,'8D representation differs')
    require(transform['mode']=='center_rms' and transform['origin']=='training_only'
        and norm['normalization']=='center_then_global_RMS_of_row_L2_norm','normalization changed')
    require(0 < transform['scale'] < 100 and 0 < norm['scale'] < 100,'bounded global scales required')
    summary=read(PRIOR/'training-r1/results/summary.json')
    selected_names={f'8-{name}-{seed}' for name in ('boundary-first-last','generated-fields','generated-fields-every2')
        for seed in (1729,2718)}
    arms={}
    for entry in summary['runs']:
        if entry['arm'] not in selected_names: continue
        arm=read(entry['summary_path']);require(digest(arm['recipe']) is not None,'recipe present')
        panel_ref=arm['postfit']['last-attempt']['training']
        panel=read(panel_ref['path']);require(sha(panel_ref['path'])==panel_ref['sha256'],'training panel reference differs')
        state=read(arm['states']['last-attempt']['path'])
        require(sha(arm['states']['last-attempt']['path'])==arm['states']['last-attempt']['sha256'],'state reference differs')
        require(state['weights_sha256']==digest(state['model_state']),'saved model state digest differs')
        require(state['input_transform']==transform and state['architecture']['clause_normalization']==norm,
            'per-arm preprocessing differs')
        require(state['model_state']['clause_source_mean']==[f32(x) for x in norm['mean']]
            and state['model_state']['clause_source_scale']==f32(norm['scale']), 'normalization buffers differ')
        def leaves(value):
            if isinstance(value,list):
                for item in value: yield from leaves(item)
            else: yield value
        zero_up={k:v for k,v in state['model_state'].items() if k.endswith(('projection_up.weight','projection_up.bias'))}
        require(len(zero_up)==2 and all(x==0. for v in zero_up.values() for x in leaves(v)),
            'identity projection requires exact zero projection-up')
        require(state['architecture']['hidden_width']==64 and state['architecture']['non_action_fields']==['actor','modality','object'],
            'shared non-action head geometry differs')
        require(state['architecture']['recurrent_feature_order']==['non_action','action'], 'recurrent branch inventory differs')
        arms[entry['arm']]=(arm,panel,state)
    require(set(arms)==selected_names,'exact six saved 8D runs required')
    first=arms['8-boundary-first-last-1729'][1]
    reference_rows=first['source_fidelity']['rows'];vocab=arms['8-boundary-first-last-1729'][2]['codec']['target_vocabulary']
    require(len(reference_rows)==48 and len(vocab)==32,'training row/vocabulary inventory differs')
    labels_by_row={row['id']:row for row in first['source_values']['predictions']}
    occurrences=[];clauses={}
    for row in reference_rows:
        rid=row['id'];require(rid in contexts and rid.startswith('authored-paragraph:train:'),'non-training row')
        segments=contexts[rid]['segments'];rules=row['expected_ir']['rules']
        require(len(segments)==len(rules),'authored positioned clause/rule alignment differs')
        for slot,(segment,rule) in enumerate(zip(segments,rules)):
            text=segment['source_text'];source_sha=hashlib.sha256(text.encode()).hexdigest()
            require(source_sha==segment['source_sha256'],'source clause hash differs')
            vector=segment['vector'];require(len(vector)==8 and all(type(x) in (float,int) and math.isfinite(x) for x in vector),
                'finite native8 training vector required')
            targets=labels_by_row[rid]['expected_token_ids'][slot]
            require(targets==[vocab.index(json.dumps(rule[field],ensure_ascii=False)) for field in FIELDS],
                'scalar token labels differ from training reference')
            record=dict(id='clause:'+source_sha,source_sha256=source_sha,source_text=text,raw_vector=vector,
                target_token_ids=dict(zip(FIELDS,targets)),reference_rule=rule)
            if record['id'] in clauses: require(clauses[record['id']]==record,'same training clause has inconsistent inputs/labels')
            else: clauses[record['id']]=record
            occurrences.append(dict(span_id=rid,slot=slot,dedup_id=record['id'],source_sha256=source_sha,
                source_text=text,raw_vector=vector,target_token_ids=dict(zip(FIELDS,targets)),
                **{key:segment[key] for key in ('char_start','char_end','byte_start','byte_end')}))
    require(len(occurrences)==180 and len(clauses)==113,'bounded training clause inventory differs')
    prepared={row['source_sha256']:row['features'] for row in prep['clause_features']}
    stages={name:{} for name in ('raw_json_float64','raw_float32','input_transformed_float32','head_normalized_float32')}
    for identity,record in clauses.items():
        values=record['raw_vector'];typed=[f32(value) for value in values]
        transformed=[f32(f32(value-f32(mean))/f32(transform['scale'])) for value,mean in zip(typed,transform['mean'])]
        require(transformed==prepared[record['source_sha256']], 'float32 input transform differs from saved projected clause feature')
        normalized=[f32(f32(value-f32(mean))/f32(norm['scale'])) for value,mean in zip(transformed,norm['mean'])]
        for stage,vector in zip(stages,(values,typed,transformed,normalized)): stages[stage][identity]=vector
    identities=sorted(clauses)
    geometry={}
    for stage,vectors in stages.items():
        groups=defaultdict(list)
        for identity in identities: groups[tuple(vectors[identity])].append(identity)
        contradictory=[group for group in groups.values() if any(len({clauses[i]['target_token_ids'][field] for i in group})>1 for field in FIELDS)]
        nn=[]
        for identity in identities:
            distances=[(l2(vectors[identity],vectors[other]),other) for other in identities if other!=identity]
            best=min(x[0] for x in distances);closest=[other for distance,other in distances if distance==best]
            nn.append(dict(id=identity,l2=best,neighbors=closest,
                object_label=clauses[identity]['reference_rule']['object'],
                neighbor_objects=[clauses[i]['reference_rule']['object'] for i in closest],
                any_same_object=any(clauses[i]['target_token_ids']['object']==clauses[identity]['target_token_ids']['object'] for i in closest),
                all_same_object=all(clauses[i]['target_token_ids']['object']==clauses[identity]['target_token_ids']['object'] for i in closest)))
        geometry[stage]=dict(unique_vectors=len(groups),contradictory_label_collision_groups=contradictory,
            per_coordinate=[dict(index=index,distinct_values=len({vectors[i][index] for i in identities}),
                **stats([vectors[i][index] for i in identities])) for index in range(8)],
            nearest_neighbor=dict(scope='leave-one-unique-training-clause-out descriptive geometry; no fitted model or generalization estimate',
                rows=nn,any_same_object=sum(row['any_same_object'] for row in nn),
                all_same_object=sum(row['all_same_object'] for row in nn),tied_rows=sum(len(row['neighbors'])>1 for row in nn)))
    contrast={}
    object_pairs=[]
    for field in FIELDS:
        groups=defaultdict(list)
        for identity in identities:
            rule=clauses[identity]['reference_rule'];key=digest({k:v for k,v in rule.items() if k!=field})
            groups[key].append(identity)
        pairs=[]
        for group in groups.values():
            for left,right in itertools.combinations(group,2):
                a,b=clauses[left],clauses[right]
                if a['target_token_ids'][field]==b['target_token_ids'][field]:continue
                masked=[]
                for item in (a,b):
                    value=item['reference_rule'][field]
                    expression=r'(?<!\w)'+re.escape(value)+r'(?!\w)'
                    text,count=re.subn(expression,'<field>',item['source_text'].casefold())
                    masked.append(text if count==1 else None)
                literal=masked[0] is not None and masked[0]==masked[1]
                pair=dict(left=left,right=right,literal_single_field_text_contrast=literal,
                    source_left=a['source_text'],source_right=b['source_text'],
                    stages={stage:dict(l2=l2(vectors[left],vectors[right]),
                        differing_coordinates=sum(x!=y for x,y in zip(vectors[left],vectors[right])),
                        exact_collision=vectors[left]==vectors[right]) for stage,vectors in stages.items()})
                pairs.append(pair)
        contrast[field]=dict(reference_only_pairs=len(pairs),literal_text_pairs=sum(pair['literal_single_field_text_contrast'] for pair in pairs),
            reference_pair_distances={stage:stats([pair['stages'][stage]['l2'] for pair in pairs]) for stage in stages},
            literal_pair_distances={stage:stats([pair['stages'][stage]['l2'] for pair in pairs if pair['literal_single_field_text_contrast']]) for stage in stages},
            collisions_by_stage={stage:sum(pair['stages'][stage]['exact_collision'] for pair in pairs) for stage in stages})
        if field=='object':object_pairs=pairs
    class_ids={field:sorted({item['target_token_ids'][field] for item in clauses.values()}) for field in FIELDS}
    raw_readouts={}
    for name,(arm,panel,state) in arms.items():
        require([row['expected_ir'] for row in panel['source_fidelity']['rows']]==[row['expected_ir'] for row in reference_rows],
            'training references differ between arms')
        require([row['id'] for row in panel['source_fidelity']['rows']]==[row['id'] for row in reference_rows],'training row order differs')
        per_field={field:dict(ce=[],class_ce=[],outside_mass=[],margin=[],correct=0,predictions=Counter()) for field in FIELDS}
        unique={};repeat_difference=0.
        for row in panel['source_values']['predictions']:
            require(row['id'] in contexts,'non-training raw-head row')
            for slot,segment in enumerate(contexts[row['id']]['segments']):
                identity='clause:'+segment['source_sha256'];expected=[clauses[identity]['target_token_ids'][f] for f in FIELDS]
                require(row['expected_token_ids'][slot]==expected,'raw-head training labels differ')
                logits=row['raw_logits'][slot]
                require(len(logits)==4 and all(len(field_logits)==32 for field_logits in logits),'full-vocabulary raw logits required')
                if identity in unique:
                    repeat_difference=max(repeat_difference,max(abs(x-y) for a,b in zip(logits,unique[identity]) for x,y in zip(a,b)))
                else:unique[identity]=logits
                for field,target,values,prediction in zip(FIELDS,expected,logits,row['predicted_token_ids'][slot]):
                    peak=max(values);denom=sum(math.exp(value-peak) for value in values)
                    support=class_ids[field];within=sum(math.exp(values[index]-peak) for index in support)
                    require(prediction==max(range(32),key=values.__getitem__),'saved argmax differs')
                    out=per_field[field];out['ce'].append(peak+math.log(denom)-values[target]);out['class_ce'].append(peak+math.log(within)-values[target])
                    out['outside_mass'].append(1-within/denom);out['margin'].append(values[target]-max(value for i,value in enumerate(values) if i!=target))
                    out['correct']+=prediction==target;out['predictions'][vocab[prediction]]+=1
        fields={}
        for field,data in per_field.items():
            require(data['correct']==panel['source_values']['by_field'][field]['correct'],'raw-head count differs')
            fields[field]=dict(presentations=len(data['ce']),correct=data['correct'],full_vocabulary_ce=statistics.fmean(data['ce']),
                training_label_support_conditional_ce=statistics.fmean(data['class_ce']),
                probability_mass_outside_observed_training_labels=statistics.fmean(data['outside_mass']),
                target_vs_best_other_margin=stats(data['margin']),predicted_tokens=dict(data['predictions']))
        pair_results=[]
        for pair in object_pairs:
            record={k:pair[k] for k in ('left','right','literal_single_field_text_contrast')};chosen=[];correct=[]
            for identity in (pair['left'],pair['right']):
                values=unique[identity][3];prediction=max(range(32),key=values.__getitem__)
                chosen.append(prediction);correct.append(prediction==clauses[identity]['target_token_ids']['object'])
            record.update(predicted_same_token=chosen[0]==chosen[1],both_correct=all(correct),either_correct=any(correct),predicted_token_ids=chosen)
            pair_results.append(record)
        raw_readouts[name]=dict(fields=fields,unique_training_clauses=len(unique),maximum_repeated_clause_raw_logit_difference=repeat_difference,
            training_exact=panel['source_fidelity']['metrics']['ordered_exact'],training_rows=48,
            generated_scalar_by_field=panel['source_fidelity']['by_facet'],
            object_contrasts=dict(rows=pair_results,both_correct=sum(row['both_correct'] for row in pair_results),
                predicted_same_token=sum(row['predicted_same_token'] for row in pair_results),
                literal_both_correct=sum(row['both_correct'] and row['literal_single_field_text_contrast'] for row in pair_results),
                literal_predicted_same_token=sum(row['predicted_same_token'] and row['literal_single_field_text_contrast'] for row in pair_results)),
            metrics_from_saved_training_logits=True,new_forward_executed=False)
    initial_refs={}
    for seed in (1729,2718):
        arm=arms[f'8-boundary-first-last-{seed}'][0];ref=arm['states']['initial'];state=read(ref['path'])
        require(sha(ref['path'])==ref['sha256'] and state['dimension']==8 and state['role']=='initial','initial state identity differs')
        require(state['input_transform']==transform and state['architecture']['clause_normalization']==norm,'initial preprocessing differs')
        initial_refs[str(seed)]=dict(ref,publication_manifest=str(P/MANIFEST),publication_git_commit=BASE)
    export=dict(schema='training-object-readout-inputs/v1',dimension=8,training_rows=48,clause_occurrences=len(occurrences),
        unique_training_clauses=len(clauses),fields=list(FIELDS),target_vocabulary=vocab,occurrences=occurrences,
        unique_clauses=[clauses[key] for key in identities],input_transform=transform,
        clause_normalization=dict(mean=norm['mean'],scale=norm['scale'],normalization=norm['normalization'],
            receipt_sha256=norm['receipt_sha256'],training_contexts_sha256=norm['training_contexts_sha256']),
        float32_model_buffers=dict(clause_source_mean=[f32(x) for x in norm['mean']],clause_source_scale=f32(norm['scale'])),
        identity_projection_policy=prep['projection_policy'],representation=prep['representation'],
        initial_baseline_states=initial_refs,source_inputs_sha256=digest(contexts),
        label_alignment='authenticated_authored_training_source_clause_ordinal_to_reference_rule',
        publication_manifest_sha256=sha(P/MANIFEST),publication_git_commit=BASE,
        validation_entries_present=False, **FALSE)
    export['contents_sha256']=digest(export)
    export_ref=save(R/'training-object-inputs.json',export)
    for path,record in ARTIFACTS.items():require(sha(path)==record['sha256'],'saved input changed during diagnosis')
    require(not any(name.startswith(('torch','ipfs_datasets_py')) for name in sys.modules),'diagnostic imported model/runtime package')
    receipt=dict(schema='training-object-readout-geometry/v1',complete=True,passed=True,findings=[],
        created_at=datetime.now(timezone.utc).isoformat(),published_base=BASE,training_rows=48,
        unique_training_clauses=len(clauses),clause_occurrences=len(occurrences),dimension=8,
        source_only_container_included_unread_validation_branch=True,
        validation_targets_read=False,validation_vectors_computed=False,
        float32_arithmetic='stdlib IEEE754 single rounding after tensor cast, subtraction and division; input stage exactly checked against saved projected features',
        raw_vs_projected='input center/RMS; frozen zero-up residual identity; training-clause center/global-RMS before64-wide tanh heads',
        structure=dict(action_branch='independent8to64 tanh plus32-class action readout',
            non_action_branch='shared8to64 tanh plus three32-class actor/modality/object readouts',
            recurrence='concat existing non_action/action64-vectors into128-to16 learned clause residual',
            source_readout_outputs_are_additive_full_vocabulary_generation_residuals=True,
            no_object_specific_feature_branch=True),
        input_transform=transform,clause_normalization_buffers=export['float32_model_buffers'],
        geometry=geometry,field_contrasts=contrast,object_contrast_rows=object_pairs,
        saved_training_readouts=raw_readouts,training_only_probe_inputs=export_ref,
        source_provenance=sources,artifacts=ARTIFACTS,checks=CHECKS,
        limitations=['Exact distinct vectors do not prove finite-head separability, optimization, capacity or generalization.',
            'Nearest-neighbor agreement is descriptive training geometry, not a fitted classifier or held-out score.',
            'No learned affine/tanh/decoder forward or gradient was executed; readout metrics use saved logits.',
            'The8D inputs are historical linguistic-feature hashes; this sidecar is not the untouched legacy teacher.',
            'Mixed split source-container bytes were authenticated, but only its train mapping entered computations.'],**FALSE)
    receipt['script_sha256']=sha(__file__)
    save(R/'training-object-geometry.json',receipt)
    print(json.dumps(dict(complete=True,checks=CHECKS,object_contrasts=contrast['object'],
        nearest_object_matches={stage:value['nearest_neighbor']['all_same_object'] for stage,value in geometry.items()},
        object_readouts={name:value['fields']['object'] for name,value in raw_readouts.items()},probe_inputs=export_ref),sort_keys=True))


if __name__=='__main__': main()
