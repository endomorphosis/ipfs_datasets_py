"""Independent torch arithmetic check of training-only exported features; no decoder forward."""
import hashlib
import json
import math
from pathlib import Path
import subprocess

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
BASE='64bc5734dc82db72e955f2e809b770127e9b6cfc'


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(value):return hashlib.sha256(raw(value)).hexdigest()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(value,message):
    if not value:raise ValueError(message)


def verify():
    import torch
    receipt_path=R/'probe-adapter-receipt.json';receipt_sha=sha(receipt_path);adapter=json.loads(receipt_path.read_bytes())
    immutable_inputs={str(receipt_path):receipt_sha}
    geometry_path=Path(adapter['geometry_receipt']['path'])
    require(sha(geometry_path)==adapter['geometry_receipt']['sha256'],'geometry receipt changed')
    geometry=json.loads(geometry_path.read_bytes());immutable_inputs[str(geometry_path)]=adapter['geometry_receipt']['sha256']
    source_path=Path(adapter['raw_training_export']['path'])
    require(sha(source_path)==adapter['raw_training_export']['sha256'],'raw training export changed')
    source=json.loads(source_path.read_bytes());immutable_inputs[str(source_path)]=adapter['raw_training_export']['sha256']
    require(source['contents_sha256']==digest({k:v for k,v in source.items() if k!='contents_sha256'}),'raw export content changed')
    probe_ref=adapter['inputs']['training'];training_path=Path(probe_ref['path'])
    require(sha(training_path)==probe_ref['sha256'],'normalized training export changed')
    training=json.loads(training_path.read_bytes());immutable_inputs[str(training_path)]=probe_ref['sha256']
    require(digest(training)==probe_ref['contents_sha256'],'normalized content digest changed')
    require(len(source['occurrences'])==len(training['rows'])==180,'exact training occurrence count required')
    require(all(row['span_id'].startswith('authored-paragraph:train:') for row in source['occurrences'])
        and training['split']=='train','training-only vectors required')
    provenance={}
    for relative,record in geometry['source_provenance'].items():
        require(record['git_commit']==BASE and sha(record['path'])==record['sha256'],'frozen source binding changed')
        published=subprocess.check_output(['git','show',BASE+':'+relative],cwd=P)
        require(hashlib.sha256(published).hexdigest()==record['sha256'],'published/frozen source differs')
        provenance[relative]=record;immutable_inputs[record['path']]=record['sha256']
    projection={}
    for seed,state_ref in adapter['initial_full_states'].items():
        state_path=Path(state_ref['path']);require(sha(state_path)==state_ref['sha256'],'original initial state changed')
        state=json.loads(state_path.read_bytes());immutable_inputs[str(state_path)]=state_ref['sha256']
        require(state['role']=='initial' and state['dimension']==8 and state['weights_sha256']==digest(state['model_state']),
            'authenticated initial state required')
        keys=[key for key in state['model_state'] if '.projection_down.' in key or '.projection_up.' in key]
        require(len(keys)==4,'exact frozen projection tensor inventory required')
        def flatten(value):
            if type(value) is list:
                for item in value:yield from flatten(item)
            else:yield value
        for key in keys:
            values=list(flatten(state['model_state'][key]))
            require(values and all(type(x) in (int,float) and math.isfinite(x) for x in values),'nonfinite saved projection')
            require('.projection_up.' not in key or all(x==0. for x in values),'projection-up differs from zero identity residual')
        projection[seed]=dict(path=str(state_path),sha256=state_ref['sha256'],finite_projection_parameters=True,
            zero_projection_up_weight_and_bias=True,learned_projection_executed=False)
    transform=source['input_transform'];buffers=source['float32_model_buffers']
    # These are exactly the preprocessing tensor operations described by the
    # pinned context/head methods. No module, affine head or decoder is called.
    raw_vectors=torch.tensor([row['raw_vector'] for row in source['occurrences']],dtype=torch.float32)
    input_mean=torch.tensor(transform['mean'],dtype=torch.float32)
    transformed=(raw_vectors-input_mean)/transform['scale']
    identity_projected=transformed
    normalized=(identity_projected-torch.tensor(buffers['clause_source_mean'],dtype=torch.float32))/torch.tensor(
        buffers['clause_source_scale'],dtype=torch.float32)
    expected=torch.tensor([row['input'] for row in training['rows']],dtype=torch.float32)
    require(tuple(expected.shape)==tuple(normalized.shape)==(180,8),'feature geometry differs')
    require(bool(torch.isfinite(normalized).all()) and torch.equal(normalized,expected),
        'actual torch preprocessing differs from exported float32 features')
    for observed,row,record,original in zip(normalized.tolist(),training['rows'],adapter['operations']['rows'],source['occurrences']):
        require(row['id']==record['id']==original['span_id']+':slot:'+str(original['slot'])
            and row['source_sha256']==original['source_sha256']
            and observed==record['head_normalized_float32'],'per-occurrence operation binding differs')
    for path,expected_hash in immutable_inputs.items():
        require(sha(path)==expected_hash,'bound arithmetic input changed: '+path)
    result=dict(schema='training-object-feature-tensor-arithmetic-check/v1',complete=True,passed=True,
        rows=180,coordinates=1440,dtype=str(normalized.dtype),device=str(normalized.device),torch_version=torch.__version__,
        exact_tensor_equal=True,maximum_absolute_difference=float((normalized-expected).abs().max()),
        raw_tensor_values_sha256=digest(raw_vectors.tolist()),input_transformed_values_sha256=digest(transformed.tolist()),
        normalized_values_sha256=digest(normalized.tolist()),training_file_sha256=probe_ref['sha256'],
        training_contents_sha256=probe_ref['contents_sha256'],adapter_receipt_sha256=sha(receipt_path),
        raw_training_export_sha256=sha(source_path),source_provenance=provenance,initial_projection_evidence=projection,
        published_base=BASE,script_sha256=sha(__file__),scope='arithmetic cross-check only; not actual decoder execution',
        model_imported=False,model_executed=False,fitted_head_executed=False,decoder_executed=False,
        validation_labels_used=False,validation_vectors_used=False,training_executed=False,weights_changed=False,
        qualified=False,admitted=False,lake_executed=False,checkpoint_promoted=False)
    output=R/'tensor-crosscheck.json';require(not output.exists(),'arithmetic receipt already exists')
    output.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({key:result[key] for key in ('complete','rows','coordinates','exact_tensor_equal','maximum_absolute_difference')}),flush=True)
    return result


if __name__=='__main__':verify()
