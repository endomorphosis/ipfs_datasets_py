"""Independent arithmetic over completed saved training-only probe reports; no model imports."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

R=Path(__file__).resolve().parent
STEPS=(0,1,10,25,100,340,1000)
MODES=('shared_non_action','isolated_object')
PARAMETERS=('source_projection.weight','source_projection.bias','field_readout.weight','field_readout.bias')
ARTIFACTS={}
CHECKS=0
FALSE=dict(model_executed=False,training_executed=False,validation_access=False,decoder_executed=False,
    qualified=False,admitted=False,lake_executed=False,checkpoint_promoted=False,convergence_proven=False,
    best_checkpoint_selected=False,fresh_holdout=False)


def require(value,message):
    global CHECKS
    CHECKS+=1
    if not value:raise ValueError(message)


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(value):return hashlib.sha256(raw(value)).hexdigest()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path,expected=None):
    path=Path(path).resolve();data=path.read_bytes();actual=hashlib.sha256(data).hexdigest()
    require(expected is None or actual==expected,'input digest differs: '+str(path))
    record=dict(sha256=actual,bytes=len(data));require(str(path) not in ARTIFACTS or ARTIFACTS[str(path)]==record,'input changed during analysis')
    ARTIFACTS[str(path)]=record
    return json.loads(data)


def close(a,b,label,atol=2e-5,rtol=2e-5):
    require(type(a) in (int,float) and type(b) in (int,float) and math.isfinite(a) and math.isfinite(b)
        and math.isclose(a,b,abs_tol=atol,rel_tol=rtol),label)


def flatten(value):
    if type(value) is list:
        for item in value:yield from flatten(item)
    else:
        require(type(value) in (int,float) and math.isfinite(value),'finite numerical array required')
        yield value


def norm_difference(a,b):
    aa,bb=list(flatten(a)),list(flatten(b));require(len(aa)==len(bb),'parameter shapes differ')
    return math.sqrt(math.fsum((x-y)**2 for x,y in zip(aa,bb)))


def numbers(values):
    require(values and all(math.isfinite(value) for value in values),'nonempty finite numeric observations required')
    return dict(minimum=min(values),median=statistics.median(values),mean=statistics.fmean(values),maximum=max(values))


def initial_parameters(head,mode):
    parameters=dict(head['parameters'])
    if mode=='isolated_object':
        parameters['field_readout.weight']=parameters['field_readout.weight'][64:96]
        parameters['field_readout.bias']=parameters['field_readout.bias'][64:96]
    return parameters


def checkpoint_summary(checkpoint,report,training,initial,previous,updates):
    step=checkpoint['step'];fields=report['fields'];rows=training['rows']
    require(checkpoint['metrics_scope']=='raw_training_readout_only'
        and checkpoint['gradient_scope']=='separate_coefficient_scaled_full_vocabulary_ce','checkpoint metric scope differs')
    require(set(checkpoint['fields'])==set(fields),'checkpoint fields differ')
    parameters=checkpoint['parameters'];require(digest(parameters)==checkpoint['parameters_sha256'],'checkpoint parameter hash differs')
    require(set(parameters)==set(PARAMETERS),'parameter inventory differs')
    motion={}
    for name in PARAMETERS:
        movement=norm_difference(parameters[name],initial[name]);motion[name]=movement
        close(movement,checkpoint['parameter_l2_motion_from_initial'][name],'parameter motion from initial differs',1e-9,1e-9)
        if previous is not None:
            displacement=norm_difference(parameters[name],previous['parameters'][name])
            charged=sum(update['parameter_l2_step'][name] for update in updates[previous['step']:step])
            require(displacement <= charged+1e-7*(1+charged),'parameter displacement exceeds sum of committed step motion')
    result={};weighted=0.
    for field in fields:
        value=checkpoint['fields'][field];logits=value['logits'];targets=[row['labels'][field] for row in rows]
        require(len(logits)==len(targets)==value['rows']==180,'complete checkpoint cohort required')
        require(value['field_coefficient']==.0625,'field weight differs')
        support=sorted(set(targets));ces=[];conditional=[];outside=[];margins=[];predictions=[]
        for vector,target in zip(logits,targets):
            require(len(vector)==32 and all(type(x) in (int,float) and math.isfinite(x) for x in vector),'full32V logits required')
            peak=max(vector);denominator=math.fsum(math.exp(x-peak) for x in vector)
            within=math.fsum(math.exp(vector[index]-peak) for index in support)
            ces.append(peak+math.log(denominator)-vector[target]);conditional.append(peak+math.log(within)-vector[target])
            outside.append(1-within/denominator)
            margins.append(vector[target]-max(x for index,x in enumerate(vector) if index!=target))
            predictions.append(max(range(32),key=vector.__getitem__))
        correct=sum(a==b for a,b in zip(predictions,targets));ce=statistics.fmean(ces)
        require(predictions==value['predictions'] and correct==value['correct'],'saved predictions/correct count differs')
        close(ce,value['cross_entropy'],'full32V CE arithmetic differs')
        close(correct/180,value['accuracy'],'accuracy arithmetic differs',1e-12,1e-12)
        require(len(value['target_minus_best_other_margins'])==180,'complete margins required')
        for actual,saved in zip(margins,value['target_minus_best_other_margins']):close(actual,saved,'target margin differs')
        close(.0625*ce,value['weighted_cross_entropy'],'weighted field CE differs')
        weighted+=.0625*ce
        gradient=value['weighted_gradient_norms']
        require(set(gradient)=={'all','source_projection','field_readout'}
            and all(math.isfinite(x) and x>=0 for x in gradient.values()),'finite gradient norms required')
        close(gradient['all']**2,gradient['source_projection']**2+gradient['field_readout']**2,
            'gradient block norm geometry differs',1e-9,1e-9)
        if step==0:require(gradient['source_projection']==0.,'zero readout unexpectedly gave initial projection gradient')
        result[field]=dict(correct=correct,rows=180,accuracy=correct/180,full_vocabulary_ce=ce,
            observed_training_label_support_conditional_ce=statistics.fmean(conditional),
            probability_mass_outside_observed_training_labels=statistics.fmean(outside),
            margin=numbers(margins),positive_margins=sum(x>0 for x in margins),zero_margins=sum(x==0 for x in margins),
            weighted_gradient_norms=gradient,field_coefficient=.0625)
    close(weighted,checkpoint['objective'],'checkpoint objective differs')
    geometry=checkpoint['projection_gradient_geometry']
    require(len(geometry)==len(fields)*(len(fields)-1)//2,'gradient pair inventory differs')
    seen=set()
    for pair in geometry:
        left,right=pair['left'],pair['right'];require(left in fields and right in fields and left!=right,'gradient pair field differs')
        require((left,right) not in seen,'duplicate gradient pair');seen.add((left,right))
        a=result[left]['weighted_gradient_norms']['source_projection'];b=result[right]['weighted_gradient_norms']['source_projection']
        require(pair['zero_gradient']==(a==0 or b==0),'gradient zero flag differs')
        if a==0 or b==0:
            require(pair['projection_cosine'] is None and pair['projection_dot']==0.,'zero-gradient geometry differs')
        else:
            close(pair['projection_dot']/(a*b),pair['projection_cosine'],'gradient cosine arithmetic differs',1e-10,1e-8)
            require(abs(pair['projection_cosine'])<=1+1e-10,'gradient cosine outside range')
    return dict(step=step,clause_occurrence_presentations=step*180,
        scalar_target_presentations=step*180*len(fields),fields=result,objective=weighted,
        parameter_l2_motion_from_initial=motion,projection_gradient_geometry=geometry,
        selected=False,no_generated_formula_metrics=True)


def summarize_report(report,entry,training,head):
    mode=entry['mode'];rate=entry['learning_rate'];fields=['actor','modality','object'] if mode=='shared_non_action' else ['object']
    require(report['schema']=='source-field-readout-probe/v1' and report['complete'] is True
        and report['mode']==mode and report['learning_rate']==rate and report['fields']==fields,'complete matching probe required')
    require(report['training_sha256']==digest(training) and report['initial_head_sha256']==digest(head),'probe content binding differs')
    require(report['source_order_sha256']==digest([row['id'] for row in training['rows']])
        and report['source_inputs_sha256']==digest([row['input'] for row in training['rows']])
        and report['source_literals_sha256']==digest([row['source_sha256'] for row in training['rows']]),'source/order binding differs')
    require(report['completed_updates']==report['requested_updates']==1000 and report['stopped_reason']=='updates_completed'
        and report['requested_checkpoints']==list(STEPS),'probe exposure/stopping differs')
    require(report['training_occurrences']==180 and report['training_unique_clauses']==113
        and report['row_presentations']==180000 and report['scalar_target_presentations']==180000*len(fields),'presentation counts differ')
    require(report['field_coefficient']==.0625 and report['dimension']==8 and report['hidden_width']==64
        and report['vocabulary_size']==32,'probe head geometry differs')
    require(report['optimizer']==dict(name='AdamW',betas=[.9,.999],eps=1e-8,weight_decay=.01,
        foreach=False,max_grad_norm=1.,full_batch=True,scheduler=None),'fixed optimizer settings differ')
    require(report['training_only'] and not report['validation_access'] and not report['formula_decoder_used']
        and not report['generated_formula_metrics_computed'] and not report['qualification_gates_changed'], 'probe authority changed')
    require(not report['optimizer_resumable'] and not report['pending_update_rolled_back'],'incomplete transaction/resume claim')
    for key in ('lake_executed','admitted','qualified','production_checkpoint','convergence_proven'):require(report[key] is False,'unexpected probe authority')
    updates=report['updates'];require(len(updates)==1000,'complete committed update ledger required')
    for step,update in enumerate(updates,1):
        require(update['step']==step and set(update['field_cross_entropy'])==set(fields),'update sequence/fields differ')
        require(all(math.isfinite(ce) and ce>=0 for ce in update['field_cross_entropy'].values()),'finite field CE required')
        close(.0625*sum(update['field_cross_entropy'].values()),update['objective'],'committed objective differs')
        require(update['clipping_limit']==1. and math.isfinite(update['preclip_norm']) and update['preclip_norm']>=0,'clipping scope differs')
        close(update['clipping_coefficient'],min(1.,1./(update['preclip_norm']+1e-6)),'clipping coefficient differs',1e-12,1e-12)
        blocks=update['preclip_gradient_norms'];require(set(blocks)=={'source_projection','field_readout'},'preclip blocks differ')
        close(update['preclip_norm']**2,blocks['source_projection']**2+blocks['field_readout']**2,'preclip norm blocks differ')
        require(set(update['parameter_l2_step'])==set(PARAMETERS)
            and all(math.isfinite(x) and x>=0 for x in update['parameter_l2_step'].values()),'finite step motions required')
    initial=initial_parameters(head,mode)
    checkpoints=report['checkpoints'];require([point['step'] for point in checkpoints]==list(STEPS),'all endpoints required')
    require(checkpoints[0]['parameters']==initial,'fresh initial head or object slice differs')
    points=[];previous=None
    for checkpoint in checkpoints:
        points.append(checkpoint_summary(checkpoint,report,training,initial,previous,updates));previous=checkpoint
    require(report['final_parameters']==checkpoints[-1]['parameters']
        and report['final_parameters_sha256']==digest(report['final_parameters'])==checkpoints[-1]['parameters_sha256'],
        'final parameter state differs')
    require(report['final_adam_state_sha256']==digest(report['final_adam_state']),'final Adam digest differs')
    for name,state in report['final_adam_state'].items():
        require(name in PARAMETERS and state['step']==1000,'Adam step differs')
        require(len(list(flatten(state['exp_avg'])))==len(list(flatten(report['final_parameters'][name])))
            ==len(list(flatten(state['exp_avg_sq']))),'Adam state shape differs')
        require(all(x>=0 for x in flatten(state['exp_avg_sq'])),'negative Adam second moment')
    close(entry['object_cross_entropy'],points[-1]['fields']['object']['full_vocabulary_ce'],'summary endpoint CE differs')
    require(entry['object_correct']==points[-1]['fields']['object']['correct'],'summary endpoint correct differs')
    require(0 < report['elapsed_seconds'] <= entry['call_elapsed_seconds']+1e-6,'timing scope differs')
    return dict(seed=entry['seed'],mode=mode,learning_rate=rate,fields=fields,checkpoints=points,
        helper_seconds=report['elapsed_seconds'],call_seconds=entry['call_elapsed_seconds'],
        clause_occurrence_presentations=180000,scalar_target_presentations=180000*len(fields),
        clause_presentations_per_call_second=180000/entry['call_elapsed_seconds'],
        completed_updates=1000,clipped_updates=sum(update['clipping_coefficient']<1 for update in updates),
        preclip_norm=numbers([update['preclip_norm'] for update in updates]),
        update_parameter_motion={name:dict(total_path_length=sum(update['parameter_l2_step'][name] for update in updates),
            step_l2=numbers([update['parameter_l2_step'][name] for update in updates])) for name in PARAMETERS},
        objective_ledger_summary=dict(initial_update=updates[0]['objective'],final_update=updates[-1]['objective']),
        optimizer=report['optimizer'],numerical_runtime=report['numerical_runtime'],report_sha256=entry['report']['sha256'],**FALSE)


def proposed_document(data):
    lines=['This is a training-only8D readout diagnostic on180 clause occurrences from113 distinct training clauses. It varies shared actor/modality/object versus isolated object optimization, with learning rates0.001 and0.01, starting from each original fresh head. All32 vocabulary tokens remain in each CE; object isolation does not reduce the output vocabulary. No decoder, compiler, encoder or validation cohort runs here.', '',
        '| Seed | Mode | LR | Object correct /180 at updates0/1/10/25/100/340/1000 | Object CE at340 /1000 | Call seconds |',
        '|---:|---|---:|---|---|---:|']
    for run in data['runs'].values():
        points={p['step']:p for p in run['checkpoints']};obj=lambda step:points[step]['fields']['object']
        lines.append(f"| {run['seed']} | {run['mode']} | {run['learning_rate']} | {' / '.join(str(obj(step)['correct']) for step in STEPS)} | {obj(340)['full_vocabulary_ce']:.6f} / {obj(1000)['full_vocabulary_ce']:.6f} | {run['call_seconds']:.3f} |")
    lines += ['', '| Seed | Mode | LR | Update | Object CE | Correct /180 | Mean target margin | Minimum target margin | Object projection-gradient norm |',
        '|---:|---|---:|---:|---:|---:|---:|---:|---:|']
    for run in data['runs'].values():
        for point in run['checkpoints']:
            obj=point['fields']['object'];lines.append(f"| {run['seed']} | {run['mode']} | {run['learning_rate']} | {point['step']} | {obj['full_vocabulary_ce']:.6f} | {obj['correct']} | {obj['margin']['mean']:.6f} | {obj['margin']['minimum']:.6f} | {obj['weighted_gradient_norms']['source_projection']:.6f} |")
    lines += ['', '| Seed | LR | Update | Shared actor correct / CE | Shared modality correct / CE | Actor–object projection-gradient cosine | Modality–object projection-gradient cosine |',
        '|---:|---:|---:|---|---|---|---|']
    for run in data['runs'].values():
        if run['mode']!='shared_non_action':continue
        for point in run['checkpoints']:
            actor=point['fields']['actor'];modal=point['fields']['modality'];pairs={(p['left'],p['right']):p['projection_cosine'] for p in point['projection_gradient_geometry']}
            show=lambda key:'undefined (zero gradient)' if pairs[key] is None else f'{pairs[key]:.6f}'
            lines.append(f"| {run['seed']} | {run['learning_rate']} | {point['step']} | {actor['correct']} / {actor['full_vocabulary_ce']:.6f} | {modal['correct']} / {modal['full_vocabulary_ce']:.6f} | {show(('actor','object'))} | {show(('modality','object'))} |")
    lines += ['', '| Seed | Mode | LR | Clipped updates | Source-projection weight movement at340 /1000 | Readout weight movement at340 /1000 | Clause presentations/second |',
        '|---:|---|---:|---:|---|---|---:|']
    for run in data['runs'].values():
        points={p['step']:p for p in run['checkpoints']};motion=lambda step,name:points[step]['parameter_l2_motion_from_initial'][name]
        lines.append(f"| {run['seed']} | {run['mode']} | {run['learning_rate']} | {run['clipped_updates']} | {motion(340,'source_projection.weight'):.6f} / {motion(1000,'source_projection.weight'):.6f} | {motion(340,'field_readout.weight'):.6f} / {motion(1000,'field_readout.weight'):.6f} | {run['clause_presentations_per_call_second']:.1f} |")
    lines += ['', 'At340 updates each head has seen61,200 clause occurrences; at1,000 it has seen180,000. Shared mode has three targets per occurrence and isolated mode one. These full-batch exposures differ from the original paragraph curriculum, and the original combined decoder optimizer is not replayed. Training-only separability, optimization progress and wall time here cannot be substituted for long-span reconstruction, a held-out improvement, or equal-work comparisons against the full decoder.', '',
        'All checkpoints and both endpoint comparisons are retained; no best checkpoint or architecture is selected. Gradient cosine is a local diagnostic, not proof that interference causes an endpoint difference. The first source-projection gradient is zero because the fresh readout is zero; AdamW may still move projection weights through weight decay. Reported parameter movement includes all optimizer effects.', '',
        f"Eight probes took {data['comparison_elapsed_seconds']:.3f}s in the numerical runner; summed call time was {data['total_call_seconds']:.3f}s. One CPU worker, cached nonsemantic8D linguistic features, bridge names[], prover evaluation false and metric disk cache disabled. There is no bridge-on evaluate or cold parser timing, and no legal-IR target count was measured. Clause presentation rate describes repeated training examples, not legal-span inference throughput.", '',
        'The unchanged production qualification gates were not exercised or weakened by this isolated diagnostic. No Lake build, formula qualification, production checkpoint promotion, convergence proof, semantic-encoder claim or historical-teacher modification follows.']
    text='\n'.join(lines)+'\n'
    for a,b in [('training-only8D','training-only 8D'),('on180','on 180'),('from113','from 113'),('rates0.001','rates 0.001'),
        ('All32','All 32'),('at340','at 340'),(' /1000',' / 1000'),('At340','At 340'),('seen61,200','seen 61,200'),
        ('at1,000','at 1,000'),('seen180,000','seen 180,000'),('nonsemantic8D','nonsemantic 8D'),('names[]','names []')]:text=text.replace(a,b)
    return text


def main():
    guardian=read(R/'guardian-exit.json');require(guardian['returncode']==0,'successful guardian required')
    exit_receipt=read(R/'probe-r1/child-exit.json');require(exit_receipt['returncode']==0 and exit_receipt['leader_reaped'],'successful reaped child required')
    resources=read(R/'probe-r1/resources-final.json');require(resources['status']=='released'
        and resources['record']['artifacts_durable_asserted'] and resources['record']['attempt_exceeded_reservation'] is False,
        'successful resource finalization required')
    summary=read(R/'probe-r1/results/summary.json');require(summary['complete'] and len(summary['runs'])==8,'eight complete probes required')
    require(summary['training_only'] and summary['no_project_runtime_imported'] and not summary['bridge_on_timing'], 'standalone training-only scope differs')
    require(summary['worker_count']==1 and summary['sample_count']==180 and summary['unique_clause_count']==113
        and summary['bridge_names']==[] and not summary['legal_ir_evaluate_provers'] and not summary['metric_disk_cache_used'],
        'measurement configuration differs')
    manifest=read(R/'training-manifest.json',summary['manifest_sha256'])
    adapter=read(R/'probe-adapter-receipt.json',manifest['inputs'][str(R/'probe-adapter-receipt.json')])
    training=read(manifest['training_input'],manifest['inputs'][manifest['training_input']])
    require(digest(training)==adapter['inputs']['training']['contents_sha256'],'adapter/training binding differs')
    heads={int(seed):read(path,manifest['inputs'][path]) for seed,path in manifest['initial_heads'].items()}
    runs={}
    for entry in summary['runs']:
        require(entry['seed'] in (1729,2718) and entry['mode'] in MODES and entry['learning_rate'] in (.001,.01),'unplanned probe identity')
        require(entry['name']==str(entry['seed'])+'-'+entry['mode']+'-lr'+str(entry['learning_rate']),'probe name differs')
        require(entry['name'] not in runs,'duplicate probe')
        report=read(entry['report']['path'],entry['report']['sha256'])
        runs[entry['name']]=summarize_report(report,entry,training,heads[entry['seed']])
    require(len({(x['seed'],x['mode'],x['learning_rate']) for x in runs.values()})==8,'incomplete factorial inventory')
    comparisons=[]
    def obj(seed,mode,rate,step):
        return next(point for point in runs[str(seed)+'-'+mode+'-lr'+str(rate)]['checkpoints'] if point['step']==step)['fields']['object']
    for seed in (1729,2718):
        for step in (340,1000):
            for rate in (.001,.01):
                a,b=obj(seed,'shared_non_action',rate,step),obj(seed,'isolated_object',rate,step)
                comparisons.append(dict(kind='isolation',seed=seed,step=step,learning_rate=rate,
                    delta_isolated_minus_shared=dict(correct=b['correct']-a['correct'],ce=b['full_vocabulary_ce']-a['full_vocabulary_ce'],
                        mean_margin=b['margin']['mean']-a['margin']['mean'])))
            for mode in MODES:
                a,b=obj(seed,mode,.001,step),obj(seed,mode,.01,step)
                comparisons.append(dict(kind='learning_rate',seed=seed,step=step,mode=mode,
                    delta_0010_minus_0001=dict(correct=b['correct']-a['correct'],ce=b['full_vocabulary_ce']-a['full_vocabulary_ce'],
                        mean_margin=b['margin']['mean']-a['margin']['mean'])))
    data=dict(schema='training-object-readout-probe-outcomes/v1',complete=True,passed=True,findings=[],
        created_at=datetime.now(timezone.utc).isoformat(),runs=runs,comparisons=comparisons,
        comparison_elapsed_seconds=summary['elapsed_seconds'],total_call_seconds=sum(run['call_seconds'] for run in runs.values()),
        guardian_exit=guardian,child_exit=exit_receipt,resource_finalization_status=resources['status'],
        measurement=dict(worker_count=1,device='CPU',training_clause_occurrences=180,unique_training_clauses=113,
            source_paragraphs=48,input_kind='nonsemantic_historical_linguistic_feature_hash',source_inputs_cached=True,
            bridge_names=[],legal_ir_evaluate_provers=False,metric_disk_cache_used=False,legal_ir_target_count_measured=False,
            bridge_on_evaluate_measured=False,cold_parser_timing=False,span_inference_timing=False),
        all_endpoints_retained=True,original_decoder_training_replayed=False,
        arithmetic_scope='saved logits/parameters/metrics only; no independent forward, backward or training',
        full_batch_exposure_at340=61200,full_batch_exposure_at1000=180000,artifacts=ARTIFACTS,**FALSE)
    for path,record in ARTIFACTS.items():require(sha(path)==record['sha256'],'input changed before final write')
    require(not any(name.startswith(('torch','ipfs_datasets_py')) for name in sys.modules),'analyzer imported model/runtime')
    data['checks']=CHECKS
    output=R/'outcomes.json';doc=R/'proposed-outcomes-doc.txt'
    require(not output.exists() and not doc.exists(),'analysis output already exists')
    documentation=proposed_document(data)
    output.write_text(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+'\n');doc.write_text(documentation)
    print(json.dumps(dict(complete=True,runs=len(runs),checkpoints=56,checks=CHECKS,
        final_objects={key:run['checkpoints'][-1]['fields']['object']['correct'] for key,run in runs.items()})))


if __name__=='__main__':main()
