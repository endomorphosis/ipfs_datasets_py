# Source readout diagnostics and optional head learning rates

The source head can learn slowly even when its clause vectors are distinct. The
training-only 8D probes below improved object readout accuracy by increasing the
learning rate of the existing head. This supports a matched full-decoder
experiment; it does not establish a global optimum, fresh holdout improvement,
or successful autoformalization.

The historical 8D linguistic teacher remains unchanged. These experiments use a
separate learned formula sidecar whose 8D inputs are cached, nonsemantic
linguistic-feature hashes. The 384D and 768D comparison lanes use their own
authenticated cached semantic inputs. Width alone does not identify a lineage,
input representation, codec, or decoder.

## Where to start

| Purpose | Entry point |
| --- | --- |
| Fit only an authenticated existing source head | [source_field_readout_probe.py](../../ipfs_datasets_py/logic/formalization/autoencoder/source_field_readout_probe.py) |
| Run the fixed eight-probe comparison | [benchmark_source_field_readout_probe.py](../../scripts/ops/autoencoder/benchmark_source_field_readout_probe.py) |
| Train a full source-conditioned decoder with optional head rates | [long_span_source_value_training.py](../../ipfs_datasets_py/logic/formalization/autoencoder/long_span_source_value_training.py) |
| Run the matched 8D/384D/768D decoder comparison | [benchmark_source_head_learning_rate.py](../../scripts/ops/autoencoder/benchmark_source_head_learning_rate.py) |
| Understand source fidelity, length limits, and retained unselected states | [decoder_length_distillation.md](decoder_length_distillation.md) |
| Use the unchanged historical teacher | [legacy_linguistic_training.md](legacy_linguistic_training.md) |

Use the workspace source tree or the exact frozen sources named in the run
manifest. In this workspace, a bare `import ipfs_datasets_py` can resolve to the
HACC editable checkout. Do not substitute that parser/runtime to make a test run.
The standalone readout probe intentionally imports no project package, parser,
encoder, compiler, or formula decoder; the decoder benchmark validates its pinned
dependency and extension trees.

## The training-only diagnosis

The diagnostic cohort has **180 clause occurrences from 113 distinct clauses in
48 authored Legal development paragraphs**. These are development fixtures, not
a completed US Code or Constitution corpus. Only the training partition supplies
probe inputs and labels. Object labels have 90 occurrences each, so the majority
baseline is 90/180. Repeated occurrences retain their original weighting.

The [geometry receipt](../../workspace/test-logs/decoder-object-readout-20261003/training-object-geometry.json)
found 113 distinct vectors after float32 input transformation and clause
normalization, with no contradictory-label collision groups. Nevertheless,
literal object substitutions can produce nearby vectors: the 34 inspected
literal object pairs have a mean normalized distance of 0.025529. Distinct
vectors do not prove that a particular finite head can separate all labels or
that optimization will find suitable weights.

The existing factorized head has an independent action branch and a shared
actor/modality/object branch. Each branch uses a learned affine projection into
64 tanh features. The shared branch has three separate full-vocabulary readouts.
Its zero-initialized readout causes the source projection's first task gradient
to be zero; subsequent gradients can be nonzero. AdamW weight decay can still
move projection weights on that first update. There is no object-specific
projection in this architecture. The full decoder also receives paragraph and
causal prefix information, so a raw source-head score is not its formula score.

The probe tests two private copies of the original fresh head for each seed:

| Mode | Trainable parameters | Objective |
| --- | --- | --- |
| `shared_non_action` | Original source projection and actor/modality/object readouts | `0.0625 * (CE_actor + CE_modality + CE_object)` |
| `isolated_object` | Exact copy of that projection and only its object readout rows | `0.0625 * CE_object` |

Each CE is a mean over all 180 occurrences and all **32 vocabulary logits**.
The object coefficient stays `0.25 / 4 = 0.0625`, matching its contribution to
the full trainer's four-field auxiliary loss. No logits are masked to the two
observed object labels. Isolation is a diagnostic parameter slice; it does not
install a new production decoder architecture.

Both modes use AdamW with betas `(0.9, 0.999)`, epsilon `1e-8`, weight decay
`0.01`, `foreach=False`, and a gradient-norm limit of `1`. Each fresh fit uses
one fixed learning rate, `0.001` or `0.01`, for 1,000 full-batch updates. There is
no scheduler, validation access, checkpoint selection, or formula generation.
Checkpoints at updates `0, 1, 10, 25, 100, 340, 1000` retain head parameters,
full logits, full-vocabulary CE, accuracy, target margins, separate field
gradient norms, projection-gradient cosines, and parameter movement. The final
Adam state is evidence, not an optimizer-resume interface.

## Measured eight-probe results, 2026-10-03

All accuracies below are **correct training occurrences out of 180**. CE is the
unweighted full-vocabulary object CE reconstructed from saved logits. Each row
is a separate fresh fit; it does not add 180 new independent examples.

| Seed | Mode | LR | Correct at 340 | Correct at 1,000 | CE at 340 | CE at 1,000 | Call seconds |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 1729 | shared_non_action | 0.001 | 103/180 | 110/180 | 0.705581 | 0.659345 | 1.352 |
| 1729 | shared_non_action | 0.01 | 135/180 | 162/180 | 0.501926 | 0.268268 | 0.736 |
| 1729 | isolated_object | 0.001 | 102/180 | 107/180 | 0.701380 | 0.675376 | 0.577 |
| 1729 | isolated_object | 0.01 | 140/180 | 176/180 | 0.454198 | 0.189325 | 0.570 |
| 2718 | shared_non_action | 0.001 | 101/180 | 108/180 | 0.704102 | 0.669677 | 0.714 |
| 2718 | shared_non_action | 0.01 | 134/180 | 163/180 | 0.502602 | 0.275790 | 0.713 |
| 2718 | isolated_object | 0.001 | 103/180 | 101/180 | 0.701400 | 0.679280 | 0.576 |
| 2718 | isolated_object | 0.01 | 139/180 | 172/180 | 0.462404 | 0.207880 | 0.581 |

At 340 updates, the shared head's higher rate also changes actor correctness
from 167/180 to 180/180 for both seeds. Modality correctness changes from
154/180 to 180/180 for seed 1729 and from 151/180 to 179/180 for seed 2718.
Object isolation alone at rate 0.001 has mixed effects. The measurements support
testing the existing head's learning rate before adding a new architecture;
they do not establish the cause of the full decoder's reconstruction errors.

Each probe has seen 61,200 clause occurrences at update 340 and 180,000 at
update 1,000. Shared mode has three scalar targets per occurrence; isolated mode
has one. These full-batch exposures differ from the full decoder's paragraph
curriculum and combined loss. No probe update was clipped. That observation does
not rule out clipping effects in the full decoder, which also trains recurrent,
count, boundary, and action-contrastive paths.

The numerical runner took **7.149 seconds**; the eight helper calls sum to
**5.819 seconds**. Per-call times above include private head setup, optimization,
and checkpoint diagnostics, and exclude the runner's report serialization and
resource admission. There is no repeated timing distribution or demonstrated
rate-dependent speedup. The guardian wrapper took 65.930 seconds including
admission, monitoring, and finalization; it is a different timing scope.

This measurement used one CPU worker, cached source inputs, bridge names `[]`,
prover evaluation `false`, and metric disk cache disabled. No legal-IR target
count, bridge-on evaluate time, cold parser time, or legal-span inference time
was measured. Repeated clause presentations per second are not spans formalized
per second.

**Peak RSS was not measured.** The resource audit has one live RSS sample and a
final sample, with no periodic observation file. The largest recorded sample is
115,986,432 bytes; the 2,048 MiB reservation is not evidence of a measured peak
or continuous memory enforcement. Final retained attempt data is 40,518,693
bytes under the 200,000,000-byte reservation, which was released successfully.

The [outcomes receipt](../../workspace/test-logs/decoder-object-readout-20261003/outcomes.json)
and [independent audit](../../workspace/test-logs/decoder-object-readout-20261003/independent-audit.json)
retain the eight fits and 56 checkpoints. The audit passed 47,070 checks with no
findings. It reconstructs saved affine/tanh/readout, CE, and gradient arithmetic
under its stated numerical error bounds; it does not independently replay all
Adam updates. The first audit attempt and its correction remain retained: the
correction handled an absent periodic RSS log without changing numerical
acceptance tolerances.

## Supplying authenticated probe inputs

`run_source_field_readout_probe` takes `torch`, a plain training object, and a
plain initial-head object. Its keyword arguments are:

```python
result = run_source_field_readout_probe(
    torch, training, initial_head,
    expected_training_sha256=authenticated_training_contents_sha256,
    expected_initial_head_sha256=authenticated_head_contents_sha256,
    mode="shared_non_action", learning_rate=0.01,
    max_updates=1000, checkpoints=(0, 1, 10, 25, 100, 340, 1000),
    deadline=absolute_monotonic_deadline,
)
```

The training schema is `source-field-readout-probe-training/v1`, with exactly
`schema`, `split="train"`, `dimension=8`, `vocabulary_size=32`, ordered
`fields=["actor", "modality", "object"]`, and `rows`. Every row has exactly
`id`, literal `source_sha256`, an eight-value `input`, and those three integer
`labels`. Inputs must already contain the authenticated frozen input projection
and clause normalization. Repeated literal sources must have identical inputs
and labels. The helper accepts at most 180 occurrences.

The initial-head schema is `source-field-readout-probe-initial-head/v1`, with
exactly `schema`, `dimension=8`, `vocabulary_size=32`, `hidden_width=64`, those
ordered `fields`, and `parameters`. Parameter names and shapes are:

| Parameter | Shape |
| --- | --- |
| `source_projection.weight` | `64 × 8` |
| `source_projection.bias` | `64` |
| `field_readout.weight` | `96 × 64`, actor/modality/object blocks |
| `field_readout.bias` | `96` |

Fresh readout values must be zero. The helper privately selects rows `64:96`
for isolated object mode. It rejects extra fields, nonfinite values, booleans
used as numbers, contradictory literals, and unbound hashes before fitting.
The external expected hashes must come from authenticated receipts; hashing an
untrusted object and immediately trusting that hash is not source provenance.

The [adapter receipt](../../workspace/test-logs/decoder-object-readout-20261003/probe-adapter-receipt.json)
binds the input export to predecessor commit
`64bc5734dc82db72e955f2e809b770127e9b6cfc`, its published manifest, both original
fresh full states, and the literal training inventory. The tensor cross-check
confirmed all 180 exported float32 feature vectors against the actual frozen
preprocessing arithmetic. Caller objects and CPU RNG are preserved. A deadline
crossing during a private update rolls back both parameters and Adam state;
partial receipts cannot pass the fixed runner's 1,000-update requirement.

## Enabling the full-decoder head learning rate

Add this keyword to an already authenticated `long_span_source_value_training.train`
call, keeping the existing training/evaluation inputs and loss settings:

```python
result = train(
    student, training_rows, validation_rows,
    non_action_learning_rate_multiplier=10.0,
    **existing_authenticated_training_options,
)
```

The default is `1.0`. It preserves the original single-group AdamW construction,
scheduler settings, tensor update path, and report schema. The opt-in multiplier
must be a finite, non-boolean number from 1 through 10. Base rate times multiplier
must not exceed `0.1`; an enabled scheduler floor must remain representable and
positive. An unsupported model is rejected rather than assigned guessed groups.

An enabled multiplier accepts only the checked
`action-factorized-clause-source-decoder-development/v1` and
`ordered-clause-recurrent-source-decoder-development/v1` classes. It applies to
exactly these four trainable tensors:

```text
non_action_head.source_projection.weight
non_action_head.source_projection.bias
non_action_head.field_readout.weight
non_action_head.field_readout.bias
```

One AdamW optimizer owns two disjoint, exhaustive groups: `base` contains all
other trainable parameters; `non_action_head` contains those four tensors.
Global gradient clipping still sees the entire original trainable parameter
order once. The action branch, recurrent decoder, count head, and other base
parameters keep the base rate. Raising the non-action projection rate can also
affect its learned recurrent features; this is not an object-only intervention.

The existing `ReduceLROnPlateau` metric and cadence remain unchanged. The enabled
path gives each group a proportional minimum rate and sets scheduler `eps=0` so
tiny reductions cannot be independently skipped and break the ratio. This
explicit scheduler epsilon differs from Adam's unchanged `eps=1e-8`. The
disabled path retains the original scheduler epsilon and scalar minimum.

Both groups retain the same AdamW weight-decay coefficient. Because decoupled
per-step shrinkage depends on `learning_rate * weight_decay`, a 10× learning
rate also increases that shrinkage 10× at the same coefficient. The experiment
does not silently compensate by changing decay.

Enabled reports add `optimizer_parameter_groups` with exact names, parameter
counts, initial/minimum/final rates, multipliers, and decay. They also add
`optimizer_group_learning_rates` on each committed update and epoch, plus start
and end rate maps on each curriculum stage. Commit rates precede that epoch's
scheduler step; epoch rates follow it. The old `learning_rate` field remains the
base group's rate. Adam state continues across stages, with one optimizer.

Loss weights, target access, full-vocabulary outputs, deadline handling, frozen
projections, and per-length fidelity/reconstruction selection gates are
unchanged. Raw source-head accuracy remains diagnostic and cannot select a
candidate on its own. Keep initial, selected, and last-complete-attempt states
distinct; a better unselected endpoint is not a promoted checkpoint.

The standalone probe freeze passed **72 tests**. The optional-rate change then
passed **166 focused regression tests** on CPU, including exact default reports,
one-step unchanged base-group tensors, both supported head classes, all three
widths' parameter inventories, scheduler floors/ratios, deadline cleanup, and
unchanged fidelity rejection. An earlier expanded test attempt had 12 failures
and 154 passes because PyTorch's accelerator health check attempted CUDA and
ran out of GPU memory; that log is retained. The same source passed with
`CUDA_VISIBLE_DEVICES=''`. The subsequent full frozen scope passed **2,708
tests in 54.66 seconds**. These are distinct test scopes, not additive counts or
evidence of corpus qualification.

## Reproducing a sealed comparison

The command entry points use `--phase training`, `--dependency-root`,
`--extension-root`, `--manifest`, `--plan`, and a fresh `--output`. Run the exact
frozen runner identified by the manifest. A plan fixes the cohort, seeds,
recipes, budgets, vocabulary, and authority flags; the manifest pins inputs and
producer bytes. Neither runner is an unconstrained hyperparameter CLI.

The retained local campaigns are:

```text
workspace/test-logs/decoder-object-readout-20261003
workspace/test-logs/decoder-source-head-lr-20261003
```

From `/home/barberb/lift_coding/external/ipfs_datasets`, the guarded launch form
is below. Each command starts a new bounded comparison, so use it only when
intentionally allocating a new attempt; never overwrite a completed attempt or
launch a duplicate of an active comparison.

```bash
D=workspace/test-logs/decoder-object-readout-20261003
python3 "$D/run_diagnostic_reserved.py" --phase training --attempt probe-replay-01

R=workspace/test-logs/decoder-source-head-lr-20261003
python3 "$R/run_training_reserved.py" --phase training --attempt training-replay-01
```

These wrappers enforce manifest hashes and use the existing resource owner and
shared scheduler. Retain a passed readiness audit and verify every artifact hash
in it before launch. The one-shot `run_guardian.py` files record the original
attempt's wrapper exit and refuse to overwrite it. They are not resumable
training entry points. New attempts start from the bound fresh state; neither
trainer exports an optimizer-resume contract.

For reference, the underlying standalone probe command is:

```bash
P=/home/barberb/lift_coding/external/ipfs_datasets
D="$P/workspace/test-logs/decoder-object-readout-20261003"
S="$P/workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2"
CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
python3 "$D/experiment-source/scripts/ops/autoencoder/benchmark_source_field_readout_probe.py" \
  --phase training --dependency-root "$S" --extension-root "$D/experiment-source" \
  --manifest "$D/training-manifest.json" --plan "$D/training-plan.json" \
  --output "$D/probe-manual-01/results"
```

The underlying command alone does not acquire the campaign resource reservation;
the guarded wrapper is the campaign launch path. CPU-only settings also avoid
an unrelated accelerator initialization during these CPU tests. No weight
downloads or backend changes are required.

Inspect the probe without retraining by reading `outcomes.json`,
`independent-audit.json`, and each `probe-r1/results/<arm>/probe.json`. Its
independent saved-arithmetic audit can be repeated with a new output file:

```bash
python3 "$D/independent_probe_audit_r2.py" \
  --source "$D/experiment-source" --manifest "$D/training-manifest.json" \
  --plan "$D/training-plan.json" --results "$D/probe-r1/results" \
  --output "$D/independent-audit-recheck.json"
```

## Full-decoder comparison: results pending

The registered comparison has twelve fresh fits: widths 8, 384, and 768, seeds
1729 and 2718, and baseline versus `non_action_learning_rate_multiplier=10`.
It uses the same exposed 48 training and 48 validation paragraphs, base rate
`0.001`, batch size 8, and four curriculum stages of 20 epochs. Each completed
arm must record 340 updates and the original exposure counts. Encoder context
and decoder output limits stay 512; generation temperature stays zero.

The two recipes retain count/source-value weights `0.25`, action-contrastive
weight `0.05`, and first/last generated-boundary weight `0.05`. Generated scalar
field supervision is disabled in both recipes. Architecture, original-order
global clipping, and qualification/selection rules are held fixed. Each of the
six baseline runs must replay the predecessor's tensors, numerical reports,
and control predictions, excluding only specified timing fields and their
time-dependent digest.

Full-decoder results and an independent results audit are pending. Report raw
per-field training/readout scores separately from generated formula exactness,
syntax, scalar fidelity, missing/extra rule content, count correctness, and
source/context controls. `whole_rules_extra` includes wrong-content substitutions
even when generated counts are correct. The exposed validation set is not a
fresh holdout, and frozen identity-projection MSE is not learned reconstruction.

Lake `lake build <Lib>` remains the only Lean admission. These probes perform
no Lake build or logic-family qualification. Numerical fitting, compiled text,
syntax checks, matching counts, and DuckDB/Hugging Face records do not confer
admission. The Constitution is not formalized and must not be marked
`roundtrip_ok`. The full experiment retains those authority boundaries even if
its decoder metrics improve.
