"""Test the exact standalone producers, then cross-check exported tensor arithmetic."""
from pathlib import Path
import hashlib, importlib.util, json, os, sys, time
R=Path(__file__).resolve().parent;S=R/'experiment-source'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
assert not (R/'tests-frozen.json').exists()
pins=read(R/'training-manifest.json')['extensions'] | read(R/'frozen-test-source.json')
for rel,h in pins.items():assert sha(S/rel)==h
check=R/'verify_exported_feature_tensors.py'
assert sha(check)=='9cb227e1b145dd1745f4397ca1ba54b6e27b80cf371b7528c6a9801a594d6e33'
os.environ.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',
 TRANSFORMERS_OFFLINE='1',CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
sys.dont_write_bytecode=True
sys.path.insert(0,str(S));os.chdir(S)
import pytest
started=time.monotonic()
code=pytest.main(['-q','-c','/dev/null','--confcutdir='+str(S),'-p','no:cacheprovider',
 '--junitxml='+str(R/'tests-frozen.xml'),*[str(S/p) for p in read(R/'frozen-test-source.json')]])
assert code==0,code
spec=importlib.util.spec_from_file_location('_exported_feature_tensor_crosscheck',check)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.verify()
for rel,h in pins.items():assert sha(S/rel)==h
assert not any(name=='ipfs_datasets_py' or name.startswith('ipfs_datasets_py.') for name in sys.modules)
receipt=dict(returncode=int(code),elapsed_seconds=time.monotonic()-started,source_sha256=pins,
 tensor_check_script_sha256=sha(check),tensor_check_sha256=sha(R/'tensor-crosscheck.json'),
 helper_imported_from=str(S/'ipfs_datasets_py/logic/formalization/autoencoder/source_field_readout_probe.py'),
 standalone=True,project_package_imported=False,real_training_probe_executed=False)
(R/'tests-frozen.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt),flush=True)
