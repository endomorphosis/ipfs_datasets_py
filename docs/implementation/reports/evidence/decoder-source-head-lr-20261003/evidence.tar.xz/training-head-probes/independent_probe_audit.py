"""Independent saved-array audit of the bounded training-only object-head probe.

Uses Python arithmetic only: no Torch, encoder, decoder, optimizer or prover is
imported or executed. Checkpoint affine/tanh/softmax arithmetic is reconstructed;
the intervening Adam trajectory is authenticated, not independently replayed.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import argparse
import ast
import hashlib
import json
import math
import struct
import subprocess
import xml.etree.ElementTree as ET

R=Path(__file__).resolve().parent
P=R.parents[2]
B=P/'workspace/test-logs/decoder-generated-field-training-r2-20261003'
BASE='64bc5734dc82db72e955f2e809b770127e9b6cfc'
PUBLIC='docs/implementation/reports/evidence/decoder-generated-field-training-r2-20261003/'
HELPER='ipfs_datasets_py/logic/formalization/autoencoder/source_field_readout_probe.py'
FIELDS=('actor','modality','object')
NAMES=('source_projection.weight','source_projection.bias','field_readout.weight','field_readout.bias')
STEPS=[0,1,10,25,100,340,1000]
UNIT_ROUNDOFF=2.**-24
TANH_ABSOLUTE_ALLOWANCE=4.*UNIT_ROUNDOFF
checks=0
findings=[]
artifacts={}


def raw(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def digest(value):return hashlib.sha256(raw(value)).hexdigest()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def f32(value):return struct.unpack('<f',struct.pack('<f',value))[0]


def check(value,label,detail=None):
    global checks
    checks+=1
    if not value:findings.append(dict(label=label,detail=detail))


def pin(path,expected=None):
    path=Path(path).resolve();value=dict(sha256=sha(path),bytes=path.stat().st_size)
    check(expected is None or value['sha256']==expected,'pin/'+str(path))
    artifacts[str(path)]=value
    return path


def read(path,expected=None):return json.loads(pin(path,expected).read_bytes())


def flatten(value):
    if isinstance(value,list):
        for item in value:yield from flatten(item)
    else:yield value


def shape(value):
    if not isinstance(value,list):return []
    if not value:return [0]
    child=shape(value[0])
    if any(shape(x)!=child for x in value):raise ValueError('ragged saved array')
    return [len(value)]+child


def norm(values):return math.sqrt(math.fsum(x*x for x in values))


def affine_error_bound(weights,values,bias):
    # Conservative floating dot-product gamma_(n+2) bound, allowing both the
    # product accumulation and separate bias add; no cancellation-relative test.
    n=len(weights)+2;gamma=n*UNIT_ROUNDOFF/(1.-n*UNIT_ROUNDOFF)
    return gamma*(math.fsum(abs(w*x) for w,x in zip(weights,values))+abs(bias))


def close(a,b,atol=2e-5,rtol=2e-5):
    return type(a) in (int,float) and type(b) in (int,float) and math.isfinite(a) and math.isfinite(b) and abs(a-b)<=atol+rtol*abs(b)


def typed_digest(values):
    result=hashlib.sha256()
    for name,value in sorted(values.items()):
        integer=name.split('.')[-1] in ('head_initialization_seed','ordered_clause_recurrent_version')
        result.update(raw([name,'torch.int64' if integer else 'torch.float32',shape(value)]))
        result.update(struct.pack('<q',value) if integer else b''.join(struct.pack('<f',v) for v in flatten(value)))
    return result.hexdigest()


def published_context():
    check(read(R/'base.json')['base']==BASE,'published/exact_base')
    published={}
    for name in ('manifest.json','results.json'):
        blob=subprocess.check_output(['git','show',BASE+':'+PUBLIC+name],cwd=P)
        published[name]=read(P/PUBLIC/name,hashlib.sha256(blob).hexdigest())
    manifest=published['manifest.json'];result=published['results.json']
    previous=read(B/'independent-audit.json',result['independent_audit_sha256'])
    check(previous['passed'] and previous['finding_count']==0 and result['guardian_succeeded'],
        'published/clean_previous_independent_review')
    def old(relative):
        path=(B/relative).resolve();member=manifest['original_artifact_archive_paths'].get(str(path))
        check(member in manifest['members'],'published/known_member/'+str(relative))
        entry=manifest['members'][member];value=read(path,entry['sha256'])
        check(path.stat().st_size==entry['bytes'],'published/member_size/'+str(relative))
        return value
    return dict(manifest=manifest,result=result,old=old)


def input_evidence(ctx):
    old=ctx['old'];export=read(R/'training-object-inputs.json')
    check(export['schema']=='training-object-readout-inputs/v1'
        and export['contents_sha256']==digest({k:v for k,v in export.items() if k!='contents_sha256'}),
        'inputs/export_digest_and_schema')
    check(export['publication_git_commit']==BASE and export['publication_manifest_sha256']==sha(P/PUBLIC/'manifest.json'),
        'inputs/published_binding')
    for key in ('admitted','checkpoint_promoted','convergence_proven','encoder_executed','historical_teacher_changed',
                'lake_executed','model_executed','model_imported','qualified','training_executed',
                'validation_labels_used','validation_vectors_used','weights_changed'):
        check(export[key] is False,'inputs/authority/'+key)
    check(export['validation_entries_present'] is False and export['dimension']==8 and export['training_rows']==48
        and export['clause_occurrences']==180 and export['unique_training_clauses']==113,
        'inputs/exact_training_inventory')
    prep=old('training-r1/results/8/preprocessing.json')
    envelope=old('training-r1/results/8/source-contexts.json');contexts=envelope['train'];del envelope
    panel=old('training-r1/results/8-boundary-first-last-1729/last-attempt/evaluation-training.json')
    initial={seed:old('training-r1/results/8-boundary-first-last-'+str(seed)+'/initial-state.json') for seed in (1729,2718)}
    vocab=initial[1729]['codec']['target_vocabulary'];transform=prep['input_transform'];normalization=prep['clause_normalization']
    check(export['target_vocabulary']==vocab and len(vocab)==32 and export['input_transform']==transform,
        'inputs/exact_vocabulary_and_paragraph_transform')
    check(export['source_inputs_sha256']==digest(contexts)==normalization['training_contexts_sha256']
        and normalization['validation_rows_used_for_fitting']==0,'inputs/training_only_context_and_normalization')
    check(export['representation']==prep['representation']
        and export['representation']['kind']=='historical_linguistic_feature_hash'
        and export['representation']['semantic_embedding'] is False
        and export['representation']['teacher_checkpoint_reconstruction'] is False,
        'inputs/historical_hash_not_checkpoint_or_semantic_encoder')
    for key,value in export['clause_normalization'].items():
        check(value==normalization[key],'inputs/clause_normalization/'+key)
    check(export['float32_model_buffers']==dict(clause_source_mean=[f32(v) for v in normalization['mean']],
        clause_source_scale=f32(normalization['scale'])),'inputs/exact_float32_model_buffers')
    labels={row['id']:row for row in panel['source_values']['predictions']}
    occurrences=[];unique={};features={};prepared={row['source_sha256']:row['features'] for row in prep['clause_features']}
    for row in panel['source_fidelity']['rows']:
        identity=row['id'];check(identity.startswith('authored-paragraph:train:') and identity in contexts,'inputs/training_row/'+identity)
        segments=contexts[identity]['segments'];rules=row['expected_ir']['rules']
        check(len(segments)==len(rules),'inputs/source_clause_reference_ordinal_count/'+identity)
        for slot,(segment,rule) in enumerate(zip(segments,rules)):
            literal=segment['source_text'];source=hashlib.sha256(literal.encode()).hexdigest()
            targets={field:vocab.index(json.dumps(rule[field],ensure_ascii=False)) for field in ('actor','action','modality','object')}
            check(source==segment['source_sha256'] and list(targets.values())==labels[identity]['expected_token_ids'][slot],
                'inputs/authenticated_reference_and_source/'+identity+'/'+str(slot))
            item=dict(span_id=identity,slot=slot,dedup_id='clause:'+source,source_sha256=source,source_text=literal,
                raw_vector=segment['vector'],target_token_ids=targets,**{k:segment[k] for k in ('char_start','char_end','byte_start','byte_end')})
            occurrences.append(item)
            detail=dict(id='clause:'+source,source_sha256=source,source_text=literal,raw_vector=segment['vector'],
                target_token_ids=targets,reference_rule=rule)
            check(source not in unique or unique[source]==detail,'inputs/repeated_source_consistency/'+source)
            unique[source]=detail
            transformed=[f32(f32(f32(x)-f32(mean))/f32(transform['scale'])) for x,mean in zip(segment['vector'],transform['mean'])]
            check(transformed==prepared[source],'inputs/independent_float32_paragraph_transform/'+source)
            normalized=[f32(f32(x-f32(mean))/f32(normalization['scale'])) for x,mean in zip(transformed,normalization['mean'])]
            features[source]=normalized
    check(export['occurrences']==occurrences and export['unique_clauses']==[unique[key] for key in sorted(unique)],
        'inputs/exact_180_occurrences_and_113_unique_references')
    heads={}
    for seed,state in initial.items():
        reference=export['initial_baseline_states'][str(seed)]
        path=B/'training-r1/results'/('8-boundary-first-last-'+str(seed))/'initial-state.json'
        check(reference['path']==str(path) and reference['sha256']==sha(path) and reference['bytes']==path.stat().st_size
            and reference['tensor_sha256']==state['tensor_sha256']==typed_digest(state['model_state'])
            and state['weights_sha256']==digest(state['model_state']) and state['role']=='initial',
            'inputs/exact_initial_native_state/'+str(seed))
        heads[seed]={name:state['model_state']['non_action_head.'+name] for name in NAMES}
        check(all(x==0. for name in ('field_readout.weight','field_readout.bias') for x in flatten(heads[seed][name])),
            'inputs/fresh_zero_readout/'+str(seed))
    return dict(export=export,occurrences=occurrences,features=features,heads=heads,vocab=vocab)


def parameter_shape(parameters,fields,label):
    expected=dict(zip(NAMES,([64,8],[64],[len(fields)*32,64],[len(fields)*32])))
    check(set(parameters)==set(NAMES),'parameters/inventory/'+label)
    for name,wanted in expected.items():
        check(shape(parameters[name])==wanted and all(type(x) in (int,float) and math.isfinite(x) and x==f32(x)
            for x in flatten(parameters[name])),'parameters/finite_float32_geometry/'+label+'/'+name)


def checkpoint_math(observation,training,initial,fields,label):
    parameters=observation['parameters'];parameter_shape(parameters,fields,label)
    check(observation['parameters_sha256']==digest(parameters),'checkpoint/parameter_hash/'+label)
    check(observation['metrics_scope']=='raw_training_readout_only'
        and observation['gradient_scope']=='separate_coefficient_scaled_full_vocabulary_ce','checkpoint/metric_scope/'+label)
    weights,bias=parameters['source_projection.weight'],parameters['source_projection.bias']
    readout,rb=parameters['field_readout.weight'],parameters['field_readout.bias']
    hidden={};hidden_errors={};maximum=0.;maximum_bound=0.;maximum_ratio=0.;means={}
    for row in training['rows']:
        source=row['source_sha256']
        if source not in hidden:
            hidden[source]=[math.tanh(math.fsum(w*x for w,x in zip(values,row['input']))+b) for values,b in zip(weights,bias)]
            # tanh is 1-Lipschitz. Its four-unit-roundoff absolute allowance is
            # an explicit approximation assumption for CPU float32 tanh, not a
            # formal guarantee for arbitrary math kernels or hardware.
            hidden_errors[source]=[affine_error_bound(values,row['input'],b)+TANH_ABSOLUTE_ALLOWANCE
                for values,b in zip(weights,bias)]
    for index,field in enumerate(fields):
        record=observation['fields'][field];values=record['logits'];losses=[];margins=[];predictions=[]
        check(shape(values)==[180,32] and all(math.isfinite(v) for v in flatten(values)),
            'checkpoint/full_vocabulary_logits/'+label+'/'+field)
        for row,logits in zip(training['rows'],values):
            h=hidden[row['source_sha256']];target=row['labels'][field]
            calculated=[math.fsum(w*x for w,x in zip(readout[index*32+j],h))+rb[index*32+j] for j in range(32)]
            maximum=max(maximum,max(abs(a-b) for a,b in zip(calculated,logits)))
            bounds=[affine_error_bound(readout[index*32+j],h,rb[index*32+j])
                +math.fsum(abs(w)*e for w,e in zip(readout[index*32+j],hidden_errors[row['source_sha256']]))
                *(1.+(66*UNIT_ROUNDOFF)/(1.-66*UNIT_ROUNDOFF))+1e-12 for j in range(32)]
            maximum_bound=max(maximum_bound,max(bounds))
            maximum_ratio=max(maximum_ratio,max(abs(a-b)/bound for a,b,bound in zip(calculated,logits,bounds)))
            check(all(abs(a-b)<=bound for a,b,bound in zip(calculated,logits,bounds)),
                'checkpoint/independent_affine_tanh_full_logits/'+label+'/'+field+'/'+row['id'])
            peak=max(logits);losses.append(peak+math.log(math.fsum(math.exp(x-peak) for x in logits))-logits[target])
            predictions.append(max(range(32),key=logits.__getitem__))
            margins.append(f32(logits[target]-max(x for j,x in enumerate(logits) if j!=target)))
        ce=math.fsum(losses)/len(losses);correct=sum(p==row['labels'][field] for p,row in zip(predictions,training['rows']))
        check(record['predictions']==predictions and record['correct']==correct and record['rows']==180
            and record['accuracy']==correct/180,'checkpoint/independent_argmax_accuracy/'+label+'/'+field)
        check(close(record['cross_entropy'],ce,1e-6,1e-6) and record['field_coefficient']==.0625
            and close(record['weighted_cross_entropy'],.0625*ce,1e-6,1e-6)
            and record['target_minus_best_other_margins']==margins,'checkpoint/independent_full_vocab_loss_and_margin/'+label+'/'+field)
        means[field]=ce
    check(close(observation['objective'],.0625*math.fsum(means.values()),1e-6,1e-6), 'checkpoint/independent_matched_objective/'+label)
    for name in NAMES:
        movement=norm(f32(a-b) for a,b in zip(flatten(parameters[name]),flatten(initial[name])))
        check(close(observation['parameter_l2_motion_from_initial'][name],movement,1e-10,1e-10),
            'checkpoint/independent_parameter_motion/'+label+'/'+name)
    gradients=checkpoint_gradients(observation,training,fields,hidden,label)
    return dict(maximum_float64_forward_error=maximum,maximum_forward_allowance=maximum_bound,
        maximum_forward_error_allowance_ratio=maximum_ratio,cross_entropy=means,
        object_correct=observation['fields']['object']['correct'],gradient_arithmetic=gradients)


def checkpoint_gradients(observation,training,fields,hidden,label):
    """Differentiate the small saved affine/tanh graph using scalar arithmetic.

    Float64 differentiation is compared to the saved float32 autograd reductions;
    this is a checkpoint gradient check, not an Adam trajectory reconstruction.
    """
    parameters=observation['parameters'];readout=parameters['field_readout.weight'];source_gradients={}
    counts=Counter(row['source_sha256'] for row in training['rows'])
    unique={row['source_sha256']:(i,row) for i,row in enumerate(training['rows'])}
    max_norm_error=0.
    for index,field in enumerate(fields):
        record=observation['fields'][field];source_w=[[0.]*8 for _ in range(64)];source_b=[0.]*64
        output_w=[[0.]*64 for _ in range(32)];output_b=[0.]*32
        for source,(position,row) in unique.items():
            logits=record['logits'][position];peak=max(logits);exp=[math.exp(v-peak) for v in logits];denom=math.fsum(exp)
            target=row['labels'][field];h=hidden[source];factor=.0625*counts[source]/180
            delta=[factor*(value/denom-(k==target)) for k,value in enumerate(exp)]
            for k in range(32):
                output_b[k]+=delta[k]
                for j in range(64):output_w[k][j]+=delta[k]*h[j]
            for j in range(64):
                back=math.fsum(delta[k]*readout[index*32+k][j] for k in range(32))*(1-h[j]*h[j])
                source_b[j]+=back
                for k in range(8):source_w[j][k]+=back*row['input'][k]
        source=list(flatten(source_w))+source_b;other=list(flatten(output_w))+output_b
        norms=dict(source_projection=norm(source),field_readout=norm(other),all=norm(source+other))
        for key,value in norms.items():
            observed=record['weighted_gradient_norms'][key];max_norm_error=max(max_norm_error,abs(value-observed))
            check(close(observed,value,2e-6,2e-4),'checkpoint/independent_weighted_gradient_norm/'+label+'/'+field+'/'+key)
        source_gradients[field]=source
    expected=[(a,b) for i,a in enumerate(fields) for b in fields[i+1:]]
    actual=observation['projection_gradient_geometry']
    check([(row['left'],row['right']) for row in actual]==expected,'checkpoint/all_projection_gradient_pairs/'+label)
    for row,(left,right) in zip(actual,expected):
        a,b=source_gradients[left],source_gradients[right];na,nb=norm(a),norm(b);dot=math.fsum(x*y for x,y in zip(a,b));zero=na==0 or nb==0
        check(row['zero_gradient'] is zero and close(row['projection_dot'],dot,2e-8,2e-4),
            'checkpoint/independent_projection_gradient_dot/'+label+'/'+left+'/'+right)
        check(row['projection_cosine'] is None if zero else close(row['projection_cosine'],dot/(na*nb),.002,2e-4),
            'checkpoint/independent_projection_gradient_cosine/'+label+'/'+left+'/'+right)
    return dict(maximum_float64_norm_error=max_norm_error,projection_pairs_checked=len(expected))


def prepared_inputs(ctx,manifest):
    evidence=input_evidence(ctx);adapter=read(R/'probe-adapter-receipt.json')
    check(adapter['schema']=='training-object-readout-probe-adapter/v1' and adapter['passed'] and adapter['complete']
        and not adapter['findings'] and adapter['published_base']==BASE,'adapter/complete_authenticated_export')
    pin(R/'export_readout_probe.py',adapter['script_sha256'])
    for key in ('raw_training_export','geometry_receipt','publication_manifest'):
        entry=adapter[key];path=pin(entry['path'],entry['sha256']);check(path.stat().st_size==entry['bytes'],'adapter/input_size/'+key)
    for path,entry in adapter['original_published_inputs'].items():
        pin(path,entry['sha256'])
        if Path(path).resolve()==P/PUBLIC/'manifest.json':
            check(entry['sha256']==sha(P/PUBLIC/'manifest.json'),'adapter/published_manifest_hash')
            continue
        member=ctx['manifest']['original_artifact_archive_paths'].get(str(Path(path).resolve()))
        check(member in ctx['manifest']['members'] and ctx['manifest']['members'][member]=={k:entry[k] for k in ('sha256','bytes')},
            'adapter/original_published_member/'+path)
    for key in ('model_executed','model_imported','training_executed','weights_changed','qualified','admitted',
        'checkpoint_promoted','lake_executed','validation_entries_present','validation_labels_used','validation_vectors_used'):
        check(adapter[key] is False,'adapter/no_authority_or_validation/'+key)
    data={}
    for name,entry in adapter['inputs'].items():
        value=read(entry['path'],entry['sha256']);check(digest(value)==entry['contents_sha256'],'adapter/bound_canonical_content/'+name);data[name]=value
        check(str(Path(entry['path']).resolve()) in manifest['inputs'],'adapter/sealed_input/'+name)
    training=data['training'];expected_rows=[]
    for occurrence in evidence['occurrences']:
        expected_rows.append(dict(id=occurrence['span_id']+':slot:'+str(occurrence['slot']),source_sha256=occurrence['source_sha256'],
            input=evidence['features'][occurrence['source_sha256']],labels={field:occurrence['target_token_ids'][field] for field in FIELDS}))
    check(training==dict(schema='source-field-readout-probe-training/v1',split='train',dimension=8,vocabulary_size=32,
        fields=list(FIELDS),rows=expected_rows),'adapter/exact_training_only_transformed_occurrences')
    check(manifest['training_input']==adapter['inputs']['training']['path'],'adapter/runner_training_alias')
    for seed in (1729,2718):
        head=data['initial_head_'+str(seed)]
        check(head==dict(schema='source-field-readout-probe-initial-head/v1',dimension=8,vocabulary_size=32,
            hidden_width=64,fields=list(FIELDS),parameters=evidence['heads'][seed]), 'adapter/exact_fresh_head/'+str(seed))
        check(manifest['initial_heads'][str(seed)]==adapter['inputs']['initial_head_'+str(seed)]['path'],'adapter/runner_head_alias/'+str(seed))
    return dict(training=training,heads={seed:data['initial_head_'+str(seed)] for seed in (1729,2718)},evidence=evidence)


def common(args):
    ctx=published_context();manifest=read(args.manifest);plan=read(args.plan)
    check(sha(args.plan)==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'],'sealed/plan_and_inputs')
    for path,wanted in manifest['inputs'].items():pin(path,wanted)
    runner='scripts/ops/autoencoder/benchmark_source_field_readout_probe.py'
    check(set(manifest['extensions'])=={HELPER,runner},'sealed/exact_two_standalone_producers')
    for path,wanted in manifest['extensions'].items():pin(args.source/path,wanted)
    source=(args.source/HELPER).read_text();tree=ast.parse(source)
    imports=[node.module for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)]
    imports += [alias.name for node in ast.walk(tree) if isinstance(node,ast.Import) for alias in node.names]
    check(set(imports)<={'copy','hashlib','json','math','re','time'},'source/no_project_or_encoder_imports')
    check('weight_decay=.01, foreach=False' in source and 'betas=(.9, .999), eps=1e-8' in source
        and 'clip_grad_norm_(parameters, 1.' in source,'source/fixed_optimizer_and_clipping')
    check('optimizer.load_state_dict(prior_adam)' in source and 'p.copy_(previous)' in source
        and 'torch.set_rng_state(rng)' in source,'source/private_deadline_rollback_and_rng_preservation')
    expected=dict(schema='source-field-head-probe-plan/v1',dimension=8,seeds=[1729,2718],
        modes=['shared_non_action','isolated_object'],learning_rates=[.001,.01],fit_count=8,
        training_occurrences=180,unique_training_clauses=113,training_paragraphs=48,vocabulary_size=32,
        hidden_width=64,updates=1000,checkpoints=STEPS,full_batch=True,field_coefficient=.0625,
        optimizer='AdamW',betas=[.9,.999],epsilon=1e-8,weight_decay=.01,max_grad_norm=1.,scheduler=None,
        validation_selection=False,input_representation='nonsemantic_historical_linguistic_feature_hash',
        context_tokens_unchanged=512,output_limit_unchanged=512,generation_temperature_unchanged=0,
        max_seconds_per_fit=60,max_seconds_entire_run=540,worker_count=1,bridge_names=[],
        legal_ir_evaluate_provers=False,metric_disk_cache_used=False,source_inputs_cached=True,
        weights_downloaded=False,original_curriculum_replayed=False,original_decoder_optimizer_replayed=False,
        full_vocabulary_retained=True,new_architecture_selected=False)
    for key,value in expected.items():check(type(plan.get(key)) is type(value) and plan[key]==value,'plan/'+key)
    for key in ('qualified','admitted','checkpoint_promoted','production_checkpoint','convergence_proven','fresh_holdout',
        'lake_executed','native_validation_executed','encoder_executed','compiler_executed','formula_decoder_executed',
        'historical_linguistic_teacher_modified','formalized','roundtrip_ok'):
        check(plan[key] is False,'plan/no_authority/'+key)
    inputs=prepared_inputs(ctx,manifest)
    return dict(ctx,manifest=manifest,plan=plan,**inputs)


def probe_result(report,seed,mode,rate,ctx,label):
    fields=list(FIELDS) if mode=='shared_non_action' else ['object'];training=ctx['training'];head=ctx['heads'][seed]
    initial=dict(head['parameters'])
    if mode=='isolated_object':
        initial['field_readout.weight']=initial['field_readout.weight'][64:96];initial['field_readout.bias']=initial['field_readout.bias'][64:96]
    check(report['schema']=='source-field-readout-probe/v1' and report['mode']==mode and report['learning_rate']==rate
        and report['dimension']==8 and report['hidden_width']==64 and report['vocabulary_size']==32
        and report['fields']==fields and report['field_coefficient']==.0625,'probe/matched_head_geometry_and_coefficient/'+label)
    check(report['training_sha256']==digest(training) and report['initial_head_sha256']==digest(head)
        and report['source_order_sha256']==digest([row['id'] for row in training['rows']])
        and report['source_inputs_sha256']==digest([row['input'] for row in training['rows']])
        and report['source_literals_sha256']==digest([row['source_sha256'] for row in training['rows']]),'probe/exact_inputs_and_initialization/'+label)
    check(report['optimizer']==dict(name='AdamW',betas=[.9,.999],eps=1e-8,weight_decay=.01,foreach=False,
        max_grad_norm=1.,full_batch=True,scheduler=None),'probe/fixed_optimizer/'+label)
    check(report['complete'] and report['requested_updates']==report['completed_updates']==1000
        and report['stopped_reason']=='updates_completed' and report['requested_checkpoints']==STEPS
        and [row['step'] for row in report['checkpoints']]==STEPS and report['pending_update_rolled_back'] is False,
        'probe/complete_fixed_budget_and_checkpoint_inventory/'+label)
    check(report['training_occurrences']==180 and report['training_unique_clauses']==113 and report['row_presentations']==180000
        and report['scalar_target_presentations']==180000*len(fields),'probe/exact_exposure/'+label)
    check(report['numerical_runtime']['device']=='cpu' and report['numerical_runtime']['dtype']=='float32'
        and report['numerical_runtime']['intraop_threads']==1 and report['training_only'] is True
        and report['source_input_kind']=='authenticated_already_projected_and_normalized_frozen_clause_vectors',
        'probe/explicit_runtime_and_input_scope/'+label)
    for key in ('optimizer_resumable','validation_access','source_parser_used','formula_decoder_used','generated_formula_metrics_computed',
        'qualification_gates_changed','lake_executed','admitted','qualified','production_checkpoint','convergence_proven'):
        check(report[key] is False,'probe/no_authority/'+label+'/'+key)
    observations=report['checkpoints'];check(observations[0]['parameters']==initial,'probe/exact_initial_slice/'+label)
    panels={}
    for observation in observations:
        panels[str(observation['step'])]=checkpoint_math(observation,training,initial,fields,label+'/'+str(observation['step']))
    check(report['final_parameters']==observations[-1]['parameters'] and report['final_parameters_sha256']==digest(report['final_parameters']),
        'probe/last_checkpoint_is_final_state/'+label)
    updates=report['updates'];check([row['step'] for row in updates]==list(range(1,1001)),'probe/committed_update_inventory/'+label)
    for update in updates:
        prefix=label+'/'+str(update['step']);ce=update['field_cross_entropy']
        check(set(ce)==set(fields) and all(math.isfinite(v) and v>=0 for v in ce.values())
            and close(update['objective'],.0625*math.fsum(ce.values())),'probe/update_objective_arithmetic/'+prefix)
        norms=update['preclip_gradient_norms'];normtotal=math.hypot(norms['source_projection'],norms['field_readout'])
        check(close(update['preclip_norm'],normtotal,2e-6,2e-4) and update['clipping_limit']==1.
            and update['clipping_coefficient']==min(1.,1./(update['preclip_norm']+1e-6)), 'probe/update_clipping_arithmetic/'+prefix)
        check(set(update['parameter_l2_step'])==set(NAMES) and all(math.isfinite(v) and v>=0 for v in update['parameter_l2_step'].values()),
            'probe/reported_finite_parameter_step/'+prefix)
    for observation in observations[:-1]:
        next_update=updates[observation['step']]
        check(all(close(next_update['field_cross_entropy'][field],observation['fields'][field]['cross_entropy']) for field in fields),
            'probe/checkpoint_matches_next_committed_preupdate_loss/'+label+'/'+str(observation['step']))
    check(updates[0]['preclip_gradient_norms']['source_projection']==0 and
        all(observations[0]['fields'][field]['weighted_gradient_norms']['source_projection']==0 for field in fields),
        'probe/first_zero_readout_projection_gradient_expected/'+label)
    adam=report['final_adam_state'];check(digest(adam)==report['final_adam_state_sha256'] and set(adam)==set(NAMES),'probe/adam_persistence_digest/'+label)
    for name,value in adam.items():
        check(set(value)=={'step','exp_avg','exp_avg_sq'} and value['step']==1000.
            and shape(value['exp_avg'])==shape(report['final_parameters'][name])==shape(value['exp_avg_sq'])
            and all(math.isfinite(v) for v in flatten(value['exp_avg']))
            and all(math.isfinite(v) and v>=0 for v in flatten(value['exp_avg_sq'])), 'probe/adam_geometry_and_committed_count/'+label+'/'+name)
    return dict(checkpoints=panels,completed_updates=1000,scalar_target_presentations=180000*len(fields),
        intervening_optimizer_trajectory_replayed=False)


def tested_source(args,ctx):
    tested=read(R/'tests-frozen.json');tensor=read(R/'tensor-crosscheck.json',tested['tensor_check_sha256'])
    check(tested['returncode']==0 and tested['standalone'] and tested['project_package_imported'] is False
        and tested['real_training_probe_executed'] is False
        and Path(tested['helper_imported_from']).resolve()==(args.source/HELPER).resolve(), 'tests/frozen_standalone_suite_passed')
    for path,wanted in tested['source_sha256'].items():pin(args.source/path,wanted)
    xml=pin(R/'tests-frozen.xml');tree=ET.parse(xml);suites=list(tree.getroot().iter('testsuite'))
    counts={key:sum(int(suite.attrib.get(key,0)) for suite in suites) for key in ('tests','failures','errors','skipped')}
    check(counts==dict(tests=72,failures=0,errors=0,skipped=0),'tests/exact_complete_frozen_test_count')
    pin(R/'verify_exported_feature_tensors.py',tensor['script_sha256'])
    check(tensor['schema']=='training-object-feature-tensor-arithmetic-check/v1' and tensor['complete'] and tensor['passed']
        and tensor['exact_tensor_equal'] and tensor['maximum_absolute_difference']==0. and tensor['rows']==180
        and tensor['coordinates']==1440 and tensor['training_contents_sha256']==digest(ctx['training'])
        and tensor['normalized_values_sha256']==digest([row['input'] for row in ctx['training']['rows']]),
        'tests/exact_real_tensor_arithmetic_crosscheck')
    check(tensor['training_file_sha256']==sha(ctx['manifest']['training_input'])
        and tensor['adapter_receipt_sha256']==sha(R/'probe-adapter-receipt.json')
        and tensor['raw_training_export_sha256']==sha(R/'training-object-inputs.json'), 'tests/crosscheck_provenance')
    for key in ('decoder_executed','fitted_head_executed','model_executed','model_imported','training_executed',
        'validation_labels_used','validation_vectors_used','weights_changed','admitted','qualified','checkpoint_promoted','lake_executed'):
        check(tensor[key] is False,'tests/crosscheck_arithmetic_only/'+key)
    for relative,entry in tensor['source_provenance'].items():
        blob=subprocess.check_output(['git','show',BASE+':'+relative],cwd=P)
        check(entry['git_commit']==BASE and hashlib.sha256(blob).hexdigest()==entry['sha256'], 'tests/exact_published_projection_source/'+relative)
        pin(entry['path'],entry['sha256'])
    for name in ('run_diagnostic_reserved.py','run_guardian.py','adopt_shared_scheduler.py','run_frozen_tests.py'):
        pin(R/name)
    adoption=ast.parse((R/'adopt_shared_scheduler.py').read_text())
    constants={node.targets[0].id:node.value.value for node in adoption.body if isinstance(node,ast.Assign)
        and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and isinstance(node.value,ast.Constant)}
    dependency=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
    for prefix in ('SCHEDULER','OWNER'):
        pin(dependency/constants[prefix+'_RELATIVE'],constants[prefix+'_SHA256'])
    guard=(R/'run_diagnostic_reserved.py').read_text()
    check('storage_bytes=200_000_000' in guard and 'memory_mb=2048' in guard and 'cpu_slots=1' in guard
        and 'time.monotonic()-child_started > 600' in guard and 'artifacts_durable=True' in guard,
        'guardian/explicit_lightweight_owned_budget_and_durable_cleanup')
    return dict(test_count=72,tensor_coordinates=1440,standalone=True)


def results(args,ctx):
    root=args.results.resolve();summary=read(root/'summary.json');sealed=read(root/'sealed-plan.json')
    check(summary['schema']=='source-field-head-probe-results/v1' and summary['complete']
        and summary['plan_sha256']==sha(args.plan) and summary['manifest_sha256']==sha(args.manifest)
        and summary['source_dependencies']==ctx['manifest']['extensions']
        and sealed['plan']==ctx['plan'] and sealed['manifest']==ctx['manifest'],'results/sealed_producer_and_plan_binding')
    expected=[(seed,mode,rate) for seed in (1729,2718) for mode in ('shared_non_action','isolated_object') for rate in (.001,.01)]
    check([(r['seed'],r['mode'],r['learning_rate']) for r in summary['runs']]==expected,'results/exact_eight_registered_fits')
    details={}
    for entry,(seed,mode,rate) in zip(summary['runs'],expected):
        name=str(seed)+'-'+mode+'-lr'+str(rate);ref=entry['report'];path=Path(ref['path']).resolve()
        check(entry['name']==name and path==root/name/'probe.json','results/exact_report_path/'+name)
        report=read(path,ref['sha256']);check(path.stat().st_size==ref['bytes'],'results/report_size/'+name)
        check(0<report['elapsed_seconds']<=entry['call_elapsed_seconds']<60.1,'results/per_fit_deadline/'+name)
        details[name]=probe_result(report,seed,mode,rate,ctx,name)
        check(entry['object_correct']==report['checkpoints'][-1]['fields']['object']['correct']
            and entry['object_cross_entropy']==report['checkpoints'][-1]['fields']['object']['cross_entropy'],
            'results/summary_endpoint_binding/'+name)
        for key in ('qualified','admitted','checkpoint_promoted','production_checkpoint','convergence_proven','fresh_holdout',
            'lake_executed','native_validation_executed','encoder_executed','compiler_executed','formula_decoder_executed',
            'historical_linguistic_teacher_modified','formalized','roundtrip_ok'):
            check(entry[key] is False and summary[key] is False,'results/no_authority/'+name+'/'+key)
    check(summary['training_only'] and summary['worker_count']==1 and summary['device']=='cpu'
        and summary['sample_count']==180 and summary['unique_clause_count']==113 and summary['source_paragraph_count']==48
        and summary['bridge_names']==[] and summary['legal_ir_evaluate_provers'] is False
        and summary['metric_disk_cache_used'] is False and summary['source_inputs_cached'] is True
        and summary['cold_parser_measurement'] is False and summary['bridge_on_timing'] is False
        and summary['no_project_runtime_imported'] is True and summary['elapsed_seconds']<540,
        'results/explicit_training_only_measurement_scope')
    attempt=root.parent;resource=read(attempt/'resources-final.json');child=read(attempt/'child-exit.json')
    guardian=read(R/'guardian-exit.json')
    record=resource['record']
    check(child['returncode']==guardian['returncode']==0 and resource['status']==record['status']=='released'
        and record['artifacts_durable_asserted'] is True and record['attempt_exceeded_reservation'] is False
        and record['storage_bytes']==200000000 and record['memory_mb']==2048 and record['cpu_slots']==1
        and resource['resource_lease']['released'] is True and resource['cleanup_error'] is None,
        'resources/successful_guardian_and_durable_released_owned_budget')
    observations=read(attempt/'resource-observations.json')
    rss=[item['group_rss']['rss_bytes'] for item in observations if item.get('group_rss',{}).get('available')]
    check(rss and max(rss)<=2147483648 and record['final_attempt_bytes']<=200000000,
        'resources/observed_usage_within_budget')
    return dict(runs=details,fit_count=8,checkpoint_count=56,maximum_observed_rss=max(rss),
        final_attempt_bytes=record['final_attempt_bytes'],comparison_elapsed_seconds=summary['elapsed_seconds'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('source','manifest','plan','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--results',type=Path)
    args=parser.parse_args()
    if args.output.exists():raise ValueError('audit output exists; preserve prior attempts')
    ctx=common(args);analysis=dict(tests=tested_source(args,ctx))
    if args.results:analysis.update(results(args,ctx))
    pin(__file__)
    receipt=dict(schema='independent-source-field-readout-probe-audit/v1',complete=True,passed=not findings,
        checks=checks,finding_count=len(findings),findings=findings,created_at_utc=datetime.now(timezone.utc).isoformat(),
        phase='results' if args.results else 'readiness',analysis=analysis,artifacts=artifacts,
        source_path=str(args.source.resolve()),manifest_sha256=sha(args.manifest),plan_sha256=sha(args.plan),
        script_sha256=sha(__file__),source_sha256=ctx['manifest']['extensions'],
        model_framework_imported=False,model_executed=False,training_executed=False,encoder_executed=False,
        optimizer_trajectory_replayed=False,checkpoint_affine_tanh_softmax_reconstructed=bool(args.results),
        checkpoint_gradient_arithmetic_reconstructed=bool(args.results),
        arithmetic_policy=dict(float32_unit_roundoff=UNIT_ROUNDOFF,
            affine_bound='gamma_(number_of_inputs+2) times sum of absolute products and bias; propagated hidden errors',
            tanh_absolute_allowance=TANH_ABSOLUTE_ALLOWANCE,
            tanh_allowance_is_explicit_CPU_approximation_assumption=True,
            float64_reconstruction_floor=1e-12,full_vocabulary_ce_atol=1e-6,full_vocabulary_ce_rtol=1e-6,
            target_margin='exact float32 subtraction of retained logits',
            gradient_norm_atol=2e-6,gradient_norm_rtol=2e-4,gradient_dot_atol=2e-8,
            gradient_cosine_atol=.002,distinct_from_strict_runtime_replay_guard=True),
        validation_rows_evaluated=False,admitted=False,qualified=False,lake_executed=False,
        limits=['Training-only probes; no generated formula or held-out fidelity measurements.',
            'Python float64 saved-checkpoint arithmetic is not bit-exact float32 framework execution.',
            'Intervening Adam updates and moments are authenticated/reconciled, not independently replayed.',
            'No inference of global convergence, input impossibility, Lake admission or production readiness.'])
    args.output.write_text(json.dumps(receipt,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(passed=receipt['passed'],checks=checks,findings=findings,output=str(args.output.resolve()))))
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__=='__main__':main()
