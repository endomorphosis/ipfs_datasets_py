"""Recover only the receipt after disk release succeeded and lease reporting failed.

Read-only shared-state reconciliation. Never acquire/release/reset any lease or
rewrite either shared JSON file. Refuse a live owner/group, outstanding own
lease, missing durability evidence, or changed completed result inventory.
"""
from contextlib import contextmanager
from copy import deepcopy
import fcntl,hashlib,importlib.util,json,os,stat,sys,time
from pathlib import Path
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2';T=R/'training-r1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def write(p,value):
 with p.open('x') as stream:
  json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n');stream.flush();os.fsync(stream.fileno())
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
@contextmanager
def locked(path):
 # Existing stable sibling lock; no scheduler/ledger client constructor is used.
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
 try:
  meta=os.fstat(fd);assert stat.S_ISREG(meta.st_mode) and meta.st_nlink==1
  deadline=time.monotonic()+60
  while True:
   try:fcntl.flock(fd,fcntl.LOCK_SH|fcntl.LOCK_NB);break
   except BlockingIOError:
    if time.monotonic()>=deadline:raise TimeoutError('read-only reconciliation lock deadline')
    time.sleep(.05)
  assert (path.stat().st_dev,path.stat().st_ino)==(meta.st_dev,meta.st_ino)
  yield
 finally:os.close(fd)
def main():
 assert not (T/'resources-final.json').exists() and not (R/'resource-reconciliation.json').exists()
 start=read(T/'resources-start.json');adopt=read(R/'training-r1-scheduler-adoption.json')
 exit_receipt=read(T/'child-exit.json');identity=read(T/'child-identity.json');summary=read(T/'results/summary.json')
 assert exit_receipt['returncode']==0 and exit_receipt['leader_reaped'] and summary['complete'] and len(summary['runs'])==12
 log=(R/'guardian.log').read_text()
 assert 'ResourceConfigurationError' in log and 'self._lease.release()' in log
 sys.dont_write_bytecode=True;sys.path.insert(0,str(S))
 from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_daemon_resources as owner
 assert Path(owner.__file__).resolve()==S/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py'
 assert sha(owner.__file__)==adopt['producer_sha256']['ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py']
 assert owner._process(start['record']['owner_pid']) is None,'original guardian must have exited without PID reuse'
 assert owner._group_usage(identity)['live_processes']==0
 ledger_path=Path(start['ledger_path']);scheduler_path=Path(adopt['observed_after']['path'])
 with locked(ledger_path.with_name(ledger_path.name+'.lock')):
  with locked(scheduler_path.with_name(scheduler_path.name+'.lock')):
   ledger=read(ledger_path);scheduler=read(scheduler_path)
   assert ledger['schema']==start['schema'] and ledger['roots']==start['roots'] and ledger['limit_bytes']==140000000000
   record=deepcopy(ledger['reservations'][start['reservation_id']])
   for name in ('reservation_id','owner_pid','attempt_directory','child','cpu_slots','memory_mb','child_process_slots','storage_bytes','created_at'):
    assert record[name]==start['record'][name],name
   assert record['status']=='released' and record['artifacts_durable_asserted'] is True and record['attempt_exceeded_reservation'] is False
   assert record['final_accounting']['limit_bytes']==140000000000 and record['final_external_charged_bytes']==0
   assert owner._root_identity(T)==record['attempt_directory']
   assert record['child']==identity and owner._group_usage(identity)['live_processes']==0
   assert owner._process(record['owner_pid']) is None
   observed=owner._inventory([T],strict=True)['apparent_bytes']
   assert observed==record['final_attempt_bytes']==record['final_total_charged_bytes'] and observed<record['storage_bytes']
   lease_id=start['resource_lease']['lease_id']
   assert lease_id not in scheduler['leases'] and not any(v.get('parent_lease_id')==lease_id for v in scheduler['leases'].values())
   assert not any(v.get('owner_pid')==record['owner_pid'] for v in scheduler['leases'].values())
   assert not any(v.get('owner_pid')==record['owner_pid'] for v in scheduler['waiters'].values())
   recovery=dict(schema='completed-resource-receipt-reconciliation/v1',complete=True,
    reconciled_at_unix=time.time(),script_sha256=sha(__file__),guardian_returncode=1,training_child_returncode=0,
    original_guardian_log_sha256=sha(R/'guardian.log'),original_guardian_cleanup_error='ResourceConfigurationError',
    release_record=record,release_record_source='existing locked disk ledger; never synthesized or rewritten',
    ledger_path=str(ledger_path),ledger_sha256=sha(ledger_path),scheduler_path=str(scheduler_path),scheduler_sha256=sha(scheduler_path),
    original_scheduler_config_sha256=adopt['shared_config_sha256'],observed_scheduler_config=scheduler['config'],
    scheduler_config_now_matches_adopted=scheduler['config']==adopt['shared_config'],
    failure_time_scheduler_configuration_not_captured=True,configuration_change_actor_unknown=True,
    scheduler_lease_id=lease_id,scheduler_lease_absent=True,scheduler_release_actor_unknown=True,
    scheduler_release_performed=False,scheduler_reset_performed=False,shared_state_mutated=False,
    foreign_claims_modified=False,owner_exited=True,child_group_dead=True,attempt_inode_verified=True,
    observed_completed_attempt_bytes=observed,resources_final_receipt_bytes_excluded_from_prior_inventory=True,
    guardian_success_claimed=False,model_rerun=False)
 result=deepcopy(start);result.update(status='released',record=record,
  cleanup_error='Original guardian ResourceConfigurationError; receipt recovered by read-only reconciliation',
  recovered_after_guardian_failure=True,guardian_returncode=1,
  finalization_scope='Exact completed disk release record plus locked observation of absent own scheduler lease')
 result['resource_lease'].update(released=True,cancelled=False,
  release_status_evidence='Absent in locked scheduler state after original owner and child group exited',
  release_actor_unknown=True,release_performed_by_reconciliation=False)
 write(R/'resource-reconciliation.json',recovery)
 result['reconciliation_receipt']=dict(path=str(R/'resource-reconciliation.json'),sha256=sha(R/'resource-reconciliation.json'))
 write(T/'resources-final.json',result)
 print(json.dumps(dict(complete=True,shared_state_mutated=False,guardian_returncode=1,training_child_returncode=0,
  observed_attempt_bytes=observed,reservation_released=True,own_scheduler_lease_absent=True)))
if __name__=='__main__':main()
