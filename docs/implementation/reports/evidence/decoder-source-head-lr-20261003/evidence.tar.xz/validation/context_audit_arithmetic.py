"""Independent saved-data audit of contextual generated-boundary supervision.

No model, encoder, optimizer or prover runs here. Prior scalar/count/readout and
selection arithmetic is authenticated against published evidence; the new loss
is checked from actual source-only rollout prefixes and complete saved logits.
"""
from pathlib import Path
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import argparse, ast, hashlib, importlib.util, json, math, subprocess, sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;P=R.parents[2]
B=P/'workspace/test-logs/decoder-boundary-reconstruction-20261003'
PUBLIC=P/'docs/implementation/reports/evidence/decoder-boundary-reconstruction-20261003'
AUTO='ipfs_datasets_py/logic/formalization/autoencoder/'
checks=0;findings=[];artifacts={}


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def digest(value):return hashlib.sha256(raw(value)).hexdigest()
def sha(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):result.update(block)
    return result.hexdigest()
def check(value,label,detail=None):
    global checks
    checks+=1
    if not value:findings.append(dict(label=label,detail=detail))
def pin(path,wanted=None):
    path=Path(path).resolve();entry=dict(sha256=sha(path),bytes=path.stat().st_size)
    if wanted is not None:check(entry['sha256']==wanted,'pin/'+str(path))
    artifacts[str(path)]=entry;return path
def read(path):return json.loads(pin(path).read_bytes())


def load_arithmetic():
    manifest=read(PUBLIC/'manifest.json');results=read(PUBLIC/'results.json');base=read(R/'base.json')['base']
    for name in ('manifest.json','results.json'):
        path=PUBLIC/name;blob=subprocess.check_output(['git','show',base+':'+str(path.relative_to(P))],cwd=P)
        check(hashlib.sha256(blob).hexdigest()==sha(path),'prior/exact_published_metadata/'+name)
    previous=read(B/'independent-audit.json')
    check(sha(B/'independent-audit.json')==results['independent_audit_sha256'] and previous['passed']
        and previous['finding_count']==0,'prior/authenticated_ordered_audit')
    # Previous guardian failed only after the complete training result existed;
    # its released reservation was independently reconciled and published.
    check(results['guardian_succeeded'] is False and results['resource_receipt_reconciled_after_guardian_failure'] is True,
        'prior/explicit_published_guardian_reconciliation')
    for name,entry in read(R/'ordered-audit-helper-pins.json').items():
        pin(R/name,entry['sha256']);member=manifest['original_artifact_archive_paths'][entry['source_path']]
        check(manifest['members'][member]=={k:entry[k] for k in ('sha256','bytes')},'prior/published_arithmetic/'+name)
    spec=importlib.util.spec_from_file_location('_authenticated_ordered_arithmetic',R/'ordered_audit_arithmetic.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    check(not module.findings and not module.action.findings,'prior/helper_self_authentication_clean')
    for owner in (module,module.action,module.native,module.clause,module.prior,module.leaf):
        owner.check=check;owner.read=read
        if hasattr(owner,'pin'):owner.pin=pin
    return module,manifest,previous


ordered,old_public,old_audit=load_arithmetic()
action=ordered.action;native=ordered.native;clause=ordered.clause;prior=ordered.prior;leaf=ordered.leaf
close=prior.close;CONTROLS=action.CONTROLS+[('recurrent-residual-off','validation','conditioned')]


def inherited(path):
    path=Path(path).resolve();expected=old_audit['artifacts'].get(str(path))
    if expected is None:
        member=old_public['original_artifact_archive_paths'].get(str(path))
        expected=old_public['members'][member] if member else old_public['referenced_artifacts'].get(str(path))
    check(expected is not None,'prior/known_artifact/'+str(path));value=read(path)
    check(expected is not None and artifacts[str(path)]==expected,'prior/exact_artifact/'+str(path))
    return value


def source_guards(source):
    old=B/'experiment-source';old_manifest=inherited(B/'training-manifest.json')
    for rel in old_manifest['extensions']:
        if rel==AUTO+'long_span_source_value_training.py':continue
        check(pin(source/rel).read_bytes()==pin(old/rel).read_bytes(),'source/unchanged_inherited_owner/'+rel)
    before=(old/AUTO/'long_span_source_value_training.py').read_text();after=(source/AUTO/'long_span_source_value_training.py').read_text()
    def section(text,start,end):return text.split(start,1)[1].split(end,1)[0]
    for label,start,end in [('optimizer','    optimizer = torch.optim.AdamW','    evaluate = lambda:'),
        ('selection','            observed, accepted, reasons =','    report = dict(')]:
        check(section(before,start,end)==section(after,start,end),'source/identical_'+label)
    without_train=lambda text:ast.dump(ast.Module(body=[node for node in ast.parse(text).body
        if not isinstance(node,ast.FunctionDef) or node.name!='train'],type_ignores=[]))
    check(without_train(before)==without_train(after),'source/all_nontraining_functions_unchanged')
    check(section(before,'                objective.backward()','                optimizer.step()')
        ==section(after,'                objective.backward()','                optimizer.step()'),
        'source/unchanged_backward_clip_deadline_before_optimizer_commit')
    helper=pin(source/AUTO/'contextual_generated_boundary_training.py').read_text();tree=ast.parse(helper)
    functions={node.name:node for node in tree.body if isinstance(node,ast.FunctionDef)}
    collector=functions['collect_source_boundary_prefixes'];loss=functions['generated_boundary_loss']
    collectargs={a.arg for a in collector.args.args+collector.args.kwonlyargs}
    check(not collectargs&{'training_counts_by_id','site_policy','target','targets','references','training_references'},
        'source/collection_signature_excludes_labels_and_policy')
    calls=lambda node:[ast.unparse(n.func) for n in ast.walk(node) if isinstance(n,ast.Call)]
    check('_select' not in calls(collector) and 'core._greedy' in calls(collector) and 'torch.no_grad' in calls(collector),
        'source/source_only_greedy_collection_without_selection_or_graph')
    check('_validate_collection' in calls(loss) and '_select' in calls(loss) and 'core._logits' in calls(loss)
        and not any(name.endswith(('.backward','.step')) for name in calls(loss)),
        'source/loss_replays_prefixes_without_optimizer_updates')
    check('deepcopy' not in calls(collector)+calls(loss) and '_snapshot' in calls(collector) and '_preserved' in calls(collector),
        'source/no_model_copy_and_preserved_caller_state')
    for name in ('action_contrastive_decoder_training','ordered_clause_recurrent_decoder_experiment',
        'decoder_distillation_experiment','decoder_source_fidelity','long_span_count_exposure_training'):
        check(sha(source/AUTO/(name+'.py'))==sha(old/AUTO/(name+'.py')),'source/unchanged_gates_and_model/'+name)


def common(args):
    manifest=read(args.manifest);plan=read(args.plan)
    check(sha(args.plan)==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'],'pins/plan_inputs')
    for path,wanted in manifest['inputs'].items():pin(path,wanted)
    for rel,wanted in manifest['extensions'].items():pin(args.source/rel,wanted)
    for rel,wanted in read(R/'validated-test-source.json').items():pin(args.source/rel,wanted)
    source_guards(args.source)
    fixed=dict(dimensions=[8,384,768],seed_order=[1729,2718],fit_count=18,original_training_rows=48,
        exposed_validation_rows=48,fixed_encoder_context_tokens=512,fixed_decoder_output_limit=512,
        temperature=0,action_contrastive_temperature=.1,fresh_initialization=True,selection_unchanged=True,
        cardinality_weight=.25,source_value_weight=.25,expected_optimizer_steps_per_arm=340,
        expected_training_token_presentations_per_arm=225840,expected_row_presentations_per_arm=2440,
        expected_count_presentations_per_arm=2440,expected_source_value_presentations_per_arm=25600,
        full_vocabulary_retained=True,syntax_forced=False,closure_forced=False,generation_reference_count_access=False,
        production_promotion_allowed=False,no_downloads=True,encoder_executed_during_training=False)
    for key,value in fixed.items():check(plan.get(key)==value,'plan/'+key)
    check([(arm['name'],arm['generated_boundary_weight'],arm['generated_boundary_site_policy']) for arm in plan['arms']]
        ==[('recurrent-clause',0.,'first_last'),('boundary-first-last',.05,'first_last'),('boundary-first-wrong',.05,'first_wrong')],
        'plan/exact_registered_three_arms')
    check(plan['max_seconds_per_arm']==180 and plan['generated_boundary_gradient_scope']=='all_trainable'
        and plan['boundary_labels_after_source_only_rollout'] is True and plan['recurrent_parameter_delta']==0,
        'plan/exact_deadline_gradient_and_architecture_scope')
    check(len(plan['arms'])==3 and all(a['recurrent'] and a['action_contrastive_weight']==.05 and a['factorized']
        and a['head_kind']=='clauses' and not a['order_augmentation'] for a in plan['arms']), 'plan/matched_recurrent_models_and_losses')
    baseline={name:inherited(path) for name,path in manifest['baseline_summaries'].items()}
    for value in baseline.values():value['training']=inherited(value['training_ref']['path'])
    corpus=inherited(manifest['paragraphs']);prepared=inherited(manifest['dimension_inputs']);donor=inherited(manifest['donor'])
    originals={row['id']:row for split in ('train','validation') for row in corpus[split]};lookup={};lanes={}
    for split in ('train','validation'):
        lookup[split]={}
        for row in corpus[split]:
            parts=row['source_text'].split('\n\n');rules=row['target']['rules']
            check(len(parts)==len(rules)==row['clause_count'],'source/ordered_component_alignment/'+row['id'])
            for part,rule in zip(parts,rules):lookup[split][clause.textsha(part)]=dict(actor=rule['actor'],action=rule['action'],source_text=part)
    for dimension in (8,384,768):
        source=prepared['dimensions'][str(dimension)];contexts=source['source_contexts'];rows={};vectors={};unique={}
        for split in ('train','validation'):
            rows[split]=[dict(row,target_ids=originals[row['id']]['target_ids']) for row in source[split]]
            vectors.update({row['id']:row['input'] for row in rows[split]});unique[split]={}
            for row in rows[split]:
                for segment in contexts[split][row['id']]['segments']:unique[split].setdefault(segment['source_sha256'],segment)
        lanes[dimension]=dict(dimension=dimension,contexts=contexts,rows=rows,vectors=vectors,unique=unique)
    return dict(manifest=manifest,plan=plan,baseline=baseline,corpus=corpus,donor=donor,lanes=lanes,lookup=lookup,
        original={r['id']:r for r in corpus['train']},prepared=originals,
        variants={r['id']:[r['id']] for r in corpus['train']})


def boundary_receipt(receipt,ids,ctx,policy,label):
    vocab=ctx['donor']['codec']['target_vocabulary'];generation=receipt['generation'];rows=generation['rows']
    counts={key:row['clause_count'] for key,row in ctx['original'].items()};contexts={key:ctx['contexts']['train'][key] for key in ids}
    check(receipt['schema']=='contextual-generated-source-boundary-loss/v1'
        and receipt['training_counts_sha256']==digest(counts) and receipt['selection_policy']==policy,
        'boundary/authenticated_training_labels_and_policy/'+label)
    check([row['id'] for row in rows]==ids and generation['source_only'] is True
        and generation['reference_count_access'] is False and generation['site_policy_access'] is False
        and generation['complete_rollout_before_site_selection'] is True and generation['max_target_tokens']==512
        and generation['source_contexts_sha256']==digest(contexts),'boundary/source_only_complete_contextual_rollout/'+label)
    check(all(type(value) is str and len(value)==64 and set(value)<=set('0123456789abcdef')
        for value in (receipt['collection_sha256'],generation['model_tensor_sha256'])),
        'boundary/recorded_collection_and_intermediate_state_digests/'+label)
    check(receipt['full_vocabulary_cross_entropy'] is True and receipt['reference_counts_used_only_in_loss'] is True
        and receipt['target_prefixes_used'] is False and receipt['additional_optimizer_steps']==0
        and receipt['gradient_scope']=='all_trainable' and receipt['rows_replayed_once'] is True
        and receipt['student_generated_prefix_replay'] is True and receipt['vocabulary_size']==len(vocab)
        and receipt['site_cap_per_row']==(2 if policy=='first_last' else 1)
        and receipt['reduction']=='mean_selected_sites_within_row_then_mean_active_rows', 'boundary/loss_scope/'+label)
    check(receipt['replay_logits_match_collection'] is True and receipt['replay_logits_atol']==receipt['replay_logits_rtol']==2e-5,
        'boundary/replay_tolerance_fixed/'+label)
    rowmap={row['id']:row for row in rows};selected=[];available=replayed=generated=empty=inactive=wrong=missed=steps=0
    batches={}
    for row in rows:
        identity=row['id'];prediction=row['prediction'];prefix=row['consumed_prefix'];tokens=prediction['token_ids'];status=prediction['generation_status']
        check(row['input_sha256']==digest(ctx['vectors'][identity]) and prediction['id']==identity
            and row['source_text_sha256']==clause.textsha(ctx['original'][identity]['source_text'])
            and row['source_context_sha256']==digest(contexts[identity]),'boundary/exact_source/'+label+'/'+identity)
        check(status in ('eos','invalid_special_token','output_limit') and prediction['eos_reached']==(status=='eos')
            and len(tokens)==len(prefix)-(status!='output_limit') and 1<=len(prefix)<512
            and prefix==[1]+tokens[:len(prefix)-1] and all(type(token) is int and 3<=token<len(vocab) for token in tokens)
            and (status!='output_limit' or len(prefix)==511),'boundary/actual_complete_greedy_prefix/'+label+'/'+identity)
        expected=prior.sites(prefix,vocab)
        check([{k:site[k] for k in ('position','completed_rules')} for site in row['available_sites']]==expected,
            'boundary/independently_parsed_all_actual_rule_boundaries/'+label+'/'+identity)
        bad=[]
        for site in row['available_sites']:
            position=site['position'];values=site['collection_logits'];chosen=site['actual_next_token_id']
            check(len(values)==len(vocab) and all(math.isfinite(value) for value in values)
                and chosen==max(range(len(vocab)),key=values.__getitem__), 'boundary/full_vocab_actual_argmax/'+label+'/'+identity+'/'+str(position))
            expected_choice=tokens[position] if position<len(tokens) else 2 if status=='eos' else chosen if status=='invalid_special_token' and chosen in (0,1) else None
            check(chosen==expected_choice,'boundary/argmax_matches_actual_greedy_output/'+label+'/'+identity+'/'+str(position))
            target=vocab.index(',' if site['completed_rules']<counts[identity] else ']')
            if chosen!=target:bad.append(site)
        wanted=(row['available_sites'] if len(expected)<=1 else [row['available_sites'][0],row['available_sites'][-1]]) if policy=='first_last' else bad[:1]
        check(row['selected_sites']==wanted and row['available_site_count']==len(expected)
            and row['selected_site_count']==len(wanted) and row['ignored_site_count']==len(expected)-len(wanted)
            and row['replay_prefix_tokens']==(wanted[-1]['position']+1 if wanted else 0),
            'boundary/independent_postrollout_site_selection/'+label+'/'+identity)
        selected.extend((identity,site['position'],site['completed_rules']) for site in wanted)
        available+=len(expected);replayed+=row['replay_prefix_tokens'];generated+=len(tokens);empty+=not expected;inactive+=not wanted
        wrong+=len(bad);missed+=sum(site not in wanted for site in bad)
        batches[row['batch_offset']]=max(batches.get(row['batch_offset'],0),len(prefix))
    active=len(rows)-inactive
    check(generation['greedy_batch_steps']==sum(batches.values()),'boundary/actual_incremental_batch_steps/'+label)
    check([(event['id'],event['position'],event['completed_rules']) for event in receipt['events']]==selected,
        'boundary/all_and_only_selected_events/'+label)
    losses={};stop=0;max_delta=0.
    for event in receipt['events']:
        identity=event['id'];row=rowmap[identity];count=counts[identity];k=event['completed_rules'];n=event['position']+1
        site=next(site for site in row['selected_sites'] if site['position']==event['position']);target=vocab.index(']' if k>=count else ',')
        values=event['replay_logits'];loss=prior.lse(values)-values[target]
        check(event['training_count']==count and event['target_token_id']==target and event['action']==('stop' if k>=count else 'continue')
            and event['actual_next_token_id']==site['actual_next_token_id'], 'boundary/authenticated_event_target/'+label+'/'+identity+'/'+str(n))
        check(len(values)==len(vocab) and all(math.isfinite(value) for value in values) and close(loss,event['cross_entropy'])
            and close(event['mean_loss_coefficient'],1/active/len(row['selected_sites']),1e-10), 'boundary/independent_full_vocabulary_CE/'+label+'/'+identity+'/'+str(n))
        check(all(abs(a-b)<=2e-5+2e-5*abs(b) for a,b in zip(values,site['collection_logits'])),
            'boundary/actual_greedy_and_replay_logit_parity/'+label+'/'+identity+'/'+str(n))
        max_delta=max(max_delta,max(abs(a-b) for a,b in zip(values,site['collection_logits'])))
        check(event['consumed_prefix_length']==n and event['consumed_prefix_sha256']==digest(row['consumed_prefix'][:n]),
            'boundary/event_actual_prefix_hash/'+label+'/'+identity+'/'+str(n))
        losses.setdefault(identity,[]).append(loss);stop+=k>=count
    expected_rows=[dict(id=key,sites=len(values),mean_ce=math.fsum(values)/len(values)) for key,values in losses.items()]
    mean=math.fsum(row['mean_ce'] for row in expected_rows)/len(expected_rows) if expected_rows else None
    check(close(receipt['row_losses'],expected_rows) and close(receipt['mean_loss'],mean), 'boundary/row_balanced_mean/'+label)
    check(receipt['rows']==len(ids) and receipt['active_rows']==active and receipt['rows_without_sites']==empty
        and receipt['rows_without_selected_sites']==inactive and receipt['available_sites']==available
        and receipt['selected_sites']==len(selected) and receipt['ignored_sites']==available-len(selected)
        and receipt['replay_prefix_tokens']==replayed and receipt['stop_labels']==stop and receipt['continue_labels']==len(selected)-stop
        and close(receipt['maximum_replay_logit_absolute_difference'],max_delta,1e-10),'boundary/complete_exposure_counters/'+label)
    prior.authority(receipt,label+'/authority')
    return dict(available_sites=available,selected_sites=len(selected),rows_without_sites=empty,rows_without_selected_sites=inactive,
        replay_prefix_tokens=replayed,generated_tokens=generated,greedy_batch_steps=generation['greedy_batch_steps'],
        stop_labels=stop,continue_labels=len(selected)-stop,actual_wrong_boundary_decisions=wrong,wrong_decisions_not_selected=missed,
        active_updates=int(mean is not None),skipped_updates=int(mean is None)),mean


def training(run,ctx):
    report=run['training'];weight=run['recipe']['generated_boundary_weight'];clean=deepcopy(run);totals=Counter()
    if weight:
        policy=run['recipe']['generated_boundary_site_policy']
        check(report['config']['max_memory_bytes']==1073741824
            and report['memory_estimate_excludes_python_import_allocator_rss'] is True,
            'boundary/explicit_larger_tensor_work_estimate_only/'+run['arm'])
        clean['training']['config']['max_memory_bytes']=ctx['prior']['shared-'+str(run['seed'])]['training']['config']['max_memory_bytes']
        check(report['generated_boundary_weight']==.05 and report['generated_boundary_used_for_selection'] is False
            and report['generated_boundary_site_cap_per_row']==(2 if policy=='first_last' else 1)
            and report['generated_boundary_rows']=='current_effective_training_batch_only'
            and report['generated_boundary_reference_access']=='training_loss_labels_only; never_greedy_rollout',
            'boundary/report_scope/'+run['arm'])
        for update,copy in zip(report['committed_updates'],clean['training']['committed_updates']):
            counters,loss=boundary_receipt(update['generated_boundary'],update['decoder_row_ids'],ctx,policy,run['arm']+'/'+str(update['optimizer_step']))
            totals.update(counters);copy['objective']-=weight*(loss or 0.);copy.pop('generated_boundary')
        if report['committed_updates']:
            check(report['committed_updates'][0]['generated_boundary']['generation']['model_tensor_sha256']==report['initial_weights_sha256'],
                'boundary/first_rollout_is_fresh_initial_state/'+run['arm'])
        clean['recipe']['generated_boundary_weight']=0.
    else:
        check(all('generated_boundary' not in u for u in report['committed_updates']), 'boundary/zero_arm_no_auxiliary_reports/'+run['arm'])
    detail=action.training(clean,ctx);detail['context_boundary']=dict(totals);return detail


def baseline_replay(run,report,states,panels,old,label):
    check(set(report)==set(old['training']) and all(report[key]==value for key,value in old['training'].items() if key!='elapsed_seconds'),
        'baseline/all_report_fields_except_elapsed/'+label)
    for role,state in states.items():
        expected=inherited(B/'training-r1/results'/old['arm']/(role+'-state.json'))
        check(state['model_state']==expected['model_state'] and state['tensor_sha256']==expected['tensor_sha256'],'baseline/exact_all_tensors/'+label+'/'+role)
    for role in ('selected','last-attempt'):
        for name,_,_ in CONTROLS:
            expected=inherited(B/'training-r1/results'/old['arm']/role/('evaluation-'+name+'.json'))
            for key in ('predictions','source_fidelity','source_count','source_values','hypothetical_boundary_diagnostics'):
                check(panels[role][name][key]==expected[key],'baseline/exact_'+key+'/'+label+'/'+role+'/'+name)
            without_time=lambda value:{k:v for k,v in value.items() if k!='elapsed_seconds'}
            check(without_time(panels[role][name]['recurrent_residual_diagnostic'])==without_time(expected['recurrent_residual_diagnostic']),
                'baseline/exact_recurrent_readouts_except_elapsed/'+label+'/'+role+'/'+name)
    check(run['baseline_replay']['complete'] and not run['baseline_replay']['timing_equality_claimed'],'baseline/explicit_runner_receipt/'+label)


def results(args,ctx):
    root=args.results;summary=read(root/'summary.json');prior.authority(summary,'summary')
    names=[str(d)+'-'+a['name']+'-'+str(s) for d in (8,384,768) for s in (1729,2718) for a in ctx['plan']['arms']]
    check(summary['complete'] and [r['arm'] for r in summary['runs']]==names,'results/all_18_registered_fits')
    check(not summary['encoder_executed'] and not summary['downloads_performed'],'results/no_encoder_or_download')
    lanes={d:native.lane_preparation(root,ctx,d) for d in (8,384,768)};out={};cache=set()
    for pointer in summary['runs']:
        pin(pointer['summary_path'],pointer['summary_sha256']);run=read(pointer['summary_path']);label=run['arm'];lane=lanes[run['dimension']]
        old=ctx['baseline'][str(run['dimension'])+'-recurrent-clause-'+str(run['seed'])]
        pin(run['training_ref']['path'],run['training_ref']['sha256']);report=read(run['training_ref']['path']);run['training']=report
        lane['prior']={'shared-'+str(run['seed']):dict(training=old['training'])}
        detail=training(run,lane);original=inherited(B/'training-r1/results'/old['arm']/'initial-state.json');states={}
        for role in ('initial','selected','last-attempt'):
            states[role]=ordered.state_check(root/label/(role+'-state.json'),report,role,original,lane,True,label+'/'+role)
        check(run['trainable_parameter_count']==states['last-attempt']['_audited_trainable_count']==old['trainable_parameter_count'],
            'state/exact_unchanged_parameter_count/'+label)
        parity=read(root/label/'initial-parity.json')
        check(parity==run['initial_parity'] and parity['complete'] and parity['predictions']==old['initial_parity']['predictions'],
            'initial/all96_full_greedy_parity/'+label)
        panels={};metrics={}
        for role in ('selected','last-attempt'):
            panels[role]={};metrics[role]={}
            check(set(run['postfit'][role])=={n for n,_,_ in CONTROLS},'postfit/exact_controls/'+label+'/'+role)
            for name,split,kind in CONTROLS:
                entry=run['postfit'][role][name];pin(entry['path'],entry['sha256']);panel=read(entry['path']);panels[role][name]=panel
                check(entry['numerical']==panel['report'] and entry['fidelity']=={k:v for k,v in panel['source_fidelity'].items() if k!='rows'},
                    'postfit/compact_index_binding/'+label+'/'+role+'/'+name)
                viewed=panel
                if name=='recurrent-residual-off':
                    check(panel['execution']['kind']=='recurrent_residual_off' and panel['execution']['recurrent_residual_disabled'] is True,
                        'postfit/explicit_recurrent_ablation/'+label+'/'+role)
                    viewed=deepcopy(panel);viewed['execution']['kind']='conditioned'
                metrics[role][name]=clause.panel_check(viewed,split,kind,states[role],lane,label+'/'+role+'/'+name,cache)
                metrics[role][name]['recurrent_readouts']=ordered.recurrent_readouts(panel,states[role],lane,split,kind,
                    name=='recurrent-residual-off',label+'/'+role+'/'+name)
                if name=='validation':
                    target=report['selected'] if role=='selected' else report['last_complete_attempt']
                    check(panel['report']['metrics']==target['numerical'],'postfit/selection_binding/'+label+'/'+role)
        if not run['recipe']['generated_boundary_weight']:baseline_replay(run,report,states,panels,old,label)
        else:check(run['baseline_replay'] is None,'baseline/no_candidate_replay_claim/'+label)
        out[label]=dict(training=detail,controls=metrics,selected_epoch=report['selected_epoch'],fit_elapsed_seconds=run['training_call_elapsed_seconds'])
    resource=read(root.parent/'resources-final.json');record=resource['record']
    check(resource['status']==record['status']=='released' and record['artifacts_durable_asserted'] is True
        and record['attempt_exceeded_reservation'] is False and record['storage_bytes']==3000000000
        and record['memory_mb']==4096 and record['cpu_slots']==1,'resources/released_durable_within_reservation')
    before=read(R/'before.json')['checkpoint'];pin(before['path'],before['sha256'])
    check(Path(before['path']).stat().st_size==before['bytes'],'protection/unchanged_original_checkpoint')
    return dict(runs=out,states=54,panels=324,distinct_fidelity_panels=len(cache),resources=resource,
        limits=['Saved-data arithmetic, not full optimizer or recurrent execution replay.',
        'Intermediate-weight hashes do not independently establish saved rollout logits.',
        'Previously exposed development cohort; no fresh holdout, global convergence, Lake admission or promotion.'])


def main():
    parser=argparse.ArgumentParser()
    for name in ('source','manifest','plan','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--results',type=Path);args=parser.parse_args()
    for key in vars(args):
        if getattr(args,key) is not None:setattr(args,key,getattr(args,key).resolve())
    ctx=common(args)
    suites=list(ET.parse(pin(R/'tests-scoped.xml')).iter('testsuite'))
    check(suites and all(int(s.get(k,0))==0 for s in suites for k in ('errors','failures','skipped')),'tests/scoped_suite_clean')
    provenance=read(R/'test-import-provenance-scoped.json')
    check(provenance['pytest_returncode']==0 and provenance['test_source_frozen'] is True,'tests/frozen_source_provenance')
    dependency=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
    for name,entry in provenance['modules'].items():
        path=pin(entry['path'],entry['sha256']);check(path.is_relative_to(args.source) or path.is_relative_to(dependency),'tests/no_live_or_HACC/'+name)
    check(all(Path(path).is_relative_to(dependency) for path in provenance['tree_pin'].values()),'tests/pinned_logic_tree')
    analysis=results(args,ctx) if args.results else dict(dimensions=[8,384,768],inherited_source_inputs_authenticated=True)
    analysis['tests']=dict(fresh_scoped_count=sum(int(s.get('tests',0)) for s in suites),historical_unused_fixture_exclusions=16)
    check('torch' not in sys.modules and 'transformers' not in sys.modules,'audit/no_model_imports');pin(__file__)
    value=dict(schema='context-boundary-training-independent-audit/v1',phase='results' if args.results else 'readiness',
        passed=not findings,complete=not findings,checks=checks,finding_count=len(findings),findings=findings,artifacts=artifacts,
        source_path=str(Path(__file__).resolve()),source_sha256=sha(__file__),manifest_path=str(args.manifest),manifest_sha256=sha(args.manifest),
        plan_path=str(args.plan),plan_sha256=sha(args.plan),analysis=analysis,created_at_utc=datetime.now(timezone.utc).isoformat(),
        models_executed=False,training_executed=False,encoder_executed=False,qualified=False,admitted=False,lake_executed=False,fresh_holdout=False)
    if not args.results:value['pre_execution']=not bool(list(R.glob('training-*/results')))
    args.output.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(passed=not findings,checks=checks,findings=findings,output=str(args.output))))
    if findings:raise SystemExit(1)


if __name__=='__main__':main()
