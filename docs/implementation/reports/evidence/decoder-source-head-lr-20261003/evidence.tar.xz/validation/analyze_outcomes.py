"""Saved-results-only source-head learning-rate comparison; no model imports or forwards."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import struct
import statistics
import sys

R=Path(__file__).resolve().parent
T=R/'training-r1/results'
ARTIFACTS={}
CHECKS=0
FALSE=dict(qualified=False,admitted=False,proof_authority=False,lake_executed=False,
    model_executed=False,formula_semantics_verified=False,formalized=False,roundtrip_ok=False,
    checkpoint_promoted=False,fresh_holdout=False,convergence_proven=False)

def require(value,message):
    global CHECKS
    CHECKS+=1
    if not value:raise ValueError(message)

def read(path,digest=None):
    path=Path(path).resolve();data=path.read_bytes();actual=hashlib.sha256(data).hexdigest()
    if digest is not None:require(actual==digest,'input hash differs: '+str(path))
    prior=ARTIFACTS.get(str(path));entry=dict(sha256=actual,bytes=len(data))
    require(prior is None or prior==entry,'artifact changed during analysis')
    ARTIFACTS[str(path)]=entry
    return json.loads(data)

def by_length(rows):
    out={str(n):dict(rows=0,exact=0,eos=0,duplicates=0,missing=0,extra=0,
        length_correct=0,short=0,long=0,unparsed=0,syntax_valid=0,generated_action=0,generated_actor_action=0)
        for n in (1,2,4,8)}
    for row in rows:
        expected=row['expected_ir']['rules'];n=len(expected);result=out[str(n)];c=row['counts']
        require(row['clause_count']==n,'expected row length differs')
        for outkey,inkey in [('exact','ordered_exact'),('eos','eos_count'),('duplicates','duplicate_rules'),
            ('missing','whole_rules_missing'),('extra','whole_rules_extra')]:result[outkey]+=c[inkey]
        result['rows']+=1;result['syntax_valid']+=c['syntax_valid'];generated=row['generated_ir'];parsed=c['parsed_documents']==1
        if not parsed:result['unparsed']+=1
        else:
            rules=generated['rules'];result['length_correct' if len(rules)==n else 'short' if len(rules)<n else 'long']+=1
            # Positional pair equality is computed from the saved parsed JSON;
            # it is not an additional syntax, semantics, or proof check.
            for reference,prediction in zip(expected,rules):
                if not isinstance(prediction,dict):continue
                result['generated_actor_action']+=int(all(reference[k]==prediction.get(k) for k in ('actor','action')))
        result['generated_action']+=row['by_facet']['action']['correct']
    return out

def panel_summary(value):
    fidelity=value['source_fidelity'];m=fidelity['metrics'];numerical=value['report'];v=value['source_values'];count=value['source_count']
    require(numerical['complete'] and numerical['sample_count']==48 and len(fidelity['rows'])==48,'complete48-row panel required')
    require(numerical['generation_temperature']==0 and not numerical['generation_target_access'],'generation policy differs')
    require(not any(numerical.get(k,False) for k in FALSE),'unexpected numerical authority')
    lengths=by_length(fidelity['rows'])
    for outkey,metric in [('exact','ordered_exact'),('eos','eos_count'),('duplicates','duplicate_rules'),('missing','whole_rules_missing'),('extra','whole_rules_extra')]:
        require(sum(x[outkey] for x in lengths.values())==m[metric],'fidelity aggregation differs: '+metric)
    require(sum(x['generated_action'] for x in lengths.values())==fidelity['by_facet']['action']['correct'],'action aggregation differs')
    rawpairs=rawaction=0
    for row in v['predictions']:
        for expected,predicted in zip(row['expected_token_ids'],row['predicted_token_ids']):
            if expected[0]<0:continue
            rawpairs+=int(predicted[:2]==expected[:2]);rawaction+=int(predicted[1]==expected[1])
    require(rawaction==v['by_field']['action']['correct'],'raw action summary differs')
    seconds=numerical['elapsed_seconds'];wall=value['timing']['postfit_evaluation_elapsed_seconds']
    require(math.isclose(seconds/48,numerical['wall_seconds_per_span'],rel_tol=1e-10),'reported per-span time differs')
    return dict(exact=m['ordered_exact'],rows=48,eos=m['eos_count'],syntax_valid=m['syntax_valid'],
        duplicates=m['duplicate_rules'],missing=m['whole_rules_missing'],extra=m['whole_rules_extra'],
        expected_rules=m['expected_rules'],generated_rules=m['generated_rules'],
        raw_action=rawaction,generated_action=fidelity['by_facet']['action']['correct'],
        raw_actor_action=rawpairs,generated_actor_action=sum(x['generated_actor_action'] for x in lengths.values()),
        raw_scalar_correct=v['correct'],raw_scalar_presentations=v['present_values'],
        raw_scalar_ce=v['cross_entropy'],count_correct=count['correct'],count_ce=count['cross_entropy'],
        count_by_length=count['by_length'],token_ce=numerical['metrics']['token_cross_entropy'],
        reconstruction_mse=numerical['metrics']['reconstructed_input_mse'],identity_mse_is_not_learned_reconstruction=True,
        by_length=lengths,numerical_seconds_per48=seconds,numerical_seconds_per_span=seconds/48,
        whole_panel_seconds_per48=wall,whole_panel_seconds_per_span=wall/48,
        potential_residual_observation_seconds=value.get('recurrent_residual_diagnostic',{}).get('elapsed_seconds'),
        numerical_timing_scope=numerical['timing_scope'],whole_panel_timing_scope=value['timing']['scope'],
        execution_kind=value['execution']['kind'])


def boundary_summary(report, recipe):
    enabled = recipe['generated_boundary_weight'] > 0
    updates = report['committed_updates']
    if not enabled:
        require(not any('generated_boundary' in update for update in updates), 'baseline attached boundary receipt')
        require(not any(key.startswith('generated_boundary_') for key in report), 'baseline report changed')
        return dict(enabled=False, rollout_rows=0, active_rows=0, selected_sites=0,
            additional_boundary_supervision=False)
    require(report['generated_boundary_weight'] == .05, 'boundary coefficient differs')
    require(report['generated_boundary_used_for_selection'] is False, 'boundary loss used for selection')
    policy = recipe['generated_boundary_site_policy']
    totals = Counter()
    stage_totals = {}
    losses = []
    collection_seconds = replay_seconds = maximum_logit_difference = 0.
    for update in updates:
        receipt = update['generated_boundary']
        generation = receipt['generation']
        require(receipt['schema'] == 'contextual-generated-source-boundary-loss/v1', 'wrong boundary receipt owner')
        require(receipt['selection_policy'] == policy and receipt['gradient_scope'] == 'all_trainable', 'boundary policy differs')
        require(receipt['site_cap_per_row'] == (1 if policy == 'first_wrong' else 2), 'boundary site cap differs')
        require(receipt['full_vocabulary_cross_entropy'] and receipt['reference_counts_used_only_in_loss']
            and not receipt['target_prefixes_used'], 'boundary supervision scope differs')
        require(generation['source_only'] and not generation['reference_count_access'] and not generation['site_policy_access']
            and generation['complete_rollout_before_site_selection'], 'generation received loss-only information')
        require(generation['max_target_tokens'] == 512, 'boundary output limit differs')
        require([row['id'] for row in generation['rows']] == update['decoder_row_ids'], 'boundary batch differs')
        require(all(row['id'].startswith('authored-paragraph:train:') for row in generation['rows']), 'non-training boundary source')
        require(all('input' not in row and 'source_contexts' not in row and row.get('source_context_sha256')
            and row.get('source_text_sha256') for row in generation['rows']), 'boundary source provenance differs')
        require(receipt['selected_sites'] == len(receipt['events'])
            and receipt['selected_sites'] + receipt['ignored_sites'] == receipt['available_sites'], 'boundary site totals differ')
        require(receipt['active_rows'] == len(receipt['row_losses'])
            and receipt['active_rows'] + receipt['rows_without_selected_sites'] == receipt['rows'], 'boundary active-row totals differ')
        require(receipt['stop_labels'] + receipt['continue_labels'] == len(receipt['events']), 'boundary label totals differ')
        observed_loss = 0.
        for event in receipt['events']:
            logits = event['replay_logits']
            require(len(logits) == receipt['vocabulary_size'], 'boundary CE omitted vocabulary classes')
            peak = max(logits)
            ce = peak + math.log(sum(math.exp(value - peak) for value in logits)) - logits[event['target_token_id']]
            require(math.isclose(ce, event['cross_entropy'], abs_tol=2e-5, rel_tol=2e-5), 'boundary CE arithmetic differs')
            require(event['action'] == ('continue' if event['completed_rules'] < event['training_count'] else 'stop'),
                'boundary training label differs')
            if policy == 'first_wrong':
                require(event['actual_next_token_id'] != event['target_token_id'], 'first-wrong selected a correct decision')
            observed_loss += ce * event['mean_loss_coefficient']
        raw_loss = receipt['mean_loss']
        if receipt['active_rows']:
            require(raw_loss is not None and math.isclose(observed_loss, raw_loss, abs_tol=2e-5, rel_tol=2e-5),
                'boundary equal-row reduction differs')
            losses.append(raw_loss)
        else:
            require(raw_loss is None and not receipt['events'], 'empty boundary batch created loss')
        expected = update['weighted_token_ce'] + report['config']['reconstruction_weight'] * update['raw_reconstruction_mse']
        expected += .25 * update['count_ce'] + .25 * update['source_value_ce']
        expected += .05 * (update['action_contrastive']['loss'] or 0.) + .05 * (raw_loss or 0.)
        require(math.isclose(expected, update['objective'], abs_tol=2e-5, rel_tol=2e-5), 'combined objective arithmetic differs')
        row_tokens = sum(len(row['consumed_prefix']) for row in generation['rows'])
        replay_tokens = sum(row['replay_prefix_tokens'] for row in generation['rows'])
        require(replay_tokens == receipt['replay_prefix_tokens'], 'replayed row-token total differs')
        counts = dict(updates=1, updates_with_loss=int(raw_loss is not None), updates_without_loss=int(raw_loss is None),
            rollout_rows=receipt['rows'], active_rows=receipt['active_rows'],
            rows_without_sites=receipt['rows_without_sites'], rows_without_selected_sites=receipt['rows_without_selected_sites'],
            rows_with_sites_without_selected_error=receipt['rows_without_selected_sites']-receipt['rows_without_sites'],
            available_sites=receipt['available_sites'], selected_sites=receipt['selected_sites'], ignored_sites=receipt['ignored_sites'],
            selected_wrong_decision_sites=sum(event['actual_next_token_id'] != event['target_token_id'] for event in receipt['events']),
            selected_correct_decision_sites=sum(event['actual_next_token_id'] == event['target_token_id'] for event in receipt['events']),
            stop_labels=receipt['stop_labels'], continue_labels=receipt['continue_labels'],
            actual_consumed_rollout_row_tokens_including_bos=row_tokens,
            differentiable_replay_row_tokens=replay_tokens, greedy_batch_steps=generation['greedy_batch_steps'])
        totals.update(counts)
        stage_totals.setdefault(update['stage'], Counter()).update(counts)
        collection_seconds += generation['elapsed_seconds']
        replay_seconds += receipt['elapsed_seconds']
        maximum_logit_difference = max(maximum_logit_difference, receipt['maximum_replay_logit_absolute_difference'])
    require(totals['rollout_rows'] == report['row_presentations'] and totals['updates'] == report['optimizer_steps'],
        'boundary collection exposure differs from ordinary batches')
    return dict(enabled=True, weight=.05, selection_policy=policy, gradient_scope='all_trainable', **dict(totals),
        per_stage={key: dict(value) for key, value in stage_totals.items()},
        mean_active_update_boundary_ce=sum(losses)/len(losses) if losses else None,
        last_active_update_boundary_ce=losses[-1] if losses else None,
        collection_seconds=collection_seconds, loss_helper_seconds=replay_seconds,
        boundary_helper_seconds=collection_seconds+replay_seconds,
        boundary_timing_scope='sum of collection and loss-helper calls within trainer; excludes combined backward/optimizer and is not an independent fit time',
        maximum_replay_logit_absolute_difference=maximum_logit_difference,
        equal_compute_claimed=False, additional_boundary_supervision=True,
        row_tokens_exclude_padding_and_inactive_batch_work=True)


_original_panel_summary = panel_summary


def panel_summary(value):
    result = _original_panel_summary(value)
    result['raw_scalar_by_field'] = value['source_values']['by_field']
    result['generated_scalar_by_field'] = {field: value['source_fidelity']['by_facet'][field]
        for field in ('actor', 'action', 'modality', 'object')}
    result['generated_scalar_metric_scope'] = 'existing saved fidelity scorer alignment including missing/invalid output; not only visited generated sites'
    return result


NAMES=('boundary-first-last','source-head-lr10')
FIELDS=('actor','action','modality','object')
CONTROL_NAMES={'validation','training','zero-condition','source-shuffle','cross-length-shuffle',
    'context-only-shuffle','context-reverse','context-rotate','recurrent-residual-off'}
TIMING_EXCLUSIONS=['elapsed_seconds','committed_updates[*].generated_boundary.elapsed_seconds',
    'committed_updates[*].generated_boundary.generation.elapsed_seconds','committed_updates[*].generated_boundary.collection_sha256']
HEAD_NAMES=['non_action_head.'+name for name in ('source_projection.weight','source_projection.bias',
    'field_readout.weight','field_readout.bias')]


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def close(a,b,label,atol=2e-5,rtol=2e-5):
    require(type(a) in (int,float) and type(b) in (int,float) and math.isfinite(a) and math.isfinite(b)
        and math.isclose(a,b,abs_tol=atol,rel_tol=rtol),label)


_base_panel_summary=panel_summary


def panel_summary(value):
    result=_base_panel_summary(value)
    losses={field:[] for field in FIELDS};margins={field:[] for field in FIELDS};correct=Counter()
    for row in value['source_values']['predictions']:
        require(len(row['expected_token_ids'])==len(row['predicted_token_ids'])==len(row['raw_logits'])==8,
            'raw source slots differ')
        for expected,predicted,all_logits in zip(row['expected_token_ids'],row['predicted_token_ids'],row['raw_logits']):
            require(len(expected)==len(predicted)==len(all_logits)==4,'raw source field inventory differs')
            for field,target,guess,logits in zip(FIELDS,expected,predicted,all_logits):
                if target<0:continue
                require(len(logits)==32 and all(math.isfinite(x) for x in logits),'raw source full-vocabulary logits required')
                require(max(range(32),key=logits.__getitem__)==guess,'raw source argmax differs')
                peak=max(logits);losses[field].append(peak+math.log(math.fsum(math.exp(x-peak) for x in logits))-logits[target])
                margins[field].append(logits[target]-max(x for i,x in enumerate(logits) if i!=target))
                correct[field]+=guess==target
    arithmetic={}
    for field in FIELDS:
        saved=value['source_values']['by_field'][field]
        require(len(losses[field])==saved['present_values']==180 and correct[field]==saved['correct'],
            'raw source field cohort/count differs')
        arithmetic[field]=dict(full_vocabulary_ce=statistics.fmean(losses[field]),correct=correct[field],rows=180,
            mean_target_margin=statistics.fmean(margins[field]),minimum_target_margin=min(margins[field]))
    close(statistics.fmean([v['full_vocabulary_ce'] for v in arithmetic.values()]),value['source_values']['cross_entropy'],
        'raw source total CE differs')
    result['raw_scalar_arithmetic']=arithmetic
    heads={row['id']:row for row in value['source_values']['predictions']}
    contingency={field:Counter() for field in FIELDS};all_rules=all_paragraphs=0
    for row in value['source_fidelity']['rows']:
        head=heads[row['id']];expected=row['expected_ir']['rules']
        generated=row['generated_ir']['rules'] if row['counts']['parsed_documents']==1 else []
        hits=[]
        for slot,reference in enumerate(expected):
            target=head['expected_token_ids'][slot];guess=head['predicted_token_ids'][slot]
            hits.append(target==guess)
            observed=generated[slot] if slot<len(generated) and type(generated[slot]) is dict else {}
            for field,a,b in zip(FIELDS,target,guess):
                key=('raw_correct' if a==b else 'raw_wrong')+('_generated_correct' if observed.get(field)==reference[field] else '_generated_wrong')
                contingency[field][key]+=1
        all_rules+=sum(hits);all_paragraphs+=all(hits)
    for field,bucket in contingency.items():
        require(bucket['raw_correct_generated_correct']+bucket['raw_correct_generated_wrong']==arithmetic[field]['correct'],
            'raw/generated contingency raw marginal differs')
        if result['syntax_valid']==48:
            require(bucket['raw_correct_generated_correct']+bucket['raw_wrong_generated_correct']==result['generated_scalar_by_field'][field]['correct'],
                'raw/generated contingency generated marginal differs on fully valid panel')
    result['raw_generated_positional_correctness_contingency']={field:dict(bucket) for field,bucket in contingency.items()}
    result['raw_generated_contingency_scope']='positional parsed scalar equality, including invalid rules; main generated_scalar_by_field retains the unchanged rule-validation gate'
    result['raw_all_field_correct_rules']=all_rules
    result['raw_all_field_correct_paragraphs']=all_paragraphs
    return result


def parameter_size(value):
    if type(value) is list:return sum(parameter_size(item) for item in value)
    require(type(value) in (int,float) and math.isfinite(value),'finite saved tensor required')
    return 1


def check_baseline(arm,report,old):
    previous=read(old['training_ref']['path'],old['training_ref']['sha256'])
    require(set(previous)==set(report),'baseline report fields differ')
    for key in report:
        if key=='elapsed_seconds':continue
        if key!='committed_updates':
            require(report[key]==previous[key],'baseline report field differs: '+key)
            continue
        require(len(report[key])==len(previous[key]),'baseline committed update count differs')
        for current,prior in zip(report[key],previous[key]):
            require(set(current)==set(prior),'baseline committed update fields differ')
            for field in current:
                if field!='generated_boundary':
                    require(current[field]==prior[field],'baseline update field differs: '+field)
                    continue
                a,b=current[field],prior[field]
                require(set(a)==set(b),'baseline boundary receipt fields differ')
                for item in a:
                    if item in ('elapsed_seconds','collection_sha256'):continue
                    if item=='generation':
                        require(set(a[item])==set(b[item]),'baseline generation fields differ')
                        require({k:v for k,v in a[item].items() if k!='elapsed_seconds'}==
                            {k:v for k,v in b[item].items() if k!='elapsed_seconds'},'baseline generation decisions/logits differ')
                    else:require(a[item]==b[item],'baseline boundary field differs: '+item)
    for role in ('initial','selected','last-attempt'):
        a=read(arm['states'][role]['path'],arm['states'][role]['sha256'])
        b=read(old['states'][role]['path'],old['states'][role]['sha256'])
        require(a['model_state']==b['model_state'] and a['tensor_sha256']==b['tensor_sha256'],
            'baseline all saved model tensors differ: '+role)
    for role,controls in arm['postfit'].items():
        for name,ref in controls.items():
            a=read(ref['path'],ref['sha256']);prior=old['postfit'][role][name];b=read(prior['path'],prior['sha256'])
            require(a['predictions']==b['predictions'] and a['source_values']==b['source_values']
                and a['source_count']==b['source_count'],'baseline control predictions/readouts differ')
    require(arm['baseline_replay']['complete'] and arm['baseline_replay']['all_tensors_and_predictions_equal']
        and not arm['baseline_replay']['timing_equality_claimed']
        and arm['baseline_replay']['excluded_fields']==TIMING_EXCLUSIONS,'baseline replay receipt differs')
    return dict(exact_training_report_except_explicit_timing_paths=True,all_saved_model_tensors_equal=True,
        all_nine_control_predictions_and_readouts_equal=True,exclusions=TIMING_EXCLUSIONS,timing_equality_claimed=False)


def optimizer_summary(arm,report,initial):
    candidate=arm['recipe']['non_action_learning_rate_multiplier']==10.
    require(arm['recipe']['non_action_learning_rate_multiplier'] in (1.,10.),'unplanned optimizer multiplier')
    config=report['config'];updates=report['committed_updates'];history=report['history'];stages=report['stage_reports']
    require(config['learning_rate']==.001 and config['max_grad_norm']==1. and config['weight_decay']==.01,
        'common optimizer settings differ')
    require(report['optimizer_instance_count']==1 and not report['optimizer_reinitialized_between_stages']
        and not report['optimizer_resumable'],'optimizer continuity differs')
    require(len(updates)==340 and all(update['optimizer_step']==i for i,update in enumerate(updates,1)),
        'complete committed optimizer sequence required')
    require(report['selection']=='per_length_nonregression_then_fidelity_progress_then_reference_ce'
        and not report['source_value_metrics_used_for_selection'] and not report['generated_boundary_used_for_selection'],
        'selection policy differs')
    gradient=report['gradient_norms'];norms=[update['preclip_norm'] for update in updates]
    require(all(math.isfinite(x) and x>=0 for x in norms),'finite preclip norms required')
    require(gradient['optimizer_steps']==340 and gradient['limit']==1.
        and gradient['norm_exceeded_limit_steps']==sum(x>1 for x in norms),'clipping ledger differs')
    close(gradient['mean_preclip_norm'],statistics.fmean(norms),'mean preclip norm differs',1e-12,1e-12)
    close(gradient['max_preclip_norm'],max(norms),'peak preclip norm differs',1e-12,1e-12)
    require(report['row_presentations']==sum(len(u['decoder_row_ids']) for u in updates)==2440,
        'decoder row presentation ledger differs')
    require(report['count_training_row_presentations']==sum(len(u['count_row_ids']) for u in updates)==2440,
        'count row presentation ledger differs')
    require(report['valid_target_token_presentations']==sum(u['target_token_presentations'] for u in updates)==225840
        and report['source_value_presentations']==sum(u['source_value_presentations'] for u in updates)==25600,
        'token/scalar presentation ledger differs')
    for mode,field in [('decoder','decoder_row_ids'),('count','count_row_ids')]:
        sequence=hashlib.sha256()
        for u in updates:sequence.update(json.dumps(u[field],sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode())
        require(sequence.hexdigest()==report['committed_'+mode+'_batch_ids_sha256'],'batch sequence digest differs')
    require(report['count_training_presentations_by_class']=={'1':610,'2':610,'4':610,'8':610},'balanced count exposure differs')
    for update in updates:
        require(all(identity.startswith('authored-paragraph:train:') for identity in update['decoder_row_ids']+update['count_row_ids']),
            'nontraining source in committed stream')
        require('generated_sites' not in update,'unplanned generated field auxiliary')
    if candidate:
        require(report['non_action_learning_rate_multiplier']==10.
            and report['optimizer_scheduler_epsilon']==0.
            and report['optimizer_global_clip_parameter_order']=='original_model_trainable_order'
            and report['optimizer_group_learning_rate_policy']=='fixed_non_action_multiplier; proportional_plateau_minima; epsilon_zero'
            and report['optimizer_group_learning_rates_scope']=='committed_updates_are_pre_scheduler; epoch_history_is_post_scheduler'
            and not report['non_action_learning_rate_used_for_selection'],'candidate optimizer semantics differ')
        groups=report['optimizer_parameter_groups'];require([g['name'] for g in groups]==['base','non_action_head'],
            'candidate optimizer group inventory differs')
        base,head=groups
        require(head['parameter_names']==HEAD_NAMES,'non-action head grouping changed')
        names=base['parameter_names']+head['parameter_names']
        require(len(names)==len(set(names)),'duplicate optimizer group membership')
        # The saved state also contains buffers; exhaustive model parameter coverage
        # is checked by the producer and independent audit, not inferred from buffers.
        require(set(names)<=set(initial['model_state']) and not set(names)&set(report['frozen_parameter_names']),
            'group contains absent/frozen tensor')
        for group,factor in zip(groups,(1.,10.)):
            require(group['learning_rate_multiplier']==factor and group['initial_learning_rate']==.001*factor
                and group['minimum_learning_rate']==.001*factor*config['min_learning_rate_ratio']
                and group['weight_decay']==.01,'group optimizer settings differ')
            require(group['parameter_count']==sum(parameter_size(initial['model_state'][name]) for name in group['parameter_names']),
                'group parameter count differs')
        require(sum(g['parameter_count'] for g in groups)==arm['trainable_parameter_count'],'group parameter total differs')
    else:
        require(not any(key in report for key in ('non_action_learning_rate_multiplier','optimizer_parameter_groups')),
            'baseline attached opt-in group fields')
        require(all('optimizer_group_learning_rates' not in u for u in updates+history)
            and all('optimizer_group_learning_rates_start' not in stage for stage in stages),'baseline telemetry changed')
        groups=None
    def rates(item):
        if not candidate:return dict(base=item['learning_rate'])
        value=item['optimizer_group_learning_rates'];require(set(value)=={'base','non_action_head'},'rate group keys differ')
        close(value['base'],item['learning_rate'],'scalar rate differs from base group',0.,1e-12)
        close(value['non_action_head'],10*value['base'],'non-action multiplier drifted',0.,1e-12)
        for group in groups:
            require(group['minimum_learning_rate']<=value[group['name']]<=group['initial_learning_rate'],'rate outside planned bounds')
        return value
    before=[rates(update) for update in updates];after=[rates(epoch) for epoch in history]
    changes=[];previous=before[0]
    require(previous['base']==.001,'initial base rate differs')
    for update,value in zip(updates,before):
        if value!=previous:
            changes.append(dict(first_optimizer_step=update['optimizer_step'],epoch=update['epoch'],rates=value))
            require(all(value[k]<=previous[k] for k in value),'scheduler increased a rate')
        previous=value
    for i,epoch in enumerate(history):
        part=[u for u in updates if u['epoch']==epoch['epoch']]
        require(part and all(rates(u)==rates(part[0]) for u in part),'rate changed within epoch')
        require(all(after[i][k]<=rates(part[0])[k] for k in after[i]),'scheduler increased epoch rate')
        if i+1<len(history):
            next_update=next(u for u in updates if u['epoch']==history[i+1]['epoch'])
            require(rates(next_update)==after[i],'post-scheduler rate did not carry into next epoch')
    if candidate:
        for group in groups:require(group['final_learning_rate']==after[-1][group['name']],'final group rate differs')
        for stage in stages:
            first=updates[stage['optimizer_step_start']];last_epoch=next(e for e in reversed(history) if e['stage']==stage['name'])
            require(stage['optimizer_group_learning_rates_start']==rates(first)
                and stage['optimizer_group_learning_rates_end']==rates(last_epoch),'stage group rates differ')
    return dict(enabled=candidate,multiplier=10. if candidate else 1.,parameter_groups=groups,
        initial_rates=before[0],final_rates=after[-1],committed_rate_changes=changes,
        epoch_rate_history=[dict(epoch=e['epoch'],optimizer_steps=e['optimizer_steps'],rates=v,
            scheduler_observation=e['numerical'] is not None) for e,v in zip(history,after)],
        gradient_norms=gradient,full_adam_trajectory_replayed=False,
        per_step_decay_policy='AdamW lr*weight_decay; raising the head LR also raises its decoupled shrinkage',
        global_clipping_couples_group_gradients=True,
        ordinary_exposure=dict(optimizer_steps=340,rows=2440,count_rows=2440,tokens=225840,scalar_labels=25600),
        source_count_stream_sha256=report['committed_count_batch_ids_sha256'],
        decoder_stream_sha256=report['committed_decoder_batch_ids_sha256'])


def initial_parity(arm,report,old):
    original=read(old['states']['initial']['path'],old['states']['initial']['sha256'])
    current=read(arm['states']['initial']['path'],arm['states']['initial']['sha256'])
    require(current['model_state']==original['model_state'] and current['tensor_sha256']==original['tensor_sha256']
        ==report['initial_weights_sha256'],'original fresh initializer differs')
    require(arm['initial_parity']['complete'] and arm['initial_parity']['parameter_delta']==0
        and arm['initial_parity']['inherited_initial_tensors_equal']
        and arm['initial_parity']['prior_initial_generation_equal'],'initial parity receipt differs')
    for role,key in [('selected','selected_weights_sha256'),('last-attempt','last_complete_attempt_weights_sha256')]:
        state=read(arm['states'][role]['path'],arm['states'][role]['sha256'])
        require(state['tensor_sha256']==report[key],'saved state/report identity differs')
        require(not any(state.get(k,False) for k in FALSE),'saved state has unexpected authority')
    return current



def remaining_errors(panel):
    """Literal saved-reference comparison, not a new syntax/semantic validator."""
    result=[]
    for row in panel['source_fidelity']['rows']:
        if row['counts']['ordered_exact']:continue
        expected=row['expected_ir']['rules']
        generated=row['generated_ir']['rules'] if row['counts']['parsed_documents']==1 else []
        slots=[]
        for slot in range(max(len(expected),len(generated))):
            reference=expected[slot] if slot<len(expected) else None
            observed=generated[slot] if slot<len(generated) else None
            if reference==observed:continue
            if type(reference) is dict and type(observed) is dict:
                differences={field:dict(expected_present=field in reference,generated_present=field in observed,
                    expected=reference.get(field),generated=observed.get(field)) for field in sorted(set(reference)|set(observed))
                    if reference.get(field)!=observed.get(field) or (field in reference)!=(field in observed)}
            else:differences=None
            slots.append(dict(zero_based_slot=slot,differing_fields=differences,
                expected_rule_missing=reference is None,generated_rule_missing=observed is None,
                generated_rule_is_dictionary=type(observed) is dict))
        result.append(dict(id=row['id'],source_sha256=row['source_provenance']['source_sha256'],
            expected_rule_count=len(expected),parsed_generated_rule_count=len(generated),
            original_fidelity_counts=row['counts'],literal_positional_differences=slots,
            scope='saved parsed fields; original fidelity and qualification remain separate'))
    return result

def build_document(data):
    runs=data['runs']
    lines=['This twelve-fit development comparison changes the learning rate of the existing shared actor/modality/object source head from the base rate to ten times that rate. The private action head, recurrent decoder, loss coefficients, source curriculum, encoder context and output limit retain their existing settings. Both arms start from the original fresh initializer. The candidate also uses proportional plateau floors and zero scheduler reduction epsilon to preserve its group ratio; larger learning rates increase AdamW decoupled shrinkage per step. This is not a pure gradient-scale-only intervention.', '',
        'Every figure below describes the private final attempt unless explicitly marked selected. The validation set has been repeatedly exposed during development; it is not a fresh holdout. Six baseline reports, saved tensor states and all nine controls are compared exactly against their predecessor, excluding only four declared timing or time-derived receipt paths.', '',
        '| Width | Seed | Validation exact baseline / LR10, of 48 | Training exact baseline / LR10, of 48 | Validation reference CE | Fit seconds |',
        '|---:|---:|---|---|---|---|']
    for d in (8,384,768):
        for seed in (1729,2718):
            arms=[runs[f'{d}-{name}-{seed}'] for name in NAMES]
            panels=[arm['controls']['last-attempt']['validation'] for arm in arms]
            lines.append('| '+' | '.join([str(d),str(seed),' / '.join(str(p['exact']) for p in panels),
                ' / '.join(str(a['controls']['last-attempt']['training']['exact']) for a in arms),
                ' / '.join(f"{p['token_ce']:.6f}" for p in panels),
                ' / '.join(f"{a['fit_seconds']:.3f}" for a in arms)])+' |')
    lines+=['', '| Width | Seed | Arm | Validation exact at lengths 1/2/4/8 | EOS / syntax | Duplicates | Extra / missing rules | Generated actor/action/modality/object, of 180 |',
        '|---:|---:|---|---|---|---:|---|---|']
    for d in (8,384,768):
        for seed in (1729,2718):
            for name in NAMES:
                arm=runs[f'{d}-{name}-{seed}'];panel=arm['controls']['last-attempt']['validation']
                lengths='/'.join(str(panel['by_length'][str(n)]['exact']) for n in (1,2,4,8))
                fields='/'.join(str(panel['generated_scalar_by_field'][f]['correct']) for f in FIELDS)
                lines.append(f"| {d} | {seed} | {name} | {lengths} | {panel['eos']} / {panel['syntax_valid']} | {panel['duplicates']} | {panel['extra']} / {panel['missing']} | {fields} |")
    lines+=['', '| Width | Seed | Arm | Panel | Raw actor/action/modality/object correct, of 180 | Raw object full-vocabulary CE | Raw object mean target margin |',
        '|---:|---:|---|---|---|---:|---:|']
    for d in (8,384,768):
        for seed in (1729,2718):
            for name in NAMES:
                for split in ('training','validation'):
                    raw=runs[f'{d}-{name}-{seed}']['controls']['last-attempt'][split]['raw_scalar_arithmetic']
                    fields='/'.join(str(raw[f]['correct']) for f in FIELDS)
                    lines.append(f"| {d} | {seed} | {name} | {split} | {fields} | {raw['object']['full_vocabulary_ce']:.6f} | {raw['object']['mean_target_margin']:.6f} |")
    lines+=['', 'Raw source-head outputs are diagnostics over reference-present slots. Generated scalar matches use the existing saved fidelity scorer, including missing or invalid output. Neither score is formal-logic semantic validation.', '',
        '| Width | Seed | Arm | Selected epoch | Selected validation exact / syntax, of 48 | Selected extra / missing rules | Final selection rejection conditions |',
        '|---:|---:|---|---:|---|---|---|']
    for d in (8,384,768):
        for seed in (1729,2718):
            for name in NAMES:
                arm=runs[f'{d}-{name}-{seed}'];reasons=sorted({r.split('/',1)[1] if '/' in r else r for r in arm['last_rejection_reasons']})
                selected=arm['controls']['selected']['validation']
                lines.append(f"| {d} | {seed} | {name} | {arm['selected_epoch']} | {selected['exact']} / {selected['syntax_valid']} | {selected['extra']} / {selected['missing']} | {'; '.join(reasons) or 'none'} |")
    lines+=['', '| Width | Seed | Arm | Initial → final group LR | Committed rate reductions | Clipped updates / 340 | Peak preclip norm | Boundary labels | Collection / loss-helper seconds |',
        '|---:|---:|---|---|---:|---|---:|---:|---|']
    for d in (8,384,768):
        for seed in (1729,2718):
            for name in NAMES:
                arm=runs[f'{d}-{name}-{seed}'];o=arm['optimizer'];b=arm['boundary_training']
                rates=', '.join(f"{k}: {v:g} → {o['final_rates'][k]:g}" for k,v in o['initial_rates'].items())
                g=o['gradient_norms']
                lines.append(f"| {d} | {seed} | {name} | {rates} | {len(o['committed_rate_changes'])} | {g['norm_exceeded_limit_steps']} / 340 | {g['max_preclip_norm']:.4f} | {b['selected_sites']} | {b['collection_seconds']:.3f} / {b['loss_helper_seconds']:.3f} |")
    lines+=['', 'The common global clipping operation covers both parameter groups in the original parameter order. Clipping statistics therefore describe the combined gradient, not an independently clipped head. First/last boundary supervision runs every committed update in both arms. It uses the unchanged contextual bulk replay and full-vocabulary CE; no generated-field auxiliary or strict causal retry is enabled in this comparison. Changed model predictions can change generated lengths and selected boundary labels even though the loss policy remains fixed.', '',
        '| Width | Seed | Arm | Fit seconds | Repeated training rows/second | Numerical seconds/48 | Numerical seconds/span | Full panel seconds/span |',
        '|---:|---:|---|---:|---:|---:|---:|---:|']
    for d in (8,384,768):
        for seed in (1729,2718):
            for name in NAMES:
                arm=runs[f'{d}-{name}-{seed}'];p=arm['controls']['last-attempt']['validation']
                lines.append(f"| {d} | {seed} | {name} | {arm['fit_seconds']:.3f} | {arm['training_rows_presented_per_fit_second']:.2f} | {p['numerical_seconds_per48']:.6f} | {p['numerical_seconds_per_span']:.6f} | {p['whole_panel_seconds_per_span']:.6f} |")
    lines+=['', f"Runner wall time: {data['comparison_elapsed_seconds']:.3f}s; summed training calls: {data['total_fit_seconds']:.3f}s. Each fit retains 340 optimizer updates, 2,440 ordinary decoder/count row presentations, 225,840 target-token presentations and 25,600 scalar labels. This fixes ordinary training exposure, not elapsed time or generated auxiliary work. It does not prove fastest convergence.", '',
        'All nine inference controls and both selected/final roles remain in outcomes.json: conditioned validation, training, zero condition, source shuffle, cross-length shuffle, context-only shuffle, context reverse, context rotate and recurrent residual off. Recurrent residual off preserves raw scalar readouts; its changed predictions are reported separately.', '',
        'One CPU worker; bridge names []; prover evaluation false; metric disk cache disabled; 48 samples per evaluation. Source representations and contexts are authenticated cached inputs. No encoder execution, weights download, cold parser timing or bridge-on evaluate occurred; legal-IR target count is unmeasured. Evaluation wall time includes numerical reference CE and source-only generation; full panels add control construction and fidelity/readout scoring. Potential residual observations and serialization remain separate. Shorter generations alone do not establish faster correct conversion.', '',
        'No native-family or Lake qualification was performed by these numerical fits. The unchanged production gates do not grant admission from CE, readout accuracy, syntax or saved rows. No production checkpoint is promoted, no historical 8D teacher is changed, and no formalized, roundtrip_ok, fresh-holdout or global-minimum claim follows. Identity projection MSE is not learned reconstruction. The Constitution remains unformalized.']
    if data['resource_receipt_reconciled_after_guardian_failure']:
        lines += ['', 'The numerical child completed all twelve fits and exited 0, but its guardian exited 1 during scheduler-lease cleanup after a concurrent scheduler configuration change. That failure is retained. Read-only locked reconciliation found the disk reservation already released and the owned scheduler lease absent, verified exited owners and exact stored attempt accounting, and wrote an explicit recovered finalization receipt. No model rerun or shared-state mutation occurred. The configuration at the moment of failure and the actor responsible for the scheduler change/release are unknown; this is reconciled accounting, not a clean guardian success.']
    return '\n'.join(lines)+'\n'


def main():
    guardian=read(R/'guardian-exit.json');require(guardian['returncode'] in (0,1),'unexpected guardian status')
    child=read(R/'training-r1/child-exit.json');require(child['leader_reaped'] and child['returncode']==0,'successful reaped child required')
    resources=read(R/'training-r1/resources-final.json');require(resources['status']=='released'
        and resources['record']['artifacts_durable_asserted'] and not resources['record']['attempt_exceeded_reservation'],
        'successful resource finalization required')
    reconciliation=None
    if guardian['returncode']==0:
        require(not resources.get('recovered_after_guardian_failure',False),'clean guardian has recovery claim')
    else:
        require(resources.get('recovered_after_guardian_failure') is True and resources['guardian_returncode']==1,
            'failed guardian requires explicit accounting reconciliation')
        ref=resources['reconciliation_receipt'];reconciliation=read(ref['path'],ref['sha256'])
        require(reconciliation['schema']=='completed-resource-receipt-reconciliation/v1'
            and reconciliation['complete'] and reconciliation['guardian_returncode']==1
            and reconciliation['training_child_returncode']==0 and not reconciliation['guardian_success_claimed'],
            'reconciliation lost actual process statuses')
        for key in ('attempt_inode_verified','child_group_dead','owner_exited','scheduler_lease_absent',
            'scheduler_config_now_matches_adopted'):
            require(reconciliation[key] is True,'incomplete resource reconciliation: '+key)
        for key in ('model_rerun','shared_state_mutated','foreign_claims_modified','scheduler_release_performed','scheduler_reset_performed'):
            require(reconciliation[key] is False,'unexpected reconciliation mutation or model rerun: '+key)
        require(reconciliation['release_record']==resources['record']
            and reconciliation['observed_completed_attempt_bytes']==resources['record']['final_attempt_bytes']
            and resources['record']['final_total_charged_bytes']<=resources['record']['storage_bytes']
            and reconciliation['scheduler_lease_id']==resources['resource_lease']['lease_id'],
            'reconciled release accounting or owner differs')
        log=R/'guardian.log';blob=log.read_bytes();actual=hashlib.sha256(blob).hexdigest()
        require(actual==reconciliation['original_guardian_log_sha256']
            and b'ResourceConfigurationError' in blob and b'self._lease.release()' in blob,
            'original guardian cleanup error provenance differs')
        ARTIFACTS[str(log.resolve())]=dict(sha256=actual,bytes=len(blob))
        script=R/'reconcile_completed_resources.py';blob=script.read_bytes();actual=hashlib.sha256(blob).hexdigest()
        require(actual==reconciliation['script_sha256'],'reconciliation producer differs')
        ARTIFACTS[str(script.resolve())]=dict(sha256=actual,bytes=len(blob))
    summary=read(T/'summary.json');require(summary['schema']=='source-head-learning-rate-comparison/v1'
        and summary['complete'] and len(summary['runs'])==12,'twelve complete fits required')
    for key,expected in [('workers',1),('bridge_names',[]),('legal_ir_evaluate_provers',False),('metric_disk_cache_used',False),
        ('encoder_executed',False),('downloads_performed',False)]:require(summary[key]==expected,'measurement scope differs: '+key)
    require(summary['all_six_original_first_last_baselines_replayed'],'six baseline replays required')
    manifest=read(R/'training-manifest.json');plan=read(R/'training-plan.json',manifest['plan_sha256'])
    require(plan['fit_count']==12 and plan['baseline_equivalence_exclusions']==TIMING_EXCLUSIONS
        and plan['input_sha256']==manifest['inputs'],'fixed comparison plan differs')
    require(plan['non_action_learning_rate_multiplier_baseline']==1.
        and plan['non_action_learning_rate_multiplier_candidate']==10.
        and plan['generated_field_supervision_enabled'] is False,'planned head-only intervention differs')
    runs={};reports={}
    for entry in summary['runs']:
        arm=read(entry['summary_path'],entry['summary_sha256']);name=arm['arm'];recipe=arm['recipe']
        require(name==entry['arm'] and arm['budget_completed'] and name not in runs,'arm identity/completion differs')
        require(recipe in plan['arms'] and name==f"{arm['dimension']}-{recipe['name']}-{arm['seed']}", 'unplanned arm')
        report=read(arm['training_ref']['path'],arm['training_ref']['sha256'])
        require(report['stopped_reason']=='epochs_completed' and not any(report.get(k,False) for k in FALSE),
            'training completion/authority differs')
        require(report['action_contrastive_weight']==.05 and report['source_value_weight']==report['cardinality_weight']==.25
            and report['generated_boundary_weight']==.05 and recipe['generated_field_weight']==0.,'common losses differ')
        prior_name=f"{arm['dimension']}-boundary-first-last-{arm['seed']}";prior_path=manifest['baseline_summaries'][prior_name]
        old=read(prior_path,manifest['inputs'][prior_path]);initial=initial_parity(arm,report,old)
        parity=check_baseline(arm,report,old) if recipe['name']==NAMES[0] else None
        if parity is None:require(arm['baseline_replay'] is None,'candidate claimed baseline replay')
        optimizer=optimizer_summary(arm,report,initial);boundary=boundary_summary(report,recipe)
        panels={};predictions={};heads={}
        require(set(arm['postfit'])=={'selected','last-attempt'},'selected/final export roles differ')
        for role,controls in arm['postfit'].items():
            require(set(controls)==CONTROL_NAMES,'all nine controls required')
            panels[role]={};predictions[role]={};heads[role]={}
            for label,ref in controls.items():
                value=read(ref['path'],ref['sha256']);panels[role][label]=panel_summary(value)
                if role=='last-attempt' and label in ('training','validation'):
                    panels[role][label]['remaining_reconstruction_errors']=remaining_errors(value)
                predictions[role][label]={row['id']:row['token_ids'] for row in value['predictions']}
                heads[role][label]=value['source_values']['predictions']
                if label=='recurrent-residual-off':
                    require(value['execution']['recurrent_residual_disabled'] and not value['execution']['training_performed']
                        and not value['execution']['selection_performed'],'residual control authority differs')
                    capture=value['recurrent_residual_diagnostic'];require(capture['residual_disabled']
                        and all(x==0 for row in capture['rows'] for slot in row['potential_residuals'] for x in slot),
                        'disabled residual is not zero')
        off={}
        for role in panels:
            a,b=predictions[role]['validation'],predictions[role]['recurrent-residual-off']
            require(set(a)==set(b) and heads[role]['validation']==heads[role]['recurrent-residual-off'],
                'residual control changed cohort or source readout')
            off[role]=dict(changed_predictions=sum(a[k]!=b[k] for k in a),scalar_readout_unchanged=True,
                inference_only=True,conditioned=panels[role]['validation'],disabled=panels[role]['recurrent-residual-off'])
        observations=[h for h in report['history'] if h['numerical'] is not None]
        require(observations,'complete validation observations required')
        runs[name]=dict(dimension=arm['dimension'],seed=arm['seed'],recipe=recipe,
            selected_epoch=report['selected_epoch'],last_complete_attempt_is_selected=report['last_complete_attempt_is_selected'],
            accepted_validations=sum(bool(item['accepted']) for item in observations),validation_attempts=len(observations),
            last_rejection_reasons=observations[-1]['rejection_reasons'],
            all_rejection_reasons=dict(Counter(reason for item in observations for reason in item['rejection_reasons'])),
            fit_seconds=arm['training_call_elapsed_seconds'],arm_seconds=arm['elapsed_seconds'],
            training_rows_presented=2440,training_rows_presented_per_fit_second=2440/arm['training_call_elapsed_seconds'],
            row_rate_scope='repeated decoder-row presentations divided by whole training-call wall time including validation',
            trainable_parameters=arm['trainable_parameter_count'],baseline_replay=parity,
            initial_tensor_sha256=report['initial_weights_sha256'],selected_tensor_sha256=report['selected_weights_sha256'],
            last_attempt_tensor_sha256=report['last_complete_attempt_weights_sha256'],
            tensor_work_estimate_bytes=report['tensor_work_estimate_bytes'],max_tensor_work_bytes=report['config']['max_memory_bytes'],
            optimizer=optimizer,boundary_training=boundary,controls=panels,residual_off_effect=off,**FALSE)
        reports[name]=dict(initial_weights_sha256=report['initial_weights_sha256'],
            config=report['config'],curriculum=report['curriculum'],
            stage_reports=[{k:v for k,v in stage.items() if k.startswith('count_') or k in ('name','training_rows',
                'completed_epochs','optimizer_step_start','optimizer_step_end','status')} for stage in report['stage_reports']],
            training_rows_sha256=report['training_rows_sha256'],training_references_sha256=report['training_references_sha256'],
            validation_rows_sha256=report['validation_rows_sha256'],validation_references_sha256=report['validation_references_sha256'],
            source_contexts_sha256=report['source_contexts_sha256'],codec_sha256=report['codec_sha256'],
            committed_updates=[{k:u[k] for k in ('optimizer_step','epoch','stage','decoder_row_ids','count_row_ids',
                'target_token_presentations','source_value_presentations')} for u in report['committed_updates']])
    expected={f'{d}-{name}-{seed}' for d in (8,384,768) for seed in (1729,2718) for name in NAMES}
    require(set(runs)==expected,'full factorial identity differs')
    comparisons=[]
    metrics=('exact','eos','syntax_valid','duplicates','missing','extra','raw_action','generated_action',
        'raw_actor_action','generated_actor_action','count_correct','token_ce')
    for d in (8,384,768):
        for seed in (1729,2718):
            a,b=[runs[f'{d}-{name}-{seed}'] for name in NAMES]
            require(reports[f'{d}-{NAMES[0]}-{seed}']==reports[f'{d}-{NAMES[1]}-{seed}'],
                'matched initialization, ordinary curriculum or committed exposure differs')
            deltas={}
            for role in ('selected','last-attempt'):
                deltas[role]={}
                for control in CONTROL_NAMES:
                    left,right=a['controls'][role][control],b['controls'][role][control]
                    deltas[role][control]=dict(metrics={k:right[k]-left[k] for k in metrics},
                        raw_fields={f:{k:right['raw_scalar_arithmetic'][f][k]-left['raw_scalar_arithmetic'][f][k]
                            for k in ('correct','full_vocabulary_ce','mean_target_margin')} for f in FIELDS},
                        generated_fields={f:right['generated_scalar_by_field'][f]['correct']-left['generated_scalar_by_field'][f]['correct'] for f in FIELDS})
            comparisons.append(dict(dimension=d,seed=seed,candidate_minus_baseline=deltas,
                baseline_fit_seconds=a['fit_seconds'],candidate_fit_seconds=b['fit_seconds'],
                fit_time_ratio=b['fit_seconds']/a['fit_seconds'],ordinary_curriculum_exposure_equal=True,
                auxiliary_rollout_exposure_equal_claimed=False))
    aggregates={}
    for name in NAMES:
        aggregates[name]={}
        for role in ('selected','last-attempt'):
            aggregates[name][role]={}
            for split in ('validation','training'):
                subset=[arm['controls'][role][split] for arm in runs.values() if arm['recipe']['name']==name]
                aggregates[name][role][split]={key:sum(p[key] for p in subset) for key in ('rows','exact','eos','syntax_valid',
                    'duplicates','missing','extra','raw_action','generated_action','raw_actor_action','generated_actor_action')}
    data=dict(schema='source-head-learning-rate-outcomes/v1',complete=True,passed=True,findings=[],
        created_at=datetime.now(timezone.utc).isoformat(),scope='saved report/tensor/logit arithmetic only; no model forward or optimizer replay',
        comparisons=comparisons,runs=runs,aggregates=aggregates,comparison_elapsed_seconds=summary['elapsed_seconds'],
        total_fit_seconds=sum(a['fit_seconds'] for a in runs.values()),guardian_exit=guardian,child_exit=child,
        resource_finalization_status=resources['status'],guardian_succeeded=guardian['returncode']==0,
        resource_receipt_reconciled_after_guardian_failure=reconciliation is not None,
        resource_reconciliation=reconciliation,all_six_baselines_exact=True,
        measurement=dict(bridge_names=[],legal_ir_evaluate_provers=False,metric_disk_cache_used=False,worker_count=1,device='CPU',
            evaluation_sample_count=48,legal_ir_target_count_measured=False,bridge_on_evaluate_measured=False,
            source_inputs_cached=True,encoder_executed=False,downloads_performed=False,cold_parser_timing=False,
            host_isolation='shared host; no isolated throughput or fastest convergence claim',
            source_representations='8D linguistic feature hash; 384D/768D authenticated cached inputs; not a dimension-only ablation'),
        historical_8d_teacher_unchanged=True,context_tokens=512,decoder_output_tokens=512,temperature=0,
        artifacts=ARTIFACTS,**FALSE)
    for path,record in ARTIFACTS.items():require(hashlib.sha256(Path(path).read_bytes()).hexdigest()==record['sha256'],
        'input changed before final write')
    require(not any(name.startswith(('torch','ipfs_datasets_py')) for name in sys.modules),'analyzer imported model/runtime')
    require(not (R/'outcomes.json').exists() and not (R/'proposed-outcomes-doc.txt').exists(),'analysis output exists')
    doc=build_document(data);data['checks']=CHECKS
    (R/'outcomes.json').write_text(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+'\n')
    (R/'proposed-outcomes-doc.txt').write_text(doc)
    print(json.dumps(dict(complete=True,runs=len(runs),panels=216,checks=CHECKS,
        final_validation_exact={name:aggregates[name]['last-attempt']['validation']['exact'] for name in NAMES},
        final_training_exact={name:aggregates[name]['last-attempt']['training']['exact'] for name in NAMES},
        selected_epochs={key:arm['selected_epoch'] for key,arm in runs.items()})))


if __name__=='__main__':main()
