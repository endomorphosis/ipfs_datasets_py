"""Read-only final publication, checkpoint and local Git-state verification."""
from pathlib import Path
import hashlib,json,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent;W=P.parent.parent
read=lambda p:json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def local(root):
 index=Path(git(root,'rev-parse','--path-format=absolute','--git-path','index'))
 return dict(head=git(root,'rev-parse','HEAD'),index_sha256=sha(index))
before=read(R/'before.json');published=read(R/'publication.json');results={}
for label,root,key in [('package',P,'package_commit'),('workspace',W,'workspace_commit')]:
 commit=published[key];remote=git(root,'ls-remote','--heads','origin','main').split()[0]
 assert remote==commit,(label,remote,commit)
 assert local(root)==before[label],('shared_local_git_state_changed',label)
 results[label]=dict(commit=commit,remote_verified=remote,local_state=local(root),local_preserved=True)
cp=before['checkpoint'];assert sha(cp['path'])==cp['sha256'] and Path(cp['path']).stat().st_size==cp['bytes']
resource=read(R/'training-r1/resources-final.json');assert resource['status']==resource['record']['status']=='released'
results.update(checkpoint_unchanged=cp,resource_status=resource['status'],qualified=False,admitted=False,
 lake_executed=False,checkpoint_promoted=False,complete=True)
(R/'final-verification.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
print(json.dumps(results))
