"""Combine unchanged saved numerical audit with explicit read-only cleanup evidence.

No models, optimizers, schedulers, shared ledgers or lease clients are imported.
The numerical audit remains immutable and explicitly excludes cleanup authority.
"""
from pathlib import Path
from copy import deepcopy
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path(__file__).resolve().parent;P=R.parents[2];T=R/'training-r1'
checks=0;findings=[];artifacts={}
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for b in iter(lambda:stream.read(1048576),b''):h.update(b)
 return h.hexdigest()
def check(value,label):
 global checks
 checks+=1
 if not value:findings.append(dict(label=label))
def pin(path,expected=None):
 path=Path(path).resolve();value=dict(sha256=sha(path),bytes=path.stat().st_size)
 if expected is not None:check(value==expected,'artifact/'+str(path))
 artifacts[str(path)]=value;return path
def read(path):return json.loads(pin(path).read_bytes())
def main():
 global checks
 numeric=read(R/'independent-numerical-audit.json')
 check(sha(R/'independent-numerical-audit.json')=='5c61cd73b5b12f3d3eae35f7cc2f4d6928aab35992a2bc33b4d2288b0f4afb92','numerical/exact_completed_receipt')
 check(numeric['passed'] and numeric['finding_count']==0 and numeric['phase']=='numerical_results_only'
  and numeric['resource_cleanup_verified'] is False and numeric['overall_readiness_for_publication'] is False,'numerical/explicit_prior_scope')
 for path,expected in numeric['artifacts'].items():pin(path,expected)
 checks+=numeric['checks']
 guardian=read(R/'guardian-exit.json');child=read(T/'child-exit.json');start=read(T/'resources-start.json')
 final=read(T/'resources-final.json');recovery=read(R/'resource-reconciliation.json');adopt=read(R/'training-r1-scheduler-adoption.json')
 identity=read(T/'child-identity.json');pin(R/'reconcile_completed_resources.py');pin(R/'resource-reconciliation.log');log=pin(R/'guardian.log').read_text()
 for name in ('independent_audit.py','independent_audit_r2.py','independent_numerical_audit.py','readiness.json','audit-revision.json'):pin(R/name)
 check(guardian['returncode']==1 and child['returncode']==0 and child['leader_reaped'] is True,'recovery/actual_failed_guardian_successful_child')
 check('ResourceConfigurationError' in log and 'self._lease.release()' in log and sha(R/'guardian.log')==recovery['original_guardian_log_sha256'],
  'recovery/authenticated_cleanup_failure')
 old=P/'workspace/test-logs/decoder-boundary-reconstruction-20261003/reconcile_completed_resources.py'
 public=P/'docs/implementation/reports/evidence/decoder-boundary-reconstruction-20261003/manifest.json';published=read(public)
 blob=subprocess.check_output(['git','show',read(R/'base.json')['base']+':'+str(public.relative_to(P))],cwd=P)
 check(hashlib.sha256(blob).hexdigest()==sha(public),'recovery/predecessor_exact_published_manifest')
 member=published['original_artifact_archive_paths'][str(old)];pin(old,published['members'][member])
 check(old.read_text().replace('training-r1-guardian.log','guardian.log')==(R/'reconcile_completed_resources.py').read_text(),
  'recovery/exact_previously_reviewed_script_except_two_log_basenames')
 check(sha(R/'reconcile_completed_resources.py')==recovery['script_sha256'],'recovery/script_binding')
 check(recovery['schema']=='completed-resource-receipt-reconciliation/v1' and recovery['complete'] is True,'recovery/complete_known_receipt')
 for name in ('owner_exited','child_group_dead','attempt_inode_verified','scheduler_lease_absent','resources_final_receipt_bytes_excluded_from_prior_inventory',
  'failure_time_scheduler_configuration_not_captured','configuration_change_actor_unknown','scheduler_release_actor_unknown'):
  check(recovery[name] is True,'recovery/'+name)
 for name in ('shared_state_mutated','foreign_claims_modified','model_rerun','guardian_success_claimed','scheduler_release_performed','scheduler_reset_performed'):
  check(recovery[name] is False,'recovery/'+name)
 check(recovery['guardian_returncode']==1 and recovery['training_child_returncode']==0
  and recovery['release_record_source']=='existing locked disk ledger; never synthesized or rewritten','recovery/actual_status_and_existing_ledger_source')
 check(recovery['original_scheduler_config_sha256']==adopt['shared_config_sha256']
  and recovery['scheduler_config_now_matches_adopted']==(recovery['observed_scheduler_config']==adopt['shared_config']),
  'recovery/observed_configuration_matches_saved_adoption_without_failure_time_inference')
 record=final['record'];lease=final['resource_lease']
 check(final['recovered_after_guardian_failure'] is True and final['guardian_returncode']==1 and final['cleanup_error'] is not None
  and final['reconciliation_receipt']==dict(path=str(R/'resource-reconciliation.json'),sha256=sha(R/'resource-reconciliation.json')),
  'recovery/final_receipt_retains_failure_and_exact_reconciliation')
 check(record==recovery['release_record'] and final['status']==record['status']=='released'
  and record['artifacts_durable_asserted'] is True and record['attempt_exceeded_reservation'] is False,'recovery/exact_existing_durable_release_record')
 for name in ('reservation_id','owner_pid','attempt_directory','child','cpu_slots','memory_mb','child_process_slots','storage_bytes','created_at'):
  check(record[name]==start['record'][name],'recovery/unchanged_owned_identity/'+name)
 check(record['child']==identity and record['cpu_slots']==1 and record['memory_mb']==4096 and record['storage_bytes']==3000000000
  and record['final_accounting']['limit_bytes']==140000000000 and record['final_external_charged_bytes']==0,
  'recovery/exact_registered_limits_and_no_external_charges')
 check(lease['lease_id']==recovery['scheduler_lease_id']==start['resource_lease']['lease_id'] and lease['released'] is True
  and lease['release_performed_by_reconciliation'] is False and lease['release_actor_unknown'] is True,'recovery/only_owned_absent_lease_observation')
 meta=T.stat();check(record['attempt_directory']==dict(device=meta.st_dev,inode=meta.st_ino,path=str(T)), 'recovery/actual_attempt_directory_identity')
 files=[p for p in T.rglob('*') if p.is_file()];check(not any(p.is_symlink() for p in files),'recovery/attempt_regular_file_inventory')
 actual=sum(p.stat().st_size for p in files)-(T/'resources-final.json').stat().st_size
 check(actual==recovery['observed_completed_attempt_bytes']==record['final_attempt_bytes']==record['final_total_charged_bytes']
  and actual<record['storage_bytes'],'recovery/exact_attempt_bytes_excluding_new_final_receipt')
 observations=[]
 for receipt in (start,final):
  if receipt['record'].get('last_usage'):observations.append(receipt['record']['last_usage'])
 observed=T/'resource-observations.json'
 if observed.exists():observations.extend(read(observed))
 rss=[x['group_rss']['rss_bytes'] for x in observations if x.get('group_rss',{}).get('available')]
 analysis=deepcopy(numeric['analysis']);analysis.update(resources=final,resource_reconciliation=recovery,
  resource_cleanup_verified=True,overall_readiness_for_publication=not findings,
  guardian_succeeded=False,resource_receipt_reconciled_after_guardian_failure=True,
  continuous_scheduler_lease_coverage_proven=False,continuous_memory_enforcement=False,peak_rss_measured=False,
  maximum_observed_rss=max(rss) if rss else None,resource_observation_count=len(observations),
  scheduler_evidence_scope='Initial admission and polled usage; owned lease absent after exit. Failure-time configuration and actor unknown; continuous lease coverage not proven.',
  numerical_audit=dict(path=str(R/'independent-numerical-audit.json'),sha256=sha(R/'independent-numerical-audit.json'),checks=numeric['checks']),
  limits=['Saved numerical arithmetic and authenticated read-only recovery receipts; no native model or optimizer replay.',
   'Guardian failed after child completion; recovery observes released accounting and absent owned lease, not clean guardian success.',
   'Previously exposed development cohort; no fresh holdout, global convergence, Lake admission or production promotion.'])
 pin(__file__)
 result=dict(numeric,schema='source-head-learning-rate-independent-audit/v1',phase='results_with_reconciled_resource_failure',
  passed=not findings,complete=not findings,checks=checks,finding_count=len(findings),findings=findings,artifacts=artifacts,analysis=analysis,
  resource_cleanup_verified=True,overall_readiness_for_publication=not findings,guardian_succeeded=False,
  continuous_scheduler_lease_coverage_proven=False,source_path=str(Path(__file__).resolve()),source_sha256=sha(__file__),
  created_at_utc=datetime.now(timezone.utc).isoformat())
 output=R/'independent-audit.json'
 with output.open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
 print(json.dumps(dict(passed=not findings,checks=checks,findings=findings,output=str(output))))
 if findings:raise SystemExit(1)
if __name__=='__main__':main()
