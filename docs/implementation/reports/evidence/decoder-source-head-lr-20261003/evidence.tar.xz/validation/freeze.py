"""Freeze source-head learning-rate study with authenticated unchanged predecessor inputs."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
B=P/'workspace/test-logs/decoder-generated-field-training-r2-20261003'
BASE=json.loads((R/'base.json').read_bytes())['base']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):
 path=R/name;assert not path.exists(),path;path.write_text(json.dumps(obj,indent=2)+'\n')
def mod(path):
 spec=importlib.util.spec_from_file_location('_context_boundary_freeze_'+path.stem,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
if __name__=='__main__':
 assert not (R/'experiment-source').exists()
 auto='ipfs_datasets_py/logic/formalization/autoencoder/'
 changes=[auto+n+'.py' for n in ('long_span_source_value_training','source_field_readout_probe')]
 changes+=['scripts/ops/autoencoder/benchmark_source_head_learning_rate.py','scripts/ops/autoencoder/benchmark_source_field_readout_probe.py']
 changes+=['tests/unit/logic/formalization/autoencoder/test_'+n+'.py' for n in ('source_head_learning_rate','source_head_learning_rate_runner','source_field_readout_probe','source_field_readout_probe_runner')]
 additions={rel:sha(P/rel) for rel in changes}
 pins=json.loads((B/'frozen-extensions.json').read_bytes());tests=json.loads((B/'validated-test-source.json').read_bytes());helpers=json.loads((B/'test-helper-sources.json').read_bytes())
 for rel,digest in {**pins,**tests,**helpers}.items():
  assert sha(B/'experiment-source'/rel)==digest,rel
  assert hashlib.sha256(subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)).hexdigest()==digest,rel
 runtime='ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_embedding_runtime.py'
 runtime_blob=subprocess.check_output(['git','show',BASE+':'+runtime],cwd=P)
 pins[runtime]=hashlib.sha256(runtime_blob).hexdigest()
 for rel,digest in additions.items():(tests if rel.startswith('tests/') else pins)[rel]=digest
 for rel,digest in {**pins,**tests,**helpers}.items():
  source=P/rel if rel in additions else B/'experiment-source'/rel
  target=R/'experiment-source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(runtime_blob) if rel==runtime else shutil.copyfile(source,target);assert sha(target)==digest
 save('frozen-extensions.json',pins);save('validated-test-source.json',tests);save('test-helper-sources.json',helpers)
 save('test-files.json',list(tests));save('code-files.json',changes+['docs/autoencoders/decoder_length_distillation.md'])
 clause=json.loads((B/'clause-parent-manifest.json').read_bytes());clause['extensions']=pins
 cplan=json.loads((B/'clause-parent-plan.json').read_bytes());save('clause-parent-plan.json',cplan)
 clause['plan_sha256']=sha(R/'clause-parent-plan.json');save('clause-parent-manifest.json',clause)
 native=json.loads((B/'native-parent-manifest.json').read_bytes());native['extensions']=pins
 for key,name in [('parent_manifest','clause-parent-manifest.json'),('parent_plan','clause-parent-plan.json')]:
  path=R/name;native[key]=str(path);native['inputs'][str(path)]=sha(path)
 nplan=json.loads((B/'native-parent-plan.json').read_bytes());nplan['input_sha256']=native['inputs'];save('native-parent-plan.json',nplan)
 native['plan_sha256']=sha(R/'native-parent-plan.json');save('native-parent-manifest.json',native)
 manifest=dict(native);manifest['inputs']=dict(native['inputs'])
 for key,path in [('parent_manifest',R/'native-parent-manifest.json'),('parent_plan',R/'native-parent-plan.json'),('original_boundary_manifest',B/'training-manifest.json')]:
  manifest[key]=str(path);manifest['inputs'][str(path)]=sha(path)
 manifest['baseline_summaries']={}
 for d in (8,384,768):
  for seed in (1729,2718):
   name=f'{d}-boundary-first-last-{seed}';path=B/'training-r1/results'/name/'summary.json';manifest['baseline_summaries'][name]=str(path);manifest['inputs'][str(path)]=sha(path)
   prior=json.loads(path.read_bytes());refs=[prior['training_ref']]+[ref for panels in prior['postfit'].values() for ref in panels.values()]
   for ref in refs:
    assert sha(ref['path'])==ref['sha256'];manifest['inputs'][ref['path']]=ref['sha256']
 probe=P/'workspace/test-logs/decoder-object-readout-20261003'
 evidence=json.loads((probe/'independent-audit.json').read_bytes());assert evidence['passed'] and not evidence['findings']
 for path,record in evidence['artifacts'].items():
  assert sha(path)==record['sha256'];manifest['inputs'][path]=record['sha256']
 for name in ['independent-audit.json','outcomes.json','probe-r1/results/summary.json']:
  path=probe/name;manifest['inputs'][str(path)]=sha(path)
 manifest['training_head_probe_summary']=str(probe/'probe-r1/results/summary.json')
 manifest['training_head_probe_audit']=str(probe/'independent-audit.json')
 for path,digest in manifest['inputs'].items():assert sha(path)==digest,path
 runner=mod(R/'experiment-source/scripts/ops/autoencoder/benchmark_source_head_learning_rate.py')
 save('training-plan.json',dict(runner.FIXED,input_sha256=manifest['inputs']))
 manifest['plan_sha256']=sha(R/'training-plan.json');save('training-manifest.json',manifest)
 (R/'adopt_shared_scheduler.py').write_bytes((B/'adopt_shared_scheduler.py').read_bytes())
 (R/'run_frozen_tests.py').write_bytes((B/'run_frozen_tests.py').read_bytes())
 guard=(B/'run_training_reserved.py').read_text().replace('benchmark_generated_field_training.py','benchmark_source_head_learning_rate.py').replace('storage_bytes=4_000_000_000','storage_bytes=3_000_000_000').replace('> 4500:', '> 3300:')
 (R/'run_training_reserved.py').write_text(guard)
 (R/'run_guardian.py').write_bytes((B/'run_guardian.py').read_bytes())
 print(json.dumps(dict(extensions=len(pins),test_files=len(tests),inputs=len(manifest['inputs']))))
