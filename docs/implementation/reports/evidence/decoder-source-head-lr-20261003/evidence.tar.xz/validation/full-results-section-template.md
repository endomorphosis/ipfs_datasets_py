<!-- LOCAL TEMPLATE ONLY. Do not publish placeholders or apply before all twelve
fits, resource finalization or verified read-only reconciliation, analyzer, and
independent results audit pass. Preserve guardian failure when applicable.
The immutable probe/API draft is D/draft-source-head-training.md. Replace its
"Full-decoder comparison: results pending" section only after final review. -->

## Full-decoder comparison, 2026-10-03

{{OUTCOME_LEAD: describe measured improvement/regression by width, distinguish
the private final attempt from selected checkpoints; derive from all six pairs.}}

This is a twelve-fit comparison on the same exposed Legal development cohort:
48 training and 48 validation paragraphs, widths 8/384/768, two seeds, and the
existing baseline versus the optional non-action head rate multiplier of 10.
The same 48 validation paragraphs recur across widths and seeds. Aggregates of
288 scored rows per recipe are repeated observations, not 288 fresh holdouts.
The 8D inputs remain nonsemantic linguistic-feature hashes; 384D and 768D retain
their authenticated cached semantic inputs. No encoder is trained in this run.

Both recipes use the original initializer, base rate 0.001, batch size 8, count
and source-value weights 0.25, action-contrastive weight 0.05, and first/last
generated-boundary weight 0.05. Scalar-field generated-prefix training stays
disabled. The context and output limits stay 512, temperature stays zero, and
the ordinary global clipping and per-length selection gates are unchanged.
The candidate's scheduler has proportional floors and reduction epsilon zero;
its higher AdamW rate also increases per-step decoupled weight decay. This is
not an isolated change to gradient magnitude.

All twelve fits completed 340 updates, 2,440 decoder/count row presentations,
225,840 target-token presentations, and 25,600 source-field labels. Six baseline
arms replayed their predecessor's saved tensors, numerical reports, and nine
control panels, excluding only the four declared timing/time-derived paths.
Generated boundary work can differ as model predictions change; equal ordinary
training exposure does not imply equal compute.

{{FULL_ANALYZER_TABLES: use the sealed proposed-outcomes-doc.txt with exact
per-width/per-seed training and validation results, raw per-field full-vocabulary
CE/margins, generated scalar/rule metrics, selected-state outcomes/rejections,
rates/clipping/boundary work, timing scopes, and source controls.}}

### Why better endpoints can remain unselected

{{SELECTION_EXPLANATION: derive selected epochs, selected validation counts,
last rejection reasons, and residual content errors from saved reports. If an
endpoint is47/48, explain the actual unmatched rule substitution from that panel.
Never infer selection from final CE or raw field accuracy.}}

`whole_rules_extra` and `whole_rules_missing` are content-matching measures:
an incorrect substitution can increment both even when every paragraph has the
correct number of generated rules. Syntax success and correct lengths do not
prove faithful reconstruction. The unchanged selector checks source fidelity
and reconstruction nonregression in addition to progress; raw source-head
accuracy alone does not select a checkpoint.

### Training-only 8D readout-to-generation diagnosis

The separately retained seed-1729 training panel has 180 clause occurrences.
At the final attempt, raw object correctness changes from 93/180 to 112/180;
generated object correctness changes from 94/180 to 112/180. In the candidate,
raw and generated object outputs agree in 176/180 positions. They are both
wrong in 66 positions; only two raw-correct object predictions become wrong
after generation, while two raw-wrong ones become correct. The raw object
readout therefore remains a substantial limitation on this training panel.
This is a positional diagnostic for one training seed, not a causal proof about
all decoder errors or a validation score.

The combined decoder's 340 updates supply 6,400 source-clause presentations,
compared with 61,200 in the standalone full-batch head probe. The standalone
probe has 9.5625 times as much source-clause exposure at the same update number.
The combined decoder also has a length
curriculum, other objectives, and global clipping. For this pair, 113 baseline
updates and 89 candidate updates were clipped; no standalone probe updates were
clipped. These differences prevent an equal-work or isolated-clipping causal
comparison with the standalone probe. The empirical gap suggests testing source
head exposure and optimizer interactions next while retaining full decoder
and validation measurements.

Source: [the training readout transfer receipt](../../workspace/test-logs/decoder-source-head-lr-20261003/training-readout-transfer-8d-1729.json).

### Evidence and operational limits

{{TEST_AND_AUDIT: retain the earlier72/166/2708 distinct scopes, exact final
independent results check count, original guardian1 and child0 exits and
read-only-reconciled released resource status;
preserve revised-audit and environment-failure receipts.}}

The training child exited zero after saving all twelve fit results. The guardian
exited one when scheduler lease release reported `ResourceConfigurationError`
after the durable-results and disk-release steps. The original failure and exit
receipts remain evidence. A later read-only reconciliation verified the released
disk reservation, exact attempt directory identity, dead owner and child group,
and an absent scheduler lease. It did not reset the scheduler, release a lease,
modify other claims, rerun a model, or rewrite the original exit. The failure-time
scheduler configuration and the actors responsible for its change or subsequent
lease removal were not captured. This is not a successful guardian exit.
The initial reservation, recorded periodic resource checks, and read-only end
reconciliation do not prove continuous scheduler-lease coverage throughout the
run. The responsible configuration-changing actor is unknown.

{{RESOURCE_SCOPE: derive final retained bytes and recorded maximum RSS from
actual resource receipts. Describe sample count, any periodic logs, reservation,
and peak-measurement limits; do not equate reservation with measured peak.}}

All twelve initial, selected, and final-attempt states and all 216 control panels
remain evidence. No production checkpoint is promoted. These measurements do
not prove global convergence or fastest convergence, and the validation cohort
is not a fresh holdout. Frozen identity-projection MSE is not learned source
reconstruction. No bridge-on evaluate, cold parser timing, or native logic-family
qualification is established by the numerical benchmark.

Lake `lake build <Lib>` remains the only Lean admission. The historical 8D
linguistic teacher is unchanged. The Constitution is not formalized and must not
be marked `roundtrip_ok`.

Final sources: [outcomes](../../workspace/test-logs/decoder-source-head-lr-20261003/outcomes.json),
[independent audit](../../workspace/test-logs/decoder-source-head-lr-20261003/independent-audit.json),
and the hash-bound raw reports and source/control panels referenced there.
