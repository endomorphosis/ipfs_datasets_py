"""Saved training panels only: initial completed 8D/1729 matched pair.

This is an observation of the predeclared comparison, not a new recipe or a
claim about incomplete validation results. No model or numerical forward runs.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,math
R=Path(__file__).resolve().parent
FIELDS=('actor','action','modality','object')
artifacts={}
def read(p):
 p=Path(p).resolve();b=p.read_bytes();artifacts[str(p)]=dict(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));return json.loads(b)
def main():
 runs={}
 for arm in ('boundary-first-last','source-head-lr10'):
  folder=R/'training-r1/results'/('8-'+arm+'-1729');summary=read(folder/'summary.json')
  ref=summary['postfit']['last-attempt']['training'];panel=read(ref['path']);assert artifacts[str(Path(ref['path']).resolve())]['sha256']==ref['sha256']
  report=read(summary['training_ref']['path']);assert artifacts[str(Path(summary['training_ref']['path']).resolve())]['sha256']==summary['training_ref']['sha256']
  state=read(summary['states']['initial']['path']);assert artifacts[str(Path(summary['states']['initial']['path']).resolve())]['sha256']==summary['states']['initial']['sha256']
  vocab=state['codec']['target_vocabulary'];heads={r['id']:r for r in panel['source_values']['predictions']}
  records=[];totals={f:Counter() for f in FIELDS};raw_rule_count=raw_paragraph_count=0
  ces={f:[] for f in FIELDS}
  for row in panel['source_fidelity']['rows']:
   assert row['id'].startswith('authored-paragraph:train:')
   head=heads[row['id']];expected=row['expected_ir']['rules'];generated=row['generated_ir']['rules'] if row['counts']['parsed_documents']==1 else []
   raw_all=[];row_fields={f:Counter() for f in FIELDS}
   for slot,reference in enumerate(expected):
    generated_rule=generated[slot] if slot<len(generated) and type(generated[slot]) is dict else {}
    targets=head['expected_token_ids'][slot];guesses=head['predicted_token_ids'][slot];vectors=head['raw_logits'][slot]
    raw_all.append(all(a==b for a,b in zip(targets,guesses)))
    for field,target,guess,vector in zip(FIELDS,targets,guesses,vectors):
     assert json.loads(vocab[target])==reference[field] and len(vector)==32
     peak=max(vector);ces[field].append(peak+math.log(math.fsum(math.exp(x-peak) for x in vector))-vector[target])
     raw_correct=target==guess;generated_correct=generated_rule.get(field)==reference[field]
     raw_value=json.loads(vocab[guess]) if vocab[guess].startswith('"') else vocab[guess]
     key=('raw_correct' if raw_correct else 'raw_wrong')+('_generated_correct' if generated_correct else '_generated_wrong')
     row_fields[field][key]+=1;totals[field][key]+=1
     totals[field]['raw_generated_equal']+=raw_value==generated_rule.get(field)
   raw_rule_count+=sum(raw_all);raw_paragraph_count+=all(raw_all)
   records.append(dict(id=row['id'],clauses=len(expected),raw_all_field_correct_rules=sum(raw_all),
    raw_all_field_correct_paragraph=all(raw_all),generated_exact=row['counts']['ordered_exact'],
    generated_rules=len(generated),fields={f:dict(v) for f,v in row_fields.items()}))
  for field in FIELDS:
   count=totals[field]
   assert count['raw_correct_generated_correct']+count['raw_correct_generated_wrong']==panel['source_values']['by_field'][field]['correct']
   assert count['raw_correct_generated_correct']+count['raw_wrong_generated_correct']==panel['source_fidelity']['by_facet'][field]['correct']
  runs[arm]=dict(training_rows=48,training_clauses=180,raw_fields={f:v['correct'] for f,v in panel['source_values']['by_field'].items()},
   generated_fields={f:panel['source_fidelity']['by_facet'][f]['correct'] for f in FIELDS},
   raw_full32v_ce={f:math.fsum(v)/len(v) for f,v in ces.items()},
   contingency={f:dict(v) for f,v in totals.items()},raw_all_field_correct_rules=raw_rule_count,
   raw_all_field_correct_paragraphs=raw_paragraph_count,generated_exact_paragraphs=panel['source_fidelity']['metrics']['ordered_exact'],
   generated_rule_metrics=panel['source_fidelity']['metrics'],gradient_norms=report['gradient_norms'],
   source_scalar_label_presentations=report['source_value_presentations'],source_clause_presentations=report['source_value_presentations']//4,
   rows=records)
 data=dict(schema='partial-training-readout-transfer/v1',scope='completed 8D/1729 training panels only; no study outcome or recipe selection',
  runs=runs,artifacts=artifacts,validation_access=False,model_executed=False,decoder_executed=False,qualified=False,admitted=False,
  observations=['The raw object readout itself remains imperfect; compare contingency with generated object accuracy before attributing all loss to decoding.',
   'Standalone readout probes used 61,200 clause presentations at 340 updates versus 6,400 source-value clause presentations here. The combined decoder also has other objectives, a length curriculum and global gradient clipping.',
   'These are 180 training clause occurrences; exact paragraph reconstruction compounds errors across all fields and clauses. No independence assumption is made.'])
 out=R/'training-readout-transfer-8d-1729.json';assert not out.exists();out.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:{f:v[f] for f in ('raw_fields','generated_fields','raw_all_field_correct_rules','raw_all_field_correct_paragraphs','generated_exact_paragraphs','contingency')} for k,v in runs.items()}))
if __name__=='__main__':main()
