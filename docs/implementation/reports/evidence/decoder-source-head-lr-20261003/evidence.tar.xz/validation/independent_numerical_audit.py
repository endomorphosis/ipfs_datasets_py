"""Independent saved-data audit of source-head learning-rate adaptation.

No model, encoder, optimizer or prover runs here. Prior scalar/count/readout and
selection arithmetic is authenticated against published evidence. Exact group
ownership, proportional scheduler rates and unchanged baseline outcomes are checked.
"""


from pathlib import Path


from collections import Counter


from copy import deepcopy


from datetime import datetime, timezone


import argparse, ast, hashlib, importlib.util, json, math, subprocess, sys


import xml.etree.ElementTree as ET


sys.dont_write_bytecode=True


R=Path(__file__).resolve().parent;P=R.parents[2]


B=P/'workspace/test-logs/decoder-context-boundary-training-20261003'


PRIOR=P/'workspace/test-logs/decoder-generated-field-training-r2-20261003'
PROBE=P/'workspace/test-logs/decoder-object-readout-20261003'
LATEST_PUBLIC=P/'docs/implementation/reports/evidence/decoder-generated-field-training-r2-20261003'


PUBLIC=P/'docs/implementation/reports/evidence/decoder-context-boundary-training-20261003'


AUTO='ipfs_datasets_py/logic/formalization/autoencoder/'


checks=0;findings=[];artifacts={}


def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()


def digest(value):return hashlib.sha256(raw(value)).hexdigest()


def sha(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):result.update(block)
    return result.hexdigest()


def check(value,label,detail=None):
    global checks
    checks+=1
    if not value:findings.append(dict(label=label,detail=detail))


def pin(path,wanted=None):
    path=Path(path).resolve();entry=dict(sha256=sha(path),bytes=path.stat().st_size)
    if wanted is not None:check(entry['sha256']==wanted,'pin/'+str(path))
    artifacts[str(path)]=entry;return path


def read(path):return json.loads(pin(path).read_bytes())


def load_arithmetic():
    manifest=read(PUBLIC/'manifest.json');results=read(PUBLIC/'results.json');base=read(R/'base.json')['base']
    for name in ('manifest.json','results.json'):
        path=PUBLIC/name;blob=subprocess.check_output(['git','show',base+':'+str(path.relative_to(P))],cwd=P)
        check(hashlib.sha256(blob).hexdigest()==sha(path),'prior/exact_published_metadata/'+name)
    previous=read(B/'independent-audit.json')
    check(sha(B/'independent-audit.json')==results['independent_audit_sha256'] and previous['passed']
        and previous['finding_count']==0,'prior/authenticated_ordered_audit')
    check(results['guardian_succeeded'] is True and results['resource_receipt_reconciled_after_guardian_failure'] is False,
        'prior/published_clean_guardian')
    overrides=manifest['publication_producer_overrides'];runtime='ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_embedding_runtime.py'
    expected=dict(historical_sha256='27855f5ffd59ebc45444d5e37c18ff1569618084cd27b1503db112940051ffb0',
        publication_sha256='ce80ed6294009e04580051e6eb06a817d74a8a56f04814ad0a698e3d27dd0d41')
    check(set(overrides)=={runtime} and all(overrides[runtime][key]==value for key,value in expected.items())
        and overrides[runtime]['training_runtime_override'] is False,'prior/explicit_only_publication_runtime_override')
    published=subprocess.check_output(['git','show',base+':'+runtime],cwd=P)
    check(hashlib.sha256(published).hexdigest()==expected['publication_sha256'],'prior/current_base_preserves_published_runtime')
    compatibility=read(B/'runtime-compatibility-review.json')
    check(compatibility['passed'] and compatibility['test_count']==2430 and compatibility['producer_overrides']==overrides
        and compatibility['historical_training_used_override'] is False,'prior/runtime_compatibility_separate_from_training')
    previous_summary=read(B/'training-r1/results/summary.json')
    check(not any(runtime in name for name in previous_summary['source_dependencies']),'prior/training_runtime_not_loaded')
    for name,entry in read(R/'context-audit-helper-pins.json').items():
        pin(R/name,entry['sha256']);member=manifest['original_artifact_archive_paths'][entry['source_path']]
        check(manifest['members'][member]=={k:entry[k] for k in ('sha256','bytes')},'prior/published_arithmetic/'+name)
    spec=importlib.util.spec_from_file_location('_authenticated_context_arithmetic',R/'context_audit_arithmetic.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    check(not module.findings and not module.action.findings,'prior/helper_self_authentication_clean')
    for owner in (module,module.ordered,module.action,module.native,module.clause,module.prior,module.leaf):
        owner.check=check;owner.read=read
        if hasattr(owner,'pin'):owner.pin=pin
    return module,manifest,previous


context,old_public,old_audit=load_arithmetic()


ordered=context.ordered


action=context.action;native=ordered.native;clause=ordered.clause;prior=ordered.prior;leaf=ordered.leaf


close=prior.close;CONTROLS=action.CONTROLS+[('recurrent-residual-off','validation','conditioned')]


def latest_provenance():
    base=read(R/'base.json')['base'];manifest=read(LATEST_PUBLIC/'manifest.json');published=read(LATEST_PUBLIC/'results.json')
    for name in ('manifest.json','results.json'):
        path=LATEST_PUBLIC/name;blob=subprocess.check_output(['git','show',base+':'+str(path.relative_to(P))],cwd=P)
        check(hashlib.sha256(blob).hexdigest()==sha(path),'prior_r2/exact_published_metadata/'+name)
    audit=read(PRIOR/'independent-audit.json')
    check(sha(PRIOR/'independent-audit.json')==published['independent_audit_sha256'] and audit['passed']
        and audit['finding_count']==0,'prior_r2/published_successful_independent_audit')
    return manifest,audit

latest_public,latest_audit=latest_provenance()

def inherited(path):
    path=Path(path).resolve();expected=None
    for proof,manifest in ((latest_audit,latest_public),(old_audit,old_public)):
        expected=proof['artifacts'].get(str(path))
        if expected is None:
            member=manifest['original_artifact_archive_paths'].get(str(path))
            expected=manifest['members'][member] if member else manifest.get('referenced_artifacts',{}).get(str(path))
        if expected is not None:break
    check(expected is not None,'prior/known_artifact/'+str(path));value=read(path)
    check(expected is not None and artifacts[str(path)]==expected,'prior/exact_artifact/'+str(path))
    return value


def source_guards(source):
    old=PRIOR/'experiment-source';old_manifest=inherited(PRIOR/'training-manifest.json')
    for rel in old_manifest['extensions']:
        if rel==AUTO+'long_span_source_value_training.py':continue
        check(pin(source/rel).read_bytes()==pin(old/rel).read_bytes(),'source/unchanged_inherited_owner/'+rel)
    before=(old/AUTO/'long_span_source_value_training.py').read_text();after=(source/AUTO/'long_span_source_value_training.py').read_text()
    oldnodes={n.name:n for n in ast.parse(before).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    nodes={n.name:n for n in ast.parse(after).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    check(set(nodes)-set(oldnodes)=={'_non_action_optimizer_groups','_group_learning_rates'},'source/only_two_group_helpers_added')
    for name,node in oldnodes.items():
        if name!='train':check(ast.dump(node)==ast.dump(nodes[name]),'source/unchanged_function/'+name)
    def section(text,start,end):return text.split(start,1)[1].split(end,1)[0]
    for label,start,end in [('selection','            observed, accepted, reasons =','            history.append'),
        ('backward_clip_deadline','                objective.backward()','                optimizer.step()')]:
        check(section(before,start,end)==section(after,start,end),'source/identical_'+label)
    oldtrain=oldnodes['train'];newtrain=nodes['train']
    original=[n for n in oldtrain.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('optimizer','scheduler') for t in n.targets)]
    branch=next(n for n in newtrain.body if isinstance(n,ast.If) and ast.unparse(n.test)=='separate_head_rate')
    check([ast.dump(n) for n in original]==[ast.dump(n) for n in branch.orelse], 'source/exact_default_optimizer_scheduler_branch')
    helper=ast.get_source_segment(after,nodes['_non_action_optimizer_groups'])
    check('original_ids == [id(parameter) for _, parameter in named]' in helper and 'optimizer groups must be disjoint and exhaustive' in helper
        and 'exact four non-action head tensors required' in helper,'source/group_membership_and_original_order_guards')
    check('min_lr=[item["minimum_learning_rate"] for item in group_inventory], eps=0.' in after,
        'source/proportional_scheduler_floor_and_zero_epsilon')
    check('core._require(not separate_head_rate or options["learning_rate"]*options["min_learning_rate_ratio"] > 0.' in after,
        'source/enabled_only_representable_positive_scheduler_floor')
    for name in ('action_contrastive_decoder_training','ordered_clause_recurrent_decoder_experiment',
        'decoder_distillation_experiment','decoder_source_fidelity','long_span_count_exposure_training','contextual_generated_boundary_training'):
        check(sha(source/AUTO/(name+'.py'))==sha(old/AUTO/(name+'.py')),'source/unchanged_gates_models_losses/'+name)


def probe_rationale(manifest):
    path=PROBE/'independent-audit.json';pin(path,'25e9c632366a242fae89af668f7b3f9dfe987cb6751aa9443748f13efa1dfe97');proof=read(path)
    check(proof['passed'] and proof['finding_count']==0 and proof['analysis']['fit_count']==8
        and proof['analysis']['checkpoint_count']==56 and proof['validation_rows_evaluated'] is False
        and proof['qualified'] is False and proof['admitted'] is False and proof['lake_executed'] is False,
        'rationale/training_only_head_probe_without_qualification')
    for name in ('training-manifest.json','training-plan.json','training-object-inputs.json','probe-training-8d.json',
        'probe-initial-head-8d-1729.json','probe-initial-head-8d-2718.json','probe-adapter-receipt.json','training-object-geometry.json',
        'independent_probe_audit.py','independent_probe_audit_r2.py','readiness.json','probe-r1/results/summary.json'):
        item=PROBE/name;expected=proof['artifacts'].get(str(item))
        check(expected is not None,'rationale/audited_artifact/'+name)
        if expected is not None:pin(item,expected['sha256'])
    check(str(path) in manifest['inputs'] and manifest['inputs'][str(path)]==sha(path),'rationale/probe_audit_sealed_before_comparison')
    return dict(probe_audit_sha256=sha(path),fit_count=8,checkpoints=56,training_rows_only=True,
        fresh_holdout=False,full_decoder_training=False,qualification=False,
        intervention='tenfold_non_action_head_learning_rate_and_corresponding_AdamW_per_step_decay',
        limitations=['Head probes do not establish formula fidelity or held-out improvement.',
                    'The matched full decoder study retains the existing selection and semantic gates.'])


HEAD_NAMES=['non_action_head.'+name for name in ('source_projection.weight','source_projection.bias','field_readout.weight','field_readout.bias')]

def optimizer_groups(run,ctx):
    report=run['training'];label=run['arm'];multiplier=run['recipe']['non_action_learning_rate_multiplier'];config=report['config']
    updates=report['committed_updates'];history=report['history'];stages=report['stage_reports']
    enabled=multiplier!=1.
    if not enabled:
        check('non_action_learning_rate_multiplier' not in report and not any(key.startswith('optimizer_group') for key in report)
            and 'optimizer_parameter_groups' not in report and all('optimizer_group_learning_rates' not in item for item in updates+history)
            and all(not any(k.startswith('optimizer_group') for k in item) for item in stages),'optimizer/default_has_no_intervention_metadata/'+label)
        return dict(non_action_learning_rate_multiplier=1.,baseline_default_branch=True)
    policies=dict(non_action_learning_rate_multiplier=10.,optimizer_scheduler_epsilon=0.,
        optimizer_group_learning_rate_policy='fixed_non_action_multiplier; proportional_plateau_minima; epsilon_zero',
        optimizer_global_clip_parameter_order='original_model_trainable_order',
        optimizer_weight_decay_policy='same_coefficient_in_both_groups; per_step_shrinkage_is_learning_rate_times_weight_decay',
        optimizer_group_learning_rates_scope='committed_updates_are_pre_scheduler; epoch_history_is_post_scheduler',
        non_action_learning_rate_used_for_selection=False)
    for key,value in policies.items():check(report.get(key)==value,'optimizer/policy/'+label+'/'+key)
    initial=inherited(PRIOR/'training-r1/results'/(str(run['dimension'])+'-boundary-first-last-'+str(run['seed']))/'initial-state.json')
    tensors=initial['model_state'];trainable=set(ctx['prior']['shared-'+str(run['seed'])]['training']['stage_reports'][-1]['optimizer_state_end']['parameter_steps'])
    groups=report['optimizer_parameter_groups'];check([g['name'] for g in groups]==['base','non_action_head'],'optimizer/group_order/'+label)
    check(groups[1]['parameter_names']==HEAD_NAMES and set(groups[0]['parameter_names'])==trainable-set(HEAD_NAMES)
        and len(groups[0]['parameter_names'])==len(trainable)-4,'optimizer/exact_disjoint_exhaustive_tensor_membership/'+label)
    rates={};floors={};decay={};allnames=[]
    for group,factor in zip(groups,(1.,10.)):
        name=group['name'];allnames+=group['parameter_names'];rates[name]=config['learning_rate']*factor;floors[name]=rates[name]*config['min_learning_rate_ratio'];decay[name]=1.
        count=sum(math.prod(leaf.shape(tensors[key])) for key in group['parameter_names'])
        check(group['parameter_count']==count and group['learning_rate_multiplier']==factor
            and group['initial_learning_rate']==rates[name] and group['minimum_learning_rate']==floors[name]
            and group['weight_decay']==config['weight_decay']==.01,'optimizer/group_exact_numel_rates_floor_decay/'+label+'/'+name)
    check(len(allnames)==len(set(allnames))==len(trainable) and set(allnames)==trainable,'optimizer/no_duplicate_or_missing_parameters/'+label)
    check(groups[1]['parameter_count']==64*(run['dimension']+1)+96*65,'optimizer/architecture_derived_head_numel/'+label)
    best=math.inf;bad=0;cursor=0;reductions=[];stage_starts={};stage_ends={}
    for epoch in history:
        stage_starts.setdefault(epoch['stage'],dict(rates))
        while cursor<len(updates) and updates[cursor]['epoch']==epoch['epoch']:
            item=updates[cursor]
            check(item['optimizer_group_learning_rates']==rates and item['learning_rate']==rates['base'],
                'optimizer/committed_pre_scheduler_rates/'+label+'/'+str(cursor+1))
            for name in rates:decay[name]*=1-rates[name]*config['weight_decay']
            cursor+=1
        metric=epoch['numerical']
        if metric is not None:
            metric=metric['token_cross_entropy']
            if metric<best*(1-1e-4):best=metric;bad=0
            else:bad+=1
            if bad>config['plateau_patience']:
                for name in rates:
                    old=rates[name];rates[name]=max(old*config['plateau_factor'],floors[name])
                    if rates[name]!=old:reductions.append(dict(epoch=epoch['epoch'],group=name,before=old,after=rates[name],difference=old-rates[name]))
                bad=0
        check(epoch['optimizer_group_learning_rates']==rates and epoch['learning_rate']==rates['base'],
            'optimizer/epoch_post_scheduler_rates/'+label+'/'+str(epoch['epoch']))
        check(close(rates['non_action_head'],10*rates['base']) and all(rates[n]>=floors[n] for n in rates),
            'optimizer/fixed_ratio_and_floors/'+label+'/'+str(epoch['epoch']))
        stage_ends[epoch['stage']]=dict(rates)
    check(cursor==len(updates)==340,'optimizer/all_committed_updates_accounted/'+label)
    for stage in stages:
        check(stage['optimizer_group_learning_rates_start']==stage_starts[stage['name']]
            and stage['optimizer_group_learning_rates_end']==stage_ends[stage['name']], 'optimizer/stage_rates_continuous/'+label+'/'+stage['name'])
        check(set(stage['optimizer_state_end']['parameter_steps'])==trainable and all(value==stage['optimizer_step_end']
            for value in stage['optimizer_state_end']['parameter_steps'].values()), 'optimizer/every_parameter_same_committed_step/'+label+'/'+stage['name'])
    check(all(group['final_learning_rate']==rates[group['name']] for group in groups),'optimizer/final_group_rates/'+label)
    check(all(event['difference']>1e-8 for event in reductions),'optimizer/default_epsilon_difference_inactive_at_registered_rates/'+label)
    return dict(non_action_learning_rate_multiplier=10.,trainable_tensors=len(trainable),non_action_tensors=4,
        proportional_plateau_reductions=reductions,final_rates=rates,decay_only_multiplicative_factors=decay,
        decay_scope='Product of registered per-update AdamW shrinkage factors; gradients also change weights.',
        scheduler_replayed_from_saved_validation_ce=True,full_optimizer_trajectory_replayed=False)


def training(run,ctx):
    report=run['training'];label=run['arm']
    check(run['recipe']['generated_field_weight']==0. and not any(key.startswith('generated_field') or key.startswith('generated_site') for key in report)
        and all('generated_sites' not in update for update in report['committed_updates']),'training/no_generated_field_loss/'+label)
    detail=context.training(run,ctx);detail['optimizer_groups']=optimizer_groups(run,ctx)
    return detail


def common(args):
    manifest=read(args.manifest);plan=read(args.plan)
    check(sha(args.plan)==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'],'pins/plan_inputs')
    for path,wanted in manifest['inputs'].items():pin(path,wanted)
    for rel,wanted in manifest['extensions'].items():pin(args.source/rel,wanted)
    for rel,wanted in read(R/'validated-test-source.json').items():pin(args.source/rel,wanted)
    diagnosis=probe_rationale(manifest)
    source_guards(args.source)
    fixed=dict(dimensions=[8,384,768],seed_order=[1729,2718],fit_count=12,original_training_rows=48,
        exposed_validation_rows=48,fixed_encoder_context_tokens=512,fixed_decoder_output_limit=512,
        temperature=0,action_contrastive_temperature=.1,fresh_initialization=True,selection_unchanged=True,
        cardinality_weight=.25,source_value_weight=.25,expected_optimizer_steps_per_arm=340,
        expected_training_token_presentations_per_arm=225840,expected_row_presentations_per_arm=2440,
        expected_count_presentations_per_arm=2440,expected_source_value_presentations_per_arm=25600,
        full_vocabulary_retained=True,syntax_forced=False,closure_forced=False,generation_reference_count_access=False,
        production_promotion_allowed=False,no_downloads=True,encoder_executed_during_training=False)
    for key,value in fixed.items():check(plan.get(key)==value,'plan/'+key)
    expected_exclusions=['elapsed_seconds','committed_updates[*].generated_boundary.elapsed_seconds',
        'committed_updates[*].generated_boundary.generation.elapsed_seconds','committed_updates[*].generated_boundary.collection_sha256']
    check(plan['baseline_equivalence_exclusions']==expected_exclusions,'plan/exact_timing_and_derived_digest_exclusions')
    check([(arm['name'],arm['generated_field_weight'],arm['generated_site_interval']) for arm in plan['arms']]
        ==[('boundary-first-last',0.,1),('source-head-lr10',0.,1)]
        and all(a['generated_boundary_weight']==.05 and a['generated_boundary_site_policy']=='first_last' for a in plan['arms']),
        'plan/exact_registered_two_arms')
    check(plan['max_seconds_per_arm']==180 and plan['generated_boundary_gradient_scope']=='all_trainable'
        and plan['boundary_labels_after_source_only_rollout'] is True and plan['recurrent_parameter_delta']==0,
        'plan/exact_deadline_gradient_and_architecture_scope')
    check(plan['generated_field_labels_after_source_only_rollout'] is False and plan['joint_generated_prefix_replay'] is False
        and plan['generated_field_supervision_enabled'] is False,'plan/no_generated_field_supervision')
    check(plan['generated_replay_strategy']=='original_contextual_boundary_bulk_replay'
        and plan['generated_replay_retry_limit_per_original_batch']==0 and plan['generated_replay_atol']==plan['generated_replay_rtol']==2e-5,
        'plan/unchanged_boundary_bulk_replay_without_retry')
    check([arm['non_action_learning_rate_multiplier'] for arm in plan['arms']]==[1.,10.]
        and plan['non_action_fields']==['actor','modality','object'] and plan['architecture_changed'] is False
        and plan['head_lr_intervention_chosen_from_training_only_probes'] is True
        and plan['higher_lr_also_increases_AdamW_per_step_decay'] is True,'plan/exact_head_lr_intervention_and_decay_scope')
    check(len(plan['arms'])==2 and all(a['recurrent'] and a['action_contrastive_weight']==.05 and a['factorized']
        and a['head_kind']=='clauses' and not a['order_augmentation'] for a in plan['arms']), 'plan/matched_recurrent_models_and_losses')
    baseline={name:inherited(path) for name,path in manifest['baseline_summaries'].items()}
    for value in baseline.values():value['training']=inherited(value['training_ref']['path'])
    corpus=inherited(manifest['paragraphs']);prepared=inherited(manifest['dimension_inputs']);donor=inherited(manifest['donor'])
    originals={row['id']:row for split in ('train','validation') for row in corpus[split]};lookup={};lanes={}
    for split in ('train','validation'):
        lookup[split]={}
        for row in corpus[split]:
            parts=row['source_text'].split('\n\n');rules=row['target']['rules']
            check(len(parts)==len(rules)==row['clause_count'],'source/ordered_component_alignment/'+row['id'])
            for part,rule in zip(parts,rules):lookup[split][clause.textsha(part)]=dict(actor=rule['actor'],action=rule['action'],source_text=part)
    for dimension in (8,384,768):
        source=prepared['dimensions'][str(dimension)];contexts=source['source_contexts'];rows={};vectors={};unique={}
        for split in ('train','validation'):
            rows[split]=[dict(row,target_ids=originals[row['id']]['target_ids']) for row in source[split]]
            vectors.update({row['id']:row['input'] for row in rows[split]});unique[split]={}
            for row in rows[split]:
                for segment in contexts[split][row['id']]['segments']:unique[split].setdefault(segment['source_sha256'],segment)
        lanes[dimension]=dict(dimension=dimension,contexts=contexts,rows=rows,vectors=vectors,unique=unique)
    return dict(manifest=manifest,plan=plan,baseline=baseline,corpus=corpus,donor=donor,lanes=lanes,lookup=lookup,revision_diagnosis=diagnosis,
        original={r['id']:r for r in corpus['train']},prepared=originals,
        variants={r['id']:[r['id']] for r in corpus['train']})


FIELDS=('actor','action','modality','object')


ALIGNMENT='authenticated_source_segment_ordinal_to_training_reference_rule'


def baseline_replay(run,report,states,panels,old,label):
    def without_timing(value):
        value=deepcopy(value);value.pop('elapsed_seconds')
        for update in value['committed_updates']:
            receipt=update['generated_boundary'];receipt.pop('elapsed_seconds');receipt.pop('collection_sha256')
            receipt['generation'].pop('elapsed_seconds')
        return value
    check(without_timing(report)==without_timing(old['training']),
        'baseline/all_report_fields_except_explicit_elapsed_and_time_derived_collection_hash/'+label)
    for role,state in states.items():
        expected=inherited(PRIOR/'training-r1/results'/old['arm']/(role+'-state.json'))
        check(state['model_state']==expected['model_state'] and state['tensor_sha256']==expected['tensor_sha256'],'baseline/exact_all_tensors/'+label+'/'+role)
    for role in ('selected','last-attempt'):
        for name,_,_ in CONTROLS:
            expected=inherited(PRIOR/'training-r1/results'/old['arm']/role/('evaluation-'+name+'.json'))
            for key in ('predictions','source_fidelity','source_count','source_values','hypothetical_boundary_diagnostics'):
                check(panels[role][name][key]==expected[key],'baseline/exact_'+key+'/'+label+'/'+role+'/'+name)
            without_time=lambda value:{k:v for k,v in value.items() if k!='elapsed_seconds'}
            check(without_time(panels[role][name]['recurrent_residual_diagnostic'])==without_time(expected['recurrent_residual_diagnostic']),
                'baseline/exact_recurrent_readouts_except_elapsed/'+label+'/'+role+'/'+name)
    check(run['baseline_replay']['complete'] and not run['baseline_replay']['timing_equality_claimed'],'baseline/explicit_runner_receipt/'+label)
    check(run['baseline_replay']['excluded_fields']==['elapsed_seconds','committed_updates[*].generated_boundary.elapsed_seconds',
        'committed_updates[*].generated_boundary.generation.elapsed_seconds','committed_updates[*].generated_boundary.collection_sha256'],
        'baseline/explicit_narrow_equivalence_exclusions/'+label)


def results(args,ctx):
    root=args.results;summary=read(root/'summary.json');prior.authority(summary,'summary')
    names=[str(d)+'-'+a['name']+'-'+str(s) for d in (8,384,768) for s in (1729,2718) for a in ctx['plan']['arms']]
    check(summary['complete'] and [r['arm'] for r in summary['runs']]==names,'results/all_12_registered_fits')
    check(not summary['encoder_executed'] and not summary['downloads_performed'],'results/no_encoder_or_download')
    lanes={d:native.lane_preparation(root,ctx,d) for d in (8,384,768)};out={};cache=set()
    for pointer in summary['runs']:
        pin(pointer['summary_path'],pointer['summary_sha256']);run=read(pointer['summary_path']);label=run['arm'];lane=lanes[run['dimension']]
        old=ctx['baseline'][str(run['dimension'])+'-boundary-first-last-'+str(run['seed'])]
        pin(run['training_ref']['path'],run['training_ref']['sha256']);report=read(run['training_ref']['path']);run['training']=report
        lane['prior']={'shared-'+str(run['seed']):dict(training=old['training'])}
        detail=training(run,lane);original=inherited(PRIOR/'training-r1/results'/old['arm']/'initial-state.json');states={}
        for role in ('initial','selected','last-attempt'):
            states[role]=ordered.state_check(root/label/(role+'-state.json'),report,role,original,lane,True,label+'/'+role)
        check(run['trainable_parameter_count']==states['last-attempt']['_audited_trainable_count']==old['trainable_parameter_count'],
            'state/exact_unchanged_parameter_count/'+label)
        parity=read(root/label/'initial-parity.json')
        check(parity==run['initial_parity'] and parity['complete'] and parity['predictions']==old['initial_parity']['predictions'],
            'initial/all96_full_greedy_parity/'+label)
        panels={};metrics={}
        for role in ('selected','last-attempt'):
            panels[role]={};metrics[role]={}
            check(set(run['postfit'][role])=={n for n,_,_ in CONTROLS},'postfit/exact_controls/'+label+'/'+role)
            for name,split,kind in CONTROLS:
                entry=run['postfit'][role][name];pin(entry['path'],entry['sha256']);panel=read(entry['path']);panels[role][name]=panel
                check(entry['numerical']==panel['report'] and entry['fidelity']=={k:v for k,v in panel['source_fidelity'].items() if k!='rows'},
                    'postfit/compact_index_binding/'+label+'/'+role+'/'+name)
                viewed=panel
                if name=='recurrent-residual-off':
                    check(panel['execution']['kind']=='recurrent_residual_off' and panel['execution']['recurrent_residual_disabled'] is True,
                        'postfit/explicit_recurrent_ablation/'+label+'/'+role)
                    viewed=deepcopy(panel);viewed['execution']['kind']='conditioned'
                metrics[role][name]=clause.panel_check(viewed,split,kind,states[role],lane,label+'/'+role+'/'+name,cache)
                metrics[role][name]['recurrent_readouts']=ordered.recurrent_readouts(panel,states[role],lane,split,kind,
                    name=='recurrent-residual-off',label+'/'+role+'/'+name)
                if name=='validation':
                    target=report['selected'] if role=='selected' else report['last_complete_attempt']
                    check(panel['report']['metrics']==target['numerical'],'postfit/selection_binding/'+label+'/'+role)
        if run['recipe']['non_action_learning_rate_multiplier']==1.:baseline_replay(run,report,states,panels,old,label)
        else:check(run['baseline_replay'] is None,'baseline/no_candidate_replay_claim/'+label)
        out[label]=dict(training=detail,controls=metrics,selected_epoch=report['selected_epoch'],fit_elapsed_seconds=run['training_call_elapsed_seconds'])
    guardian=read(R/'guardian-exit.json');child=read(root.parent/'child-exit.json')
    check(guardian['returncode']==1 and child['returncode']==0 and child['leader_reaped'] is True,
        'resources/preserved_failed_guardian_and_completed_owned_child')
    pin(R/'guardian.log')
    return dict(runs=out,states=36,panels=216,distinct_fidelity_panels=len(cache),
        resource_cleanup_verified=False,overall_readiness_for_publication=False,
        guardian_exit=guardian['returncode'],owned_child_exit=child['returncode'],
        limits=['Saved-data numerical audit only; resource finalization failed and remains outside this receipt.',
        'Saved-data arithmetic, not full optimizer or recurrent execution replay.',
        'Previously exposed development cohort; no fresh holdout, global convergence, Lake admission or promotion.'])


def main():
    parser=argparse.ArgumentParser()
    for name in ('source','manifest','plan','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--results',type=Path);args=parser.parse_args()
    for key in vars(args):
        if getattr(args,key) is not None:setattr(args,key,getattr(args,key).resolve())
    for name in ('run_guardian.py','run_training_reserved.py','adopt_shared_scheduler.py','freeze.py','run_frozen_tests.py','before.json','base.json','test-files.json','test-helper-sources.json','frozen-extensions.json','validated-test-source.json'):
        pin(R/name)
    for name in ('independent_audit.py','readiness.json','audit-revision.json'):pin(R/name)
    ctx=common(args)
    suites=list(ET.parse(pin(R/'tests-scoped.xml')).iter('testsuite'))
    check(suites and all(int(s.get(k,0))==0 for s in suites for k in ('errors','failures','skipped')),'tests/scoped_suite_clean')
    provenance=read(R/'test-import-provenance-scoped.json')
    check(provenance['pytest_returncode']==0 and provenance['test_source_frozen'] is True,'tests/frozen_source_provenance')
    dependency=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
    for name,entry in provenance['modules'].items():
        path=pin(entry['path'],entry['sha256']);check(path.is_relative_to(args.source) or path.is_relative_to(dependency),'tests/no_live_or_HACC/'+name)
    check(all(Path(path).is_relative_to(dependency) for path in provenance['tree_pin'].values()),'tests/pinned_logic_tree')
    runtime='ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_embedding_runtime.py'
    module='ipfs_datasets_py.optimizers.logic_theorem_optimizer.autoencoder_embedding_runtime'
    expected_runtime=args.source/runtime;published=subprocess.check_output(['git','show',read(R/'base.json')['base']+':'+runtime],cwd=P)
    check(provenance['modules'][module]['path']==str(expected_runtime)
        and provenance['modules'][module]['sha256']==sha(expected_runtime)==hashlib.sha256(published).hexdigest(),
        'tests/exact_current_published_runtime_as_explicit_frozen_extension')
    analysis=results(args,ctx) if args.results else dict(dimensions=[8,384,768],inherited_source_inputs_authenticated=True)
    analysis['revision_diagnosis']=ctx['revision_diagnosis']
    analysis['tests']=dict(fresh_scoped_count=sum(int(s.get('tests',0)) for s in suites),historical_unused_fixture_exclusions=16)
    check('torch' not in sys.modules and 'transformers' not in sys.modules,'audit/no_model_imports');pin(__file__)
    value=dict(schema='source-head-learning-rate-independent-numerical-audit/v1',phase='numerical_results_only',
        passed=not findings,complete=not findings,checks=checks,finding_count=len(findings),findings=findings,artifacts=artifacts,
        source_path=str(Path(__file__).resolve()),source_sha256=sha(__file__),manifest_path=str(args.manifest),manifest_sha256=sha(args.manifest),
        plan_path=str(args.plan),plan_sha256=sha(args.plan),analysis=analysis,created_at_utc=datetime.now(timezone.utc).isoformat(),
        resource_cleanup_verified=False,overall_readiness_for_publication=False,
        models_executed=False,training_executed=False,encoder_executed=False,qualified=False,admitted=False,lake_executed=False,fresh_holdout=False)
    if not args.results:value['pre_execution']=not bool(list(R.glob('training-*/results')))
    args.output.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(passed=not findings,checks=checks,findings=findings,output=str(args.output))))
    if findings:raise SystemExit(1)


if __name__=='__main__':main()
