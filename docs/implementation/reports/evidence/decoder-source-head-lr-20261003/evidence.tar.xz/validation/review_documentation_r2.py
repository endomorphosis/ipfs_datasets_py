"""Saved-evidence review of the source-head guide and authorized index append."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import argparse,hashlib,json,re,subprocess
R=Path(__file__).resolve().parent;P=R.parents[2];D=P/'workspace/test-logs/decoder-object-readout-20261003'
checks=0;findings=[];artifacts={}
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for b in iter(lambda:stream.read(1048576),b''):h.update(b)
 return h.hexdigest()
def check(value,label):
 global checks
 checks+=1
 if not value:findings.append(dict(label=label))
def pin(path,expected=None):
 path=Path(path).resolve();item=dict(sha256=sha(path),bytes=path.stat().st_size)
 if expected is not None:check(item==expected,'artifact/'+str(path))
 artifacts[str(path)]=item;return path
def read(path):return json.loads(pin(path).read_bytes())
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--document-sha256',required=True);args=parser.parse_args()
 doc=P/'docs/autoencoders/source_head_training.md';guide=P/'docs/autoencoders/decoder_length_distillation.md'
 text=pin(doc).read_text();prose=' '.join(text.split());pin(guide)
 check(sha(doc)==args.document_sha256,'documentation/exact_final_review_target')
 base=read(R/'base.json')['base'];old=subprocess.check_output(['git','show',base+':'+str(guide.relative_to(P))],cwd=P).decode()
 append='\n### Source-head optimizer follow-up\n\nThe [source-head training guide](source_head_training.md) documents the training-only 8D object-readout diagnosis and the opt-in learning-rate comparison for 8D, 384D and 768D formula sidecars. It keeps the original fidelity selection gates, baseline replay and qualification boundaries.\n'
 check(guide.read_text()==old+append,'documentation/only_authorized_old_guide_append')
 audit=read(R/'independent-audit.json');outcome=read(R/'outcomes.json');probe=read(D/'independent-audit.json');probe_review=read(D/'probe-doc-review.json')
 check(audit['passed'] and audit['finding_count']==0 and audit['checks']==714113,'evidence/independent_results_audit_clean')
 check(outcome['passed'] and not outcome['findings'] and outcome['checks']==1356213,'evidence/outcomes_analysis_clean')
 check(probe['passed'] and probe['finding_count']==0 and probe['analysis']['checkpoint_count']==56,'evidence/probe_results_clean')
 for proof in (audit,outcome,probe):
  for path,expected in proof['artifacts'].items():pin(path,expected)
 check(probe_review['passed'] is True,'documentation/retained_initial_probe_review')
 for line in pin(R/'proposed-outcomes-doc.txt').read_text().splitlines():
  if line.startswith('|'):check(line in text,'documentation/exact_saved_outcomes_table/'+line[:75])
 probe_outcomes=read(D/'outcomes.json')
 for run in probe_outcomes['runs'].values():
  checkpoints={item['step']:item for item in run['checkpoints']};early=checkpoints[340]['fields']['object'];final=checkpoints[1000]['fields']['object']
  line=f"| {run['seed']} | {run['mode']} | {run['learning_rate']:g} | {early['correct']}/180 | {final['correct']}/180 | {early['full_vocabulary_ce']:.6f} | {final['full_vocabulary_ce']:.6f} | {run['call_seconds']:.3f} |"
  check(line in text,'documentation/exact_eight_probe_summary_rows/'+str(run['seed'])+'/'+run['mode']+'/'+str(run['learning_rate']))
 pin(R/'review_documentation.py');pin(R/'documentation-review-attempt1.json')
 for label,fragment in {
  'fixed_context':'Encoder context and decoder output limits remain 512',
  'development_not_holdout':'not 288 fresh holdouts',
  'changed_work':'equal ordinary exposure does not imply equal compute',
  'selected_partial':'only 19 generated rules, zero extra rules, and 161 missing rules',
  'final_unselected':'The unchanged selector rejects every final attempt',
  'lr_decay':'This is not a pure gradient-scale intervention',
  'clip_spikes':'7,146.0010 and 10,289.4531',
  'resource_failure':'not a clean end-to-end guardian success',
  'lease_scope':'do not prove continuous scheduler-lease coverage',
  'failure_unknown':'failure-time scheduler configuration and the actors responsible',
  'teacher_unchanged':'The historical 8D linguistic teacher is unchanged',
  'no_native_qualification':'No native logic-family or Lake qualification was performed',
  'no_constitution_claim':'The Constitution is not formalized',
  'no_resume_contract':'neither trainer exports an optimizer-resume contract',
  'no_speedup_claim':'not an equal-wall-time comparison, a reproducible speedup estimate',
  'identity_mse':'Frozen identity-projection MSE is not learned source reconstruction',
  'source_inputs':'Current 8D inputs remain nonsemantic linguistic-feature hashes',
  'unattended_gap':'verify the guarded lifecycle before claiming readiness for unattended long runs',
 }.items():check(fragment in prose,'documentation/scope/'+label)
 check('83 to 188 out of 288' in prose and '147 to 212 out of 288' in prose,'documentation/pooled_repeated_scores')
 check('2,708 tests in 54.66 seconds' in prose and '714,113 checks' in prose and '713,191 checks' in prose,'documentation/distinct_evidence_counts')
 check(str(audit['analysis']['resource_observation_count'])+' observations' in prose
  and format(audit['analysis']['maximum_observed_rss'],',')+' bytes' in prose,'documentation/sampled_rss_only')
 check('818,464,439 bytes' in prose and '3,000,000,000 storage bytes' in prose,'documentation/exact_accounting')
 # Independently recompute the one-seed training contingency added after the main audit.
 transfer=read(R/'training-readout-transfer-8d-1729.json');pin(R/'diagnose_training_readout_transfer.py')
 check(not transfer['validation_access'] and not transfer['model_executed'] and not transfer['decoder_executed'],'transfer/training_saved_data_only')
 fields=('actor','action','modality','object')
 for arm,saved in transfer['runs'].items():
  folder=R/'training-r1/results'/('8-'+arm+'-1729');panel=read(folder/'last-attempt/evaluation-training.json');state=read(folder/'initial-state.json');report=read(folder/'training.json')
  for path in (folder/'last-attempt/evaluation-training.json',folder/'initial-state.json',folder/'training.json'):
   check(artifacts[str(path)]==transfer['artifacts'][str(path)]==audit['artifacts'][str(path)],'transfer/authenticated_original_inputs/'+arm+'/'+path.name)
  vocab=state['codec']['target_vocabulary'];heads={r['id']:r for r in panel['source_values']['predictions']};counts={f:Counter() for f in fields}
  for row in panel['source_fidelity']['rows']:
   check(row['id'].startswith('authored-paragraph:train:'),'transfer/no_validation_row')
   expected=row['expected_ir']['rules'];generated=row['generated_ir']['rules'];head=heads[row['id']]
   for index,reference in enumerate(expected):
    for field,target,guess,logits in zip(fields,head['expected_token_ids'][index],head['predicted_token_ids'][index],head['raw_logits'][index]):
     check(len(logits)==32 and guess==max(range(32),key=logits.__getitem__) and json.loads(vocab[target])==reference[field], 'transfer/actual_full_vocabulary_argmax_and_label')
     actual=generated[index].get(field);raw=json.loads(vocab[guess]) if vocab[guess].startswith('"') else vocab[guess]
     key=('raw_correct' if target==guess else 'raw_wrong')+('_generated_correct' if actual==reference[field] else '_generated_wrong')
     counts[field][key]+=1;counts[field]['raw_generated_equal']+=raw==actual
  check({f:dict(v) for f,v in counts.items()}==saved['contingency'],'transfer/independently_recomputed_all_field_contingencies/'+arm)
  check(saved['source_clause_presentations']==report['source_value_presentations']//4==6400,'transfer/source_clause_exposure/'+arm)
 check(180*340/6400==9.5625 and '9.5625 times' in prose,'transfer/exposure_ratio')
 selected=[(k,v['selected_epoch']) for k,v in audit['analysis']['runs'].items() if v['selected_epoch']]
 check(selected==[('768-source-head-lr10-2718',52)],'documentation/only_one_noninitial_selected_state')
 # Local source and evidence links must be useful without guessing class locations.
 for target in re.findall(r'\]\(([^)]+)\)',text):
  if '://' not in target and not target.startswith('#'):check((doc.parent/target.split('#',1)[0]).resolve().exists(),'documentation/local_link/'+target)
 pin(__file__)
 result=dict(schema='source-head-learning-rate-documentation-review/v1',passed=not findings,finding_count=len(findings),findings=findings,checks=checks,
  document_path=str(doc),document_sha256=sha(doc),guide_path=str(guide),guide_sha256=sha(guide),artifacts=artifacts,
  main_independent_audit_sha256=sha(R/'independent-audit.json'),outcomes_sha256=sha(R/'outcomes.json'),
  source_path=str(Path(__file__).resolve()),source_sha256=sha(__file__),models_executed=False,training_executed=False,
  global_convergence_claimed=False,fresh_holdout_claimed=False,qualified=False,admitted=False,lake_executed=False,
  guardian_succeeded=False,continuous_scheduler_lease_coverage_proven=False,created_at_utc=datetime.now(timezone.utc).isoformat())
 with (R/'documentation-review.json').open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
 print(json.dumps(dict(passed=not findings,checks=checks,findings=findings)))
 if findings:raise SystemExit(1)
if __name__=='__main__':main()
