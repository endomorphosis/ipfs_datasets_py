"""Archive checked Intent/code effects as append-only Security checkpoint evidence.

The Security candidate is freshly inferred from an unchanged published 384d
checkpoint. Intent clauses for the three checked contracts are authored. The
separate existing local paired-text Intent checkpoint supplies a no-effect
candidate that correctly abstains. This package includes no numerical weights.
"""
import argparse
from copy import deepcopy
import importlib.util
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SOURCE_HELPERS = HERE / "_source_state_helpers.py"
if not SOURCE_HELPERS.exists():
    SOURCE_HELPERS = HERE.parent / "source-derived-states-20261002/publish_evidence.py"
spec = importlib.util.spec_from_file_location("source_state_publication_helpers", SOURCE_HELPERS)
source_helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source_helper)
helper = source_helper.helper
require, raw, sha, ref = helper.require, helper.raw, helper.sha, helper.ref
false_fields, identifier = helper.false_fields, helper.identifier
REPOSITORY = source_helper.REPOSITORY
CHECKPOINT = source_helper.CHECKPOINT
DISPOSITIONS = ("satisfied", "refuted", "no_enabled_cases")
INSTRUCTION = "the agent may delete the report."


def expected_files():
    return {"summary.json", "security-config.json", "source-inputs.json", "security-advice.json",
        "authored-contract-inputs.json", "authored-native/receipt.json", "authored-native/IntentCodeEffects.lean",
        "intent-advice.json", "intent-input.json", "learned-contract-config.json", "learned-contract-advice.json",
        "producer-sources.json", "intent-checkpoint-reference.json", "intent-checkpoint-descriptor.json",
        "intent-checkpoint-manifest.json", "execution-environment.json"}


def normalize_capture(captured, datasets_checkout, accelerate_checkout):
    require(type(captured.get("modules")) is list and captured["modules"], "complete imported producer capture required")
    roots = {"datasets": Path(datasets_checkout).resolve(), "accelerate": Path(accelerate_checkout).resolve()}
    modules, identities = [], set()
    for item in captured["modules"]:
        require(set(item) == {"module", "path", "sha256"} and identifier(item["sha256"], 64),
            "closed imported source record required")
        path = Path(item["path"])
        require(path.is_absolute() and path.resolve() == path and not path.is_symlink(), "canonical source path required")
        matches = [(repo, path.relative_to(root).as_posix()) for repo, root in roots.items() if path.is_relative_to(root)]
        require(len(matches) == 1, "captured producer outside reviewed checkouts")
        repo, relative = matches[0]
        allowed = relative.startswith("ipfs_datasets_py/") if repo == "datasets" else relative.startswith("ipfs_accelerate_py/")
        allowed |= repo == "datasets" and relative == "tests/unit/logic/formalization/autoencoder/test_intent_code_effects.py"
        require(allowed and helper.safe_name(relative) and (repo, relative) not in identities,
            "unexpected or duplicate producer path")
        identities.add((repo, relative))
        modules.append(dict(repository=repo, module=item["module"], path=relative, sha256=item["sha256"]))
    require(any(row["path"].startswith("tests/") for row in modules), "authored fixture producer was not captured")
    return dict(schema="intent-code-effect-tested-producers/v1", modules=modules,
        reproducer_sha256=captured["reproducer_sha256"], scope=captured["scope"])


def verify_loaded(captured):
    for row in captured["modules"]:
        module = sys.modules.get(row["module"])
        if module is not None and getattr(module, "__file__", None):
            path = Path(module.__file__).resolve()
            require(path.as_posix().endswith("/" + row["path"]) and sha(path.read_bytes()) == row["sha256"],
                "offline validation source differs from run capture: " + row["module"])


def validate_native(receipt, rows, lean_bytes):
    from ipfs_datasets_py.logic.formalization.autoencoder import intent_code_effects_lake as gate
    prepared = gate.prepare_intent_code_effects_lean(rows)
    require(receipt["status"] == "passed" and receipt["all_candidates_checked"] is True
        and receipt["finite_effects_kernel_checked"] is True and receipt["backend_executed"] is True
        and receipt["bounded_effects_satisfied"] is False and receipt["count"] == receipt["supported_count"] == 3,
        "all three distinct native contract dispositions must be checked")
    false_fields(receipt, tuple(gate.FALSE), "native receipt")
    require(receipt["provider_calls"] == receipt["training_steps"] == receipt["download_calls"] == 0,
        "native checks cannot train or call providers")
    execution = receipt["execution"]
    require(execution["status"] == "passed" and execution["backend_executed"] is True
        and execution["returncode"] == 0 and execution["timed_out"] is False
        and execution["output_truncated"] is False and execution["workspace_limit_exceeded"] is False,
        "actual complete Lean execution required")
    require(receipt["lean_source"].encode() == lean_bytes and receipt["lean_source_sha256"] == sha(lean_bytes)
        == execution["input_files_sha256"]["IntentCodeEffects.lean"], "native Lean artifact binding differs")
    overrides = {"status", "rows", "backend_executed", "all_candidates_checked", "finite_effects_kernel_checked",
        "bounded_effects_satisfied"}
    require(all(receipt[key] == value for key, value in prepared.items() if key not in overrides),
        "native source/producer/input replay differs")
    for saved, replayed, disposition in zip(receipt["rows"], prepared["rows"], DISPOSITIONS):
        updates = dict(status="passed", lake_status="passed", finite_effects_kernel_checked=True,
            counterexample_kernel_checked=disposition == "refuted", bounded_effects_satisfied=disposition == "satisfied")
        require(saved == {**replayed, **updates}, "native candidate evidence differs from exact contract replay")
        require(saved["id"] == saved["effect_status"] == disposition and saved["case_count"] == 9
            and saved["enabled_case_count"] == (0 if disposition == "no_enabled_cases" else 9),
            "unexpected authored disposition or case population")
    tool_pins = receipt["tool_binary_sha256"]
    require(type(tool_pins) is dict and len(tool_pins) == 2, "exact Lake and Lean binary pins required")
    used = Path(execution["command"][0]).resolve()
    require(tool_pins.get(str(used)) == execution["executable_sha256"] and str(used.with_name("lean")) in tool_pins,
        "observed native tool identity differs")
    for name, checksum in tool_pins.items():
        require(Path(name).is_file() and sha(Path(name).read_bytes()) == checksum, "native checker binary changed")
    return prepared


def validate_intent(files, summary):
    from ipfs_accelerate_py.agent_supervisor.runtime.intent_autoencoder_advisor import validate_intent_advice
    selected, advice = json.loads(files["intent-input.json"]), json.loads(files["intent-advice.json"])
    require(selected["instruction"] == INSTRUCTION, "unreviewed learned Intent instruction")
    descriptor_bytes = files["intent-checkpoint-descriptor.json"]
    descriptor = json.loads(descriptor_bytes)
    require(descriptor == selected["checkpoint_descriptor"] == advice["checkpoint_descriptor"]
        and set(descriptor) == {"schema", "path", "sha256"}
        and descriptor["schema"] == "intent-roundtrip-checkpoint/v1", "local paired-text Intent descriptor differs")
    require(validate_intent_advice(advice, instruction=INSTRUCTION) == advice
        and advice["status"] == summary["learned_intent_status"] == "semantic_candidate_advice",
        "original learned Intent advice did not validate")
    require(advice["report"]["checkpoint_sha256"] == descriptor["sha256"] == summary["intent_checkpoint_sha256"],
        "actual Intent inference checkpoint differs")
    candidate = advice["report"]["candidate_intent_ir"]
    require(len(candidate["actions"]) == 1 and candidate["actions"][0]["effect_ids"] == [],
        "learned Intent unexpectedly declares effects")
    manifest_path = Path(descriptor["path"])
    require(manifest_path.is_file() and not manifest_path.is_symlink(), "local Intent package manifest missing or linked")
    manifest_bytes = manifest_path.read_bytes()
    require(sha(manifest_bytes) == descriptor["sha256"], "local Intent package bytes changed")
    manifest = json.loads(manifest_bytes)
    backend = manifest["backend"]
    require(helper.safe_name(backend["file"]), "unsafe Intent backend path")
    backend_path = manifest_path.parent / backend["file"]
    require(backend_path.is_file() and not backend_path.is_symlink() and
        backend_path.resolve().is_relative_to(manifest_path.parent.resolve()), "unsafe local Intent backend")
    backend_ref = ref(backend_path.read_bytes())
    require(backend_ref["sha256"] == backend["sha256"], "local Intent backend weights changed")
    require(files["intent-checkpoint-manifest.json"] == manifest_bytes, "captured Intent package bytes differ")
    reference = json.loads(files["intent-checkpoint-reference.json"])
    descriptor_path = Path(reference["descriptor"]["path"])
    require(descriptor_path.is_absolute() and descriptor_path.is_file() and not descriptor_path.is_symlink()
        and descriptor_path.read_bytes() == descriptor_bytes, "original local Intent descriptor bytes changed")
    require(reference == dict(kind="existing_local_paired_text_roundtrip_checkpoint", published_384_checkpoint=False,
        descriptor=dict(path=str(descriptor_path), **ref(descriptor_bytes)),
        manifest=dict(path=str(manifest_path), schema=manifest["schema"], **ref(manifest_bytes)),
        weights=dict(path=str(backend_path), schema=backend["schema"], **backend_ref)),
        "original local Intent checkpoint reference differs")
    # The run's original descriptor reference is retained; this additional closed
    # reference binds exact metadata and existing backend bytes, without weights.
    local_reference = dict(schema="local-paired-text-Intent-reference/v1", descriptor=ref(descriptor_bytes),
        package_manifest=dict(path=str(manifest_path), **ref(manifest_bytes)),
        backend=dict(path=str(backend_path), **backend_ref), checkpoint_family="paired-text-roundtrip",
        published=False, shared384_inference=False, weights_included=False, weights_changed=False)
    files["intent-local-package-reference.json"] = raw(local_reference)
    return selected, advice, candidate, local_reference


def validate_run(root, run, *, prior_run, datasets_checkout, accelerate_checkout):
    files = helper.snapshot(root / run, expected_files())
    get = lambda name: json.loads(files[name])
    summary = get("summary.json")
    require(summary["schema"] == "intent-code-effects-development-evidence/v1", "unexpected evidence schema")
    false_fields(summary, ("authored_intent_learned", "source_semantics_verified", "proof_authority",
        "whole_instruction_verified", "training_executed", "weights_changed", "new_holdout_evaluation",
        "terminal_bench_executed", "full_daemon_executed", "source_executed"), "summary")
    require(summary["provider_calls"] == 0 and summary["security_checkpoint_loaded"] is True
        and summary["intent_checkpoint_loaded"] is True and summary["security_embeddings_recomputed"] is True,
        "actual fresh inference scope missing")
    require(summary["intent_checkpoint_family"] == "existing_local_paired_text_roundtrip"
        and summary["embedding_device"] == "cpu" and get("execution-environment.json") == dict(
            embedding_device="cpu", cuda_visible_devices="",
            scope="selected device for correctness replay, not a throughput measurement"),
        "explicit CPU correctness replay or local Intent family differs")
    captured = normalize_capture(get("producer-sources.json"), datasets_checkout, accelerate_checkout)
    files["reproduce.py"] = (root / "reproduce.py").read_bytes()
    require(captured["reproducer_sha256"] == sha(files["reproduce.py"]), "tested reproducer bytes changed")
    files["normalized-producer-sources.json"] = raw(captured)
    from ipfs_datasets_py.logic.formalization.autoencoder import intent_code_effects as contracts
    from tests.unit.logic.formalization.autoencoder.test_intent_code_effects import fixture
    from ipfs_datasets_py.logic.software_verification.program import ProgramIR
    from ipfs_accelerate_py.agent_supervisor.runtime import intent_code_effect_advisor as advisor
    verify_loaded(captured)
    sources, config, security = get("source-inputs.json"), get("security-config.json"), get("security-advice.json")
    require(sources == [dict(id="checkpoint-source.py", source_text=source_helper.SOURCE,
        source_sha256=sha(source_helper.SOURCE.encode()))], "unreviewed source input")
    require(security["checkpoint_selection"] == config and config["checkpoint_sha256"] == CHECKPOINT
        == summary["security_checkpoint_sha256"] and config["lake"] is None, "Security checkpoint selection differs")
    false_fields(security, (*source_helper.AUTHORITY, "mutation_authority", "claim_proved", "default_model_promoted"), "Security advice")
    require(security["provider_calls"] == security["training_steps"] == security["download_calls"] == 0,
        "unexpected Security provider/training/download activity")
    inference = security["inference"]
    require(inference["checkpoint_sha256"] == CHECKPOINT and inference["domain_id"] == "security_ir"
        and len(inference["rows"]) == 1, "actual Security prediction missing")
    source_helper.verify_compatibility(security, config, captured)
    prediction = inference["rows"][0]
    false_fields(prediction, ("target_access", "teacher_forcing", "proof_authority"), "Security prediction")
    source_text = sources[0]["source_text"]
    require(security["status"] == "source_candidate_advice" and security["qualified_candidate_count"] == 1
        and inference["dimension"] == security["runtime"]["dimension"] == 384
        and security["input_bindings"] == [dict(inference_id=prediction["id"], source_id=sources[0]["id"],
            source_sha256=sources[0]["source_sha256"])]
        and prediction["source_sha256"] == sources[0]["source_sha256"],
        "actual Security candidate source differs")
    domains = {name: dict(lower=-1, upper=1) for name in ("capacity", "threshold")}
    require(config["finite_state_domains"] == {sources[0]["id"]: domains}, "reviewed finite domain differs")
    from ipfs_datasets_py.logic.formalization.autoencoder.security.source_program_binding_384_v2 import verify_source_qualification
    from ipfs_accelerate_py.agent_supervisor.runtime.security_source_state_advisor_384 import consume_source_state_advice
    require(verify_source_qualification(prediction["source_contract"], source_text, prediction["candidate_ir"])
        == prediction["source_contract"], "actual predicted source qualification differs")
    state_replay = consume_source_state_advice(inference=inference, source_rows=sources,
        input_bindings=security["input_bindings"], finite_state_domains=config["finite_state_domains"])
    require(state_replay == security["source_state"] and state_replay["status"] == "state_candidate_advice"
        and state_replay["native"]["backend_executed"] is False, "recorded pre-build Security state advice differs")
    rows = get("authored-contract-inputs.json")
    require(len(rows) == 3, "exact three authored contracts required")
    fields = ("intent_source_text", "intent_candidate_ir", "code_source_text", "code_candidate_ir", "input_domains", "association")
    for row, status in zip(rows, DISPOSITIONS):
        inputs = list(fixture(status))
        inputs[2:5] = [source_text, deepcopy(prediction["candidate_ir"]), domains]
        required = contracts.intent_code_effect_requirements(*inputs[:5])
        inputs[-1].update({key: required[key] for key in contracts.IDENTITY_FIELDS})
        inputs[-1]["expression_program"]["sources"] = deepcopy(required["code_source_refs"])
        inputs[-1]["expression_program"].pop("program_id", None)
        inputs[-1]["expression_program"] = ProgramIR.from_dict(inputs[-1]["expression_program"]).to_dict()
        require(row == dict(id=status, **dict(zip(fields, inputs))),
            "authored Intent interpretation or actual Security prediction changed")
    native = get("authored-native/receipt.json")
    validate_native(native, rows, files["authored-native/IntentCodeEffects.lean"])
    require(summary["authored_contracts"] == [{key: row[key] for key in ("id", "effect_status", "case_count",
        "enabled_case_count", "finite_effects_kernel_checked", "bounded_effects_satisfied", "counterexample_kernel_checked")}
        for row in native["rows"]], "summary merged incompatible effect dispositions")
    intent_input, intent, candidate, local_intent = validate_intent(files, summary)
    selection, learned = get("learned-contract-config.json"), get("learned-contract-advice.json")
    required = contracts.intent_code_effect_requirements(INSTRUCTION, candidate, source_text,
        prediction["candidate_ir"], domains)
    association = deepcopy(rows[0]["association"])
    association.update({key: required[key] for key in contracts.IDENTITY_FIELDS})
    association.update(action_id=candidate["actions"][0]["action_id"],
        intent_evidence_ref=candidate["actions"][0]["source_ref_ids"][0], precondition_bindings=[], effect_bindings=[])
    require(selection == dict(schema="supervisor-intent-code-effect-config/v1", lake=None,
        contracts=[dict(id="learned-no-effects", source_id=sources[0]["id"], input_domains=domains, association=association)]),
        "learned abstention association differs")
    replay = advisor.prepare_intent_code_effect_advice(instruction=INSTRUCTION, intent_advice=intent,
        security_advice=security, source_rows=sources, config=selection)
    require(replay == learned and learned["status"] == summary["learned_contract_status"] == "fail_open_no_supported_contracts"
        and summary["learned_effect_count"] == 0 and learned["continue_planning"] is True
        and learned["selected_bounded_effects_satisfied"] is False and learned["native"]["backend_executed"] is False
        and len(learned["native"]["rows"]) == 1 and "no declared effects" in learned["native"]["rows"][0]["reason"],
        "learned missing-effect abstention did not replay exactly")
    false_fields(learned, tuple(advisor.FALSE), "learned supervisor advice")
    require(learned["provider_calls"] == learned["training_steps"] == learned["download_calls"] == 0,
        "learned contract validation executed additional inference/training")
    published_bytes = (prior_run / "published-checkpoint-reference.json").read_bytes()
    published = json.loads(published_bytes)
    require(published["repository_id"] == REPOSITORY and published["repo_type"] == "model"
        and published["kind"] == "checkpoint" and published["revision"] == source_helper.CHECKPOINT_REVISION
        and published["binding"]["domain_id"] == "security_ir" and identifier(published["binding"]["plan_id"], 64),
        "immutable original Security checkpoint reference differs")
    checkpoint_path = Path(config["checkpoint_path"])
    require(checkpoint_path.is_file() and not checkpoint_path.is_symlink(), "immutable local Security checkpoint missing")
    checkpoint = ref(checkpoint_path.read_bytes())
    require(checkpoint["sha256"] == CHECKPOINT, "immutable Security checkpoint bytes changed")
    manifest_path = checkpoint_path.parent.parent / "bundles/checkpoints" / published["manifest_sha256"] / "manifest.json"
    manifest_bytes = manifest_path.read_bytes(); manifest = json.loads(manifest_bytes)
    require(sha(manifest_bytes) == published["manifest_sha256"] and manifest["binding"] == published["binding"]
        and manifest["result"] == checkpoint, "original checkpoint publication manifest differs")
    provenance_bytes = (prior_run / "source-provenance.json").read_bytes()
    provenance = json.loads(provenance_bytes)
    require(provenance["redistribution_allowed"] is True and "Authored" in provenance["description"]
        and provenance["source_path"] == "tests/fixtures/logic/source_reconstruction_v3.py", "unreviewed source provenance")
    files.update({"published-checkpoint-reference.json": published_bytes,
        "published-checkpoint-manifest.json": manifest_bytes, "source-provenance.json": provenance_bytes,
        "publish_evidence.py": Path(__file__).read_bytes(), "_source_state_helpers.py": SOURCE_HELPERS.read_bytes(),
        "_publication_helpers.py": source_helper.HELPERS.read_bytes()})
    verify_loaded(captured)
    return summary, files, published, checkpoint, local_intent


def validate_commits(files, datasets_commit, accelerate_commit, datasets_checkout, accelerate_checkout):
    require(identifier(datasets_commit, 40) and identifier(accelerate_commit, 40), "two immutable tested Git commits required")
    captured = json.loads(files["normalized-producer-sources.json"])
    require(captured["reproducer_sha256"] == sha(files["reproduce.py"]), "reproducer changed")
    pins = {"datasets": {}, "accelerate": {}}
    for row in captured["modules"]:
        pins[row["repository"]][row["path"]] = row["sha256"]
    native = json.loads(files["authored-native/receipt.json"])
    learned = json.loads(files["learned-contract-advice.json"])["native"]
    for receipt in (native, learned, json.loads(files["security-advice.json"])["source_state"]["native"]):
        for path, checksum in receipt["producer"].items():
            relative = Path(path).relative_to(Path(datasets_checkout).resolve()).as_posix()
            require(helper.safe_name(relative) and relative.startswith("ipfs_datasets_py/"), "foreign native owner path")
            require(relative not in pins["datasets"] or pins["datasets"][relative] == checksum,
                "producer changed during artifact run")
            pins["datasets"][relative] = checksum
    for repo, commit, checkout in (("datasets", datasets_commit, datasets_checkout),
            ("accelerate", accelerate_commit, accelerate_checkout)):
        require(pins[repo], "both tested repository source closures required")
        for relative, checksum in pins[repo].items():
            require(identifier(checksum, 64) and sha(source_helper.git_file(checkout, commit, relative)) == checksum,
                "requested Git commit differs from tested source: " + relative)
    return pins


def prepare_package(summary, files, published, checkpoint, local_intent, datasets_commit, accelerate_commit,
        datasets_checkout, accelerate_checkout):
    producers = validate_commits(files, datasets_commit, accelerate_commit, datasets_checkout, accelerate_checkout)
    manifest = dict(schema="intent-code-effects-development-evidence/v1", domain_id="security_ir",
        checkpoint=checkpoint, published_checkpoint=published, local_intent_checkpoint=local_intent,
        code=dict(datasets=dict(repository="https://github.com/endomorphosis/ipfs_datasets_py", commit=datasets_commit),
            accelerate=dict(repository="https://github.com/endomorphosis/ipfs_accelerate_py", commit=accelerate_commit)),
        tested_producer_files=producers, result=summary,
        scope="three authored Intent contracts against one fresh unchanged Security384 code prediction; separate local paired-text Intent advice abstains for missing effects",
        proof_scope="explicit selected-action scalar interpretations over nine finite source-derived ProgramIR outcomes per contract",
        source_provenance="one existing redistributable authored tuning source and separate authored Intent clauses; no full corpus or training-target rows; not a holdout evaluation",
        weights_included=False, weights_changed=False, training_executed=False, training_target_rows_included=False,
        intent_shared384_inference=False, intent_checkpoint_published=False,
        saved_evidence_is_live_authority=False, model_source_semantic_fidelity_verified=False,
        source_semantics_verified=False, proof_authority=False, whole_instruction_verified=False,
        full_daemon_executed=False, terminal_bench_executed=False, admitted=False, qualified=False, promotion_performed=False,
        files=[dict(path=name, **ref(data)) for name, data in sorted(files.items())])
    archive = helper.bundle_files(files)
    manifest["archive"] = dict(path="evidence.tar.gz", **ref(archive))
    helper.verify_archive(archive, manifest)
    manifest_bytes = raw(manifest); identity = sha(manifest_bytes)
    prefix = "training/structured384/" + published["binding"]["plan_id"] + "/intent-code-effect-checks/" + identity
    return dict(prefix=prefix, manifest=manifest, published=published, checkpoint=checkpoint,
        desired={prefix + "/manifest.json": manifest_bytes, prefix + "/evidence.tar.gz": archive},
        receipt=dict(repository_id=REPOSITORY, repo_type="model", path=prefix, manifest_sha256=identity,
            archive_sha256=sha(archive), archive_bytes=len(archive), uploaded=False))


def upload_package(package):
    from huggingface_hub import CommitOperationAdd, HfApi, hf_hub_download
    helper.verify_published_checkpoint(package, hf_hub_download)
    class EvidenceApi:
        def __init__(self): self.api = HfApi()
        def model_info(self, *args, **kwargs): return self.api.model_info(*args, **kwargs)
        def create_commit(self, **kwargs):
            kwargs["commit_message"] = "Archive explicit Intent code effect checks and learned abstention"
            return self.api.create_commit(**kwargs)
    return helper.upload_package(package, EvidenceApi(), hf_hub_download, CommitOperationAdd)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=HERE)
    parser.add_argument("--run", default="run-03")
    parser.add_argument("--prior-run", type=Path, default=HERE.parent / "source-derived-states-20261002/run-02")
    parser.add_argument("--datasets-commit")
    parser.add_argument("--accelerate-commit")
    parser.add_argument("--datasets-checkout", type=Path, default=Path("/tmp/ir-release-datasets-20261001"))
    parser.add_argument("--accelerate-checkout", type=Path, default=Path("/tmp/ir-release-accelerate-20261001"))
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--upload", action="store_true")
    args = parser.parse_args(argv)
    require(helper.safe_name(args.run) and len(PurePosixPath(args.run).parts) == 1, "single run directory required")
    require(not (args.validate_only and args.upload), "validation cannot upload")
    sys.path[:0] = [str(args.datasets_checkout.resolve()), str(args.accelerate_checkout.resolve())]
    record = validate_run(args.root, args.run, prior_run=args.prior_run,
        datasets_checkout=args.datasets_checkout, accelerate_checkout=args.accelerate_checkout)
    if args.validate_only:
        print(json.dumps(dict(validated=True, staged=False, uploaded=False, files=len(record[1]))))
        return
    package = prepare_package(*record, args.datasets_commit, args.accelerate_commit,
        args.datasets_checkout, args.accelerate_checkout)
    stage = args.root / "publication" / package["receipt"]["manifest_sha256"]
    for name, data in package["desired"].items():
        helper.bounded_snapshot(stage / PurePosixPath(name).name, data)
    receipt = upload_package(package) if args.upload else package["receipt"]
    receipt_path = stage / "receipt.json"
    if receipt_path.exists() and not args.upload:
        previous = json.loads(receipt_path.read_bytes())
        require(all(previous[key] == receipt[key] for key in receipt if key != "uploaded"), "previous staged receipt differs")
        receipt = previous
    receipt_path.write_bytes(raw(receipt))
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
