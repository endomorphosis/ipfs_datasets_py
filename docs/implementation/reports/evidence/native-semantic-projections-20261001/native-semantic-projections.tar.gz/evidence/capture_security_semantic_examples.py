import hashlib,json,runpy
from pathlib import Path
fixture = Path('tests/unit/logic/formalization/autoencoder/test_native_security_lean.py')
module = Path('ipfs_datasets_py/logic/formalization/autoencoder/native_security_lean.py')
namespace = runpy.run_path(str(fixture))
original=namespace['lake']; receipts=[]
def recorded(source,extra=''):
    receipt=original(source,extra)
    receipt['example_case']=active[0]
    receipt['submitted_source_sha256']=hashlib.sha256((source+'\n'+extra).encode()).hexdigest()
    receipts.append(receipt)
    return receipt
active=['']
for name in ['test_actual_native_three_payloads_compile_without_admitting_claims',
 'test_disjoint_heap_union_is_satisfiable_and_not_ordinary_conjunction',
 'test_same_address_separation_is_impossible_but_ordinary_conjunction_holds',
 'test_different_identifiers_are_not_assumed_nonaliasing',
 'test_empty_heap_and_integer_boolean_values_do_not_collapse',
 'test_hyperproperty_can_reject_leak_without_asserting_program_noninterference',
 'test_actual_allocated_heap_fragment_has_full_permission_cell_semantics',
 'test_failing_heap_proof_cannot_claim_overlapping_resource_ownership']:
    active[0]=name
    namespace[name].__globals__['lake']=recorded
    namespace[name]()
result={'schema':'native-security-semantic-examples/v1','module_sha256':hashlib.sha256(module.read_bytes()).hexdigest(),
 'test_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'receipts':receipts,
 'passed_builds':sum(row['status']=='passed' for row in receipts),'expected_false_proof_failures':sum(row['status']=='failed' for row in receipts),
 'source_program_semantics_verified':False,'legal_admitted':False,'hyperltl_temporal_semantics_provided':False}
Path('../native-security-semantic-examples.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='receipts'}))
