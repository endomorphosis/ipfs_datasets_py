"""Read-only source/resource review; never imports Torch or runs training/tests."""
from pathlib import Path
import ast
from copy import deepcopy
import hashlib
import json

R=Path(__file__).resolve().parent
P=R.parents[2]
O=P/'workspace/test-logs/decoder-order-boundary-training-20261003'
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
F=R/'experiment-source'
AUTO='ipfs_datasets_py/logic/formalization/autoencoder/'
SCRIPT='scripts/ops/autoencoder/'
artifacts={}
checks=[]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def bind(path):
    path=Path(path).resolve()
    value=dict(sha256=sha(path),bytes=path.stat().st_size)
    artifacts[str(path)]=value
    return value
def read(path):bind(path);return json.loads(Path(path).read_bytes())
def check(value,name):
    checks.append(dict(check=name,passed=bool(value)))
    if not value:raise ValueError(name)
def tree(path):bind(path);return ast.parse(Path(path).read_text())
def functions(module):return {n.name:n for n in module.body if isinstance(n,ast.FunctionDef)}
def dump(node):return ast.dump(node,include_attributes=False)


def trainer_default_path():
    old=tree(O/'experiment-source'/AUTO/'long_span_source_value_training.py')
    new=tree(F/AUTO/'long_span_source_value_training.py')
    candidate=deepcopy(new)
    train=functions(candidate)['train']
    check(train.args.kwonlyargs[-1].arg=='generated_boundary_gradient_scope'
        and dump(train.args.kw_defaults[-1])==dump(ast.Constant(value='all_trainable')),
        'trainer/new_scope_keyword_defaults_to_prior_behavior')
    train.args.kwonlyargs.pop();train.args.kw_defaults.pop()
    approved=[
        "core._require(type(generated_boundary_gradient_scope) is str and generated_boundary_gradient_scope in ('all_trainable', 'count_head_only'), 'unknown generated-boundary gradient scope')",
        "core._require(generated_boundary_gradient_scope == 'all_trainable' or generated_boundary_weight > 0, 'count-only boundary gradient scope requires positive boundary weight')",
        "if generated_boundary_gradient_scope != 'all_trainable':\n report['generated_boundary_gradient_scope'] = generated_boundary_gradient_scope",
    ]
    for index,statement in enumerate(approved):
        wanted=dump(ast.parse(statement).body[0])
        matches=[n for n in train.body if dump(n)==wanted]
        check(len(matches)==1,'trainer/exact_approved_scope_statement_'+str(index))
        train.body.remove(matches[0])
    calls=[n for n in ast.walk(train) if isinstance(n,ast.Call)
        and ast.unparse(n.func)=='boundary_owner.generated_boundary_loss']
    check(len(calls)==1,'trainer/single_boundary_loss_call')
    call=calls[0]
    keyword=call.keywords[-1]
    expected=ast.parse("{} if generated_boundary_gradient_scope == 'all_trainable' else {'gradient_scope': generated_boundary_gradient_scope}",mode='eval').body
    check(keyword.arg is None and dump(keyword.value)==dump(expected),
        'trainer/default_call_passes_no_new_keyword')
    call.keywords.pop()
    check(dump(old)==dump(candidate),'trainer/entire_remaining_module_ast_unchanged')
    # This includes all numerical objectives, optimizer, clipping, deadline,
    # source-fidelity selection, history and original report construction.


def source_and_resource():
    published=read(P/'docs/implementation/reports/evidence/decoder-order-boundary-training-20261003/manifest.json')
    for path in (O/'run_training_reserved.py',O/'run_frozen_tests.py',O/'adopt_shared_scheduler.py',
                 O/'experiment-source'/AUTO/'long_span_source_value_training.py'):
        member=published['original_artifact_archive_paths'][str(path)]
        check(bind(path)==published['members'][member],'predecessor/published_'+path.name)
    previous=(O/'run_training_reserved.py').read_text()
    before='benchmark_order_boundary_source_training.py';after='benchmark_multiplicative_source_training.py'
    check(previous.count(before)==1,'guardian/one_script_name_occurrence')
    check(previous.replace(before,after)==(R/'run_training_reserved.py').read_text(),
        'guardian/only_benchmark_filename_changed')
    bind(R/'run_training_reserved.py')
    for name in ('run_frozen_tests.py','adopt_shared_scheduler.py'):
        check(bind(R/name)==bind(O/name),'guardian/unchanged_'+name)
    bind(R/'freeze.py')
    resource=read(O/'guardian-review.json')
    check(resource['passed'] is True and not resource['findings']
        and resource['guardian_sha256']==sha(O/'run_training_reserved.py'),
        'guardian/previous_exact_resource_review')
    for name,h in [('autoencoder_daemon_resources.py','5ed9b83f571a4a892e1fac4a1fe6f5a995950d0725bad8461a0876a9415a03d1'),
                   ('resource_scheduler.py','a418e84f70ed8509ba0518feea69e7a8c27865139f83b6c81349eefdfd5893a4')]:
        path=S/'ipfs_datasets_py/optimizers/logic_theorem_optimizer'/name
        check(bind(path)['sha256']==h,'guardian/frozen_resource_owner_'+name)
    plan=read(R/'training-plan.json');manifest=read(R/'training-manifest.json')
    check(sha(R/'training-plan.json')==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'],
        'freeze/plan_input_bindings')
    for path,h in manifest['inputs'].items():check(sha(path)==h,'freeze/input_'+path)
    for name in ('frozen-extensions.json','validated-test-source.json','test-helper-sources.json'):
        pins=read(R/name)
        for rel,h in pins.items():check(sha(F/rel)==h,'freeze/source_'+rel)
    check(plan['seed_order']==[1729,2718] and plan['arms']==[
        dict(name='baseline',slot_interaction='additive',order_augmentation=False,generated_boundary_weight=0.),
        dict(name='multiplicative',slot_interaction='additive_multiplicative',order_augmentation=False,generated_boundary_weight=0.)],
        'plan/four_fits_only_binding_interaction_varies')
    check(plan['max_seconds_per_arm']==180 and plan['max_seconds_entire_run']==2400
        and plan['expected_optimizer_steps_per_arm']==340 and plan['selection_unchanged'] is True,
        'plan/unchanged_bounded_optimizer_and_selection')
    return resource


def initial_and_restoration():
    runner=functions(tree(F/SCRIPT/'benchmark_multiplicative_source_training.py'))
    previous=functions(tree(O/'experiment-source'/SCRIPT/'benchmark_order_boundary_source_training.py'))
    for name in ('validate_baseline','train_candidate','postfit_mechanisms'):
        check(dump(runner[name])==dump(previous[name]),'runner/unchanged_'+name)
    initial=ast.unparse(runner['validate_initial'])
    for fragment in ("set(params) == set(bparams)","torch.equal(params[k], v)",
        "set(state) == set(bstate) | extra", "torch.equal(state[k], v)",
        "state['slot_interaction_version'].dtype == torch.long", "int(state['slot_interaction_version']) == 1",
        "observed['predictions'] == reference['predictions']"):
        check(fragment in initial,'initial/comparison_'+fragment)
    restored=ast.unparse(runner['restored_tensors'])
    for fragment in ("set(state) == set(template)","type(state[name]) is int",
        "state[name] == int(value)","name != 'slot_interaction_version' or state[name] == 1"):
        check(fragment in restored,'state/typed_restore_'+fragment)
    inventory=functions(tree(F/SCRIPT/'benchmark_projected_source_reconstruction.py'))['greedy_inventory']
    old_inventory=functions(tree(O/'experiment-source'/SCRIPT/'benchmark_projected_source_reconstruction.py'))['greedy_inventory']
    check(dump(inventory)==dump(old_inventory),'initial/published_greedy_replay_unchanged')
    tries=[n for n in inventory.body if isinstance(n,ast.Try)]
    check(len(tries)==1 and "module.training = modes[name]" in ast.unparse(ast.Module(body=tries[0].finalbody,type_ignores=[])),
        'initial/modes_restored_in_finally_including_failure')
    check('core.tensor_digest(model) != before' in ast.unparse(inventory),
        'initial/tensor_mutation_refused')
    bind(F/AUTO/'shared_slot_source_decoder_experiment.py')


def main():
    resource=source_and_resource();trainer_default_path();initial_and_restoration()
    before=read(R/'before.json');checkpoint=Path(before['checkpoint']['path'])
    observed=dict(path=str(checkpoint),sha256=sha(checkpoint),bytes=checkpoint.stat().st_size)
    check(observed==before['checkpoint'],'protected/original_checkpoint_unchanged')
    receipt=dict(schema='multiplicative-source-static-review/v1',complete=True,passed=True,findings=[],
        check_count=len(checks),checks=checks,artifacts=artifacts,reviewed_controls=resource['reviewed_controls'],
        historical_scheduler_tests_reused=resource['historical_scheduler_tests_reused'],
        protected_external_artifacts=dict(original_checkpoint=observed),
        scope='Static source, exact resource-guard reuse, initial parity and typed-state contracts; actual tensors/control fidelity are audited separately after the run.',
        trainer_default_module_ast_unchanged_except_explicit_opt_in=True,
        source_tree='Authenticated frozen validation-source-r2 plus experiment-source; no HACC substitution.',
        models_executed=False,tests_executed=False,scheduler_client_created=False,
        resources_admitted=False,qualified=False,admitted=False)
    path=R/'static-review.json';path.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(json.dumps(dict(path=str(path),sha256=sha(path),checks=len(checks),findings=[])))


if __name__=='__main__':main()
