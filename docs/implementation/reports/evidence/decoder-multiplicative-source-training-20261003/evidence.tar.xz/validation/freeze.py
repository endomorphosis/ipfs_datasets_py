"""Freeze the four-fit interaction ablation and exact authenticated predecessor closure."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
O=P/'workspace/test-logs/decoder-order-boundary-training-20261003'
BASE=json.loads((R/'base.json').read_bytes())['base']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):(R/name).write_text(json.dumps(obj,indent=2)+'\n')
def gitbytes(rel):return subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)
if __name__=='__main__':
 assert not (R/'experiment-source').exists()
 runner='scripts/ops/autoencoder/benchmark_multiplicative_source_training.py'
 changes=['ipfs_datasets_py/logic/formalization/autoencoder/'+n+'.py' for n in
  ('shared_slot_source_decoder_experiment','generated_boundary_training','long_span_source_value_training')]
 changes += [runner]+['tests/unit/logic/formalization/autoencoder/'+n+'.py' for n in
  ('test_shared_slot_multiplicative_source','test_generated_boundary_gradient_scope',
   'test_order_boundary_training_integration','test_benchmark_multiplicative_source_training')]
 additions={rel:sha(P/rel) for rel in changes}
 pins=json.loads((O/'frozen-extensions.json').read_bytes());tests=json.loads((O/'validated-test-source.json').read_bytes())
 helpers=json.loads((O/'test-helper-sources.json').read_bytes())
 for rel,digest in {**pins,**tests,**helpers}.items():
  assert sha(O/'experiment-source'/rel)==digest,rel
  assert hashlib.sha256(gitbytes(rel)).hexdigest()==digest,rel
 for rel,digest in additions.items():(tests if rel.startswith('tests/') else pins)[rel]=digest
 for rel,digest in {**pins,**tests,**helpers}.items():
  source=P/rel if rel in additions else O/'experiment-source'/rel
  target=R/'experiment-source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(source,target);assert sha(target)==digest
 save('frozen-extensions.json',pins);save('validated-test-source.json',tests);save('test-helper-sources.json',helpers)
 save('test-files.json',list(tests));save('code-files.json',changes+['docs/autoencoders/decoder_length_distillation.md'])
 spec=importlib.util.spec_from_file_location('_freeze_multiplicative_training',R/'experiment-source'/runner)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 manifest=json.loads((O/'training-manifest.json').read_bytes())
 for path,digest in manifest['inputs'].items():assert sha(path)==digest,path
 manifest['extensions']=pins
 save('training-plan.json',dict(module.FIXED,input_sha256=manifest['inputs']))
 manifest['plan_sha256']=sha(R/'training-plan.json');save('training-manifest.json',manifest)
 (R/'run_frozen_tests.py').write_bytes((O/'run_frozen_tests.py').read_bytes())
 guardian=(O/'run_training_reserved.py').read_text().replace('benchmark_order_boundary_source_training.py','benchmark_multiplicative_source_training.py')
 (R/'run_training_reserved.py').write_text(guardian)
 (R/'adopt_shared_scheduler.py').write_bytes((O/'adopt_shared_scheduler.py').read_bytes())
 print(json.dumps(dict(extensions=len(pins),test_files=len(tests),inputs=len(manifest['inputs']))))
