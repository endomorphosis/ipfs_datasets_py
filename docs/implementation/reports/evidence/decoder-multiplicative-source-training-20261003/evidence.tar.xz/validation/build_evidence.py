"""Seal saved multiplicative source-head training evidence without running models or publication.

All new observations are retained. Exact predecessor archive members bind original
inputs and trained weights. Installed encoder assets and host runtime are external.
"""
import hashlib
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from collections import Counter

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
E=P/'docs/implementation/reports/evidence/decoder-multiplicative-source-training-20261003'
DOC='docs/autoencoders/decoder_length_distillation.md'
REPOSITORY='https://github.com/endomorphosis/ipfs_datasets_py'
MAX_ARCHIVE_BYTES=90_000_000
FALSE=dict(qualified=False,admitted=False,proof_authority=False,source_semantics_verified=False,
    convergence_proven=False,fresh_holdout=False,lake_executed=False,formalized=False,
    roundtrip_ok=False,checkpoint_promoted=False,production_checkpoint=False,
    optimizer_resumable=False,native_validation_executed=False,order_recoverability_proven=False)
DYNAMIC={'publication.json','owned-files.json','build-evidence.log','build-evidence-final.log'}
PRIOR_SPECS=[
 ('order-training','ccfd3dabdf25e93774b1a10e29b15882bf8fad0f',
  'docs/implementation/reports/evidence/decoder-order-boundary-training-20261003','evidence.tar.xz',
  'a3e23328da1d23685c201d86eede682db973991c79c9773ff5ed5dde6d6ae9f7'),
 ('order-diagnostic','164fbd4b9c159b1ee53c301dd35a373203bf42f0',
  'docs/implementation/reports/evidence/decoder-order-boundary-diagnostic-20261003','evidence.tar.xz',
  '28563f52812a597f2ede07ec9c07ec2eff3ce821fe33b985152aa7873787c82c'),
 ('shared-slot','903ec6a3e37e9f797ab961509ba4253e66e1f265',
  'docs/implementation/reports/evidence/decoder-shared-slot-source-20261003','evidence.tar.xz',
  '761db20f355ab8fbe8d651610dfac12e1b9ff0f6e608a396dadf952981805810'),
 ('projected-source','4ecbc3ab8668135f084b1fcd49808c7fbfe8a8dc',
  'docs/implementation/reports/evidence/decoder-projected-source-20261003','evidence.tar.gz',
  'e5a0878721ec9134c22c5686b4307c4b49c192fd12dcb363f60a02ac32cb6676')]

def require(condition,message):
    if not condition:raise ValueError(message)


def absolute(path):
    path=Path(path)
    return path if path.is_absolute() else P/path


def read(path):
    def unique(pairs):
        result={}
        for key,value in pairs:
            require(key not in result,'duplicate JSON key: '+key)
            result[key]=value
        return result
    return json.loads(absolute(path).read_bytes(),object_pairs_hook=unique)


def sha(path):
    value=hashlib.sha256()
    with absolute(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):value.update(block)
    return value.hexdigest()


def info(path):
    path=absolute(path)
    require(path.is_file() and not path.is_symlink(),'regular evidence file required: '+str(path))
    return dict(sha256=sha(path),bytes=path.stat().st_size)


def write_new(path,value):
    data=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if path.exists():
        require(path.read_bytes()==data,'existing generated output differs: '+str(path));return
    with path.open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())


def authority(value):
    require(all(value[key] is False for key in FALSE if key in value),'forbidden authority claim')


def passing_tests(path,expected=None):
    result={key:0 for key in ('tests','failures','errors','skipped')}
    for suite in ET.parse(path).getroot().iter('testsuite'):
        for key in result:result[key]+=int(suite.get(key,0))
    require(result['tests']>0 and result['failures']==result['errors']==result['skipped']==0,'complete passing test suite required')
    if expected is not None:require(result['tests']==expected,'test inventory differs')
    return dict(result,junit_sha256=sha(path))


def attempt_for(audit,schema):
    candidates=[]
    for artifact in audit['artifacts']:
        path=absolute(artifact)
        if path.is_relative_to(R) and path.name=='summary.json' and path.parent.name=='results':
            if read(path).get('schema')==schema:candidates.append(path.parent.parent)
    require(len(set(candidates))==1,'exactly one audited phase summary required: '+schema)
    return candidates[0]


def resources(attempt,phase):
    final,child=read(attempt/'resources-final.json'),read(attempt/'child-exit.json');record=final['record']
    require(final['status']==record['status']=='released' and record['artifacts_durable_asserted'] is True
        and record['attempt_exceeded_reservation'] is False and child['returncode']==0
        and child['leader_reaped'] is True,'durable released successful phase required')
    require(record['cpu_slots']==record['child_process_slots']==1 and record['memory_mb']==4096
        and record['storage_bytes']>0 and record['final_accounting']['limit_bytes']==140000000000,
        'resource contract differs')
    observation_path=attempt/'resource-observations.json'
    observations=read(observation_path) if observation_path.exists() else []
    guardians=[]
    for path in (R/(attempt.name+'-guardian.log'),R/(phase+'-guardian.log'),R/('guardian-'+attempt.name+'.log')):
        if not path.exists():continue
        # A preserved failed guardian log may contain a traceback, not a success receipt.
        try:value=read(path)
        except json.JSONDecodeError:continue
        if value.get('returncode')==0 and value.get('resources',{}).get('record',{}).get('attempt_directory',{}).get('path')==str(attempt):
            guardians.append(value)
    require(len(guardians)==1,'one completed guardian receipt bound to successful attempt required')
    guardian=guardians[0]
    return dict(guardian_elapsed_seconds=guardian['elapsed_seconds'],
        guardian_elapsed_through_child_exit_seconds=child['guardian_elapsed_through_child_exit_seconds'],
        launch_return_through_reap_wall_seconds=child['launch_return_through_reap_wall_seconds'],
        child_time_scope=child['child_time_scope'],isolated_child_execution_seconds=None,
        owned_output_bytes=record['final_attempt_bytes'],reservation_bytes=record['storage_bytes'],reservation_released=True,
        observed_peak_child_rss_bytes=max((item['group_rss']['rss_bytes'] for item in observations),default=None),
        rss_observation_count=len(observations),rss_observation_receipt_present=observation_path.exists(),storage_cap_unchanged=True,
        final_charged_storage_bytes=record['final_accounting']['charged_bytes'])


def excluded(path):
    return ('__pycache__' in path.parts or '.pytest_cache' in path.parts
        or any(part.endswith('pytest-cache') for part in path.parts)
        or path.suffix in ('.pyc','.index') or path.name in DYNAMIC
        or path.parent==R/'packaging-attempts' and path.name.endswith(('.tar.xz','.tar.gz')))


def prior_archive(spec):
    label,commit,relative,filename,expected=spec;folder=P/relative
    manifest,results=read(folder/'manifest.json'),read(folder/'results.json')
    for name in ('manifest.json','results.json'):
        require((folder/name).read_bytes()==subprocess.check_output(['git','show',commit+':'+relative+'/'+name],cwd=P),
            'published predecessor metadata differs: '+label)
    archive=folder/filename
    require(info(archive)==manifest['archive']==results['archive'] and sha(archive)==expected
        and results['complete'] is True,'exact complete predecessor archive required: '+label)
    dependency=dict(id=label+'-'+commit,repository=REPOSITORY,git_commit=commit,
        archive=dict(path=relative+'/'+filename,**info(archive)),
        manifest=dict(path=relative+'/manifest.json',**info(folder/'manifest.json')),
        results=dict(path=relative+'/results.json',**info(folder/'results.json')),
        retrieval='Read exact Git blob git_commit:path; verify SHA-256/bytes before extraction.')
    return dict(folder=folder,archive=archive,manifest=manifest,dependency=dependency)


def audit_receipt(name,phase):
    receipt=read(R/name)
    require(receipt.get('schema')=='multiplicative-source-training-independent-audit/v1'
        and receipt.get('phase')==phase and receipt.get('passed') is True
        and receipt.get('findings')==[] and receipt.get('finding_count')==0
        and type(receipt.get('checks')) is int and receipt['checks']>0,'clean exact audit required: '+name)
    require(receipt['artifacts'][str(R/'independent_audit.py')]==info(R/'independent_audit.py'),
        'independent auditor source changed')
    for path,expected in receipt['artifacts'].items():require(info(path)==expected,'audited artifact changed: '+path)
    authority(receipt)
    return receipt


def aggregate_order(panel):
    generated=panel['generated'];scalars=panel['scalars'];projection=panel['projection']
    require(len(generated['rows'])==len(scalars['rows'])==108 and len(generated['pairs'])==len(scalars['pairs'])==60,
        'full original/permuted order observations required')
    summary={}
    for count in (1,2,4,8):
        grows=[r for r in generated['rows'] if r['clause_count']==count]
        srows=[r for r in scalars['rows'] if r['clause_count']==count]
        result=dict(rows=len(grows),eos_count=sum(r['eos_reached'] for r in grows),
            syntax_valid=sum(r['syntax_valid'] for r in grows),
            exact_target_with_eos=sum(r['exact_target_with_eos'] for r in grows),
            generated_rules=sum(r['generated_rules'] for r in grows),
            ordered_rules_correct=sum(r['ordered_rules_correct'] for r in grows),
            generated_actor_action_pairs_correct=sum(r['actor_action_pairs_correct'] for r in grows),
            raw_head_actor_action_pairs_correct=sum(r['actor_action_pairs_correct'] for r in srows),
            expected_rule_slots=sum(r['expected_rules'] for r in grows))
        for name,rows in [('generated_scalar_correct',grows),('raw_head_scalar_correct',srows)]:
            result[name]={f:sum(r['scalar_correct'][f] for r in rows) for f in ('actor','action','modality','object')}
        summary[str(count)]=result
    equivariance={}
    for label,value in [('generated',generated),('raw_head',scalars)]:
        equivariance[label]={}
        for count in (2,4,8):
            pairs=[row for row in value['pairs'] if row['clause_count']==count]
            equivariance[label][str(count)]={field:{key:sum(pair['equivariance'][field][key] for pair in pairs)
                for key in pairs[0]['equivariance'][field]} for field in ('actor','action','modality','object','actor_action')}
    return dict(by_length=summary,projection_by_length=projection['by_length'],equivariance=equivariance,
        informative_slot_policy='Reference-changing slots reported separately from all slots; references used only after generation.',
        full_logit_distances_by_length={str(count):dict(pairs=sum(p['clause_count']==count for p in scalars['pairs']),
            fixed_l2_mean=sum(p['full_logit_fixed_slot_distance']['l2'] for p in scalars['pairs'] if p['clause_count']==count)
                /sum(p['clause_count']==count for p in scalars['pairs']),
            permuted_l2_mean=sum(p['full_logit_permuted_slot_distance']['l2'] for p in scalars['pairs'] if p['clause_count']==count)
                /sum(p['clause_count']==count for p in scalars['pairs'])) for count in (2,4,8)})


def aggregate_boundaries(panel):
    require(panel['schema']=='causal-source-boundary-trace/v1' and panel['complete'] is True
        and panel['sample_count']==len(panel['rows'])==len(panel['predictions'])==48
        and panel['optimizer_steps']==0 and panel['logits_addition_replay_exact'] is True
        and panel['actual_prefix_argmax_binding'] is True,'complete unchanged boundary replay required')
    events=[event for row in panel['rows'] for event in row['boundaries']]
    require(len(events)==panel['boundary_event_count'],'boundary event inventory differs')
    return dict(sample_count=48,event_count=len(events),rows_without_boundary=sum(not r['boundaries'] for r in panel['rows']),
        eos_count=sum(r['eos_reached'] for r in panel['rows']),
        rows_with_invalid_prefix=sum(r['first_invalid_prefix_position'] is not None for r in panel['rows']),
        visited_completed_rule_counts=dict(sorted(Counter(str(e['completed_rules']) for e in events).items())),
        event_actions=dict(Counter(e['action'] for e in events)),
        count_correction_active_events=sum(e['count_correction_active'] for e in events),
        local_argmax_changed_events=sum(e['local_argmax_changed'] for e in events),
        positive_count_corrections=sum(e['count_correction']>0 for e in events),
        negative_count_corrections=sum(e['count_correction']<0 for e in events),
        unchanged_count_corrections=sum(e['count_correction']==0 for e in events),
        scalar_guidance_overlap_events=sum(e['scalar_guidance_active'] for e in events),
        elapsed_seconds=panel['elapsed_seconds'],wall_seconds_per_span=panel['elapsed_seconds']/48,
        matching_current_postfit_prediction_replay=True,full_counterfactual_rollout_performed=False)


def quality(panel):
    report=panel['report'];fidelity=panel['source_fidelity'];values=panel['source_values'];counts=panel['source_count']
    require(report['complete'] is True and len(panel['predictions'])==48 and values['present_values']==720,
        'complete actual generation and source readouts required')
    authority(report);authority(fidelity)
    return dict(numerical_metrics=report['metrics'],generated=fidelity['metrics'],
        by_length=fidelity['by_length'],by_facet=fidelity['by_facet'],
        raw_auxiliary_source_values=dict(correct=values['correct'],present_values=values['present_values'],
            cross_entropy=values['cross_entropy'],by_length=values['by_length'],
            by_field={key:{k:v for k,v in value.items() if k!='classes'} for key,value in values['by_field'].items()}),
        source_count={key:value for key,value in counts.items() if key!='predictions'})


def main():
    audits={'readiness':audit_receipt('readiness.json','readiness'),'results':audit_receipt('independent-audit.json','results')}
    cache_inventory=read(R/'clause-cache-inventory.json')
    require(cache_inventory.get('schema')=='source-clause-cache-prerequisite-inventory/v1'
        and cache_inventory.get('complete') is True and cache_inventory.get('passed') is True
        and cache_inventory.get('findings')==[] and cache_inventory.get('check_count')==1756
        and all(cache_inventory.get(key) is False for key in ('encoder_executed','model_executed',
            'training_executed','context_input_runtime_implemented','reference_formulas_used_for_segmentation')),
        'clean unexecuted future clause-cache prerequisite required')
    authority(cache_inventory)
    for path,expected in cache_inventory['artifacts'].items():
        require(info(path)==expected,'future clause-cache inventory input changed: '+path)
    doc_receipt=R/'documentation-review.json'
    docs=read(doc_receipt)
    require(docs.get('passed') is True and docs.get('findings')==[] and docs.get('document_sha256')==sha(P/DOC),
        'final documentation binding required')
    attempt=attempt_for(audits['results'],'multiplicative-source-training-comparison/v1')
    summary=read(attempt/'results/summary.json');manifest=read(R/'training-manifest.json');plan=read(R/'training-plan.json')
    require(summary.get('complete') is True and len(summary['runs'])==4 and summary['training_executed'] is True
        and summary['baseline_replay_parity'] is True,'complete four-fit matched training and baseline replay required')
    authority(summary)
    require(summary['workers']==1 and summary['bridge_names']==[] and all(summary[k] is False
        for k in ('legal_ir_evaluate_provers','metric_disk_cache_used','downloads_performed','encoder_executed')),
        'training execution scope differs')
    require(manifest['plan_sha256']==sha(R/'training-plan.json') and plan['input_sha256']==manifest['inputs'],
        'fixed plan/input binding differs')
    require([r['arm'] for r in summary['runs']]==[arm['name']+'-'+str(seed)
        for seed in plan['seed_order'] for arm in plan['arms']]
        and plan['trainable_parameter_count_unchanged'] is True
        and plan['order_augmentation_enabled'] is False
        and plan['generated_boundary_loss_enabled'] is False
        and len({run['trainable_parameter_count'] for run in summary['runs']})==1,
        'matched source-interaction experiment differs')
    sealed=read(attempt/'results/sealed-recipe.json')
    require(sealed['manifest']==manifest and sealed['plan']==plan,'executed recipe differs')
    source=R/'experiment-source';tests_source=read(R/'validated-test-source.json');code=read(R/'code-files.json')
    require(len(code)==len(set(code)) and 7<=len(code)<=12 and DOC in code
        and len(manifest['extensions'])==42 and len(tests_source)==45,'fixed owner/source/test inventory differs')
    for relative,expected in {**manifest['extensions'],**tests_source}.items():
        require(sha(source/relative)==sha(P/relative)==expected,'frozen owner/test changed: '+relative)
    for path,expected in manifest['inputs'].items():require(sha(path)==expected,'frozen input changed: '+path)
    tests=passing_tests(R/'tests-frozen.xml');resource_receipt=resources(attempt,'training')
    prior=[prior_archive(spec) for spec in PRIOR_SPECS]
    files={};original_paths={};referenced={};protected={}

    def add(name,path,expected=None):
        path=absolute(path);observed=info(path);member=PurePosixPath(name)
        require(not member.is_absolute() and '..' not in member.parts and str(member)==name,'unsafe archive member')
        if expected is not None:require(observed==expected,'physical artifact pin differs: '+str(path))
        if str(path) in original_paths:
            require(files[original_paths[str(path)]]['info']==observed,'duplicate artifact differs');return
        require(name not in files,'conflicting archive member: '+name)
        files[name]=dict(path=path,info=observed);original_paths[str(path)]=name

    checkpoint=read(R/'before.json')['checkpoint']
    require(info(checkpoint['path'])=={k:checkpoint[k] for k in ('sha256','bytes')},'protected checkpoint changed')
    protected[checkpoint['path']]=dict(checkpoint,role='protected_unmodified_not_executed_input',bundled=False)

    def retain(path,expected=None):
        path=absolute(path);observed=info(path)
        if expected is not None:require(observed==expected,'retained input pin differs: '+str(path))
        if str(path) in original_paths:return
        if path.is_relative_to(R):add('validation/'+path.relative_to(R).as_posix(),path,observed);return
        if str(path) in protected:
            require({k:protected[str(path)][k] for k in ('sha256','bytes')}==observed,'protected external artifact changed');return
        for old in prior:
            if path in (old['folder']/'manifest.json',old['folder']/'results.json'):
                add('predecessor-public/'+old['dependency']['id']+'/'+path.name,path,observed);return
            if path==old['archive']:
                referenced[str(path)]=dict(dependency_id=old['dependency']['id'],kind='archive_itself',**observed);return
            member=old['manifest']['original_artifact_archive_paths'].get(str(path))
            if member is not None:
                require(old['manifest']['members'][member]==observed,'predecessor member differs')
                referenced[str(path)]=dict(dependency_id=old['dependency']['id'],kind='archive_member',member=member,**observed);return
        require(path.is_relative_to(P) and path.suffix in ('.py','.json','.xml','.log') and observed['bytes']<=4194304,
            'unmapped historical input requires explicit review: '+str(path))
        add('historical/'+path.relative_to(P).as_posix(),path,observed)

    producers=dict(prior[0]['manifest']['validated_producer_source_sha256'])
    require(len(producers)==106,'exact106-source predecessor required')
    for relative,expected in manifest['extensions'].items():
        require(relative not in producers or producers[relative]==expected
            or relative in ('ipfs_datasets_py/logic/formalization/autoencoder/long_span_source_value_training.py',
                'ipfs_datasets_py/logic/formalization/autoencoder/generated_boundary_training.py',
                'ipfs_datasets_py/logic/formalization/autoencoder/shared_slot_source_decoder_experiment.py'),
            'unreviewed prior numerical source change')
        producers[relative]=expected
    producer_files={relative:(source/relative if (source/relative).is_file() else S/relative) for relative in producers}
    for scoped,expected in summary['source_dependencies'].items():
        scope,relative=scoped.split(':',1);require(scope in ('extension','dependency'),'unknown producer source scope')
        path=(source if scope=='extension' else S)/relative
        require(sha(path)==expected and (relative not in producers or producers[relative]==expected),'executed source differs')
        producers[relative]=expected;producer_files[relative]=path
    for relative,path in producer_files.items():require(sha(path)==producers[relative],'producer changed: '+relative)
    imports=read(R/'test-import-provenance.json');require(imports['pytest_returncode']==0,'frozen test imports failed')
    for entry in imports['modules'].values():
        path=Path(entry['path']);root=source if path.is_relative_to(source) else S
        require(path.is_relative_to(root) and producers.get(path.relative_to(root).as_posix())==entry['sha256']==sha(path),
            'test producer escaped frozen tree')
    for relative in sorted(set(code)|set(tests_source)|set(producers)):
        path=producer_files.get(relative,source/relative if relative in tests_source else P/relative)
        expected=producers.get(relative,tests_source.get(relative))
        add('source/'+relative,path,None if expected is None else dict(sha256=expected,bytes=path.stat().st_size))
        if (P/relative).is_file() and info(P/relative)==files['source/'+relative]['info']:
            original_paths[str((P/relative).absolute())]='source/'+relative
    for old in prior:
        for name in ('manifest.json','results.json'):retain(old['folder']/name)
    for path,expected in manifest['inputs'].items():retain(path,dict(sha256=expected,bytes=Path(path).stat().st_size))
    for path in sorted(R.rglob('*')):
        if path.is_file() and not excluded(path):retain(path)
    closure_receipts=list(audits.values())+[cache_inventory]
    if (R/'static-review.json').exists():
        review=read(R/'static-review.json')
        require(review.get('passed') is True and review.get('findings')==[],'clean static review required')
        closure_receipts.append(review)
    for receipt in closure_receipts:
        for path,expected in receipt['artifacts'].items():retain(path,expected)
    for path in sorted(R.glob('*arithmetic.py')):retain(path)
    require(all({str(absolute(p)) for p in a['artifacts']}<=set(original_paths)|set(referenced)|set(protected)
        for a in closure_receipts),'audit artifact closure incomplete')
    require(not set(original_paths)&set(referenced),'physical and referenced artifact overlap')
    for old in prior:
        needed={r['member']:r for r in referenced.values() if r['kind']=='archive_member'
            and r['dependency_id']==old['dependency']['id']}
        with tarfile.open(old['archive'],'r:*') as archive:
            checked=set()
            for member in archive:
                if member.name not in needed:continue
                require(member.isfile(),'predecessor member must be regular');data=archive.extractfile(member).read()
                require(dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))==
                    {k:needed[member.name][k] for k in ('sha256','bytes')},'predecessor member bytes differ')
                checked.add(member.name)
            require(checked==set(needed),'predecessor archive member absent')

    arms=[];state_count=panel_count=0
    for run in summary['runs']:
        folder=attempt/'results'/run['arm'];report=read(folder/'training.json')
        parity=read(folder/'initial-parity.json')
        require(parity==run['initial_parity'] and all(parity.get(k) is True for k in
            ('complete','parameter_values_equal','inherited_buffers_equal','initial_greedy_predictions_equal')),
            'initial source-interaction parity differs')
        require(run['recipe']['slot_interaction'] in ('additive','additive_multiplicative')
            and run['recipe']['order_augmentation'] is False
            and run['recipe']['generated_boundary_weight']==0.
            and 'order_augmentation' not in report and 'generated_boundary_weight' not in report
            and all('generated_boundary' not in update for update in report['committed_updates']),
            'unplanned training augmentation or boundary loss')
        require(report==run['training'] and run['budget_completed'] is True
            and report['optimizer_steps']==340 and report['row_presentations']==2440
            and report['valid_target_token_presentations']==225840 and report['source_value_presentations']==25600
            and report['count_training_row_presentations']==2440 and report['stopped_reason']=='epochs_completed',
            'complete matched training exposure required')
        authority(report);states={};controls={};prediction_controls={}
        for role in ('initial','selected','last-attempt'):
            path=folder/(role+'-state.json');state=read(path)
            require(state['schema']=='private-multiplicative-source-state/v1' and state['role']==role,
                'complete typed state role required')
            authority(state);state_count+=1
            states[role]=dict(path=str(path),**info(path),tensor_sha256=state['tensor_sha256'])
            if role=='initial':continue
            controls[role]={};prediction_controls[role]={}
            for label,split,control in plan['postfit_controls']:
                path=folder/role/('evaluation-'+label+'.json');panel=read(path)
                require(panel['execution']['kind']==('source_shuffle' if control=='cross_length_shuffle' else control),
                    'source control execution differs')
                controls[role][label]=dict(artifact=dict(path=str(path),**info(path)),**quality(panel))
                prediction_controls[role][label]=panel['predictions'];panel_count+=1
        mechanism=folder/'last-attempt';boundaries={}
        for split,label in [('train','training'),('validation','validation')]:
            trace=read(mechanism/('boundary-'+split+'.json'))
            keys=('id','token_ids','eos_reached','generation_status')
            require(trace['predictions']==[{k:r[k] for k in keys} for r in prediction_controls['last-attempt'][label]],
                'actual boundary trace differs from same final-state postfit predictions')
            boundaries[split]=aggregate_boundaries(trace)
        rejection=Counter(reason for epoch in report['history'] for reason in epoch['rejection_reasons'])
        order=aggregate_order(read(mechanism/'order-pairs.json'))
        arms.append(dict(arm=run['arm'],seed=run['seed'],recipe=run['recipe'],
            selected_epoch=report['selected_epoch'],last_complete_attempt_is_selected=report['last_complete_attempt_is_selected'],
            optimizer_steps=340,decoder_row_presentations=2440,count_row_presentations=2440,
            target_token_presentations=225840,scalar_label_presentations=25600,
            rejection_reason_counts=dict(rejection),states=states,controls=controls,
            training_call_elapsed_seconds=run['training_call_elapsed_seconds'],trainable_parameter_count=run['trainable_parameter_count'],
            arm_elapsed_seconds=run['elapsed_seconds'],postfit_elapsed_seconds=run['postfit_elapsed_seconds'],
            baseline_replay=run['baseline_replay'],
            initial_parity={k:v for k,v in parity.items() if k not in ('reference','observed')},
            initial_parity_artifact=dict(path=str(folder/'initial-parity.json'),**info(folder/'initial-parity.json')),
            order_augmentation_enabled=False,generated_boundary_auxiliary_loss_enabled=False,
            postfit_order=order,postfit_boundaries=boundaries,**FALSE))
    require(state_count==12 and panel_count==40,'all12typed states and40controls required')
    outputs=[str((E/name).relative_to(P)) for name in ('results.json','manifest.json','evidence.tar.xz')]
    write_new(R/'owned-files.json',code+outputs);retain(R/'owned-files.json')
    require(not E.exists() or not any(E.iterdir()),'public evidence destination must be fresh')
    E.mkdir(parents=True,exist_ok=True);archive=E/'evidence.tar.xz'
    with archive.open('xb') as stream:
        with lzma.LZMAFile(stream,mode='wb',format=lzma.FORMAT_XZ,preset=6) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as bundle:
                for name,entry in sorted(files.items()):
                    require(info(entry['path'])==entry['info'],'physical input changed before archive')
                    header=tarfile.TarInfo(name);header.size=entry['info']['bytes'];header.mode=0o644;header.mtime=0
                    with entry['path'].open('rb') as data:bundle.addfile(header,data)
        stream.flush();os.fsync(stream.fileno())
    require(all(info(e['path'])==e['info'] for e in files.values()),'physical artifact changed during packaging')
    require(all(info(p)=={k:e[k] for k in ('sha256','bytes')} for p,e in {**referenced,**protected}.items()),
        'historical/protected artifact changed during packaging')
    archive_info=info(archive);require(archive_info['bytes']<=MAX_ARCHIVE_BYTES,'archive exceeds90MB; retain all raw observations')
    metadata=dict(archive_filename='evidence.tar.xz',archive_compression='xz',xz_preset=6,archive_standalone=False,
        archive_dependencies=[x['dependency'] for x in prior],referenced_artifacts=referenced,
        protected_external_artifacts=protected,
        dependency_scope='All new training states and raw observations retained; exact previous Git archive members bind original and augmented inputs and reference fits.',
        reproducibility_scope='Artifact closure and original-path mapping; Python/host libraries and hardware are external. Encoder not executed in this training experiment.')
    write_new(E/'manifest.json',dict(schema='decoder-multiplicative-source-training-archive/v1',archive=archive_info,
        members={name:e['info'] for name,e in files.items()},original_artifact_archive_paths=original_paths,
        validated_producer_source_sha256=producers,archive_maximum_bytes=MAX_ARCHIVE_BYTES,**metadata,**FALSE))
    paired_validation=[]
    for seed in plan['seed_order']:
        pair={}
        for variant in ('baseline','multiplicative'):
            arm=next(a for a in arms if a['seed']==seed and a['recipe']['name']==variant)
            panel=arm['controls']['last-attempt']['validation']
            pair[variant]=dict(sequence_cross_entropy=panel['numerical_metrics']['token_cross_entropy'],
                generated_scalar_matches=sum(panel['by_facet'][k]['correct'] for k in ('actor','action','modality','object')),
                scalar_positions=720,raw_auxiliary_scalar_matches=panel['raw_auxiliary_source_values']['correct'],
                exact_documents=panel['generated']['ordered_exact'],eos=panel['generated']['eos_count'],
                syntax=panel['generated']['syntax_valid'],generated_rules=panel['generated']['generated_rules'],
                missing_reference_rules=panel['generated']['whole_rules_missing'],
                duplicate_rules=panel['generated']['duplicate_rules'],fit_seconds=arm['training_call_elapsed_seconds'])
        paired_validation.append(dict(seed=seed,**pair))
    final_validation_exact=[arm['controls']['last-attempt']['validation']['generated']['ordered_exact'] for arm in arms]
    outcome=('No accepted reconstruction improvement: every fit selected epoch 0 and every final validation panel remained 0/48 exact. '
        'The tied source/slot gain changed reconstruction behavior without passing the unchanged gates.'
        if all(arm['selected_epoch']==0 for arm in arms) and not any(final_validation_exact)
        else 'Parameter-equivalent multiplicative-source training completed; generated fidelity, source controls and unchanged strict selection results are reported per arm.')
    if all(p['multiplicative']['sequence_cross_entropy']>p['baseline']['sequence_cross_entropy']
        and p['multiplicative']['generated_scalar_matches']<p['baseline']['generated_scalar_matches'] for p in paired_validation):
        outcome+=' The multiplicative variant worsened validation sequence CE and generated scalar recovery in both seeds.'
    results=dict(schema='decoder-multiplicative-source-training-results/v1',complete=True,
        outcome=outcome,
        training_fit_count=4,arms=arms,typed_state_count=12,postfit_control_panel_count=40,
        paired_final_validation=paired_validation,
        initial_state_count=4,selected_final_state_count=8,baseline_training_replay_verified=True,
        trainable_parameter_count_unchanged=True,initial_float_parameters_and_greedy_predictions_equal=True,
        interaction_formula='u=W*x+b; h_i=tanh(u*(1+e_i)+e_i)',
        order_augmentation_enabled=False,generated_boundary_auxiliary_loss_enabled=False,
        selected_checkpoint_epochs=[arm['selected_epoch'] for arm in arms],
        training_rows=48,validation_rows=48,effective_training_sources=48,postfit_order_sources=108,
        encoder_context_tokens=512,decoder_output_limit=512,generation_temperature=0,
        training_executed=True,generation_executed=True,weight_selection_performed=True,encoder_executed=False,
        dimensions_actually_trained=[384],historical_8d_teacher_modified=False,actual_768d_execution_performed=False,
        independent_diagnostic_analysis=audits['results'].get('analysis',audits['results'].get('records')),
        future_clause_cache_prerequisite=dict(receipt_sha256=sha(R/'clause-cache-inventory.json'),
            generator_sha256=sha(R/'clause_cache_inventory.py'),checks=cache_inventory['check_count'],
            splits={split:{k:v for k,v in details.items() if type(v) in (str,int,float,bool)}
                for split,details in cache_inventory['splits'].items()},
            split_overlap_counts=cache_inventory['split_overlap_counts'],
            publication_binding=cache_inventory['publication_binding'],
            source_segmentation=cache_inventory['source_segmentation'],
            provenance_scope=cache_inventory['provenance_scope'],limitations=cache_inventory['limitations'],
            used_by_current_models=False,context_input_runtime_implemented=False,
            encoder_executed=False,training_executed=False,qualified=False,admitted=False),
        candidate_sha256={p:sha(P/p) for p in code},independent_audit_sha256=sha(R/'independent-audit.json'),
        independent_audits={phase:dict(path=str(R/name),sha256=sha(R/name),checks=a.get('checks',a.get('checked_count')),
            findings=a['findings'],audited_artifacts=len(a['artifacts'])) for phase,name,a in
            [('readiness','readiness.json',audits['readiness']),('results','independent-audit.json',audits['results'])]},
        tests=tests,test_file_count=len(tests_source),
        test_scope=f'Fresh frozen {len(tests_source)}-file suite; historical receipts are not recounted.',
        telemetry=dict(device='cpu',workers=1,bridge_names=[],legal_ir_evaluate_provers=False,
            legal_ir_bridge_evaluation_performed=False,bridge_on_evaluate_seconds=None,metric_disk_cache_used=False,
            verified_paragraph_embedding_cache_used=True,encoder_executed=False,
            fit_call_wall_seconds_total=sum(arm['training_call_elapsed_seconds'] for arm in arms),
            runner_elapsed_seconds=summary['elapsed_seconds'],resources=resource_receipt,
            workload='Cached-embedding private decoder training; four matched fits with equal parameter count and identical reference/update budgets; no order augmentation or generated-boundary auxiliary loss.'),
        limitations=['Previously exposed authored development corpus; original validation preserved, not a fresh holdout.',
            'The candidate ties slot gain and bias using the same parameters; this tests that specific interaction, not all multiplicative architectures.',
            'Raw scalar scores, generated relational binding, duplicate counts, EOS and whole-document exactness are distinct.',
            'No order augmentation or generated-boundary auxiliary loss ran; source-only inference has no target count or forced closure.',
            'No global optimum, native-family qualification, Lake build, production promotion or Constitution formalization is established.'],
        archive=archive_info,**metadata,**FALSE)
    require(len(json.dumps(results))<2500000,'public summary duplicates excessive raw observations')
    write_new(E/'results.json',results)
    with tarfile.open(archive,'r:xz') as bundle:
        members=bundle.getmembers();require(len(members)==len(files) and {m.name for m in members}==set(files),'sealed member inventory differs')
        for member in members:
            require(member.isfile(),'sealed member not regular');data=bundle.extractfile(member).read()
            require(dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))==files[member.name]['info'],
                'sealed member bytes differ')
    print(json.dumps(dict(archive=archive_info,members=len(files),references=len(referenced),
        producers=len(producers),test_files=len(tests_source),owned_files=len(code)+3,typed_states=12,control_panels=40,
        results=info(E/'results.json'),manifest=info(E/'manifest.json'))))


if __name__=='__main__':main()
