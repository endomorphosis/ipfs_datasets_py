"""Independent saved-output audit; no model/encoder/training/prover execution.

The previous authenticated stdlib selection/fidelity arithmetic is reused. New
checks cover matched parameter geometry, the extra immutable integer mode,
actual saved head arithmetic, source controls and ordered actor/action binding.
This does not reconstruct gradient updates or assert native qualification.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
import math
import struct
import sys
sys.dont_write_bytecode = True
R = Path(__file__).resolve().parent
P = R.parents[2]
OLD = P/'workspace/test-logs/decoder-order-boundary-training-20261003'
SHARED = P/'workspace/test-logs/decoder-shared-slot-source-20261003'
ARITHMETIC_SHA = '459eed5588f46b88550ae8568e756c11160303c1e74ee736d36e56594c6d793c'
findings = []; artifacts = {}; checks = 0


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def raw(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()
def digest(value): return hashlib.sha256(raw(value)).hexdigest()
def check(value, label, detail=None):
    global checks
    checks += 1
    if not value: findings.append(dict(label=label, detail=detail))
def read(path):
    path = Path(path); data = path.read_bytes()
    artifacts[str(path)] = dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))
    return json.loads(data)


helper = R/'prior_training_arithmetic.py'
check(sha(helper) == ARITHMETIC_SHA, 'authenticated_previous_stdlib_audit')
spec = importlib.util.spec_from_file_location('_matched_source_arithmetic', helper)
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
prior.check = check; prior.read = read; prior.leaf.check = check
close = prior.close


def tensor_digest(values):
    result = hashlib.sha256()
    for name, value in sorted(values.items()):
        if name in ('head_initialization_seed', 'slot_interaction_version'):
            if type(value) is not int: raise ValueError('architecture buffer must remain scalar int64')
            dtype, data = 'torch.int64', struct.pack('<q', value)
        else: dtype, data = 'torch.float32', prior.leaf.tensor_bytes(value)
        result.update(raw([name, dtype, prior.leaf.shape(value)])); result.update(data)
    return result.hexdigest()


def common(args):
    manifest = read(args.manifest); plan = read(args.plan)
    check(sha(args.plan) == manifest['plan_sha256'] and plan['input_sha256'] == manifest['inputs'], 'pins/plan_inputs')
    for path, expected in manifest['inputs'].items():
        check(sha(path) == expected, 'pins/input/'+path)
        artifacts[path] = dict(sha256=expected, bytes=Path(path).stat().st_size)
    for rel, expected in manifest['extensions'].items():
        path = args.source/rel; check(sha(path) == expected, 'pins/source/'+rel)
        artifacts[str(path)] = dict(sha256=expected, bytes=path.stat().st_size)
    fixed = dict(schema='multiplicative-source-training-plan/v1', seed_order=[1729, 2718], representation_dimension=384,
        hidden_width=64, candidate_hidden_formula='tanh(source*(1+slot)+slot)', trainable_parameter_count_unchanged=True,
        candidate_extra_state='frozen_int64_slot_interaction_version_1', order_augmentation_enabled=False,
        generated_boundary_loss_enabled=False, expected_optimizer_steps_per_arm=340,
        expected_training_token_presentations_per_arm=225840, expected_count_presentations_per_arm=2440,
        expected_source_value_presentations_per_candidate=25600, fixed_encoder_context_tokens=512,
        fixed_decoder_output_limit=512, temperature=0, batch_size=8, learning_rate=.001, max_seconds_per_arm=180,
        source_value_weight=.25, cardinality_weight=.25, source_only_generation=True,
        generation_reference_count_access=False, generation_reference_prefix_access=False,
        full_vocabulary_retained=True, syntax_forced=False, closure_forced=False, original_training_rows=48,
        exposed_validation_rows=48, encoder_executed=False, selection_unchanged=True,
        native_qualification=False, production_promotion_allowed=False)
    for key, value in fixed.items(): check(plan.get(key) == value, 'plan/'+key)
    expected = [dict(name=n, slot_interaction=m, order_augmentation=False, generated_boundary_weight=0.)
        for n, m in [('baseline', 'additive'), ('multiplicative', 'additive_multiplicative')]]
    check(plan['arms'] == expected, 'plan/only_matched_head_interaction_changes')
    static = read(R/'static-review.json')
    check(static.get('passed') is True and static.get('findings') == [], 'peer/frozen_trainer_guardian_review')
    for path, item in static['artifacts'].items():
        p = Path(path); p = p if p.is_absolute() else P/p
        expected_hash = item['sha256'] if type(item) is dict else item
        check(sha(p) == expected_hash, 'peer/unchanged_review_artifact/'+str(p))
    oldaudit = read(OLD/'independent-audit.json')
    check(oldaudit['passed'] and oldaudit['finding_count'] == 0, 'predecessor/audited_evidence')
    corpus = read(manifest['paragraphs']); donor = read(manifest['donor']); cached = read(manifest['embeddings'])
    prep = read(manifest['order_preparation']); enc = read(manifest['order_embeddings']); shared = read(manifest['shared_summary'])
    original = {r['id']:r for r in corpus['train']}; prepared = {r['id']:r for r in prep['rows']}
    variants = {key:[] for key in original}
    for row in prep['rows']: variants[row['order_diagnostic']['parent_id']].append(row['id'])
    return dict(manifest=manifest, plan=plan, corpus=corpus, donor=donor, preparation=prep, prepared=prepared,
        original=original, variants=variants, vectors={r['input_id']:r['vector'] for r in cached['rows']},
        native={r['input_id']:r['vector'] for r in enc['observations']['main']}, prior={r['arm']:r for r in shared['runs']})


def state_check(path, report, role, initial, old_initial, mode, ctx, label):
    state = read(path); prior.authority(state, label); values = state['model_state']; old = old_initial['model_state']
    extra = {'slot_interaction_version'} if mode == 'additive_multiplicative' else set()
    check(state['schema'] == 'private-multiplicative-source-state/v1' and state['role'] == role
        and state['codec'] == ctx['donor']['codec'], 'state/schema_role_codec/'+label)
    check(set(values) == set(old)|extra and (not extra or type(values['slot_interaction_version']) is int
        and values['slot_interaction_version'] == 1), 'state/only_expected_int64_mode/'+label)
    check(digest(values) == state['weights_sha256'] and tensor_digest(values) == state['tensor_sha256'], 'state/typed_hashes/'+label)
    expected = report['initial_weights_sha256'] if role == 'initial' else report['selected_weights_sha256'] if role == 'selected' else report['last_complete_attempt_weights_sha256']
    check(state['tensor_sha256'] == expected, 'state/report_binding/'+label)
    actual = prior.canonical(state); base = prior.canonical(old_initial)
    fixed = [k for k in base if k.startswith(('projection_down.', 'projection_up.'))
        or k in ('source_mean', 'source_scale', 'count_prior_logits', 'head_initialization_seed')]
    check(all(actual[k] == base[k] for k in fixed), 'state/frozen_projection_preprocessing_seed/'+label)
    if role == 'initial': check(all(values[k] == old[k] for k in old), 'state/all_common_initial_tensors_identical/'+label)
    if initial is not None: check(state['architecture'] == initial['architecture'], 'state/architecture_unchanged_during_training/'+label)
    if not extra: check(state['architecture'] == old_initial['architecture'], 'state/default_architecture_exact/'+label)
    else:
        desc = state['architecture']
        check(desc['slot_interaction'] == mode and desc['slot_interaction_version'] == 1
            and desc['source_slot_multiplication'] is True, 'state/explicit_interaction_architecture/'+label)
        check(desc['source_value_parameter_count'] == old_initial['architecture']['source_value_parameter_count']
            and desc['source_value_parameter_names'] == old_initial['architecture']['source_value_parameter_names'],
            'state/parameter_equivalent_head/'+label)
    return state


def decode(tokens, vocab):
    try:
        doc = json.loads(''.join(vocab[i] for i in tokens), object_pairs_hook=prior.unique)
        return doc['rules'] if type(doc) is dict and set(doc) == {'rules'} and type(doc['rules']) is list and all(prior.valid_rule(r) for r in doc['rules']) else []
    except (ValueError, TypeError): return []


def audit_order(observed, paired, state, ctx, label):
    """Recompute saved affine/tanh head scores in stdlib float64, not a model run."""
    values = prior.canonical(state); vocab = ctx['donor']['codec']['target_vocabulary']; size = len(vocab)
    check(observed['rows'] == len(observed['predictions']) == 108 and observed['model_tensor_sha256'] == state['tensor_sha256'], 'order/complete_saved_observations/'+label)
    weight = values['source_value_head.source_projection.weight']; bias = values['source_value_head.source_projection.bias']
    slots = values['source_value_head.slot_embeddings']; readout = values['source_value_head.field_readout.weight']; rbias = values['source_value_head.field_readout.bias']
    mean, scale = values['source_mean'], values['source_scale']; mul = 'slot_interaction_version' in values
    original = set(ctx['preparation']['original_ids']); groups = {'original_training':Counter(), 'changed_order_training_components':Counter()}
    grows = {r['id']:r for r in paired['generated']['rows']}; hrows = {r['id']:r for r in paired['scalars']['rows']}
    max_error = 0.; fields = ('actor', 'action', 'modality', 'object')
    for pred in observed['predictions']:
        key = pred['id']; source = observed['projected_vectors'][key]; features = [(x-m)/scale for x,m in zip(source, mean)]
        u = [math.fsum(w*x for w,x in zip(row, features))+b for row,b in zip(weight, bias)]
        actual = observed['scalar_logits'][key]; heads = []
        for slot, saved in zip(slots, actual):
            hidden = [math.tanh(x*(1.+e)+e if mul else x+e) for x,e in zip(u, slot)]
            logits = [math.fsum(w*x for w,x in zip(row, hidden))+b for row,b in zip(readout, rbias)]
            for f, scores in enumerate(saved):
                expected = logits[f*size:(f+1)*size]
                max_error = max(max_error, max(abs(a-b) for a,b in zip(expected, scores)))
                check(close(expected, scores, 6e-5), 'head/saved_full_vocabulary_arithmetic/'+label+'/'+key+'/'+str(len(heads))+'/'+fields[f])
            head = {}
            for field, scores in zip(fields, saved):
                token = max(range(len(scores)), key=scores.__getitem__)
                try: value = json.loads(vocab[token]) if token >= 3 else None
                except ValueError: value = None
                head[field] = value if type(value) is str else None
            heads.append(head)
        gold = ctx['prepared'][key]['target']['rules']; generated = decode(pred['token_ids'], vocab)
        pair_count = lambda rows: sum(i < len(rows) and all(rows[i].get(k) == rule[k] for k in ('actor', 'action')) for i,rule in enumerate(gold))
        gp, hp = pair_count(generated), pair_count(heads)
        check(grows[key]['actor_action_pairs_correct'] == gp and hrows[key]['actor_action_pairs_correct'] == hp, 'order/actual_joint_actor_action/'+label+'/'+key)
        group = groups['original_training' if key in original else 'changed_order_training_components']
        group.update(rows=1, expected_pair_slots=len(gold), generated_pair_correct=gp, raw_head_pair_correct=hp,
            exact_with_eos=int(pred['eos_reached'] and generated == gold))
    pairs = paired['scalars']['pairs']; check(len(pairs) == 60, 'order/all_changed_source_pairs/'+label)
    return dict(groups={k:dict(v) for k,v in groups.items()}, order_pairs=len(pairs),
        full_logits_closer_to_fixed_positions=sum(r['full_logit_fixed_slot_distance']['l2'] < r['full_logit_permuted_slot_distance']['l2'] for r in pairs),
        saved_head_float64_max_absolute_difference=max_error, head_arithmetic_tolerance=6e-5,
        permutations_used_for_training=False)


def results(args, ctx):
    root = args.results; summary = read(root/'summary.json'); prior.authority(summary, 'summary')
    check(summary['complete'] and [r['arm'] for r in summary['runs']] == [n+'-'+str(s) for s in (1729,2718) for n in ('baseline','multiplicative')], 'results/four_fixed_fits')
    check(summary['baseline_replay_parity'] and summary['dimensions_actually_trained'] == [384] and summary['encoder_executed'] is False, 'results/scope')
    cache = set(); out = {}; parameters = {}
    for run in summary['runs']:
        label = run['arm']; folder = root/label; report = read(folder/'training.json'); check(report == run['training'], 'training/persisted_report/'+label)
        detail = prior.training(run, ctx); seed = run['seed']; mode = run['recipe']['slot_interaction']
        oldfolder = SHARED/'training-r1/results'/('shared-'+str(seed)); old_initial = read(oldfolder/'initial-state.json')
        states = {}; initial = None
        for role in ('initial','selected','last-attempt'):
            states[role] = state_check(folder/(role+'-state.json'), report, role, initial, old_initial, mode, ctx, label+'/'+role)
            if role == 'initial': initial = states[role]
        parity = read(folder/'initial-parity.json')
        check(parity == run['initial_parity'] and parity['complete'] and parity['parameter_values_equal'] and parity['inherited_buffers_equal']
            and parity['reference']['predictions'] == parity['observed']['predictions'], 'initial/full_greedy_parity/'+label)
        check(parity['baseline_tensor_sha256'] == old_initial['tensor_sha256'] and parity['candidate_tensor_sha256'] == initial['tensor_sha256'], 'initial/typed_parity_binding/'+label)
        panels = {}; rawpanels = {}
        for role in ('selected','last-attempt'):
            panels[role] = {}; rawpanels[role] = {}
            for name,split,kind in prior.CONTROLS:
                panel = read(folder/role/('evaluation-'+name+'.json')); rawpanels[role][name] = panel
                panels[role][name] = prior.panel_check(panel, ctx['corpus'][split], ctx['vectors'], kind, ctx['donor']['codec'], label+'/'+role+'/'+name, cache)
                if name == 'validation':
                    expected = report['selected'] if role == 'selected' else report['last_complete_attempt']
                    check(panel['report']['metrics'] == expected['numerical'], 'postfit/selection_report_binding/'+label+'/'+role)
        if mode == 'additive':
            previous = deepcopy(ctx['prior']['shared-'+str(seed)]['training']); current = deepcopy(report)
            current['config']['max_seconds'] = 90
            for value in (previous,current): value.pop('elapsed_seconds',None)
            check(current == previous, 'baseline/exact_all_training_fields_except_time_timeout/'+label)
            for role in ('selected','last-attempt'):
                oldstate = read(oldfolder/(role+'-state.json')); check(states[role]['model_state'] == oldstate['model_state'], 'baseline/exact_final_state/'+label+'/'+role)
                for name,_,_ in prior.CONTROLS:
                    previous = read(oldfolder/role/('evaluation-'+name+'.json'))
                    check(rawpanels[role][name]['predictions'] == previous['predictions'], 'baseline/exact_prediction_envelopes/'+label+'/'+role+'/'+name)
        for split,name in (('train','training'),('validation','validation')):
            trace = read(folder/'last-attempt'/('boundary-'+split+'.json'))
            check(trace['predictions'] == [{k:p[k] for k in ('id','token_ids','generation_status','eos_reached')} for p in rawpanels['last-attempt'][name]['predictions']], 'mechanism/exact_boundary_replay/'+label+'/'+split)
        observed = read(folder/'last-attempt/order-observations.json'); pairs = read(folder/'last-attempt/order-pairs.json')
        order = audit_order(observed, pairs, states['last-attempt'], ctx, label)
        parameters[label] = run['trainable_parameter_count']
        out[label] = dict(training=detail, controls=panels, order_binding=order, selected_epoch=report['selected_epoch'],
            fit_elapsed_seconds=run['training_call_elapsed_seconds'], trainable_parameter_count=run['trainable_parameter_count'],
            auxiliary_head_original_training={key:rawpanels['last-attempt']['training']['source_values'][key] for key in ('accuracy','cross_entropy')})
    check(len(set(parameters.values())) == 1, 'matched_all_trainable_parameter_counts')
    return dict(runs=out, distinct_fidelity_panels_audited=len(cache), limits=[
        'Saved arithmetic checks do not execute models or replay gradients.',
        'The exposed validation set is not a fresh holdout; changed-order sources were not used for these fits.',
        'Head logits are independently recomputed with float64 arithmetic and a declared float32 comparison tolerance.',
        'Raw auxiliary accuracy or order-pair scores cannot override full-generation per-length/facet selection.',
        'No native logic-family or Lake validation occurs; no proof admission or production promotion follows.'])


def main():
    parser = argparse.ArgumentParser()
    for name in ('source','manifest','plan','output'): parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--results', type=Path); args = parser.parse_args()
    ctx = common(args); analysis = results(args,ctx) if args.results else None
    check('torch' not in sys.modules and 'transformers' not in sys.modules, 'auditor/no_model_imports')
    for path in (Path(__file__).resolve(), helper, R/'audit_leaf_arithmetic.py'):
        artifacts[str(path)] = dict(sha256=sha(path), bytes=path.stat().st_size)
    value = dict(schema='multiplicative-source-training-independent-audit/v1', phase='results' if args.results else 'readiness',
        created_at_utc=datetime.now(timezone.utc).isoformat(), passed=not findings, checks=checks, finding_count=len(findings),
        findings=findings, artifacts=artifacts, analysis=analysis, manifest_sha256=sha(args.manifest), plan_sha256=sha(args.plan),
        models_executed=False, training_executed=False, encoder_executed=False, qualified=False, admitted=False,
        lake_executed=False, fresh_holdout=False)
    args.output.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n')
    print(json.dumps(dict(passed=value['passed'], checks=checks, findings=len(findings), output=str(args.output))))
    if findings: sys.exit(1)


if __name__ == '__main__': main()
