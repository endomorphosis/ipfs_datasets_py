"""Inventory existing clause vectors using source text only; no model imports.

This is a future-input prerequisite. Literal paragraph segmentation is computed
without target tokens, formulas, component IDs, or reference clause counts.
Published component records are used afterward to authenticate that inventory.
"""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path

R=Path(__file__).resolve().parent
P=R.parents[2]
D=P/'workspace/test-logs/decoder-distillation-limits-20261002'
C=D/'prepared-r1'
CORPUS=D/'smoke-r2/results/paragraphs.json'
PUB=P/'docs/implementation/reports/evidence/decoder-projected-source-20261003/manifest.json'
PINS={
    'manifest.json':'9d89b1898b4cc06f5ce52491f148ab31c29620e9db8a6463611d689640924ab0',
    'metadata384.json':'de5ef43e8d81be193993258177b706a92bc65ac5a9cb488af327db921ed37d86',
    'prepared384-train.json':'7452be739ba851899e6a3374caeceeca5db08e043073e073e36bc9ea3222214e',
    'prepared384-validation.json':'26eb933cf0e7266b9d822c5404ff4002b410f259df58669b1f94aa9f673f0002',
}
artifacts={}
checks=[]


def sha(data):return hashlib.sha256(data).hexdigest()
def digest(value):return sha(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def source_sha(text):return sha(text.encode())
def normalized_sha(text):return source_sha(' '.join(text.casefold().split()))
def read(path,expected=None):
    data=Path(path).read_bytes();observed=sha(data)
    check(expected is None or observed==expected,'pinned_file/'+str(path))
    artifacts[str(path)]=dict(sha256=observed,bytes=len(data))
    return json.loads(data)
def check(value,label):
    checks.append(dict(check=label,passed=bool(value)))
    if not value:raise ValueError(label)


def segment_source(source_text,cache_by_text):
    """All selection inputs are observable text and an exact source-keyed cache."""
    pieces=source_text.split('\n\n')
    check(all(pieces),'segmentation/no_empty_literal_clause')
    result=[];offset=0
    for piece in pieces:
        check(piece in cache_by_text,'segmentation/exact_text_cache_hit')
        cached=cache_by_text[piece]
        result.append(dict(id=cached['id'],source_sha256=source_sha(piece),
            embedding_sha256=digest(cached['input']),char_start=offset,char_end=offset+len(piece),
            byte_start=len(source_text[:offset].encode()),byte_end=len(source_text[:offset+len(piece)].encode())))
        offset+=len(piece)+2
    return result


def main():
    manifest=read(C/'manifest.json',PINS['manifest.json'])
    metadata=read(C/'metadata384.json',PINS['metadata384.json'])
    check(manifest['schema']=='decoder-distillation-data-preparation/v1'
        and metadata['schema']=='decoder-distillation-original-data-provenance/v1','cache/expected_receipts')
    public=read(PUB,'dabc92affb67ff518238e22717866d997b4baa6bfb5edf473e55f087b8e4adc3')
    member=public['original_artifact_archive_paths'][str(CORPUS)]
    binding=public['members'][member]
    corpus=read(CORPUS,binding['sha256'])
    check(artifacts[str(CORPUS)]==binding,'published/paragraph_member_exact_hash_and_size')
    check(corpus['source_join']=='two literal newline characters; exact original components retained',
        'published/literal_source_join')
    provenance=metadata['embedding_provenance']
    check(provenance['model_id']=='thenlper/gte-small'
        and provenance['revision']=='17e1f347d17fe144873b1201da91788898c639cd'
        and provenance['dimension']==384 and provenance['dtype']=='float32'
        and provenance['device']=='cuda' and provenance['normalized'] is True
        and provenance['truncated'] is False and provenance['max_tokens_observed']<=512,
        'cache/recorded_historical_clause_encoder_receipt')
    input_pins={x['path']:x for x in manifest['inputs']}
    for asset in provenance['assets']:
        matches=[x for p,x in input_pins.items() if p.endswith('/'+provenance['revision']+'/'+asset['name'])]
        check(len(matches)==1 and all(matches[0][key]==asset[key] for key in ('sha256','bytes')),
            'cache/recorded_asset_receipt_binding/'+asset['name'])
    # Assets are authenticated as retained receipt fields. This inventory does
    # not load, copy, download, or hash model weights or reexecute the encoder.
    cache_sets={};used_sets={};summaries={};mappings={}
    for split in ('train','validation'):
        path=C/('prepared384-'+split+'.json');rows=read(path,PINS[path.name])
        check(artifacts[str(path)]=={k:manifest['outputs'][split][k] for k in ('sha256','bytes')},
            'cache/manifest_output_binding/'+split)
        check(artifacts[str(C/'metadata384.json')]=={k:manifest['outputs']['metadata'][k] for k in ('sha256','bytes')},
            'cache/manifest_metadata_binding/'+split)
        records={r['original_row_without_embedding']['id']:r for r in metadata['splits'][split]}
        check(len(records)==len(rows)==manifest[split+'_count'],'cache/complete_row_inventory/'+split)
        by_text={};sets={k:set() for k in ('id','source','normalized_source','embedding','group')}
        for row in rows:
            original=records[row['id']]['original_row_without_embedding']
            stamp=records[row['id']]['original_manifest_entry']
            vector=row['input'];text=row['source_text'];embedded=digest(vector)
            check(type(vector) is list and len(vector)==384 and all(type(x) in (int,float) and math.isfinite(x) for x in vector)
                and abs(sum(x*x for x in vector)-1)<1e-4,'cache/finite_normalized384/'+row['id'])
            check(row['id']==original['id']==stamp['id'] and text==original['source_text']
                and source_sha(text)==original['source_sha256']==stamp['source_sha256']
                and embedded==original['embedding_sha256']==stamp['embedding_sha256']
                and normalized_sha(text)==stamp['normalized_source_sha256'] and original['split']==split,
                'cache/row_receipt_source_and_vector_binding/'+row['id'])
            check(text not in by_text,'cache/unique_exact_source_text/'+row['id']);by_text[text]=row
            for key,value in dict(id=row['id'],source=source_sha(text),normalized_source=normalized_sha(text),
                                  embedding=embedded,group=original['group_id']).items():sets[key].add(value)
        cache_sets[split]=sets;occurrences=Counter();paragraph_rows=[]
        for paragraph in corpus[split]:
            # No reference metadata enters the segmentation or cache lookup.
            segments=segment_source(paragraph['source_text'],by_text)
            check(source_sha(paragraph['source_text'])==paragraph['source_sha256'],
                'published/paragraph_source_hash/'+paragraph['id'])
            check(len(segments)==len(paragraph['components']),'published/component_coverage/'+paragraph['id'])
            for segment,component in zip(segments,paragraph['components']):
                check(all(segment[key]==component[key] for key in ('id','source_sha256','char_start','char_end','byte_start','byte_end'))
                    and segment['embedding_sha256']==component['original_metadata']['embedding_sha256']
                    and component['split']==component['original_metadata']['split']==split,
                    'published/ordered_source_embedding_component/'+paragraph['id']+'/'+segment['id'])
                occurrences[segment['id']]+=1
            paragraph_rows.append(dict(id=paragraph['id'],source_sha256=paragraph['source_sha256'],segments=segments))
        used={k:set() for k in sets}
        for row in rows:
            if row['id'] not in occurrences:continue
            original=records[row['id']]['original_row_without_embedding'];text=row['source_text']
            for key,value in dict(id=row['id'],source=source_sha(text),normalized_source=normalized_sha(text),
                                  embedding=digest(row['input']),group=original['group_id']).items():used[key].add(value)
        used_sets[split]=used;mappings[split]=paragraph_rows
        summaries[split]=dict(cache_rows=len(rows),paragraph_rows=len(paragraph_rows),
            clause_occurrences=sum(occurrences.values()),unique_used_clauses=len(occurrences),
            unused_cached_clauses=len(rows)-len(occurrences),missing_clauses=0,dimension=384,
            occurrences_by_clause_id=dict(sorted(occurrences.items())))
    overlaps={}
    for scope,sets in [('entire_cache',cache_sets),('used_clause_subset',used_sets)]:
        overlaps[scope]={key:len(sets['train'][key]&sets['validation'][key]) for key in sets['train']}
        check(not any(overlaps[scope].values()),'split/no_overlap/'+scope)
    check(summaries['train']['unique_used_clauses']==113 and summaries['validation']['unique_used_clauses']==54
        and sum(v['clause_occurrences'] for v in summaries.values())==360,'coverage/observed167clauses360occurrences')
    receipt=dict(schema='source-clause-cache-prerequisite-inventory/v1',complete=True,passed=True,findings=[],
        check_count=len(checks),checks=checks,artifacts=artifacts,splits=summaries,split_overlap_counts=overlaps,
        paragraph_source_mappings=mappings,source_segmentation='source_text.split("\\n\\n"); exact text cache lookup; no target/count/component selection inputs',
        publication_binding=dict(git_commit='4ecbc3ab8668135f084b1fcd49808c7fbfe8a8dc',
            repository='https://github.com/endomorphosis/ipfs_datasets_py',manifest_path=str(PUB),
            paragraph_archive_member=member,paragraph_member=binding,
            used_subset_source_and_embedding_digests_authenticated=True,
            prepared_cache_whole_file_public_archive_mapping_established=False),
        recorded_clause_embedding_provenance=provenance,
        provenance_scope='Historical clause vectors/receipts verified by hashes; used vectors additionally match already-published paragraph component hashes. Historical CUDA clause encoder is distinct from later CPU paragraph encoder. No tokenizer or encoder was rerun; recorded producer claims were not independently regenerated.',
        context_input_runtime_implemented=False,future_clause_conditioning_experiment_ready=False,
        weights_read_or_downloaded=False,encoder_executed=False,model_executed=False,training_executed=False,
        reference_formulas_used_for_segmentation=False,encoder_context_changed=False,
        qualified=False,admitted=False,proof_authority=False,source_semantics_verified=False,
        native_validation_executed=False,lake_executed=False,checkpoint_promoted=False,formalized=False,roundtrip_ok=False,
        limitations=['Source delimiter/cache prerequisite only; no inference conditioning implementation or reconstruction improvement.',
            'The whole prepared-cache files are locally hash-bound; a prior public whole-file archive mapping is not established here.',
            'Previously exposed authored development sources, not unseen real-law qualification.'])
    output=R/'clause-cache-inventory.json';output.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(json.dumps(dict(path=str(output),sha256=sha(output.read_bytes()),checks=len(checks),
        splits={k:{n:v[n] for n in ('cache_rows','paragraph_rows','clause_occurrences','unique_used_clauses')} for k,v in summaries.items()},overlaps=overlaps)))


if __name__=='__main__':main()
