"""Source/contract review only: no model, encoder, checkpoint, or test execution."""
import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

R = Path(__file__).resolve().parent
P = R.parents[2]
OLD = P / 'workspace/test-logs/decoder-multiplicative-source-training-20261003/experiment-source'
AUTO = 'ipfs_datasets_py/logic/formalization/autoencoder/'
artifacts, checks = {}, []


def bind(path):
    path = Path(path)
    content = path.read_bytes()
    artifacts[str(path)] = dict(sha256=hashlib.sha256(content).hexdigest(), bytes=len(content))
    return content


def check(name, condition):
    checks.append(dict(name=name, passed=bool(condition)))


def definitions(path):
    module = ast.parse(bind(path))
    return {node.name: node for node in module.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}


class OptionalContextOnly(ast.NodeTransformer):
    """Remove only the reviewed context seams, then compare the complete old AST."""
    def visit_FunctionDef(self, node):
        pairs = [(arg, default) for arg, default in zip(node.args.kwonlyargs, node.args.kw_defaults)
            if arg.arg not in ('source_context', 'source_contexts')]
        node.args.kwonlyargs = [arg for arg, _ in pairs]
        node.args.kw_defaults = [default for _, default in pairs]
        return self.generic_visit(node)

    def visit_Assign(self, node):
        targets = {item.id for target in node.targets for item in ast.walk(target) if isinstance(item, ast.Name)}
        if targets and targets <= {'contextual', 'context_receipt', 'training_contexts', 'validation_contexts', 'context_kwargs'}:
            return None
        return self.generic_visit(node)

    def visit_If(self, node):
        if (isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name)
                and node.test.left.id in ('source_contexts', 'context_receipt')
                and len(node.test.ops) == 1 and isinstance(node.test.ops[0], ast.IsNot)
                and isinstance(node.test.comparators[0], ast.Constant) and node.test.comparators[0].value is None):
            return None
        return self.generic_visit(node)

    def visit_Expr(self, node):
        if (isinstance(node.value, ast.Call) and len(node.value.args) == 2
                and isinstance(node.value.args[1], ast.Constant)
                and node.value.args[1].value == 'clause source model and explicit contexts must be paired'):
            return None
        return self.generic_visit(node)

    def visit_Tuple(self, node):
        node.elts = [item for item in node.elts if not
            (isinstance(item, ast.Constant) and item.value == 'clause-source-decoder-development/v1')]
        return self.generic_visit(node)

    def visit_Call(self, node):
        def context_keyword(keyword):
            if keyword.arg is not None:
                return False
            value = keyword.value
            if isinstance(value, ast.Name) and value.id == 'context_kwargs':
                return True
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute) and value.func.attr == '_source_context_kwargs':
                return True
            if isinstance(value, ast.IfExp):
                dictionaries = (value.body, value.orelse)
                return all(isinstance(item, ast.Dict) for item in dictionaries) and any(
                    isinstance(key, ast.Constant) and key.value in ('source_context', 'source_contexts')
                    for item in dictionaries for key in item.keys)
            return False
        node.keywords = [keyword for keyword in node.keywords if not context_keyword(keyword)]
        return self.generic_visit(node)


reviewed = {
    'decoder_distillation_experiment': {'_logits', '_greedy', '_evaluate', 'evaluate_model', '_source_context_kwargs'},
    'long_span_source_value_training': {'_head_specification', '_source_value_logits', '_source_value_evaluation', '_evaluate', 'train'},
    'long_span_count_exposure_training': {'_evaluate'},
    'decoder_source_fidelity': {'_control'},
}
for module, changed in reviewed.items():
    old = definitions(OLD / AUTO / (module + '.py'))
    new = definitions(P / AUTO / (module + '.py'))
    check(module + ': unchanged definition inventory', set(old) - changed == set(new) - changed)
    for name in sorted(set(old) - changed):
        check(module + ':' + name + ': exact protected AST', ast.dump(old[name]) == ast.dump(new[name]))
    names = ({'_logits', '_greedy', '_evaluate'} if module == 'decoder_distillation_experiment' else
        {'train', '_source_value_logits', '_source_value_evaluation', '_evaluate'} if module == 'long_span_source_value_training' else
        {'_evaluate'} if module == 'long_span_count_exposure_training' else set())
    for name in sorted(names):
        restored = OptionalContextOnly().visit(deepcopy(new[name]))
        check(module + ':' + name + ': complete AST equal after explicit context seams', ast.dump(restored) == ast.dump(old[name]))

for path in [
    P / 'scripts/ops/autoencoder/benchmark_clause_context_source_training.py',
    P / AUTO / 'clause_source_controls.py', P / AUTO / 'clause_source_context.py',
    P / AUTO / 'clause_source_decoder_experiment.py',
    P / 'tests/unit/logic/formalization/autoencoder/test_clause_source_controls.py',
    P / 'tests/unit/logic/formalization/autoencoder/test_clause_context_training_runner.py',
    R / 'controls-ready.json', Path(__file__),
]:
    bind(path)
xml = ET.fromstring(bind(R / 'runner-contract-tests.xml'))
suites = list(xml.iter('testsuite'))
counts = {field: sum(int(suite.attrib.get(field, 0)) for suite in suites)
    for field in ('tests', 'failures', 'errors', 'skipped')}
check('runner plus controls synthetic contracts passed', counts == dict(tests=84, failures=0, errors=0, skipped=0))
findings = [check['name'] for check in checks if not check['passed']]
receipt = dict(schema='clause-context-static-review/v1', passed=not findings, complete=True,
    finding_count=len(findings), findings=findings, checks=checks, artifacts=artifacts, synthetic_tests=counts,
    scope='read-only integration/source review and source-only contract tests; no model run',
    manual_review=[
        'Default None context helper returns an empty keyword mapping; original signatures and reports are retained.',
        'Entire trainer objective, optimizer, clipping, deadline-to-step ordering, exposure and selection AST match after removing only explicit optional-context seams.',
        'Source descriptors are built from literal source text and exact cached vectors; target payloads remain opaque in controls.',
        'One controlled context map reaches numerical CE/free generation, scalar auxiliary readout and guidance; reference labels are built from original rows.',
        'Whole-source controls move paragraph vector and clauses; context-only/order controls explicitly bind both the original paragraph and effective clause sources.',
        'Cross-length scorer label/derangement mismatch found during review was repaired and now has a real scorer-descriptor regression.',
        'Baseline five controls delegate unchanged; baseline training/report/final-state/full-prediction replay is required.',
        'Initial comparison authenticates inherited tensors/trainability/buffers, omits only512slot parameters, and checks full free-generation parity.',
        'Clause normalization uses113unique training sources only and binds the complete training context digest; validation54sources are exclusions.',
        'Zero control discards both clause values and mask length, retains eight bias slots, and zeroes recurrent/count source signal.',
        '180second fit deadlines remain cooperative; no optimizer step is committed after failed pre-step deadline check.2400second whole-run and30second postfit bounds remain explicit.',
        'Order/boundary augmentation with contextual training is rejected until its context plumbing is implemented.',
    ], training_executed=False, model_executed=False, encoder_executed=False,
    qualified=False, admitted=False, lake_executed=False)
(R / 'static-review.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps(dict(passed=receipt['passed'], checks=len(checks), findings=findings, tests=counts)))
raise SystemExit(bool(findings))
