"""Independent saved-output audit; no model/encoder/training/prover execution.

The previous authenticated stdlib selection/fidelity arithmetic is reused. New
checks cover explicit source clause context, unique training normalization,
actual saved head arithmetic, source controls and ordered actor/action binding.
This does not reconstruct gradient updates or assert native qualification.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
import math
import struct
import sys
sys.dont_write_bytecode = True
R = Path(__file__).resolve().parent
P = R.parents[2]
OLD = P/'workspace/test-logs/decoder-multiplicative-source-training-20261003'
SHARED = P/'workspace/test-logs/decoder-shared-slot-source-20261003'
ARITHMETIC_SHA = '459eed5588f46b88550ae8568e756c11160303c1e74ee736d36e56594c6d793c'
findings = []; artifacts = {}; checks = 0


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def raw(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()
def digest(value): return hashlib.sha256(raw(value)).hexdigest()
def check(value, label, detail=None):
    global checks
    checks += 1
    if not value: findings.append(dict(label=label, detail=detail))
def read(path):
    path = Path(path); data = path.read_bytes()
    artifacts[str(path)] = dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))
    return json.loads(data)


helper = R/'prior_training_arithmetic.py'
check(sha(helper) == ARITHMETIC_SHA, 'authenticated_previous_stdlib_audit')
spec = importlib.util.spec_from_file_location('_matched_source_arithmetic', helper)
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
prior.check = check; prior.read = read; prior.leaf.check = check
close = prior.close


def tensor_digest(values):
    result = hashlib.sha256()
    for name, value in sorted(values.items()):
        if name in ('head_initialization_seed', 'slot_interaction_version'):
            if type(value) is not int: raise ValueError('architecture buffer must remain scalar int64')
            dtype, data = 'torch.int64', struct.pack('<q', value)
        else: dtype, data = 'torch.float32', prior.leaf.tensor_bytes(value)
        result.update(raw([name, dtype, prior.leaf.shape(value)])); result.update(data)
    return result.hexdigest()


def common(args):
    manifest = read(args.manifest); plan = read(args.plan)
    check(sha(args.plan) == manifest['plan_sha256'] and plan['input_sha256'] == manifest['inputs'], 'pins/plan_inputs')
    for path, expected in manifest['inputs'].items():
        check(sha(path) == expected, 'pins/input/'+path)
        artifacts[path] = dict(sha256=expected, bytes=Path(path).stat().st_size)
    for rel, expected in manifest['extensions'].items():
        path = args.source/rel; check(sha(path) == expected, 'pins/source/'+rel)
        artifacts[str(path)] = dict(sha256=expected, bytes=path.stat().st_size)
    fixed = dict(schema='clause-context-source-training-plan/v1', seed_order=[1729, 2718], representation_dimension=384,
        hidden_width=64, candidate_hidden_formula='tanh(W*normalized_projected_clause+b)',
        candidate_training_parameter_delta=-512, clause_normalization_policy='unique_training_sources_first_occurrence',
        unique_training_clause_count=113, unique_validation_clause_count=54, richer_source_input_comparison=True,
        parameter_only_comparison=False, order_augmentation_enabled=False, generated_boundary_loss_enabled=False,
        expected_optimizer_steps_per_arm=340, expected_training_token_presentations_per_arm=225840,
        expected_count_presentations_per_arm=2440, expected_source_value_presentations_per_candidate=25600,
        fixed_encoder_context_tokens=512, fixed_decoder_output_limit=512, temperature=0, batch_size=8,
        learning_rate=.001, max_seconds_per_arm=180, source_value_weight=.25, cardinality_weight=.25,
        source_only_generation=True, generation_reference_count_access=False, generation_reference_prefix_access=False,
        full_vocabulary_retained=True, syntax_forced=False, closure_forced=False, original_training_rows=48,
        exposed_validation_rows=48, encoder_executed=False, selection_unchanged=True,
        native_qualification=False, production_promotion_allowed=False)
    for key, value in fixed.items(): check(plan.get(key) == value, 'plan/'+key)
    expected = [dict(name=n, head_kind=m, order_augmentation=False, generated_boundary_weight=0.)
        for n, m in [('baseline', 'pooled'), ('clauses', 'clauses')]]
    check(plan['arms'] == expected, 'plan/only_registered_source_context_intervention')
    static = read(R/'static-review.json')
    check(static.get('passed') is True and static.get('findings') == [], 'peer/frozen_trainer_guardian_review')
    for path, item in static['artifacts'].items():
        p = Path(path); p = p if p.is_absolute() else P/p
        expected_hash = item['sha256'] if type(item) is dict else item
        check(sha(p) == expected_hash, 'peer/unchanged_review_artifact/'+str(p))
    oldaudit = read(OLD/'independent-audit.json')
    check(oldaudit['passed'] and oldaudit['finding_count'] == 0, 'predecessor/audited_evidence')
    corpus = read(manifest['paragraphs']); donor = read(manifest['donor']); cached = read(manifest['embeddings'])
    prep = read(manifest['order_preparation']); enc = read(manifest['order_embeddings']); shared = read(manifest['shared_summary'])
    original = {r['id']:r for r in corpus['train']}; prepared = {r['id']:r for r in prep['rows']}
    variants = {key:[] for key in original}
    for row in prep['rows']: variants[row['order_diagnostic']['parent_id']].append(row['id'])
    cached_clauses = {split:read(manifest['clause_cache_'+split]) for split in ('train','validation')}
    contexts = {}; unique = {}
    for split in ('train','validation'):
        by_text = {r['source_text']:r['input'] for r in cached_clauses[split]}
        contexts[split] = {r['id']:descriptor(r['source_text'], by_text) for r in corpus[split]}
        unique[split] = {}
        for row in corpus[split]:
            for segment in contexts[split][row['id']]['segments']:
                unique[split].setdefault(segment['source_sha256'], segment)
        check(len(unique[split]) == (113 if split=='train' else 54), 'contexts/source_only_unique_inventory/'+split)
        check(sum(len(c['segments']) for c in contexts[split].values())==180, 'contexts/180_occurrences/'+split)
    check(not set(unique['train'])&set(unique['validation']), 'contexts/no_validation_source_overlap')
    check(not {digest(v['vector']) for v in unique['train'].values()}&{digest(v['vector']) for v in unique['validation'].values()}, 'contexts/no_validation_vector_overlap')
    return dict(manifest=manifest, plan=plan, corpus=corpus, donor=donor, preparation=prep, prepared=prepared,
        original=original, variants=variants, vectors={r['input_id']:r['vector'] for r in cached['rows']},
        native={r['input_id']:r['vector'] for r in enc['observations']['main']}, prior={r['arm']:r for r in shared['runs']},
        contexts=contexts, unique=unique)


def textsha(text): return hashlib.sha256(text.encode('utf-8')).hexdigest()
def descriptor(text, by_text):
    segments=[]; char=byte=0
    for piece in text.split('\n\n'):
        vector=by_text[piece]
        check(len(vector)==384 and all(math.isfinite(x) for x in vector) and abs(math.fsum(x*x for x in vector)-1)<1e-4, 'contexts/normalized_cached_vector/'+textsha(piece))
        segments.append(dict(source_text=piece,source_sha256=textsha(piece),embedding_sha256=digest(vector),vector=vector,
            char_start=char,char_end=char+len(piece),byte_start=byte,byte_end=byte+len(piece.encode('utf-8'))))
        char+=len(piece)+2;byte+=len(piece.encode('utf-8'))+2
    return dict(source_sha256=textsha(text),segments=segments)


def f32(value): return struct.unpack('<f',struct.pack('<f',value))[0]
def affine(vector,weight,bias): return [math.fsum(w*x for w,x in zip(row,vector))+b for row,b in zip(weight,bias)]
def projection(vector,state,transform):
    x=[f32(f32(v-f32(m))/f32(transform['scale'])) for v,m in zip(vector,transform['mean'])]
    hidden=[math.tanh(v) for v in affine(x,state['projection_down.weight'],state['projection_down.bias'])]
    return [a+b for a,b in zip(x,affine(hidden,state['projection_up.weight'],state['projection_up.bias']))]


def preprocessing(root,ctx,initial):
    saved=read(root/'source-contexts.json'); receipt=read(root/'clause-preprocessing.json');norm=receipt['normalization']
    check(saved==ctx['contexts'], 'contexts/complete_exact_source_vectors_offsets_and_bindings')
    inventory=[dict(id='clause:'+k,source_sha256=k) for k in ctx['unique']['train']]
    forbidden=['clause:'+k for k in ctx['unique']['validation']]
    check(norm['training_inventory']==inventory and norm['expected_training_ids']==[v['id'] for v in inventory]
        and norm['forbidden_validation_ids']==forbidden and norm['fitted_rows']==113
        and norm['validation_rows_used_for_fitting']==0, 'normalization/113_unique_training_only')
    check(norm['training_contexts_sha256']==digest(saved['train']) and norm['receipt_sha256']==digest({k:v for k,v in norm.items() if k!='receipt_sha256'}), 'normalization/full_vector_context_digest')
    features=receipt['projected_features']; check(norm['training_feature_rows_sha256']==digest(features), 'normalization/features_digest')
    state=prior.canonical(initial);maximum=0
    for feature,item in zip(features,inventory):
        expected=projection(ctx['unique']['train'][item['source_sha256']]['vector'],state,ctx['donor']['input_transform'])
        maximum=max(maximum,max(abs(a-b) for a,b in zip(expected,feature['features'])))
        check(feature['id']==item['id'] and feature['source_sha256']==item['source_sha256'] and close(expected,feature['features'],3e-6), 'normalization/frozen_projection/'+item['id'])
    means=[math.fsum(r['features'][i] for r in features)/113 for i in range(384)]
    energy=math.fsum((x-means[i])**2 for r in features for i,x in enumerate(r['features']))/113
    check(len(features)==113 and close(means,norm['mean'],1e-12) and close(energy,norm['fitted_training_centered_row_squared_norm'],1e-12)
        and close(math.sqrt(energy),norm['scale'],1e-12), 'normalization/independent_unique_mean_global_RMS')
    ctx['normalization']=norm
    return dict(unique_training_clauses=113,validation_clauses=54,training_occurrences=180,projection_float64_max_absolute_error=maximum)


def state_check(path,report,role,initial,old_initial,mode,ctx,label):
    state=read(path);prior.authority(state,label);values=state['model_state'];old=old_initial['model_state'];candidate=mode=='clauses'
    check(state['schema']=='private-clause-context-source-state/v1' and state['role']==role and state['codec']==ctx['donor']['codec'], 'state/schema_role_codec/'+label)
    mapped={k.replace('clause_head.','body.source_value_head.',1) if k.startswith('clause_head.') else k:v for k,v in values.items() if k not in ('clause_source_mean','clause_source_scale')}
    omitted={'body.source_value_head.slot_embeddings'} if candidate else set()
    check(set(mapped)==set(old)-omitted and (not candidate or {'clause_source_mean','clause_source_scale'}<=set(values)), 'state/registered_inventory_and_no_dead_scalar_head/'+label)
    check(digest(values)==state['weights_sha256'] and tensor_digest(values)==state['tensor_sha256'], 'state/typed_hashes/'+label)
    expected=report['initial_weights_sha256'] if role=='initial' else report['selected_weights_sha256'] if role=='selected' else report['last_complete_attempt_weights_sha256']
    check(state['tensor_sha256']==expected,'state/report_binding/'+label)
    actual=prior.canonical(state);base=prior.canonical(old_initial)
    frozen=[k for k in base if k.startswith(('projection_down.','projection_up.')) or k in ('source_mean','source_scale','count_prior_logits','head_initialization_seed')]
    check(all(actual[k]==base[k] for k in frozen),'state/frozen_projection_preprocessing_seed/'+label)
    if role=='initial':check(all(v==old[k] for k,v in mapped.items()),'state/exact_common_initial_values/'+label)
    if initial is not None:check(state['architecture']==initial['architecture'],'state/architecture_fixed/'+label)
    if not candidate:check(state['architecture']==old_initial['architecture'],'state/default_architecture_exact/'+label)
    else:
        desc=state['architecture'];norm=desc['clause_normalization']
        check(desc['schema']=='clause-source-decoder-development/v1' and desc['slot_parameters'] is False
            and desc['source_context_required'] is True and desc['source_context_cached_on_module'] is False
            and desc['source_clause_count_used_for_stopping'] is False,'state/explicit_source_context_only/'+label)
        check(desc['source_value_parameter_count']==old_initial['architecture']['source_value_parameter_count']-512,'state/head_parameter_delta/'+label)
        check(values['clause_source_mean']==[f32(v) for v in norm['mean']] and values['clause_source_scale']==f32(norm['scale']),'state/frozen_clause_buffers/'+label)
    return state


def decode(tokens, vocab):
    try:
        doc = json.loads(''.join(vocab[i] for i in tokens), object_pairs_hook=prior.unique)
        return doc['rules'] if type(doc) is dict and set(doc) == {'rules'} and type(doc['rules']) is list and all(prior.valid_rule(r) for r in doc['rules']) else []
    except (ValueError, TypeError): return []



CONTROLS=prior.CONTROLS+[
    ('context-only-shuffle','validation','context_only_shuffle'),
    ('context-reverse','validation','context_reverse'),('context-rotate','validation','context_rotate')]
FIELDS=('actor','action','modality','object')
PROJECTIONS={}; HEADS={}


def projected(vector,state,ctx):
    key=digest(vector)
    if key not in PROJECTIONS:PROJECTIONS[key]=projection(vector,prior.canonical(state),ctx['donor']['input_transform'])
    return PROJECTIONS[key]


def head_scores(state,ctx,vector,descriptor_value,zero=False):
    candidate=state['recipe']['head_kind']=='clauses';values=prior.canonical(state);size=len(ctx['donor']['codec']['target_vocabulary'])
    prefix='clause_head.' if candidate else 'source_value_head.'
    W=values[prefix+'source_projection.weight'];b=values[prefix+'source_projection.bias']
    Rw=values[prefix+'field_readout.weight'];Rb=values[prefix+'field_readout.bias']
    result=[]
    for slot in range(8):
        if candidate and not zero and slot>=len(descriptor_value['segments']):
            result.append([[0.]*size for _ in FIELDS]);continue
        source=(descriptor_value['segments'][slot]['vector'] if candidate else vector) if not zero else None
        key=(state['tensor_sha256'],None if zero else digest(source),None if candidate else slot)
        if key not in HEADS:
            mean=values['clause_source_mean' if candidate else 'source_mean'];scale=values['clause_source_scale' if candidate else 'source_scale']
            x=[0.]*384 if zero else [(v-m)/scale for v,m in zip(projected(source,state,ctx),mean)]
            hidden=affine(x,W,b)
            if not candidate:hidden=[v+e for v,e in zip(hidden,values['source_value_head.slot_embeddings'][slot])]
            scores=affine([math.tanh(v) for v in hidden],Rw,Rb)
            HEADS[key]=[scores[i*size:(i+1)*size] for i in range(4)]
        result.append(HEADS[key])
    return result


def control_contexts(ctx,split,kind):
    refs=ctx['corpus'][split];lookup={r['id']:r for r in refs};ids=list(lookup)
    groups={}
    for r in refs:groups.setdefault(len(r['source_text'].split('\n\n')),[]).append(r['id'])
    for group in groups.values():group.sort()
    identity={k:k for k in ids}
    if kind in ('source_shuffle','context_only_shuffle'):
        assignment={k:v for g in groups.values() for k,v in zip(g,g[1:]+g[:1])}
    elif kind=='cross_length_shuffle':
        seq=[k for n in (1,2,4,8) for k in groups[n]];assignment={k:seq[(i+12)%48] for i,k in enumerate(seq)}
    else:assignment=identity.copy()
    paragraphs=assignment.copy() if kind in ('source_shuffle','cross_length_shuffle') else identity.copy()
    contexts={};permutations={};bindings={}
    for key in ids:
        original=lookup[key];para=lookup[paragraphs[key]];donor=lookup[assignment[key]]
        desc=ctx['contexts'][split][donor['id']];perm=list(range(len(desc['segments'])))
        if kind=='context_reverse':perm=perm[::-1]
        elif kind=='context_rotate':perm=perm[1:]+perm[:1]
        pieces=[desc['segments'][i] for i in perm];text='\n\n'.join(p['source_text'] for p in pieces)
        rebound=descriptor(text,{p['source_text']:p['vector'] for p in pieces});contexts[key]=rebound;permutations[key]=perm
        bindings[key]=dict(original_source_text=original['source_text'],original_source_sha256=textsha(original['source_text']),
            paragraph_source_text=para['source_text'],paragraph_source_sha256=textsha(para['source_text']),
            context_donor_source_sha256=textsha(donor['source_text']),actual_context_source_text=text,actual_context_source_sha256=textsha(text),
            original_input_sha256=digest(ctx['vectors'][key]),actual_input_sha256=digest(ctx['vectors'][para['id']]),
            original_context_sha256=digest(ctx['contexts'][split][key]),donor_context_sha256=digest(desc),actual_context_sha256=digest(rebound),
            original_source_clause_count=len(original['source_text'].split('\n\n')),actual_context_clause_count=len(pieces),
            effective_context_change=text!=original['source_text'],effective_paragraph_change=ctx['vectors'][key]!=ctx['vectors'][para['id']])
    return paragraphs,assignment,contexts,permutations,bindings


def scalar_metrics(panel,refs,state,ctx,paragraphs,contexts,zero,label):
    value=panel['source_values'];predictions=value['predictions'];vocab=ctx['donor']['codec']['target_vocabulary'];lookup={r['id']:r for r in refs}
    check(value['references_passed_to_model'] is False and value['used_for_selection'] is False and value['source_only_head'] is True,'scalar/source_only_auxiliary_scope/'+label)
    correct=present=0;loss=0.;byfield={f:Counter() for f in FIELDS};bylength={};pairs=0;maxerror=0.
    for row in predictions:
        key=row['id'];rules=lookup[key]['target']['rules'];expected=[[vocab.index(json.dumps(r[f])) for f in FIELDS] for r in rules]+[[-1]*4 for _ in range(8-len(rules))]
        scores=row['raw_logits'];guess=[[max(range(len(v)),key=v.__getitem__) for v in record] for record in scores]
        check(row['expected_token_ids']==expected and row['predicted_token_ids']==guess,'scalar/present_original_reference_values/'+label+'/'+key)
        wanted=head_scores(state,ctx,ctx['vectors'][paragraphs[key]],contexts[key],zero)
        maxerror=max(maxerror,max(abs(a-b) for sa,sb in zip(scores,wanted) for fa,fb in zip(sa,sb) for a,b in zip(fa,fb)))
        check(close(scores,wanted,6e-5),'scalar/full_vocabulary_source_context_arithmetic/'+label+'/'+key)
        length=bylength.setdefault(str(len(rules)),dict(rows=0,present_values=0,correct=0));length['rows']+=1
        for i,r in enumerate(rules):
            pairs+=all(guess[i][j]==expected[i][j] for j in (0,1))
            for j,f in enumerate(FIELDS):
                target=expected[i][j];hit=int(guess[i][j]==target);correct+=hit;present+=1
                loss+=prior.lse(scores[i][j])-scores[i][j][target]
                byfield[f].update(correct=hit,present_values=1);length['present_values']+=1;length['correct']+=hit
    check(len(predictions)==len(refs)==48 and value['present_values']==present==720 and value['correct']==correct
        and close(value['accuracy'],correct/present,1e-10) and close(value['cross_entropy'],loss/present,2e-6)
        and value['by_length']==bylength,'scalar/independent_label_accuracy_CE/'+label)
    for field,totals in byfield.items():check(all(value['by_field'][field][k]==v for k,v in totals.items()),'scalar/field_totals/'+label+'/'+field)
    if 'scalar_guidance' in panel:
        guidance=panel['scalar_guidance'];check(guidance['source_only'] and guidance['target_tokens_passed_to_model'] is False,'scalar/applied_guidance_source_scope/'+label)
        check([(r['id'],r['applied_logits'],r['predicted_token_ids']) for r in guidance['rows']]==[(r['id'],r['raw_logits'],r['predicted_token_ids']) for r in predictions], 'scalar/applied_guidance_matches_raw/'+label)
    return dict(correct=correct,total=present,actor_action_pairs_correct=pairs,pair_slots=180,cross_entropy=loss/present,maximum_float64_logit_error=maxerror)


def panel_check(panel,split,kind,state,ctx,label,cache):
    refs=ctx['corpus'][split];exe=panel['execution'];report=panel['report'];pred=panel['predictions'];candidate=state['recipe']['head_kind']=='clauses'
    check(report['complete'] and report['optimizer_steps']==0 and report['generation_target_access'] is False
        and report['generation_temperature']==0 and report['max_target_tokens']==512
        and exe['training_performed'] is False and exe['selection_performed'] is False,'postfit/full_source_only_generation/'+label)
    paragraphs,assignment,contexts,permutations,bindings=control_contexts(ctx,split,kind)
    if 'source_bindings' in exe:
        check(exe['kind']==kind and exe['control']==dict(kind=kind,source_assignment=assignment)
            and exe['source_assignment']==assignment and exe['context_source_assignment']==assignment
            and exe['paragraph_source_assignment']==paragraphs and exe['context_permutation']==permutations
            and exe['source_bindings']==bindings,'postfit/independent_source_only_controls/'+label)
        check(exe['references_accepted'] is False and exe['target_payloads_read'] is False
            and exe['context_passed_to_model']==candidate and exe['actual_contexts_sha256']==digest(contexts)
            and exe['source_contexts_sha256']==(digest(contexts) if candidate else None),'postfit/context_source_hashes_and_no_targets/'+label)
        if kind=='zero_condition':check(exe['normalized_clause_values_and_padding_mask_removed'] is True,'postfit/no_zero_control_mask_leak/'+label)
    else:
        prior.panel_check(panel,refs,ctx['vectors'],kind,ctx['donor']['codec'],label+'/legacy_control',cache)
        check(not candidate,'postfit/legacy_control_only_for_pooled/'+label)
    identity=(digest(panel['source_fidelity']),digest(pred),digest(refs))
    if identity not in cache:prior.leaf.audit_fidelity(panel['source_fidelity'],refs,pred,ctx['donor']['codec'],label);cache.add(identity)
    prior.leaf.audit_counts(panel['source_count'],refs,label)
    prior.authority(report,label)
    scalar=scalar_metrics(panel,refs,state,ctx,paragraphs,contexts,kind=='zero_condition',label)
    metrics=panel['source_fidelity']['metrics'];facets=panel['source_fidelity']['by_facet']
    pairs=0
    for row in panel['source_fidelity']['rows']:
        gold=row['expected_ir']['rules'];actual=row['generated_ir'];rules=actual.get('rules',[]) if isinstance(actual,dict) else []
        pairs+=sum(i<len(rules) and isinstance(rules[i],dict) and all(rules[i].get(f)==r[f] for f in ('actor','action')) for i,r in enumerate(gold))
    return dict(exact=metrics['ordered_exact'],syntax=metrics['syntax_valid'],eos=metrics['eos_count'],
        generated_scalar_correct=sum(facets[f]['correct'] for f in FIELDS),duplicate_rules=metrics['duplicate_rules'],
        generated_actor_action_pairs_correct=pairs,generated_pair_scope='parseable rules; separate from complete syntax validity',
        source_head=scalar)


def audit_order(observed,paired,state,ctx,label):
    vocab=ctx['donor']['codec']['target_vocabulary'];original=set(ctx['preparation']['original_ids']);groups={'original_training':Counter(),'changed_order_training_components':Counter()}
    check(observed['rows']==len(observed['predictions'])==108 and observed['model_tensor_sha256']==state['tensor_sha256'],'order/all_source_only_rows/'+label)
    bytext={r['source_text']:r['vector'] for r in ctx['unique']['train'].values()}
    contexts={r['id']:descriptor(r['source_text'],bytext) for r in ctx['preparation']['rows']}
    check(observed['source_contexts_sha256']==digest(contexts) and observed['context_passed_to_model']==(state['recipe']['head_kind']=='clauses'),'order/source_context_binding/'+label)
    grows={r['id']:r for r in paired['generated']['rows']};hrows={r['id']:r for r in paired['scalars']['rows']}
    maximum=0.
    for pred in observed['predictions']:
        key=pred['id'];scores=observed['scalar_logits'][key]
        wanted=head_scores(state,ctx,ctx['native'][key],contexts[key])
        maximum=max(maximum,max(abs(a-b) for sa,sb in zip(scores,wanted) for fa,fb in zip(sa,sb) for a,b in zip(fa,fb)))
        check(close(scores,wanted,6e-5),'order/source_only_head_arithmetic/'+label+'/'+key)
        head=[]
        for record in scores:
            out={}
            for field,field_scores in zip(FIELDS,record):
                token=max(range(len(field_scores)),key=field_scores.__getitem__)
                try:v=json.loads(vocab[token]) if token>=3 else None
                except ValueError:v=None
                out[field]=v if type(v) is str else None
            head.append(out)
        gold=ctx['prepared'][key]['target']['rules'];generated=decode(pred['token_ids'],vocab)
        pair=lambda rows:sum(i<len(rows) and all(rows[i].get(f)==r[f] for f in ('actor','action')) for i,r in enumerate(gold))
        gp,hp=pair(generated),pair(head)
        check(grows[key]['actor_action_pairs_correct']==gp and hrows[key]['actor_action_pairs_correct']==hp,'order/joint_pair_arithmetic/'+label+'/'+key)
        groups['original_training' if key in original else 'changed_order_training_components'].update(rows=1,expected_pair_slots=len(gold),generated_pair_correct=gp,raw_head_pair_correct=hp,exact_with_eos=int(pred['eos_reached'] and generated==gold))
    pairs=paired['scalars']['pairs'];check(len(pairs)==60,'order/all_changed_order_pairs/'+label)
    return dict(groups={k:dict(v) for k,v in groups.items()},order_pairs=len(pairs),
        full_logits_closer_to_fixed_positions=sum(r['full_logit_fixed_slot_distance']['l2']<r['full_logit_permuted_slot_distance']['l2'] for r in pairs),
        saved_head_float64_max_absolute_difference=maximum,structural_equivariance_is_not_learned_order_recovery=True)


def results(args,ctx):
    root=args.results;summary=read(root/'summary.json');prior.authority(summary,'summary')
    check(summary['complete'] and [r['arm'] for r in summary['runs']]==[n+'-'+str(s) for s in (1729,2718) for n in ('baseline','clauses')],'results/four_fixed_fits')
    check(summary['baseline_replay_parity'] and summary['dimensions_actually_trained']==[384] and summary['encoder_executed'] is False,'results/scope')
    cache=set();out={};parameters={};prep=None
    for run in summary['runs']:
        label=run['arm'];folder=root/label;report=read(folder/'training.json');check(report==run['training'],'training/persisted_report/'+label)
        detail=prior.training(run,ctx);seed=run['seed'];mode=run['recipe']['head_kind']
        oldfolder=SHARED/'training-r1/results'/('shared-'+str(seed));old_initial=read(oldfolder/'initial-state.json')
        states={};initial=None
        for role in ('initial','selected','last-attempt'):
            states[role]=state_check(folder/(role+'-state.json'),report,role,initial,old_initial,mode,ctx,label+'/'+role)
            if role=='initial':initial=states[role]
        if prep is None:prep=preprocessing(root,ctx,initial)
        if mode=='clauses':
            check(initial['architecture']['clause_normalization']==ctx['normalization'],'normalization/exact_all_candidate_receipts/'+label)
            check(report['source_contexts_sha256']==digest(ctx['contexts']) and report['source_context_target_access'] is False
                and report['source_context_used_for_scalar_head_only'] is True,'training/explicit_context_binding/'+label)
        parity=read(folder/'initial-parity.json')
        check(parity==run['initial_parity'] and parity['complete'] and parity['parameter_values_equal_after_head_renaming']
            and parity['inherited_buffers_equal'] and parity['initial_greedy_predictions_equal']
            and all(c['reference']==c['observed'] and len(c['reference'])==48 for c in parity['controls']), 'initial/full_greedy_parity/'+label)
        check(parity['baseline_tensor_sha256']==old_initial['tensor_sha256'] and parity['candidate_tensor_sha256']==initial['tensor_sha256']
            and parity['parameter_delta']==(-512 if mode=='clauses' else 0),'initial/typed_state_and_parameter_binding/'+label)
        panels={};rawpanels={}
        for role in ('selected','last-attempt'):
            panels[role]={};rawpanels[role]={}
            for name,split,kind in CONTROLS:
                panel=read(folder/role/('evaluation-'+name+'.json'));rawpanels[role][name]=panel
                panels[role][name]=panel_check(panel,split,kind,states[role],ctx,label+'/'+role+'/'+name,cache)
                if name=='validation':
                    expected=report['selected'] if role=='selected' else report['last_complete_attempt']
                    check(panel['report']['metrics']==expected['numerical'],'postfit/selection_report_binding/'+label+'/'+role)
        if mode=='pooled':
            previous=deepcopy(ctx['prior']['shared-'+str(seed)]['training']);current=deepcopy(report);current['config']['max_seconds']=90
            for value in (previous,current):value.pop('elapsed_seconds',None)
            check(current==previous,'baseline/exact_training_except_time_timeout/'+label)
            for role in ('selected','last-attempt'):
                oldstate=read(oldfolder/(role+'-state.json'));check(states[role]['model_state']==oldstate['model_state'],'baseline/exact_state/'+label+'/'+role)
                for name,_,_ in prior.CONTROLS:
                    old=read(oldfolder/role/('evaluation-'+name+'.json'));check(rawpanels[role][name]['predictions']==old['predictions'],'baseline/exact_prediction_envelope/'+label+'/'+role+'/'+name)
                for name,_,_ in CONTROLS[5:]:check(rawpanels[role][name]['predictions']==rawpanels[role]['validation']['predictions'],'baseline/context_unused_generation_invariance/'+label+'/'+role+'/'+name)
        observed=read(folder/'last-attempt/order-observations.json');pairs=read(folder/'last-attempt/order-pairs.json')
        order=audit_order(observed,pairs,states['last-attempt'],ctx,label);parameters[label]=run['trainable_parameter_count']
        out[label]=dict(training=detail,controls=panels,order_binding=order,selected_epoch=report['selected_epoch'],
            fit_elapsed_seconds=run['training_call_elapsed_seconds'],trainable_parameter_count=run['trainable_parameter_count'],
            auxiliary_head_original_training={k:rawpanels['last-attempt']['training']['source_values'][k] for k in ('accuracy','cross_entropy')})
    check(all(parameters['clauses-'+str(s)]==parameters['baseline-'+str(s)]-512 for s in (1729,2718)),'parameters/exact_candidate_reduction')
    return dict(runs=out,preprocessing=prep,distinct_fidelity_panels_audited=len(cache),limits=[
        'Saved stdlib arithmetic does not execute models or replay gradients.',
        'Clause inputs and unique-clause normalization differ from paragraph inputs; this is not a parameter-only comparison.',
        'The validation data were already exposed; no fresh holdout or native/Lake qualification.',
        'Clause-head permutation equivariance is architectural; generated ordered fidelity is scored independently.',
        'Context-only and order controls intentionally mismatch paragraph and clause source; all original references remain fixed.',
        'Auxiliary scalar and count accuracy cannot override full-generation per-length/facet selection.'])



def main():
    parser = argparse.ArgumentParser()
    for name in ('source','manifest','plan','output'): parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--results', type=Path); args = parser.parse_args()
    ctx = common(args); analysis = results(args,ctx) if args.results else None
    check('torch' not in sys.modules and 'transformers' not in sys.modules, 'auditor/no_model_imports')
    for path in (Path(__file__).resolve(), helper, R/'audit_leaf_arithmetic.py'):
        artifacts[str(path)] = dict(sha256=sha(path), bytes=path.stat().st_size)
    value = dict(schema='clause-context-source-training-independent-audit/v1', phase='results' if args.results else 'readiness',
        created_at_utc=datetime.now(timezone.utc).isoformat(), passed=not findings, checks=checks, finding_count=len(findings),
        findings=findings, artifacts=artifacts, analysis=analysis, manifest_sha256=sha(args.manifest), plan_sha256=sha(args.plan),
        models_executed=False, training_executed=False, encoder_executed=False, qualified=False, admitted=False,
        lake_executed=False, fresh_holdout=False)
    args.output.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n')
    print(json.dumps(dict(passed=value['passed'], checks=checks, findings=len(findings), output=str(args.output))))
    if findings: sys.exit(1)


if __name__ == '__main__': main()
