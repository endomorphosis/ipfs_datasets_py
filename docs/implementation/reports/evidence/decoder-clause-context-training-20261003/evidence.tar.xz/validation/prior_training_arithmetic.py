"""Saved-output audit for optional order substitution and actual-prefix training.

No Torch/model/encoder/prover imports or executions. Reuses an authenticated
stdlib fidelity/selection arithmetic leaf and audits the new supervision receipts.
It cannot replay gradients or recover intermediate weights from a digest alone.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import argparse
import ast
from copy import deepcopy
import hashlib
import importlib.util
import json
import math
import struct
import sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;P=R.parents[2]
OLD=P/'workspace/test-logs/decoder-shared-slot-source-20261003'
DIAG=P/'workspace/test-logs/decoder-order-boundary-diagnostic-20261003'
AUTO='ipfs_datasets_py/logic/formalization/autoencoder/'
LEAF_SHA='ea440ebb1fc7b978da165329c864a69631be88048f2b694690522674cdc98c47'
SEEDS=(1729,2718);NAMES=('baseline','order','boundary','both')
CONTROLS=[('validation','validation','conditioned'),('training','train','conditioned'),('zero-condition','validation','zero_condition'),('source-shuffle','validation','source_shuffle'),('cross-length-shuffle','validation','cross_length_shuffle')]
findings=[];artifacts={};checks=0

def raw(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def digest(x):return hashlib.sha256(raw(x)).hexdigest()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    path=Path(path);data=path.read_bytes();artifacts[str(path)]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data));return json.loads(data)
def check(value,label,detail=None):
    global checks
    checks+=1
    if not value:findings.append(dict(label=label,detail=detail))
def close(a,b,tol=3e-5):
    if type(a) is dict and type(b) is dict:return a.keys()==b.keys() and all(close(a[k],b[k],tol) for k in a)
    if type(a) is list and type(b) is list:return len(a)==len(b) and all(close(x,y,tol) for x,y in zip(a,b))
    if type(a) in (int,float) and type(b) in (int,float):return math.isfinite(a) and math.isfinite(b) and math.isclose(a,b,rel_tol=tol,abs_tol=tol)
    return type(a) is type(b) and a==b

def load_leaf():
    path=R/'audit_leaf_arithmetic.py';check(sha(path)==LEAF_SHA,'authenticated_prior_arithmetic_leaf');artifacts[str(path)]=dict(sha256=sha(path),bytes=path.stat().st_size)
    spec=importlib.util.spec_from_file_location('_training_fidelity_leaf',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.check=check;return module
leaf=load_leaf()

def authority(x,label):leaf.authority(x,label)
def canonical(state):
    out={}
    for name,value in state['model_state'].items():
        while name.startswith('body.'):name=name[5:]
        if name in out:raise ValueError('duplicate canonical state name')
        out[name]=value
    return out

def tensor_digest(values):
    result=hashlib.sha256()
    for name,value in sorted(values.items()):
        if name.endswith('head_initialization_seed'):
            if type(value) is not int:raise ValueError('seed must remain int64')
            dtype='torch.int64';data=struct.pack('<q',value)
        else:dtype='torch.float32';data=leaf.tensor_bytes(value)
        result.update(raw([name,dtype,leaf.shape(value)]));result.update(data)
    return result.hexdigest()

def source_guards(source):
    before=ast.parse((DIAG/'experiment-source'/AUTO/'long_span_source_value_training.py').read_text())
    after=ast.parse((source/AUTO/'long_span_source_value_training.py').read_text())
    old={n.name:n for n in before.body if isinstance(n,ast.FunctionDef)};new={n.name:n for n in after.body if isinstance(n,ast.FunctionDef)}
    check(old.keys()==new.keys(),'source/trainer_function_inventory')
    check(all(ast.dump(old[k])==ast.dump(new[k]) for k in old if k!='train'),'source/all_other_trainer_functions_unchanged')
    a,b=old['train'],new['train'];args=deepcopy(b.args)
    check([x.arg for x in args.kwonlyargs[-2:]]==['order_augmentation','generated_boundary_weight'],'source/only_new_keyword_options')
    args.kwonlyargs=args.kwonlyargs[:-2];args.kw_defaults=args.kw_defaults[:-2]
    check(ast.dump(a.args)==ast.dump(args),'source/original_api_preserved')
    def assignment(nodes,name):
        return next(n for n in nodes if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
    for name in ('optimizer','scheduler','generator','evaluate','report'):
        check(ast.dump(assignment(a.body,name))==ast.dump(assignment(b.body,name)),'source/unchanged_'+name)
    def epoch(n):
        stage=next(x for x in n.body if isinstance(x,ast.For) and ast.unparse(x.target)=='stage')
        return next(x for x in stage.body if isinstance(x,ast.For) and ast.unparse(x.target)=='stage_epoch')
    def selection(n):
        body=epoch(n).body
        start=next(i for i,x in enumerate(body) if isinstance(x,ast.Assign) and any(ast.unparse(t)=='(observed, accepted, reasons)' for t in x.targets))
        return ast.dump(ast.Module(body=body[start:],type_ignores=[]))
    check(selection(a)==selection(b),'source/entire_evaluation_selection_history_path_unchanged')
    for expression in ('objective.backward()','torch.nn.utils.clip_grad_norm_(trainable, options[\'max_grad_norm\'], error_if_nonfinite=True)','optimizer.step()'):
        target=ast.dump(ast.parse(expression).body[0].value)
        check(sum(isinstance(n,ast.Call) and ast.dump(n)==target for n in ast.walk(a))==sum(isinstance(n,ast.Call) and ast.dump(n)==target for n in ast.walk(b))==1,'source/unchanged_update_operation/'+expression)


def common(args):
    m=read(args.manifest);plan=read(args.plan);previous=read(DIAG/'diagnostic-manifest.json')
    check(sha(args.plan)==m['plan_sha256'] and plan['input_sha256']==m['inputs'],'pins/plan_and_inputs')
    for path,h in m['inputs'].items():check(sha(path)==h,'pins/input/'+path);artifacts[path]=dict(sha256=h,bytes=Path(path).stat().st_size)
    for rel,h in m['extensions'].items():
        p=args.source/rel;check(sha(p)==h,'pins/source/'+rel);artifacts[str(p)]=dict(sha256=h,bytes=p.stat().st_size)
        if rel in previous['extensions'] and not rel.endswith('/long_span_source_value_training.py'):check(h==previous['extensions'][rel],'source/unchanged_numerical_and_gates/'+rel)
    source_guards(args.source)
    fixed=dict(schema='order-boundary-source-training-plan/v1',seed_order=[1729,2718],representation_dimension=384,
        expected_optimizer_steps_per_arm=340,expected_training_token_presentations_per_arm=225840,
        expected_source_value_presentations_per_candidate=25600,expected_count_presentations_per_arm=2440,
        fixed_encoder_context_tokens=512,fixed_decoder_output_limit=512,temperature=0,max_seconds_per_arm=180,
        order_normalization_refitted=False,order_count_stream_changed=False,order_policy_uses_rng=False,
        boundary_site_cap_per_row=2,full_vocabulary_retained=True,syntax_forced=False,closure_forced=False,
        source_only_generation=True,generation_reference_count_access=False,generation_reference_prefix_access=False,
        selection_unchanged=True,native_qualification=False,production_promotion_allowed=False,encoder_executed=False,no_downloads=True)
    for key,value in fixed.items():check(plan.get(key)==value,'plan/'+key)
    check(plan['arms']==[dict(name=n,order_augmentation=o,generated_boundary_weight=w) for n,o,w in [('baseline',False,0.),('order',True,0.),('boundary',False,.25),('both',True,.25)]],'plan/factorial_arms')
    corpus=read(m['paragraphs']);donor=read(m['donor']);cached=read(m['embeddings']);pre=read(m['order_preparation']);enc=read(m['order_embeddings']);prior=read(m['shared_summary'])
    prior_audit=read(DIAG/'independent-audit.json');check(prior_audit['passed'] and prior_audit['finding_count']==0,'predecessor/read_only_order_diagnostic_authenticated')
    original={r['id']:r for r in corpus['train']};prepared={r['id']:r for r in pre['rows']}
    native={r['input_id']:r['vector'] for r in enc['observations']['main']};variants={key:[] for key in original}
    for row in pre['rows']:variants[row['order_diagnostic']['parent_id']].append(row['id'])
    check(len(prepared)==108 and len(original)==48 and sum(len(v) for v in variants.values())==108,'augmentation/original_effective_inventory')
    check(not {' '.join(r['source_text'].casefold().split()) for r in pre['rows']}&{' '.join(r['source_text'].casefold().split()) for r in corpus['validation']},'augmentation/no_normalized_validation_overlap')
    return dict(manifest=m,plan=plan,corpus=corpus,donor=donor,preparation=pre,prepared=prepared,native=native,original=original,variants=variants,
        vectors={r['input_id']:r['vector'] for r in cached['rows']},prior={r['arm']:r for r in prior['runs']})


def unique(pairs):
    d={}
    for k,v in pairs:
        if k in d:raise ValueError('duplicate key')
        d[k]=v
    return d

def valid_rule(r):
    fields={'actor','action','modality','object','conditions','exceptions','temporal'}
    return type(r) is dict and set(r)==fields and all(type(r[f]) is str and r[f] for f in ('actor','action','modality','object')) and r['modality'] in ('O','P','F') and all(type(r[f]) is list and len(r[f])<=4 and all(type(v) is str and v for v in r[f]) and r[f]==sorted(set(r[f])) for f in ('conditions','exceptions','temporal'))

def sites(prefix,vocab):
    result=[]
    for pos,token in enumerate(prefix):
        if pos==0 or vocab[token]!='}':continue
        try:doc=json.loads(''.join(vocab[i] for i in prefix[1:pos+1])+']}',object_pairs_hook=unique)
        except (ValueError,TypeError):continue
        if type(doc) is dict and set(doc)=={'rules'} and type(doc['rules']) is list and doc['rules'] and all(valid_rule(r) for r in doc['rules']):result.append(dict(position=pos,completed_rules=len(doc['rules'])))
    return result

def lse(values):
    m=max(values);return m+math.log(math.fsum(math.exp(x-m) for x in values))

def boundary_receipt(receipt,ids,ctx,aug,label):
    vocab=ctx['donor']['codec']['target_vocabulary'];g=receipt['generation'];rows=g['rows'];counts={k:r['clause_count'] for k,r in (ctx['prepared'] if aug else ctx['original']).items()}
    check(receipt['schema']=='generated-source-boundary-loss/v1' and receipt['training_counts_sha256']==digest(counts),'boundary/authenticated_training_labels/'+label)
    check(g['source_only'] is True and g['reference_count_access'] is False and [r['id'] for r in rows]==ids and g['max_target_tokens']==512,'boundary/source_only_batch/'+label)
    check(receipt['full_vocabulary_cross_entropy'] is True and receipt['reference_counts_used_only_in_loss'] is True and receipt['target_prefixes_used'] is False and receipt['additional_optimizer_steps']==0,'boundary/loss_scope/'+label)
    selected=[];available=0;replayed=0;generation_tokens=0;empty=0
    rowmap={r['id']:r for r in rows}
    for row in rows:
        key=row['id'];p=row['prediction'];prefix=row['consumed_prefix'];tok=p['token_ids'];generation_tokens+=len(tok)
        check(row['input_sha256']==digest(ctx['native'][key]) and p['id']==key,'boundary/source_binding/'+label+'/'+key)
        expected_len=len(tok)+(1 if p['generation_status']!='output_limit' else 0)
        check(prefix==[1]+tok[:len(prefix)-1] and len(prefix)==expected_len and 1<=len(prefix)<512,'boundary/actual_complete_prefix/'+label+'/'+key)
        expected=sites(prefix,vocab);wanted=expected if len(expected)<=1 else [expected[0],expected[-1]]
        check(row['available_sites']==expected and row['selected_sites']==wanted and row['available_site_count']==len(expected) and row['selected_site_count']==len(wanted) and row['ignored_site_count']==len(expected)-len(wanted),'boundary/independent_first_last/'+label+'/'+key)
        available+=len(expected);replayed+=wanted[-1]['position']+1 if wanted else 0;empty+=not wanted
        selected.extend((key,x['position'],x['completed_rules']) for x in wanted)
    check([(e['id'],e['position'],e['completed_rules']) for e in receipt['events']]==selected,'boundary/complete_selected_events/'+label)
    losses={};stop=0
    active=len(rows)-empty
    for event in receipt['events']:
        key=event['id'];row=rowmap[key];count=counts[key];k=event['completed_rules'];target=vocab.index(']' if k>=count else ',');n=event['position']+1;values=event['replay_logits'];loss=lse(values)-values[target]
        check(event['training_count']==count and event['target_token_id']==target and event['action']==('stop' if k>=count else 'continue'),'boundary/training_loss_target/'+label+'/'+key+'/'+str(n))
        check(len(values)==len(vocab) and all(math.isfinite(v) for v in values) and close(loss,event['cross_entropy']) and close(event['mean_loss_coefficient'],1/active/len(row['selected_sites']),1e-10),'boundary/full_vocab_ce/'+label+'/'+key+'/'+str(n))
        check(event['consumed_prefix_length']==n and event['consumed_prefix_sha256']==digest(row['consumed_prefix'][:n]),'boundary/event_prefix_binding/'+label+'/'+key+'/'+str(n))
        losses.setdefault(key,[]).append(loss);stop+=k>=count
    expected_rows=[dict(id=k,sites=len(v),mean_ce=sum(v)/len(v)) for k,v in losses.items()];mean=sum(r['mean_ce'] for r in expected_rows)/len(expected_rows) if expected_rows else None
    check(close(receipt['row_losses'],expected_rows) and close(receipt['mean_loss'],mean),'boundary/row_balanced_mean/'+label)
    check(receipt['rows']==len(ids) and receipt['active_rows']==active and receipt['rows_without_sites']==empty and receipt['available_sites']==available and receipt['selected_sites']==len(selected) and receipt['ignored_sites']==available-len(selected) and receipt['replay_prefix_tokens']==replayed and receipt['stop_labels']==stop and receipt['continue_labels']==len(selected)-stop,'boundary/exposure_counters/'+label)
    return dict(available_sites=available,selected_sites=len(selected),rows_without_sites=empty,replay_prefix_tokens=replayed,generated_tokens=generation_tokens,greedy_batch_steps=g['greedy_batch_steps'],stop_labels=stop,continue_labels=len(selected)-stop)


def training(run,ctx):
    report=run['training'];recipe=run['recipe'];seed=run['seed'];label=run['arm'];prior=ctx['prior']['shared-'+str(seed)]['training'];aug=recipe['order_augmentation'];boundary=recipe['generated_boundary_weight']!=0
    check(report['config']['max_seconds']==180 and all(v==prior['config'][k] for k,v in report['config'].items() if k!='max_seconds'),'training/config/'+label)
    check(report['curriculum']==prior['curriculum'] and report['count_selector_initial']==prior['count_selector_initial'] and report['count_selector_final']==prior['count_selector_final'],'training/unchanged_curriculum_count_stream/'+label)
    drawn=Counter();variants=Counter();count_stream=hashlib.sha256();decoder_stream=hashlib.sha256();aug_stream=hashlib.sha256();totals=Counter();byclass=Counter();boundary_totals=Counter()
    for i,(update,old) in enumerate(zip(report['committed_updates'],prior['committed_updates']),1):
        ids=update['decoder_row_ids'];parents=update.get('decoder_parent_row_ids',ids);countids=update['count_row_ids']
        expected=[]
        for key in parents:
            chosen=ctx['variants'][key][drawn[key]%len(ctx['variants'][key])] if aug else key;expected.append(chosen);drawn[key]+=1;variants[chosen]+=1
        check(update['optimizer_step']==i and parents==old['decoder_row_ids'] and ids==expected and countids==old['count_row_ids'],'training/parent_variant_count_schedule/'+label+'/'+str(i))
        tokens=sum(len(ctx['prepared'][key]['target_ids'])-1 for key in ids);scalars=sum(4*ctx['prepared'][key]['clause_count'] for key in ids)
        check(update['target_token_presentations']==old['target_token_presentations']==tokens and update['source_value_presentations']==old['source_value_presentations']==scalars,'training/fixed_exposure/'+label+'/'+str(i))
        objective=update['weighted_token_ce']+report['config']['reconstruction_weight']*update['raw_reconstruction_mse']+.25*update['count_ce']+.25*update['source_value_ce']
        if boundary:
            extra=boundary_receipt(update['generated_boundary'],ids,ctx,aug,label+'/'+str(i));boundary_totals.update(extra)
            if update['generated_boundary']['mean_loss'] is not None:objective+=recipe['generated_boundary_weight']*update['generated_boundary']['mean_loss']
        else:check('generated_boundary' not in update,'training/no_disabled_graph_or_receipt/'+label+'/'+str(i))
        check(close(objective,update['objective'],2e-6),'training/complete_objective_arithmetic/'+label+'/'+str(i))
        count_stream.update(raw(countids));decoder_stream.update(raw(ids));aug_stream.update(raw(dict(parent_ids=parents,effective_ids=ids)))
        totals.update(rows=len(ids),tokens=tokens,scalars=scalars);byclass.update(str(ctx['original'][key]['clause_count']) for key in countids)
    check(len(report['committed_updates'])==report['optimizer_steps']==340 and totals==Counter(rows=2440,tokens=225840,scalars=25600) and report['stopped_reason']=='epochs_completed','training/complete_fixed_budget/'+label)
    check(report['row_presentations']==report['count_training_row_presentations']==2440 and report['valid_target_token_presentations']==225840 and report['source_value_presentations']==25600,'training/reported_budget/'+label)
    check(dict(byclass)==report['count_training_presentations_by_class']=={str(n):610 for n in (1,2,4,8)} and count_stream.hexdigest()==report['committed_count_batch_ids_sha256']==prior['committed_count_batch_ids_sha256'] and decoder_stream.hexdigest()==report['committed_decoder_batch_ids_sha256'],'training/stream_hashes/'+label)
    if aug:
        initial=report['order_augmentation']['initial'];last=report['order_augmentation']['final']
        check(all(v==0 for v in initial['parent_occurrence_counts'].values()) and last['parent_occurrence_counts']==dict(drawn) and last['variant_draw_counts']=={k:variants[k] for k in ctx['prepared']} and last['draw_batches']==340 and last['draw_rows']==2440 and last['selection_sequence_sha256']==aug_stream.hexdigest(),'augmentation/exact_committed_cycles/'+label)
        check(initial['variant_ids_by_parent']==last['variant_ids_by_parent']==ctx['variants'] and initial['normalization_fit_rows']=='unchanged original48' and initial['count_sampler_rows']=='unchanged original48','augmentation/unaltered_fitting_cohort/'+label)
    else:check('order_augmentation' not in report,'augmentation/disabled_path_unchanged/'+label)
    selection=leaf.audit_selection(report,label+'/strict_selection')
    return dict(exposure=dict(totals),additional_boundary_work=dict(boundary_totals),selection=selection)


def state_check(path,report,role,old_initial,ctx,label):
    state=read(path);authority(state,label);values=state['model_state'];canonical_values=canonical(state);old=canonical(old_initial)
    check(state['schema']=='private-order-boundary-source-state/v1' and state['role']==role and state['codec']==ctx['donor']['codec'] and state['architecture']==old_initial['architecture'],'state/unchanged_architecture/'+label)
    check(digest(values)==state['weights_sha256'] and tensor_digest(values)==state['tensor_sha256'],'state/exact_typed_tensor_digest/'+label)
    expected=report['initial_weights_sha256'] if role=='initial' else report['selected_weights_sha256'] if role=='selected' else report['last_complete_attempt_weights_sha256']
    check(state['tensor_sha256']==expected,'state/training_binding/'+label)
    names=[k for k in old if k.startswith(('projection_down.','projection_up.')) or k in ('source_mean','source_scale','count_prior_logits','head_initialization_seed')]
    check(all(canonical_values[k]==old[k] for k in names),'state/frozen_projection_preprocessing_seed/'+label)
    return state


def panel_check(panel,refs,vectors,kind,codec,label,cache):
    report=panel['report'];exe=panel['execution'];assignment=exe['source_assignment'];lookup={r['id']:r for r in refs};pred=panel['predictions']
    check(report['complete'] and report['optimizer_steps']==0 and report['generation_target_access'] is False and report['generation_temperature']==0 and report['max_target_tokens']==512 and exe['training_performed'] is False and exe['selection_performed'] is False,'postfit/unchanged_target_free_scope/'+label)
    expectedkind='source_shuffle' if kind=='cross_length_shuffle' else kind
    check(exe['kind']==expectedkind and set(assignment)==set(assignment.values())==set(lookup),'postfit/source_inventory/'+label)
    if kind in ('source_shuffle','cross_length_shuffle'):
        same=kind=='source_shuffle';check(all(k!=v and (lookup[k]['clause_count']==lookup[v]['clause_count']) is same for k,v in assignment.items()),'postfit/actual_shuffle_stratum/'+label)
        check(exe['input_substitutions']=={k:dict(original_input_sha256=digest(vectors[k]),substituted_input_sha256=digest(vectors[v])) for k,v in assignment.items()},'postfit/actual_source_hashes/'+label)
    else:check(all(k==v for k,v in assignment.items()),'postfit/identity_sources/'+label)
    key=(digest(panel['source_fidelity']),digest(pred),digest(refs))
    if key not in cache:leaf.audit_fidelity(panel['source_fidelity'],refs,pred,codec,label);cache.add(key)
    else:check(True,'postfit/reused_identical_fidelity_arithmetic/'+label)
    authority(report,label)
    return dict(exact=panel['source_fidelity']['metrics']['ordered_exact'],syntax=panel['source_fidelity']['metrics']['syntax_valid'],eos=panel['source_fidelity']['metrics']['eos_count'],generated_scalar_correct=sum(panel['source_fidelity']['by_facet'][f]['correct'] for f in ('actor','action','modality','object')),duplicate_rules=panel['source_fidelity']['metrics']['duplicate_rules'])


def results(args,ctx):
    root=args.results;summary=read(root/'summary.json');check(summary['complete'] and [r['arm'] for r in summary['runs']]==[name+'-'+str(seed) for seed in SEEDS for name in NAMES],'results/eight_fixed_arms')
    check(summary['baseline_replay_parity'] and summary['dimensions_actually_trained']==[384] and summary['encoder_executed'] is False,'results/completed_scope');authority(summary,'results')
    cache=set();out={}
    for run in summary['runs']:
        label=run['arm'];folder=root/label;report=read(folder/'training.json');check(report==run['training'],'training/full_persisted_report/'+label)
        seed=run['seed'];oldfolder=OLD/'training-r1/results'/('shared-'+str(seed));old_initial=read(oldfolder/'initial-state.json')
        detail=training(run,ctx);states={role:state_check(folder/(role+'-state.json'),report,role,old_initial,ctx,label+'/'+role) for role in ('initial','selected','last-attempt')}
        panels={};rawpanels={}
        for role in ('selected','last-attempt'):
            panels[role]={};rawpanels[role]={}
            for name,split,kind in CONTROLS:
                value=read(folder/role/('evaluation-'+name+'.json'));rawpanels[role][name]=value
                panels[role][name]=panel_check(value,ctx['corpus'][split],ctx['vectors'],kind,ctx['donor']['codec'],label+'/'+role+'/'+name,cache)
                if name=='validation':
                    expected=report['selected'] if role=='selected' else report['last_complete_attempt'];check(value['report']['metrics']==expected['numerical'],'postfit/selection_numerical_binding/'+label+'/'+role)
        if run['recipe']['name']=='baseline':
            oldrun=ctx['prior']['shared-'+str(seed)];old=oldrun['training'];new=deepcopy(report);new['config']['max_seconds']=90
            for key in ('elapsed_seconds',):new.pop(key,None)
            old=deepcopy(old);old.pop('elapsed_seconds',None)
            check(new==old,'baseline/all_old_training_fields_except_time_and_timeout/'+label)
            for role in ('selected','last-attempt'):
                oldstate=read(oldfolder/(role+'-state.json'));check(states[role]['model_state']==oldstate['model_state'],'baseline/exact_saved_state/'+label+'/'+role)
                for name,_,_ in CONTROLS:
                    previous=read(oldfolder/role/('evaluation-'+name+'.json'));check(rawpanels[role][name]['predictions']==previous['predictions'],'baseline/full_prediction_envelope/'+label+'/'+role+'/'+name)
        for split,name in (('train','training'),('validation','validation')):
            trace=read(folder/'last-attempt'/('boundary-'+split+'.json'));check(trace['predictions']==[{k:p[k] for k in ('id','token_ids','generation_status','eos_reached')} for p in rawpanels['last-attempt'][name]['predictions']],'mechanism/exact_source_only_boundary_replay/'+label+'/'+split)
        order=read(folder/'last-attempt/order-observations.json');pairs=read(folder/'last-attempt/order-pairs.json')
        check(order['rows']==len(order['predictions'])==108 and order['model_tensor_sha256']==states['last-attempt']['tensor_sha256'] and len(pairs['generated']['rows'])==108 and len(pairs['generated']['pairs'])==60,'mechanism/complete_order_panel/'+label)
        out[label]=dict(training=detail,controls=panels,selected_epoch=report['selected_epoch'],fit_elapsed_seconds=run['training_call_elapsed_seconds'])
    return dict(runs=out,distinct_fidelity_panels_audited=len(cache),limits=['No gradient replay or intermediate-weight reconstruction from hashes.','Cached source vectors and prior architecture arithmetic reuse authenticated predecessor evidence.','Boundary CE labels supervise training only; exact generated fidelity remains the selection gate.','Exposed validation is not a fresh holdout; no native/Lake execution or qualification.'])


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--manifest',type=Path,required=True);parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--results',type=Path);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    ctx=common(args);analysis=results(args,ctx) if args.results else None
    check('torch' not in sys.modules and 'transformers' not in sys.modules,'auditor/no_model_imports')
    artifacts[str(Path(__file__).resolve())]=dict(sha256=sha(__file__),bytes=Path(__file__).stat().st_size)
    value=dict(schema='order-boundary-training-independent-audit/v1',phase='results' if args.results else 'readiness',created_at_utc=datetime.now(timezone.utc).isoformat(),passed=not findings,checks=checks,finding_count=len(findings),findings=findings,artifacts=artifacts,analysis=analysis,manifest_sha256=sha(args.manifest),plan_sha256=sha(args.plan),models_executed=False,training_executed=False,encoder_executed=False,qualified=False,admitted=False,lake_executed=False,fresh_holdout=False)
    args.output.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n');print(json.dumps(dict(passed=value['passed'],checks=checks,findings=len(findings),output=str(args.output))))
    if findings:sys.exit(1)

if __name__=='__main__':main()
