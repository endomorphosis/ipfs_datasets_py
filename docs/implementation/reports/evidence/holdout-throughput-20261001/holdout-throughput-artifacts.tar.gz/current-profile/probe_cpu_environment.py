"""Replay the train-only profile with accelerators hidden from this CPU worker."""
import json
import os
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'source'))
assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
import torch
torch.set_num_threads(1)
from scripts.ops.legal_ir.validate_teacher_student_transfer import sha,write
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import modal_latent_formula as learning
p=json.loads((HERE/'report.json').read_text())
for name in ('inputs','initial_head'):
    assert sha(p[name]['path'])==p[name]['sha256']
rows=json.loads(Path(p['inputs']['path']).read_text())
head=json.loads(Path(p['initial_head']['path']).read_text())
tick=time.perf_counter()
out=learning.train(head,rows,[],epochs=1000,max_optimizer_steps=100,max_seconds=120)
elapsed=time.perf_counter()-tick
identity=learning.checkpoint_digest(out['checkpoint'])
assert identity==p['final_checkpoint_sha256']
write(HERE/'cpu-environment-probe.json',dict(schema='cpu-accelerator-visibility-diagnostic/v1',
    CUDA_VISIBLE_DEVICES='',torch_threads=1,device='cpu',steps=100,training_rows=48,
    wall_seconds=elapsed,steps_per_second=100/elapsed,reference_wall_seconds=p['unprofiled_wall_seconds'],
    checkpoint_exact=True,checkpoint_sha256=identity,paired_order_randomized=False,
    earlier_profile_receipt_sha256=sha(HERE/'report.json'),script_sha256=sha(__file__),
    holdout_targets_read=False,admitted=False,qualified=False,formalized=False,roundtrip_ok=False))
print(json.dumps({'wall_seconds':elapsed,'steps_per_second':100/elapsed,'checkpoint_exact':True}))
