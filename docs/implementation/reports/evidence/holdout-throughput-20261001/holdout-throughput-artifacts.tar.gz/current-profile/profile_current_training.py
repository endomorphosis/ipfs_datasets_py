"""Training-only100step CPU profile; no held-out target or checkpoint is loaded."""
import cProfile
import hashlib
import json
from pathlib import Path
import pstats
import sys
import time

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'source'
REPO=SOURCE.parents[3]
PRIOR=REPO/'workspace/test-logs/training-continuation-release-20261001/current-augmentation-r1'
sys.path.insert(0,str(SOURCE))
import torch
torch.set_num_threads(1)
from scripts.ops.legal_ir import validate_teacher_student_transfer as shared
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_embedding_production as embeddings
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_runtime_registry as runtimes
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import modal_joint_formula as joint
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import modal_latent_formula as learning
from ipfs_datasets_py.optimizers.logic_theorem_optimizer.autoencoder_lineages import current_v2
from ipfs_datasets_py.optimizers.logic_theorem_optimizer.formula_training_profiles import get_training_profile

def read(ref):
    p=Path(ref['path']); assert shared.sha(p)==ref['sha256'] and p.stat().st_size==ref['bytes']
    return json.loads(p.read_text())

start=time.perf_counter()
prepared=json.loads((PRIOR/'prepared.json').read_text())
plan=json.loads((PRIOR/'plan.json').read_text())
assert shared.sha(PRIOR/'plan.json')==prepared['plan_sha256']
source_hashes=shared.source_hashes()
targets=read(prepared['files']['original_training'])+read(prepared['files']['added_wording'])
assert len(targets)==48
by_id={row['sample_id']:row for row in read(prepared['files']['samples'])}
production=read(prepared['files']['embedding_production'])
ref=production['artifact']
receipt=embeddings.load_embedding_production_receipt(ref['path'],expected_sha256=ref['sha256'],
    expected_size_bytes=ref['bytes'],resolver=lambda value:production['source_paths'][value['sha256']])
data=receipt.to_dict()
assert data['execution']['kind']=='native'
assert data['producer']['code_sha256']==shared.sha(SOURCE/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_embedding_runtime.py')
vectors={item['section']:embeddings._decode_vector(result['vector']) for item,result in zip(data['inputs'],data['results'])}
samples=[]
for target in targets:
    archived=by_id[target['id']]
    assert archived['text']==target['source_text']
    assert archived['embedding_vector']==list(vectors[archived['section']])
    sample=current_v2.build_sample(title=archived['title'],section=archived['section'],text=archived['text'],
        citation=archived['citation'],embedding_vector=archived['embedding_vector'],embedding_model=archived['embedding_model'])
    assert sample.to_dict()==archived
    samples.append(sample)
profile=get_training_profile('raw_gain10_v1')
runtime=runtimes.open_runtime('legal_ir','current_v2',**profile['core_options'])
rows=joint._rows(runtime.model,samples,targets)
checkpoint=learning.build_checkpoint(joint._core_binding(runtime.model),rows,[],**profile['formula_options'])
inputs_ref=shared.write(HERE/'training-inputs.json',rows)
initial_ref=shared.write(HERE/'initial-head.json',checkpoint)
preparation_seconds=time.perf_counter()-start
options=dict(epochs=1000,max_optimizer_steps=100,max_seconds=120)
profiler=cProfile.Profile(); tick=time.perf_counter()
profiler.enable(); profiled=learning.train(checkpoint,rows,[],**options); profiler.disable()
profiled_wall=time.perf_counter()-tick
profiler.dump_stats(HERE/'training.pstats')
tick=time.perf_counter(); measured=learning.train(checkpoint,rows,[],**options); measured_wall=time.perf_counter()-tick
assert measured['checkpoint']==profiled['checkpoint']
assert measured['report']['optimizer_steps']==100
assert shared.source_hashes()==source_hashes
stats=pstats.Stats(profiler)
records=[]
for (file,line,name),(primitive,total,self_seconds,cumulative_seconds,callers) in stats.stats.items():
    records.append(dict(file=file,line=line,name=name,primitive_calls=primitive,total_calls=total,
                        self_seconds=self_seconds,cumulative_seconds=cumulative_seconds))
records.sort(key=lambda x:x['cumulative_seconds'],reverse=True)
report=dict(schema='current-formula-training-cpu-profile/v1',source_hashes=source_hashes,
    script_sha256=shared.sha(__file__),inputs=inputs_ref,initial_head=initial_ref,
    prepared_from_sha256=shared.sha(PRIOR/'prepared.json'),source_binding='verified local production; rebuilt training samples exact',
    profiled_steps=100,training_count=48,tuning_count=0,holdout_count=0,temperature=0,torch_threads=1,
    preparation_seconds=preparation_seconds,profiled_wall_seconds=profiled_wall,
    unprofiled_wall_seconds=measured_wall,unprofiled_steps_per_second=100/measured_wall,
    profiled_and_unprofiled_checkpoint_exact=True,final_checkpoint_sha256=learning.checkpoint_digest(measured['checkpoint']),
    profiled_training_report=profiled['report'],unprofiled_training_report=measured['report'],
    cumulative_times_overlap=True,profile_records=records,
    admitted=False,qualified=False,formalized=False,roundtrip_ok=False,holdout_targets_read=False)
shared.write(HERE/'report.json',report)
print(json.dumps({k:report[k] for k in ('profiled_wall_seconds','unprofiled_wall_seconds','unprofiled_steps_per_second','final_checkpoint_sha256')}))
