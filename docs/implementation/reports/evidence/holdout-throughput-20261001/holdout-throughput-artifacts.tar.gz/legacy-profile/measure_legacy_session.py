import cProfile, hashlib, json, os, pstats, sys, time
from pathlib import Path
source = Path(__file__).resolve().parents[1] / 'source'
sys.path.insert(0, str(source))
os.environ['IPFS_DATASETS_LEGAL_IR_METRIC_DISK_CACHE']='0'
os.environ['IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI']='0'
os.environ['IPFS_DATASETS_PY_LAZY_INSTALL_PROVERS']='0'
from scripts.ops.legal_ir import compare_legacy_active_training as prior
from ipfs_datasets_py.optimizers.logic_theorem_optimizer.autoencoder_lineages.legacy_v1 import active_training as active, feature_training_session as session
from ipfs_datasets_py.optimizers.logic_theorem_optimizer.autoencoder_lineages.legacy_v1.linguistic_view_reuse import ViewReuseHistoricalDaemonAutoencoder as Model
out = Path(__file__).parent
results = {}
for name in ['uninterrupted', 'session']:
    model = Model(compute_device='cpu')
    splits={s:[model.build_sample(title='authored-feature-diagnostic',section=f'{s}-{i}',text=t,citation=f'authored feature diagnostic:{s}-{i}') for i,t in enumerate(texts)] for s,texts in prior.TEXTS.items()}
    for sample in splits['training']+splits['tuning']: model.linguistic_observation(sample)
    controller=session.FeatureTrainingSession(model,splits['training'], validation_samples=splits['tuning'],proposal_budget=12) if name=='session' else None
    profile=cProfile.Profile()
    tick=time.perf_counter(); profile.enable()
    result=controller.advance(max_proposals=12,max_seconds=120) if controller else active.train_active_family_features(model,splits['training'],validation_samples=splits['tuning'],epochs=12,max_line_search_attempts=1,max_seconds=120)
    profile.disable(); elapsed=time.perf_counter()-tick
    profile.dump_stats(str(out/(name+'.prof')))
    rows=[]
    for (path,line,func),(primitive,total,self_seconds,cumulative,callers) in pstats.Stats(profile).stats.items():
        if '/legacy_v1/' in path or func in {'evaluate','state_identity','_apply_projection_update_batch','encode','describe','to_json'}:
            rows.append(dict(path=path,line=line,function=func,primitive_calls=primitive,total_calls=total,self_seconds=self_seconds,cumulative_seconds=cumulative))
    rows.sort(key=lambda x:x['cumulative_seconds'], reverse=True)
    results[name]=dict(elapsed_seconds=elapsed,profile=rows,accepted=result.get('accepted_updates',result.get('accepted_epochs')),after=result['after'],weights_sha256=hashlib.sha256(prior.raw(model.state.to_dict())).hexdigest())
    print(name, elapsed, results[name]['accepted'],results[name]['weights_sha256'],flush=True)
    with (out/(name+'.txt')).open('w') as fp: pstats.Stats(profile,stream=fp).sort_stats('cumulative').print_stats(65)
(out/'profile.json').write_text(json.dumps(results,indent=2))
