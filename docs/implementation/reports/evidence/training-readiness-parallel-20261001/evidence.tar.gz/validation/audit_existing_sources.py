"""Explicit adaptation of previously inspected diagnostic files; no new labels."""
import hashlib
import json
from collections import Counter
from pathlib import Path

from ipfs_datasets_py.logic.formalization.autoencoder.training_readiness import audit_source_corpus

ROOT = Path('/home/barberb/lift_coding/external/ipfs_datasets')
OUT = ROOT / 'workspace/test-logs/training-readiness-parallel-20261001'
LEGAL = ROOT / 'workspace/test-logs/federal-corpus-audits/parallel-training-campaign-20260929T042818Z/verified-embeddings-r1'
INTENT = Path('/home/barberb/lift_coding/artifacts/intent-ir-open-vocab-20260930/coverage-01/public-paired-corpus.json')

pins = {}
def read(path):
    assert path.stat().st_size < 4 * 1024 * 1024
    raw = path.read_bytes()
    pins[str(path)] = hashlib.sha256(raw).hexdigest()
    return raw

legal = []
for file, split in [('training.jsonl', 'train'), ('tuning.jsonl', 'validation')]:
    for source in map(json.loads, read(LEGAL / file).splitlines()):
        identity = source['citation']
        legal.append({'id': identity, 'domain_id': 'legal_ir', 'document_id': identity,
            'group_id': identity, 'split': split, 'source_text': source['text'],
            'embedding': source['embedding_vector'], 'reference_target': None,
            'target_origin': 'unlabeled', 'source_language': 'en', 'evaluation_role': 'development'})
assert len(legal) == 8
intent = []
for source in json.loads(read(INTENT))['samples']:
    # The test partition is neither opened for numerical fitting nor relabeled.
    if source['split'] not in ('train', 'validation'):
        continue
    intent.append({'id': source['id'], 'domain_id': 'intent_ir',
        'document_id': source['provenance']['source_id'], 'group_id': source['group_id'],
        'split': source['split'], 'source_text': source['instruction'], 'embedding': None,
        'reference_target': source['native_intent_ir'], 'target_origin': 'compiler_weak',
        'source_language': 'en', 'evaluation_role': 'development'})
assert len(intent) == 12
reports = {
    'legal_ir': audit_source_corpus(legal, vector_space_id='declared:thenlper/gte-small:existing-diagnostic'),
    'intent_ir': audit_source_corpus(intent, vector_space_id='unavailable:existing-weak-intent-pairs'),
}
for domain in ('security_ir', 'ui_ux_ir'):
    rows = []
    directory = Path('/home/barberb/lift_coding/artifacts/source-native-v3-20261001/run-02') / domain
    for split in ('train', 'validation'):
        for source in json.loads(read(directory / (split + '.json')))['rows']:
            assert source['split'] == split
            assert hashlib.sha256(source['source_text'].encode()).hexdigest() == source['source_sha256']
            rows.append({'id': source['id'], 'domain_id': domain,
                'document_id': source['group_id'], 'group_id': source['group_id'],
                'split': split, 'source_text': source['source_text'], 'embedding': source['embedding'],
                'reference_target': source['target'], 'target_origin': 'authored',
                'source_language': 'python' if domain == 'security_ir' else 'en', 'evaluation_role': 'development'})
    assert len(rows) == 480
    reports[domain] = audit_source_corpus(rows, vector_space_id='declared:thenlper/gte-small:source-native-v3-authored')
for path, digest in pins.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
for domain, report in reports.items():
    (OUT / (domain + '-existing-source-readiness.json')).write_text(json.dumps(report, indent=2) + '\n')
result = {'schema': 'existing-source-readiness-exercise/v1', 'input_sha256': pins,
    'producer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'adaptation': {
        'legal': 'Existing source text and384D vectors preserved; no formal target supplied; citation is explicitly declared document/group, not independently verified grouping.',
        'intent': 'Existing instruction, source/group/split and native Intent target preserved. Weak label origin explicit. No vector invented; original test split excluded from this audit panel.',
        'security_ui': 'Existing authored training/tuning source, vector, native target and group preserved. Source hashes checked; group used as conservative document identity. No independent embedding or semantic authentication inferred.',
        'language': 'English is a caller declaration for these previously inspected diagnostic inputs.',
        'evaluation': 'Only existing train/tuning rows are mapped. No model fit, no heldout score or newly sealed split claim.',
    },
    'domains': {domain: {'rows': len(report['rows']), 'ready_rows': report['source_decoder_ready_row_count'],
        'native_target_shape_validated_rows': sum(row['native_target_shape_validated'] for row in report['rows']),
        'blocker_counts': dict(Counter(reason for row in report['rows'] for reason in row['blockers']))}
        for domain, report in reports.items()},
    'training_executed': False, 'source_semantics_verified': False, 'admitted': False}
(OUT / 'existing-source-readiness.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result['domains'], indent=2))
