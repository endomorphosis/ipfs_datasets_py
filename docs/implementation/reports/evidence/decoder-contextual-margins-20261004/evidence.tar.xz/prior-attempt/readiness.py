"""Verify the exact saved-state observation plan before resource admission."""
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys
import xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent;P=R.parents[2]
artifacts={};findings=[];checks=0
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def check(ok,message):
    global checks
    checks+=1
    if not ok:findings.append(message)
def pin(path,expected=None):
    path=Path(path).resolve();record=dict(bytes=path.stat().st_size,sha256=sha(path));artifacts[str(path)]=record
    if expected is not None:check(record['sha256']==expected,'digest '+str(path))
    return path
def read(path):return json.loads(pin(path).read_bytes())
def main():
    manifest=read(R/'diagnostic-manifest.json');plan=read(R/'diagnostic-plan.json')
    pin(R/'diagnostic-plan.json',manifest['plan_sha256'])
    check(plan['input_sha256']==manifest['inputs'],'exact plan inputs')
    for path,h in manifest['inputs'].items():pin(path,h)
    for file in ('frozen-extensions.json','validated-test-source.json','test-helper-sources.json'):
        for path,h in read(R/file).items():pin(R/'experiment-source'/path,h)
    runner=R/'experiment-source/scripts/ops/autoencoder/diagnose_contextual_scalar_margins.py'
    spec=importlib.util.spec_from_file_location('_readiness_scalar_runner',runner)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.validate_plan(plan)
    check(len(manifest['saved_summaries'])==18,'18 saved final states')
    provenance=read(R/'test-import-provenance-scoped.json')
    check(provenance['pytest_returncode']==0,'regression tests passed')
    for value in provenance['modules'].values():pin(value['path'],value['sha256'])
    root=ET.parse(pin(R/'tests-scoped.xml')).getroot()
    suites=list(root.iter('testsuite'))
    check(sum(int(s.get('tests',0)) for s in suites)>2801,'new and inherited regression cases')
    check(all(int(s.get('failures',0))==int(s.get('errors',0))==0 for s in suites),'no regression failures')
    check(not root.findall('.//skipped'),'no skipped cases counted')
    for name in ('test_generated_scalar_observation','test_contextual_scalar_margins_runner'):
        check(any(name in c.get('classname','') for c in root.findall('.//testcase')),'new suite ran '+name)
    watchdog=read(R/'watchdog-test-results.json');check(watchdog['returncode']==0,'isolated guardian passed')
    for path,h in watchdog.get('source_sha256',{}).items():pin(path,h)
    for path,expected in watchdog.get('artifacts',{}).items():
        pin(path,expected['sha256']);check(Path(path).stat().st_size==expected['bytes'],'guardian artifact bytes '+path)
    runtime=read(R/'guardian-runtime-provenance.json')
    for path,expected in runtime['artifacts'].items():
        pin(path,expected['sha256']);check(Path(path).stat().st_size==expected['bytes'],'guardian runtime bytes '+path)
    for name in ('run_diagnostic_reserved.py','run_guardian.py','owned_lease_watchdog.py',
        'adopt_shared_scheduler.py','test_owned_lease_watchdog.py','readiness.py','freeze.py','run_frozen_tests.py'):
        pin(R/name)
    check(manifest['published_commit']==read(R/'base.json')['base'],'declared publication revision')
    for key in ('publication_manifest','publication_results'):
        path=Path(manifest[key]);content=subprocess.check_output(['git','show',manifest['published_commit']+':'+str(path.relative_to(P))],cwd=P)
        check(hashlib.sha256(content).hexdigest()==sha(path),'published '+key)
    before=read(R/'before.json')['checkpoint'];pin(before['path'],before['sha256'])
    check(Path(before['path']).stat().st_size==before['bytes'],'protected size')
    result=dict(schema='contextual-scalar-diagnostic-readiness/v1',passed=not findings,checks=checks,
        finding_count=len(findings),findings=findings,artifacts=artifacts,training_executed=False,
        qualification_unchanged=True,qualified=False,admitted=False,proof_authority=False,
        frozen_source_provenance=True,inherited_unselected_setup_cases=16)
    path=R/'readiness.json';assert not path.exists()
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('passed','checks','findings')}));sys.exit(bool(findings))
if __name__=='__main__':main()
