"""Read-only exact producer/current-main compatibility before alternate-index publication."""
from pathlib import Path
import hashlib,json,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
BASE=json.loads((R/'base.json').read_bytes())['base'];E=P/'docs/implementation/reports/evidence/decoder-contextual-margins-20261004'
def git(*args):return subprocess.check_output(['git',*args],cwd=P)
def sha(b):return hashlib.sha256(b).hexdigest()
remote=git('rev-parse','origin/main').decode().strip()
subprocess.check_call(['git','merge-base','--is-ancestor',BASE,remote],cwd=P)
manifest=json.loads((E/'manifest.json').read_bytes());owned=json.loads((R/'owned-files.json').read_bytes())
changed=set(git('diff','--name-only',BASE+'..'+remote).decode().splitlines())
producer_overlap=changed & set(manifest['validated_producer_source_sha256']);owned_overlap=changed & set(owned)
assert not producer_overlap and not owned_overlap, dict(producer_overlap=sorted(producer_overlap),owned_overlap=sorted(owned_overlap))
assert manifest['publication_producer_overrides']=={}
assert manifest['validated_producer_source_sha256']==manifest['publication_producer_source_sha256']
intentional=set(json.loads((R/'code-files.json').read_bytes()))
comparisons={}
for rel,h in manifest['publication_producer_source_sha256'].items():
 value=subprocess.run(['git','show',remote+':'+rel],cwd=P,capture_output=True)
 old=None if value.returncode else sha(value.stdout)
 if old!=h:
  assert rel in intentional and sha((P/rel).read_bytes())==h,rel
 comparisons[rel]=dict(parent_sha256=old,validated_sha256=h,intentional_change=old!=h)
result=dict(publication_parent=remote,validated_base=BASE,producer_overlap=[],reviewed_producer_overlap=sorted(producer_overlap),owned_overlap=sorted(owned_overlap),
 producer_overrides=manifest['publication_producer_overrides'],
 comparisons=comparisons,producer_count=len(comparisons),changed_producers=[p for p,v in comparisons.items() if v['intentional_change']],
 passed=True,publication_performed=False,head_or_index_changed=False)
(R/'publication-compatibility.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='comparisons'}))
