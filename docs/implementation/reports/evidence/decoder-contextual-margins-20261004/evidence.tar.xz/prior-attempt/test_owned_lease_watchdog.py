"""Isolated scheduler-file and owned-CPU-child tests; no shared scheduler clients."""
from copy import deepcopy
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
from types import SimpleNamespace

import pytest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned_lease_watchdog',HERE/'owned_lease_watchdog.py')
w=importlib.util.module_from_spec(spec);sys.modules[spec.name]=w;spec.loader.exec_module(w)


def process(pid):
    try:raw=Path('/proc',str(pid),'stat').read_text()
    except FileNotFoundError:return None
    row=raw[raw.rfind(')')+2:].split()
    return dict(pid=pid,birth=row[19],parent_pid=int(row[1]),group_pid=int(row[2]),state=row[0])


class FakeResources:
    def __init__(self,pid=None):
        self.child=pid or os.getpid()+100000
        self.live=1;self.reused=False;self.calls=[]
    def _process(self,pid):
        if pid==os.getpid():return process(pid)
        if pid==self.child:return dict(pid=pid,birth='child-birth',parent_pid=os.getpid(),group_pid=pid)
        return None
    def _group_usage(self,identity):
        self.calls.append(dict(identity))
        if self.reused:raise RuntimeError('child PID was reused')
        return dict(available=True,live_processes=self.live,rss_bytes=0)


class RealResources:
    _process=staticmethod(process)
    @staticmethod
    def _group_usage(identity):
        row=process(identity['pid'])
        if row is not None and row['birth']!=identity['birth']:raise RuntimeError('child PID was reused')
        return dict(available=True,live_processes=int(row is not None and row['state']!='Z'),rss_bytes=0)


@pytest.fixture
def sample(tmp_path):
    state_path=tmp_path/'scheduler.json';lock_path=tmp_path/'scheduler.json.lock';lock_path.write_text('')
    now=time.time();fields=dict(lease_id='our-lease',lane='hammer_lean',cpu_slots=1,memory_mb=4096,gpu_memory_mb=0,
        unified_memory_mb=0,child_process_slots=1,requires_gpu=False,parent_lease_id=None,
        owner_pid=os.getpid(),owner_birth_marker=process(os.getpid())['birth'],acquired_at=now-1)
    capability='opaque-own-capability-never-output-83401';foreign='opaque-foreign-capability-never-output-83200'
    row=dict(fields,lease_key=capability,heartbeat_at=now,expires_at=now+120,cancelled=False)
    config=dict(total_cpu_slots=4,total_memory_mb=9830,lane_reservations={'validation':{'cpu_slots':1,'memory_mb':0}})
    state=dict(schema_version=w.SCHEDULER_SCHEMA,config=config,leases={'our-lease':row,'foreign':{'lease_key':foreign}},
               waiters={'foreign-waiter':{'owner_pid':987654}},metrics={},next_sequence=3)
    state_path.write_text(json.dumps(state));meta=lock_path.stat()
    binding=w.LeaseBinding(state_path,lock_path,deepcopy(config),fields,(meta.st_dev,meta.st_ino),capability)
    return SimpleNamespace(path=state_path,lock=lock_path,state=state,binding=binding,capability=capability,foreign=foreign,tmp=tmp_path)


def write(sample):sample.path.write_text(json.dumps(sample.state))


def watch(sample,resources=None,**kwargs):
    resources=resources or FakeResources();sent=[]
    watcher=w.OwnedLeaseWatchdog(sample.binding,resources=resources,events_path=sample.tmp/'events.jsonl',
        poll_seconds=.02,lock_timeout=.05,max_observation_gap=.2,signal_group=lambda *args:sent.append(args),**kwargs)
    return watcher,resources,sent


def bind(watcher,resources):watcher.bind_child(dict(pid=resources.child,birth='child-birth'))


def test_read_only_healthy_and_foreign_records_unchanged(sample):
    before=sample.path.read_bytes();lock_before=sample.lock.read_bytes()
    event=w.observe_lease(sample.binding,stage='pre_spawn')
    assert event['healthy'] and event['lease_present'] and event['configuration_matches']
    assert sample.path.read_bytes()==before and sample.lock.read_bytes()==lock_before
    assert sample.capability not in json.dumps(event) and sample.foreign not in json.dumps(event)
    assert sample.capability not in repr(sample.binding)


def test_atomic_state_replacement_with_same_lock_is_valid(sample):
    temp=sample.tmp/'next.json';temp.write_bytes(sample.path.read_bytes());os.replace(temp,sample.path)
    assert w.observe_lease(sample.binding,stage='monitor')['healthy']


@pytest.mark.parametrize('mutation,code',[
    ('config','scheduler_configuration_changed'),('missing','owned_lease_missing'),
    ('key','owned_lease_authority_changed'),('cancelled','owned_lease_cancelled'),
    ('expired','owned_lease_expired'),('clock','invalid_owned_lease_clock'),
    ('schema','scheduler_schema_changed'),('containers','invalid_scheduler_containers'),
    ('cancel_secret','invalid_owned_cancellation_flag')])
def test_failures_capture_sanitized_facts_without_mutating_state(sample,mutation,code):
    row=sample.state['leases']['our-lease']
    if mutation=='config':sample.state['config']['total_cpu_slots']=3
    elif mutation=='missing':sample.state['leases'].pop('our-lease')
    elif mutation=='key':row['lease_key']='different-secret'
    elif mutation=='cancelled':row['cancelled']=True
    elif mutation=='expired':row.update(heartbeat_at=row['acquired_at']+.05,expires_at=row['acquired_at']+.1)
    elif mutation=='clock':row['expires_at']=float('nan')
    elif mutation=='schema':sample.state['schema_version']='unknown'
    elif mutation=='containers':sample.state['leases']=[]
    else:row['cancelled']=sample.capability
    write(sample);before=sample.path.read_bytes()
    with pytest.raises(w.LeaseWatchdogError) as caught:w.observe_lease(sample.binding,stage='monitor')
    assert caught.value.code==('nonfinite_state_json' if mutation=='clock' else code)
    serialized=json.dumps(caught.value.observation)
    assert sample.capability not in serialized and sample.foreign not in serialized
    assert sample.path.read_bytes()==before


@pytest.mark.parametrize('field',w.OWN_FIELDS)
def test_immutable_owned_identity_checks_every_bound_field(sample,field):
    value=sample.state['leases']['our-lease'][field]
    sample.state['leases']['our-lease'][field]=('wrong' if type(value) is not str else value+'-wrong')
    write(sample)
    with pytest.raises(w.LeaseWatchdogError,match='owned_lease_identity_changed'):
        w.observe_lease(sample.binding,stage='monitor')


@pytest.mark.parametrize('kind',['disappeared','corrupt','duplicate','symlink','fifo','oversize','lock_missing','lock_replaced','lock_symlink','lock_hardlink'])
def test_missing_or_unsafe_files_fail_without_creation(sample,kind,monkeypatch):
    if kind=='disappeared':sample.path.unlink()
    elif kind=='corrupt':sample.path.write_text('{invalid')
    elif kind=='duplicate':sample.path.write_text('{"lease_key":1,"lease_key":2}')
    elif kind=='symlink':sample.path.unlink();sample.path.symlink_to(sample.lock)
    elif kind=='fifo':sample.path.unlink();os.mkfifo(sample.path)
    elif kind=='oversize':monkeypatch.setattr(w,'MAX_STATE_BYTES',10)
    elif kind=='lock_missing':sample.lock.unlink()
    elif kind=='lock_replaced':temp=sample.tmp/'new-lock';temp.write_text('');os.replace(temp,sample.lock)
    elif kind=='lock_symlink':sample.lock.unlink();sample.lock.symlink_to(sample.path)
    else:os.link(sample.lock,sample.tmp/'duplicate-lock')
    names=set(sample.tmp.iterdir())
    with pytest.raises(w.LeaseWatchdogError):w.observe_lease(sample.binding,stage='monitor',lock_timeout=.05)
    assert set(sample.tmp.iterdir())==names


def test_bounded_shared_lock_wait(sample):
    with sample.lock.open('r') as stream:
        fcntl.flock(stream.fileno(),fcntl.LOCK_EX)
        started=time.monotonic()
        with pytest.raises(w.LeaseWatchdogError,match='scheduler_lock_timeout'):
            w.observe_lease(sample.binding,stage='monitor',lock_timeout=.05)
        assert time.monotonic()-started<.5


def test_configuration_failure_retains_exact_fingerprint_not_capabilities(sample):
    sample.state['config']['total_cpu_slots']=2;write(sample)
    with pytest.raises(w.LeaseWatchdogError) as caught:w.observe_lease(sample.binding,stage='monitor')
    event=caught.value.observation
    assert event['observed_config_sha256']==w._digest(sample.state['config'])
    assert event['changed_known_configuration_fields']==['total_cpu_slots']
    assert event['state_sha256']==w.hashlib.sha256(sample.path.read_bytes()).hexdigest()


def test_expected_absent_requires_actual_removal_and_same_configuration(sample):
    with pytest.raises(w.LeaseWatchdogError,match='still_present'):
        w.observe_lease(sample.binding,stage='post_finalize',expected='absent')
    sample.state['leases'].pop('our-lease');write(sample)
    assert w.observe_lease(sample.binding,stage='post_finalize',expected='absent')['healthy']
    sample.state['config']['total_cpu_slots']=2;write(sample)
    with pytest.raises(w.LeaseWatchdogError,match='configuration_changed'):
        w.observe_lease(sample.binding,stage='post_finalize',expected='absent')


def test_background_failure_interrupts_only_captured_group_and_preserves_foreign_claims(sample):
    watcher,resources,sent=watch(sample)
    try:
        watcher.observe('pre_spawn');bind(watcher,resources);watcher.start()
        foreign=deepcopy(sample.state['leases']['foreign']);sample.state['leases'].pop('our-lease');write(sample)
        deadline=time.monotonic()+2
        while watcher.failure_receipt() is None and time.monotonic()<deadline:time.sleep(.01)
        watcher.stop()
        with pytest.raises(w.LeaseWatchdogError,match='owned_lease_missing'):watcher.assert_healthy()
        assert sent==[(resources.child,signal.SIGINT)]
        assert sample.state['leases']['foreign']==foreign
        assert json.loads(sample.path.read_text())==sample.state
    finally:watcher.close()
    output=(sample.tmp/'events.jsonl').read_text()
    assert sample.capability not in output and sample.foreign not in output


def test_pid_reuse_refuses_signal(sample):
    watcher,resources,sent=watch(sample)
    try:
        bind(watcher,resources);resources.reused=True;sample.state['leases'].pop('our-lease');write(sample)
        with pytest.raises(w.LeaseWatchdogError):watcher.observe('monitor')
        assert not sent and watcher.failure_receipt()['child_interrupt']['status']=='signal_refused_or_failed'
    finally:watcher.close()


def test_already_exited_child_is_not_signalled(sample):
    watcher,resources,sent=watch(sample)
    try:
        bind(watcher,resources);resources.live=0;sample.state['leases'].pop('our-lease');write(sample)
        with pytest.raises(w.LeaseWatchdogError):watcher.observe('monitor')
        assert not sent and watcher.failure_receipt()['child_interrupt']['status']=='owned_group_already_exited'
    finally:watcher.close()


def test_late_child_binding_still_interrupts_after_prior_failure(sample):
    watcher,resources,sent=watch(sample)
    try:
        sample.state['leases'].pop('our-lease');write(sample)
        with pytest.raises(w.LeaseWatchdogError):watcher.observe('pre_spawn')
        assert not sent
        bind(watcher,resources)
        assert sent==[(resources.child,signal.SIGINT)]
    finally:watcher.close()


def test_wrong_parent_or_group_never_becomes_signal_target(sample):
    watcher,resources,sent=watch(sample)
    resources._process=lambda pid:dict(pid=pid,birth='child-birth',parent_pid=99999,group_pid=pid)
    try:
        with pytest.raises(w.LeaseWatchdogError,match='not_owned'):bind(watcher,resources)
        assert not sent
    finally:watcher.close()


def test_log_failure_cannot_prevent_child_interrupt(sample,monkeypatch):
    watcher,resources,sent=watch(sample)
    try:
        bind(watcher,resources)
        monkeypatch.setattr(watcher,'_record',lambda event:(_ for _ in ()).throw(OSError('private-message')))
        sample.state['leases'].pop('our-lease');write(sample)
        with pytest.raises(w.LeaseWatchdogError):watcher.observe('monitor')
        assert sent==[(resources.child,signal.SIGINT)]
        assert watcher.failure_receipt()['evidence_write_error_type']=='OSError'
        assert 'private-message' not in json.dumps(watcher.failure_receipt())
    finally:watcher.close()


def test_gap_fails_closed_even_when_next_snapshot_would_be_healthy(sample):
    watcher,resources,sent=watch(sample)
    try:
        watcher.observe('pre_spawn');bind(watcher,resources);watcher._last-=1
        with pytest.raises(w.LeaseWatchdogError,match='observation_gap_exceeded'):watcher.observe('monitor')
        assert sent==[(resources.child,signal.SIGINT)]
    finally:watcher.close()


def test_monitor_is_independent_of_slow_census_and_stops_real_owned_cpu_child(sample):
    child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)'],start_new_session=True,
                           stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    watcher=w.OwnedLeaseWatchdog(sample.binding,resources=RealResources(),events_path=sample.tmp/'events.jsonl',
        poll_seconds=.02,lock_timeout=.05,max_observation_gap=.2)
    try:
        row=process(child.pid);watcher.bind_child(dict(pid=child.pid,birth=row['birth']));watcher.start()
        sample.state['config']['total_cpu_slots']=2;write(sample)
        time.sleep(.25) # Main guardian represents a slow accounting operation.
        assert child.wait(timeout=2)!=0
        assert watcher.failure_receipt()['code']=='scheduler_configuration_changed'
        assert watcher.failure_receipt()['child_interrupt']['status']=='SIGINT_sent'
    finally:
        watcher.close()
        if child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=2)


def test_healthy_monitor_stopped_before_release_allows_absent_postcheck(sample):
    watcher,resources,sent=watch(sample)
    try:
        watcher.observe('pre_spawn');bind(watcher,resources);watcher.start();time.sleep(.03);watcher.stop()
        watcher.assert_healthy();watcher.observe('pre_finalize')
        sample.state['leases'].pop('our-lease');write(sample)
        assert watcher.observe('post_finalize',expected='absent')['healthy']
        assert not sent and watcher.failure_receipt() is None
    finally:watcher.close()


def test_capture_and_cached_snapshot_never_touch_cancelled_or_to_dict(sample):
    class Lease(SimpleNamespace):
        @property
        def cancelled(self):raise AssertionError('scheduler access forbidden')
        def to_dict(self):raise AssertionError('scheduler access forbidden')
    client=SimpleNamespace(state_path=sample.path,lock_path=sample.lock,config=SimpleNamespace(persisted_dict=lambda:deepcopy(sample.binding.config)))
    attrs={k:v for k,v in sample.binding.own_fields.items() if k!='owner_birth_marker'}
    lease=Lease(**attrs,lease_key=sample.capability,_scheduler=client,_released=False,wait_seconds=0.)
    owner=SimpleNamespace(_lease=lease,_entered=True,_owner_pid=os.getpid(),reservation_id='disk',ledger_path=sample.tmp/'ledger',
        _record={'status':'retained','owner_pid':os.getpid()},_cleanup_error='ResourceConfigurationError')
    adoption=dict(shared_config=sample.binding.config,shared_config_sha256=w._digest(sample.binding.config),observed_after={'path':str(sample.path)})
    binding=w.capture_lease_binding(owner,adoption,FakeResources())
    assert binding==sample.binding
    snapshot=w.safe_owner_snapshot(owner)
    assert snapshot['record']['status']=='retained' and not snapshot['scheduler_state_read']
    assert sample.capability not in json.dumps(snapshot)
    assert 'scheduler access' not in json.dumps(w.safe_exception(RuntimeError(sample.capability)))
    assert sample.capability not in json.dumps(w.safe_exception(RuntimeError(sample.capability)))


@pytest.mark.parametrize('argument,value',[('poll_seconds',0),('poll_seconds',float('nan')),('lock_timeout',11),('max_observation_gap',.01)])
def test_invalid_bounds_fail_before_log_creation(sample,argument,value):
    args=dict(resources=FakeResources(),events_path=sample.tmp/'events.jsonl');args[argument]=value
    with pytest.raises(w.LeaseWatchdogError):w.OwnedLeaseWatchdog(sample.binding,**args)
    assert not (sample.tmp/'events.jsonl').exists()


def test_existing_observation_log_is_never_overwritten(sample):
    path=sample.tmp/'events.jsonl';path.write_text('previous evidence')
    with pytest.raises(FileExistsError):watch(sample)
    assert path.read_text()=='previous evidence'


def test_mutating_bound_configuration_is_refused(sample):
    sample.binding.config['total_cpu_slots']=9
    with pytest.raises(w.LeaseWatchdogError,match='lease_binding_changed'):
        w.observe_lease(sample.binding,stage='monitor')


def test_mutating_bound_identity_is_refused(sample):
    sample.binding.own_fields['owner_pid']=1234
    with pytest.raises(w.LeaseWatchdogError,match='lease_binding_changed'):
        w.observe_lease(sample.binding,stage='monitor')


def test_main_thread_detects_stalled_observer_without_waiting_for_log_mutex(sample):
    watcher,resources,sent=watch(sample)
    try:
        bind(watcher,resources);watcher._thread=SimpleNamespace(is_alive=lambda:False,join=lambda timeout:None)
        watcher._last=time.monotonic()-1;watcher._io.acquire()
        try:
            with pytest.raises(w.LeaseWatchdogError,match='observation_gap_exceeded'):watcher.assert_healthy()
            assert sent==[(resources.child,signal.SIGINT)]
            assert watcher.failure_receipt()['evidence_write_error_type']=='ObservationLogBusy'
        finally:watcher._io.release()
    finally:watcher.close()


def test_invalid_untrusted_cancellation_value_cannot_leak_capability_in_failure_receipt(sample):
    watcher,resources,sent=watch(sample)
    try:
        bind(watcher,resources);sample.state['leases']['our-lease']['cancelled']=sample.capability;write(sample)
        with pytest.raises(w.LeaseWatchdogError):watcher.observe('monitor')
        assert sample.capability not in json.dumps(watcher.failure_receipt())
        assert sample.capability not in (sample.tmp/'events.jsonl').read_text()
    finally:watcher.close()


@pytest.fixture
def guardian_case(sample,monkeypatch):
    spec=importlib.util.spec_from_file_location('watchdog_guardian_case',HERE/'run_diagnostic_reserved.py')
    guardian=importlib.util.module_from_spec(spec);spec.loader.exec_module(guardian)
    run=sample.tmp/'run';run.mkdir();plan=run/'diagnostic-plan.json';plan.write_text('{}')
    (run/'diagnostic-manifest.json').write_text(json.dumps(dict(extensions={},inputs={},plan_sha256=w.hashlib.sha256(plan.read_bytes()).hexdigest())))
    resources=FakeResources();case=SimpleNamespace(mode='healthy',owner=None,resources=resources,run=run,guardian=guardian,sample=sample,
                                                 final_calls=0,to_dict_calls=0,signals=[])
    class Lease(SimpleNamespace):
        @property
        def cancelled(self):raise AssertionError('cancelled query must never be used by safe failure handling')
    client=SimpleNamespace(state_path=sample.path,lock_path=sample.lock,config=SimpleNamespace(persisted_dict=lambda:deepcopy(sample.binding.config)))
    attrs={k:v for k,v in sample.binding.own_fields.items() if k!='owner_birth_marker'}
    lease=Lease(**attrs,lease_key=sample.capability,_scheduler=client,_released=False,wait_seconds=0.)
    class Owner:
        def __init__(self,ledger,**kwargs):
            case.reservation_arguments=dict(kwargs);case.reservation_ledger=ledger
            self._lease=lease;self._entered=False;self._owner_pid=os.getpid();self.ledger_path=ledger
            self.reservation_id='owned-disk';self._record={'status':'reserved','owner_pid':os.getpid()};self._cleanup_error=None;case.owner=self
        def __enter__(self):self._entered=True;return self
        def __exit__(self,kind,error,trace):
            if kind is not None:
                self._cleanup_error='ResourceConfigurationError';self._record['status']='retained'
            return False
        def check_usage(self,attempt,child_pid=None):
            if case.mode=='accounting_failure':raise RuntimeError('accounting primary failure')
            return dict(group_rss={'live_processes':0,'rss_bytes':0})
        def to_dict(self):
            case.to_dict_calls+=1
            if case.mode in ('drift_at_spawn','capture_failure'):raise AssertionError('unsafe failure to_dict called')
            return dict(record=deepcopy(self._record),status=self._record['status'])
        def finalize(self,attempt,artifacts_durable=False):
            case.final_calls+=1;self._record['status']='released'
            if case.mode=='finalize_configuration_error':raise RuntimeError(sample.capability)
            sample.state['leases'].pop('our-lease');write(sample);lease._released=True
            if case.mode=='drift_after_release':sample.state['config']['total_cpu_slots']=2;write(sample)
            return dict(record=deepcopy(self._record),status='released')
    resources.DaemonResourceReservation=Owner
    adoption=dict(shared_config=deepcopy(sample.binding.config),shared_config_sha256=w._digest(sample.binding.config),observed_after={'path':str(sample.path)})
    monkeypatch.setitem(sys.modules,'adopt_shared_scheduler',SimpleNamespace(adopt_for_owner=lambda *a,**k:adoption))
    monkeypatch.setattr(guardian,'RUN',run);monkeypatch.setattr(guardian,'resource_owner',lambda:resources)
    monkeypatch.setattr(sys,'argv',['run_diagnostic_reserved.py','--phase','diagnostic','--attempt','attempt'])
    class Child:
        pid=resources.child
        def poll(self):return 0
        def wait(self,timeout=None):return 0
    def spawn(*args,**kwargs):
        case.child_command=args[0];case.child_options=kwargs
        (run/'attempt/results').mkdir();(run/'attempt/results/summary.json').write_text('{"complete":true}')
        resources.live=0
        if case.mode=='drift_at_spawn':sample.state['config']['total_cpu_slots']=2;write(sample)
        if case.mode=='capture_failure':resources._process=lambda pid:process(pid) if pid==os.getpid() else None
        return Child()
    monkeypatch.setattr(guardian.subprocess,'Popen',spawn)
    return case


def test_guardian_healthy_fast_child_has_pre_and_post_checks(guardian_case):
    c=guardian_case;c.guardian.main()
    result=json.loads((c.run/'attempt/resources-final.json').read_text())
    assert result['status']=='released' and c.final_calls==1
    assert result['lease_watchdog']['post_release_observation']['lease_present'] is False
    events=[json.loads(line) for line in (c.run/'attempt-lease-observations.jsonl').read_text().splitlines()]
    assert [e['stage'] for e in events if 'stage' in e]==['pre_spawn','post_spawn','pre_finalize','post_finalize']
    assert not (c.run/'attempt/failure.json').exists()
    assert c.sample.capability not in json.dumps(result)


@pytest.mark.parametrize('mode,original_type,code',[
    ('drift_at_spawn','LeaseWatchdogError','scheduler_configuration_changed'),
    ('accounting_failure','RuntimeError',None),
    ('finalize_configuration_error','RuntimeError',None),
    ('drift_after_release','LeaseWatchdogError','scheduler_configuration_changed'),
    ('capture_failure','RuntimeError',None),
])
def test_guardian_failure_receipts_survive_scheduler_and_cleanup_failures(guardian_case,mode,original_type,code):
    c=guardian_case;c.mode=mode
    with pytest.raises(RuntimeError,match='guardian failed') as caught:c.guardian.main()
    assert c.sample.capability not in str(caught.value)
    primary=json.loads((c.run/'attempt/failure-primary.json').read_text())
    final=json.loads((c.run/'attempt/failure.json').read_text())
    assert primary['error']['error_type']==original_type and primary['error']['code']==code
    assert final['error']==primary['error']
    assert final['resources']['scheduler_state_read'] is False
    assert final['resources']['cleanup_error']=='ResourceConfigurationError'
    assert final['automatic_scheduler_reset'] is False and not final['replacement_lease_acquired']
    assert not (c.run/'attempt/resources-final.json').exists()
    if mode in ('drift_at_spawn','capture_failure'):assert c.to_dict_calls==0
    if mode=='capture_failure':assert final['cleanup']['cleanup_verified'] is False
    serialized=''.join(p.read_text() for p in c.run.rglob('*.json'))
    assert c.sample.capability not in serialized and c.sample.foreign not in serialized


def test_guardian_cleanup_pid_reuse_refuses_group_signal(guardian_case,monkeypatch):
    c=guardian_case;c.resources.reused=True;sent=[]
    monkeypatch.setattr(c.guardian.os,'killpg',lambda *args:sent.append(args))
    child=SimpleNamespace(pid=c.resources.child,poll=lambda:None,wait=lambda timeout:0)
    with pytest.raises(RuntimeError,match='reused'):
        c.guardian.cleanup_owned_group(child,{'pid':child.pid,'birth':'child-birth'},c.resources,grace_seconds=.01,kill_seconds=.01)
    assert not sent


def test_diagnostic_uses_exact_small_reservation_and_frozen_inference_command(guardian_case):
    c=guardian_case;c.guardian.main()
    assert c.reservation_arguments['storage_bytes']==300_000_000
    assert c.reservation_arguments['memory_mb']==4096
    assert c.reservation_arguments['cpu_slots']==c.reservation_arguments['child_process_slots']==1
    assert c.reservation_arguments['timeout_seconds']==300
    assert c.child_command==[sys.executable,
        str(c.run/'experiment-source/scripts/ops/autoencoder/diagnose_contextual_scalar_margins.py'),
        '--phase','diagnostic','--dependency-root',str(c.guardian.SOURCE),
        '--extension-root',str(c.run/'experiment-source'),
        '--manifest',str(c.run/'diagnostic-manifest.json'),
        '--plan',str(c.run/'diagnostic-plan.json'),
        '--output',str(c.run/'attempt/results')]
    assert c.child_options['cwd']==c.guardian.SOURCE
    assert c.child_options['start_new_session'] is True
    env=c.child_options['env']
    assert env['PYTHONPATH']==str(c.guardian.SOURCE)
    for name in ('HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_DATASETS_OFFLINE','PYTHONDONTWRITEBYTECODE',
                 'OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
        assert env[name]=='1'
    assert env['CUDA_VISIBLE_DEVICES']==''
    assert env['IPFS_DATASETS_LEGAL_IR_METRIC_DISK_CACHE']=='0'
    command=json.loads((c.run/'attempt/command.json').read_text())
    assert 'inference only' in command['scheduler_scope']
    assert 'no training' in command['scheduler_scope']
    assert command['guardian_revision']=='run_diagnostic_reserved.py'


def test_training_phase_is_rejected_before_resource_access(guardian_case,monkeypatch):
    c=guardian_case
    monkeypatch.setattr(sys,'argv',['run_diagnostic_reserved.py','--phase','training','--attempt','attempt'])
    with pytest.raises(SystemExit) as caught:c.guardian.main()
    assert caught.value.code==2 and c.owner is None
    assert not (c.run/'attempt').exists()


@pytest.mark.parametrize('changed',['plan','input','extension'])
def test_sealed_diagnostic_mutation_is_rejected_before_resource_access(guardian_case,changed):
    c=guardian_case;manifest_path=c.run/'diagnostic-manifest.json';manifest=json.loads(manifest_path.read_text())
    if changed=='plan':(c.run/'diagnostic-plan.json').write_text('{"different":true}')
    elif changed=='input':
        source=c.run/'input.json';source.write_text('{}')
        manifest['inputs'][str(source)]='0'*64
    else:
        source=c.run/'experiment-source/module.py';source.parent.mkdir();source.write_text('')
        manifest['extensions']['module.py']='0'*64
    manifest_path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError,match='changed before admission'):c.guardian.main()
    assert c.owner is None and not (c.run/'attempt').exists()


def test_diagnostic_deadline_retains_timeout_and_cleans_owned_child(guardian_case,monkeypatch):
    c=guardian_case;original_spawn=c.guardian.subprocess.Popen
    def spawn(*args,**kwargs):
        child=original_spawn(*args,**kwargs)
        child.poll=lambda:None
        return child
    monkeypatch.setattr(c.guardian.subprocess,'Popen',spawn)
    ticks=iter([0.,0.,901.])
    monkeypatch.setattr(c.guardian,'time',SimpleNamespace(monotonic=lambda:next(ticks,902.),sleep=lambda seconds:None))
    with pytest.raises(RuntimeError,match='guardian failed: TimeoutError'):c.guardian.main()
    result=json.loads((c.run/'attempt/failure.json').read_text())
    assert result['error']['error_type']=='TimeoutError'
    assert result['cleanup']['leader_reaped'] and result['cleanup']['live_group_processes']==0
    assert c.final_calls==0
    assert not result['automatic_scheduler_reset'] and not result['replacement_lease_acquired']


@pytest.mark.parametrize('returncode',[0,1])
def test_launcher_rehashes_readiness_and_retains_actual_exit(tmp_path,monkeypatch,returncode):
    import runpy
    launcher=tmp_path/'run_guardian.py';launcher.write_bytes((HERE/'run_guardian.py').read_bytes())
    artifact=tmp_path/'pinned.py';artifact.write_text('pinned source')
    expected=dict(bytes=artifact.stat().st_size,sha256=w.hashlib.sha256(artifact.read_bytes()).hexdigest())
    (tmp_path/'readiness.json').write_text(json.dumps(dict(passed=True,findings=[],artifacts={str(artifact):expected})))
    calls=[]
    def execute(command,**kwargs):calls.append(command);return SimpleNamespace(returncode=returncode)
    monkeypatch.setattr(subprocess,'run',execute)
    with pytest.raises(SystemExit) as caught:runpy.run_path(str(launcher),run_name='__main__')
    assert caught.value.code==returncode
    assert calls==[[sys.executable,str(tmp_path/'run_diagnostic_reserved.py'),
                   '--phase','diagnostic','--attempt','diagnostic-r1']]
    assert json.loads((tmp_path/'guardian-exit.json').read_text())['returncode']==returncode


@pytest.mark.parametrize('kind',['failed_readiness','changed_artifact','prior_attempt'])
def test_launcher_refuses_unready_or_repeated_attempt_without_spawning(tmp_path,monkeypatch,kind):
    import runpy
    launcher=tmp_path/'run_guardian.py';launcher.write_bytes((HERE/'run_guardian.py').read_bytes())
    artifact=tmp_path/'pinned.py';artifact.write_text('pinned source')
    expected=dict(bytes=artifact.stat().st_size,sha256=w.hashlib.sha256(artifact.read_bytes()).hexdigest())
    (tmp_path/'readiness.json').write_text(json.dumps(dict(passed=kind!='failed_readiness',findings=[],
        artifacts={str(artifact):expected})))
    if kind=='changed_artifact':artifact.write_text('changed source')
    if kind=='prior_attempt':(tmp_path/'guardian-exit.json').write_text('{"returncode":0}')
    def execute(*args,**kwargs):raise AssertionError('must not spawn')
    monkeypatch.setattr(subprocess,'run',execute)
    with pytest.raises(AssertionError) as caught:runpy.run_path(str(launcher),run_name='__main__')
    assert 'must not spawn' not in str(caught.value)
    assert not (tmp_path/'guardian.log').exists()
