"""Focused CPU tests: frozen R3 dependencies with one explicitly reviewed live owner."""
from pathlib import Path
import hashlib, importlib, importlib.util, json, os, sys, time
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
F=P/'workspace/test-logs/decoder-action-consistency-20261003/experiment-source'
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
A=sys.argv[1]
assert A.isdigit()
output=R/('observation-tests-attempt'+A+'.json')
assert not output.exists()
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
owner='ipfs_datasets_py/logic/formalization/autoencoder/generated_scalar_observation.py'
tests=['test_generated_scalar_observation.py','test_generated_field_training.py','test_contextual_generated_boundary_training.py']
testdir=P/'tests/unit/logic/formalization/autoencoder'
before={str(P/owner):sha(P/owner),**{str(testdir/name):sha(testdir/name) for name in tests}}
os.environ.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',
 TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI='0',CUDA_VISIBLE_DEVICES='',
 OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
sys.dont_write_bytecode=True
sys.path.insert(0,str(S))
package=importlib.import_module('ipfs_datasets_py.logic.formalization.autoencoder')
package.__path__.insert(0,str(F/'ipfs_datasets_py/logic/formalization/autoencoder'))
from ipfs_datasets_py.logic.autoformal.tree_pin import require_workspace_logic_tree
pin=require_workspace_logic_tree()
assert all(Path(path).is_relative_to(S) for path in pin.values())
for name,path in [('ipfs_datasets_py.optimizers.logic_theorem_optimizer.autoencoder_embedding_runtime',
 F/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_embedding_runtime.py'),
 ('ipfs_datasets_py.logic.formalization.autoencoder.generated_scalar_observation',P/owner)]:
 parent=importlib.import_module(name.rsplit('.',1)[0]);assert name not in sys.modules
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
 sys.modules[name]=module;spec.loader.exec_module(module);setattr(parent,name.rsplit('.',1)[1],module)
import pytest
started=time.monotonic()
code=pytest.main(['-q','-c','/dev/null','--confcutdir='+str(testdir),'-p','no:cacheprovider',
 '--junitxml='+str(R/('observation-tests-attempt'+A+'.xml')),*[str(testdir/name) for name in tests]])
modules={}
for name,module in list(sys.modules.items()):
 path=getattr(module,'__file__',None)
 if name.startswith('ipfs_datasets_py') and path and Path(path).is_file():
  resolved=Path(path).resolve()
  assert resolved.is_relative_to(S) or resolved.is_relative_to(F) or resolved==P/owner,(name,str(resolved))
  modules[name]={'path':str(resolved),'sha256':sha(resolved)}
for path,digest in before.items():assert sha(path)==digest,path
result=dict(returncode=int(code),elapsed_seconds=time.monotonic()-started,tree_pin=pin,source_sha256=before,
 modules=modules,live_owner=str(P/owner),dependency_root=str(S),frozen_extensions_root=str(F),
 cpu_only=True,real_campaign_executed=False)
output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('modules',)}))
raise SystemExit(code)
