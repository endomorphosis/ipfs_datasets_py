"""Run the guarded saved-checkpoint diagnosis and retain its actual process exit."""
from pathlib import Path
import json, subprocess, sys, time
r=Path(__file__).resolve().parent
assert not (r/'guardian-exit.json').exists()
import hashlib
ready=json.loads((r/'readiness.json').read_bytes())
assert ready['passed'] and not ready['findings'], 'clean readiness audit required'
for name, expected in ready['artifacts'].items():
 path=Path(name)
 assert path.stat().st_size==expected['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==expected['sha256'], name

start=time.monotonic()
with (r/'guardian.log').open('x') as stream:
 result=subprocess.run([sys.executable,str(r/'run_diagnostic_reserved.py'),'--phase','diagnostic','--attempt','diagnostic-r1'],stdout=stream,stderr=subprocess.STDOUT)
receipt=dict(returncode=result.returncode,wrapper_elapsed_seconds=time.monotonic()-start)
(r/'guardian-exit.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode)
