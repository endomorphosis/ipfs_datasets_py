#!/usr/bin/env python3
"""Fresh 8D/384D/768D action-binding ablation on exposed Legal development rows.

The historical linguistic teacher is untouched. New candidates remain private
formula sidecars; numerical or syntax results never grant Lake admission.
"""
import argparse
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import time

AUTO = 'ipfs_datasets_py/logic/formalization/autoencoder/'
PREFIX = 'ipfs_datasets_py.logic.formalization.autoencoder.'
FALSE = dict(qualified=False, admitted=False, proof_authority=False, source_semantics_verified=False,
    checkpoint_promoted=False, convergence_proven=False, fresh_holdout=False, lake_executed=False,
    formalized=False, roundtrip_ok=False)
ARMS = [dict(name='clauses', factorized=False, action_contrastive_weight=0.),
        dict(name='action-head', factorized=True, action_contrastive_weight=0.),
        dict(name='action-contrastive', factorized=True, action_contrastive_weight=.05)]
for _arm in ARMS:
    _arm.update(head_kind='clauses', order_augmentation=False, generated_boundary_weight=0.)
CONTROLS = [['validation','validation','conditioned'], ['training','train','conditioned'],
    ['zero-condition','validation','zero_condition'], ['source-shuffle','validation','source_shuffle'],
    ['cross-length-shuffle','validation','cross_length_shuffle'],
    ['context-only-shuffle','validation','context_only_shuffle'],
    ['context-reverse','validation','context_reverse'], ['context-rotate','validation','context_rotate']]
FIXED = dict(schema='action-binding-source-training-plan/v1', dimensions=[8,384,768], seed_order=[1729,2718],
    arms=ARMS, fit_count=18, original_training_rows=48, exposed_validation_rows=48,
    fixed_encoder_context_tokens=512, fixed_decoder_output_limit=512, temperature=0,
    action_contrastive_temperature=.1, contrastive_positive_policy='same_action_different_actor',
    contrastive_negative_policy='different_action', contrastive_unique_source_clauses=True,
    fresh_initialization=True, selection_unchanged=True, validation_pairs_added_to_training=False,
    teacher_distillation_used=False, historical_linguistic_teacher_modified=False,
    identity_projection_frozen=True, identity_mse_is_not_learned_reconstruction=True,
    source_independent_donor_tensors_copied=True, dimension_only_ablation=False,
    learning_rate=.001, batch_size=8, epochs_per_source_stage=20, max_seconds_per_arm=180,
    validation_interval=4, expected_optimizer_steps_per_arm=340,
    expected_training_token_presentations_per_arm=225840, expected_row_presentations_per_arm=2440,
    expected_count_presentations_per_arm=2440, expected_source_value_presentations_per_arm=25600,
    expected_balanced_count_presentations={'1':610,'2':610,'4':610,'8':610},
    cardinality_weight=.25, source_value_weight=.25, count_exposure='balanced_all', strategy='semantic_fields',
    baseline_replay_required=True, full_vocabulary_retained=True, syntax_forced=False, closure_forced=False,
    production_promotion_allowed=False, generation_reference_count_access=False, postfit_controls=CONTROLS,
    max_seconds_per_postfit=30, max_seconds_per_numerical_evaluation=20,
    max_seconds_entire_run=3000, max_memory_bytes=536870912,
    no_downloads=True, encoder_executed_during_training=False)


def require(value, message):
    if not value: raise ValueError(message)


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_plan(plan):
    require(type(plan) is dict and all(type(plan.get(k)) is type(v)
        and json.dumps(plan[k],sort_keys=True,allow_nan=False)==json.dumps(v,sort_keys=True,allow_nan=False)
        for k,v in FIXED.items()), 'fixed action-binding comparison differs')


def jobs():
    return [(dimension,seed,deepcopy(arm)) for dimension in FIXED['dimensions']
        for seed in FIXED['seed_order'] for arm in ARMS]


def load_helper(root, pins, path, name):
    require(sha(root/path)==pins[path], 'frozen helper differs: '+path)
    spec=importlib.util.spec_from_file_location(name,root/path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module


def load_context(args):
    manifest=json.loads(args.manifest.read_bytes()); plan=json.loads(args.plan.read_bytes()); validate_plan(plan)
    require(sha(args.plan)==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'], 'fixed inputs differ')
    for path,digest in manifest['inputs'].items(): require(sha(path)==digest, 'input changed: '+path)
    for key in ('parent_manifest','parent_plan','baseline_summary'):
        require(str(Path(manifest[key]).resolve()) in manifest['inputs'], 'unbound manifest alias: '+key)
    native=load_helper(args.extension_root,manifest['extensions'],
        'scripts/ops/autoencoder/benchmark_native_dimension_source_training.py','_action_native_runner')
    oldargs=SimpleNamespace(**vars(args)); oldargs.manifest=Path(manifest['parent_manifest']); oldargs.plan=Path(manifest['parent_plan'])
    ctx=native.load_context(oldargs)
    ctx.update(plan=plan,manifest=manifest,pins=manifest['extensions'],native_runner=native)
    for name in ('action_factorized_clause_decoder_experiment','action_contrastive_decoder_training'):
        ctx['owners'][name]=ctx['helpers'].extension(args.extension_root,AUTO+name+'.py',PREFIX+name,ctx['pins'])
    baseline=json.loads(Path(manifest['baseline_summary']).read_bytes())
    require(baseline.get('complete') is True and len(baseline['runs'])==12, 'complete prior native comparison required')
    ctx['baseline_runs']={r['arm']:r for r in baseline['runs']}
    return ctx


def bind_candidate(ctx, recipe, seed):
    require(recipe in ARMS and seed in FIXED['seed_order'], 'unplanned action candidate')
    model=ctx['native_runner'].bind_candidate(ctx,ctx['native_runner'].ARMS[1],seed)
    if recipe['factorized']:
        model=ctx['owners']['action_factorized_clause_decoder_experiment'].bind_action_factorized_clause_model(
            model,codec=ctx['donor']['codec'])
    return model


def validate_initial(ctx, model, seed, recipe):
    import torch
    baseline=bind_candidate(ctx,ARMS[0],seed); core=ctx['core']; count=lambda m:sum(p.numel() for p in m.parameters() if p.requires_grad)
    expected=64*(ctx['dimension']+1) if recipe['factorized'] else 0
    require(count(model)-count(baseline)==expected, 'action-specific parameter delta differs')
    for name,value in baseline.state_dict().items():
        if not name.startswith('clause_head.'):
            require(name in model.state_dict() and torch.equal(model.state_dict()[name],value), 'inherited initial tensor differs')
    predictions=[]
    with torch.inference_mode():
        for split in ('train','validation'):
            outputs=[]
            for offset in range(0,48,8):
                part=ctx['rows'][split][offset:offset+8]
                data=ctx['native_runner'].transformed_rows(torch,part,ctx['donor']['input_transform'])
                kw=core._source_context_kwargs(torch,part,ctx['source_contexts'][split],ctx['donor']['input_transform'])
                require(torch.equal(model.source_value_logits(data,**kw),baseline.source_value_logits(data,**kw)),
                    'initial scalar logits differ')
                observed=core._greedy(torch,model,data,512,len(ctx['donor']['codec']['target_vocabulary']),time.monotonic()+30,**kw)
                require(observed is not None and torch.equal(observed[0],data), 'initial projection/generation differs')
                outputs.extend(dict(id=r['id'],token_ids=t,generation_status=s) for r,t,s in zip(part,observed[1],observed[2]))
            predictions.append(dict(split=split,predictions=outputs))
    prior=ctx['baseline_runs'][str(ctx['dimension'])+'-clauses-'+str(seed)]['initial_parity']
    require(predictions==prior['predictions'], 'initial generation differs from original immutable baseline')
    return dict(complete=True,dimension=ctx['dimension'],predictions=predictions,
        baseline_trainable_parameters=count(baseline),trainable_parameters=count(model),parameter_delta=expected,
        inherited_initial_tensors_equal=True,initial_scalar_logits_equal=True,prior_initial_generation_equal=True,**FALSE)


def train_candidate(ctx, model, seed, recipe):
    return ctx['owners']['long_span_source_value_training'].train(model,ctx['rows']['train'],ctx['rows']['validation'],
        training_references=ctx['references']['train'],validation_references=ctx['references']['validation'],
        codec=ctx['donor']['codec'],input_transform=ctx['donor']['input_transform'],lineage=ctx['lineage'],
        validate_rule=ctx['validate_rule'],validator_id=ctx['validator_id'],curriculum=ctx['stages'],
        strategy='semantic_fields',cardinality_weight=.25,count_exposure='balanced_all',source_value_weight=.25,
        source_contexts=ctx['source_contexts'],action_contrastive_weight=recipe['action_contrastive_weight'],
        config=dict(seed=seed,max_seconds=180,max_target_tokens=512,batch_size=8,learning_rate=.001,
            max_optimizer_steps=1000,patience=0,validation_interval=4,alpha=0.))


def validate_baseline(ctx, report, panels, seed):
    previous=ctx['baseline_runs'][str(ctx['dimension'])+'-clauses-'+str(seed)]
    old=previous['training']; require(set(report)==set(old), 'baseline report inventory differs')
    fields=sorted(set(old)-{'elapsed_seconds'})
    for field in fields: require(ctx['core'].digest(report[field])==ctx['core'].digest(old[field]), 'baseline replay differs: '+field)
    for role in ('selected','last-attempt'):
        for label,_,_ in CONTROLS:
            require(panels[role][label]['predictions']==previous['postfit'][role][label]['predictions'], 'baseline control predictions differ')
    return dict(complete=True,compared_training_fields=fields,all_tensors_and_predictions_equal=True,timing_equality_claimed=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('dependency-root','extension-root','manifest','plan','output'): parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--phase',choices=['training'],required=True); args=parser.parse_args()
    started=time.monotonic(); ctx=load_context(args); h=ctx['helpers']; core=ctx['core']; save=h.save
    before=h.inventory(args.dependency_root,args.extension_root,ctx['pins']); args.output.mkdir(parents=True)
    save(args.output/'sealed-recipe.json',dict(plan=ctx['plan'],manifest=ctx['manifest'],tree_pin=ctx['tree'],**FALSE))
    runs=[]
    for dimension in FIXED['dimensions']:
        lane=ctx['native_runner'].prepare_dimension(ctx,dimension)
        save(args.output/str(dimension)/'preprocessing.json',lane['preparation'])
        save(args.output/str(dimension)/'source-contexts.json',lane['source_contexts'])
        save(args.output/str(dimension)/'training-rows.json',lane['rows'])
        for seed in FIXED['seed_order']:
            for recipe in ARMS:
                require(time.monotonic()-started<FIXED['max_seconds_entire_run'], 'comparison deadline exceeded')
                arm_started=time.monotonic(); name=str(dimension)+'-'+recipe['name']+'-'+str(seed); folder=args.output/name
                lane['lineage']['student_lineage']=('native_dimension_formula_sidecar:' if recipe==ARMS[0] else 'action_binding_formula_sidecar:')+name
                model=bind_candidate(lane,recipe,seed); initial=validate_initial(lane,model,seed,recipe)
                save(folder/'initial-parity.json',initial)
                states={'initial':ctx['native_runner'].save_state(lane,model,recipe,'initial',False,folder/'initial-state.json')}
                fit_started=time.monotonic(); value=train_candidate(lane,model,seed,recipe)
                fit_seconds=time.monotonic()-fit_started; report=value['report']; save(folder/'training.json',report)
                require(report['stopped_reason']=='epochs_completed' and report['optimizer_steps']==340
                    and report['row_presentations']==2440 and report['valid_target_token_presentations']==225840
                    and report['source_value_presentations']==25600 and report['count_training_row_presentations']==2440
                    and report['count_training_presentations_by_class']==FIXED['expected_balanced_count_presentations'],
                    'incomplete action-binding training exposure')
                postfit={}
                for role,state,predictions in [('selected',value['state_dict'],value['predictions']),
                    ('last-attempt',value['last_complete_attempt_state_dict'],value['last_complete_attempt_predictions'])]:
                    require(state is not None, 'complete selected/final state required')
                    ctx['native_runner'].validate_wrapper_state(lane,state); model.load_state_dict(state,strict=True)
                    expected=report['selected_weights_sha256'] if role=='selected' else report['last_complete_attempt_weights_sha256']
                    require(core.tensor_digest(model)==expected, 'training state hash differs')
                    states[role]=ctx['native_runner'].save_state(lane,model,recipe,role,
                        role=='selected' or report['last_complete_attempt_is_selected'],folder/(role+'-state.json'))
                    postfit[role]={}
                    for label,split,control in CONTROLS:
                        panel=ctx['clause_runner'].evaluate(lane,model,split,control)
                        if label=='validation': require(panel['predictions']==predictions, 'saved state generation differs')
                        save(folder/role/('evaluation-'+label+'.json'),panel)
                        postfit[role][label]=ctx['prior'].compact_panel(panel,retain_predictions=True)
                replay=validate_baseline(lane,report,postfit,seed) if recipe==ARMS[0] else None
                record=dict(arm=name,dimension=dimension,seed=seed,recipe=recipe,training=report,states=states,
                    postfit=postfit,initial_parity=initial,baseline_replay=replay,training_call_elapsed_seconds=fit_seconds,
                    elapsed_seconds=time.monotonic()-arm_started,budget_completed=True,
                    trainable_parameter_count=sum(p.numel() for p in model.parameters() if p.requires_grad),**FALSE)
                save(folder/'summary.json',record); runs.append(record)
                print(json.dumps(dict(arm=name,steps=340,selected_epoch=report['selected_epoch'],
                    final_exact=report['last_complete_attempt']['fidelity']['metrics']['ordered_exact'],fit_seconds=fit_seconds)),flush=True)
    after=h.inventory(args.dependency_root,args.extension_root,ctx['pins'])
    require(all(after.get(k)==v for k,v in before.items()), 'loaded producer changed')
    for path,digest in ctx['manifest']['inputs'].items(): require(sha(path)==digest, 'sealed input changed')
    for relative,digest in ctx['pins'].items(): require(sha(args.extension_root/relative)==digest, 'frozen extension changed')
    require(sha(args.plan)==ctx['manifest']['plan_sha256'], 'plan changed')
    require(time.monotonic()-started<FIXED['max_seconds_entire_run'], 'comparison deadline exceeded')
    save(args.output/'summary.json',dict(schema='action-binding-source-training-comparison/v1',complete=len(runs)==18,
        runs=runs,training_executed=True,dimensions_actually_trained=[8,384,768],source_dependencies=after,
        all_six_original_clause_baselines_replayed=True,historical_linguistic_teacher_modified=False,
        identity_projection_is_not_learned_reconstruction=True,dimension_only_ablation=False,
        elapsed_seconds=time.monotonic()-started,workers=1,bridge_names=[],legal_ir_evaluate_provers=False,
        metric_disk_cache_used=False,encoder_executed=False,downloads_performed=False,**FALSE))


if __name__=='__main__': main()
