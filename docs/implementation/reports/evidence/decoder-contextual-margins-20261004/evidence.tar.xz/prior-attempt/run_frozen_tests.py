"""Run regression tests and check their actual producer provenance."""
from pathlib import Path
import hashlib,importlib,json,os,sys
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((R/'frozen-extensions.json').read_bytes())
tests=json.loads((R/'validated-test-source.json').read_bytes())
test_helpers=json.loads((R/'test-helper-sources.json').read_bytes())
def check():
    for rel,digest in pins.items(): assert sha(R/'experiment-source'/rel)==digest,rel
    for rel,digest in tests.items(): assert sha(R/'experiment-source'/rel)==digest,rel
    for rel,digest in test_helpers.items(): assert sha(R/'experiment-source'/rel)==digest,rel
check()
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI='0',CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
sys.dont_write_bytecode=True
sys.path.insert(0,str(S))
package=importlib.import_module('ipfs_datasets_py.logic.formalization.autoencoder')
package.__path__.insert(0,str(R/'experiment-source/ipfs_datasets_py/logic/formalization/autoencoder'))
from ipfs_datasets_py.logic.autoformal.tree_pin import require_workspace_logic_tree
pin=require_workspace_logic_tree()
assert all(Path(path).is_relative_to(S) for path in pin.values())
runtime='ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_embedding_runtime.py'
import importlib.util
runtime_name='ipfs_datasets_py.optimizers.logic_theorem_optimizer.autoencoder_embedding_runtime'
runtime_parent=importlib.import_module(runtime_name.rsplit('.',1)[0])
assert runtime_name not in sys.modules, 'unexpected prior runtime import'
runtime_spec=importlib.util.spec_from_file_location(runtime_name,R/'experiment-source'/runtime)
runtime_module=importlib.util.module_from_spec(runtime_spec)
sys.modules[runtime_name]=runtime_module
runtime_spec.loader.exec_module(runtime_module)
setattr(runtime_parent,'autoencoder_embedding_runtime',runtime_module)
import pytest
scoped='--scoped' in sys.argv
args=[str(R/'experiment-source'/name)+(
    '::test_historical8_uses_real_feature_profile_without_reconstruction'
    if scoped and name=='tests/unit/logic/test_legal_native_conditioning.py' else '') for name in tests]
args+=['--junitxml='+str(R/('tests-scoped.xml' if scoped else 'tests-frozen.xml')),'-o','cache_dir='+str(R/'pytest-cache')]
code=pytest.main(args)
check()
modules={}
for name,module in list(sys.modules.items()):
    if name.startswith('ipfs_datasets_py'):
        path=getattr(module,'__file__',None)
        if path and Path(path).is_file():
            resolved=Path(path).resolve()
            assert resolved.is_relative_to(S) or resolved.is_relative_to(R/'experiment-source'),(name,str(resolved))
            modules[name]={'path':str(resolved),'sha256':sha(resolved)}
(R/('test-import-provenance-scoped.json' if scoped else 'test-import-provenance.json')).write_text(json.dumps({'tree_pin':pin,'modules':modules,'pytest_returncode':code,'test_source_frozen':True},indent=2)+'\n')
raise SystemExit(code)
