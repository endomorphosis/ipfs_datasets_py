"""Independent saved-data audit; no model, encoder, optimizer or prover imports.

Numeric policy fixed before outcomes: component addition is exactly rounded to
float32; CE and margins use 1e-11 absolute plus 2e-12 relative tolerance. Archived
source vectors and generated token envelopes must match exactly. The recurrent
component includes source-conditioned history; this is not a causal ablation.
"""
from pathlib import Path
from collections import Counter
import argparse, hashlib, json, math, struct, subprocess, sys

sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;P=R.parents[2]
B=P/'workspace/test-logs/decoder-action-consistency-20261003'
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
BASE='8e751fb9e7fff73647fcef834d7db81d4620caf8'
FIELDS=('actor','action','modality','object')
GRAMMAR_FIELDS=('modality','actor','action','object','conditions','exceptions','temporal')
AUTHORITY=('qualified','admitted','proof_authority','source_semantics_verified')
checks=0;findings=[];artifacts={}

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()

def check(ok,label):
    global checks
    checks+=1
    if not ok:findings.append(label)

def pin(path,wanted=None):
    path=Path(path).resolve();value=dict(bytes=path.stat().st_size,sha256=sha(path))
    if wanted is not None:
        check(value['sha256']==(wanted if isinstance(wanted,str) else wanted['sha256']),'hash '+str(path))
        if isinstance(wanted,dict) and 'bytes' in wanted:check(value['bytes']==wanted['bytes'],'bytes '+str(path))
    if str(path) in artifacts:check(artifacts[str(path)]==value,'immutable '+str(path))
    artifacts[str(path)]=value;return path

def read(path,wanted=None):return json.loads(pin(path,wanted).read_bytes())

def close(actual,expected,label):
    check(type(actual) in (float,int) and math.isfinite(actual) and
          abs(actual-expected)<=1e-11+2e-12*abs(expected),label)

def f32(value):return struct.unpack('<f',struct.pack('<f',value))[0]

def false(value,names,label):
    for name in names:check(value.get(name) is False,label+'/'+name)

def true(value,names,label):
    for name in names:check(value.get(name) is True,label+'/'+name)

def published_info(public,path):
    path=str(Path(path).resolve())
    member=public.get('original_artifact_archive_paths',{}).get(path)
    if member is not None:return public['members'][member]
    member=public.get('post_archive_artifact_paths',{}).get(path)
    if member is not None:return public['publication_support'][member]
    return public['referenced_artifacts'][path]

def inherited(public,path):return read(path,published_info(public,path))

def scan(prefix,vocabulary):
    """Independent scalar lexical recognizer, retaining full six-field states."""
    decoded={i:json.loads(v) for i,v in enumerate(vocabulary) if v.startswith('"')}
    ranks={v:i+1 for i,v in enumerate(sorted(set(decoded.values())))}
    state=[0]*6;sites=[];invalid=None
    for position,token in enumerate(prefix):
        before=list(state);phase,seen,pending,count,length,last=state
        text=vocabulary[token];word=decoded.get(token);rank=ranks.get(word,0)
        field=GRAMMAR_FIELDS.index(word) if word in GRAMMAR_FIELDS else -1
        next_phase=18;site=None
        if phase==0 and token==1:next_phase=1
        elif phase==1 and text=='{':next_phase=2
        elif phase==2 and word=='rules':next_phase=3
        elif phase==3 and text==':':next_phase=4
        elif phase==4 and text=='[':next_phase=5
        elif phase in (5,14) and text=='{':next_phase=6;seen=0
        elif phase==6 and field>=0 and not seen&(1<<field):next_phase=7;seen|=1<<field;pending=field
        elif phase==7 and text==':':
            next_phase=8
            if pending<4 and count<32:site=(position,count,GRAMMAR_FIELDS[pending])
        elif phase==8:
            if pending<4 and rank and (pending!=0 or word in ('O','P','F')):next_phase=9
            elif pending>=4 and text=='[':next_phase=10;length=last=0
        elif phase==10 and text==']':next_phase=9
        elif phase in (10,12) and rank>last and length<4:next_phase=11;length+=1;last=rank
        elif phase==11 and text==',':next_phase=12
        elif phase==11 and text==']':next_phase=9
        elif phase==9 and text==',':next_phase=6
        elif phase==9 and seen==127 and text=='}':next_phase=13;count+=1
        elif phase==13 and text==',':next_phase=14
        elif phase==13 and text==']':next_phase=15
        elif phase==15 and text=='}':next_phase=16
        elif phase==16 and token==2:next_phase=17
        elif phase==17 and token==0:next_phase=17
        state=[next_phase,seen,pending,count,length,last]
        if next_phase==18 and invalid is None:invalid=position
        if site is not None:sites.append((*site,before,list(state)))
    return sites,invalid

def metrics(logits,target,emitted):
    maximum=max(logits)
    return dict(argmax_token_id=max(range(len(logits)),key=logits.__getitem__),
        target_minus_best_other=logits[target]-max(v for i,v in enumerate(logits) if i!=target),
        target_minus_emitted=logits[target]-logits[emitted],
        full_vocabulary_cross_entropy=maximum+math.log(math.fsum(math.exp(v-maximum) for v in logits))-logits[target])

def panel(record,public,run,rows,contexts,references,state):
    label=record['arm']+'/'+record['split'];vocabulary=state['codec']['target_vocabulary']
    trace=read(record['trace_ref']['path'],record['trace_ref']);score=read(record['score_ref']['path'],record['score_ref'])
    archived=inherited(public,record['archived_panel_ref']['path'])
    old_heads={row['id']:row for row in archived['source_values']['predictions']}
    index=read(record['summary_ref']['path'],record['summary_ref'])
    check(index=={k:v for k,v in record.items() if k!='summary_ref'},label+'/panel_index')
    check(trace['schema']=='generated-contextual-scalar-trace/v1' and score['schema']=='generated-contextual-scalar-scores/v1',label+'/schemas')
    check(trace['trace_sha256']==digest({k:v for k,v in trace.items() if k!='trace_sha256'}),label+'/trace_digest')
    check(score['score_sha256']==digest({k:v for k,v in score.items() if k!='score_sha256'}),label+'/score_digest')
    check(score['trace_sha256']==trace['trace_sha256'],label+'/score_trace')
    for value in (record,trace,score):false(value,AUTHORITY,label)
    true(record,('generation_predictions_exact','reference_scoring_after_completed_collection'),label)
    check(record['sample_count']==48 and record['greedy_passes']==1 and record['optimizer_steps']==0,label+'/work')
    check(record['model_tensor_sha256']==trace['model_tensor_sha256']==score['model_tensor_sha256']==state['tensor_sha256'],label+'/model_hash')
    check(trace['dimension']==record['dimension'] and trace['vocabulary_size']==len(vocabulary)==32,label+'/geometry')
    check(trace['batch_size']==8 and trace['max_target_tokens']==512 and trace['generation_temperature']==0,label+'/bounds')
    sources=[{k:row[k] for k in ('id','input','source_text')} for row in rows]
    for key,value in [('source_rows',sources),('source_contexts',contexts),('codec',state['codec']),('input_transform',state['input_transform'])]:
        check(trace[key+'_sha256']==digest(value),label+'/trace_'+key)
    for key,value in [('rows',rows),('references',references),('source_contexts',contexts),('codec',state['codec'])]:
        check(score[key+'_sha256']==digest(value),label+'/score_'+key)
    envelope=lambda rs:[{k:r[k] for k in ('id','token_ids','generation_status','eos_reached')} for r in rs]
    check(envelope(trace['predictions'])==envelope(archived['predictions']),label+'/exact_archived_generation')
    check([r['id'] for r in rows]==[r['id'] for r in trace['rows']]==[r['id'] for r in trace['predictions']],label+'/complete_row_order')
    true(trace,('complete','full_vocabulary_retained','decomposition_exact','source_only','caller_state_preserved',
        'hooks_removed','complete_rollout_before_reference_scoring','memory_estimate_excludes_model_import_allocator_rss'),label)
    false(trace,('reference_count_access','reference_prefix_access','reference_documents_passed_to_model','inventory_access',
        'source_context_target_access','syntax_mask','forced_closure','model_copied','recurrent_clause_effect_causally_isolated'),label)
    check(trace['extra_model_passes']==trace['source_head_extra_evaluations']==trace['optimizer_steps']==0,label+'/no_extra_forwards')
    true(score,('complete','reference_labels_used_only_after_rollout'),label)
    false(score,('training_loss_returned','models_executed','source_alignment_inferred','statutory_alignment_verified',
        'recurrent_clause_effect_causally_isolated'),label)
    check(score['split']==record['split'] and score['optimizer_steps']==0,label+'/score_scope')
    references_by_id={r['id']:r for r in references};events=[];unscored=[];visited=set();all_sites=0;literals={}
    totals={f:dict(scored=0,source_correct=0,recurrent_correct=0,combined_correct=0,source_correct_combined_wrong=0) for f in FIELDS}
    for i,(row,observation,prediction) in enumerate(zip(rows,trace['rows'],trace['predictions'])):
        rowlabel=label+'/'+row['id'];prefix=observation['consumed_prefix'];tokens=prediction['token_ids'];status=prediction['generation_status']
        check(observation['batch_offset']==i//8*8,rowlabel+'/batch')
        check(prefix[0]==1 and prefix==[1]+tokens[:len(prefix)-1] and 1<=len(prefix)<512,rowlabel+'/prefix')
        check(all(type(t) is int and 0<=t<32 for t in prefix) and all(type(t) is int and 3<=t<32 for t in tokens),rowlabel+'/tokens')
        check(status in ('eos','invalid_special_token','output_limit') and prediction['eos_reached']==(status=='eos'),rowlabel+'/status')
        check(len(tokens)==len(prefix)-(status!='output_limit') and (status!='output_limit' or len(prefix)==511),rowlabel+'/completion')
        context=contexts[row['id']];segments=context['segments'];ref=references_by_id[row['id']];rules=ref['target']['rules']
        check(observation['input_sha256']==digest(row['input']) and observation['source_context_sha256']==digest(context),rowlabel+'/hashes')
        source_sha=hashlib.sha256(row['source_text'].encode()).hexdigest()
        check(observation['source_text_sha256']==context['source_sha256']==ref['source_sha256']==source_sha,rowlabel+'/text')
        check(ref['source_text']==row['source_text'] and len(rules)==len(segments)==ref['clause_count'],rowlabel+'/alignment')
        check(row['target_ids'][0]==1 and row['target_ids'][-1]==2 and
              json.loads(''.join(vocabulary[t] for t in row['target_ids'][1:-1]))==ref['target'],rowlabel+'/target_authentication')
        for slot,(segment,rule) in enumerate(zip(segments,rules)):
            text=segment['source_text'];textsha=hashlib.sha256(text.encode()).hexdigest()
            check(row['source_text'][segment['char_start']:segment['char_end']]==text and
                row['source_text'].encode()[segment['byte_start']:segment['byte_end']]==text.encode(),rowlabel+'/source_offsets')
            check(textsha==segment['source_sha256'] and digest(segment['vector'])==segment['embedding_sha256'],rowlabel+'/segment_hashes')
            targets=[vocabulary.index(json.dumps(rule[f],ensure_ascii=True)) for f in FIELDS]
            check(textsha not in literals or literals[textsha]==targets,rowlabel+'/unambiguous_fixture')
            literals[textsha]=targets
        expected,invalid=scan(prefix,vocabulary)
        check(observation['first_invalid_prefix_position']==invalid and len(expected)==len(observation['scalar_sites'])<=128,rowlabel+'/sites')
        for site,(position,slot,field,before,after) in zip(observation['scalar_sites'],expected):
            slabel=rowlabel+'/'+str(position);all_sites+=1
            check((site['position'],site['slot'],site['field'],site['grammar_before'],site['grammar_after'])==(position,slot,field,before,after),slabel+'/causal_route')
            available=slot<len(segments)
            check(site['source_slot_available'] is available and site['source_guidance_active'] is (slot<8),slabel+'/source_route')
            check(site['source_clause_sha256']==(segments[slot]['source_sha256'] if available else None),slabel+'/source_clause')
            vectors=[site[k] for k in ('raw_recurrent_logits','applied_source_logits','combined_logits')]
            for vec in vectors:
                check(len(vec)==32 and all(type(v) in (int,float) and math.isfinite(v) and f32(v)==v for v in vec),slabel+'/float32_fullV')
            recurrent,source,combined=vectors
            check(site['decomposition_exact'] is True and [f32(a+b) for a,b in zip(recurrent,source)]==combined,slabel+'/exact_addition')
            emitted=site['actual_next_token_id'];check(emitted==max(range(32),key=combined.__getitem__),slabel+'/argmax')
            expected_emitted=tokens[position] if position<len(tokens) else 2 if status=='eos' else emitted if status=='invalid_special_token' and emitted in (0,1) else None
            check(emitted==expected_emitted,slabel+'/output_binding')
            if not available:
                check(all(v==0 for v in source),slabel+'/no_missing_source_guidance')
                unscored.append(dict(id=row['id'],position=position,slot=slot,field=field,reason='source_slot_unavailable'));continue
            target=vocabulary.index(json.dumps(rules[slot][field],ensure_ascii=True));head=old_heads[row['id']]
            check(source==head['raw_logits'][slot][FIELDS.index(field)],slabel+'/exact_archived_source_logits')
            check(target==head['expected_token_ids'][slot][FIELDS.index(field)],slabel+'/archived_target')
            measures={name:metrics(vec,target,emitted) for name,vec in zip(('recurrent','source','combined'),vectors)}
            event=dict(id=row['id'],position=position,slot=slot,field=field,target_token_id=target,
                actual_next_token_id=emitted,source_clause_sha256=site['source_clause_sha256'],
                prefix_sha256=digest(prefix[:position+1]),**measures)
            events.append(event);visited.add((row['id'],slot,field));bucket=totals[field];bucket['scored']+=1
            for name in ('source','recurrent','combined'):bucket[name+'_correct']+=int(measures[name]['argmax_token_id']==target)
            bucket['source_correct_combined_wrong']+=int(measures['source']['argmax_token_id']==target and emitted!=target)
    check(score['scored_sites']==len(events) and len(score['events'])==len(events),label+'/event_count')
    for actual,expected in zip(score['events'],events):
        for key,value in expected.items():
            if key in ('source','recurrent','combined'):
                for metric,wanted in value.items():
                    if metric=='argmax_token_id':check(actual[key][metric]==wanted,label+'/score_argmax')
                    else:close(actual[key][metric],wanted,label+'/score_'+key+'_'+metric)
            else:check(actual[key]==value,label+'/event_'+key)
    unvisited=[dict(id=row['id'],slot=slot,field=field,reason='reference_site_not_visited') for row in rows
        for slot in range(len(contexts[row['id']]['segments'])) for field in FIELDS if (row['id'],slot,field) not in visited]
    check(score['unscored_sites']==unscored and score['unvisited_reference_sites']==unvisited,label+'/complete_unscored_and_unvisited')
    check(score['per_field']==totals,label+'/field_counts')
    if 'per_field' in record:check(record['per_field']==totals,label+'/record_counts')
    steps=sum(max(len(row['consumed_prefix']) for row in trace['rows'][i:i+8]) for i in range(0,48,8))
    check(trace['sample_count']==48 and trace['scalar_site_count']==all_sites and trace['greedy_batch_steps']==trace['recurrent_readout_calls']==steps,label+'/actual_work')
    estimate=48*(128*32*3*40+512*64+32768)
    check(trace['memory_estimate_bytes']==estimate<=134217728,label+'/trace_memory_estimate')
    check(0<=record['elapsed_seconds']<=30 and 0<=trace['elapsed_seconds']<=record['elapsed_seconds'],label+'/panel_deadline')
    return dict(arm=record['arm'],dimension=record['dimension'],seed=record['seed'],split=record['split'],
        scalar_site_count=all_sites,scored_sites=len(events),unscored_sites=len(unscored),unvisited_reference_sites=len(unvisited),
        per_field=totals,greedy_batch_steps=steps,elapsed_seconds=record['elapsed_seconds'])

def resources():
    exit_receipt=read(R/'guardian-exit.json');check(exit_receipt['returncode']==0,'guardian_exit0')
    folder=R/'diagnostic-r1';child=read(folder/'child-exit.json');check(child['returncode']==0 and child['leader_reaped'],'child_exit0_reaped')
    final=read(folder/'resources-final.json');record=final['record']
    check(final['status']==record['status']=='released' and record['artifacts_durable_asserted'],'durable_released_resources')
    check(record['storage_bytes']==300_000_000 and record['memory_mb']==4096 and record['cpu_slots']==record['child_process_slots']==1,'resource_budget')
    check(final['storage_limit_bytes']==140_000_000_000 and record['attempt_exceeded_reservation'] is False and record['final_attempt_bytes']<=300_000_000,'unchanged_storage_cap')
    check(final['cleanup_error'] is None and final['resource_lease']['released'] is True,'resource_release')
    adoption=read(R/'diagnostic-r1-scheduler-adoption.json');historical=read(R/'guardian-runtime-provenance.json')
    check(adoption['complete'] and not adoption['reset_performed'] and not adoption['capacity_changed'] and not adoption['proof_guards_changed'],'exact_adoption')
    check(adoption['producer_sha256']=={k:v['sha256'] for k,v in historical['sources'].items()},'historical_resource_sources')
    for value in historical['sources'].values():pin(value['path'],value)
    binding=read(folder/'lease-binding.json');watch=final['lease_watchdog'];events_path=pin(watch['events_path'],watch['events_sha256'])
    events=[json.loads(line) for line in events_path.read_text().splitlines()]
    observations=[x for x in events if 'stage' in x]
    check(observations[0]['stage']=='pre_spawn' and observations[-1]['stage']=='post_finalize','lease_lifecycle_endpoints')
    for item in observations:
        check(item['healthy'] and item['read_only'] and item['configuration_matches'] and not item['capability_persisted'],'healthy_readonly_lease_observation')
        check(item['lease_present'] is (item['stage']!='post_finalize') and item['observed_config_sha256']==adoption['shared_config_sha256'],'exact_lease_configuration')
    active=[x for x in observations if x['stage']!='post_finalize']
    gaps=[b['observed_at_monotonic']-a['observed_at_monotonic'] for a,b in zip(active,active[1:])]
    check(all(0<=x<=5 for x in gaps),'bounded_sampled_lease_gaps')
    false(watch,('continuous_lease_coverage_claimed','shared_state_mutated_by_observer'),'lease_scope')
    check(watch['post_release_observation']==observations[-1],'post_release_binding')
    observations_path=folder/'resource-observations.json';samples=read(observations_path) if observations_path.exists() else []
    live=[x['group_rss']['rss_bytes'] for x in samples if x.get('group_rss',{}).get('available') and x['group_rss'].get('live_processes',0)>0]
    if live:check(max(live)<=4096*1024**2,'sampled_memory_within_budget')
    for name in ('command.json','child-identity.json','resources-start.json','child.log'):pin(folder/name)
    pin(R/'guardian.log')
    check(not any((folder/name).exists() for name in ('failure-primary.json','failure.json','watchdog-close-failure.json')),'no_hidden_guardian_failure')
    return dict(guardian_returncode=0,child_returncode=0,resources_released=True,
        actual_attempt_bytes=record['final_attempt_bytes'],resource_observation_count=len(samples),
        live_RSS_sample_count=len(live),peak_observed_live_RSS_bytes=max(live) if live else None,
        active_lease_observation_count=len(active),maximum_observed_active_gap_seconds=max(gaps,default=None),
        continuous_lease_coverage_proven=False,kernel_quota_claimed=False,
        scope='Actual exit, durable release, sampled lease and RSS observations; admission/accounting time is not isolated inference timing.')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=R/'independent-audit.json');args=parser.parse_args()
    if args.output.exists():raise ValueError('audit output already exists; retain every attempt')
    pin(__file__);manifest=read(R/'diagnostic-manifest.json');plan=read(R/'diagnostic-plan.json',manifest['plan_sha256'])
    check(manifest['published_commit']==read(R/'base.json')['base']==BASE,'exact_published_base')
    check(plan['input_sha256']==manifest['inputs'],'sealed_input_inventory')
    for path,h in manifest['inputs'].items():pin(path,h)
    for relative,h in manifest['extensions'].items():pin(R/'experiment-source'/relative,h)
    ready=read(R/'readiness.json');check(ready['passed'] and not ready['findings'],'clean_readiness')
    for path,value in ready['artifacts'].items():pin(path,value)
    public=read(manifest['publication_manifest']);published_results=read(manifest['publication_results'])
    for key in ('publication_manifest','publication_results'):
        p=Path(manifest[key]);blob=subprocess.check_output(['git','show',BASE+':'+str(p.relative_to(P))],cwd=P)
        check(hashlib.sha256(blob).hexdigest()==sha(p),'exact_git_metadata/'+key)
    check(public['archive']==published_results['archive'],'parent_archive_binding')
    archivehash=hashlib.sha256();offset=0
    for i,part in enumerate(public['archive_parts'],1):
        check(part['offset_bytes']==offset and part['filename']=='evidence.tar.xz.part-'+str(i).zfill(3),'archive_part_order')
        path=pin(Path(manifest['publication_manifest']).parent/part['filename'],part)
        with path.open('rb') as stream:
            for block in iter(lambda:stream.read(1048576),b''):archivehash.update(block);offset+=len(block)
    check(dict(bytes=offset,sha256=archivehash.hexdigest())==public['archive'],'logical_parent_archive')
    parent=inherited(public,manifest['parent_manifest']);inherited(public,manifest['parent_plan'])
    corpus=inherited(public,parent['paragraphs'])
    references={split:[{k:r[k] for k in ('id','source_text','source_sha256','target','clause_count')} for r in corpus[split]] for split in ('train','validation')}
    summary=read(R/'diagnostic-r1/results/summary.json')
    check(summary['schema']=='contextual-scalar-margin-diagnostic-results/v1' and summary['complete'],'complete_result')
    false(summary,(*AUTHORITY,'training_executed','encoder_executed','downloads_performed','checkpoint_promoted',
        'convergence_proven','fresh_holdout','lake_executed','native_validation_executed','formalized','roundtrip_ok'), 'summary')
    true(summary,('all_archived_generation_predictions_equal','all_saved_weights_preserved','inference_executed','no_new_validation_targets'),'summary')
    check(summary['state_count']==18 and summary['panel_count']==len(summary['panels'])==36 and summary['greedy_passes']==36 and summary['optimizer_steps']==0,'complete_work')
    check(summary['workers']==1 and summary['bridge_names']==[] and not summary['legal_ir_evaluate_provers'] and not summary['metric_disk_cache_used'],'diagnostic_measurement_flags')
    check(0<=summary['elapsed_seconds']<=600,'entire_diagnostic_deadline')
    arms=('source-head-lr10','joint-replay-zero','joint-replay-fields')
    expected=[(f'{d}-{arm}-{seed}',scope) for d in (8,384,768) for seed in (1729,2718) for arm in arms for scope in ('training','exposed_development')]
    check([(r['arm'],r['split']) for r in summary['panels']]==expected,'exact_panel_inventory')
    details=[];cache={}
    for record in summary['panels']:
        name=record['arm'];dimension=record['dimension'];split='train' if record['split']=='training' else 'validation'
        if name not in cache:
            run=inherited(public,manifest['saved_summaries'][name]);state=inherited(public,run['states']['last-attempt']['path'])
            check(state['role']=='last-attempt' and state['dimension']==dimension and digest(state['model_state'])==state['weights_sha256'],'authenticated_final_state/'+name)
            check(state['tensor_sha256']==run['states']['last-attempt']['tensor_sha256'],'state_tensor_digest/'+name)
            folder=B/'training-r1/results'/str(dimension)
            rows=inherited(public,folder/'training-rows.json');contexts=inherited(public,folder/'source-contexts.json')
            inherited(public,folder/'preprocessing.json');cache[name]=(run,state,rows,contexts)
        run,state,rows,contexts=cache[name]
        check(record['state_ref']==run['states']['last-attempt'],'exact_state_ref/'+name)
        expected_panel=run['postfit']['last-attempt']['training' if split=='train' else 'validation']
        check(record['archived_panel_ref']==expected_panel,'exact_panel_ref/'+name)
        details.append(panel(record,public,run,rows[split],contexts[split],references[split],state))
    for scoped,h in summary['source_dependencies'].items():
        kind,relative=scoped.split(':',1);check(kind in ('dependency','extension'),'source_scope')
        pin((S if kind=='dependency' else R/'experiment-source')/relative,h)
        check(h==public['validated_producer_source_sha256'].get(relative) or
            kind=='extension' and manifest['extensions'].get(relative)==h,'loaded_source_pin/'+relative)
    protected=read(R/'before.json')['checkpoint'];pin(protected['path'],protected)
    resource_review=resources()
    for name in ('outcomes-summary.json','outcomes.json'):
        if (R/name).exists():pin(R/name)
    pin(R/'diagnostic-r1/results/sealed-recipe.json')
    result=dict(schema='contextual-scalar-independent-saved-data-audit/v1',passed=not findings,checks=checks,
        finding_count=len(findings),findings=findings,artifacts=artifacts,panels=details,resources=resource_review,
        numeric_policy=dict(component_addition='exact IEEE754 float32',archived_source_logits='exact',
            scalar_metric_atol=1e-11,scalar_metric_rtol=2e-12),
        models_executed=False,optimizers_executed=False,encoders_executed=False,provers_executed=False,
        qualification_unchanged=True,qualified=False,admitted=False,proof_authority=False,
        scope='Saved-data provenance, lexical routing, actual-prefix logits, posthoc labels and resource receipts; no independent semantic or causal validation.')
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ('passed','checks','finding_count','findings')}));return bool(findings)

if __name__=='__main__':raise SystemExit(main())
