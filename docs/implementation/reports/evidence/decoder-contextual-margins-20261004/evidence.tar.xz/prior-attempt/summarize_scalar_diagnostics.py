"""Independent scalar distributions from completed saved traces; no model imports."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,math,statistics,struct
R=Path(__file__).resolve().parent
FIELDS=('actor','action','modality','object')
NAMES={'source':'applied_source_logits','recurrent':'raw_recurrent_logits','combined':'combined_logits'}
CHECKS=0;ARTIFACTS={}
def require(value,message):
 global CHECKS
 CHECKS+=1
 if not value:raise ValueError(message)
def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(value):return hashlib.sha256(raw(value)).hexdigest()
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def read(path,wanted=None):
 path=Path(path).resolve();record=dict(sha256=sha(path),bytes=path.stat().st_size)
 require(wanted is None or record['sha256']==wanted,'artifact hash differs: '+str(path))
 require(str(path) not in ARTIFACTS or ARTIFACTS[str(path)]==record,'artifact changed: '+str(path))
 ARTIFACTS[str(path)]=record;return json.loads(path.read_bytes())
def close(a,b):return abs(a-b)<=1e-11+2e-12*abs(b)
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def lse(values):
 high=max(values);return high+math.log(math.fsum(math.exp(x-high) for x in values))
def distribution(values):
 if not values:return dict(count=0,minimum=None,mean=None,p05=None,median=None,p95=None,maximum=None)
 ordered=sorted(values)
 def quantile(p):
  offset=(len(ordered)-1)*p;lower=int(offset);fraction=offset-lower
  return ordered[lower]*(1-fraction)+ordered[min(lower+1,len(ordered)-1)]*fraction
 return dict(count=len(values),minimum=ordered[0],mean=math.fsum(values)/len(values),p05=quantile(.05),
  median=statistics.median(values),p95=quantile(.95),maximum=ordered[-1])
def metrics(values,target,emitted):
 return dict(argmax_token_id=max(range(len(values)),key=values.__getitem__),
  target_minus_best_other=values[target]-max(x for i,x in enumerate(values) if i!=target),
  target_minus_emitted=values[target]-values[emitted],full_vocabulary_cross_entropy=lse(values)-values[target])
def divergence(source,combined):
 ls=lse(source);lc=lse(combined)
 value=math.fsum(math.exp(x-ls)*((x-ls)-(y-lc)) for x,y in zip(source,combined))
 require(value>=-1e-12,'negative KL exceeds double arithmetic allowance')
 return max(0.,value)

def summarize_panel(trace,score):
 require(trace['complete'] is True and score['complete'] is True and score['trace_sha256']==trace['trace_sha256'],
  'complete bound trace and score required')
 require(trace['trace_sha256']==digest({k:v for k,v in trace.items() if k!='trace_sha256'})
  and score['score_sha256']==digest({k:v for k,v in score.items() if k!='score_sha256'}),'receipt digest differs')
 require(score['split'] in ('training','exposed_development') and score['training_loss_returned'] is False
  and score['reference_labels_used_only_after_rollout'] is True,'posthoc split/target policy differs')
 sites={(r['id'],s['position']):s for r in trace['rows'] for s in r['scalar_sites']}
 require(len(sites)==trace['scalar_site_count'],'duplicate scalar position')
 expected={f:dict(scored=0,source_correct=0,recurrent_correct=0,combined_correct=0,source_correct_combined_wrong=0) for f in FIELDS}
 counts={f:Counter() for f in FIELDS};samples={f:{} for f in FIELDS};targets=set()
 def observe(field,name,value):samples[field].setdefault(name,[]).append(value)
 for event in score['events']:
  field=event['field'];target=event['target_token_id'];emitted=event['actual_next_token_id'];site=sites[(event['id'],event['position'])]
  require(type(target) is int and 0<=target<32 and type(emitted) is int and 0<=emitted<32,'full-vocabulary token id required')
  require(field in FIELDS and site['field']==field and site['source_slot_available'] is True
   and site['source_clause_sha256']==event['source_clause_sha256'] and site['slot']==event['slot'],'scored source identity differs')
  targetkey=(event['id'],event['slot'],field);require(targetkey not in targets,'duplicate scored reference site');targets.add(targetkey)
  values={name:site[key] for name,key in NAMES.items()}
  require(all(len(v)==32 and all(math.isfinite(x) for x in v) for v in values.values()),'full finite32-vocabulary values required')
  require(all(f32(a+b)==c for a,b,c in zip(values['source'],values['recurrent'],values['combined'])),
   'recorded exact float32 decomposition differs')
  require(emitted==site['actual_next_token_id']==max(range(32),key=values['combined'].__getitem__),'actual argmax differs')
  measured={name:metrics(v,target,emitted) for name,v in values.items()}
  for name,m in measured.items():
   require(m['argmax_token_id']==event[name]['argmax_token_id'] and all(close(m[k],event[name][k]) for k in m if k!='argmax_token_id'),
    'independent scalar margin/CE differs')
   for metric in ('target_minus_best_other','target_minus_emitted','full_vocabulary_cross_entropy'):
    observe(field,name+'_'+metric,m[metric])
  source,right,combined=(measured[name]['argmax_token_id'] for name in ('source','recurrent','combined'))
  sc=source==target;rc=right==target;cc=combined==target;disagree=source!=right
  c=counts[field];c.update(scored=1,source_correct=int(sc),recurrent_correct=int(rc),combined_correct=int(cc),
   source_correct_combined_wrong=int(sc and not cc),source_wrong_combined_correct=int(not sc and cc),
   source_correct_combined_correct=int(sc and cc),source_wrong_combined_wrong=int(not sc and not cc),
   source_recurrent_argmax_disagree=int(disagree),source_recurrent_argmax_disagree_combined_correct=int(disagree and cc),
   source_correct_recurrent_wrong_combined_correct=int(sc and not rc and cc),
   source_wrong_recurrent_correct_combined_correct=int(not sc and rc and cc))
  for key in expected[field]:expected[field][key]=c[key]
  kl=divergence(values['source'],values['combined']);observe(field,'KL_source_to_combined_full_vocabulary',kl)
  observe(field,'combined_minus_source_target_margin',measured['combined']['target_minus_best_other']-measured['source']['target_minus_best_other'])
  if cc:
   observe(field,'KL_source_to_combined_when_combined_correct',kl)
   observe(field,'combined_minus_source_target_margin_when_combined_correct',measured['combined']['target_minus_best_other']-measured['source']['target_minus_best_other'])
  if sc and cc:observe(field,'KL_source_to_combined_when_both_correct',kl)
 require(expected==score['per_field'],'independent per-field counts differ')
 require(len(score['events'])==score['scored_sites']==sum(v['scored'] for v in counts.values()),'scored site count differs')
 return dict(split=score['split'],per_field={f:dict(counts=dict(counts[f]),distributions={k:distribution(v) for k,v in samples[f].items()}) for f in FIELDS},
  scored_sites=score['scored_sites'],unscored_sites=len(score['unscored_sites']),unvisited_reference_sites=len(score['unvisited_reference_sites']),
  full_vocabulary=32,softmax_temperature_for_diagnostic=1.,generation_temperature=0,
  distribution_quantiles='linear interpolation on sorted values; summaries of observed sites, not confidence intervals',
  raw_recurrent_scope='Pre-addition recurrent readout includes source-conditioned history; recurrent clause contribution is not isolated.',
  KL_scope='Diagnostic disagreement in nats, not a training loss or evidence that either distribution is preferable.',
  no_unvisited_or_unavailable_labels_fabricated=True)

def training_assessment(panels):
 training=[p for p in panels if p['split']=='training'];require(len(training)==18,'all eighteen training panels required')
 totals=Counter();perfect=Counter()
 for p in training:
  for field,data in p['per_field'].items():
   totals.update(data['counts'])
   if p['archived_exact_documents']==48:perfect.update(data['counts'])
 return dict(training_panels=18,training_scalar_counts=dict(totals),counts_in_perfect_training_panels=dict(perfect),
  development_values_used_for_this_assessment=False,
  eligible_generic_hypothesis='Test a bounded full-vocabulary source/combined consistency regularizer only at training sites where the source head predicts the authenticated training label. Keep ordinary reconstruction losses and gates unchanged.',
  design_requirement='First retain the legacy baseline and a zero-weight observation control with exact tensor/prediction parity; predeclare one small coefficient and fresh seeds before seeing a new validation cohort.',
  interpretation='Persistent disagreement in a correct training output could support testing regularization, but does not establish that recurrence is harmful. Source-wrong/combined-correct counts identify useful recurrent corrections that an unconditional penalty could damage.',
  next_training_authorized_by_this_receipt=False,fresh_validation_required=True,
  fresh_validation_requirements=['New literal paragraphs and clause-order/paraphrase combinations, disjoint by source/hash and template group from all prior training/development rows.',
   'Preregister seen-combination and unseen-combination strata using training inventory only; do not insert previously observed development failures as training targets.',
   'Use a separate development set for checkpoint selection and a blind final test panel evaluated once after choosing the objective.',
   'Include authentic statutory spans as separately reviewed coverage evidence; authored fixtures do not establish federal-law or other-modality fidelity.'])

def main():
 guardian=read(R/'guardian-exit.json');child=read(R/'diagnostic-r1/child-exit.json');resources=read(R/'diagnostic-r1/resources-final.json')
 require(guardian['returncode']==0 and child['returncode']==0 and child['leader_reaped'] is True,'clean completed diagnostic processes required')
 require(resources['status']==resources['record']['status']=='released' and resources['record']['artifacts_durable_asserted'] is True
  and resources['cleanup_error'] is None,'durable completed resource release required')
 ready=read(R/'readiness.json');require(ready['passed'] and not ready['findings'],'passed frozen readiness required')
 for path,entry in ready['artifacts'].items():require(sha(path)==entry['sha256'] and Path(path).stat().st_size==entry['bytes'],'sealed readiness artifact changed')
 root=R/'diagnostic-r1/results';summary=read(root/'summary.json');require(summary['complete'] and summary['panel_count']==36,'complete36 panels required')
 panels=[]
 for item in summary['panels']:
  trace=read(item['trace_ref']['path'],item['trace_ref']['sha256']);score=read(item['score_ref']['path'],item['score_ref']['sha256'])
  value=summarize_panel(trace,score);archived=read(item['archived_panel_ref']['path'],item['archived_panel_ref']['sha256'])
  value.update(arm=item['arm'],dimension=item['dimension'],seed=item['seed'],
   archived_exact_documents=archived['source_fidelity']['metrics']['ordered_exact'],
   archived_syntax_valid_documents=archived['source_fidelity']['metrics']['syntax_valid'],
   elapsed_seconds=item['elapsed_seconds'],source_trace=deepcopy_ref(item['trace_ref']),source_score=deepcopy_ref(item['score_ref']))
  panels.append(value)
 require(len(panels)==36 and len({(p['arm'],p['split']) for p in panels})==36,'duplicate or missing output panels')
 assessment=training_assessment(panels)
 value=dict(schema='contextual-scalar-diagnostic-outcomes/v1',complete=True,checks=CHECKS,panels=panels,
  training_only_assessment=assessment,independent_audit_performed_by_this_script=False,independent_audit_required_for_publication=True,
  script_sha256=sha(__file__),artifacts=ARTIFACTS,models_executed=False,training_executed=False,
  qualified=False,admitted=False,lake_executed=False,native_validation_executed=False,fresh_holdout=False,
  convergence_proven=False,checkpoint_promoted=False,new_targets_created=False,created_at_utc=datetime.now(timezone.utc).isoformat())
 with (R/'outcomes-summary.json').open('x') as f:json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
 print(json.dumps(dict(complete=True,checks=CHECKS,output=str(R/'outcomes-summary.json'))))
def deepcopy_ref(value):return json.loads(json.dumps(value,allow_nan=False))
if __name__=='__main__':main()
