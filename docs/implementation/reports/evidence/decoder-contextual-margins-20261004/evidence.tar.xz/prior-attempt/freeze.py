"""Freeze observation-only sources against the published generated-replay study."""
from pathlib import Path
import hashlib, importlib.util, json, shutil, subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
B=P/'workspace/test-logs/decoder-action-consistency-20261003'
E=P/'docs/implementation/reports/evidence/decoder-action-consistency-20261003'
BASE=json.loads((R/'base.json').read_bytes())['base']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):
    path=R/name
    assert not path.exists(),path
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def main():
    assert not (R/'experiment-source').exists()
    changes=['ipfs_datasets_py/logic/formalization/autoencoder/generated_scalar_observation.py',
        'scripts/ops/autoencoder/diagnose_contextual_scalar_margins.py',
        'tests/unit/logic/formalization/autoencoder/test_generated_scalar_observation.py',
        'tests/unit/logic/formalization/autoencoder/test_contextual_scalar_margins_runner.py']
    pins=json.loads((B/'frozen-extensions.json').read_bytes())
    tests=json.loads((B/'validated-test-source.json').read_bytes())
    helpers=json.loads((B/'test-helper-sources.json').read_bytes())
    for rel,digest in {**pins,**tests,**helpers}.items():
        assert sha(B/'experiment-source'/rel)==digest,rel
        assert hashlib.sha256(subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)).hexdigest()==digest,rel
    additions={rel:sha(P/rel) for rel in changes}
    for rel,digest in additions.items():
        (tests if rel.startswith('tests/') else pins)[rel]=digest
    for rel,digest in {**pins,**tests,**helpers}.items():
        src=P/rel if rel in additions else B/'experiment-source'/rel
        target=R/'experiment-source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(src,target);assert sha(target)==digest
    save('frozen-extensions.json',pins);save('validated-test-source.json',tests)
    save('test-helper-sources.json',helpers);save('test-files.json',list(tests))
    save('code-files.json',changes+['docs/autoencoders/contextual_scalar_diagnostics.md'])
    old=json.loads((B/'training-manifest.json').read_bytes())
    inputs=dict(old['inputs'])
    for path in (B/'training-manifest.json',B/'training-plan.json',E/'manifest.json',E/'results.json'):
        inputs[str(path)]=sha(path)
    summaries={}
    for d in (8,384,768):
        for label in ('preprocessing.json','source-contexts.json','training-rows.json'):
            path=B/'training-r1/results'/str(d)/label;inputs[str(path)]=sha(path)
        for seed in (1729,2718):
            for recipe in ('source-head-lr10','joint-replay-zero','joint-replay-fields'):
                name=f'{d}-{recipe}-{seed}';path=B/'training-r1/results'/name/'summary.json'
                summaries[name]=str(path);inputs[str(path)]=sha(path)
                summary=json.loads(path.read_bytes())
                refs=[summary['states']['last-attempt']]+[
                    summary['postfit']['last-attempt'][label] for label in ('training','validation')]
                for ref in refs:
                    assert sha(ref['path'])==ref['sha256'],ref['path']
                    inputs[ref['path']]=ref['sha256']
    for path,digest in inputs.items(): assert sha(path)==digest,path
    runner=R/'experiment-source/scripts/ops/autoencoder/diagnose_contextual_scalar_margins.py'
    spec=importlib.util.spec_from_file_location('_frozen_scalar_diagnosis',runner)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    save('diagnostic-plan.json',dict(module.FIXED,input_sha256=inputs))
    manifest=dict(extensions=pins,inputs=inputs,parent_manifest=str(B/'training-manifest.json'),
        parent_plan=str(B/'training-plan.json'),saved_summaries=summaries,published_commit=BASE,
        publication_manifest=str(E/'manifest.json'),publication_results=str(E/'results.json'),
        plan_sha256=sha(R/'diagnostic-plan.json'))
    save('diagnostic-manifest.json',manifest)
    shutil.copyfile(B/'run_frozen_tests.py',R/'run_frozen_tests.py')
    print(json.dumps(dict(extensions=len(pins),test_files=len(tests),inputs=len(inputs))))
if __name__=='__main__':main()
