from pathlib import Path
import hashlib,json,subprocess
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');W=P.parent.parent;R=Path(__file__).resolve().parent
E=P/'docs/implementation/reports/evidence/decoder-contextual-margins-20261004'
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def state(root):
 index=Path(git(root,'rev-parse','--path-format=absolute','--git-path','index').decode().strip())
 return dict(head=git(root,'rev-parse','HEAD').decode().strip(),index_sha256=sha(index))
x=read(R/'publication.json');assert x['package_pushed'] and x['workspace_pushed']
for root,name in ((P,'package'),(W,'workspace')):
 assert git(root,'ls-remote','--heads','origin','main').decode().split()[0]==x[name+'_commit']
 assert state(root)==x[name+'_local_before']
assert git(W,'rev-parse',x['workspace_commit']+':external/ipfs_datasets').decode().strip()==x['package_commit']
owned=read(R/'owned-files.json');assert len(owned)>=9
for relative in owned:
 blob=git(P,'show',x['package_commit']+':'+relative)
 assert hashlib.sha256(blob).hexdigest()==sha(P/relative),relative
m=read(E/'manifest.json');results=read(E/'results.json');assert m['archive']==results['archive']
assert read(R/'independent-audit.json')['passed'] and read(R/'documentation-review.json')['passed']
for relative,wanted in results['candidate_sha256'].items():assert sha(P/relative)==wanted
checkpoint=read(R/'before.json')['checkpoint'];path=Path(checkpoint['path']);metadata=path.stat()
assert sha(path)==checkpoint['sha256'] and metadata.st_size==checkpoint['bytes'] and metadata.st_ino==checkpoint['inode']
value=dict(complete=True,package_commit=x['package_commit'],workspace_commit=x['workspace_commit'],remote_heads_verified=True,
 local_heads_and_indexes_preserved=True,protected_checkpoint_unchanged=True,owned_file_count=len(owned),archive=m['archive'],
 numerical_resource_checks=read(R/'independent-audit.json')['checks'],documentation_checks=read(R/'documentation-review.json')['checks'],
 qualified=False,admitted=False,lake_executed=False,checkpoint_promoted=False)
(R/'final-verification.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
