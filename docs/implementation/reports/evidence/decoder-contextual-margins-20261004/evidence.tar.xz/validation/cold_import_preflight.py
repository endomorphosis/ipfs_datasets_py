"""Cold import-only extension closure; rejects torch and never reads a state."""
from pathlib import Path
import hashlib
import importlib
import importlib.abc
import importlib.util
import json
import sys

R=Path(__file__).resolve().parent
P=R.parents[2]
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
F=R/'experiment-source'
AUTO='ipfs_datasets_py/logic/formalization/autoencoder/'
PREFIX='ipfs_datasets_py.logic.formalization.autoencoder.'
CHECKS=0
ARTIFACTS={}

def require(value,message):
    global CHECKS
    CHECKS+=1
    if not value:raise ValueError(message)

def bind(path,wanted=None):
    path=Path(path).resolve()
    record=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    require(wanted is None or record['sha256']==wanted,'source hash differs: '+str(path))
    ARTIFACTS[str(path)]=record
    return path

def script(relative,name,pins):
    path=bind(F/relative,pins[relative])
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

class NoTorch(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname=='torch' or fullname.startswith('torch.'):
            raise RuntimeError('cold import preflight must not import torch')
        return None

def main():
    sys.dont_write_bytecode=True
    require(not any(n=='ipfs_datasets_py' or n.startswith('ipfs_datasets_py.') for n in sys.modules),'cold package process required')
    require(not any(n=='torch' or n.startswith('torch.') for n in sys.modules),'torch must be absent')
    blocker=NoTorch();sys.meta_path.insert(0,blocker)
    pins=json.loads(bind(R/'frozen-extensions.json').read_bytes())
    helper=script('scripts/ops/autoencoder/benchmark_decoder_source_fidelity.py','_cold_frozen_helpers',pins)
    runner=script('scripts/ops/autoencoder/diagnose_contextual_scalar_margins.py','_cold_scalar_runner',pins)
    sys.path.insert(0,str(S))
    package=importlib.import_module(PREFIX[:-1])
    original=list(package.__path__)
    require(original==[str(S/AUTO.rstrip('/'))],'package path must remain solely frozen S')
    names=['decoder_distillation_experiment','decoder_distillation_experiment_v2','decoder_source_fidelity',
           'long_span_decoder_training','source_length_curriculum',
           'decoder_cardinality_experiment','long_span_cardinality_training','long_span_count_exposure_training',
           'source_value_decoder_experiment','projected_source_decoder_experiment','mean_centered_source_decoder_experiment',
           'shared_slot_source_decoder_experiment','clause_source_context','clause_source_decoder_experiment',
           'clause_source_controls','order_source_diagnostic','boundary_source_diagnostic','order_training_augmentation',
           'generated_boundary_training','long_span_source_value_training','dimension_native_decoder_experiment',
           'action_factorized_clause_decoder_experiment','ordered_clause_recurrent_decoder_experiment']
    ctx={'helpers':helper,'owners':{}}
    for name in names:
        relative=AUTO+name+'.py';bind(F/relative,pins[relative])
        ctx['owners'][name]=helper.extension(F,relative,PREFIX+name,pins)
    observed=[]
    for name,missing in [('generated_scalar_observation','generated_field_training'),
                         ('generated_field_training','contextual_generated_boundary_training')]:
        relative=AUTO+name+'.py';bind(F/relative,pins[relative])
        try:helper.extension(F,relative,PREFIX+name,pins)
        except ImportError as exc:
            require(missing in str(exc),'unexpected cold extension import failure')
            observed.append(dict(extension=name,missing_dependency=missing))
        else:raise ValueError('prior broken ordering unexpectedly imported')
        finally:sys.modules.pop(PREFIX+name,None)
    observer=runner.load_observer_extensions(ctx,F,pins)
    require(observer.fields is ctx['owners']['generated_field_training'],'field dependency identity differs')
    require(observer.boundary is ctx['owners']['contextual_generated_boundary_training'],'boundary dependency identity differs')
    require(observer.fields.boundary is observer.boundary,'transitive boundary identity differs')
    require(list(package.__path__)==original,'package path changed')
    require(not any(n=='torch' or n.startswith('torch.') for n in sys.modules),'torch was imported')
    inventory=helper.inventory(S,F,pins)
    for scoped,digest in inventory.items():
        kind,relative=scoped.split(':',1)
        bind((S if kind=='dependency' else F)/relative,digest)
    bind(__file__)
    output=dict(schema='contextual-scalar-cold-import-preflight/v1',passed=True,checks=CHECKS,findings=[],
                artifacts=ARTIFACTS,source_dependencies=inventory,package_path_unchanged=True,
                package_path=original,prior_failures_reproduced=observed,
                explicit_load_order=names+['contextual_generated_boundary_training','generated_field_training','generated_scalar_observation'],
                model_executed=False,model_constructed=False,state_read=False,torch_imported=False,
                training_executed=False,qualified=False,admitted=False)
    with (R/'cold-import-preflight.json').open('x') as stream:
        json.dump(output,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(passed=True,checks=CHECKS,loaded_sources=len(inventory),model_executed=False)))

if __name__=='__main__':main()
