"""Check published diagnostic tables against independently audited saved events."""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,math

R=Path(__file__).resolve().parent;checks=0;findings=[];artifacts={}
def check(ok,label):
    global checks
    checks+=1
    if not ok:findings.append(label)
def read(path):
    p=Path(path);b=p.read_bytes();artifacts[str(p)]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());return json.loads(b)
def near(a,b,label):check(math.isfinite(a) and abs(a-b)<=1e-11+2e-12*abs(b),label)
def logsumexp(xs):
    top=max(xs);return top+math.log(math.fsum(math.exp(x-top) for x in xs))
def stats(xs):
    ordered=sorted(xs);n=len(xs)
    def percentile(q):
        place=(n-1)*q;lower=math.floor(place);alpha=place-lower
        return ordered[lower]+alpha*(ordered[min(lower+1,n-1)]-ordered[lower])
    return dict(count=n,minimum=ordered[0],mean=math.fsum(xs)/n,median=percentile(.5),
        p05=percentile(.05),p95=percentile(.95),maximum=ordered[-1])
def main():
    audit=read(R/'independent-audit.json');out=read(R/'outcomes-summary.json');raw=read(R/'diagnostic-r1/results/summary.json')
    check(audit['passed'] and not audit['findings'],'successful_independent_raw_data_audit')
    check(audit['artifacts'][str(R/'outcomes-summary.json')]==artifacts[str(R/'outcomes-summary.json')],'audited_outcome_bytes')
    bykey={(p['arm'],p['split']):p for p in audit['panels']};source={(p['arm'],p['split']):p for p in raw['panels']}
    check(len(out['panels'])==len(bykey)==36,'36panels')
    all_training=Counter();perfect=Counter();by_field=defaultdict(Counter);perfect_by_field=defaultdict(Counter);perfect_count=0
    for p in out['panels']:
        key=(p['arm'],p['split']);base=bykey[key];entry=source[key]
        for metric in ('scored_sites','unscored_sites','unvisited_reference_sites'):check(p[metric]==base[metric],str(key)+'/'+metric)
        score=read(entry['score_ref']['path']);trace=read(entry['trace_ref']['path']);archived=read(entry['archived_panel_ref']['path'])
        for ref in (entry['score_ref'],entry['trace_ref'],entry['archived_panel_ref']):check(artifacts[ref['path']]['sha256']==ref['sha256'],'bound_events')
        for label,metric in [('archived_exact_documents','ordered_exact'),('archived_syntax_valid_documents','syntax_valid')]:
            check(p[label]==archived['source_fidelity']['metrics'][metric],'archived_document_metric')
        counts=defaultdict(Counter);values=defaultdict(lambda:defaultdict(list));sites={(row['id'],site['position']):site for row in trace['rows'] for site in row['scalar_sites']}
        for e in score['events']:
            target=e['target_token_id'];field=e['field'];sc,rc,cc=[e[name]['argmax_token_id']==target for name in ('source','recurrent','combined')]
            disagree=e['source']['argmax_token_id']!=e['recurrent']['argmax_token_id']
            flags=dict(scored=True,source_correct=sc,recurrent_correct=rc,combined_correct=cc,
                source_correct_combined_wrong=sc and not cc,source_correct_combined_correct=sc and cc,
                source_wrong_combined_correct=not sc and cc,source_wrong_combined_wrong=not sc and not cc,
                source_recurrent_argmax_disagree=disagree,source_recurrent_argmax_disagree_combined_correct=disagree and cc,
                source_correct_recurrent_wrong_combined_correct=sc and not rc and cc,
                source_wrong_recurrent_correct_combined_correct=not sc and rc and cc)
            counts[field].update({k:int(v) for k,v in flags.items()});bucket=values[field]
            for name in ('source','recurrent','combined'):
                for metric in ('target_minus_best_other','target_minus_emitted','full_vocabulary_cross_entropy'):
                    bucket[name+'_'+metric].append(e[name][metric])
            site=sites[(e['id'],e['position'])];a=site['applied_source_logits'];b=site['combined_logits'];la=logsumexp(a);lb=logsumexp(b)
            kl=math.fsum(math.exp(x-la)*((x-la)-(y-lb)) for x,y in zip(a,b));check(kl>=-1e-12,'nonnegative_KL');kl=max(0.,kl)
            delta=e['combined']['target_minus_best_other']-e['source']['target_minus_best_other']
            bucket['KL_source_to_combined_full_vocabulary'].append(kl);bucket['combined_minus_source_target_margin'].append(delta)
            if cc:
                bucket['KL_source_to_combined_when_combined_correct'].append(kl)
                bucket['combined_minus_source_target_margin_when_combined_correct'].append(delta)
            if sc and cc:bucket['KL_source_to_combined_when_both_correct'].append(kl)
        for field,group in p['per_field'].items():
            check(group['counts']==dict(counts[field]),str(key)+'/'+field+'/all_counts')
            for name,count in base['per_field'][field].items():check(count==group['counts'][name],'independent_base_counts')
            check(set(group['distributions'])==set(values[field]),'distribution_inventory')
            for name,numbers in values[field].items():
                for metric,expected in stats(numbers).items():near(group['distributions'][name][metric],expected,'distribution/'+name+'/'+metric)
            if p['split']=='training':
                all_training.update(counts[field]);by_field[field].update(counts[field])
                if p['archived_exact_documents']==48:perfect.update(counts[field]);perfect_by_field[field].update(counts[field])
        perfect_count+=p['split']=='training' and p['archived_exact_documents']==48
    assessment=out['training_only_assessment']
    for key,expected in [('training_scalar_counts',dict(all_training)),('counts_in_perfect_training_panels',dict(perfect)),
        ('training_scalar_counts_by_field',{k:dict(v) for k,v in by_field.items()}),
        ('perfect_training_scalar_counts_by_field',{k:dict(v) for k,v in perfect_by_field.items()}),('perfect_training_panel_count',perfect_count)]:
        check(assessment[key]==expected,'training_only/'+key)
    check(assessment['training_panels']==18 and assessment['development_values_used_for_this_assessment'] is False,'training_only_scope')
    check(assessment['next_training_authorized_by_this_receipt'] is False and assessment['fresh_validation_required'] is True,'future_work_scope')
    p=Path(__file__);artifacts[str(p)]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    result=dict(schema='contextual-scalar-independent-outcomes-review/v1',passed=not findings,checks=checks,findings=findings,
        finding_count=len(findings),artifacts=artifacts,panels_checked=36,models_executed=False,
        qualified=False,admitted=False,training_executed=False)
    path=R/'independent-outcomes-review.json'
    with path.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps({k:result[k] for k in ('passed','checks','findings')}));return bool(findings)
if __name__=='__main__':raise SystemExit(main())
