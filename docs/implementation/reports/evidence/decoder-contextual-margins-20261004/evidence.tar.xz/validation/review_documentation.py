"""Review the scalar-observation guide and README using saved evidence only."""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import argparse, hashlib, json, math, xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent;P=R.parents[2]
checks=0;findings=[];artifacts={}
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block)
 return h.hexdigest()
def check(ok,label):
 global checks
 checks+=1
 if not ok:findings.append(label)
def pin(path,expected=None):
 path=Path(path).resolve();item=dict(bytes=path.stat().st_size,sha256=sha(path))
 if expected is not None:check(item==expected,'artifact/'+str(path))
 if str(path) in artifacts:check(item==artifacts[str(path)],'unchanged/'+str(path))
 artifacts[str(path)]=item;return path
def read(path):return json.loads(pin(path).read_bytes())
def reference(ref):
 path=pin(ref['path']);check(sha(path)==ref['sha256'],'reference/sha256/'+str(path))
 if 'bytes' in ref:check(path.stat().st_size==ref['bytes'],'reference/bytes/'+str(path))
 return read(path)
def bind(receipt):
 for path,expected in receipt.get('artifacts',{}).items():pin(path,expected)
def phrase(text,part,label):check(part in ' '.join(text.split()),'prose/'+label)
def table(text,header):
 lines=text.splitlines();check(lines.count(header)==1,'table/header/'+header)
 offset=lines.index(header)+2;result=[]
 while offset<len(lines) and lines[offset].startswith('|'):result.append(lines[offset]);offset+=1
 return result
def xml_counts(path):
 values=Counter()
 for suite in ET.parse(pin(path)).getroot().iter('testsuite'):
  values.update({k:int(suite.get(k,0)) for k in ('tests','failures','errors','skipped')})
 return dict(values)
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--document-sha256',required=True);args=parser.parse_args()
 doc=P/'docs/autoencoders/contextual_scalar_diagnostics.md';readme_path=R/'public-readme.txt'
 text=pin(doc).read_text();readme=pin(readme_path).read_text()
 check(sha(doc)==args.document_sha256,'document/exact_review_target')
 audit=read(R/'independent-audit.json');outcomes=read(R/'outcomes-summary.json');outcome_review=read(R/'independent-outcomes-review.json')
 summary=read(R/'diagnostic-r1/results/summary.json');cold=read(R/'cold-import-preflight.json')
 for name,value in (('audit',audit),('outcomes_review',outcome_review),('cold',cold)):
  check(value['passed'] is True and not value['findings'],name+'/passed');bind(value)
 check(outcomes['complete'] is True and outcomes['script_sha256']==sha(pin(R/'summarize_scalar_diagnostics.py')),'outcomes/producer');bind(outcomes)
 check(summary['complete'] and summary['state_count']==18 and summary['panel_count']==len(summary['panels'])==36,'panels/complete_inventory')
 check(summary['all_archived_generation_predictions_equal'] is True and summary['all_saved_weights_preserved'] is True,'panels/unchanged')
 check(summary['greedy_passes']==36 and summary['optimizer_steps']==0,'panels/no_training')
 for key in ('training_executed','encoder_executed','downloads_performed','qualified','admitted','lake_executed','formalized','roundtrip_ok','fresh_holdout','checkpoint_promoted','convergence_proven','native_validation_executed'):
  check(summary[key] is False,'authority/'+key)
 check(summary['workers']==1 and summary['bridge_names']==[] and summary['legal_ir_evaluate_provers'] is False and summary['metric_disk_cache_used'] is False,'timing/declared_controls')
 panels={(p['arm'],p['split']):p for p in outcomes['panels']};aggregate=defaultdict(Counter);timings=defaultdict(list);gaps=defaultdict(Counter)
 margin_counts=defaultdict(Counter);perfect_count=0;perfect_sites=0;perfect_disagreements=0;available_vectors=0
 for panel in summary['panels']:
  name,split,dimension=panel['arm'],panel['split'],panel['dimension'];key=(dimension,split);saved=panels[(name,split)]
  trace=reference(panel['trace_ref']);score=reference(panel['score_ref']);archived=reference(panel['archived_panel_ref'])
  check(trace['trace_sha256']==score['trace_sha256'] and score['split']==split,'panel/score_trace_binding/'+name+'/'+split)
  check(panel['generation_predictions_exact'] is True and trace['predictions']==[{k:r[k] for k in ('id','token_ids','generation_status','eos_reached')} for r in archived['predictions']], 'panel/generation_parity/'+name+'/'+split)
  check(trace['sample_count']==48 and trace['batch_size']==8 and trace['generation_temperature']==0 and trace['max_target_tokens']==512 and trace['vocabulary_size']==32,'panel/limits/'+name+'/'+split)
  check(panel['elapsed_seconds']==saved['elapsed_seconds'],'panel/timing/'+name+'/'+split);timings[dimension].append(panel['elapsed_seconds'])
  site_map={(row['id'],site['position']):site for row in trace['rows'] for site in row['scalar_sites']}
  raw_by_id={row['id']:row for row in archived['source_values']['predictions']}
  for row in trace['rows']:
   for site in row['scalar_sites']:
    if site['source_slot_available']:
     old=raw_by_id[row['id']]['raw_logits'][site['slot']][('actor','action','modality','object').index(site['field'])]
     check(site['applied_source_logits']==old,'source/exact_archived_vector/'+name+'/'+split+'/'+str(site['position']));available_vectors+=1
  local=Counter();by_field=defaultdict(Counter)
  for event in score['events']:
   site=site_map[(event['id'],event['position'])];target=event['target_token_id'];guesses={}
   for component,logits_key in (('source','applied_source_logits'),('recurrent','raw_recurrent_logits'),('combined','combined_logits')):
    logits=site[logits_key];guesses[component]=max(range(32),key=logits.__getitem__)
    check(guesses[component]==event[component]['argmax_token_id'],'event/argmax/'+component)
    check(event[component]['target_minus_best_other']==logits[target]-max(v for i,v in enumerate(logits) if i!=target),'event/full_vocabulary_margin/'+component)
   source_ok=guesses['source']==target;recurrent_ok=guesses['recurrent']==target;combined_ok=guesses['combined']==target
   counts=dict(scored=1,source_correct=int(source_ok),recurrent_correct=int(recurrent_ok),combined_correct=int(combined_ok),
    source_wrong_combined_correct=int(not source_ok and combined_ok),source_correct_combined_wrong=int(source_ok and not combined_ok))
   local.update(counts);by_field[event['field']].update(counts)
   if dimension>8 and split=='exposed_development' and source_ok and not combined_ok:check(event['field']=='action','higher_width/overturn_action_only')
   if dimension>8 and split=='training':
    perfect_sites+=1;perfect_disagreements+=not recurrent_ok
    if source_ok:
     sm=event['source']['target_minus_best_other'];cm=event['combined']['target_minus_best_other']
     margin_counts[event['field']].update(source_correct=1,reduced=int(cm<sm),below_half=int(0<cm<.5*sm))
  aggregate[key].update(local)
  for field,counts in by_field.items():
   for label,count in counts.items():check(saved['per_field'][field]['counts'][label]==count,'summary/event_count/'+name+'/'+split+'/'+field+'/'+label)
  check(local['scored']==score['scored_sites']==saved['scored_sites'],'summary/scored_count/'+name+'/'+split)
  gaps[key].update(unvisited=len(score['unvisited_reference_sites']),unscored=len(score['unscored_sites']))
  check(len(score['unvisited_reference_sites'])==saved['unvisited_reference_sites'] and len(score['unscored_sites'])==saved['unscored_sites'],'summary/gaps/'+name+'/'+split)
  if dimension>8 and split=='training':
   check(saved['archived_exact_documents']==archived['source_fidelity']['metrics']['ordered_exact']==48,'higher_width/training_exact/'+name);perfect_count+=1
 expected=[]
 for dimension in (8,384,768):
  for split,title in (('training','Training'),('exposed_development','Exposed development')):
   c=aggregate[(dimension,split)];expected.append(f"| {dimension} | {title} | "+' | '.join(f'{c[k]:,}' for k in ('scored','source_correct','combined_correct','source_wrong_combined_correct','source_correct_combined_wrong'))+' |')
 check(table(text,'| Width | Split | Scored scalar sites | Source correct | Combined correct | Source error corrected | Correct source overturned |')==expected,'document/aggregate_table')
 expected_time=[]
 for dimension,values in sorted(timings.items()):
  expected_time.append(f'| {dimension} | {min(values):.3f}–{max(values):.3f} s | {1000*min(values)/48:.2f}–{1000*max(values)/48:.2f} ms |')
 check(table(text,'| Width | Observation plus posthoc scoring per 48-row panel | Wall time per span |')==expected_time,'document/timing_table')
 check(gaps[(8,'training')]['unvisited']==28 and gaps[(384,'exposed_development')]['unvisited']==24 and sum(v['unvisited'] for v in gaps.values())==52,'gaps/explicit')
 check(perfect_count==12 and perfect_sites==8640 and perfect_disagreements==5112,'higher_width/training_diagnostic_counts')
 check(sum(aggregate[(d,'exposed_development')]['source_correct_combined_wrong'] for d in (384,768))==18,'higher_width/development_overturns')
 # Supplemental training-only margin assessment is distinct from the main outcomes.
 margin=read(R/'training-margin-preservation.json');bind(margin)
 check(margin['complete'] is True and margin['script_sha256']==sha(pin(R/'assess_training_margin_preservation.py')),'margin/producer')
 for key in ('development_score_or_trace_read','models_executed','training_executed','loss_changed','coefficient_selected','improvement_established'):
  check(margin[key] is False,'margin/scope/'+key)
 check(sum(v['reduced'] for v in margin_counts.values())==2902 and margin_counts['action']['reduced']==164 and margin_counts['action']['source_correct']==2160,'margin/independent_reduced_counts')
 check(sum(v['below_half'] for v in margin_counts.values())==0,'margin/no_half_floor_signal')
 for field,counts in margin_counts.items():
  check(sum(margin['per_dimension'][str(d)][field]['counts']['eligible_margin_reduced'] for d in (384,768))==counts['reduced'],'margin/summary/'+field)
 # Followup audit, if completed before this review, binds the additional arithmetic review.
 followup=R/'independent-training-margin-review.json'
 if followup.exists():
  checked=read(followup);check(checked['passed'] is True and not checked['findings'],'margin/independent_review');bind(checked)
 tests=xml_counts(R/'tests-scoped.xml');guardian_tests=xml_counts(R/'watchdog-tests-attempt1.xml')
 check(tests==dict(tests=2899,failures=0,errors=0,skipped=0),'tests/frozen')
 check(guardian_tests==dict(tests=73,failures=0,errors=0,skipped=0),'tests/guardian')
 check(cold['checks']==70 and cold['torch_imported'] is False and cold['model_constructed'] is False and cold['model_executed'] is False and cold['state_read'] is False,'cold/no_model_or_state')
 check(cold['package_path_unchanged'] is True and len(cold['package_path'])==1 and 'validation-source-r2' in cold['package_path'][0],'cold/pinned_search_path')
 order=cold['explicit_load_order'];check(order.index('contextual_generated_boundary_training')<order.index('generated_field_training')<order.index('generated_scalar_observation'),'cold/explicit_dependency_order')
 prior=read(R/'prior-attempt.json');old=Path(prior['path']);failed=read(old/'diagnostic-r1/failure.json');old_exit=read(old/'guardian-exit.json');old_child=read(old/'diagnostic-r1/child-exit.json')
 oldlog=pin(old/'diagnostic-r1/child.log').read_text()
 check(old_exit['returncode']==old_child['returncode']==1 and 'ImportError' in oldlog and 'generated_field_training' in oldlog,'failed_attempt/real_import_failure')
 check(failed['resources']['record']['status']=='retained' and failed['resources']['record']['storage_bytes']==300000000,'failed_attempt/retained_claim')
 check(not (old/'diagnostic-r1/results/summary.json').exists() and prior['prior_outputs_reused'] is False,'failed_attempt/not_counted_as_success')
 resources=read(R/'diagnostic-r1/resources-final.json');exit=read(R/'guardian-exit.json');child=read(R/'diagnostic-r1/child-exit.json')
 check(exit['returncode']==child['returncode']==0 and resources['record']['status']=='released','success/actual_exits_release')
 check(resources['record']['final_attempt_bytes']==audit['resources']['actual_attempt_bytes']==83297988 and resources['record']['storage_bytes']==300000000 and resources['record']['memory_mb']==4096,'success/resource_budget')
 phrase(text,f"{summary['elapsed_seconds']:.3f} seconds",'timing/diagnostic_process')
 phrase(text,f"{exit['wrapper_elapsed_seconds']:.3f} seconds",'timing/wrapper')
 phrase(text,f"{old_exit['wrapper_elapsed_seconds']:.3f} seconds",'timing/failed_attempt')
 phrase(text,f"{audit['resources']['peak_observed_live_RSS_bytes']:,} bytes",'resource/sampled_RSS')
 check(audit['resources']['live_RSS_sample_count']==2 and audit['resources']['active_lease_observation_count']==40 and audit['resources']['continuous_lease_coverage_proven'] is False,'resource/scope')
 phrase(text,f"{audit['resources']['maximum_observed_active_gap_seconds']:.3f} seconds",'resource/observed_gap')
 phrase(text,f"{tests['tests']:,} frozen regression tests, {guardian_tests['tests']} guardian tests, {cold['checks']} actual-package cold-import checks and {audit['checks']:,} independent numerical/resource checks",'tests/exact_separate_counts')
 for label,part in {
  'all_states':'all 18 final attempts and observed all 36 panels',
  'source_parity':'Every visited, available source-logit vector also matched',
  'not_training':'not a new reconstruction improvement',
  'not_independent':'not 1,728 independent holdout documents',
  'gaps':'28 unvisited reference scalar sites in 8D training and 24 in 384D development',
  'training':'8,640 scalar sites',
  'disagreement':'5,112 sites',
  'benefit_and_harm':'recurrence corrects 139 source mistakes while overturning 45 correct source decisions',
  'margin_counts':'2,902 of the 8,640 higher-width source-correct sites, including 164 of the 2,160 action sites',
  'margin_not_chosen':'threshold is descriptive, not a chosen hyperparameter',
  'margin_subset':'margin-preservation eligibility excludes source-wrong sites',
  'no_common_pair_error':'different best competitors must not be added',
  'timing_scope':'not bare inference throughput',
  'bridges':'Bridge names were `[]`, provers were disabled',
  'metric_cache':'legal-IR metric disk cache was disabled',
  'cold':'no source encoder or cold natural-language compiler was timed',
  'no_bridge_speed':'not a legal-IR bridge speedup measurement',
  'no_peak':'not an absolute peak',
  'historical':'historical 8D linguistic teacher is untouched',
  'source_dimension':'nonsemantic linguistic-feature hashes',
  'lake':'Only the applicable successful `lake build <Lib>`',
  'constitution':'Constitution remains unformalized',
  'all_modalities':'not a decoder or family-qualification adapter for Security, Intent or UI IRs',
  'not_component_causal':'do not isolate the causal effect',
  'no_fresh_hypothesis_claim':'neither selects a loss coefficient nor establishes that such a penalty will generalize',
  'future_blind':'new blind test set is needed',
  'no_defaults':'no weights or optimizer defaults changed',
 }.items():phrase(text,part,label)
 for part in ('18 experimental Legal formula sidecars','36 trace/score panels','not a new training or reconstruction improvement','not independent holdouts',
  'unchanged historical linguistic teacher','No training, source encoder execution, weights download, Lake build',
  'Constitution remains unformalized','before observation','exact predecessor references','no automatic downloads'):
  phrase(readme,part,'readme/'+part)
 manifest=read(R/'diagnostic-manifest.json');frozen={**manifest['extensions'],**read(R/'validated-test-source.json')}
 for rel in read(R/'code-files.json'):
  if rel!=str(doc.relative_to(P)):
   check(sha(pin(P/rel))==frozen[rel] and sha(pin(R/'experiment-source'/rel))==frozen[rel],'source/live_frozen/'+rel)
 pin(__file__)
 check(sha(doc)==args.document_sha256,'document/unchanged_during_review')
 check(sha(readme_path)==artifacts[str(readme_path.resolve())]['sha256'],'readme/unchanged_during_review')
 result=dict(schema='contextual-scalar-documentation-review/v1',passed=not findings,checks=checks,findings=findings,finding_count=len(findings),
  document_path=str(doc),document_sha256=sha(doc),readme_path=str(readme_path),readme_sha256=sha(readme_path),artifacts=artifacts,
  source_sha256=sha(__file__),source_path=str(Path(__file__).resolve()),source_vectors_independently_matched=available_vectors,
  independent_audit_sha256=sha(R/'independent-audit.json'),outcomes_sha256=sha(R/'outcomes-summary.json'),training_margin_sha256=sha(R/'training-margin-preservation.json'),
  models_executed=False,training_executed=False,qualified=False,admitted=False,lake_executed=False,fresh_holdout_claimed=False,convergence_claimed=False,
  created_at_utc=datetime.now(timezone.utc).isoformat())
 with (R/'documentation-review.json').open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
 print(json.dumps(dict(passed=not findings,checks=checks,findings=findings)))
 if findings:raise SystemExit(1)
if __name__=='__main__':main()
