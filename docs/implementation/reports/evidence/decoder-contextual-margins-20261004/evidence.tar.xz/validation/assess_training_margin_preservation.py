"""Read-only, training-only applicability counts; no new objective or model run."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import struct

R=Path(__file__).resolve().parent
FIELDS=('actor','action','modality','object')
ARTIFACTS={}
CHECKS=0

def require(value,message):
    global CHECKS
    CHECKS+=1
    if not value:raise ValueError(message)

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def read(path,wanted=None):
    path=Path(path).resolve();data=path.read_bytes()
    record=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    require(wanted is None or record['sha256']==wanted,'bound artifact changed')
    ARTIFACTS[str(path)]=record
    return json.loads(data)

def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]

def classify(event):
    source=event['source'];combined=event['combined'];target=event['target_token_id']
    sm=source['target_minus_best_other'];cm=combined['target_minus_best_other']
    require(math.isfinite(sm) and math.isfinite(cm),'finite margins required')
    source_correct=source['argmax_token_id']==target
    combined_correct=combined['argmax_token_id']==target
    eligible=source_correct and sm>0
    return dict(scored=1,source_correct=int(source_correct),source_wrong=int(not source_correct),
        source_wrong_combined_correct=int(not source_correct and combined_correct),
        source_correct_zero_margin=int(source_correct and sm==0),
        eligible_positive_source_margin=int(eligible),
        eligible_combined_correct=int(eligible and combined_correct),
        eligible_combined_wrong=int(eligible and not combined_correct),
        eligible_margin_reduced=int(eligible and cm<sm),
        eligible_margin_not_reduced=int(eligible and cm>=sm),
        eligible_positive_combined_below_half_source_margin=int(eligible and 0<cm<.5*sm),
        eligible_nonpositive_combined_margin=int(eligible and cm<=0))

def example(event,site,panel,codec):
    target=event['target_token_id'];emitted=event['actual_next_token_id']
    pairs={}
    for name,key in [('source','applied_source_logits'),('recurrent','raw_recurrent_logits'),('combined','combined_logits')]:
        values=site[key]
        require(len(values)==32,'full vocabulary required')
        pair=dict(target_logit=values[target],emitted_logit=values[emitted],
                  target_minus_emitted=values[target]-values[emitted])
        require(pair['target_minus_emitted']==event[name]['target_minus_emitted'],'pair score differs')
        pairs[name]=pair
    for key in ('target_logit','emitted_logit'):
        require(f32(pairs['source'][key]+pairs['recurrent'][key])==pairs['combined'][key],'exact float32 additive logits differ')
    return dict(arm=panel['arm'],dimension=panel['dimension'],seed=panel['seed'],split='training',
        id=event['id'],slot=event['slot'],position=event['position'],field=event['field'],
        source_clause_sha256=event['source_clause_sha256'],prefix_sha256=event['prefix_sha256'],
        target_token_id=target,target_token=codec['target_vocabulary'][target],
        emitted_token_id=emitted,emitted_token=codec['target_vocabulary'][emitted],
        target_vs_actual_emitted_pairs=pairs,
        pair_margin_addition_rounding_residual=pairs['combined']['target_minus_emitted']-
            (pairs['source']['target_minus_emitted']+pairs['recurrent']['target_minus_emitted']),
        recurrent_component_is_source_conditioned=True,
        source_trace_ref=panel['trace_ref'],source_score_ref=panel['score_ref'])

def main():
    outcomes=read(R/'outcomes-summary.json')
    require(outcomes['complete'] is True and outcomes['models_executed'] is False,'completed immutable outcomes required')
    summary_path=R/'diagnostic-r1/results/summary.json'
    summary=read(summary_path,outcomes['artifacts'][str(summary_path)]['sha256'])
    panels=[p for p in summary['panels'] if p['split']=='training']
    require(len(panels)==18 and len({p['arm'] for p in panels})==18,'exact eighteen training panels required')
    first=panels[0]['state_ref'];state=read(first['path'],first['sha256']);codec=state['codec']
    require(len(codec['target_vocabulary'])==32,'fixed full vocabulary required')
    buckets={str(d):{f:Counter() for f in FIELDS} for d in (8,384,768)}
    reduced={str(d):{f:[] for f in FIELDS} for d in (8,384,768)}
    crosses={};per_panel=[]
    for panel in panels:
        score=read(panel['score_ref']['path'],panel['score_ref']['sha256'])
        trace=read(panel['trace_ref']['path'],panel['trace_ref']['sha256'])
        require(score['split']=='training' and score['complete'] and trace['complete'],'training-only complete receipts required')
        require(score['trace_sha256']==trace['trace_sha256'] and score['codec_sha256']==trace['codec_sha256']==digest(codec),'bound trace/codec differs')
        require(score['score_sha256']==digest({k:v for k,v in score.items() if k!='score_sha256'}) and
                trace['trace_sha256']==digest({k:v for k,v in trace.items() if k!='trace_sha256'}),'receipt digest differs')
        sites={(r['id'],s['position']):s for r in trace['rows'] for s in r['scalar_sites']}
        row={f:Counter() for f in FIELDS};dimension=str(panel['dimension'])
        for event in score['events']:
            field=event['field'];require(field in FIELDS,'unknown field')
            counts=classify(event);row[field].update(counts);buckets[dimension][field].update(counts)
            if counts['eligible_margin_reduced']:
                reduced[dimension][field].append(event['source']['target_minus_best_other']-event['combined']['target_minus_best_other'])
            key=dimension+':'+field
            if counts['eligible_combined_wrong'] and key not in crosses:
                crosses[key]=example(event,sites[(event['id'],event['position'])],panel,codec)
        per_panel.append(dict(arm=panel['arm'],dimension=panel['dimension'],seed=panel['seed'],
            per_field={f:dict(c) for f,c in row.items()},unvisited_reference_sites=len(score['unvisited_reference_sites']),
            score_ref=panel['score_ref'],trace_ref=panel['trace_ref']))
    for d,fields in buckets.items():
        for f,c in fields.items():
            require(c['eligible_margin_reduced']+c['eligible_margin_not_reduced']==c['eligible_positive_source_margin'],'partition differs')
            require(c['eligible_positive_combined_below_half_source_margin']<=c['eligible_margin_reduced'],'descriptive fraction subset differs')
    output=dict(schema='training-scalar-margin-preservation-applicability/v1',complete=True,checks=CHECKS,
        artifacts=ARTIFACTS,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        per_dimension={d:{f:dict(counts=dict(c),mean_margin_reduction_at_reduced_sites=
            (math.fsum(reduced[d][f])/len(reduced[d][f]) if reduced[d][f] else None)) for f,c in fields.items()} for d,fields in buckets.items()},
        panels=per_panel,first_crossing_example_per_dimension_and_field=crosses,
        counts_scope='Repeated model/site observations across six saved states per width; not unique training examples.',
        reduced_definition='Source argmax equals training label, source target-vs-best-other margin >0, combined margin < source margin.',
        fraction_definition='0 < combined target-vs-best-other margin < 0.5 * source margin; descriptive only, not a selected objective threshold.',
        candidate_hypothesis='A train-label-gated, detached-source margin-preservation penalty could target erosion while leaving helpful source-wrong recurrent corrections unpenalized. This report does not establish benefit, choose a coefficient, or authorize changing losses.',
        limitations=['Margins compare each component against its own full-vocabulary best alternative; those alternative tokens may differ.',
            'Crossing examples instead use the same target and actual emitted token, with float32 addition rounding reported explicitly.',
            'A smaller positive margin does not by itself indicate an incorrect or less useful distribution.',
            'The recurrent readout already contains source-conditioned history; the clause residual is not causally isolated.',
            'Any next objective needs a preregistered baseline/control comparison and fresh validation; no development labels were used here.'],
        development_score_or_trace_read=False,models_executed=False,training_executed=False,
        loss_changed=False,coefficient_selected=False,improvement_established=False,qualified=False,admitted=False)
    with (R/'training-margin-preservation.json').open('x') as stream:
        json.dump(output,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(complete=True,checks=CHECKS,training_panels=18,crossing_examples=len(crosses))))

if __name__=='__main__':main()
