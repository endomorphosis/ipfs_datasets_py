"""Audit margin applicability using original training traces only; no models."""
from pathlib import Path
from collections import Counter,defaultdict
import ast,hashlib,json,math,struct
R=Path(__file__).resolve().parent;checks=0;findings=[];artifacts={}
def check(ok,label):
    global checks
    checks+=1
    if not ok:findings.append(label)
def pin(path,wanted=None):
    p=Path(path).resolve();b=p.read_bytes();record=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());artifacts[str(p)]=record
    if wanted is not None:check(record=={k:wanted[k] for k in ('bytes','sha256')},'bound '+str(p))
    return p
def read(path,wanted=None):return json.loads(pin(path,wanted).read_bytes())
def close(a,b,label):check(abs(a-b)<=1e-11+2e-12*abs(b),label)
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def eligibility(source,target):
    margin=source[target]-max(v for i,v in enumerate(source) if i!=target)
    correct=max(range(len(source)),key=source.__getitem__)==target
    return correct and margin>0,correct,margin
def main():
    report=read(R/'training-margin-preservation.json');audit=read(R/'independent-audit.json')
    check(audit['passed'] and not audit['findings'],'independent_training_trace_audit_passed')
    source=pin(R/'assess_training_margin_preservation.py')
    check(artifacts[str(source)]['sha256']==report['script_sha256'],'producer_hash')
    # Review eligibility's strict inequality explicitly; tied correct argmaxes
    # may not occur in real data and therefore need a separate policy check.
    tree=ast.parse(source.read_text());classify=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='classify')
    value=next(n.value for n in classify.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='eligible' for t in n.targets))
    check(ast.dump(value)==ast.dump(ast.parse('source_correct and sm>0',mode='eval').body),'strict_positive_correct_source_policy')
    check(eligibility([1.,1.,0.],0)==(False,True,0.),'tied_correct_source_excluded')
    check(eligibility([0.,1.,0.],0)==(False,False,-1.),'wrong_source_excluded')
    check(eligibility([2.,1.,0.],0)==(True,True,1.),'strict_positive_source_eligible')
    check(len(report['panels'])==18 and len({r['arm'] for r in report['panels']})==18,'all_training_panels')
    totals=defaultdict(lambda:defaultdict(Counter));reductions=defaultdict(lambda:defaultdict(list));crossings={};codec=None
    parent=read(R/'diagnostic-r1/results/summary.json',audit['artifacts'][str(R/'diagnostic-r1/results/summary.json')])
    expected={r['arm']:r for r in parent['panels'] if r['split']=='training'}
    check({r['arm'] for r in report['panels']}==set(expected),'exact_training_inventory')
    for p in report['panels']:
        original=expected[p['arm']];check(p['score_ref']==original['score_ref'] and p['trace_ref']==original['trace_ref'],'original_training_references')
        if codec is None:codec=read(original['state_ref']['path'],audit['artifacts'][original['state_ref']['path']])['codec']
        for ref in (p['score_ref'],p['trace_ref']):
            check(Path(ref['path']).name.endswith('-training.json'),'training_files_only')
            check(audit['artifacts'][ref['path']]=={k:ref[k] for k in ('bytes','sha256')},'independently_audited_input')
        score=read(p['score_ref']['path'],p['score_ref']);trace=read(p['trace_ref']['path'],p['trace_ref'])
        check(score['split']=='training' and score['trace_sha256']==trace['trace_sha256'],'training_trace_binding')
        sites={(r['id'],s['position']):(r,s) for r in trace['rows'] for s in r['scalar_sites']};counts=defaultdict(Counter)
        for e in score['events']:
            row,site=sites[(e['id'],e['position'])];target=e['target_token_id'];emitted=e['actual_next_token_id'];field=e['field'];d=str(p['dimension'])
            eligible,sc,sm=eligibility(site['applied_source_logits'],target)
            combined=site['combined_logits'];cc=max(range(32),key=combined.__getitem__)==target
            cm=combined[target]-max(v for i,v in enumerate(combined) if i!=target)
            check(sm==e['source']['target_minus_best_other'] and cm==e['combined']['target_minus_best_other'],'raw_margin_arithmetic')
            check(site['source_slot_available'] and site['actual_next_token_id']==emitted,'visited_available_site')
            flags=dict(scored=1,source_correct=int(sc),source_wrong=int(not sc),source_wrong_combined_correct=int(not sc and cc),
                source_correct_zero_margin=int(sc and sm==0),eligible_positive_source_margin=int(eligible),
                eligible_combined_correct=int(eligible and cc),eligible_combined_wrong=int(eligible and not cc),
                eligible_margin_reduced=int(eligible and cm<sm),eligible_margin_not_reduced=int(eligible and cm>=sm),
                eligible_positive_combined_below_half_source_margin=int(eligible and 0<cm<.5*sm),
                eligible_nonpositive_combined_margin=int(eligible and cm<=0))
            check(not eligible if not sc or sm==0 else True,'ineligible_wrong_or_tied_source')
            counts[field].update(flags);totals[d][field].update(flags)
            if eligible and cm<sm:reductions[d][field].append(sm-cm)
            key=d+':'+field
            if eligible and not cc and key not in crossings:
                pairs={}
                for name,vector in [('source',site['applied_source_logits']),('recurrent',site['raw_recurrent_logits']),('combined',combined)]:
                    pairs[name]=dict(target_logit=vector[target],emitted_logit=vector[emitted],target_minus_emitted=vector[target]-vector[emitted])
                for which in ('target_logit','emitted_logit'):
                    check(f32(pairs['source'][which]+pairs['recurrent'][which])==pairs['combined'][which],'paired_logit_float32_addition')
                crossings[key]=dict(arm=p['arm'],dimension=p['dimension'],seed=p['seed'],split='training',
                    id=e['id'],slot=e['slot'],position=e['position'],field=field,source_clause_sha256=e['source_clause_sha256'],
                    prefix_sha256=digest(row['consumed_prefix'][:e['position']+1]),target_token_id=target,
                    target_token=codec['target_vocabulary'][target],emitted_token_id=emitted,emitted_token=codec['target_vocabulary'][emitted],
                    target_vs_actual_emitted_pairs=pairs,pair_margin_addition_rounding_residual=pairs['combined']['target_minus_emitted']-
                        (pairs['source']['target_minus_emitted']+pairs['recurrent']['target_minus_emitted']),
                    recurrent_component_is_source_conditioned=True,source_trace_ref=p['trace_ref'],source_score_ref=p['score_ref'])
        check({k:dict(v) for k,v in counts.items()}==p['per_field'],'panel_counts')
        check(p['unvisited_reference_sites']==len(score['unvisited_reference_sites']),'unvisited_reference_inventory')
    for d,fields in report['per_dimension'].items():
        for field,values in fields.items():
            check(values['counts']==dict(totals[d][field]),'dimension_field_counts')
            expected_mean=math.fsum(reductions[d][field])/len(reductions[d][field]) if reductions[d][field] else None
            if expected_mean is None:check(values['mean_margin_reduction_at_reduced_sites'] is None,'empty_reduction_mean')
            else:close(values['mean_margin_reduction_at_reduced_sites'],expected_mean,'mean_reduction')
    check(report['first_crossing_example_per_dimension_and_field']==crossings,'first_crossings_complete_exact')
    for name in ('development_score_or_trace_read','models_executed','training_executed','loss_changed','coefficient_selected','improvement_established','qualified','admitted'):
        check(report[name] is False,'scope/'+name)
    # The producer may read outcomes/summary metadata, but never a development
    # trace or score. Its recorded artifact inventory is independently checked.
    check(not any(Path(p).name in ('score-exposed_development.json','trace-exposed_development.json') for p in report['artifacts']),'producer_never_read_development_trace_or_score')
    higher=sum(totals[d][f]['eligible_margin_reduced'] for d in ('384','768') for f in totals[d])
    action=sum(totals[d]['action']['eligible_margin_reduced'] for d in ('384','768'))
    half=sum(totals[d][f]['eligible_positive_combined_below_half_source_margin'] for d in ('384','768') for f in totals[d])
    result=dict(schema='independent-training-margin-review/v1',passed=not findings,checks=checks,finding_count=len(findings),
        findings=findings,artifacts=artifacts,training_panels=18,higher_width_reduced_margin_observations=higher,
        higher_width_action_reduced_margin_observations=action,higher_width_positive_combined_below_half_source=half,
        source_wrong_combined_correct_excluded=sum(totals[d][f]['source_wrong_combined_correct'] for d in totals for f in totals[d]),
        source_correct_zero_margin_excluded=sum(totals[d][f]['source_correct_zero_margin'] for d in totals for f in totals[d]),
        scope='Repeated training-site observations; descriptive half-margin threshold only. No objective selected or benefit established.',
        development_score_or_trace_read=False,models_executed=False,training_executed=False,qualified=False,admitted=False)
    p=Path(__file__);pin(p);result['artifacts']=artifacts
    with (R/'independent-training-margin-review.json').open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps({k:result[k] for k in ('passed','checks','findings','higher_width_reduced_margin_observations','higher_width_action_reduced_margin_observations','higher_width_positive_combined_below_half_source','source_wrong_combined_correct_excluded','source_correct_zero_margin_excluded')}));return bool(findings)
if __name__=='__main__':raise SystemExit(main())
