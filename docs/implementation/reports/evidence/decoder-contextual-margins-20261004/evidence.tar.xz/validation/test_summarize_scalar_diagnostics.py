"""Pure-Python, hand-authored arithmetic fixtures. No production/model imports."""
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path

import pytest

SPEC = importlib.util.spec_from_file_location(
    'saved_scalar_summary', Path(__file__).with_name('summarize_scalar_diagnostics.py'))
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def seal(value, name):
    value.pop(name, None)
    value[name] = hashlib.sha256(json.dumps(
        value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    return value


def independent_metrics(values, target, emitted):
    # Integer fixture logits avoid float32 conversion subtleties. Direct exp/sum
    # deliberately differs from the implementation's stable logsumexp.
    return {
        'argmax_token_id': values.index(max(values)),
        'target_minus_best_other': values[target] - max(values[:target] + values[target + 1:]),
        'target_minus_emitted': values[target] - values[emitted],
        'full_vocabulary_cross_entropy': math.log(sum(math.exp(x) for x in values)) - values[target],
    }


def fixture():
    # Target token 0: source right/recurrent wrong/combined right;
    # source wrong/recurrent right/combined right; source right/combined wrong.
    cases = [(4., 0., 0., 1.), (0., 1., 4., 0.), (1., 0., 0., 4.)]
    events, sites = [], []
    for slot, (s0, s1, r0, r1) in enumerate(cases):
        source = [s0, s1] + [-4.] * 30
        recurrent = [r0, r1] + [-4.] * 30
        combined = [x + y for x, y in zip(source, recurrent)]
        emitted = combined.index(max(combined))
        site = dict(position=slot + 1, slot=slot, field='action',
                    actual_next_token_id=emitted, source_slot_available=True,
                    source_clause_sha256='a' * 64,
                    applied_source_logits=source, raw_recurrent_logits=recurrent,
                    combined_logits=combined)
        event = dict(id='fixture', position=slot + 1, slot=slot, field='action',
                     target_token_id=0, actual_next_token_id=emitted,
                     source_clause_sha256='a' * 64)
        event.update({k: independent_metrics(v, 0, emitted) for k, v in
                      [('source', source), ('recurrent', recurrent), ('combined', combined)]})
        sites.append(site)
        events.append(event)
    trace = seal(dict(complete=True, rows=[dict(id='fixture', scalar_sites=sites)],
                      scalar_site_count=3), 'trace_sha256')
    counts = {f: dict(scored=0, source_correct=0, recurrent_correct=0,
                     combined_correct=0, source_correct_combined_wrong=0) for f in M.FIELDS}
    counts['action'] = dict(scored=3, source_correct=2, recurrent_correct=1,
                            combined_correct=2, source_correct_combined_wrong=1)
    score = seal(dict(complete=True, trace_sha256=trace['trace_sha256'], split='training',
                     training_loss_returned=False, reference_labels_used_only_after_rollout=True,
                     events=events, per_field=counts, scored_sites=3,
                     unscored_sites=[], unvisited_reference_sites=[]), 'score_sha256')
    return trace, score


def reseal(trace, score):
    seal(trace, 'trace_sha256')
    score['trace_sha256'] = trace['trace_sha256']
    seal(score, 'score_sha256')


def test_hand_computed_counts_and_distributions():
    trace, score = fixture()
    result = M.summarize_panel(trace, score)
    count = result['per_field']['action']['counts']
    assert count == dict(scored=3, source_correct=2, recurrent_correct=1, combined_correct=2,
                         source_correct_combined_wrong=1, source_wrong_combined_correct=1,
                         source_correct_combined_correct=1, source_wrong_combined_wrong=0,
                         source_recurrent_argmax_disagree=3,
                         source_recurrent_argmax_disagree_combined_correct=2,
                         source_correct_recurrent_wrong_combined_correct=1,
                         source_wrong_recurrent_correct_combined_correct=1)
    distribution = result['per_field']['action']['distributions']
    assert distribution['source_target_minus_best_other']['mean'] == pytest.approx(4 / 3)
    assert distribution['combined_target_minus_best_other']['mean'] == 1
    assert distribution['combined_minus_source_target_margin']['mean'] == pytest.approx(-1 / 3)
    assert distribution['KL_source_to_combined_full_vocabulary']['count'] == 3
    assert distribution['KL_source_to_combined_when_both_correct']['count'] == 1
    assert result['scored_sites'] == 3
    assert result['unscored_sites'] == result['unvisited_reference_sites'] == 0
    assert result['softmax_temperature_for_diagnostic'] == 1
    assert result['generation_temperature'] == 0


@pytest.mark.parametrize('mutation,reason', [
    (lambda t, s: t['rows'][0]['scalar_sites'][0]['combined_logits'].__setitem__(4, -7.), 'decomposition'),
    (lambda t, s: s['events'][0]['source'].__setitem__('target_minus_best_other', 3.), 'margin/CE'),
    (lambda t, s: s['per_field']['action'].__setitem__('scored', 4), 'per-field counts'),
    (lambda t, s: s.__setitem__('scored_sites', 4), 'site count'),
    (lambda t, s: s['events'][0].__setitem__('target_token_id', -1), 'token id'),
    (lambda t, s: s['events'][0].__setitem__('target_token_id', True), 'token id'),
    (lambda t, s: t['rows'][0]['scalar_sites'][0].__setitem__('source_slot_available', False), 'source identity'),
    (lambda t, s: s.__setitem__('training_loss_returned', True), 'posthoc'),
    (lambda t, s: s.__setitem__('split', 'blind_test'), 'posthoc'),
])
def test_arithmetic_and_policy_tampering_fails(mutation, reason):
    trace, score = fixture()
    mutation(trace, score)
    reseal(trace, score)
    with pytest.raises(ValueError, match=reason):
        M.summarize_panel(trace, score)


def test_unsealed_score_tampering_fails():
    trace, score = fixture()
    score['events'][0]['combined']['target_minus_emitted'] += .1
    with pytest.raises(ValueError, match='digest'):
        M.summarize_panel(trace, score)


def test_duplicate_scored_reference_fails():
    trace, score = fixture()
    trace['rows'][0]['scalar_sites'][1]['slot'] = 0
    score['events'][1]['slot'] = 0
    reseal(trace, score)
    with pytest.raises(ValueError, match='duplicate scored reference'):
        M.summarize_panel(trace, score)


def test_duplicate_positions_fail():
    trace, score = fixture()
    trace['rows'][0]['scalar_sites'][1]['position'] = 1
    reseal(trace, score)
    with pytest.raises(ValueError, match='duplicate scalar position'):
        M.summarize_panel(trace, score)


def test_missing_unvisited_inventory_cannot_complete():
    trace, score = fixture()
    score.pop('unvisited_reference_sites')
    reseal(trace, score)
    with pytest.raises(KeyError, match='unvisited_reference_sites'):
        M.summarize_panel(trace, score)


def test_kl_is_zero_at_equal_distributions_and_translation_invariant():
    source = [3., 1.] + [-4.] * 30
    assert M.divergence(source, source) == 0
    assert M.divergence(source, [v + 5 for v in source]) == pytest.approx(0, abs=1e-12)
    combined = [1., 3.] + [-4.] * 30
    expected = sum(math.exp(x) / sum(math.exp(a) for a in source) *
                   math.log((math.exp(x) / sum(math.exp(a) for a in source)) /
                            (math.exp(y) / sum(math.exp(b) for b in combined)))
                   for x, y in zip(source, combined))
    assert M.divergence(source, combined) == pytest.approx(expected, abs=1e-12)


def test_quantiles_are_defined_for_empty_singleton_and_even_samples():
    assert M.distribution([])['mean'] is None
    assert M.distribution([4])['p95'] == 4
    result = M.distribution([3, 0, 1, 2])
    assert result['median'] == 1.5
    assert result['p05'] == pytest.approx(.15)
    assert result['p95'] == pytest.approx(2.85)


def test_training_assessment_does_not_read_development_values():
    trace, score = fixture()
    panel = M.summarize_panel(trace, score)
    panel['archived_exact_documents'] = 48
    panels = [copy.deepcopy(panel) for _ in range(18)]
    development = dict(split='exposed_development')  # Poison: missing all other keys.
    value = M.training_assessment(panels + [development])
    assert value['development_values_used_for_this_assessment'] is False
    assert value['training_scalar_counts']['scored'] == 54
    assert value['counts_in_perfect_training_panels']['scored'] == 54
    assert value['training_scalar_counts_by_field']['action']['scored'] == 54
    assert value['perfect_training_scalar_counts_by_field']['action']['scored'] == 54
    assert value['perfect_training_panel_count'] == 18
    assert value['next_training_authorized_by_this_receipt'] is False
    assert value['fresh_validation_required'] is True


def test_incomplete_training_panels_refused():
    with pytest.raises(ValueError, match='eighteen'):
        M.training_assessment([])
