"""Hand-authored descriptive margin cases, independent of any model outputs."""
import importlib.util
from pathlib import Path
import pytest

SPEC=importlib.util.spec_from_file_location('_margin_assessment_tests',
    Path(__file__).with_name('assess_training_margin_preservation.py'))
M=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(M)

def event(source_margin,combined_margin,source_id=0,combined_id=0):
    return dict(target_token_id=0,source=dict(argmax_token_id=source_id,target_minus_best_other=source_margin),
                combined=dict(argmax_token_id=combined_id,target_minus_best_other=combined_margin))

def test_helpful_recurrence_after_wrong_source_is_excluded():
    c=M.classify(event(-1.,2.,source_id=1))
    assert c['source_wrong_combined_correct']==1
    assert c['eligible_positive_source_margin']==c['eligible_margin_reduced']==0

@pytest.mark.parametrize('source,combined,eligible,reduced,half,nonpositive',[
    (2.,3.,1,0,0,0), (2.,2.,1,0,0,0), (2.,1.5,1,1,0,0),
    (2.,1.,1,1,0,0), (2.,.5,1,1,1,0), (2.,0.,1,1,0,1),
    (2.,-.5,1,1,0,1), (0.,1.,0,0,0,0),
])
def test_strict_positive_and_descriptive_half_boundaries(source,combined,eligible,reduced,half,nonpositive):
    c=M.classify(event(source,combined,combined_id=int(combined<0)))
    assert c['eligible_positive_source_margin']==eligible
    assert c['eligible_margin_reduced']==reduced
    assert c['eligible_positive_combined_below_half_source_margin']==half
    assert c['eligible_nonpositive_combined_margin']==nonpositive

def test_nonfinite_margin_cannot_be_classified():
    with pytest.raises(ValueError,match='finite margins'):
        M.classify(event(float('nan'),1.))
