"""Retain the complete observation run with exact published-state references."""
from pathlib import Path
import hashlib,json,os,subprocess,tarfile,xml.etree.ElementTree as ET
P=Path('/home/barberb/lift_coding/external/ipfs_datasets');R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
O=P/'docs/implementation/reports/evidence/decoder-action-consistency-20261003'
E=P/'docs/implementation/reports/evidence/decoder-contextual-margins-20261004'
BASE=json.loads((R/'base.json').read_bytes())['base']
FALSE=dict(qualified=False,admitted=False,proof_authority=False,source_semantics_verified=False,
    convergence_proven=False,fresh_holdout=False,lake_executed=False,formalized=False,roundtrip_ok=False,
    checkpoint_promoted=False,production_checkpoint=False,optimizer_resumable=False,native_validation_executed=False,
    training_executed=False,encoder_executed=False,downloads_performed=False)
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def info(path):return dict(bytes=Path(path).stat().st_size,sha256=sha(path))
def read(path):return json.loads(Path(path).read_bytes())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def git(*args):return subprocess.check_output(['git',*args],cwd=P)
def main():
    require(not E.exists(),'immutable new evidence directory required')
    audit=read(R/'independent-audit.json');ready=read(R/'readiness.json');docs=read(R/'documentation-review.json')
    for value in (audit,ready,docs):
        require(value['passed'] and not value['findings'],'clean audit required')
        for path,expected in value['artifacts'].items():require(info(path)==expected,'changed audited artifact '+path)
    summary=read(R/'diagnostic-r1/results/summary.json');manifest=read(R/'diagnostic-manifest.json');plan=read(R/'diagnostic-plan.json')
    require(summary['complete'] and summary['state_count']==18 and summary['panel_count']==36,'complete saved-state observation required')
    require(summary['all_archived_generation_predictions_equal'] and summary['all_saved_weights_preserved'],'unchanged inference and weights required')
    require(sha(R/'diagnostic-plan.json')==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'],'plan binding differs')
    for path,h in manifest['inputs'].items():require(sha(path)==h,'sealed input differs')
    old=read(O/'manifest.json')
    for name in ('manifest.json','results.json'):
        require((O/name).read_bytes()==git('show',BASE+':'+str((O/name).relative_to(P))),'published metadata differs')
    dependency=dict(id='generated-replay-consistency-'+BASE,repository='https://github.com/endomorphosis/ipfs_datasets_py',git_commit=BASE,
        archive=dict(logical_filename='evidence.tar.xz',**old['archive']),
        archive_parts=[dict(path=str((O/p['filename']).relative_to(P)),**p) for p in old['archive_parts']],
        manifest=dict(path=str((O/'manifest.json').relative_to(P)),**info(O/'manifest.json')),
        results=dict(path=str((O/'results.json').relative_to(P)),**info(O/'results.json')),
        retrieval='Read ordered archive_parts at git_commit:path, verify chunks, concatenate and verify logical archive before extraction.')
    sources={};members={};originals={};refs={}
    def add(path,name):
        path=Path(path);require(path.is_file() and not path.is_symlink(),'regular artifact required')
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'safe member path required')
        entry=info(path)
        require(name not in members or members[name]==entry,'archive member collision')
        members[name]=entry;sources[name]=path;originals[str(path.resolve())]=name
    exclusions={'owned-files.json','publication.json','publication-compatibility.json','build-evidence.log'}
    for path in sorted(R.rglob('*')):
        if not path.is_file() or path.name in exclusions or path.suffix in ('.pyc','.index') or any(
            q=='__pycache__' or q.startswith('pytest-') or q=='.pytest_cache' for q in path.relative_to(R).parts):continue
        rel=path.relative_to(R);name='source/'+str(rel.relative_to('experiment-source')) if rel.parts[0]=='experiment-source' else 'validation/'+str(rel)
        add(path,name)
    prior=Path(read(R/'prior-attempt.json')['path'])
    for path in sorted(prior.rglob('*')):
        if not path.is_file() or path.suffix in ('.pyc','.index') or any(
            q=='__pycache__' or q.startswith('pytest-') or q=='.pytest_cache' for q in path.relative_to(prior).parts):continue
        add(path,'prior-attempt/'+str(path.relative_to(prior)))
    owned=read(R/'code-files.json');doc='docs/autoencoders/contextual_scalar_diagnostics.md'
    add(P/doc,'source/'+doc)
    frozen={**manifest['extensions'],**read(R/'validated-test-source.json')}
    for rel in owned:
        expected=docs['document_sha256'] if rel==doc else frozen[rel]
        require(sha(P/rel)==expected and members['source/'+rel]==info(P/rel),'candidate differs '+rel)
        originals[str((P/rel).resolve())]='source/'+rel
    union=dict(old['validated_producer_source_sha256']);union.update(manifest['extensions'])
    for scoped,h in summary['source_dependencies'].items():
        kind,rel=scoped.split(':',1);require(kind in ('dependency','extension'),'producer scope differs')
        require(rel not in union or union[rel]==h,'producer conflict');union[rel]=h
    for rel,h in union.items():
        path=R/'experiment-source'/rel
        if not path.is_file():path=S/rel
        require(path.is_file() and sha(path)==h,'missing exact frozen source '+rel);add(path,'source/'+rel)
    needed=set(manifest['inputs'])|set(audit['artifacts'])|set(ready['artifacts'])|set(docs['artifacts'])
    for path in sorted(needed):
        if path in originals:continue
        expected=info(path);p=Path(path)
        if p.parent==O and p.name in {'manifest.json','results.json','guardian-provenance.json',
            *[part['filename'] for part in old['archive_parts']]}:
            require(p.read_bytes()==git('show',BASE+':'+str(p.relative_to(P))),'published support differs')
            refs[path]=dict(kind='git_blob',dependency_id=dependency['id'],git_commit=BASE,path=str(p.relative_to(P)),**expected)
        elif path in old['original_artifact_archive_paths']:
            member=old['original_artifact_archive_paths'][path];require(old['members'][member]==expected,'predecessor member differs')
            refs[path]=dict(kind='archive_member',dependency_id=dependency['id'],member=member,**expected)
        elif path in old['referenced_artifacts']:
            value=old['referenced_artifacts'][path];require(all(value[k]==v for k,v in expected.items()),'predecessor reference differs');refs[path]=value
        elif path in old['protected_external_artifacts']:
            require(all(old['protected_external_artifacts'][path][k]==v for k,v in expected.items()),'protected artifact differs')
        elif path in old['external_runtime_dependencies']:
            require(all(old['external_runtime_dependencies'][path][k]==v for k,v in expected.items()),'external runtime differs')
        else:
            require(expected['bytes']<10_000_000,'unresolved large external artifact '+path)
            add(path,'additional-inputs/'+expected['sha256']+'-'+p.name)
    E.mkdir(parents=True);archive=E/'evidence.tar.xz'
    with tarfile.open(archive,'w:xz',preset=6) as bundle:
        for name,path in sorted(sources.items()):
            require(info(path)==members[name],'artifact changed during archive');item=bundle.gettarinfo(str(path),arcname=name)
            item.uid=item.gid=0;item.uname=item.gname='';item.mtime=0
            with path.open('rb') as f:bundle.addfile(item,f)
    parts=[];offset=0
    with archive.open('rb') as f:
        for index,block in enumerate(iter(lambda:f.read(48_000_000),b''),1):
            path=E/('evidence.tar.xz.part-'+str(index).zfill(3));path.write_bytes(block)
            parts.append(dict(filename=path.name,offset_bytes=offset,**info(path)));offset+=len(block)
    with tarfile.open(archive,'r:xz') as bundle:
        require(len(bundle.getmembers())==len(members),'archive inventory mismatch')
        for item in bundle:
            b=bundle.extractfile(item).read();require(dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())==members[item.name],'archive content mismatch')
    readme=E/'README.md';readme.write_bytes((R/'public-readme.txt').read_bytes())
    tests={k:sum(int(s.get(k,0)) for s in ET.parse(R/'tests-scoped.xml').getroot().iter('testsuite')) for k in ('tests','failures','errors','skipped')}
    require(tests['tests']>2801 and not any(tests[k] for k in ('failures','errors','skipped')),'regression failed')
    m=dict(schema='contextual-scalar-diagnostic-archive/v1',archive=info(archive),archive_filename=archive.name,archive_parts=parts,
        publication_support={'README.md':info(readme)},archive_standalone=False,archive_compression='xz',xz_preset=6,
        members=members,original_artifact_archive_paths=originals,referenced_artifacts=refs,
        archive_dependencies=[dependency]+old['archive_dependencies'],external_runtime_dependencies=old['external_runtime_dependencies'],
        protected_external_artifacts=old['protected_external_artifacts'],validated_producer_source_sha256=union,
        publication_producer_source_sha256=union,publication_producer_overrides={},
        dependency_scope='36 observed panels with full scalar logits; unchanged saved states and source inputs use exact predecessor archive references.',
        reproducibility_scope='Frozen producers and retained artifacts; installed libraries and hardware external; no source encoding.',**FALSE)
    result=dict(schema='contextual-scalar-diagnostic-results/v1',complete=True,archive=info(archive),plan=plan,
        outcomes=read(R/'outcomes-summary.json'),tests=tests,
        independent_audit_sha256=sha(R/'independent-audit.json'),independent_audit_checks=audit['checks'],
        candidate_sha256={rel:sha(P/rel) for rel in owned},resources=read(R/'diagnostic-r1/resources-final.json'),
        guardian_succeeded=read(R/'guardian-exit.json')['returncode']==read(R/'diagnostic-r1/child-exit.json')['returncode']==0,
        workers=1,bridge_names=[],legal_ir_evaluate_provers=False,metric_disk_cache_used=False,
        known_excluded_fixture='16 inherited incompatible384 setup cases, not used or counted as passing',**FALSE)
    save(E/'manifest.json',m);save(E/'results.json',result)
    save(R/'owned-files.json',owned+[str((E/name).relative_to(P)) for name in [p['filename'] for p in parts]+['manifest.json','results.json','README.md']])
    print(json.dumps(dict(archive=info(archive),members=len(members),sources=len(union),references=len(refs))))
if __name__=='__main__':main()
