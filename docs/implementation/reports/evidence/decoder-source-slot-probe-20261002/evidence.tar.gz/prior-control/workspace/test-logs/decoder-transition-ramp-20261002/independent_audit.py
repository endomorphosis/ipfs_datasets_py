"""Independent persisted-evidence audit of a fixed transition learning-rate ramp.

Standard-library arithmetic only: no Torch, model, parser or native tool runs.
Exact prior-control equality is distinct from the candidate's intentional LR
change. No diagnostic result grants qualification or checkpoint promotion.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import math
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
ROOT = Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN = Path(__file__).resolve().parent
PRIOR = ROOT/'workspace/test-logs/decoder-gradient-trace-20261002'
HELPER = PRIOR/'independent_audit.py'
HELPER_SHA = '9f0b1cdfd992d744c89c7a35566963782b19d9923986491d47d5b1bf615f15fb'
TESTED_BASE = '8de37ba8d216cd21a5d7134292de01d9e12c9a56'
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA:
    raise ValueError('previous published arithmetic audit helper differs')
spec = importlib.util.spec_from_file_location('_transition_ramp_gradient_audit', HELPER)
gradient = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = gradient; spec.loader.exec_module(gradient)
prior, old = gradient.prior, gradient.old
read, check, sha, digest, raw = old.read, old.check, old.sha, old.digest, old.raw
checks, findings, artifacts = old.checks, old.findings, old.artifacts
artifacts[str(HELPER)] = dict(sha256=HELPER_SHA, bytes=HELPER.stat().st_size)


def audit_schedule(run, folder):
    report = run['training']; trace = report['gradient_trace']; update = report['transition_updates']; label = run['arm']+'/schedule'
    mode = run['recipe']['transition_schedule']; steps = update['steps']
    check(update['schema'] == 'first-expansion-transition-updates/v1' and update['mode'] == mode
        and update['uncommitted_steps'] == [] and len(steps) == len(trace['steps']) == 340
        and update['scheduler_base_restored_after_each_step'] is True and update['optimizer_reinitialized'] is False
        and update['full_sequence_backpropagation'] is True and update['additional_backwards'] is False
        and update['additional_gradient_clipping'] is False and update['used_for_selection'] is False,
        label+'/closed_committed_budget_and_unchanged_update_policy')
    previous_ids = None; first_expansion = first_stage = None; index = 0
    for stage in report['curriculum']:
        current = set(stage['training_ids'])
        if first_expansion is None and previous_ids is not None and previous_ids < current:
            first_expansion, first_stage = index, stage['name']
        index += math.ceil(len(current)/report['config']['batch_size'])*stage['epochs']
        previous_ids = current
    expected_start = first_expansion if mode == 'first_expansion_ramp20' else None
    check(first_expansion == 40 and update['ramp_start_optimizer_step'] == expected_start
        and update['ramp_stage'] == (first_stage if expected_start is not None else None)
        and update['ramp_committed_updates'] == (20 if expected_start is not None else 0), label+'/first_strict_superset_once')
    history = {row['epoch']: row for row in report['history']}
    base = report['config']['learning_rate']; best = float('inf'); bad = 0
    base_before_epoch = {}; base_after_epoch = {}
    for epoch, observation in sorted(history.items()):
        base_before_epoch[epoch] = base
        if observation['numerical'] is not None:
            value = observation['numerical']['token_cross_entropy']
            if value < best*(1-1e-4): best, bad = value, 0
            else: bad += 1
            if bad > report['config']['plateau_patience']:
                next_rate = max(base*report['config']['plateau_factor'],
                    report['config']['learning_rate']*report['config']['min_learning_rate_ratio'])
                if base-next_rate > 1e-8: base = next_rate
                bad = 0
        base_after_epoch[epoch] = base
        check(observation['learning_rate'] == base, label+'/epoch-'+str(epoch)+'/independent_plateau_base_not_compounded_by_ramp')
    selected = read(folder/'selected-state.json')['model_state']; frozen = set(report['frozen_parameter_names'])
    all_parameters = set(selected); elements = {name: len(list(old.flat(value))) for name, value in selected.items()}
    def valid_norms(values, parameter_sq, update_sq, path):
        p, u = math.sqrt(parameter_sq), math.sqrt(update_sq)
        check(math.isclose(values['parameter_norm_before'], p, rel_tol=1e-12, abs_tol=1e-12)
            and math.isclose(values['actual_update_norm'], u, rel_tol=1e-12, abs_tol=1e-12), path+'/squared_to_l2_norms')
        ratio = u/p if p else None
        check(values['update_to_parameter_ratio'] is None if ratio is None else math.isclose(
            values['update_to_parameter_ratio'], ratio, rel_tol=1e-12, abs_tol=1e-12), path+'/relative_update')
    summaries = {}; update_by_step = {}
    for row, gradient_row in zip(steps, trace['steps']):
        number = row['optimizer_step_before']; path = label+'/step-'+str(number)
        j = number-expected_start if expected_start is not None and 0 <= number-expected_start < 20 else None
        factor = .1+.9*j/19 if j is not None else 1.
        expected_base = [base_before_epoch[row['epoch']]]
        expected_effective = [rate*factor for rate in expected_base]
        check(row['committed'] is True and all(row[key] == gradient_row[key] for key in ('optimizer_step_before', 'epoch', 'stage', 'stage_epoch'))
            and row['ramp_index'] == j and row['ramp_factor'] == factor and row['scheduler_base_learning_rates'] == expected_base
            and row['effective_learning_rates'] == gradient_row['learning_rates'] == expected_effective, path+'/exact_factor_and_effective_rates')
        values = row['update_norms']; seen = set(); p_sq = u_sq = train_p = train_u = 0.
        for group, item in values['groups'].items():
            names = item['parameter_names']; nameset = set(names)
            check(nameset <= all_parameters and not seen & nameset and len(nameset) == len(names)
                and item['elements'] == sum(elements[name] for name in names)
                and item['trainable_elements'] == sum(elements[name] for name in names if name not in frozen), path+'/'+group+'/complete_parameter_inventory')
            seen.update(nameset)
            a, b = item['parameter_squared_norm'], item['update_squared_norm']
            check(math.isfinite(a) and math.isfinite(b) and a >= 0 and b >= 0, path+'/'+group+'/finite_actual_delta_norms')
            valid_norms(item, a, b, path+'/'+group)
            p_sq += a; u_sq += b
            if nameset <= frozen:
                check(b == 0., path+'/'+group+'/frozen_projection_zero_movement')
            else:
                check(not nameset & frozen, path+'/'+group+'/unmixed_trainable_group')
                train_p += a; train_u += b
        check(seen == all_parameters, path+'/all_parameters_measured')
        valid_norms(values['global_summary'], p_sq, u_sq, path+'/global')
        valid_norms(values['trainable_global_summary'], train_p, train_u, path+'/trainable_global')
        update_by_step[number] = values
        bucket = summaries.setdefault(row['stage'], dict(steps=0, sum_actual_update_norm=0., max_actual_update_norm=0., min_effective_lr=float('inf'), max_effective_lr=0.))
        norm = values['trainable_global_summary']['actual_update_norm']
        bucket['steps'] += 1; bucket['sum_actual_update_norm'] += norm; bucket['max_actual_update_norm'] = max(bucket['max_actual_update_norm'], norm)
        bucket['min_effective_lr'] = min(bucket['min_effective_lr'], *expected_effective)
        bucket['max_effective_lr'] = max(bucket['max_effective_lr'], *expected_effective)
    check(update['scheduler_base_learning_rates_final'] == [base], label+'/final_scheduler_base')
    # Captured weights let arithmetic verify measured pre-update parameter norms.
    # Post-update values are SHA-only: delta-vector reconstruction stays a model replay task.
    for item in run['gradient_replays']['events']:
        packet = read(Path(item['packet_receipt']['path'])); event = gradient.unpack(packet['event'])
        number = event['optimizer_step_before']; values = update_by_step[number]
        check(event['learning_rates'] == steps[number]['effective_learning_rates'], label+'/capture-'+str(number)+'/effective_lr')
        for group, item in values['groups'].items():
            parameter_sq = sum(sum(value*value for value in old.flat(event['model_state_dict'][name].values)) for name in item['parameter_names'])
            check(math.isclose(parameter_sq, item['parameter_squared_norm'], rel_tol=1e-11, abs_tol=1e-11),
                label+'/capture-'+str(number)+'/'+group+'/independent_prestate_norm')
    return dict(mode=mode, first_expansion_step=first_expansion, actual_ramp_start=expected_start,
        ramp_indices_verified=list(range(20)) if expected_start is not None else [],
        scheduler_base_learning_rates_final=[base], all_step_rate_arithmetic_verified=True,
        actual_delta_summary_arithmetic_verified=True, delta_vectors_recomputed_by_auditor=False,
        per_stage=summaries, observer_elapsed_seconds=update['observer_elapsed_seconds'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', default='smoke-r1')
    parser.add_argument('--output', type=Path, default=RUN/'independent-audit.json')
    parser.add_argument('--published-main', default=TESTED_BASE)
    args = parser.parse_args(); attempt = RUN/args.attempt; results = attempt/'results'
    if not all((attempt/path).is_file() for path in ('results/summary.json', 'results/sealed-recipe.json',
        'resources-final.json', 'command.json', 'child-exit.json')):
        print(json.dumps(dict(status='waiting_for_complete_durable_results'))); return 3
    if args.output.exists(): raise FileExistsError('audit output must be fresh')
    source_sha = sha(__file__)
    command = read(attempt/'command.json'); argv = command['command']
    argument = lambda name: Path(argv[argv.index('--'+name)+1])
    manifest, plan = read(argument('manifest')), read(argument('plan'))
    source, dependency = argument('extension-root'), argument('dependency-root')
    summary, sealed = read(results/'summary.json'), read(results/'sealed-recipe.json')
    check(sealed['plan'] == plan and sealed['manifest'] == manifest and sha(argument('plan')) == manifest['plan_sha256'], 'pins/sealed_recipe')
    for relative, expected in manifest['extensions'].items(): check(sha(source/relative) == expected, 'pins/extension/'+relative)
    for path, expected in manifest['inputs'].items(): check(sha(path) == expected, 'pins/input/'+path)
    for key, expected in summary['source_dependencies'].items():
        scope, relative = key.split(':', 1)
        check(scope in ('extension', 'dependency') and sha((source if scope == 'extension' else dependency)/relative) == expected,
            'pins/loaded_source/'+key)
    archive_path = 'docs/implementation/reports/evidence/decoder-gradient-trace-20261002/manifest.json'
    archive = read(ROOT/archive_path)
    published = subprocess.check_output(['git', 'show', TESTED_BASE+':'+archive_path], cwd=ROOT)
    check(sha(ROOT/archive_path) == hashlib.sha256(published).hexdigest(), 'pins/prior_archive_at_published_base')
    # The preceding packager explicitly maps original absolute paths to members.
    def previous(path):
        path = Path(path)
        mapping = archive.get('original_artifact_archive_paths', {})
        member = mapping.get(str(path)) if mapping else None
        if member is None:
            member = 'validation/'+str(path.relative_to(PRIOR))
        record = archive['members'][member]
        check(sha(path) == record['sha256'] and path.stat().st_size == record['bytes'], 'pins/prior_artifact/'+member)
        return read(path)
    before_summary = previous(PRIOR/'smoke-r1/results/summary.json')
    before_runs = {row['arm']: row for row in before_summary['runs']}
    before_audit = previous(PRIOR/'independent-audit.json')
    check(before_audit['complete'] and not before_audit['findings'] and before_audit['audit_source_sha256'] == HELPER_SHA,
        'pins/prior_independent_audit_and_program')
    corpus, donor, embeddings = (read(manifest[name]) for name in ('paragraphs', 'donor', 'embeddings'))
    vectors = {row['input_id']: row['vector'] for row in embeddings['rows']}
    expected_arms = {recipe['name']+'-'+str(seed) for recipe in plan['arms'] for seed in plan['seed_order']}
    check(summary['complete'] is True and len(summary['runs']) == 4 and {row['arm'] for row in summary['runs']} == expected_arms
        and summary['dimensions_actually_trained'] == [384] and summary['encoder_executed'] is False
        and summary['encoder_context_changed'] is False and summary['output_limit_changed'] is False
        and summary['downloads_performed'] is False and summary['bridge_names'] == []
        and summary['legal_ir_evaluate_provers'] is False, 'scope/complete_fixed384_exposed_experiment')
    old.authority(summary, 'scope/summary')
    initial, capacity, arms = set(), set(), []
    comparisons = {}
    for run in summary['runs']:
        arm = run['arm']; folder = results/arm; recipe = run['recipe']; report = read(folder/'training.json')
        reference_arm = 'balanced_all-'+str(run['seed']); reference_folder = PRIOR/'smoke-r1/results'/reference_arm
        before = previous(reference_folder/'training.json'); is_control = recipe['transition_schedule'] == 'unchanged'
        check(report == run['training'] and recipe in plan['arms'] and run['seed'] in plan['seed_order']
            and recipe['count_exposure'] == report['count_exposure'] == 'balanced_all' and recipe['guide_boundary'] is False
            and report['cardinality_weight'] == .25 and report['config'] == before['config']
            and (report['optimizer_steps'], report['valid_target_token_presentations'], report['row_presentations']) == (340, 225840, 2440)
            and report['stopped_reason'] == 'epochs_completed' and run['budget_completed'] is True, arm+'/fixed_recipe_and_complete_budget')
        initial.add(report['initial_weights_sha256']); capacity.add(run['trainable_parameter_count'])
        invariant_keys = ('initial_weights_sha256', 'training_rows_sha256', 'validation_rows_sha256', 'training_references_sha256',
            'validation_references_sha256', 'codec_sha256', 'frozen_parameter_names', 'baseline', 'curriculum',
            'count_selector_initial', 'count_selector_final', 'committed_count_batch_ids_sha256',
            'count_training_presentations_by_class', 'count_mean_loss_exposure_by_class')
        check(all(prior.subset_equal(report[key], before[key]) for key in invariant_keys), arm+'/unchanged_initial_data_curriculum_and_count_sampling')
        if is_control:
            keys = ('selected_weights_sha256', 'last_complete_attempt_weights_sha256', 'selected_epoch',
                'selected', 'last_complete_attempt', 'history', 'stage_reports', 'gradient_norms')
            check(all(prior.subset_equal(report[key], before[key]) for key in keys), arm+'/exact_archived_epoch_stage_and_final_control')
            strip = lambda step: {key: value for key, value in step.items() if key != 'captured_event_sha256'}
            check([strip(row) for row in report['gradient_trace']['steps']] == [strip(row) for row in before['gradient_trace']['steps']],
                arm+'/exact_archived_per_step_scalar_and_postclip_module_control')
        selection = old.audit_selection(report, arm); exposure = prior.exposure(report, corpus, vectors, arm)
        check(report['optimizer_instance_count'] == 1 and report['optimizer_reinitialized_between_stages'] is False, arm+'/continuous_optimizer')
        for first, second in zip(report['stage_reports'], report['stage_reports'][1:]):
            check(first['optimizer_state_end'] == second['optimizer_state_start'] and first['optimizer_step_end'] == second['optimizer_step_start'],
                arm+'/continuous_adam/'+second['name'])
        for role in ('selected', 'last-attempt'):
            state = read(folder/(role+'-state.json'))
            expected = report['selected_weights_sha256'] if role == 'selected' else report['last_complete_attempt_weights_sha256']
            check(state['role'] == role and state['recipe'] == recipe and state['weights_sha256'] == digest(state['model_state'])
                and state['tensor_sha256'] == old.tensor_digest(state['model_state']) == expected, arm+'/'+role+'/strict_state_identity')
            check(state['selected'] == (role == 'selected' or report['last_complete_attempt_is_selected'])
                and state['optimizer_resumable'] is False and state['architecture']['guide_boundary'] is False
                and state['architecture']['decoder_reference_count_access'] is False, arm+'/'+role+'/private_and_target_free_generation')
            if is_control: gradient.compare_states(state, previous(reference_folder/(role+'-state.json')), arm+'/'+role)
            old.authority(state, arm+'/'+role)
            old.audit_projections(state['model_state'], donor, report['frozen_parameter_names'], arm+'/'+role)
            stored = report['selected'] if role == 'selected' else report['last_complete_attempt']
            predictions = read(folder/('selected-predictions.json' if role == 'selected' else 'last-attempt-predictions.json'))
            for label, split, kind in prior.LABELS:
                value = read(folder/role/('evaluation-'+label+'.json')); refs = corpus[split]
                old.audit_execution(value, refs, vectors, arm+'/'+role+'/'+label, kind)
                old.audit_fidelity(value['source_fidelity'], refs, value['predictions'], donor['codec'], arm+'/'+role+'/'+label)
                prior.probabilities(value['source_count'], value['hypothetical_boundary_diagnostics'], refs, arm+'/'+role+'/'+label)
                compact = dict(numerical=value['report'], source_count=value['source_count'], timing=value['timing'],
                    execution=value['execution'], hypothetical_boundary_diagnostics=value['hypothetical_boundary_diagnostics'],
                    source_fidelity={key: item for key, item in value['source_fidelity'].items() if key != 'rows'})
                check(compact == run['postfit'][role][label], arm+'/'+role+'/'+label+'/complete_summary_binding')
                if label == 'validation':
                    check(value['predictions'] == predictions and value['report']['metrics'] == stored['numerical']
                        and compact['source_fidelity'] == stored['fidelity'] and value['source_count'] == stored['source_count'],
                        arm+'/'+role+'/selected_or_diagnostic_replay_exact')
                if is_control:
                    original = previous(reference_folder/role/('evaluation-'+label+'.json'))
                    check(value['predictions'] == original['predictions'] and value['report']['metrics'] == original['report']['metrics']
                        and value['source_fidelity'] == original['source_fidelity'] and value['source_count'] == original['source_count']
                        and value['hypothetical_boundary_diagnostics'] == original['hypothetical_boundary_diagnostics'],
                        arm+'/'+role+'/'+label+'/exact_previous_control_readout')
        trace = gradient.audit_trace(run, folder, before, corpus['train'], vectors, donor)
        schedule = audit_schedule(run, folder)
        comparisons[(run['seed'], recipe['transition_schedule'])] = run
        arms.append(dict(arm=arm, prior_balanced_arm=reference_arm, control=is_control,
            selected_epoch=report['selected_epoch'], selection=selection, exposure=exposure, trace=trace, schedule=schedule,
            selected={key: report['selected'][key] for key in ('numerical', 'fidelity')},
            last_attempt={key: report['last_complete_attempt'][key] for key in ('numerical', 'fidelity')},
            gradient_norms=report['gradient_norms'], training_call_seconds=report['elapsed_seconds'], whole_arm_seconds=run['elapsed_seconds']))
    check(len(initial) == len(capacity) == 1, 'scope/identical_initial_weights_and_parameter_count')
    for seed in plan['seed_order']:
        control = comparisons[(seed, 'unchanged')]['training']; candidate = comparisons[(seed, 'first_expansion_ramp20')]['training']
        clean = lambda row: {key: value for key, value in row.items() if key != 'captured_event_sha256'}
        check([clean(row) for row in candidate['gradient_trace']['steps'][:40]] ==
            [clean(row) for row in control['gradient_trace']['steps'][:40]], 'paired/'+str(seed)+'/identical_before_first_expansion')
    resource, child = read(attempt/'resources-final.json'), read(attempt/'child-exit.json'); record = resource['record']
    check(resource['status'] == record['status'] == 'released' and record['artifacts_durable_asserted'] is True
        and child['returncode'] == 0 and child['leader_reaped'] is True
        and record['last_usage']['group_rss']['live_processes'] == 0, 'resources/durable_success_and_release')
    check(record['cpu_slots'] == record['child_process_slots'] == 1 and record['memory_mb'] == 4096
        and record['final_accounting']['limit_bytes'] == 140000000000
        and record['final_accounting']['charged_bytes'] <= 140000000000 and record['attempt_exceeded_reservation'] is False,
        'resources/unchanged_caps_one_process')
    changed = set(subprocess.check_output(['git', 'diff', '--name-only', TESTED_BASE, args.published_main], cwd=ROOT, text=True).splitlines())
    loaded = {key.split(':', 1)[1] for key in summary['source_dependencies']}
    resources = {'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py',
        'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py'}
    check(not changed & (loaded | resources), 'publication/disjoint_remote_changes')
    compatibility = read(RUN/'resource-compatibility.json')
    old_compatibility = previous(PRIOR/'resource-compatibility.json')
    check(compatibility['prior_compatibility_sha256'] == sha(PRIOR/'resource-compatibility.json')
        and compatibility['prior_resource_audit_sha256'] == old_compatibility['prior_resource_audit_sha256']
        and compatibility['root_admission_path_unchanged'] is True and compatibility['nested_lease_exercised'] is False
        and compatibility['ledger_mutated'] is False and compatibility['storage_cap_changed'] is False,
        'resources/prior_root_admission_binding_no_nested_lease_claim')
    for relative in resources:
        published = subprocess.check_output(['git', 'show', args.published_main+':'+relative], cwd=ROOT)
        check(hashlib.sha256(published).hexdigest() == compatibility['published_owner_sha256'][relative], 'resources/published_owner/'+relative)
    check(sha(dependency/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py')
        == compatibility['executed_historical_owner']['sha256'] and
        sha(dependency/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py')
        == compatibility['executed_scheduler']['sha256'], 'resources/historical_executed_owners_exact')
    tests = []
    for path in sorted(RUN.glob('*tests*.xml')):
        suites = list(ET.parse(path).getroot().iter('testsuite'))
        counts = {key: sum(int(item.get(key, 0)) for item in suites) for key in ('tests', 'failures', 'errors', 'skipped')}
        tests.append(dict(path=str(path), sha256=sha(path), **counts))
    check(tests and all(row['failures'] == row['errors'] == 0 for row in tests), 'tests/recorded_suites_pass')
    check(sha(__file__) == source_sha and sha(HELPER) == HELPER_SHA, 'pins/audit_programs_unchanged')
    groups = {}
    for item in checks:
        bucket = groups.setdefault(item['check'].split('/', 1)[0], dict(passed=0, failed=0))
        bucket['passed' if item['passed'] else 'failed'] += 1
    result = dict(schema='independent-decoder-transition-ramp-audit/v1', complete=True,
        created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        verdict='blocking_findings' if findings else 'no_blocking_correctness_issue_found', findings=findings,
        checked_count=len(checks), failed_check_count=len(findings), checks=groups,
        all_pins_match=all(row['passed'] for row in checks if row['check'].startswith('pins/')),
        arms=arms, tests=tests, test_count_note='Overlapping test receipts are not additive.',
        resource_status=resource['status'], resource_compatibility=compatibility,
        artifacts=artifacts, audit_source_sha256=source_sha, audit_helper_sha256=HELPER_SHA,
        publication_compatibility=dict(tested_base=TESTED_BASE, inspected_main=args.published_main,
            changed_path_count=len(changed), loaded_or_resource_overlap=sorted(changed & (loaded | resources))),
        limitations=['Previously exposed authored development, two seeds; no fresh holdout or natural-statute generalization.',
            'Controls compare every archived scalar step, epoch metrics, stage Adam summaries, final tensors and postfit controls; prior intermediate model tensors were not all archived.',
            'Top-K gradient replay diagnoses selected tail events, not a representative sample or global causal explanation.',
            'Standard-library audit verifies recorded delta-summary arithmetic; it does not execute Adam to regenerate all measured parameter deltas.',
            'Only384D cached inputs are trained; original8D teacher and768D lineage unchanged.',
            'No model/native execution by auditor, native/Lake qualification, checkpoint promotion or convergence proof.'],
        model_executed_by_auditor=False, native_executed_by_auditor=False, **{key: False for key in old.AUTHORITY})
    with args.output.open('xb') as stream:
        stream.write(json.dumps(result, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False).encode()+b'\n')
    print(json.dumps(dict(path=str(args.output), sha256=sha(args.output), bytes=args.output.stat().st_size,
        verdict=result['verdict'], checks=len(checks), findings=findings)))
    return int(bool(findings))


if __name__ == '__main__':
    raise SystemExit(main())
