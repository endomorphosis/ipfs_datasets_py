"""Read-only arithmetic/provenance audit of bounded gradient-tail replay.

Uses SHA-pinned standard-library evidence helpers. Never imports Torch, runs a
model, grants native authority, or repairs evidence. Output must be a new file.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import math
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from dataclasses import dataclass

sys.dont_write_bytecode = True
ROOT = Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN = Path(__file__).resolve().parent
PRIOR = ROOT/'workspace/test-logs/decoder-count-exposure-20261002'
HELPER = PRIOR/'independent_audit.py'
HELPER_SHA = 'b7eab0337a44328e140947ab0964a3265692e1fad74d3a560c6cd5495d8c3bf3'
TESTED_BASE = 'd71ef66bee3b99777ed2d03d1bcd9ffd24b48ea1'
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA:
    raise ValueError('prior arithmetic audit helper differs from published bytes')
spec = importlib.util.spec_from_file_location('_gradient_trace_prior_audit', HELPER)
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
old = prior.old
read, check, sha, digest, raw = old.read, old.check, old.sha, old.digest, old.raw
checks, findings, artifacts = old.checks, old.findings, old.artifacts
artifacts[str(HELPER)] = dict(sha256=HELPER_SHA, bytes=HELPER.stat().st_size)


@dataclass(frozen=True)
class Tensor:
    dtype: str
    shape: tuple
    values: object

    def bytes(self):
        formats = {'torch.float32': 'f', 'torch.float64': 'd', 'torch.int64': 'q',
            'torch.int32': 'i', 'torch.uint8': 'B', 'torch.bool': '?'}
        if self.dtype not in formats:
            raise ValueError('unknown tagged tensor dtype')
        values = list(old.flat(self.values))
        if len(values) != math.prod(self.shape):
            raise ValueError('tagged tensor element count differs')
        if any(type(value) not in (int, float, bool) or not math.isfinite(value) for value in values):
            raise ValueError('nonfinite or nonnumeric tagged tensor')
        return b''.join(struct.pack('<'+formats[self.dtype], value) for value in values)


def unpack(value, depth=0):
    """Decode only the closed, bounded JSON data grammar; never execute code."""
    if type(value) is not dict or depth > 32:
        raise ValueError('invalid tagged packet nesting')
    kind = value.get('kind')
    if kind == 'scalar' and set(value) == {'kind', 'value'}:
        item = value['value']
        if item is None or type(item) in (str, bool, int) or type(item) is float and math.isfinite(item):
            return item
    if kind in ('tuple', 'list') and set(value) == {'kind', 'items'}:
        if type(value['items']) is not list or len(value['items']) > 1000000:
            raise ValueError('invalid tagged sequence')
        items = [unpack(item, depth+1) for item in value['items']]
        return tuple(items) if kind == 'tuple' else items
    if kind == 'dict' and set(value) == {'kind', 'pairs'}:
        if type(value['pairs']) is not list or len(value['pairs']) > 65536:
            raise ValueError('invalid tagged mapping')
        result = {}
        for pair in value['pairs']:
            if type(pair) is not list or len(pair) != 2 or type(pair[0]) not in (str, int) or pair[0] in result:
                raise ValueError('invalid or duplicate tagged dictionary key')
            result[pair[0]] = unpack(pair[1], depth+1)
        return result
    if kind == 'tensor' and set(value) == {'kind', 'dtype', 'shape', 'values'}:
        geometry = value['shape']
        if type(geometry) is not list or len(geometry) > 4 or any(type(n) is not int or not 0 <= n <= 1000000 for n in geometry) or math.prod(geometry) > 1000000:
            raise ValueError('invalid tagged tensor geometry')
        tensor = Tensor(value['dtype'], tuple(geometry), value['values'])
        tensor.bytes()
        return tensor
    raise ValueError('unknown or nonclosed tagged snapshot')


def wire_digest(value):
    if isinstance(value, Tensor):
        return dict(kind='tensor', dtype=value.dtype, shape=list(value.shape), sha256=hashlib.sha256(value.bytes()).hexdigest())
    if type(value) is dict:
        pairs = [[key, wire_digest(item)] for key, item in value.items()]
        pairs.sort(key=lambda pair: raw(pair[0]))
        return dict(kind='dict', pairs=pairs)
    if type(value) in (list, tuple):
        return dict(kind='tuple' if type(value) is tuple else 'list', items=[wire_digest(item) for item in value])
    return dict(kind='scalar', value=value)


def state_digest(value):
    return digest(wire_digest(value))


def model_digest(value):
    result = hashlib.sha256()
    for name, tensor in sorted(value.items()):
        result.update(raw([name, tensor.dtype, list(tensor.shape)])); result.update(tensor.bytes())
    return result.hexdigest()


def tensor_bytes_in(value):
    if isinstance(value, Tensor):
        return len(value.bytes())
    if type(value) is dict:
        return sum(tensor_bytes_in(item) for item in value.values())
    if type(value) in (tuple, list):
        return sum(tensor_bytes_in(item) for item in value)
    return 0


def reference_tokens(value):
    text = lambda item: json.dumps(item, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)
    if type(value) is dict:
        output = [('{', .25)]
        for index, key in enumerate(sorted(value)):
            if index: output.append((',', .25))
            output.extend(((text(key), .25), (':', .25)))
            output.extend(reference_tokens(value[key]))
        return output+[('}', .25)]
    if type(value) is list:
        if not value: return [('[', 1.), (']', 1.)]
        output = [('[', .25)]
        for index, child in enumerate(value):
            if index: output.append((',', .25))
            output.extend(reference_tokens(child))
        return output+[(']', .25)]
    return [(text(value), 4.)]


def audit_attribution(report, event, label):
    check(report['complete'] is True and all(report[key] is True for key in ('full_step_exact', 'full_loss_exact',
        'preclip_norm_exact', 'clipped_gradient_digest_exact', 'poststep_model_digest_exact', 'poststep_optimizer_digest_exact',
        'template_model_unchanged')), label+'/exact_recorded_combined_step_required')
    check(report['event_sha256'] == event['event_sha256'] and report['optimizer_step_before'] == event['optimizer_step_before']
        and report['losses'] == event['losses'] and report['preclip_norm'] == event['preclip_norm']
        and report['decoder_row_ids'] == event['decoder_row_ids'] and report['count_row_ids'] == event['count_row_ids'],
        label+'/replay_exact_event_binding')
    check(report['optimizer_steps_on_private_copy'] == 1 and report['used_for_selection'] is False
        and report['live_training_modified'] is False and report['generation_executed'] is False
        and report['frozen_reconstruction_branch'] == dict(requires_grad=False, gradient_norm=0., cosine=None),
        label+'/private_diagnostic_and_zero_reconstruction_gradient')
    old.authority(report, label)
    values = report['attribution']; seen = set(); combined_sq = token_sq = count_sq = dots = 0.
    check(report['attribution_valid'] == values['branches_reconcile']
        and values['status'] == ('reconciled' if values['branches_reconcile'] else 'unreconciled_do_not_claim_additive_attribution'),
        label+'/explicit_additive_attribution_validity')
    check(values['count_gradient_coefficient'] == .25 and values['zero_norm_cosine'] is None
        and math.isfinite(values['max_absolute_reconciliation_error']) and values['max_absolute_reconciliation_error'] >= 0
        and values['reconciliation_atol'] == values['reconciliation_rtol'] == 1e-4, label+'/explicit_attribution_tolerance')
    for name, group in values['groups'].items():
        a, b, c, dot = (group[key] for key in ('weighted_token_ce_norm', 'quarter_weight_count_ce_norm', 'combined_norm', 'weighted_branch_dot'))
        check(all(math.isfinite(value) for value in (a, b, c, dot)) and min(a, b, c) >= 0
            and group['raw_count_ce_norm'] == b/.25, label+'/'+name+'/finite_correctly_weighted_branch_norms')
        expected_cosine = dot/(a*b) if a*b else None
        check(group['weighted_branch_cosine'] == expected_cosine and (expected_cosine is None or abs(expected_cosine) <= 1+1e-12),
            label+'/'+name+'/cosine_and_zero_norm_handling')
        parameters = group['parameters']
        check(len(parameters) == len(set(parameters)) and not seen.intersection(parameters)
            and set(parameters) <= set(event['trainable_parameter_names']), label+'/'+name+'/nonoverlapping_trainable_modules')
        seen.update(parameters)
        squared = a*a+b*b+2*dot
        count = sum(math.prod(event['model_state_dict'][key].shape) for key in parameters)
        bound = values['max_absolute_reconciliation_error']*math.sqrt(count)
        check(squared >= -1e-10 and abs(c-math.sqrt(max(0., squared))) <= bound+1e-9*max(1., c),
            label+'/'+name+'/independent_norm_dot_reconciliation')
        combined_sq += c*c
        token_sq += a*a; count_sq += b*b; dots += dot
    aggregate = values['global_summary']
    global_token, global_count = math.sqrt(token_sq), math.sqrt(count_sq)
    for key, expected in dict(combined_norm=math.sqrt(combined_sq), weighted_token_ce_norm=global_token,
        quarter_weight_count_ce_norm=global_count, raw_count_ce_norm=global_count/.25, weighted_branch_dot=dots).items():
        check(math.isclose(aggregate[key], expected, rel_tol=1e-12, abs_tol=1e-12), label+'/global_'+key)
    cosine = dots/(global_token*global_count) if global_token*global_count else None
    check(aggregate['weighted_branch_cosine'] is None if cosine is None else math.isclose(
        aggregate['weighted_branch_cosine'], cosine, rel_tol=1e-12, abs_tol=1e-12), label+'/global_branch_cosine')
    check(math.isclose(math.sqrt(combined_sq), event['preclip_norm'], rel_tol=3e-6, abs_tol=1e-6),
        label+'/float64_module_norms_match_recorded_float32_global_norm')
    return dict(step=event['optimizer_step_before'], norm=event['preclip_norm'], groups=values['groups'], global_summary=aggregate,
        branches_reconcile=values['branches_reconcile'], max_absolute_reconciliation_error=values['max_absolute_reconciliation_error'])


def audit_trace(run, folder, previous_report, training_rows, vectors, donor):
    report = run['training']; trace = report['gradient_trace']; label = run['arm']+'/trace'
    configuration = dict(enabled=True, threshold=50., top_k=2, module_summaries=True)
    check(trace['configuration'] == configuration and trace['additional_backwards_in_live_path'] is False
        and trace['additional_preclip_norm_calls'] is False and trace['observer_arithmetic'] == 'detached_postclip_only',
        label+'/bounded_observation_only_configuration')
    steps = trace['steps']; committed = [row for row in steps if row['committed']]
    check(len(steps) == len(committed) == report['optimizer_steps'] == 340
        and [row['optimizer_step_before'] for row in committed] == list(range(340))
        and trace['uncommitted_event_summaries'] == [], label+'/complete_contiguous_committed_stream')
    lookup = {row['id']: row for row in training_rows}
    numerical = {identity: dict(id=identity, source_text=row['source_text'], target_ids=row['target_ids'], input=vectors[identity])
        for identity, row in lookup.items()}
    weights = {}
    for identity, row in lookup.items():
        tokens = reference_tokens(row['target']); weights[identity] = [0.]+[weight for _, weight in tokens]+[1.]
        positions = {token: index for index, token in enumerate(donor['codec']['target_vocabulary'])}
        check([1]+[positions[token] for token, _ in tokens]+[2] == row['target_ids'], label+'/complete_weighted_reference/'+identity)
    expected_coordinates = []
    epoch = 0
    for stage in report['curriculum']:
        for stage_epoch in range(1, stage['epochs']+1):
            epoch += 1
            for offset in range(0, len(stage['training_ids']), report['config']['batch_size']):
                expected_coordinates.append((stage, epoch, stage_epoch, min(report['config']['batch_size'], len(stage['training_ids'])-offset)))
    sampler = prior.SelectorReplay(training_rows, run['seed']) if report['count_exposure'] == 'balanced_all' else None
    selector_states = {}; count_stream = hashlib.sha256(); epoch_ids = {}; class_counts = Counter(); presentations = tokens_seen = 0
    for row, (stage, epoch, stage_epoch, size) in zip(committed, expected_coordinates):
        step = row['optimizer_step_before']; path = label+'/step-'+str(step)
        decoder_ids, count_ids = row['decoder_row_ids'], row['count_row_ids']
        check(row['stage'] == stage['name'] and row['epoch'] == epoch and row['stage_epoch'] == stage_epoch
            and len(decoder_ids) == len(count_ids) == size and len(set(decoder_ids)) == size
            and set(decoder_ids) <= set(stage['training_ids']) and set(count_ids) <= set(lookup), path+'/exact_training_batch_scope')
        epoch_ids.setdefault((stage['name'], epoch), []).extend(decoder_ids)
        expected_count = decoder_ids if sampler is None else sampler.take(size)
        check(count_ids == expected_count, path+'/count_ids_exact_current_or_balanced_source_stream')
        selector_states[step] = None if sampler is None else sampler.snapshot()
        count_stream.update(raw(count_ids)); presentations += size
        tokens_seen += sum(len(lookup[identity]['target_ids'])-1 for identity in decoder_ids)
        class_counts.update(str(lookup[identity]['clause_count']) for identity in count_ids)
        losses = row['losses']; coefficient = report['config']['reconstruction_weight']
        expected_loss = losses['weighted_token_ce']+coefficient*losses['mse']+.25*losses['count_ce']
        check(set(losses) == {'weighted_token_ce', 'token_ce', 'count_ce', 'mse', 'objective'}
            and all(math.isfinite(value) and value >= 0 for value in losses.values())
            and math.isclose(losses['objective'], expected_loss, rel_tol=3e-7, abs_tol=1e-8), path+'/finite_original_objective')
        check(row['learning_rates'] and all(type(value) in (float, int) and math.isfinite(value) and value > 0 for value in row['learning_rates'])
            and math.isfinite(row['preclip_norm']) and row['preclip_norm'] >= 0, path+'/finite_rate_and_norm')
        modules = row['postclip_module_summaries']
        observed_norm = math.sqrt(sum(value['postclip_l2_norm']**2 for value in modules.values()))
        expected_norm = row['preclip_norm']*min(1., report['config']['max_grad_norm']/(row['preclip_norm']+1e-6))
        check(all(value['parameter_count'] >= value['gradients_none'] >= 0 and value['gradient_elements'] >= 0
            and math.isfinite(value['postclip_l2_norm']) and value['postclip_l2_norm'] >= 0 for value in modules.values())
            and math.isclose(observed_norm, expected_norm, rel_tol=4e-6, abs_tol=1e-7), path+'/postclip_norm_consistency')
    for stage in report['curriculum']:
        for (name, epoch), identities in epoch_ids.items():
            if name == stage['name']:
                check(Counter(identities) == Counter(stage['training_ids']), label+'/'+name+'/'+str(epoch)+'/every_decoder_row_once')
    norms = [row['preclip_norm'] for row in committed]
    check(sum(norms)/len(norms) == report['gradient_norms']['mean_preclip_norm']
        and max(norms) == report['gradient_norms']['max_preclip_norm']
        and sum(value > report['gradient_norms']['limit'] for value in norms) == report['gradient_norms']['norm_exceeded_limit_steps'],
        label+'/independent_complete_norm_aggregates')
    check(presentations == 2440 and tokens_seen == 225840 and dict(class_counts) == report['count_training_presentations_by_class']
        and count_stream.hexdigest() == report['committed_count_batch_ids_sha256'], label+'/every_recorded_batch_budget_and_digest')
    qualifying = sorted([row for row in committed if row['preclip_norm'] > configuration['threshold']],
        key=lambda row: (row['preclip_norm'], -row['optimizer_step_before']), reverse=True)
    expected = qualifying[:configuration['top_k']]
    captured = trace['captured_event_summaries']
    check([row['optimizer_step_before'] for row in captured] == [row['optimizer_step_before'] for row in expected],
        label+'/independent_strict_top_k_with_earliest_ties')
    replay_summary = run['gradient_replays']
    if type(replay_summary) is not dict or not {'complete', 'event_count', 'events'} <= set(replay_summary):
        raise ValueError('gradient driver replay summary contract differs')
    check(replay_summary['complete'] is True and replay_summary['event_count'] == len(expected)
        and len(replay_summary['events']) == len(expected), label+'/every_retained_event_replayed')
    items = {row['event_sha256']: row for row in replay_summary['events']}
    check(set(items) == {row['event_sha256'] for row in captured}, label+'/exact_retained_event_inventory')
    def receipt(record):
        path = Path(record['path'])
        check(path.resolve().is_relative_to(folder.resolve()) and sha(path) == record['sha256']
            and path.stat().st_size == record['bytes'], label+'/receipt/'+path.name)
        return read(path)
    event_results = []; retained_bytes = 0
    for capture, expected_step in zip(captured, expected):
        item = items[capture['event_sha256']]; packet = receipt(item['packet_receipt']); observation = receipt(item['replay_receipt'])
        check(set(packet) == {'schema', 'event'} and packet['schema'] == 'decoder-gradient-event-wire/v1', label+'/closed_packet_schema')
        event = unpack(packet['event']); step = event['optimizer_step_before']; path = label+'/event-'+str(step)
        check(event['event_sha256'] == state_digest({key: value for key, value in event.items() if key != 'event_sha256'})
            == capture['event_sha256'] and all(event[key] == value for key, value in capture.items()), path+'/independent_typed_event_digest')
        check(event['schema'] == 'decoder-gradient-event/v1' and event['complete'] is True and event['committed'] is True
            and event['preclip_norm'] > 50 and all(event[key] == expected_step[key] for key in
                ('optimizer_step_before', 'epoch', 'stage', 'stage_epoch', 'preclip_norm', 'decoder_row_ids', 'count_row_ids',
                    'learning_rates', 'losses', 'postclip_module_summaries')), path+'/exact_committed_scalar_record')
        old.authority(event, path)
        check(event['config'] == report['config'] and event['cardinality_weight'] == .25 and event['strategy'] == 'semantic_fields'
            and event['count_exposure'] == report['count_exposure'] and event['input_transform'] == donor['input_transform']
            and event['codec_sha256'] == digest(donor['codec']), path+'/unchanged_numerical_configuration')
        check(event['decoder_batch_sha256'] == digest([numerical[key] for key in event['decoder_row_ids']])
            and event['count_batch_sha256'] == digest([numerical[key] for key in event['count_row_ids']])
            and event['token_weights_sha256'] == digest({key: weights[key] for key in event['decoder_row_ids']})
            and event['count_targets'] == [lookup[key]['clause_count']-1 for key in event['count_row_ids']],
            path+'/exact_full_training_batches_targets_and_weights')
        check(event['source_selector_snapshot'] == selector_states[step], path+'/independent_balanced_sampler_state')
        check(model_digest(event['model_state_dict']) == event['pre_step_model_sha256']
            and state_digest(event['optimizer_state_dict']) == event['pre_step_optimizer_sha256'], path+'/pre_step_model_and_adam_byte_digests')
        names = event['trainable_parameter_names']; groups = event['optimizer_state_dict']['param_groups']
        indices = [index for group in groups for index in group['params']]
        check(event['optimizer_class'] == 'AdamW' and [group['lr'] for group in groups] == event['learning_rates']
            and len(names) == len(set(names)) and set(names) == set(event['model_state_dict'])-set(report['frozen_parameter_names'])
            and indices == list(range(len(names))), path+'/named_adam_order_and_group_rates')
        for index, moments in event['optimizer_state_dict']['state'].items():
            check(type(index) is int and index in indices and moments['step'].values == step
                and moments['exp_avg'].shape == moments['exp_avg_sq'].shape == event['model_state_dict'][names[index]].shape,
                path+'/adam_moment_geometry_and_step/'+str(index))
        check(event['captured_tensor_bytes'] == tensor_bytes_in(event), path+'/exact_retained_tensor_byte_count')
        retained_bytes += event['captured_tensor_bytes']
        check(item['full_step_exact'] is True and item['branches_reconcile'] == observation['attribution']['branches_reconcile']
            and item['optimizer_steps_on_private_copy'] == observation['optimizer_steps_on_private_copy'] == 1
            and item['replay_elapsed_seconds'] == observation['elapsed_seconds'], path+'/driver_replay_summary_binding')
        event_results.append(audit_attribution(observation, event, path))
    check(retained_bytes == trace['retained_tensor_bytes'] and trace['peak_snapshot_tensor_bytes'] >= retained_bytes,
        label+'/bounded_retained_snapshot_bytes')
    check(replay_summary['uncommitted'] == [] and replay_summary['optimizer_steps_on_private_copies'] == len(expected)
        and replay_summary['replay_elapsed_seconds'] == sum(item['replay_elapsed_seconds'] for item in replay_summary['events']),
        label+'/private_replay_budget_and_time_totals')
    check(trace['total_observer_seconds'] == trace['observer_elapsed_seconds']+trace['initialization_seconds']+trace['report_construction_seconds']
        and trace['observer_elapsed_seconds'] >= trace['capture_seconds'] >= 0
        and report['elapsed_seconds'] >= trace['total_observer_seconds'], label+'/scoped_observer_timings')
    return dict(qualifying_event_count=len(qualifying), retained_event_count=len(expected),
        selected_steps=[row['optimizer_step_before'] for row in expected], all_top_k_verified=True,
        captures_created=trace['qualifying_captures_created'], displaced_captures=trace['displaced_captures'],
        observer_elapsed_seconds=trace['observer_elapsed_seconds'], capture_seconds=trace['capture_seconds'],
        retained_tensor_bytes=retained_bytes, events=event_results)


def compare_states(candidate, reference, label):
    actual, expected = candidate['model_state'], reference['model_state']
    same = set(actual) == set(expected) and all(old.tensor_bytes(value) == old.tensor_bytes(expected[key])
        for key, value in actual.items())
    check(same and candidate['tensor_sha256'] == reference['tensor_sha256'], label+'/exact_all_tensor_bytes')
    return same


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', default='smoke-r1')
    parser.add_argument('--output', type=Path, default=RUN/'independent-audit.json')
    parser.add_argument('--published-main', default=TESTED_BASE)
    args = parser.parse_args(); attempt = RUN/args.attempt; results = attempt/'results'
    required = ('results/summary.json', 'results/sealed-recipe.json', 'resources-final.json', 'command.json', 'child-exit.json')
    if not all((attempt/item).is_file() for item in required):
        print(json.dumps(dict(status='waiting_for_complete_durable_results'))); return 3
    if args.output.exists():
        raise FileExistsError('audit output must be fresh')
    source_sha = sha(__file__)
    command = read(attempt/'command.json'); argv = command['command']
    argument = lambda name: Path(argv[argv.index('--'+name)+1])
    manifest = read(argument('manifest')); plan = read(argument('plan'))
    source, dependency = argument('extension-root'), argument('dependency-root')
    summary = read(results/'summary.json'); sealed = read(results/'sealed-recipe.json')
    check(sealed['plan'] == plan and sealed['manifest'] == manifest and sha(argument('plan')) == manifest['plan_sha256'],
        'pins/sealed_recipe')
    for relative, expected in manifest['extensions'].items():
        check(sha(source/relative) == expected, 'pins/extension/'+relative)
    for path, expected in manifest['inputs'].items():
        check(sha(path) == expected, 'pins/input/'+path)
    for scoped, expected in summary['source_dependencies'].items():
        scope, relative = scoped.split(':', 1)
        check(scope in ('dependency', 'extension') and sha((dependency if scope == 'dependency' else source)/relative) == expected,
            'pins/loaded_producer/'+scoped)
    archive_relative = 'docs/implementation/reports/evidence/decoder-count-exposure-20261002/manifest.json'
    archive = read(ROOT/archive_relative)
    published_archive = subprocess.check_output(['git', 'show', TESTED_BASE+':'+archive_relative], cwd=ROOT)
    check(sha(ROOT/archive_relative) == hashlib.sha256(published_archive).hexdigest(), 'pins/prior_archive_published_binding')
    def previous(path):
        path = Path(path); member = 'validation/'+str(path.relative_to(PRIOR)); receipt = archive['members'][member]
        check(sha(path) == receipt['sha256'] and path.stat().st_size == receipt['bytes'], 'pins/prior_artifact/'+member)
        return read(path)
    check(sha(HELPER) == archive['members']['validation/independent_audit.py']['sha256'],
        'pins/prior_helper_published_binding')
    previous_summary = previous(PRIOR/'smoke-r2/results/summary.json')
    previous_runs = {row['arm']: row for row in previous_summary['runs']}
    prior_audit = previous(PRIOR/'independent-audit.json')
    check(prior_audit['complete'] and not prior_audit['findings'], 'pins/prior_completed_independent_audit')
    corpus, donor, embeddings = (read(manifest[key]) for key in ('paragraphs', 'donor', 'embeddings'))
    vectors = {row['input_id']: row['vector'] for row in embeddings['rows']}
    old.authority(summary, 'scope/summary')
    check(summary['complete'] is True and len(summary['runs']) == 4 and summary['dimensions_actually_trained'] == [384]
        and summary['encoder_executed'] is False and summary['encoder_context_changed'] is False
        and summary['output_limit_changed'] is False and summary['downloads_performed'] is False
        and summary['bridge_names'] == [] and summary['legal_ir_evaluate_provers'] is False, 'scope/four_exposed_384_arms_no_native')
    expected_arms = {recipe['name']+'-'+str(seed) for recipe in plan['arms'] for seed in plan['seed_order']}
    check({row['arm'] for row in summary['runs']} == expected_arms == set(previous_runs), 'scope/all_predeclared_arms')
    initial, capacities, arm_results = set(), set(), []
    for run in summary['runs']:
        arm = run['arm']; folder = results/arm; old_folder = PRIOR/'smoke-r2/results'/arm
        report = read(folder/'training.json'); before = previous(old_folder/'training.json'); recipe = run['recipe']
        check(report == run['training'] and recipe == previous_runs[arm]['recipe']
            and report['count_exposure'] == recipe['count_exposure'] and recipe['guide_boundary'] is False
            and report['config']['max_target_tokens'] == 512
            and (report['optimizer_steps'], report['valid_target_token_presentations'], report['row_presentations']) == (340, 225840, 2440)
            and report['stopped_reason'] == 'epochs_completed' and run['budget_completed'] is True, arm+'/complete_unchanged_recipe_and_budget')
        initial.add(report['initial_weights_sha256']); capacities.add(run['trainable_parameter_count'])
        keys = ('config', 'initial_weights_sha256', 'selected_weights_sha256', 'last_complete_attempt_weights_sha256',
            'selected_epoch', 'row_presentations', 'valid_target_token_presentations', 'optimizer_steps', 'curriculum',
            'training_rows_sha256', 'validation_rows_sha256', 'training_references_sha256', 'validation_references_sha256',
            'codec_sha256', 'frozen_parameter_names', 'baseline', 'selected', 'last_complete_attempt', 'history', 'stage_reports',
            'gradient_norms', 'count_selector_initial', 'count_selector_final', 'committed_count_batch_ids_sha256',
            'count_training_presentations_by_class', 'count_mean_loss_exposure_by_class')
        check(all(prior.subset_equal(report[key], before[key]) for key in keys), arm+'/original_epoch_metrics_stage_adam_summaries_and_final_digests_exact')
        check(report['optimizer_instance_count'] == 1 and report['optimizer_reinitialized_between_stages'] is False, arm+'/one_optimizer')
        selection = old.audit_selection(report, arm)
        exposure = prior.exposure(report, corpus, vectors, arm)
        for first, second in zip(report['stage_reports'], report['stage_reports'][1:]):
            check(first['optimizer_state_end'] == second['optimizer_state_start']
                and first['optimizer_step_end'] == second['optimizer_step_start'], arm+'/continuous_adam/'+second['name'])
        for role in ('selected', 'last-attempt'):
            state = read(folder/(role+'-state.json')); reference = previous(old_folder/(role+'-state.json'))
            expected = report['selected_weights_sha256'] if role == 'selected' else report['last_complete_attempt_weights_sha256']
            check(state['role'] == role and state['recipe'] == recipe and state['weights_sha256'] == digest(state['model_state'])
                and state['tensor_sha256'] == old.tensor_digest(state['model_state']) == expected, arm+'/'+role+'/strict_state_identity')
            check(state['selected'] == (role == 'selected' or report['last_complete_attempt_is_selected'])
                and state['optimizer_resumable'] is False and state['architecture']['guide_boundary'] is False
                and state['architecture']['decoder_reference_count_access'] is False, arm+'/'+role+'/no_promotion_or_reference_count_generation')
            compare_states(state, reference, arm+'/'+role)
            old.authority(state, arm+'/'+role)
            old.audit_projections(state['model_state'], donor, report['frozen_parameter_names'], arm+'/'+role)
            stored = report['selected'] if role == 'selected' else report['last_complete_attempt']
            predictions = read(folder/('selected-predictions.json' if role == 'selected' else 'last-attempt-predictions.json'))
            for label, split, kind in prior.LABELS:
                value = read(folder/role/('evaluation-'+label+'.json')); refs = corpus[split]
                original = previous(old_folder/role/('evaluation-'+label+'.json'))
                old.audit_execution(value, refs, vectors, arm+'/'+role+'/'+label, kind)
                old.audit_fidelity(value['source_fidelity'], refs, value['predictions'], donor['codec'], arm+'/'+role+'/'+label)
                prior.probabilities(value['source_count'], value['hypothetical_boundary_diagnostics'], refs, arm+'/'+role+'/'+label)
                check(value['predictions'] == original['predictions'] and value['report']['metrics'] == original['report']['metrics']
                    and value['source_fidelity'] == original['source_fidelity'] and value['source_count'] == original['source_count']
                    and value['hypothetical_boundary_diagnostics'] == original['hypothetical_boundary_diagnostics'],
                    arm+'/'+role+'/'+label+'/exact_previous_readout')
                compact = dict(numerical=value['report'], source_count=value['source_count'], timing=value['timing'],
                    execution=value['execution'], hypothetical_boundary_diagnostics=value['hypothetical_boundary_diagnostics'],
                    source_fidelity={key: item for key, item in value['source_fidelity'].items() if key != 'rows'})
                check(compact == run['postfit'][role][label], arm+'/'+role+'/'+label+'/summary_binding')
                if label == 'validation':
                    check(value['predictions'] == predictions and value['report']['metrics'] == stored['numerical']
                        and compact['source_fidelity'] == stored['fidelity'] and value['source_count'] == stored['source_count'],
                        arm+'/'+role+'/conditioned_replay_exact')
        trace = audit_trace(run, folder, before, corpus['train'], vectors, donor)
        arm_results.append(dict(arm=arm, initial_weights_sha256=report['initial_weights_sha256'],
            selected_epoch=report['selected_epoch'], selected_weights_sha256=report['selected_weights_sha256'],
            last_attempt_weights_sha256=report['last_complete_attempt_weights_sha256'],
            selection=selection, count_exposure=exposure, trace=trace, gradient_norms=report['gradient_norms'],
            training_call_seconds=report['elapsed_seconds'], whole_arm_seconds=run['elapsed_seconds']))
    check(len(initial) == len(capacities) == 1, 'scope/identical_initial_tensors_and_capacity')
    resource, child = read(attempt/'resources-final.json'), read(attempt/'child-exit.json'); record = resource['record']
    check(resource['status'] == record['status'] == 'released' and record['artifacts_durable_asserted'] is True
        and child['returncode'] == 0 and child['leader_reaped'] is True
        and record['last_usage']['group_rss']['live_processes'] == 0, 'resources/durable_success_and_release')
    check(record['cpu_slots'] == record['child_process_slots'] == 1 and record['memory_mb'] == 4096
        and record['final_accounting']['limit_bytes'] == 140000000000
        and record['final_accounting']['charged_bytes'] <= 140000000000 and record['attempt_exceeded_reservation'] is False,
        'resources/unchanged_caps_and_one_process')
    changed = set(subprocess.check_output(['git', 'diff', '--name-only', TESTED_BASE, args.published_main], cwd=ROOT, text=True).splitlines())
    loaded_paths = {key.split(':', 1)[1] for key in summary['source_dependencies']}
    resource_paths = {'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py',
        'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py'}
    check(not changed & (loaded_paths | resource_paths), 'publication/disjoint_remote_changes')
    compatibility = read(RUN/'resource-compatibility.json')
    previous_compatibility = previous(PRIOR/'resource-compatibility.json')
    check(compatibility['prior_compatibility_sha256'] == sha(PRIOR/'resource-compatibility.json')
        and compatibility['prior_resource_audit_sha256'] == previous_compatibility['prior_resource_audit_sha256']
        and compatibility['root_admission_path_unchanged'] is True and compatibility['nested_lease_exercised'] is False
        and compatibility['ledger_mutated'] is False and compatibility['storage_cap_changed'] is False,
        'resources/previous_admission_compatibility_bound_without_nested_lease_claim')
    for relative in resource_paths:
        published = subprocess.check_output(['git', 'show', args.published_main+':'+relative], cwd=ROOT)
        check(hashlib.sha256(published).hexdigest() == compatibility['published_owner_sha256'][relative],
            'resources/published_owner/'+relative)
    check(sha(dependency/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py')
        == compatibility['executed_historical_owner']['sha256'] and
        sha(dependency/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py')
        == compatibility['executed_scheduler']['sha256'], 'resources/executed_historical_owners_unchanged')
    test_suites = []
    for path in sorted(RUN.glob('*tests*.xml')):
        suites = list(ET.parse(path).getroot().iter('testsuite'))
        counts = {key: sum(int(item.get(key, 0)) for item in suites) for key in ('tests', 'failures', 'errors', 'skipped')}
        test_suites.append(dict(path=str(path), sha256=sha(path), **counts))
    check(test_suites and all(row['failures'] == row['errors'] == 0 for row in test_suites), 'tests/recorded_suites_pass')
    check(sha(__file__) == source_sha and sha(HELPER) == HELPER_SHA, 'pins/audit_programs_unchanged')
    groups = {}
    for item in checks:
        bucket = groups.setdefault(item['check'].split('/', 1)[0], dict(passed=0, failed=0))
        bucket['passed' if item['passed'] else 'failed'] += 1
    result = dict(schema='independent-decoder-gradient-trace-audit/v1', complete=True,
        created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        verdict='blocking_findings' if findings else 'no_blocking_correctness_issue_found', findings=findings,
        checked_count=len(checks), failed_check_count=len(findings), checks=groups,
        check_detail_policy='Pass counts grouped; every failed check retained. Exact audit program and artifact hashes permit replay.',
        all_pins_match=all(row['passed'] for row in checks if row['check'].startswith('pins/')),
        arms=arm_results, tests=test_suites, test_count_note='Overlapping test receipts are not additive.',
        resource_status=resource['status'], resource_compatibility=compatibility,
        artifacts=artifacts, audit_source_sha256=source_sha, audit_helper_sha256=HELPER_SHA,
        publication_compatibility=dict(tested_base=TESTED_BASE, inspected_main=args.published_main,
            changed_path_count=len(changed), loaded_or_resource_overlap=sorted(changed & (loaded_paths | resource_paths))),
        limitations=['Previously exposed authored development; no fresh holdout or natural-statute generalization.',
            'Top-K replay is a selected-tail mechanism diagnostic, not an estimate of typical gradients or causal proof.',
            'Previous-run parity covers all archived epoch metrics, four stage Adam summaries, final tensors and controls; previous per-step tensors were not recorded.',
            'All new340 scalar norm/batch records are audited, but comparison to prior scalar norms is aggregate-only.',
            'No model or native parser/prover is executed by this standard-library auditor.',
            'Exact replay predicates bind recorded model executions; numerical branch attribution uses declared tolerances.',
            '8D teacher and 768D lineage remain unchanged; actual cached-input384D only.',
            'No native/Lake qualification, checkpoint promotion, convergence proof or global-optimum claim.'],
        model_executed_by_auditor=False, native_executed_by_auditor=False, **{key: False for key in old.AUTHORITY})
    with args.output.open('xb') as stream:
        stream.write(json.dumps(result, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False).encode()+b'\n')
    print(json.dumps(dict(path=str(args.output), sha256=sha(args.output), bytes=args.output.stat().st_size,
        verdict=result['verdict'], checks=len(checks), findings=findings)))
    return int(bool(findings))


if __name__ == '__main__':
    raise SystemExit(main())
