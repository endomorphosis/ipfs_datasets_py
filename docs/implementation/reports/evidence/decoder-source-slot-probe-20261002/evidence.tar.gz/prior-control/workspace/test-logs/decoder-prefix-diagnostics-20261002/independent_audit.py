"""Independent arithmetic audit of archived-state reference-prefix diagnostics.

No Torch, model forward, optimizer, generation, parser backend or prover is run.
Reference-prefix predictions are conditional diagnostics, never reconstruction
or native authority. Original archived greedy outputs remain a separate input.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import math
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
ROOT = Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN = Path(__file__).resolve().parent
PRIOR = ROOT/'workspace/test-logs/decoder-transition-ramp-20261002'
HELPER = PRIOR/'independent_audit.py'
HELPER_SHA = '28619a5dbebdae44329f4515351c1df5a69eadd9b8cbd891a47290d9e534b97e'
TESTED_BASE = 'bde8a6af7dc1cb249c76ad777c86a8e79854dca8'
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA:
    raise ValueError('published prior arithmetic audit helper changed')
spec = importlib.util.spec_from_file_location('_prefix_transition_audit', HELPER)
transition = importlib.util.module_from_spec(spec); sys.modules[spec.name] = transition; spec.loader.exec_module(transition)
old, prior = transition.old, transition.prior
read, sha, digest, raw = old.read, old.sha, old.digest, old.raw
checks, findings, artifacts = old.checks, old.findings, old.artifacts
COUNTS = {}
artifacts[str(HELPER)] = dict(sha256=HELPER_SHA, bytes=HELPER.stat().st_size)
def sha(path):
    path = Path(path).resolve()
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    artifacts[str(path)] = dict(sha256=value, bytes=path.stat().st_size)
    return value


FACETS = ('modality', 'actor', 'action', 'object', 'conditions', 'exceptions', 'temporal')
TOKEN = re.compile(r'"(?:[^"\\]|\\.)*"|[{}\[\],:]|true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?')


def check(condition, label, detail=None):
    bucket = COUNTS.setdefault(label.split('/', 1)[0], dict(passed=0, failed=0))
    bucket['passed' if condition else 'failed'] += 1
    if not condition:
        findings.append(dict(priority='blocking', finding=label, detail=detail))


def annotations(reference, vocabulary):
    """Walk a separately lexed canonical JSON token stream, not decoder helpers."""
    encoded = json.dumps(reference['target'], sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)
    tokens = TOKEN.findall(encoded)
    if ''.join(tokens) != encoded:
        raise ValueError('canonical target has unsupported lexical content')
    lookup = {token: index for index, token in enumerate(vocabulary)}
    if len(lookup) != len(vocabulary): raise ValueError('duplicate codec token')
    ids = [1]+[lookup[token] for token in tokens]+[2]
    if ids != reference['target_ids']: raise ValueError('full canonical target tokens differ')
    position = 0; output = [dict(position=0, token='<bos>', token_id=1, kind='bos', path=[],
        rule_index=None, field=None, meaningful_value=False, value_id=None, boundary_after_rule=None)]
    def emit(path, kind='syntax', boundary=None):
        nonlocal position
        rule = path[1] if len(path) > 1 and path[0] == 'rules' and type(path[1]) is int else None
        field = path[2] if len(path) > 2 and path[2] in FACETS else None
        semantic = kind in ('scalar_value', 'qualifier_atom')
        output.append(dict(position=position+1, token_id=lookup[tokens[position]], token=tokens[position],
            path=list(path), kind=kind, rule_index=rule, field=field, meaningful_value=semantic,
            value_id=json.dumps(path, separators=(',', ':'), ensure_ascii=True) if semantic else None,
            boundary_after_rule=boundary))
        position += 1
    def parse(path=()):
        nonlocal position
        token = tokens[position]
        facet = path[2] if len(path) >= 3 and path[0] == 'rules' and path[2] in FACETS else None
        if token == '{':
            emit(path)
            if tokens[position] != '}':
                while True:
                    key = json.loads(tokens[position]); emit((*path, key), 'field_key')
                    if tokens[position] != ':': raise ValueError('missing object colon')
                    emit((*path, key)); parse((*path, key))
                    if tokens[position] != ',': break
                    emit(path)
            if tokens[position] != '}': raise ValueError('unclosed object')
            emit(path)
        elif token == '[':
            empty = tokens[position+1] == ']'
            kind = 'fixed_empty_qualifier' if empty and facet in FACETS[4:] else 'syntax'
            emit(path, kind)
            index = 0
            if not empty:
                while True:
                    parse((*path, index))
                    if tokens[position] != ',': break
                    emit(path, 'rule_boundary' if path == ('rules',) else 'syntax', index if path == ('rules',) else None)
                    index += 1
            if tokens[position] != ']': raise ValueError('unclosed array')
            emit(path, 'rule_boundary' if path == ('rules',) else kind, index if path == ('rules',) else None)
        else:
            json.loads(token)
            emit(path, 'scalar_value' if len(path) == 3 else 'qualifier_atom')
    parse()
    if position != len(tokens): raise ValueError('unconsumed canonical target tokens')
    output.append(dict(position=len(tokens)+1, token_id=2, token='<eos>', kind='eos', path=[],
        rule_index=None, field=None, meaningful_value=False, value_id=None, boundary_after_rule=None))
    return output


def softmax(logits):
    if type(logits) is not list or not logits or any(type(value) not in (int, float) or not math.isfinite(value) for value in logits):
        raise ValueError('invalid recorded full-vocabulary logits')
    maximum = max(logits); normalizer = sum(math.exp(value-maximum) for value in logits)
    log_z = maximum+math.log(normalizer)
    return [math.exp(value-log_z) for value in logits], [value-log_z for value in logits]


def first_divergence(prediction, expected):
    """Archived content excludes BOS/EOS; never invent an absent terminal token."""
    if prediction is None: return dict(available=False)
    content = list(prediction['token_ids']); status = prediction['generation_status']
    if prediction['eos_reached'] != (status == 'eos'): raise ValueError('inconsistent archived EOS status')
    actual = content+[2] if status == 'eos' else content
    for position, (a, b) in enumerate(zip(actual, expected)):
        if a != b: return dict(available=True, exact=False, position=position, actual_token_id=a, expected_token_id=b, reason='token_mismatch')
    if actual == expected and status == 'eos': return dict(available=True, exact=True, position=None, reason=None)
    position = min(len(actual), len(expected))
    return dict(available=True, exact=False, position=position,
        actual_token_id=actual[position] if position < len(actual) else None,
        expected_token_id=expected[position] if position < len(expected) else None,
        reason='extra_tokens' if len(actual) > len(expected) else status if status != 'eos' else 'premature_end')


def bucket(positions):
    count = len(positions); correct = sum(row['correct'] for row in positions)
    return dict(tokens=count, correct=correct, accuracy=correct/count if count else None,
        mean_negative_log_probability=-sum(row['log_probability'] for row in positions)/count if count else None)


def aggregate(records):
    positions = [p for row in records for p in row['positions']]
    semantic = [p for p in positions if p['meaningful_value']]
    groups = []
    for row in records:
        values = {}
        for position in row['positions']:
            if position['meaningful_value']: values.setdefault(position['value_id'], []).append(position)
        groups.extend(values.values())
    boundaries = [b for row in records for b in row['boundaries']]
    divergence = [row['first_divergence'] for row in records if row['first_divergence']['available']]
    return dict(tokens=bucket(positions), semantic_values=bucket(semantic),
        by_kind={kind: bucket([p for p in positions if p['kind'] == kind]) for kind in sorted({p['kind'] for p in positions})},
        by_facet={field: bucket([p for p in semantic if p['field'] == field]) for field in FACETS},
        by_rule_index={str(index): bucket([p for p in semantic if p['rule_index'] == index]) for index in sorted({p['rule_index'] for p in semantic})},
        whole_value=dict(values=len(groups), correct=sum(all(p['correct'] for p in group) for group in groups),
            token_counts=sorted({len(group) for group in groups}), scope='complete_JSON_string_atom_not_whitespace_word'),
        boundaries=dict(count=len(boundaries), full_vocabulary_correct=sum(b['full_vocabulary_correct'] for b in boundaries),
            two_way_correct=sum(b['two_way_correct'] for b in boundaries), by_expected={kind:dict(
                count=sum(b['expected'] == kind for b in boundaries),
                full_vocabulary_correct=sum(b['expected'] == kind and b['full_vocabulary_correct'] for b in boundaries),
                two_way_correct=sum(b['expected'] == kind and b['two_way_correct'] for b in boundaries)) for kind in ('stop', 'continue')}),
        archived_first_divergence=dict(available_rows=len(divergence), unavailable_rows=len(records)-len(divergence),
            by_status={status:sum(d['status'] == status for d in divergence) for status in sorted({d['status'] for d in divergence})},
            availability_statuses={status:sum(r['first_divergence']['status'] == status for r in records)
                for status in sorted({r['first_divergence']['status'] for r in records})}))


def audit_panel(value, references, numerical_rows, original_rows, state, codec, transform, archived, label):
    report, records = value['report'], value['rows']; vocabulary = codec['target_vocabulary']
    refs = {row['id']: row for row in references}; numerical = {row['id']: row for row in numerical_rows}
    before = {row['id']: row for row in original_rows}; predictions = None if archived is None else {row['id']:row for row in archived['predictions']}
    check(report['schema'] == 'decoder-prefix-diagnostics/v1' and report['complete'] is True
        and [row['id'] for row in records] == [row['id'] for row in numerical_rows]
        and report['rows_sha256'] == digest(numerical_rows) and report['source_rows_sha256'] == digest(original_rows), 'provenance/'+label+'/exact_panel_rows')
    compact_refs = [dict(id=row['id'],source_text=row['source_text'],source_sha256=row['source_sha256'],
        target=row['target'],clause_count=row['clause_count']) for row in references]
    check(report['references_sha256'] == digest(compact_refs) and report['codec_sha256'] == digest(codec)
        and report['target_vocabulary'] == vocabulary and report['input_transform_sha256'] == digest(transform), 'provenance/'+label+'/complete_references_and_codec')
    check(report['diagnostic_rows_sha256'] == digest(records)
        and report['report_sha256'] == digest({key:item for key,item in report.items() if key != 'report_sha256'}), 'provenance/'+label+'/report_and_rows_digests')
    old.authority(report, 'report/'+label)
    check(report['training_executed'] is report['generation_executed'] is report['optimizer_executed'] is False
        and report['reference_prefix_access'] is True and report['forward_executed'] is True
        and report['source_text_used_for_decoding'] is False and report['generation_temperature'] == 0
        and report['output_limit'] == 512 and report['full_targets_truncated'] is False, 'scope/'+label+'/teacher_forcing_without_generation')
    check(report['model_weights_sha256'] == state['tensor_sha256'], 'provenance/'+label+'/saved_state_identity')
    execution = report['control']; kind = execution['kind']; assignment = execution['source_assignment']
    expected_digest = old.tensor_digest({'body.'+name:weights for name,weights in state['model_state'].items()}) if kind == 'zero_condition' else state['tensor_sha256']
    check(report['executed_model_weights_sha256'] == expected_digest and report['control_execution_verified'] is True
        and report['source_vector_binding_intentionally_broken'] == (kind == 'source_shuffle')
        and report['count_labels_preserved_by_assignment'] is True, 'controls/'+label+'/private_zero_wrapper_or_explicit_permutation')
    check(set(assignment) == set(assignment.values()) == set(before)
        and all(numerical[key]['input'] == before[donor]['input'] and refs[key]['clause_count'] == refs[donor]['clause_count'] for key,donor in assignment.items())
        and (all(key != donor for key,donor in assignment.items()) if kind == 'source_shuffle' else all(key == donor for key,donor in assignment.items())),
        'controls/'+label+'/complete_same_length_source_assignment')
    provenance = report['archive_provenance']; archived_available = archived is not None
    check(provenance['status'] == ('available' if archived_available else 'unavailable')
        and provenance['rows_sha256'] == digest(numerical_rows) and provenance['control_sha256'] == digest(execution)
        and provenance['output_limit'] == 512 and report['archive_authenticity_verified'] is False
        and report['archive_consistency_verified'] is True, 'provenance/'+label+'/scope_of_owner_consistency')
    if archived_available:
        check(provenance['predictions_sha256'] == digest(archived['predictions']) and provenance['executed_model_weights_sha256'] == expected_digest
            and provenance['codec_sha256'] == digest(codec) and report['archived_fidelity_metrics'] == archived['source_fidelity']['metrics'],
            'provenance/'+label+'/bound_archived_predictions_and_original_fidelity')
    else:
        check(kind == 'zero_condition' and provenance['split'] == 'train' and report['archived_fidelity_metrics'] is None,
            'scope/'+label+'/missing_train_zero_generation_not_invented')
    total_nll = 0.; total_tokens = 0
    for row in records:
        reference = refs[row['id']]; ann = annotations(reference, vocabulary); path = label+'/'+row['id']
        check(row['annotation'] == ann and len(row['positions']) == len(ann)-1 and row['clause_count'] == reference['clause_count'],
            'annotation/'+path+'/independent_complete_json_lexical_tree')
        check(row['source_sha256'] == hashlib.sha256(reference['source_text'].encode()).hexdigest()
            and row['assigned_source_id'] == assignment[row['id']] and row['input_sha256'] == digest(numerical[row['id']]['input'])
            and row['reference_sha256'] == digest(next(r for r in compact_refs if r['id'] == row['id']))
            and row['full_target_ids_sha256'] == digest(reference['target_ids']), 'provenance/'+path+'/row_source_reference_binding')
        for item, expected in zip(row['positions'], ann[1:]):
            location = path+'/'+str(item['position']); logits = item['raw_logits']; probabilities, log_probabilities = softmax(logits)
            target = expected['token_id']; selected = logits.index(max(logits)); rank = 1+sum(score > logits[target] for score in logits)
            check(len(logits) == len(vocabulary) == 32 and all(item[key] == v for key,v in expected.items()), 'annotation/'+location+'/position_and_key_value_roles')
            check(math.isclose(item['log_probability'], log_probabilities[target], rel_tol=2e-6, abs_tol=2e-6)
                and item['rank'] == rank and item['argmax_token_id'] == selected and item['argmax_token'] == vocabulary[selected]
                and item['correct'] == (selected == target), 'probability/'+location+'/full_vocabulary_logsoftmax_rank_and_argmax')
            total_nll -= log_probabilities[target]; total_tokens += 1
        boundaries = [p for p in row['positions'] if p['boundary_after_rule'] is not None]
        check(len(boundaries) == len(row['boundaries']) == reference['clause_count'], 'annotation/'+path+'/one_outer_boundary_per_rule')
        for boundary, site in zip(row['boundaries'], boundaries):
            logits = site['raw_logits']; probabilities, lps = softmax(logits); stop = vocabulary.index(']'); continuation = vocabulary.index(',')
            margin = logits[stop]-logits[continuation]; choice = 'stop' if margin > 0 else 'continue' if margin < 0 else 'tie'
            expected = 'stop' if site['token_id'] == stop else 'continue'
            check(boundary['position'] == site['position'] and boundary['rule_index'] == site['boundary_after_rule'] and boundary['expected'] == expected
                and boundary['two_way_choice'] == choice and boundary['two_way_correct'] == (choice == expected)
                and boundary['full_vocabulary_correct'] == site['correct'] and boundary['argmax_token_id'] == site['argmax_token_id'],
                'boundary/'+path+'/'+str(site['position'])+'/conditional_boundary_not_inner_delimiter')
            check(math.isclose(boundary['stop_log_probability'], lps[stop], rel_tol=2e-6, abs_tol=2e-6)
                and math.isclose(boundary['continue_log_probability'], lps[continuation], rel_tol=2e-6, abs_tol=2e-6)
                and math.isclose(boundary['stop_probability'], probabilities[stop], rel_tol=3e-6, abs_tol=3e-7)
                and math.isclose(boundary['continue_probability'], probabilities[continuation], rel_tol=3e-6, abs_tol=3e-7)
                and boundary['other_probability'] == max(0., 1.-boundary['stop_probability']-boundary['continue_probability'])
                and math.isclose(boundary['stop_minus_continue_logit'], margin, rel_tol=2e-6, abs_tol=2e-6),
                'boundary/'+path+'/'+str(site['position'])+'/full_mass_and_logit_margin_no_renormalization')
        check(row['eos'] == row['positions'][-1] and row['eos']['kind'] == 'eos', 'annotation/'+path+'/actual_final_eos_site')
        divergence = row['first_divergence']
        if predictions is None:
            check(divergence['available'] is False and divergence['status'] == 'archive_panel_unavailable'
                and divergence['expected_position'] is None and divergence['matched_prefix_tokens'] is None,
                'divergence/'+path+'/unavailable_not_failed_or_fabricated')
        else:
            prediction = predictions[row['id']]; expected = reference['target_ids'][1:]; first = first_divergence(prediction, expected)
            n = len(expected) if first.get('exact') else first['position']
            expected_position = ann[n+1] if n < len(expected) else None
            status = 'exact_with_explicit_eos' if first.get('exact') else {
                'token_mismatch':'token_mismatch', 'extra_tokens':'extra_emitted_token',
                'invalid_special_token':'invalid_special_token_unidentified', 'output_limit':'prefix_exhausted_without_eos',
                'premature_end':'prefix_exhausted_without_eos'}[first['reason']]
            check(divergence['available'] is True and divergence['status'] == status and divergence['matched_prefix_tokens'] == n
                and divergence['expected_position'] == expected_position and divergence['explicit_eos_appended'] == prediction['eos_reached']
                and divergence['missing_eos'] == (not prediction['eos_reached'])
                and divergence['emitted_token_id'] == first.get('actual_token_id')
                and divergence['archived_content_sha256'] == digest(prediction['token_ids'])
                and divergence['archived_prediction_sha256'] == digest(prediction), 'divergence/'+path+'/independent_archived_first_mismatch')
    expected_aggregate = aggregate(records)
    check(report['aggregates'] == expected_aggregate and report['by_length'] == {
        str(count): aggregate([r for r in records if r['clause_count'] == count]) for count in sorted({r['clause_count'] for r in records})},
        'aggregation/'+label+'/all_kind_facet_rule_length_and_boundary_denominators')
    numerical_report = report['numerical']
    check(total_tokens == numerical_report['target_token_count'] == 6228 and numerical_report['count'] == 48
        and numerical_report['batch_size'] == 8 and numerical_report['ce_teacher_forced'] is True and numerical_report['ce_reconciled'] is True
        and math.isclose(total_nll/total_tokens, numerical_report['token_cross_entropy'], rel_tol=1e-6, abs_tol=1e-6)
        and numerical_report['positional_token_cross_entropy'] == expected_aggregate['tokens']['mean_negative_log_probability'],
        'aggregation/'+label+'/independent_all_logits_ce_reconciliation')
    check(expected_aggregate['semantic_values']['tokens'] == 720 and expected_aggregate['boundaries']['count'] == 180
        and expected_aggregate['by_kind']['eos']['tokens'] == 48
        and all(expected_aggregate['by_facet'][field]['tokens'] == 0 for field in FACETS[4:]), 'scope/'+label+'/semantic_and_absence_denominators')
    if archived_available:
        check(numerical_report['token_cross_entropy'] == archived['report']['metrics']['token_cross_entropy'], 'replay/'+label+'/exact_prior_native_ce')
    return dict(numerical=numerical_report, aggregates=report['aggregates'], by_length=report['by_length'],
        archive_available=archived_available, elapsed_seconds=report['elapsed_seconds'])


def authenticate_prior(manifest):
    parent_manifest = Path(manifest['parent_public_manifest']); parent_results = Path(manifest['parent_public_results'])
    for path in (parent_manifest, parent_results):
        relative = str(path.relative_to(ROOT))
        published = subprocess.check_output(['git', 'show', TESTED_BASE+':'+relative], cwd=ROOT)
        check(hashlib.sha256(published).hexdigest() == sha(path) == manifest['inputs'][str(path)],
            'provenance/prior_git_publication/'+relative)
    archive = read(parent_manifest); results = read(parent_results)
    check(results['complete'] is True and results['checkpoint_promoted'] is False and results['lake_executed'] is False,
        'scope/prior_publication_private_development')
    def prior_read(path):
        path = Path(path); member = archive['original_artifact_archive_paths'][str(path)]; record = archive['members'][member]
        check(sha(path) == record['sha256'] == manifest['inputs'][str(path)] and path.stat().st_size == record['bytes'],
            'provenance/published_prior_member/'+member)
        return read(path)
    summary = prior_read(manifest['parent_summary']); arms = {row['arm']:row for row in summary['runs']}
    states = {}
    for specification in manifest['state_catalog']:
        state = prior_read(specification['state_path']); role = specification['role']; name = specification['name']
        report = arms[specification['prior_arm']]['training']; expected_hash = report['selected_weights_sha256'] if role == 'selected' else report['last_complete_attempt_weights_sha256']
        check(state['schema'] == 'private-transition-ramp-state/v1' and state['role'] == role
            and state['weights_sha256'] == digest(state['model_state'])
            and state['tensor_sha256'] == old.tensor_digest(state['model_state']) == expected_hash,
            'provenance/'+name+'/exact_archived_state_role_tensor_bytes')
        check(state['optimizer_resumable'] is False and state['selected'] == (role == 'selected' or report['last_complete_attempt_is_selected'])
            and state['architecture']['guide_boundary'] is False and report['selected_epoch'] == 0,
            'scope/'+name+'/unselected_finals_or_common_initialization')
        old.authority(state, 'state/'+name)
        states[name] = state
        expected_panels = {'train/conditioned', 'train/source_shuffle', 'validation/conditioned', 'validation/source_shuffle', 'validation/zero_condition'}
        check(set(specification['archived_evaluations']) == expected_panels, 'provenance/'+name+'/five_existing_greedy_panels')
    baseline = states['selected-common']
    for path in manifest['selected_state_equivalence_paths']:
        state = prior_read(path)
        check(state['role'] == 'selected' and state['tensor_sha256'] == baseline['tensor_sha256']
            and state['model_state'] == baseline['model_state'], 'provenance/'+Path(path).parent.name+'/common_epoch_zero_baseline')
    return states, prior_read, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', default='smoke-r1')
    parser.add_argument('--output', type=Path, default=RUN/'independent-audit.json')
    parser.add_argument('--published-main', default=TESTED_BASE)
    args = parser.parse_args(); attempt = RUN/args.attempt
    if not all((attempt/name).is_file() for name in ('results/summary.json', 'resources-final.json', 'command.json', 'child-exit.json')):
        print(json.dumps(dict(status='waiting_for_complete_durable_results'))); return 3
    if args.output.exists(): raise FileExistsError('audit output must be fresh')
    source_sha = sha(__file__); results = attempt/'results'
    command = read(attempt/'command.json'); argv = command['command']
    argument = lambda name: Path(argv[argv.index('--'+name)+1])
    manifest, plan = read(argument('manifest')), read(argument('plan'))
    source, dependency = argument('extension-root'), argument('dependency-root')
    summary, sealed = read(results/'summary.json'), read(results/'sealed-recipe.json')
    check(argument('output') == results and sealed['plan'] == plan and sealed['manifest'] == manifest
        and sha(argument('plan')) == manifest['plan_sha256'], 'pins/sealed_recipe')
    check(len(manifest['inputs']) == 41 and len(manifest['extensions']) == 20, 'pins/full_input_and_extension_inventory')
    for relative, expected in manifest['extensions'].items():
        check(sha(source/relative) == expected, 'pins/extension/'+relative)
    for path, expected in manifest['inputs'].items():
        check(sha(path) == expected, 'pins/input/'+path)
    for key, expected in summary['source_dependencies'].items():
        scope, relative = key.split(':', 1)
        check(scope in ('extension', 'dependency') and sha((source if scope == 'extension' else dependency)/relative) == expected,
            'pins/loaded_source/'+key)
    states, prior_read, previous_summary = authenticate_prior(manifest)
    corpus, donor, embeddings = (read(manifest[name]) for name in ('paragraphs','donor','embeddings'))
    vectors = {row['input_id']:row['vector'] for row in embeddings['rows']}
    check(len(vectors) == len(embeddings['rows']) == 96 and all(len(v) == 384 for v in vectors.values()), 'scope/original_complete384_embeddings')
    originals = {split:[dict(id=row['id'],source_text=row['source_text'],target_ids=row['target_ids'],input=vectors[row['id']])
        for row in corpus[split]] for split in ('train','validation')}
    check(all(len(rows) == 48 for rows in originals.values()) and corpus['codec'] == donor['codec'], 'provenance/full_original_panels_and_donor_codec')
    catalog = {row['name']:row for row in manifest['state_catalog']}
    expected_states = ['selected-common','unchanged-1729-last','ramp20-1729-last','unchanged-2718-last','ramp20-2718-last']
    expected_panels = [(state,split,control) for state in expected_states for split in ('train','validation')
        for control in ('conditioned','source_shuffle','zero_condition')]
    check(plan['state_order'] == expected_states and plan['split_order'] == ['train','validation']
        and plan['control_order'] == ['conditioned','source_shuffle','zero_condition']
        and plan['training_executed'] is plan['new_generation_allowed'] is plan['strict_gates_changed'] is False
        and plan['optimizer_steps'] == 0 and plan['temperature'] == 0
        and plan['fixed_encoder_context_tokens'] == plan['fixed_decoder_output_limit'] == 512, 'scope/fixed_diagnostic_recipe')
    check(summary['schema'] == 'decoder-prefix-diagnostic-comparison/v1' and summary['complete'] is True
        and [(p['state'],p['split'],p['control']) for p in summary['panels']] == expected_panels
        and summary['dimensions_diagnosed'] == [384] and summary['optimizer_steps'] == 0
        and all(summary[key] is False for key in ('training_executed','generation_executed','encoder_executed',
            'encoder_context_changed','output_limit_changed','downloads_performed','legal_ir_evaluate_provers','metric_disk_cache_used'))
        and summary['paragraph_embedding_cache_used'] is True and summary['bridge_names'] == [] and summary['workers'] == 1,
        'scope/complete30panels_no_training_generation_or_native_execution')
    old.authority(summary, 'summary')
    dedup = summary['selected_baseline_deduplication']
    check(dedup == sealed['selected_baseline_deduplication'] and dedup['selected_epoch'] == 0
        and dedup['source_state_count'] == 4 and dedup['executed_state_count'] == 1
        and dedup['source_paths'] == manifest['selected_state_equivalence_paths']
        and dedup['tensor_sha256'] == states['selected-common']['tensor_sha256'], 'provenance/verified_common_epoch_zero_deduplication')
    panels = []; available = 0; prediction_positions = 0
    for panel in summary['panels']:
        state, split, kind = panel['state'], panel['split'], panel['control']; label = state+'/'+split+'/'+kind
        specification = catalog[state]; receipt = panel['artifact']; path = Path(receipt['path'])
        check(path == results/state/split/(kind+'.json') and sha(path) == receipt['sha256']
            and path.stat().st_size == receipt['bytes'], 'pins/panel/'+label)
        value = read(path); report = value['report']; control = report['control']
        check(panel['report'] == report and panel['state_path'] == specification['state_path']
            and panel['state_file_sha256'] == manifest['inputs'][specification['state_path']]
            and control['kind'] == kind and report['archive_provenance']['split'] == split,
            'provenance/summary_state_control_and_raw_binding/'+label)
        assignment = control['source_assignment']; originals_by_id = {r['id']:r for r in originals[split]}
        rows = [{**row,'input':originals_by_id[assignment[row['id']]]['input']} for row in originals[split]]
        archived = None; key = split+'/'+kind
        if key in specification['archived_evaluations']:
            archived_path = specification['archived_evaluations'][key]; archived = prior_read(archived_path); available += 1
            check(report['archive_provenance']['prior_report_sha256'] == sha(archived_path)
                and panel['archived_native_ce_delta'] == 0. and panel['archive_authentication'] == 'pinned published predecessor member SHA256 and byte count'
                and {k:archived['execution'][k] for k in ('kind','source_assignment')} == control,
                'provenance/archived_exact_control_and_file/'+label)
        else:
            check(key == 'train/zero_condition' and panel['archived_native_ce_delta'] is None
                and panel['archive_authentication'] == 'unavailable', 'scope/five_unavailable_training_zero_panels/'+label)
        compact = audit_panel(value,corpus[split],rows,originals[split],states[state],donor['codec'],donor['input_transform'],archived,label)
        check(report['memory_work_estimate_bytes'] <= plan['max_memory_bytes_per_panel']
            and report['elapsed_seconds'] <= plan['max_seconds_per_panel']
            and panel['wall_seconds_including_write'] >= report['elapsed_seconds'], 'resources/panel_work_and_elapsed_bounds/'+label)
        prediction_positions += report['numerical']['target_token_count']
        panels.append(dict(state=state,split=split,control=kind,artifact=receipt,**compact))
        del value, report, archived
    check(available == summary['archive_panels_available'] == 25 and summary['archive_panels_unavailable'] == 5
        and prediction_positions == 186840, 'scope/exact_prediction_and_archive_denominators')
    resource, child = read(attempt/'resources-final.json'), read(attempt/'child-exit.json'); record = resource['record']
    check(resource['status'] == record['status'] == 'released' and record['artifacts_durable_asserted'] is True
        and child['returncode'] == 0 and child['leader_reaped'] is True
        and record['last_usage']['group_rss']['live_processes'] == 0, 'resources/durable_success_and_release')
    check(record['cpu_slots'] == record['child_process_slots'] == 1 and record['memory_mb'] == 4096
        and record['final_accounting']['limit_bytes'] == 140000000000
        and record['final_accounting']['charged_bytes'] <= 140000000000
        and record['attempt_exceeded_reservation'] is False, 'resources/unchanged_caps_one_process')
    compatibility = read(RUN/'resource-compatibility.json')
    previous_compatibility = read(PRIOR/'resource-compatibility.json')
    check(compatibility['prior_compatibility_sha256'] == sha(PRIOR/'resource-compatibility.json')
        and compatibility['prior_resource_audit_sha256'] == previous_compatibility['prior_resource_audit_sha256']
        and compatibility['root_admission_path_unchanged'] is True and compatibility['nested_lease_exercised'] is False
        and compatibility['ledger_mutated'] is compatibility['storage_cap_changed'] is False
        and compatibility['reservation_bytes'] == 300000000, 'resources/existing_owner_root_admission_scope')
    resources = {'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py',
        'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py'}
    for relative in resources:
        published = subprocess.check_output(['git','show',args.published_main+':'+relative],cwd=ROOT)
        check(hashlib.sha256(published).hexdigest() == compatibility['published_owner_sha256'][relative], 'pins/published_resource/'+relative)
    check(sha(dependency/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py')
        == compatibility['executed_historical_owner']['sha256']
        and sha(dependency/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py')
        == compatibility['executed_scheduler']['sha256'], 'pins/executed_historical_resource_owners')
    changed = set(subprocess.check_output(['git','diff','--name-only',TESTED_BASE,args.published_main],cwd=ROOT,text=True).splitlines())
    loaded = {key.split(':',1)[1] for key in summary['source_dependencies']}
    check(not changed & (loaded | resources), 'pins/publication_disjoint_loaded_source')
    tests = []
    for path in sorted(RUN.glob('*tests*.xml')):
        suites = list(ET.parse(path).getroot().iter('testsuite'))
        counts = {key:sum(int(item.get(key,0)) for item in suites) for key in ('tests','failures','errors','skipped')}
        tests.append(dict(path=str(path),sha256=sha(path),**counts))
    check(tests and all(t['failures'] == t['errors'] == 0 for t in tests), 'tests/recorded_suites_pass')
    for path,expected in manifest['inputs'].items(): check(sha(path) == expected, 'pins/final_input/'+path)
    for relative,expected in manifest['extensions'].items(): check(sha(source/relative) == expected,'pins/final_extension/'+relative)
    check(sha(__file__) == source_sha and sha(HELPER) == HELPER_SHA,'pins/audit_programs_unchanged')
    for item in checks:
        bucket = COUNTS.setdefault(item['check'].split('/',1)[0],dict(passed=0,failed=0))
        bucket['passed' if item['passed'] else 'failed'] += 1
    result = dict(schema='independent-decoder-prefix-diagnostics-audit/v1',complete=True,
        created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        verdict='blocking_findings' if findings else 'no_blocking_correctness_issue_found',findings=findings,
        checked_count=sum(sum(c.values()) for c in COUNTS.values()),failed_check_count=len(findings),checks=COUNTS,
        all_pins_match=not any(f['finding'].startswith(('pins/','provenance/')) for f in findings),
        panels=panels,tests=tests,test_count_note='Overlapping test receipts are not additive.',
        resource_status=resource['status'],resource_compatibility=compatibility,
        artifacts=artifacts,audit_source_sha256=source_sha,audit_helper_sha256=HELPER_SHA,
        publication_compatibility=dict(tested_base=TESTED_BASE,inspected_main=args.published_main,
            changed_path_count=len(changed),loaded_or_resource_overlap=sorted(changed & (loaded | resources))),
        limitations=['Reference-prefix probabilities are conditional diagnostics, not generated output reconstruction.',
            'Previously exposed authored48train+48validation paragraphs; no fresh holdout or natural-statute generalization.',
            'Only four scalar fields have meaningful values here; all qualifier lists are empty, so their semantic denominator is zero.',
            'Same-length source permutations cannot test source/count association; zero controls also remove source-based initialization.',
            'Five train-zero panels have no archived greedy outputs; missing generation is explicitly unavailable.',
            'Native float32 CE equals25 archived panels exactly; independent float64 logsoftmax arithmetic uses declared small tolerances.',
            'Only384D cached embeddings diagnosed; no original8D/768D mutation, generation, optimization, model promotion or native/Lake authority.'],
        model_executed_by_auditor=False,native_executed_by_auditor=False,**{key:False for key in old.AUTHORITY})
    with args.output.open('xb') as stream:
        stream.write(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
    print(json.dumps(dict(path=str(args.output),sha256=sha(args.output),bytes=args.output.stat().st_size,
        verdict=result['verdict'],checks=result['checked_count'],findings=findings)))
    return int(bool(findings))


if __name__ == '__main__':
    raise SystemExit(main())
