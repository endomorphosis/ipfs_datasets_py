"""Package completed source-slot readout diagnostics without executing models.

Every raw feature, coefficient and prediction score is retained. A single deterministic archive is preferred;
independent tar.gz shards are used only when compressed evidence exceeds 90 MB.
This script is run only after the complete diagnostic fit/evaluation run and arithmetic audit.
"""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import tarfile
import xml.etree.ElementTree as ET

P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
R = P/'workspace/test-logs/decoder-source-slot-probe-20261002'
PREV = P/'workspace/test-logs/decoder-prefix-diagnostics-20261002'
S = P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
E = P/'docs/implementation/reports/evidence/decoder-source-slot-probe-20261002'
MAX_ARCHIVE_BYTES = 90_000_000
SHARD_RAW_BYTES = 80_000_000
FALSE = dict(qualified=False, admitted=False, proof_authority=False,
    source_semantics_verified=False, convergence_proven=False, fresh_holdout=False,
    lake_executed=False, formalized=False, roundtrip_ok=False,
    checkpoint_promoted=False, production_checkpoint=False, optimizer_resumable=False,
    decoder_training_executed=False, generation_executed=False, optimizer_executed=False,
    full_legal_ir_exactness_measured=False, native_validation_executed=False,
    validation_tuning=False, selection_performed=False)
EXCLUDED = {'.git', '.lake', '__pycache__', '.pytest_cache', 'pytest-cache', 'pytest-cache-agent'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def info(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'regular evidence file required: '+str(path))
    return dict(sha256=sha(path), bytes=path.stat().st_size)


def write_new(path, value):
    content = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()
    if path.exists():
        require(path.read_bytes() == content, 'existing generated artifact differs: '+str(path))
        return
    with path.open('xb') as stream:
        stream.write(content); stream.flush(); os.fsync(stream.fileno())


def compress_archive(path, names, files):
    """One member at a time; raw panels are never accumulated in memory."""
    with path.open('xb') as target:
        with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as bundle:
                for name in names:
                    entry = files[name]
                    require(info(entry['path']) == entry['info'], 'archive input changed: '+name)
                    header = tarfile.TarInfo(name)
                    header.size = entry['info']['bytes']; header.mode = 0o644; header.mtime = 0
                    with entry['path'].open('rb') as source:
                        bundle.addfile(header, source)
        target.flush(); os.fsync(target.fileno())
    return info(path)


def seal_archives(files):
    names = sorted(files)
    temporary = E/'.evidence-single.tmp'
    require(not temporary.exists(), 'stale temporary archive requires review')
    candidate = compress_archive(temporary, names, files)
    if candidate['bytes'] <= MAX_ARCHIVE_BYTES:
        archive = E/'evidence.tar.gz'
        require(not archive.exists(), 'evidence archive must be fresh')
        temporary.rename(archive)
        return {'evidence.tar.gz':candidate}, {name:'evidence.tar.gz' for name in names}
    # The over-limit temporary archive was created only by this invocation and
    # is never staged. Original source, run data and prior evidence are untouched.
    temporary.unlink()
    groups, current, raw_bytes = [], [], 0
    for name in names:
        # Conservative allowance covers a member's padding, PAX path and header.
        estimate = files[name]['info']['bytes']+8192
        require(estimate <= SHARD_RAW_BYTES, 'single evidence member exceeds bounded shard capacity: '+name)
        if current and raw_bytes+estimate > SHARD_RAW_BYTES:
            groups.append(current); current=[]; raw_bytes=0
        current.append(name); raw_bytes += estimate
    if current:
        groups.append(current)
    archives, membership = {}, {}
    for index, group in enumerate(groups, 1):
        name = 'evidence-%03d.tar.gz' % index
        artifact = compress_archive(E/name, group, files)
        require(artifact['bytes'] <= MAX_ARCHIVE_BYTES, 'compressed shard exceeds Git artifact bound')
        archives[name] = artifact
        membership.update({member:name for member in group})
    require(set(membership) == set(files), 'shard inventory incomplete')
    return archives, membership


def fixed_probe_measures(report):
    a = report['aggregates']
    return dict(present_scalar_correct=a['gold_present_scalar_values']['correct'],
        present_scalar_accuracy=a['gold_present_scalar_values']['accuracy'],
        absent_scalar_correct=a['gold_absent_slots']['correct'],
        absent_scalar_accuracy=a['gold_absent_slots']['accuracy'],
        count_correct=a['count_correct'],
        scalar_slots_and_count_exact=a['scalar_slots_and_count_exact'],
        count_and_slot_presence_consistent=a['count_and_slot_presence_consistent'])


def control_comparisons(panels, plan):
    lookup = {(row['feature'],row['split'],row['control']):row for row in panels}
    require(len(lookup) == len(panels), 'duplicate feature/split/control panel')
    comparisons = []
    for feature in plan['feature_order']:
        for split in plan['split_order']:
            baseline = fixed_probe_measures(lookup[(feature,split,'conditioned')]['report'])
            for control in ('source_shuffle','cross_length_shuffle','zero_features'):
                value = fixed_probe_measures(lookup[(feature,split,control)]['report'])
                comparisons.append(dict(feature=feature,split=split,control=control,
                    conditioned=baseline,controlled=value,
                    delta_control_minus_conditioned={key:value[key]-baseline[key] for key in value},
                    count_labels_preserved_by_assignment=control != 'cross_length_shuffle',
                    scope='fixed ordered scalar/count readout only; not formula decoding or full Legal IR fidelity',**FALSE))
    return comparisons


def main():
    code = read(R/'code-files.json')
    manifest, plan = read(R/'manifest.json'), read(R/'plan.json')
    data = read(R/'smoke-r1/results/summary.json')
    audit = read(R/'independent-audit.json')
    require(data['schema'] == 'decoder-source-slot-probe-comparison/v1'
        and data['complete'] is True and len(data['fits']) == 7 and len(data['panels']) == 56
        and len(data['extractions']) == 10, 'complete fixed seven-probe diagnostic required')
    require(audit['complete'] is True and audit['all_pins_match'] is True and not audit['findings'],
        'complete independent arithmetic audit without findings required')
    require(sha(R/'independent_audit.py') == audit['audit_source_sha256'], 'audit source changed')
    require(type(code) is list and len(set(code)) == len(code), 'unique scoped source files required')
    require(len(manifest['extensions']) == 22 and len(manifest['inputs']) == 16,
        'exact source and original input inventories required')
    require(len(manifest['state_catalog']) == 5, 'five predeclared fixed states required')
    require(sha(R/'plan.json') == manifest['plan_sha256'], 'sealed plan changed')
    require(all(data[key] is False for key in FALSE if key in data), 'false authority/execution scope required')
    require(data['decoder_training_executed'] is False and data['formula_generation_executed'] is False
        and data['optimizer_steps'] == 0 and data['probe_fitting_executed'] is True,
        'probe fitting must remain separate from decoder training and generation')
    require(not E.exists() or not any(E.iterdir()), 'published evidence destination must be fresh')
    tests_source = read(R/'validated-test-source.json')
    for relative, expected in manifest['extensions'].items():
        require(sha(P/relative) == sha(R/'experiment-source'/relative) == expected,
            'candidate/frozen extension changed: '+relative)
    for relative, expected in tests_source.items():
        require(sha(P/relative) == expected, 'validated test source changed: '+relative)
    for path, expected in manifest['inputs'].items():
        require(sha(path) == expected, 'original pinned input changed: '+path)
    for path, expected in audit['artifacts'].items():
        require(info(path) == expected, 'audited raw input changed: '+path)
    for suite in audit['tests']:
        require(sha(suite['path']) == suite['sha256'], 'audited test receipt changed')

    def artifact(receipt):
        require(info(receipt['path']) == {key:receipt[key] for key in ('sha256','bytes')}, 'raw artifact receipt changed')
        return read(receipt['path'])

    expected_extractions = {(state,split) for state in plan['state_order'] for split in plan['split_order']}
    require({(row['state'],row['split']) for row in data['extractions']} == expected_extractions,
        'exact predeclared feature extraction inventory required')
    for extraction in data['extractions']:
        value = artifact(extraction['artifact']); report = value['report']
        require(report == extraction['report'] and report['complete'] is True and report['sample_count'] == 48,
            'complete source extraction report required')
        require(extraction['state_file_sha256'] == manifest['inputs'][extraction['state_path']], 'extraction state binding changed')
        require(report['reference_access'] is False and report['count_label_access'] is False
            and report['prefix_access'] is False and report['model_changed'] is False
            and report['decoder_recurrent_forward_executed'] is False, 'source-only immutable feature extraction required')
        for kind, width in [('projected_source',384),('conditioning',48)]:
            require(len(value['rows'][kind]) == 48 and all(len(row['features']) == width for row in value['rows'][kind]),
                'complete projected/conditioning feature arrays required')
    require(len(data['projected_feature_equivalence']) == 5
        and len({row['rows_sha256'] for row in data['projected_feature_equivalence']}) == 1,
        'shared frozen projection equivalence required')

    require({row['feature'] for row in data['fits']} == set(plan['feature_order']), 'exact seven fit inventory required')
    fits, columns = [], {}
    for fit in data['fits']:
        feature_value = artifact(fit['features_artifact']); value = artifact(fit['fit_artifact'])
        report, probe = value['report'], value['probe']
        require(report == fit['report'] and report['schema'] == 'decoder-source-slot-probe-fit/v1'
            and report['complete'] is True and report['probe_fitting_executed'] is True
            and report['training_rows'] == 48 and report['validation_rows_used_for_fitting'] == 0
            and report['generation_executed'] is False and report['decoder_training_executed'] is False,
            'training-only complete fixed probe fit required')
        require(report['existing_model_weights_modified'] is False and report['normal_equation']['verified'] is True,
            'unchanged decoder and verified ridge fit required')
        require(report['ridge_lambda'] == plan['ridge_lambda'] == .001 and report['intercept_penalized'] is False,
            'fixed ridge objective required')
        require(probe['inference_gold_count_access'] is False and probe['inference_reference_prefix_access'] is False,
            'target-free probe prediction required')
        require(feature_value['specification'] == report['feature_specification']
            and all(len(feature_value['rows'][split]) == 48 for split in plan['split_order']),
            'complete raw source feature matrices required')
        require(len(probe['coefficients']) == report['feature_dimension']
            and len(probe['intercept']) == report['output_columns'], 'complete raw coefficient arrays required')
        columns[fit['feature']] = report['output_columns']
        omitted = {'raw_training_feature_matrix','training_onehot_matrix','coefficients','intercept'}
        fits.append({**{key:item for key,item in fit.items() if key != 'report'},
            'report':{key:item for key,item in report.items() if key not in omitted},
            'raw_arrays_retained_in_fit_artifact':sorted(omitted)})

    expected_panels = {(feature,split,control) for feature in plan['feature_order']
        for split in plan['split_order'] for control in plan['control_order']}
    require({(row['feature'],row['split'],row['control']) for row in data['panels']} == expected_panels,
        'exact predeclared panel inventory required')
    score_values = 0
    for panel in data['panels']:
        value = artifact(panel['artifact']); report = value['report']
        require(report == panel['report'] and report['complete'] is True
            and report['schema'] == 'decoder-source-slot-probe-evaluation/v1'
            and report['generation_executed'] is False and report['decoder_training_executed'] is False,
            'raw and summary panel reports differ')
        require(len(value['rows']) == 48 and report['aggregates']['rows'] == 48
            and report['oracle_count_mask_applied'] is False and report['full_slot_prediction_count_is_fixed'] == 8,
            'all eight unmasked slots must be evaluated')
        require(report['full_legal_ir_exactness_measured'] is False
            and report['unscored_facets'] == ['conditions','exceptions','temporal']
            and report['prediction_report']['gold_count_access'] is False
            and report['prediction_report']['reference_prefix_access'] is False,
            'scalar probe scope cannot imply full Legal IR or target-assisted prediction')
        require(all(len(row['prediction']['scores']) == columns[panel['feature']]
            and len(row['scalar_slots']) == 32 for row in value['rows']), 'raw scalar/count scores omitted')
        score_values += 48*columns[panel['feature']]
        del value

    corpus = read(manifest['paragraphs']); curriculum_rows = read(manifest['curriculum_inputs'])
    require(all(row['source_tokens']['truncated'] is False and row['source_tokens']['padded'] is False
        and row['source_tokens']['encoder_context_tokens'] == 512 for row in curriculum_rows),
        'unchanged-context complete source receipts required')
    source_lengths = [row['source_tokens']['token_count'] for row in curriculum_rows]
    producers, producer_files = {}, {}
    for qualified_path, expected_pin in data['source_dependencies'].items():
        category, relative = qualified_path.split(':',1)
        require(category in ('extension','dependency'), 'unknown producer scope')
        frozen = (R/'experiment-source' if category == 'extension' else S)/relative
        require(sha(frozen) == expected_pin and (relative not in producers or producers[relative] == expected_pin),
            'executed source pin changed: '+qualified_path)
        producers[relative], producer_files[relative] = expected_pin, frozen
    for relative, expected_pin in manifest['extensions'].items():
        require(relative not in producers or producers[relative] == expected_pin, 'conflicting extension pin')
        producers[relative], producer_files[relative] = expected_pin, R/'experiment-source'/relative

    files, by_path, original_paths = {}, {}, {}
    def add(name, path, expected_info=None):
        path = Path(path).absolute(); observed = info(path); member = PurePosixPath(name)
        require(not member.is_absolute() and '..' not in member.parts and str(member) == name,
            'unsafe archive member name: '+name)
        if expected_info is not None:
            require(observed == expected_info, 'archive input pin changed: '+str(path))
        if name in files:
            require(files[name] == dict(path=path,info=observed), 'conflicting archive member')
        elif str(path) in by_path:
            name = by_path[str(path)]
        else:
            files[name] = dict(path=path,info=observed); by_path[str(path)] = name
        original_paths[str(path)] = name
    for relative in sorted(set(code)|set(tests_source)|set(producers)):
        path = producer_files.get(relative,P/relative)
        expected_pin = producers.get(relative,tests_source.get(relative))
        add('source/'+relative,path,None if expected_pin is None else dict(sha256=expected_pin,bytes=path.stat().st_size))
    for path, expected_pin in manifest['inputs'].items():
        add('inputs/'+expected_pin+'/'+Path(path).name,path,dict(sha256=expected_pin,bytes=Path(path).stat().st_size))
    for path in sorted(R.iterdir()):
        if path.is_file() and path.suffix in ('.json','.log','.xml','.py') and path.name not in ('publication.json','owned-files.json'):
            add('validation/'+path.name,path)
    for name in ('smoke-r1','experiment-source'):
        for path in sorted((R/name).rglob('*')):
            if path.is_file() and not set(path.relative_to(R).parts)&EXCLUDED:
                add('validation/'+path.relative_to(R).as_posix(),path)
    for path, expected_info in sorted(audit['artifacts'].items()):
        value = Path(path)
        if value.is_relative_to(R):
            name = 'validation/'+value.relative_to(R).as_posix()
        elif value.is_relative_to(P):
            name = 'prior-control/'+value.relative_to(P).as_posix()
        else:
            require(path in manifest['inputs'], 'unscoped external audit dependency')
            name = 'inputs/'+expected_info['sha256']+'/'+value.name
        add(name,value,expected_info)
    required_prior = [PREV/'independent_audit.py',
        P/'workspace/test-logs/decoder-transition-ramp-20261002/independent_audit.py',
        P/'workspace/test-logs/decoder-gradient-trace-20261002/independent_audit.py',
        P/'workspace/test-logs/decoder-count-exposure-20261002/independent_audit.py',
        P/'workspace/test-logs/decoder-cardinality-20261002/audit.py',
        P/'docs/implementation/reports/evidence/decoder-prefix-diagnostics-20261002/manifest.json',
        P/'docs/implementation/reports/evidence/decoder-prefix-diagnostics-20261002/results.json']
    require(all(str(path) in audit['artifacts'] for path in required_prior), 'missing prior helper/publication audit dependency')
    require(set(audit['artifacts']) <= set(original_paths), 'raw audited artifact omitted')
    compatibility = read(R/'resource-compatibility.json')
    for relative, expected_pin in (
        ('ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py',compatibility['executed_historical_owner']['sha256']),
        ('ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py',compatibility['executed_scheduler']['sha256'])):
        path = S/relative
        add('historical/dependency-source/'+relative,path,dict(sha256=expected_pin,bytes=path.stat().st_size))

    tests = dict(tests=0,failures=0,errors=0,skipped=0)
    for suite in ET.parse(R/'tests-frozen.xml').getroot().iter('testsuite'):
        for key in tests:
            tests[key] += int(suite.get(key,'0'))
    require(tests['tests'] > 0 and tests['failures'] == tests['errors'] == 0, 'passing frozen tests required')
    resource = read(R/'smoke-r1/resources-final.json'); record = resource['record']
    child = read(R/'smoke-r1/child-exit.json'); guardian = read(R/'smoke-r1-guardian.log')
    require(record['status'] == 'released' and record['artifacts_durable_asserted'] is True
        and record['storage_bytes'] == 100000000 and record['attempt_exceeded_reservation'] is False,
        'durable completed 100MB reservation required')
    require(record['cpu_slots'] == record['child_process_slots'] == 1 and record['memory_mb'] == 4096
        and record['final_accounting']['limit_bytes'] == 140000000000, 'resource contract changed')
    observations_path = R/'smoke-r1/resource-observations.json'
    observations = read(observations_path) if observations_path.exists() else []

    E.mkdir(parents=True,exist_ok=True)
    archives, member_archives = seal_archives(files)
    require(all(info(entry['path']) == entry['info'] for entry in files.values()), 'evidence changed before archive sealing')
    archive = next(iter(archives.values())) if len(archives) == 1 else None
    members = {name:entry['info'] for name,entry in files.items()}
    output_files = [str((E/name).relative_to(P)) for name in ('results.json','manifest.json',*archives)]
    write_new(R/'owned-files.json',code+output_files)
    write_new(E/'manifest.json',dict(schema='decoder-source-slot-probe-archive/v1',
        archive=archive,archives=archives,members=members,member_archives=member_archives,
        original_artifact_archive_paths=original_paths,validated_producer_source_sha256=producers,
        raw_audit_artifact_count=len(audit['artifacts']),archive_maximum_bytes=MAX_ARCHIVE_BYTES,
        historical_resource_owner_scope='executed frozen root admission; published nested-lease path not exercised',**FALSE))
    results = dict(schema='decoder-source-slot-probe-results/v1',complete=True,
        scope='fixed source-only linear scalar-slot/count diagnostic on previously exposed authored Legal data',
        dimensions_actually_evaluated=[384],dimensions_actually_trained=[],optimizer_steps=0,
        probe_fitting_executed=True,historical_8d_teacher_modified=False,actual_768d_training_performed=False,
        fixed_states=manifest['state_catalog'],state_count=5,feature_variants=plan['feature_order'],
        fits=fits,panels=data['panels'],extractions=data['extractions'],
        selected_baseline_deduplication=data['selected_baseline_deduplication'],
        projected_feature_equivalence=data['projected_feature_equivalence'],
        probe_fit_count=7,panel_count=56,feature_extraction_count=10,
        source_control_comparisons=control_comparisons(data['panels'],plan),
        train_rows=len(corpus['train']),validation_rows=len(corpus['validation']),
        source_token_range=[min(source_lengths),max(source_lengths)],
        target_token_lengths=sorted({len(row['target_ids']) for row in curriculum_rows}),
        encoder_context_tokens=512,decoder_output_limit=512,generation_temperature=0,
        reference_prefix_access=False,inference_gold_count_access=False,
        probe_fields=plan['fields'],max_rule_slots=8,independent_count_classes=plan['count_classes'],
        unscored_facets=['conditions','exceptions','temporal'],
        gold_present_scalar_metrics_are_conditional=True,
        scalar_slots_and_count_exact_scope='all eight unmasked scalar slots including ABSENT plus independently predicted count; not complete IR',
        raw_feature_and_probe_arrays_retained=True,raw_score_values=score_values,
        score_interpretation='unconstrained float64 ridge scores, not probabilities',
        ridge_lambda=plan['ridge_lambda'],normalization=plan['normalization'],
        zero_feature_scope=plan['zero_feature_scope'],
        source_material_scope='sixteen pinned inputs plus actually read audit dependencies; legacy state-catalog evaluation pointers are identity metadata, not freshly evaluated panels',
        original_donor_sha256=manifest['inputs'][manifest['donor']],
        frozen_manifest_sha256=sha(R/'manifest.json'),plan_sha256=sha(R/'plan.json'),
        candidate_sha256={relative:sha(P/relative) for relative in code},
        independent_audit_sha256=sha(R/'independent-audit.json'),
        tests={**tests,'junit_sha256':sha(R/'tests-frozen.xml')},
        telemetry=dict(device='cpu',workers=1,bridge_names=[],legal_ir_evaluate_provers=False,
            legal_ir_bridge_evaluation_performed=False,bridge_on_evaluate_seconds=None,
            metric_disk_cache_used=False,paragraph_embedding_cache_used=True,encoder_executed=False,
            use_sample_memory=False,
            extraction_api_seconds_total=sum(row['report']['elapsed_seconds'] for row in data['extractions']),
            probe_fit_api_seconds_total=sum(row['report']['elapsed_seconds'] for row in data['fits']),
            probe_fit_wall_seconds_including_write_total=sum(row['wall_seconds_including_write'] for row in data['fits']),
            evaluation_api_seconds_total=sum(row['report']['elapsed_seconds'] for row in data['panels']),
            evaluation_wall_seconds_including_write_total=sum(row['wall_seconds_including_write'] for row in data['panels']),
            comparison_seconds=data['elapsed_seconds'],comparison_timing_scope=data['timing_scope'],
            guardian_elapsed_seconds=guardian['elapsed_seconds'],
            guardian_elapsed_through_child_exit_seconds=child['guardian_elapsed_through_child_exit_seconds'],
            launch_return_through_reap_wall_seconds=child['launch_return_through_reap_wall_seconds'],
            child_time_scope=child['child_time_scope'],isolated_child_execution_seconds=None,
            owned_output_bytes=record['final_attempt_bytes'],reservation_bytes=100000000,reservation_released=True,
            observed_peak_child_rss_bytes=max((row['group_rss']['rss_bytes'] for row in observations),default=None),
            storage_cap_unchanged=True),
        raw_evidence=dict(audited_artifacts=len(audit['artifacts']),
            archive_mapping='manifest.original_artifact_archive_paths',member_archive_mapping='manifest.member_archives',
            raw_arrays='source extraction rows, train/validation feature matrices, fit normalization/classes/one-hot matrices/coefficients/intercepts, every predicted score and slot'),
        limitations=['Linear probe results do not train or repair the recurrent decoder, or produce formal logic',
            'Conditions, exceptions and temporal facets are unscored; scalar/count exactness is not complete Legal IR fidelity',
            'Gold-present metrics are conditional on reference presence; full eight-slot/count exactness remains separately reported',
            'Probes fit training-only data with a fixed lambda; no validation tuning or checkpoint selection occurred',
            'The strictly convex ridge objective does not establish global convergence of the autoencoder or decoder',
            'Authored training/validation rows were previously exposed; no fresh holdout or natural-law benchmark',
            'No recurrent decoder generation, encoder execution, or native/Lake checks occurred',
            'Historical8D untouched; no verified768D experiment'],archive=archive,archives=archives,**FALSE)
    write_new(E/'results.json',results)
    print(json.dumps(dict(archives=archives,members=len(members),fits=7,panels=56,
        raw_score_values=score_values,tests=tests)))


if __name__ == '__main__':
    main()
