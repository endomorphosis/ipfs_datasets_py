"""Seal reviewed owners only after tests complete; never starts a model run."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((R/'input-manifest-draft.json').read_bytes())
base=json.loads((R/'base.json').read_bytes())['base']
for suite in ET.parse(R/'tests-frozen.xml').getroot().iter('testsuite'):
    assert int(suite.get('failures','0'))==int(suite.get('errors','0'))==0
for path,digest in manifest['inputs'].items():assert sha(Path(path))==digest,path
for key in ('parent_public_manifest','parent_public_results'):
    path=Path(manifest[key]);relative=str(path.relative_to(P))
    assert path.read_bytes()==subprocess.check_output(['git','show',base+':'+relative],cwd=P),key
for path,digest in manifest['extensions'].items():
    assert sha(P/path)==digest,path
    assert hashlib.sha256(subprocess.check_output(['git','show',base+':'+path],cwd=P)).hexdigest()==digest,path
new=[
    'ipfs_datasets_py/logic/formalization/autoencoder/decoder_source_slot_probe.py',
    'scripts/ops/autoencoder/benchmark_decoder_source_slot_probe.py']
for path in new:manifest['extensions'][path]=sha(P/path)
ready=json.loads((R/'agent-ready.json').read_bytes())
assert ready['ready'] is True
for path,digest in ready['files'].items():assert sha(P/path)==digest,('agent source changed',path)
assert not (R/'experiment-source').exists(),'freeze already exists'
for path in manifest['extensions']:
    target=R/'experiment-source'/path;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(P/path,target)
    assert sha(target)==manifest['extensions'][path]
manifest['plan_sha256']=sha(R/'plan.json')
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
checks={path:dict(sha256=digest,bytes=Path(path).stat().st_size) for path,digest in manifest['inputs'].items()}
(R/'input-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
code=new+[
    'tests/unit/logic/formalization/autoencoder/test_decoder_source_slot_probe.py',
    'tests/unit/logic/formalization/autoencoder/test_benchmark_decoder_source_slot_probe.py',
    'docs/autoencoders/decoder_length_distillation.md']
(R/'code-files.json').write_text(json.dumps(code,indent=2)+'\n')
test_sources={path:sha(P/path) for path in json.loads((R/'test-files.json').read_bytes())}
(R/'validated-test-source.json').write_text(json.dumps(test_sources,indent=2)+'\n')
print(json.dumps(dict(extensions=len(manifest['extensions']),inputs=len(checks),manifest_sha256=sha(R/'manifest.json'))))
