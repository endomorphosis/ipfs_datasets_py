"""Independent arithmetic audit of fixed-source categorical ridge probes.

Uses only the standard library: no fitting, model forward, generation, or
native tools.  Coefficients are checked against the unique positive-ridge
normal equations, independently of the numerical implementation's solver.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import math
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
ROOT = Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN = Path(__file__).resolve().parent
PRIOR = ROOT/'workspace/test-logs/decoder-prefix-diagnostics-20261002'
HELPER = PRIOR/'independent_audit.py'
HELPER_SHA = 'd900a513d2771549bbcb138e8b036f84b9f31f2c19fb43e62b308f277c94700d'
TESTED_BASE = 'aeff1f635085a6bb7d43bc7e3dc8468eeb4385ee'
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA:
    raise ValueError('published arithmetic helper changed')
spec = importlib.util.spec_from_file_location('_source_slot_prefix_audit', HELPER)
prefix = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = prefix
spec.loader.exec_module(prefix)
old = prefix.old
read, sha, digest, raw = prefix.read, prefix.sha, prefix.digest, prefix.raw
check, COUNTS = prefix.check, prefix.COUNTS
checks, findings, artifacts = old.checks, old.findings, old.artifacts
artifacts[str(HELPER)] = dict(sha256=HELPER_SHA, bytes=HELPER.stat().st_size)


def matrix(value, rows=None, columns=None):
    if (type(value) is not list or not value or
            any(type(row) is not list or not row for row in value)):
        raise ValueError('nonempty rectangular numeric matrix required')
    width = len(value[0])
    if any(len(row) != width or any(type(x) not in (int, float) or not math.isfinite(x) for x in row) for row in value):
        raise ValueError('matrix shape or finite entries differ')
    if rows is not None and len(value) != rows or columns is not None and width != columns:
        raise ValueError('declared matrix dimensions differ')
    return value


def normal_equations(x, targets, weights, ridge, label):
    """Verify X^T(XW-Y)+lambda*W=0 without refitting any coefficients."""
    matrix(x); matrix(targets, len(x)); matrix(weights, len(x[0]), len(targets[0]))
    if type(ridge) not in (int, float) or not math.isfinite(ridge) or ridge <= 0:
        raise ValueError('strictly positive predeclared ridge required')
    n, dimension, columns = len(x), len(x[0]), len(targets[0])
    # The archived solver's float64 reductions and Python sums may differ in
    # the final bits.  This scale-relative residual check does not select fits.
    predictions = [[sum(a*b for a,b in zip(row,column)) for column in zip(*weights)] for row in x]
    residuals = [[predictions[i][j]-targets[i][j] for j in range(columns)] for i in range(n)]
    maximum = 0.; rhs_maximum = 0.; gradient_squared = 0.; rhs_squared = 0.
    for k in range(dimension):
        for j in range(columns):
            gradient = sum(x[i][k]*residuals[i][j] for i in range(n))+ridge*weights[k][j]
            rhs = sum(x[i][k]*targets[i][j] for i in range(n))
            maximum = max(maximum, abs(gradient)); rhs_maximum = max(rhs_maximum, abs(rhs))
            gradient_squared += gradient*gradient; rhs_squared += rhs*rhs
    relative = math.sqrt(gradient_squared)/max(1., math.sqrt(rhs_squared))
    check(relative <= 1e-8 and maximum <= 1e-8*max(1.,rhs_maximum), 'coefficients/'+label+'/independent_positive_ridge_normal_equations',
        dict(relative_residual=relative,maximum_absolute_residual=maximum,rhs_maximum=rhs_maximum))
    return dict(shape=[n,dimension,columns], ridge=ridge,
        relative_residual=relative, maximum_absolute_residual=maximum,
        sum_squared_fit_residual=sum(v*v for row in residuals for v in row),
        ridge_squared_weight_penalty=ridge*sum(v*v for row in weights for v in row),
        numerical_scope='float64 coefficients; independent standard-library normal-equation residual; no refit')


def first_maximum(scores):
    if not scores or any(type(v) not in (int,float) or not math.isfinite(v) for v in scores):
        raise ValueError('finite nonempty scores required')
    return scores.index(max(scores))


def close_values(first, second, *, tolerance=1e-9):
    if type(first) is dict and type(second) is dict:
        return first.keys() == second.keys() and all(close_values(first[k],second[k],tolerance=tolerance) for k in first)
    if type(first) is list and type(second) is list:
        return len(first) == len(second) and all(close_values(a,b,tolerance=tolerance) for a,b in zip(first,second))
    if type(first) in (int,float) and type(second) in (int,float):
        return math.isfinite(first) and math.isfinite(second) and math.isclose(first,second,rel_tol=tolerance,abs_tol=tolerance)
    return type(first) is type(second) and first == second


def training_transform(features):
    """Independent mean + one scalar centered-row RMS, including dimension zero."""
    if type(features) is not list or not features or any(type(row) is not list for row in features):
        raise ValueError('complete training feature matrix required')
    n, width = len(features), len(features[0])
    if any(len(row) != width for row in features):
        raise ValueError('training feature geometry differs')
    means = [sum(row[k] for row in features)/n for k in range(width)]
    centered = [[v-means[k] for k,v in enumerate(row)] for row in features]
    rms = math.sqrt(sum(v*v for row in centered for v in row)/n)
    scale = rms if rms > 0 else 1.
    return means, scale, [[v/scale for v in row] for row in centered]


def reference_slots(reference):
    fields = ('actor','action','modality','object')
    rules = reference['target']['rules']
    if len(rules) != reference['clause_count'] or not 1 <= len(rules) <= 8:
        raise ValueError('complete one-to-eight-clause references required')
    if any(any(type(rule[field]) is not str for field in fields) for rule in rules):
        raise ValueError('typed scalar reference fields required')
    # Tagged ABSENT is structural, never a plausible source-derived string.
    return len(rules), [[dict(kind='value',value=rules[slot][field]) if slot < len(rules)
        else dict(kind='absent') for field in fields] for slot in range(8)]


FIELDS = ('actor','action','modality','object')


def heads_for(references):
    inventories = {field:sorted({rule[field] for row in references for rule in row['target']['rules']}) for field in FIELDS}
    heads = []; offset = 0
    for slot in range(8):
        for field in FIELDS:
            classes = [dict(kind='absent')]+[dict(kind='value',value=v) for v in inventories[field]]
            heads.append(dict(name=f'slot:{slot}:{field}',slot_index=slot,field=field,start=offset,stop=offset+len(classes),classes=classes))
            offset += len(classes)
    heads.append(dict(name='count',slot_index=None,field=None,start=offset,stop=offset+8,
        classes=[dict(kind='count',value=i) for i in range(1,9)]))
    return heads, inventories


def audit_fit(value, features, references, feature_specification, label):
    probe, report = value['probe'], value['report']; raw_x = [r['features'] for r in features]
    dimension = feature_specification['dimension']; heads, inventories = heads_for(references)
    refs = {r['id']:r for r in references}; targets = []; labels = []; columns = heads[-1]['stop']
    for row in features:
        reference = refs[row['id']]; count,slots = reference_slots(reference)
        desired = [v for slot in slots for v in slot]+[dict(kind='count',value=count)]
        indices = [h['classes'].index(target) for h,target in zip(heads,desired)]
        onehot = [0.] * columns
        for head,index in zip(heads,indices): onehot[head['start']+index] = 1.
        labels.append(indices); targets.append(onehot)
    means, scale, x = training_transform(raw_x); n = len(features)
    bias = [sum(row[j] for row in targets)/n for j in range(columns)]
    centered = [[v-bias[j] for j,v in enumerate(row)] for row in targets]
    check(probe['schema'] == 'decoder-source-slot-probe/v1' and report['schema'] == 'decoder-source-slot-probe-fit/v1'
        and report['complete'] is True and probe['probe_sha256'] == report['probe_sha256']
        == digest({k:v for k,v in probe.items() if k != 'probe_sha256'})
        and report['report_sha256'] == digest({k:v for k,v in report.items() if k != 'report_sha256'}), 'pins/fit/'+label)
    check(probe['heads'] == report['heads'] == heads and probe['training_facet_inventories'] == inventories
        and probe['feature_specification'] == report['feature_specification'] == feature_specification
        and probe['dimension'] == report['feature_dimension'] == dimension and probe['fields'] == list(FIELDS)
        and probe['max_slots'] == 8 and probe['coefficient_shape'] == report['coefficient_shape'] == [dimension,columns],
        'training/'+label+'/complete_train_only_classes_and_head_geometry')
    check(probe['training_ids'] == report['training_row_ids'] == [r['id'] for r in features]
        and probe['training_feature_rows_sha256'] == report['training_feature_rows_sha256'] == digest(features)
        and probe['training_references_sha256'] == report['training_references_sha256'] == digest(references)
        and report['training_rows'] == n == 48 and report['raw_training_feature_matrix'] == raw_x
        and report['training_onehot_matrix'] == targets and report['training_class_indices'] == labels,
        'training/'+label+'/independent_training_targets_and_data_binding')
    transform = probe['transform']
    check(transform == report['transform'] and close_values(transform['mean'],means)
        and close_values(transform['scale'],scale) and transform['origin'] == 'training_only'
        and transform['constant_training_features'] == all(all(v == 0 for v in row) for row in x)
        and close_values(transform['mean_training_centered_row_squared_norm'],sum(v*v for row in x for v in row)/n),
        'normalization/'+label+'/training_only_mean_and_global_RMS')
    weights = probe['coefficients']; ridge = probe['ridge_lambda']
    check(ridge == report['ridge_lambda'] == .001 and report['dual_diagonal_regularizer'] == n*ridge
        and report['intercept_penalized'] is False and close_values(probe['intercept'],bias)
        and report['intercept'] == probe['intercept'] and report['coefficients'] == weights,
        'coefficients/'+label+'/fixed_mean_loss_lambda_and_unpenalized_intercept')
    if dimension:
        equation = normal_equations(x,centered,weights,n*ridge,label)
        objective = (equation['sum_squared_fit_residual']+equation['ridge_squared_weight_penalty'])/n
    else:
        check(weights == [], 'coefficients/'+label+'/intercept_has_no_feature_parameters')
        objective = sum(v*v for row in centered for v in row)/n
        equation = dict(shape=[n,0,columns],ridge=n*ridge,relative_residual=0.,maximum_absolute_residual=0.,
            numerical_scope='zero feature dimensions; independent class means are the unpenalized intercept minimizer')
    check(close_values(objective,report['mean_objective']) and report['normal_equation']['verified'] is True
        and report['normal_equation']['strictly_convex_weight_objective'] is True
        and report['normal_equation']['max_abs_residual'] <= report['normal_equation']['absolute_tolerance'],
        'coefficients/'+label+'/independent_mean_objective_and_certificate')
    check(report['probe_fitting_executed'] is True and report['existing_model_weights_modified'] is False
        and report['validation_rows_used_for_fitting'] == 0 and probe['inference_gold_count_access'] is False
        and probe['inference_reference_prefix_access'] is False and probe['score_interpretation'] == 'unconstrained ridge scores, not probabilities',
        'scope/'+label+'/only_readout_fit_no_validation_or_decoder_update')
    old.authority(value,'authority/fit/'+label)
    return dict(normal_equations=equation,mean_objective=objective,training_ids_sha256=digest(probe['training_ids']),
        feature_dimension=dimension,head_count=len(heads),output_columns=columns,probe_sha256=probe['probe_sha256'])


def summarize(rows):
    present = [slot for row in rows for slot in row['scalar_slots'] if slot['expected']['kind'] == 'value']
    absent = [slot for row in rows for slot in row['scalar_slots'] if slot['expected']['kind'] == 'absent']
    def score(items):
        correct = sum(item['correct'] for item in items)
        return dict(total=len(items),correct=correct,accuracy=correct/len(items) if items else None,
            out_of_training_inventory=sum(item['out_of_training_inventory'] for item in items))
    per_class = {}
    for field in FIELDS:
        items = [slot for slot in present if slot['field'] == field]; classes = sorted({s['expected']['value'] for s in items})
        per_class[field] = []
        for value in classes:
            matches = [s for s in items if s['expected']['value'] == value]; correct = sum(s['correct'] for s in matches)
            per_class[field].append(dict(value=value,support=len(matches),correct=correct,recall=correct/len(matches)))
    return dict(rows=len(rows),gold_present_scalar_values=score(present),gold_absent_slots=score(absent),
        by_facet={field:score([s for s in present if s['field'] == field]) for field in FIELDS},
        by_slot_index={str(i):score([s for s in present if s['slot_index'] == i]) for i in range(8)},
        per_class_recall=per_class,count_correct=sum(r['count_correct'] for r in rows),
        count_by_class={str(k):dict(total=sum(r['expected_count'] == k for r in rows),
            correct=sum(r['expected_count'] == k and r['count_correct'] for r in rows)) for k in range(1,9)},
        scalar_slots_and_count_exact=sum(r['scalar_slots_and_count_exact'] for r in rows),
        count_and_slot_presence_consistent=sum(r['prediction']['count_and_slot_presence_consistent'] for r in rows))


def audit_evaluation(value, probe, features, originals, references, control, label):
    report, rows = value['report'], value['rows']; prediction_report = report['prediction_report']
    refs = {r['id']:r for r in references}; by_id = {r['id']:r for r in features}; original = {r['id']:r for r in originals}
    check(report['schema'] == 'decoder-source-slot-probe-evaluation/v1' and report['complete'] is True
        and report['probe_sha256'] == prediction_report['probe_sha256'] == probe['probe_sha256']
        and report['rows_sha256'] == digest(rows) and report['report_sha256'] == digest({k:v for k,v in report.items() if k != 'report_sha256'})
        and prediction_report['report_sha256'] == digest({k:v for k,v in prediction_report.items() if k != 'report_sha256'}),
        'pins/evaluation/'+label)
    check(report['feature_rows_sha256'] == prediction_report['feature_rows_sha256'] == digest(features)
        and report['source_features_sha256'] == digest(originals) and report['references_sha256'] == digest(references)
        and [r['id'] for r in rows] == [r['id'] for r in features] and report['control'] == control
        and prediction_report['predictions_sha256'] == digest([r['prediction'] for r in rows]), 'provenance/'+label+'/all_inputs_and_scores_bound')
    kind = control['kind']; assignment = control['source_assignment']; shuffled = kind in ('source_shuffle','cross_length_shuffle')
    check(set(assignment) == set(assignment.values()) == set(by_id) and all(features[i]['source_sha256'] == originals[i]['source_sha256']
        and by_id[key]['features'] == original[assigned]['features'] for i,(key,assigned) in enumerate(assignment.items())),
        'controls/'+label+'/complete_feature_permutation')
    check(all((key != assigned) if shuffled else (key == assigned) for key,assigned in assignment.items())
        and all((refs[key]['clause_count'] != refs[assigned]['clause_count']) if kind == 'cross_length_shuffle'
            else (refs[key]['clause_count'] == refs[assigned]['clause_count']) for key,assigned in assignment.items()),
        'controls/'+label+'/declared_count_stratum')
    if kind == 'cross_length_shuffle':
        ordered = sorted(refs,key=lambda identity:(refs[identity]['clause_count'],identity))
        expected = {identity:ordered[(i+12)%48] for i,identity in enumerate(ordered)}
        check(assignment == expected, 'controls/'+label+'/predeclared_cross_length_rotation')
    check(report['source_vector_binding_intentionally_broken'] == shuffled and report['count_labels_preserved_by_assignment'] == (kind != 'cross_length_shuffle')
        and report['normalized_zero_is_training_mean_control'] == (kind == 'zero_features') and prediction_report['zero_features'] == (kind == 'zero_features')
        and prediction_report['gold_count_access'] is prediction_report['reference_prefix_access'] is False,
        'scope/'+label+'/feature_only_prediction_and_control_scope')
    heads = probe['heads']; dimension = probe['dimension']; columns = len(probe['intercept'])
    for row in rows:
        identity = row['id']; prediction = row['prediction']; reference = refs[identity]
        z = [0.]*dimension if kind == 'zero_features' else [(x-m)/probe['transform']['scale'] for x,m in zip(by_id[identity]['features'],probe['transform']['mean'])]
        scores = [probe['intercept'][j]+sum(z[k]*probe['coefficients'][k][j] for k in range(dimension)) for j in range(columns)]
        indices = [first_maximum(prediction['scores'][h['start']:h['stop']]) for h in heads]
        classes = [h['classes'][i] for h,i in zip(heads,indices)]
        slots = [{field:classes[i*4+j] for j,field in enumerate(FIELDS)} for i in range(8)]
        count = classes[-1]['value']; consistent = all(all(v['kind'] == ('value' if i < count else 'absent') for v in slot.values()) for i,slot in enumerate(slots))
        check(close_values(prediction['scores'],scores) and prediction['class_indices'] == indices
            and prediction['slots'] == slots and prediction['predicted_count'] == count
            and prediction['count_and_slot_presence_consistent'] == consistent,
            'scores/'+label+'/'+identity+'/independent_linear_scores_and_first_argmax')
        expected_count,expected_slots = reference_slots(reference); expected = [v for slot in expected_slots for v in slot]
        observations = [dict(slot_index=h['slot_index'],field=h['field'],expected=e,predicted=c,correct=e == c,
            out_of_training_inventory=e not in h['classes']) for h,e,c in zip(heads[:-1],expected,classes[:-1])]
        check(row['source_sha256'] == prediction['source_sha256'] == by_id[identity]['source_sha256']
            and prediction['id'] == identity and row['assigned_source_id'] == assignment[identity]
            and row['scalar_slots'] == observations and row['expected_count'] == expected_count
            and row['count_correct'] == (count == expected_count)
            and row['scalar_slots_and_count_exact'] == (count == expected_count and all(s['correct'] for s in observations)),
            'metrics/'+label+'/'+identity+'/all_unmasked_slots_and_count')
    aggregate = summarize(rows)
    check(report['aggregates'] == aggregate and report['by_length'] == {str(k):summarize([r for r in rows if r['expected_count'] == k]) for k in (1,2,4,8)},
        'metrics/'+label+'/complete_independent_aggregates')
    check(aggregate['rows'] == 48 and aggregate['gold_present_scalar_values']['total'] == 720
        and aggregate['gold_absent_slots']['total'] == 816 and report['oracle_count_mask_applied'] is False
        and report['full_legal_ir_exactness_measured'] is False and report['gold_present_metrics_are_conditional'] is True
        and report['full_slot_prediction_count_is_fixed'] == 8 and report['unscored_facets'] == ['conditions','exceptions','temporal'],
        'scope/'+label+'/no_complete_IR_claim_or_absence_denominator_shortcut')
    old.authority(value,'authority/evaluation/'+label)
    return dict(aggregates=aggregate,by_length=report['by_length'],probe_sha256=probe['probe_sha256'])


def audit_context(args):
    attempt = RUN/args.attempt; results = attempt/'results'
    command = read(attempt/'command.json'); argv = command['command']
    argument = lambda name: Path(argv[argv.index('--'+name)+1])
    source, dependency = argument('extension-root'), argument('dependency-root')
    manifest, plan = read(argument('manifest')), read(argument('plan'))
    summary, sealed = read(results/'summary.json'), read(results/'sealed-recipe.json')
    check(argument('output') == results and sealed['manifest'] == manifest and sealed['plan'] == plan
        and sha(argument('plan')) == manifest['plan_sha256'], 'pins/sealed_recipe')
    check(len(manifest['inputs']) == 16 and len(manifest['extensions']) == 22, 'pins/complete_input_source_inventory')
    for path, expected in manifest['inputs'].items(): check(sha(path) == expected, 'pins/input/'+path)
    for relative, expected in manifest['extensions'].items(): check(sha(source/relative) == expected, 'pins/extension/'+relative)
    for key,expected in summary['source_dependencies'].items():
        scope,relative = key.split(':',1)
        check(scope in ('extension','dependency') and sha((source if scope == 'extension' else dependency)/relative) == expected,
            'pins/loaded_source/'+key)
    for key in ('parent_public_manifest','parent_public_results'):
        path = Path(manifest[key]); published = subprocess.check_output(['git','show',TESTED_BASE+':'+str(path.relative_to(ROOT))],cwd=ROOT)
        check(hashlib.sha256(published).hexdigest() == sha(path) == manifest['inputs'][str(path)], 'pins/published_prefix/'+key)
    archive, public = read(manifest['parent_public_manifest']), read(manifest['parent_public_results'])
    check(public['complete'] is True and public['checkpoint_promoted'] is public['lake_executed'] is False,
        'scope/prior_prefix_evidence_nonqualifying')
    def previous(path):
        path = Path(path); member = archive['original_artifact_archive_paths'][str(path)]; entry = archive['members'][member]
        check(sha(path) == entry['sha256'] == manifest['inputs'][str(path)] and path.stat().st_size == entry['bytes'],
            'pins/published_prior_member/'+member)
        return read(path)
    previous_summary = previous(manifest['parent_summary']); runs = {row['arm']:row for row in previous_summary['runs']}
    states = {}
    for item in manifest['state_catalog']:
        state = previous(item['state_path']); report = runs[item['prior_arm']]['training']; role = item['role']
        expected_hash = report['selected_weights_sha256'] if role == 'selected' else report['last_complete_attempt_weights_sha256']
        check(state['schema'] == 'private-transition-ramp-state/v1' and state['role'] == role
            and state['selected'] is (role == 'selected') and state['optimizer_resumable'] is False
            and digest(state['model_state']) == state['weights_sha256']
            and old.tensor_digest(state['model_state']) == state['tensor_sha256'] == expected_hash,
            'pins/state/'+item['name'])
        old.authority(state,'authority/state/'+item['name']); states[item['name']] = state
    check(len(states) == 5 and list(states) == plan['state_order'], 'scope/five_exact_frozen_states')
    baseline = states['selected-common']
    for path in manifest['selected_state_equivalence_paths']:
        state = previous(path)
        check(state['model_state'] == baseline['model_state'] and state['tensor_sha256'] == baseline['tensor_sha256'],
            'pins/common_selected_state/'+Path(path).parent.name)
    corpus, donor, embeddings = (previous(manifest[name]) for name in ('paragraphs','donor','embeddings'))
    vectors = {row['input_id']:row['vector'] for row in embeddings['rows']}
    check(len(vectors) == len(embeddings['rows']) == 96 and all(len(row) == 384 for row in vectors.values()),
        'scope/original_cached_embeddings')
    for state in states.values():
        original = {name:weights for name,weights in donor['model_state'].items() if name.startswith('projection_')}
        restored = {name.split('body.body.',1)[1]:weights for name,weights in state['model_state'].items() if name.startswith('body.body.projection_')}
        check(original == restored and len(original) == 4, 'pins/frozen_inherited_projection/'+state['tensor_sha256'])
    for split in ('train','validation'):
        rows = corpus[split]
        check(len(rows) == len({r['id'] for r in rows}) == len({r['source_sha256'] for r in rows}) == 48,
            'provenance/unique_source_inventory/'+split)
        check(all(r['source_sha256'] == hashlib.sha256(r['source_text'].encode()).hexdigest()
            and len(r['target']['rules']) == r['clause_count'] for r in rows), 'provenance/complete_source_references/'+split)
    for key in ('id','source_sha256'):
        check(not {r[key] for r in corpus['train']} & {r[key] for r in corpus['validation']}, 'provenance/no_cross_split_'+key)
    vector_hashes = {split:{digest(vectors[row['id']]) for row in corpus[split]} for split in ('train','validation')}
    groups = {split:{group for row in corpus[split] for group in row['component_group_ids']} for split in ('train','validation')}
    check(len(vector_hashes['train']) == len(vector_hashes['validation']) == 48
        and not vector_hashes['train'] & vector_hashes['validation'], 'provenance/no_duplicate_or_cross_split_embedding')
    check(not groups['train'] & groups['validation'], 'provenance/original_component_groups_remain_split_disjoint')
    check(plan['ridge_lambda'] == .001 and plan['validation_tuning'] is plan['selection_performed'] is False
        and plan['count_classes'] == list(range(1,9)) and plan['max_rule_slots'] == 8
        and plan['fields'] == ['actor','action','modality','object'] and plan['fixed_encoder_context_tokens'] == plan['fixed_decoder_output_limit'] == 512,
        'scope/predeclared_fit_and_fixed_context')
    return locals()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', default='smoke-r1')
    parser.add_argument('--output', type=Path, default=RUN/'independent-audit.json')
    parser.add_argument('--published-main', default=TESTED_BASE)
    args = parser.parse_args()
    attempt = RUN/args.attempt
    required = ('results/summary.json','resources-final.json','command.json','child-exit.json')
    if not all((attempt/name).is_file() for name in required):
        print(json.dumps(dict(status='waiting_for_complete_durable_results')))
        return 3
    if args.output.exists():
        raise FileExistsError('audit output must be fresh')
    source_sha = sha(__file__); ctx = audit_context(args)
    summary, plan, manifest, results = (ctx[k] for k in ('summary','plan','manifest','results'))
    corpus, donor, states, vectors = (ctx[k] for k in ('corpus','donor','states','vectors'))
    refs = {split:[{k:r[k] for k in ('id','source_text','source_sha256','target','clause_count')} for r in corpus[split]]
        for split in ('train','validation')}
    check(summary['schema'] == 'decoder-source-slot-probe-comparison/v1' and summary['complete'] is True
        and summary['probe_fitting_executed'] is True and summary['optimizer_steps'] == 0 and summary['dimensions_diagnosed'] == [384]
        and summary['workers'] == 1 and summary['bridge_names'] == [] and summary['paragraph_embedding_cache_used'] is True
        and all(summary[k] is False for k in ('decoder_training_executed','encoder_training_executed','formula_generation_executed',
            'validation_tuning','selection_performed','encoder_executed','encoder_context_changed','output_limit_changed',
            'downloads_performed','legal_ir_evaluate_provers','metric_disk_cache_used')), 'scope/complete_fixed_source_only_probe_experiment')
    old.authority(summary,'authority/summary')
    def artifact(receipt, expected):
        path = Path(receipt['path'])
        check(path == expected and sha(path) == receipt['sha256'] and path.stat().st_size == receipt['bytes'], 'pins/artifact/'+str(path.relative_to(results)))
        return read(path)
    extractions = {}; projected = {}
    expected_extractions = [(state,split) for state in plan['state_order'] for split in ('train','validation')]
    check([(p['state'],p['split']) for p in summary['extractions']] == expected_extractions, 'scope/all10_source_feature_extractions')
    catalog = {row['name']:row for row in manifest['state_catalog']}
    for item in summary['extractions']:
        state,split = item['state'],item['split']; value = artifact(item['artifact'],results/'features'/state/(split+'.json'))
        report = value['report']; raw_rows = [dict(id=r['id'],source_sha256=r['source_sha256'],input=vectors[r['id']]) for r in corpus[split]]
        check(item['report'] == report and item['state_path'] == catalog[state]['state_path']
            and item['state_file_sha256'] == manifest['inputs'][item['state_path']]
            and report['model_weights_sha256'] == states[state]['tensor_sha256']
            and report['source_rows_sha256'] == digest(raw_rows) and report['input_transform_sha256'] == digest(donor['input_transform']),
            'provenance/extraction/'+state+'/'+split)
        check(report['complete'] is True and report['sample_count'] == 48
            and report['feature_dimensions'] == dict(projected_source=384,conditioning=48)
            and report['conditioning_layout'] == ['initial_hidden32','persistent_source_residual16']
            and all(report[k] is False for k in ('reference_access','count_label_access','prefix_access','decoder_recurrent_forward_executed',
                'model_changed','caller_rng_changed')) and report['elapsed_seconds'] <= plan['max_seconds_per_operation'],
            'scope/extraction_source_only_unchanged_state/'+state+'/'+split)
        for kind,dimension in (('projected_source',384),('conditioning',48)):
            rows = value['rows'][kind]
            check([r['id'] for r in rows] == [r['id'] for r in raw_rows] and len(rows) == 48
                and all(set(r) == {'id','source_sha256','features'} and r['source_sha256'] == original['source_sha256']
                    and len(r['features']) == dimension and all(type(x) in (int,float) and math.isfinite(x) for x in r['features'])
                    for r,original in zip(rows,raw_rows)) and report['feature_rows_sha256'][kind] == digest(rows),
                'provenance/extracted_feature_inventory/'+state+'/'+split+'/'+kind)
        extractions[(state,split)] = value['rows']
        if split not in projected: projected[split] = value['rows']['projected_source']
        check(projected[split] == value['rows']['projected_source'], 'provenance/all_states_share_exact_projection/'+state+'/'+split)
    check(summary['projected_feature_equivalence'] == [dict(state=state,rows_sha256=digest(projected)) for state in plan['state_order']],
        'provenance/exact_shared_projection_receipt')
    dedup = summary['selected_baseline_deduplication']
    check(dedup == ctx['sealed']['selected_baseline_deduplication'] and dedup['selected_epoch'] == 0
        and dedup['source_state_count'] == 4 and dedup['executed_state_count'] == 1
        and dedup['source_paths'] == manifest['selected_state_equivalence_paths']
        and dedup['tensor_sha256'] == states['selected-common']['tensor_sha256'], 'provenance/selected_baseline_deduplication')
    check([row['feature'] for row in summary['fits']] == plan['feature_order'] and len(summary['fits']) == 7,
        'scope/seven_predeclared_single_probe_fits')
    fitted = {}; feature_records = {}; fit_records = []
    for item in summary['fits']:
        name = item['feature']; feature_value = artifact(item['features_artifact'],results/name/'features.json')
        specification = feature_value['specification']; feature_rows = feature_value['rows']
        if name == 'projected-shared':
            expected_features = projected; kind,dimension,source_states = 'projected_source',384,plan['state_order']
        elif name == 'intercept':
            expected_features = {split:[{**row,'features':[]} for row in projected[split]] for split in ('train','validation')}
            kind,dimension,source_states = 'intercept',0,[]
        else:
            state = name.removeprefix('conditioning-')
            expected_features = {split:extractions[(state,split)]['conditioning'] for split in ('train','validation')}
            kind,dimension,source_states = 'conditioning',48,[state]
        expected_specification = dict(id=name,kind=kind,dimension=dimension,provenance=dict(
            parent_public_manifest_sha256=manifest['inputs'][manifest['parent_public_manifest']],source_states=source_states,
            feature_rows_sha256={split:digest(rows) for split,rows in expected_features.items()}))
        check(feature_rows == expected_features and specification == expected_specification, 'provenance/probe_features/'+name)
        value = artifact(item['fit_artifact'],results/name/'fit.json')
        check(item['report'] == value['report'], 'provenance/fit_summary/'+name)
        fit_record = audit_fit(value,feature_rows['train'],refs['train'],specification,name)
        check(value['report']['elapsed_seconds'] <= plan['max_seconds_per_operation']
            and value['report']['memory_work_estimate_bytes'] <= plan['max_memory_bytes_per_operation']
            and item['wall_seconds_including_write'] >= value['report']['elapsed_seconds'], 'resources/bounded_fit/'+name)
        fitted[name] = value['probe']; feature_records[name] = feature_rows
        fit_records.append(dict(feature=name,artifact=item['fit_artifact'],**fit_record))
    expected_panels = [(feature,split,control) for feature in plan['feature_order'] for split in ('train','validation') for control in plan['control_order']]
    check([(p['feature'],p['split'],p['control']) for p in summary['panels']] == expected_panels
        and len(expected_panels) == 56, 'scope/complete56_control_panels')
    panels = []
    for item in summary['panels']:
        name,split,kind = item['feature'],item['split'],item['control']; label = name+'/'+split+'/'+kind
        value = artifact(item['artifact'],results/name/split/(kind+'.json')); report = value['report']
        control = report['control']; originals = feature_records[name][split]; by_id = {r['id']:r for r in originals}
        actual = [{**row,'features':by_id[control['source_assignment'][row['id']]]['features']} for row in originals]
        check(report == item['report'] and control['kind'] == kind, 'provenance/panel_summary/'+label)
        if kind == 'source_shuffle':
            expected = {}
            for count in (1,2,4,8):
                ids = sorted(r['id'] for r in refs[split] if r['clause_count'] == count)
                expected.update({identity:ids[(i+1)%len(ids)] for i,identity in enumerate(ids)})
            check(control['source_assignment'] == expected, 'controls/'+label+'/predeclared_within_length_rotation')
        compact = audit_evaluation(value,fitted[name],actual,originals,refs[split],control,label)
        check(report['elapsed_seconds'] <= plan['max_seconds_per_operation']
            and report['prediction_report']['memory_work_estimate_bytes'] <= plan['max_memory_bytes_per_operation']
            and item['wall_seconds_including_write'] >= report['elapsed_seconds'], 'resources/bounded_evaluation/'+label)
        panels.append(dict(feature=name,split=split,control=kind,artifact=item['artifact'],**compact))
    resource,child = read(attempt/'resources-final.json'),read(attempt/'child-exit.json'); record = resource['record']
    check(resource['status'] == record['status'] == 'released' and record['artifacts_durable_asserted'] is True
        and child['returncode'] == 0 and child['leader_reaped'] is True
        and record['last_usage']['group_rss']['live_processes'] == 0, 'resources/durable_success_and_release')
    check(record['cpu_slots'] == record['child_process_slots'] == 1 and record['memory_mb'] == 4096
        and record['final_accounting']['limit_bytes'] == 140000000000
        and record['final_accounting']['charged_bytes'] <= 140000000000 and record['attempt_exceeded_reservation'] is False,
        'resources/unchanged_caps_one_process')
    compatibility = read(RUN/'resource-compatibility.json'); previous_compatibility = read(PRIOR/'resource-compatibility.json')
    check(compatibility['prior_compatibility_sha256'] == sha(PRIOR/'resource-compatibility.json')
        and compatibility['prior_resource_audit_sha256'] == previous_compatibility['prior_resource_audit_sha256']
        and compatibility['root_admission_path_unchanged'] is True and compatibility['nested_lease_exercised'] is False
        and compatibility['ledger_mutated'] is compatibility['storage_cap_changed'] is False
        and compatibility['reservation_bytes'] == 100000000, 'resources/existing_admission_scope')
    resources = {'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py',
        'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py'}
    for relative in resources:
        published = subprocess.check_output(['git','show',args.published_main+':'+relative],cwd=ROOT)
        check(hashlib.sha256(published).hexdigest() == compatibility['published_owner_sha256'][relative], 'pins/published_resource/'+relative)
    dependency = ctx['dependency']
    check(sha(dependency/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py') == compatibility['executed_historical_owner']['sha256']
        and sha(dependency/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py') == compatibility['executed_scheduler']['sha256'], 'pins/executed_resource_owners')
    changed = set(subprocess.check_output(['git','diff','--name-only',TESTED_BASE,args.published_main],cwd=ROOT,text=True).splitlines())
    loaded = {key.split(':',1)[1] for key in summary['source_dependencies']}
    check(not changed & (loaded | resources), 'pins/publication_disjoint_loaded_source')
    tests = []
    for path in sorted(RUN.glob('*tests*.xml')):
        suites = list(ET.parse(path).getroot().iter('testsuite'))
        counts = {key:sum(int(item.get(key,0)) for item in suites) for key in ('tests','failures','errors','skipped')}
        tests.append(dict(path=str(path),sha256=sha(path),**counts))
    check(tests and all(t['failures'] == t['errors'] == 0 for t in tests), 'tests/recorded_suites_pass')
    for path,expected in manifest['inputs'].items(): check(sha(path) == expected,'pins/final_input/'+path)
    for relative,expected in manifest['extensions'].items(): check(sha(ctx['source']/relative) == expected,'pins/final_extension/'+relative)
    check(sha(__file__) == source_sha and sha(HELPER) == HELPER_SHA, 'pins/audit_programs_unchanged')
    for item in checks:
        bucket = COUNTS.setdefault(item['check'].split('/',1)[0],dict(passed=0,failed=0))
        bucket['passed' if item['passed'] else 'failed'] += 1
    result = dict(schema='independent-decoder-source-slot-probe-audit/v1',complete=True,
        created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),verdict='blocking_findings' if findings else 'no_blocking_correctness_issue_found',
        findings=findings,checked_count=sum(sum(c.values()) for c in COUNTS.values()),failed_check_count=len(findings),checks=COUNTS,
        all_pins_match=not any(f['finding'].startswith(('pins/','provenance/')) for f in findings),fits=fit_records,panels=panels,
        tests=tests,test_count_note='Overlapping test receipts are not additive.',resource_status=resource['status'],resource_compatibility=compatibility,
        artifacts=artifacts,audit_source_sha256=source_sha,audit_helper_sha256=HELPER_SHA,
        publication_compatibility=dict(tested_base=TESTED_BASE,inspected_main=args.published_main,
            changed_path_count=len(changed),loaded_or_resource_overlap=sorted(changed & (loaded | resources))),
        limitations=['Seven new fixed-ridge readouts are fitted; inherited decoder and encoder weights remain unchanged.',
            'Previously exposed authored48train+48validation paragraphs; no fresh holdout or natural-statute generalization.',
            'Four scalar facets and count are scored; conditions, exceptions, temporal semantics and full Legal IR are unscored.',
            'Every prediction has eight unmasked slots and a separate count; gold-present accuracy is conditional and is not full-slot exactness.',
            'Normalized zero is the training mean feature control, not the prior decoder zero-source wrapper.',
            'Positive-ridge normal equations and linear scores are checked with standard-library arithmetic; no fitting or frozen neural forward is rerun by auditor.',
            'Source-only extractor code/pins and archived raw features establish provenance; auditor does not independently rerun extraction.',
            'Only384D-derived features are diagnosed; no8D/768D changes, formula generation, native/Lake qualification, or checkpoint promotion.'],
        model_executed_by_auditor=False,probe_fitted_by_auditor=False,native_executed_by_auditor=False,**{key:False for key in old.AUTHORITY})
    with args.output.open('xb') as stream:
        stream.write(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
    print(json.dumps(dict(path=str(args.output),sha256=sha(args.output),bytes=args.output.stat().st_size,
        verdict=result['verdict'],checks=result['checked_count'],findings=findings)))
    return int(bool(findings))


if __name__ == '__main__':
    raise SystemExit(main())
