"""Run synthetic tests against exactly the staged numerical source capsule."""
from pathlib import Path
import hashlib,importlib,json,os,sys
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI='0',CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
sys.dont_write_bytecode=True
sys.path.insert(0,str(S))
package=importlib.import_module('ipfs_datasets_py.logic.formalization.autoencoder')
package.__path__.insert(0,str(R/'experiment-source/ipfs_datasets_py/logic/formalization/autoencoder'))
from ipfs_datasets_py.logic.autoformal.tree_pin import require_workspace_logic_tree
pin=require_workspace_logic_tree()
assert all(Path(path).is_relative_to(S) for path in pin.values())
import pytest
args=[str(P/name) for name in json.loads((R/'test-files.json').read_text())]
args+=['--junitxml='+str(R/'tests-frozen.xml'),'-o','cache_dir='+str(R/'pytest-cache')]
code=pytest.main(args)
modules={}
for name,module in list(sys.modules.items()):
 if name.startswith('ipfs_datasets_py'):
  path=getattr(module,'__file__',None)
  if path and Path(path).is_file():
   resolved=Path(path).resolve()
   assert resolved.is_relative_to(S) or resolved.is_relative_to(R/'experiment-source'),(name,str(resolved))
   modules[name]={'path':str(resolved),'sha256':hashlib.sha256(resolved.read_bytes()).hexdigest()}
(R/'test-import-provenance.json').write_text(json.dumps({'tree_pin':pin,'modules':modules,'pytest_returncode':code},indent=2)+'\n')
raise SystemExit(code)
