"""Independent arithmetic audit of mean-centered source guidance.

Only standard-library reads/arithmetic run here. Two byte-identical, SHA-pinned
local helpers retain the already reviewed exposure, fidelity and head formulas;
they have no external helper dependency, and their command-line mains are not run.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import math
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parent
P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
PARENT = P/'workspace/test-logs/decoder-projected-source-20261003'
HELPERS = {
    'audit_projected_arithmetic.py': '341f91c3ed3b53430a63bd208a3d41ebd810f35cda2cce035d81b8d40fc3a9c2',
    'audit_leaf_arithmetic.py': 'ea440ebb1fc7b978da165329c864a69631be88048f2b694690522674cdc98c47',
}
for name, expected in HELPERS.items():
    if hashlib.sha256((R/name).read_bytes()).hexdigest() != expected:
        raise ValueError('local arithmetic helper digest mismatch: '+name)
spec = importlib.util.spec_from_file_location('_centered_projected_arithmetic', R/'audit_projected_arithmetic.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
leaf = base.old
read, sha, digest, raw, close = base.read, base.sha, base.digest, base.raw, base.close
check, findings, artifacts = base.check, base.findings, base.artifacts
for name, expected in HELPERS.items():
    artifacts[str(R/name)] = dict(sha256=expected, bytes=(R/name).stat().st_size)
MODEL_SHA = 'bfdba26a640ecdeb1a4bcf7369a9149d83667f72a55fd2d1264e94161fbf0dd6'
TRAINER_SHA = '74b0c55992dab5a038eb3c700ab44cc9af10e70936fefa4d82682f97007b5ba5'
MODEL_DIR = 'ipfs_datasets_py/logic/formalization/autoencoder'


def protected_sources(source):
    folder = Path(source)/MODEL_DIR
    old_folder = PARENT/'experiment-source'/MODEL_DIR
    check(sha(folder/'mean_centered_source_decoder_experiment.py') == MODEL_SHA,
          'source/reviewed_centering_wrapper')
    check(sha(folder/'long_span_source_value_training.py') == TRAINER_SHA,
          'source/reviewed_new_schema_acceptance_only')
    for name, expected in {**base.UNCHANGED,
            'projected_source_decoder_experiment.py': 'ce4354a96324285bff08277c3fac43e9885a75e84a50337414f7dea8501af3ee'}.items():
        check(sha(folder/name) == expected, 'source/unchanged/'+name)
    old_path = old_folder/'long_span_source_value_training.py'
    check(sha(old_path) == 'a7f957936b619ec63e4f3fb7fba01934500917d19300b2f02da9cc1e3e164a59', 'source/authenticated_previous_trainer')
    artifacts[str(old_path)] = dict(sha256=sha(old_path), bytes=old_path.stat().st_size)
    before = ast.parse(old_path.read_text())
    after = ast.parse((folder/'long_span_source_value_training.py').read_text())
    old_functions = {node.name: node for node in before.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    new_functions = {node.name: node for node in after.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    check(old_functions.keys() == new_functions.keys(), 'source/no_new_trainer_functions')
    head = new_functions['_head_specification']
    branches = [node for node in head.body if isinstance(node, ast.If)
        and ast.unparse(node.test) == "description.get('schema') == 'mean-centered-source-decoder-development/v1'"]
    check(len(branches) == 1, 'source/exact_new_head_schema_branch')
    if len(branches) == 1: head.body.remove(branches[0])
    old_train, new_train = old_functions['train'], new_functions['train']
    old_guards = [node for node in old_train.body if isinstance(node, ast.If)
        and "head_specification.get('schema')" in ast.unparse(node.test)]
    new_guards = [node for node in new_train.body if isinstance(node, ast.If)
        and "head_specification.get('schema')" in ast.unparse(node.test)]
    check(len(old_guards) == len(new_guards) == 1, 'source/one_exact_train_cohort_guard')
    if len(old_guards) == len(new_guards) == 1:
        expected = ast.parse("head_specification is not None and head_specification.get('schema') in ('projected-source-decoder-development/v1', 'mean-centered-source-decoder-development/v1')", mode='eval').body
        check(ast.dump(new_guards[0].test) == ast.dump(expected), 'source/cohort_guard_adds_only_new_schema')
        new_guards[0].test = old_guards[0].test
    for name, old_function in old_functions.items():
        check(ast.dump(new_functions[name], include_attributes=False) == ast.dump(old_function, include_attributes=False),
              'source/exact_unchanged_objective_selection_and_functions/'+name)
    # Module imports, global constants, and other statements also remain exact.
    check(ast.dump(after, include_attributes=False) == ast.dump(before, include_attributes=False),
          'source/whole_trainer_ast_equal_except_reviewed_schema_guards')


def canonical_state(state):
    return base.canonical_parameters(state)


def verify_state(state, label):
    check(digest(state['model_state']) == state['weights_sha256']
        and leaf.tensor_digest(state['model_state']) == state['tensor_sha256'], label+'/state_digests')
    leaf.authority(state, label)


def scalar_guidance_arithmetic(state, evaluation, label):
    """Recompute applied logits at training mean; never replay a decoder."""
    parameters = canonical_state(state)
    architecture = state['architecture']
    mode = architecture['scalar_mode']
    reference = parameters['source_reference_mean']
    features = [base.f32(base.f32(v-m)/parameters['source_scale'])
                for v,m in zip(reference, parameters['source_mean'])]
    baseline = base.affine(parameters['source_value_head.weight'], parameters['source_value_head.bias'], features)
    return dict(mode=mode, baseline=baseline)


def save(args, records, extra=None):
    for name, expected in HELPERS.items(): check(sha(R/name) == expected, 'pins/unchanged_helper/'+name)
    artifacts[str(Path(__file__).resolve())] = dict(sha256=sha(__file__), bytes=Path(__file__).stat().st_size)
    result = dict(schema='mean-centered-source-'+('diagnostic' if args.phase == 'diagnostics' else args.phase)+'-audit/v1', phase=args.phase,
        passed=not findings, ready=not findings, complete=True, finding_count=len(findings), failed_check_count=len(findings), findings=findings,
        checks=base.COUNTS, records=records, artifacts=artifacts,
        model_executed=False, autoregressive_generation_executed=False, training_executed=False,
        native_executed=False, torch_executed=False, qualified=False, admitted=False,
        source_semantics_verified=False, checkpoint_promoted=False,
        audit_source_sha256=sha(__file__), **(extra or {}))
    with args.output.open('x') as stream:
        json.dump(result, stream, sort_keys=True, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps(dict(path=str(args.output), sha256=sha(args.output), finding_count=len(findings))))
    return int(bool(findings))


def common(args):
    manifest, plan = read(args.manifest), read(args.plan)
    check(sha(args.plan) == manifest['plan_sha256'], 'pins/sealed_plan')
    for path, expected in manifest['inputs'].items():
        check(sha(path) == expected, 'pins/input/'+path)
        artifacts[path] = dict(sha256=expected, bytes=Path(path).stat().st_size)
    for relative, expected in manifest['extensions'].items():
        path = args.source/relative
        check(sha(path) == expected, 'pins/frozen_extension/'+relative)
        artifacts[str(path)] = dict(sha256=expected, bytes=path.stat().st_size)
    protected_sources(args.source)
    check(plan['representation_dimension'] == 384 and plan['fixed_encoder_context_tokens'] == 512
        and plan['fixed_decoder_output_limit'] == 512 and plan['temperature'] == 0
        and plan['no_downloads'] is True and plan['selection_unchanged'] is True
        and plan['native_qualification'] is False and plan['production_promotion_allowed'] is False,
        'plan/unchanged_limits_and_authority')
    check(plan['scalar_mean_fit_split'] == 'train'
        and plan['scalar_auxiliary_readout'] == 'unchanged_raw_head_logits'
        and plan['scalar_centering'] == 'subtract_current_head_logits_at_authenticated_training_feature_mean'
        and plan['generation_reference_count_access'] is False
        and plan['generation_reference_prefix_access'] is False
        and plan['diagnostic_efficacy_used_to_select_training'] is False,
        'plan/fixed_train_only_centering_without_adaptive_arm_selection')
    if plan['schema'] == 'mean-centered-source-diagnostic-plan/v1':
        expected = [mode+('-boundary-' if guided else '-unguided-')+str(seed)
            for seed in (1729,2718) for mode in ('none','center_rms') for guided in (False,True)]
        check(plan['state_order'] == expected and plan['scalar_modes'] == ['raw','off','mean_centered']
            and plan['split_order'] == ['train','validation'] and plan['expected_panels'] == 48
            and plan['training_executed'] is False and plan['optimizer_steps'] == 0,
            'plan/exact_eight_fixed_states_three_modes_two_splits')
    else:
        check(plan['schema'] == 'mean-centered-source-training-plan/v1'
            and plan['seed_order'] == [1729,2718]
            and plan['arms'] == [dict(name=mode, scalar_mode=mode, normalization='center_rms', guide_boundary=True,
                source_value_weight=.25,count_exposure='balanced_all',cardinality_weight=.25)
                for mode in ('raw','mean_centered')]
            and plan['expected_optimizer_steps_per_arm'] == 340
            and plan['expected_training_token_presentations_per_arm'] == 225840
            and plan['expected_count_presentations_per_arm'] == 2440
            and plan['expected_source_value_presentations_per_candidate'] == 25600
            and plan['expected_balanced_count_presentations'] == {str(k):610 for k in (1,2,4,8)},
            'plan/exact_four_matched_fits_and_exposure')
    corpus, donor, embeddings = [read(manifest[key]) for key in ('paragraphs','donor','embeddings')]
    vectors = {row['input_id']:row['vector'] for row in embeddings['rows']}
    preprocessing = read(manifest['parent_preprocessing'])
    ctx = dict(manifest=manifest, plan=plan, corpus=corpus, donor=donor, vectors=vectors,
               preprocessing=preprocessing, source=args.source)
    ctx['preprocessing_audit'] = base.preprocess(ctx, preprocessing)
    old_public = read(manifest['parent_public_manifest'])
    parent_summary = read(manifest['parent_summary'])
    check(old_public['schema'] == 'decoder-projected-source-archive/v1'
        and parent_summary['complete'] is True
        and parent_summary['preprocessing_sha256'] == sha(manifest['parent_preprocessing']),
        'pins/complete_published_predecessor')
    ctx['parent_runs'] = {run['arm']:run for run in parent_summary['runs']}
    for item in manifest['state_catalog']:
        for path in [item['state_path'], *item['archived_evaluations'].values()]:
            member = old_public['original_artifact_archive_paths'].get(path)
            archived = old_public['members'].get(member) if member else old_public.get('referenced_artifacts',{}).get(path)
            check(archived is not None and archived['sha256'] == manifest['inputs'][path]
                  and archived['bytes'] == Path(path).stat().st_size,
                  'pins/published_parent_artifact/'+path)
    return ctx


def architecture_receipt(architecture, parameters, ctx, label):
    mode = architecture['scalar_mode']
    normalization = architecture['normalization']
    expected = ctx['preprocessing']['normalizations'][normalization['kind']]
    check(normalization == expected and architecture['training_feature_mean_receipt'] == ctx['preprocessing']['normalizations']['center_rms']
        and architecture['count_prior'] == ctx['preprocessing']['count_prior'], label+'/training_only_receipts')
    reference = [base.f32(v) for v in ctx['preprocessing']['normalizations']['center_rms']['fitted_training_mean']]
    frozen = dict(source_reference_mean=reference, source_mean=[base.f32(v) for v in expected['mean']],
        source_scale=base.f32(expected['scale']),count_prior_logits=ctx['preprocessing']['count_prior']['log_prior'])
    for name, value in frozen.items():
        check(parameters[name] == value, label+'/frozen_buffer/'+name)
    check(mode in ('raw','off','mean_centered')
        and architecture['source_auxiliary_logits'] == 'unchanged_raw_classifier'
        and architecture['reference_baseline_detached'] is False
        and architecture['source_auxiliary_objective_changed'] is False
        and architecture['count_path_changed'] is False
        and architecture['recurrent_path_changed'] is False
        and architecture['projection_path_changed'] is False
        and architecture['added_trainable_parameters'] == 0
        and architecture['full_vocabulary_retained'] is True
        and architecture['syntax_forced'] is False and architecture['closure_forced'] is False
        and architecture['reference_documents_passed_to_generation'] is False
        and architecture['generation_reference_count_access'] is False
        and architecture['calibrated_posterior_claim'] is False,
        label+'/guidance_only_no_shortcut_architecture')
    return frozen


def audit_panel(ctx, state, value, split, kind, label, cache=None):
    refs, codec = ctx['corpus'][split],ctx['donor']['codec']
    base.evaluation_scope(value, refs, ctx['vectors'], kind, label)
    leaf.audit_fidelity(value['source_fidelity'], refs, value['predictions'], codec, label)
    base.scalar_metrics(value['source_values'], refs, codec, label+'/raw_scalar')
    base.count_metrics(value['source_count'], refs, label+'/count')
    base.boundary_metrics(value['hypothetical_boundary_diagnostics'], ctx['preprocessing']['count_prior'], value['source_count'], label+'/boundary')
    if cache is not None:
        base.source_binding(value,state,ctx['projected'],label,cache)
    return dict(exact=value['source_fidelity']['metrics']['ordered_exact'],
        eos=value['source_fidelity']['metrics']['eos_count'],
        syntax=value['source_fidelity']['metrics']['syntax_valid'],
        raw_source_value_correct=value['source_values']['correct'])


def complete_scope(summary, ctx, args):
    check(summary['complete'] is True and summary['workers'] == 1 and summary['bridge_names'] == []
        and all(summary[key] is False for key in ('legal_ir_evaluate_provers','metric_disk_cache_used',
            'encoder_executed','encoder_context_changed','output_limit_changed','downloads_performed')),
        'scope/complete_numerical_development_only')
    leaf.authority(summary,'scope')
    sealed = read(args.results/'sealed-recipe.json')
    check(sealed['manifest'] == ctx['manifest'] and sealed['plan'] == ctx['plan'], 'pins/executed_sealed_recipe')
    prep = read(args.results/'preprocessing-replay.json')
    check(prep['complete'] is True and prep['training_feature_rows_sha256'] == digest(ctx['preprocessing']['feature_rows'])
        and prep['training_mean_receipt_sha256'] == ctx['preprocessing']['normalizations']['center_rms']['receipt_sha256']
        and prep['validation_features_passed_to_fitting'] is False
        and prep['validation_targets_passed_to_fitting'] is False, 'preprocessing/exact_training_only_replay')
    for scoped, expected in summary['source_dependencies'].items():
        scope,relative = scoped.split(':',1)
        path = (args.dependency if scope == 'dependency' else args.source)/relative
        check(scope in ('dependency','extension') and sha(path) == expected, 'pins/executed_source/'+scoped)
        artifacts[str(path)] = dict(sha256=expected, bytes=path.stat().st_size)


def released(results):
    attempt = results.parent
    resource, child = read(attempt/'resources-final.json'),read(attempt/'child-exit.json')
    record=resource['record']
    check(resource['status'] == record['status'] == 'released' and record['artifacts_durable_asserted'] is True
        and child['returncode'] == 0 and child['leader_reaped'] is True
        and record['last_usage']['group_rss']['live_processes'] == 0,
        'resources/clean_exit_and_durable_release/'+attempt.name)
    check(record['attempt_exceeded_reservation'] is False
        and record['final_accounting']['charged_bytes'] <= record['final_accounting']['limit_bytes'] == 140000000000,
        'resources/unchanged_storage_cap_and_successful_bounds/'+attempt.name)


def applied_guidance(state, evaluation, label):
    mode = state['architecture']['scalar_mode']
    reference = scalar_guidance_arithmetic(state,evaluation,label)['baseline']
    guide = evaluation['scalar_guidance']
    raw_rows = {row['id']:row for row in evaluation['source_values']['predictions']}
    check(guide['schema'] == 'applied-source-scalar-guidance-diagnostic/v1'
        and guide['source_only'] is True and guide['reference_documents_passed_to_model'] is False
        and guide['target_tokens_passed_to_model'] is False and guide['posterior_probability_claimed'] is False
        and guide['metric_used_for_selection'] is False, label+'/applied_residual_scope')
    check([row['id'] for row in guide['rows']] == list(raw_rows), label+'/applied_residual_complete_rows')
    zero = evaluation['execution']['kind'] == 'zero_condition'
    maximum = 0.
    for row in guide['rows']:
        original = list(leaf.flat(raw_rows[row['id']]['raw_logits']))
        if mode == 'raw': expected = original
        elif mode == 'off' or zero: expected = [0.]*len(original)
        else: expected = [base.f32(a-b) for a,b in zip(original,reference)]
        actual = list(leaf.flat(row['applied_logits']))
        check(leaf.shape(row['applied_logits']) == [8,4,32] and all(math.isfinite(v) for v in actual),
              label+'/applied_full_vocabulary_geometry/'+row['id'])
        error=max(abs(a-b) for a,b in zip(actual,expected));maximum=max(maximum,error)
        check(close(actual,expected,3e-5), label+'/applied_affine_centering/'+row['id'],error)
        guesses = [[values.index(max(values)) for values in slot] for slot in row['applied_logits']]
        check(guesses == row['predicted_token_ids'], label+'/unmasked_full_vocabulary_argmax/'+row['id'])
    return dict(maximum_absolute_error=maximum,calibrated_posterior_claim=False,
        capture_scope='Potential residual for every slot; this does not record visited causal sites or prove every residual was used during free generation.')


def diagnostics(args,ctx):
    summary = read(args.results/'summary.json')
    complete_scope(summary,ctx,args)
    check(summary['schema'] == 'mean-centered-source-diagnostic-comparison/v1'
        and summary['training_executed'] is False and summary['optimizer_steps'] == 0
        and summary['raw_replay_parity'] is True and summary['diagnostic_efficacy_used_to_select_training'] is False,
        'diagnostic/no_training_selection_or_efficacy_gate')
    expected=[(state,mode,split) for state in ctx['plan']['state_order'] for mode in ('raw','off','mean_centered')
              for split in ('train','validation')]
    check([(p['state'],p['mode'],p['split']) for p in summary['panels']] == expected,
        'diagnostic/exact_48_ordered_complete_panels')
    catalog={item['name']:item for item in ctx['manifest']['state_catalog']}
    records=[];loaded=None;original=None;archived={}
    for entry in summary['panels']:
        name,mode,split=entry['state'],entry['mode'],entry['split']
        item=catalog[name]
        if loaded != name:
            original=read(item['state_path']);verify_state(original,name+'/original')
            archived={split:read(path) for split,path in item['archived_evaluations'].items()}
            loaded=name
        path=args.results/name/mode/('evaluation-'+split+'.json')
        value=read(path);label=name+'/'+mode+'/'+split
        check(entry['artifact'] == dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size),label+'/exact_panel_artifact')
        architecture=value['scalar_calibration']
        reference=[base.f32(v) for v in ctx['preprocessing']['normalizations']['center_rms']['fitted_training_mean']]
        wrapped={**{'body.'+key:tensor for key,tensor in original['model_state'].items()},'source_reference_mean':reference}
        state=dict(model_state=wrapped,architecture=architecture,tensor_sha256=leaf.tensor_digest(wrapped))
        architecture_receipt(architecture,canonical_state(state),ctx,label)
        check(architecture['scalar_mode'] == mode and architecture['base_architecture'] == original['architecture'],label+'/mode_and_original_architecture')
        binding=value['initial_state_binding']
        check(binding == dict(path=item['state_path'],sha256=sha(item['state_path']),
            original_tensor_sha256=original['tensor_sha256'],wrapper_tensor_sha256=state['tensor_sha256'],raw_state_rewritten=False),
            label+'/original_state_and_wrapper_binding')
        baseline=archived[split]
        check(value['source_count'] == baseline['source_count'] and value['source_values'] == baseline['source_values'],
            label+'/unchanged_auxiliary_readouts_at_exact_parent_state')
        if mode == 'raw':
            check(value['predictions'] == baseline['predictions'] and value['report']['metrics'] == baseline['report']['metrics']
                and all(value['source_fidelity'][key] == baseline['source_fidelity'][key] for key in ('metrics','by_length','by_facet')),
                label+'/exact_raw_generation_and_fidelity_replay')
            check(value['raw_replay_parity'] == entry['raw_replay_parity'] and all(value['raw_replay_parity'][key] is True
                for key in ('predictions_equal','numerical_metrics_equal','source_fidelity_equal','raw_source_head_readouts_equal')),
                label+'/raw_replay_receipt')
        else: check(value['raw_replay_parity'] is None and entry['raw_replay_parity'] is None,label+'/no_false_raw_replay_claim')
        metrics=audit_panel(ctx,state,value,split,'conditioned',label)
        guidance=applied_guidance(state,value,label)
        records.append(dict(state=name,mode=mode,split=split,metrics=metrics,guidance=guidance))
    released(args.results)
    return dict(panels=records,panel_count=len(records),preprocessing=ctx['preprocessing_audit'],
        scope='Saved raw generation parity, exact parent tensors, full-vocabulary affine guidance and persisted-output fidelity arithmetic; no decoder execution.')


RAW_PARITY_FIELDS = ['config','strategy','cardinality_weight','count_exposure','source_value_weight',
    'source_value_presentations','committed_decoder_batch_ids_sha256','committed_updates',
    'count_training_row_presentations','count_training_presentations_by_class',
    'count_mean_loss_exposure_by_class','committed_count_batch_ids_sha256',
    'count_selector_initial','count_selector_final','count_training_inventory_sha256',
    'gradient_norms','curriculum','optimizer_steps','row_presentations',
    'valid_target_token_presentations','optimizer_instance_count','optimizer_reinitialized_between_stages',
    'selected_epoch','selection','baseline','selected','last_complete_attempt',
    'last_complete_attempt_is_selected','history','stopped_reason']


def results(args,ctx):
    summary=read(args.results/'summary.json');complete_scope(summary,ctx,args)
    check(summary['schema'] == 'mean-centered-source-training-comparison/v1'
        and summary['dimensions_actually_trained'] == [384]
        and summary['raw_training_replay_parity'] is True and summary['diagnostic_efficacy_used_to_select_training'] is False,
        'training/fixed_four_fit_comparison')
    diagnostic=read(ctx['manifest']['diagnostic_audit'])
    check(diagnostic['passed'] is True and diagnostic['finding_count'] == 0
        and diagnostic['diagnostic_summary_sha256'] == sha(ctx['manifest']['diagnostic_summary'])
        and diagnostic['plan_sha256'] == sha(ctx['manifest']['diagnostic_plan'])
        and diagnostic['manifest_sha256'] == sha(ctx['manifest']['diagnostic_manifest']),
        'training/clean_exact_diagnostic_integrity_prerequisite')
    initial=read(args.results/'original-initial-generation.json')
    parent=next(iter(ctx['parent_runs'].values()))['initial_greedy_invariance']
    check(initial['predictions'] == parent['predictions']
        and initial['model_tensor_sha256'] == ctx['preprocessing']['initializer_tensor_sha256'],
        'training/original_donor_greedy_parity')
    # The previous immutable zero-head state supplies the exact initial tensor
    # inventory. Its archive pin is verified before using it, not inferred from
    # fitted outcomes in this experiment.
    parent_initial_path=Path(ctx['manifest']['parent_summary']).parent/'initial-state-center_rms.json'
    public=read(ctx['manifest']['parent_public_manifest'])
    member=public['original_artifact_archive_paths'][str(parent_initial_path)]
    check(sha(parent_initial_path) == public['members'][member]['sha256'], 'initial/published_zero_head_state_pin')
    parent_initial=read(parent_initial_path)
    reference=[base.f32(v) for v in ctx['preprocessing']['normalizations']['center_rms']['fitted_training_mean']]
    initial_tensors={**{'body.'+key:tensor for key,tensor in parent_initial['model_state'].items()},'source_reference_mean':reference}
    initial_digest=leaf.tensor_digest(initial_tensors)
    for name in ('source_value_head.weight','source_value_head.bias','count_head.weight','count_head.bias','source_to_embedding.weight'):
        check(all(v == 0. for v in leaf.flat(canonical_state(parent_initial)[name])), 'initial/zero_residual/'+name)
    expected=[mode+'-'+str(seed) for seed in (1729,2718) for mode in ('raw','mean_centered')]
    check([run['arm'] for run in summary['runs']] == expected, 'training/all_four_exact_predeclared_arms')
    ctx['projected']={identity:base.project(vector,ctx['donor']) for identity,vector in ctx['vectors'].items()}
    records=[];panels=0
    for run in summary['runs']:
        arm=run['arm'];folder=args.results/arm;mode=run['recipe']['scalar_mode'];seed=run['seed']
        report=read(folder/'training.json')
        check(run == read(folder/'summary.json') and report == run['training'] and run['budget_completed'] is True
            and report['initial_weights_sha256'] == initial_digest
            and report['source_value_weight'] == report['cardinality_weight'] == .25
            and report['strategy'] == 'semantic_fields' and report['count_exposure'] == 'balanced_all'
            and report['selection'] == 'per_length_nonregression_then_fidelity_progress_then_reference_ce'
            and report['config']['alpha'] == 0. and report['teacher_distillation_used'] is False,
            arm+'/exact_initialization_objective_and_selection')
        init=read(folder/'initial-generation.json')
        check(init == run['initial_greedy_invariance'] and init['predictions'] == initial['predictions']
            and init['model_tensor_sha256'] == initial_digest and init['identical_to_original_greedy'] is True,
            arm+'/complete_initial_generation_parity')
        exposures=base.exposure(report,ctx['corpus'],arm)
        selection=leaf.audit_selection(report,arm+'/selection')
        prior=ctx['parent_runs']['center_rms-boundary-'+str(seed)]
        if mode == 'raw':
            for field in RAW_PARITY_FIELDS:
                check(report[field] == prior['training'][field],arm+'/exact_parent_numerical_replay/'+field)
            replay=read(folder/'raw-training-replay.json')
            check(replay == run['raw_training_replay'] and replay['complete'] is True
                and replay['compared_fields'] == RAW_PARITY_FIELDS,arm+'/raw_replay_receipt')
        cache={};role_records={}
        for role in ('selected','last-attempt'):
            state=read(folder/(role+'-state.json'));label=arm+'/'+role;verify_state(state,label)
            check(state['schema'] == 'private-mean-centered-source-state/v1'
                and state['recipe'] == run['recipe'] and state['role'] == role,
                label+'/state_role')
            expected_hash=report['selected_weights_sha256'] if role == 'selected' else report['last_complete_attempt_weights_sha256']
            check(state['tensor_sha256'] == expected_hash,label+'/training_tensor_binding')
            parameters=canonical_state(state);architecture_receipt(state['architecture'],parameters,ctx,label)
            leaf.audit_projections(state['model_state'],ctx['donor'],report['frozen_parameter_names'],label)
            check(state['architecture']['scalar_mode'] == mode
                and state['architecture']['base_architecture']['guide_boundary'] is True,
                label+'/fixed_scalar_mode_and_count_guidance')
            underlying={key[5:]:value for key,value in state['model_state'].items() if key.startswith('body.')}
            underlying_digest=leaf.tensor_digest(underlying)
            check(underlying_digest == run['underlying_state_tensor_sha256'][role],label+'/underlying_tensor_binding')
            if mode == 'raw':
                expected_parent=(prior['training']['selected_weights_sha256'] if role == 'selected'
                    else prior['training']['last_complete_attempt_weights_sha256'])
                check(underlying_digest == expected_parent,label+'/exact_parent_tensors')
            role_records[role]={}
            for panel_name,split,kind in ctx['plan']['postfit_controls']:
                panel=read(folder/role/('evaluation-'+panel_name+'.json'));prefix=label+'/'+panel_name
                record=audit_panel(ctx,state,panel,split,kind,prefix,cache)
                record['applied_guidance']=applied_guidance(state,panel,prefix)
                role_records[role][panel_name]=record;panels+=1
                summary_panel=run['postfit'][role][panel_name]
                check(summary_panel['predictions'] == panel['predictions'] and summary_panel['numerical'] == panel['report']
                    and summary_panel['source_count'] == panel['source_count']
                    and summary_panel['source_values'] == {k:v for k,v in panel['source_values'].items() if k != 'predictions'}
                    and summary_panel['source_fidelity'] == {k:v for k,v in panel['source_fidelity'].items() if k != 'rows'},
                    prefix+'/durable_summary_binding')
                if panel_name == 'validation':
                    selected=report['selected'] if role == 'selected' else report['last_complete_attempt']
                    check(panel['predictions'] == read(folder/(role+'-predictions.json'))
                        and panel['report']['metrics'] == selected['numerical']
                        and summary_panel['source_fidelity'] == selected['fidelity'],prefix+'/training_evaluation_replay')
                if mode == 'raw':
                    prior_panel=prior['postfit'][role][panel_name]
                    check(panel['report']['metrics'] == prior_panel['numerical']['metrics']
                        and summary_panel['source_fidelity'] == prior_panel['source_fidelity'],prefix+'/parent_control_metric_parity')
        records.append(dict(arm=arm,selected_epoch=report['selected_epoch'],exposure=exposures,selection=selection,postfit=role_records))
        print(json.dumps(dict(audited_arm=arm,findings=len(findings))),flush=True)
    check(panels == 40,'training/all_forty_complete_control_panels')
    released(args.results)
    return dict(runs=records,panel_count=panels,preprocessing=ctx['preprocessing_audit'],
        scope='Exact raw fit replay, frozen buffers/projection, affine scalar/count logits, actual guidance, saved grammar/fidelity counts, exposure and strict selection.',
        limits='No recurrent rollout, full token-CE recomputation, gradient replay, native logic-family qualification or Lake admission by auditor.')


def readiness(ctx,args):
    import xml.etree.ElementTree as ET
    tests=[]
    for name in ('tests-frozen.xml','scheduler-tests.xml'):
        path=R/name;suites=list(ET.parse(path).getroot().iter('testsuite'))
        totals={key:sum(int(suite.get(key,0)) for suite in suites) for key in ('tests','failures','errors','skipped')}
        check(totals['tests'] > 0 and all(totals[key] == 0 for key in ('failures','errors','skipped')),'tests/clean_complete/'+name)
        artifacts[str(path)]=dict(sha256=sha(path),bytes=path.stat().st_size);tests.append(dict(path=str(path),**totals))
    imports=read(R/'test-import-provenance.json')
    check(imports['pytest_returncode'] == 0,'tests/frozen_source_exit')
    for name,value in imports['modules'].items():
        path=Path(value['path'])
        check((path.is_relative_to(args.source) or path.is_relative_to(args.dependency)) and sha(path) == value['sha256'],
              'tests/authenticated_loaded_module/'+name)
    coverage=read(R/'coverage-diagnosis.json')
    check(coverage['finding_count'] == 0 and coverage['checked_component_occurrences'] == 360
        and coverage['unsupported_validation_label_count'] == 9 and len(coverage['affected_validation_ids']) == 7,
        'coverage/predeclared_postfit_diagnostic_strata')
    return dict(preprocessing=ctx['preprocessing_audit'],tests=tests,
        readiness_scope='Static source/plan/data/pin review and recorded frozen synthetic suites only; no model execution by this audit.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('readiness','diagnostics','results'),required=True)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--plan',type=Path,required=True)
    parser.add_argument('--source',type=Path,default=R/'experiment-source')
    parser.add_argument('--dependency',type=Path,default=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2')
    parser.add_argument('--results',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.output.exists():raise FileExistsError('fresh audit output required')
    ctx=common(args)
    records=(readiness(ctx,args) if args.phase == 'readiness' else diagnostics(args,ctx)
             if args.phase == 'diagnostics' else results(args,ctx))
    extra=dict(plan_sha256=sha(args.plan),manifest_sha256=sha(args.manifest))
    if args.phase == 'diagnostics':extra['diagnostic_summary_sha256']=sha(args.results/'summary.json')
    return save(args,records,extra)


if __name__ == '__main__':raise SystemExit(main())
