"""Arithmetic on saved source-only logits; no decoder/model execution.

Averaging affine-head logits on training features equals that affine head at
training mean, up to stored float rounding. This is not calibrated Bayes.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parent-results', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists(): raise ValueError('fresh output required')
    artifacts, results = {}, []
    for folder in sorted(args.parent_results.iterdir()):
        training_path = folder/'last-attempt/evaluation-training.json'
        if not training_path.exists(): continue
        paths = [training_path, folder/'last-attempt/evaluation-validation.json']
        panels = []
        for path in paths:
            content = path.read_bytes()
            artifacts[str(path.resolve())] = dict(sha256=hashlib.sha256(content).hexdigest(), bytes=len(content))
            panels.append(json.loads(content))
        train, validation = [panel['source_values']['predictions'] for panel in panels]
        if len(train) != 48 or len(validation) != 48 or {row['id'] for row in train} & {row['id'] for row in validation}:
            raise ValueError('complete disjoint original development splits required')
        size = len(train[0]['raw_logits'][0][0])
        mean = [[[math.fsum(row['raw_logits'][slot][field][token] for row in train)/len(train)
            for token in range(size)] for field in range(4)] for slot in range(8)]
        metrics = dict(values=0, raw_correct=0, centered_correct=0, training_mean_only_correct=0,
                       raw_target_margin_sum=0., centered_target_margin_sum=0.)
        for row in validation:
            for slot, labels in enumerate(row['expected_token_ids']):
                for field, target in enumerate(labels):
                    if target < 0: continue
                    values = row['raw_logits'][slot][field]
                    centered = [a-b for a,b in zip(values,mean[slot][field])]
                    metrics['values'] += 1
                    metrics['raw_correct'] += int(max(range(size), key=values.__getitem__) == target)
                    metrics['centered_correct'] += int(max(range(size), key=centered.__getitem__) == target)
                    metrics['training_mean_only_correct'] += int(max(range(size), key=mean[slot][field].__getitem__) == target)
                    metrics['raw_target_margin_sum'] += values[target]-max(value for token,value in enumerate(values) if token != target)
                    metrics['centered_target_margin_sum'] += centered[target]-max(value for token,value in enumerate(centered) if token != target)
        metrics['raw_mean_target_margin'] = metrics.pop('raw_target_margin_sum')/metrics['values']
        metrics['centered_mean_target_margin'] = metrics.pop('centered_target_margin_sum')/metrics['values']
        metrics['mean_training_mean_logit_range'] = math.fsum(max(values)-min(values) for slots in mean for values in slots)/32
        results.append(dict(arm=folder.name, training_ids=[row['id'] for row in train],
                            mean_training_raw_logits=mean, metrics=metrics))
    if len(results) != 8: raise ValueError('exactly eight parent arms required')
    script = Path(__file__).resolve()
    artifacts[str(script)] = dict(sha256=hashlib.sha256(script.read_bytes()).hexdigest(), bytes=script.stat().st_size)
    result = dict(schema='saved-affine-source-prior-diagnostic/v1', results=results, artifacts=artifacts,
        source='Stored last-attempt source-head logits, original 48 training vectors; validation references used only for diagnostic scoring.',
        reference_count_used_for_generation=False, model_executed=False, decoder_executed=False, training_executed=False,
        selection_modified=False, qualified=False, admitted=False, source_semantics_verified=False,
        interpretation=[
            'Raw source-head logits contain a nontrivial source-independent mean which is added to the recurrent decoder at scalar sites.',
            'Centering removes field/type and class priors as well as source-independent offset; it need not improve standalone classification.',
            'These scalar-only numbers cannot predict free-generation fidelity or demonstrate that double-counted priors caused the failures.',
            'Exact affine centering is not a calibrated Bayesian likelihood-ratio claim; a fixed-state generation ablation is required.'])
    args.output.write_text(json.dumps(result, sort_keys=True, indent=2, allow_nan=False)+'\n')
    print(json.dumps([dict(arm=row['arm'], **row['metrics']) for row in results]))


if __name__ == '__main__': main()
