# Mean-centered scalar evidence experiment

This fixed development comparison investigates one training/inference mismatch:
the source-value head is trained as a standalone classifier and its logits are
added to an already conditioned recurrent decoder. Its source-independent
preferences may be counted twice. This is a hypothesis, not an established
causal explanation of all reconstruction failures.

The candidate subtracts the head evaluated at the training-only projected
feature mean from scalar guidance at causal scalar boundaries. Auxiliary
cross-entropy still uses the unmodified head. Gradients flow through both terms;
there is no target-aware gate, detached baseline, forced count, hard syntax
mask, or vocabulary restriction. Count guidance and the recurrent decoder are
unchanged. The correction is not claimed to be a calibrated likelihood ratio.

Phase 1 replays all eight previous final attempts with raw, disabled, and
mean-centered scalar guidance on both original training and previously exposed
development-validation rows. Raw replay must reproduce archived predictions.
No weights are updated or selected by this phase.

Phase 2 compares raw versus mean-centered scalar guidance with center-RMS
normalization and count boundary guidance enabled, for seeds 1729 and 2718.
All four fits start from the same authenticated original initializer, not the
previous fitted attempts. Each fit has the same 340 optimizer steps, source
curriculum, loss, clipping, learning-rate schedule, exposure, and unchanged
per-length source-fidelity selection gates. Phase 1 efficacy does not change
this predeclared four-fit comparison. Raw arms must reproduce their prior
matched fits after accounting for the wrapper state-name prefix.

Source text, reference values, source counts and target prefixes do not enter
free generation. Authenticated targets enter training loss and evaluation only.
The fresh holdout remains unopened. All full outputs, rejected final states,
selected states, and negative controls are retained.

Only actual lake build of the relevant library can confer Lean admission.
This numerical development experiment grants none. It changes neither the
8D linguistic teacher nor any production checkpoint. It uses existing local
384D embeddings with the fixed 512-token encoder context and 512-token output
limit, temperature zero, no downloads, and no external prover execution.
