"""Freeze the reviewed mean-centering experiment without touching shared Git state."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import subprocess

P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
R = Path(__file__).resolve().parent
OLD = P/'workspace/test-logs/decoder-projected-source-20261003'
BASE = json.loads((R/'base.json').read_bytes())['base']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
save = lambda p, v: Path(p).write_text(json.dumps(v, indent=2)+'\n')
changed = ['ipfs_datasets_py/logic/formalization/autoencoder/long_span_source_value_training.py']
new = ['ipfs_datasets_py/logic/formalization/autoencoder/mean_centered_source_decoder_experiment.py',
       'scripts/ops/autoencoder/benchmark_mean_centered_source_reconstruction.py']
new_tests = ['tests/unit/logic/formalization/autoencoder/test_mean_centered_source_decoder_experiment.py',
             'tests/unit/logic/formalization/autoencoder/test_benchmark_mean_centered_source_reconstruction.py']

if __name__ == '__main__':
    assert not (R/'experiment-source').exists(), 'immutable source freeze already exists'
    for name in ('model-ready.json', 'runner-ready.json'):
        ready = json.loads((R/name).read_bytes())
        assert ready.get('ready') is True, name
        for rel, item in ready['files'].items():
            assert sha(P/rel) == (item['sha256'] if isinstance(item, dict) else item), rel
    for rel, digest in json.loads((OLD/'validated-test-source.json').read_bytes()).items():
        assert sha(P/rel) == digest, ('previous tests changed', rel)
    m = json.loads((OLD/'training-manifest.json').read_bytes())
    for rel, digest in m['extensions'].items():
        assert sha(OLD/'experiment-source'/rel) == digest, rel
        assert hashlib.sha256(subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)).hexdigest() == digest, rel
    for rel in changed+new:
        m['extensions'][rel] = sha(P/rel)
    for rel, digest in m['extensions'].items():
        source = P/rel if rel in changed+new else OLD/'experiment-source'/rel
        target = R/'experiment-source'/rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        assert sha(target) == digest, rel
    tests = json.loads((R/'test-files.json').read_bytes())
    tests = list(dict.fromkeys(tests+new_tests))
    save(R/'test-files.json', tests)
    save(R/'validated-test-source.json', {rel:sha(P/rel) for rel in tests})
    save(R/'code-files.json', changed+new+new_tests+['docs/autoencoders/decoder_length_distillation.md'])
    # Manifest input construction is deliberately a separate step: the training
    # phase also pins the completed independent diagnostic review.
    save(R/'frozen-extensions.json', m['extensions'])
    print(json.dumps(dict(extensions=len(m['extensions']),test_files=len(tests))))
