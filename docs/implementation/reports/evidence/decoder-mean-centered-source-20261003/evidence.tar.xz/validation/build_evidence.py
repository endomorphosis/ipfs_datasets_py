"""Seal new mean-centering observations with authenticated predecessor references.

This is packaging only: no model, optimizer, prover, download or publication.
All newly produced observations remain physical members. Historical inputs and
states are exact members of the previous published projected-source archive.
"""
import ast
import lzma
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import xml.etree.ElementTree as ET

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
E=P/'docs/implementation/reports/evidence/decoder-mean-centered-source-20261003'
DOC='docs/autoencoders/decoder_length_distillation.md'
PRIOR_COMMIT='4ecbc3ab8668135f084b1fcd49808c7fbfe8a8dc'
PRIOR_RELATIVE='docs/implementation/reports/evidence/decoder-projected-source-20261003'
PRIOR_ARCHIVE_SHA='e5a0878721ec9134c22c5686b4307c4b49c192fd12dcb363f60a02ac32cb6676'
REPOSITORY='https://github.com/endomorphosis/ipfs_datasets_py'
MAX_ARCHIVE_BYTES=90_000_000
FALSE=dict(qualified=False,admitted=False,proof_authority=False,source_semantics_verified=False,
    convergence_proven=False,fresh_holdout=False,lake_executed=False,formalized=False,
    roundtrip_ok=False,checkpoint_promoted=False,production_checkpoint=False,
    optimizer_resumable=False,native_validation_executed=False)
DYNAMIC={'publication.json','owned-files.json','build-evidence.log','build-evidence-final.log'}


def require(condition,message):
    if not condition:raise ValueError(message)


def read(path):
    def unique(pairs):
        result={}
        for key,value in pairs:
            require(key not in result,'duplicate JSON key: '+key)
            result[key]=value
        return result
    return json.loads(Path(path).read_bytes(),object_pairs_hook=unique)


def sha(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):value.update(block)
    return value.hexdigest()


def info(path):
    path=Path(path)
    require(path.is_file() and not path.is_symlink(),'regular evidence file required: '+str(path))
    return dict(sha256=sha(path),bytes=path.stat().st_size)


def write_new(path,value):
    data=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if path.exists():
        require(path.read_bytes()==data,'existing generated output differs: '+str(path));return
    with path.open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())


def authority(value):
    require(all(value[key] is False for key in FALSE if key in value),'forbidden authority claim')


def passing_tests(path,expected=None):
    result={key:0 for key in ('tests','failures','errors','skipped')}
    for suite in ET.parse(path).getroot().iter('testsuite'):
        for key in result:result[key]+=int(suite.get(key,0))
    require(result['tests']>0 and result['failures']==result['errors']==result['skipped']==0,'complete passing test suite required')
    if expected is not None:require(result['tests']==expected,'test inventory differs')
    return dict(result,junit_sha256=sha(path))


def audit_receipt(filename,phase):
    path=R/filename;value=read(path)
    schema='mean-centered-source-'+('diagnostic' if phase=='diagnostics' else phase)+'-audit/v1'
    require(value.get('schema')==schema and value.get('phase')==phase and value.get('passed') is True
        and value.get('complete') is True and value.get('failed_check_count')==value.get('finding_count')==0
        and value.get('findings')==[],'complete clean audit required: '+filename)
    require(value['audit_source_sha256']==sha(R/'independent_audit.py'),'auditor changed')
    for artifact,expected in value['artifacts'].items():require(info(artifact)==expected,'audited artifact changed: '+artifact)
    authority(value)
    return value


def attempt_for(audit,schema):
    candidates=[]
    for artifact in audit['artifacts']:
        path=Path(artifact)
        if path.is_relative_to(R) and path.name=='summary.json' and path.parent.name=='results':
            if read(path).get('schema')==schema:candidates.append(path.parent.parent)
    require(len(set(candidates))==1,'exactly one audited phase summary required: '+schema)
    return candidates[0]


def phase_bindings(audits,attempts):
    """Use audited bytes, not mutable conventional filenames, after a harness retry."""
    manifests,plans,roots={},{},{}
    runner='scripts/ops/autoencoder/benchmark_mean_centered_source_reconstruction.py'
    for phase,key in [('diagnostic','diagnostics'),('training','results')]:
        audit=audits[key]
        def bound_json(digest,kind):
            paths=[Path(path) for path,entry in audit['artifacts'].items()
                if entry['sha256']==digest and Path(path).suffix=='.json' and Path(path).is_relative_to(R)]
            require(bool(paths),'audited '+kind+' artifact missing')
            values=[read(path) for path in paths]
            require(all(value==values[0] for value in values),'conflicting audited '+kind)
            return values[0]
        manifests[phase]=bound_json(audit['manifest_sha256'],'manifest')
        plans[phase]=bound_json(audit['plan_sha256'],'plan')
        require(manifests[phase]['plan_sha256']==audit['plan_sha256'],'phase plan binding changed')
        sealed=read(attempts[phase]/'results/sealed-recipe.json')
        require(sealed['manifest']==manifests[phase] and sealed['plan']==plans[phase], 'successful phase recipe differs')
        candidates=[]
        for path,entry in audit['artifacts'].items():
            if path.endswith('/'+runner) and entry['sha256']==manifests[phase]['extensions'][runner]:
                root=Path(path[:-len(runner)])
                if root.is_relative_to(R) and root.name.startswith('experiment-source'):candidates.append(root)
        require(len(set(candidates))==1,'one audited frozen source root per phase required')
        roots[phase]=candidates[0]
    old,new=manifests['diagnostic']['extensions'],manifests['training']['extensions']
    changed={key for key in set(old)|set(new) if old.get(key)!=new.get(key)}
    require(changed in (set(),{runner}),'phase source mismatch outside the retry harness')
    if changed:
        before,after=(ast.parse((roots[phase]/runner).read_text()) for phase in ('diagnostic','training'))
        for module in (before,after):
            for function in ('validate_training_parity','training_phase'):
                candidates=[node for node in module.body if isinstance(node,ast.FunctionDef) and node.name==function]
                require(len(candidates)==1,'one explicit raw replay function required: '+function)
                module.body.remove(candidates[0])
        require(ast.dump(before,include_attributes=False)==ast.dump(after,include_attributes=False),
            'retry changed code beyond the two authorized parity functions')
    return manifests,plans,roots


def resources(attempt,phase):
    final,child=read(attempt/'resources-final.json'),read(attempt/'child-exit.json');record=final['record']
    require(final['status']==record['status']=='released' and record['artifacts_durable_asserted'] is True
        and record['attempt_exceeded_reservation'] is False and child['returncode']==0
        and child['leader_reaped'] is True,'durable released successful phase required')
    require(record['cpu_slots']==record['child_process_slots']==1 and record['memory_mb']==4096
        and record['storage_bytes']==800000000 and record['final_accounting']['limit_bytes']==140000000000,
        'resource contract differs')
    observations=read(attempt/'resource-observations.json')
    guardians=[]
    for path in (R/(attempt.name+'-guardian.log'),R/(phase+'-guardian.log')):
        if not path.exists():continue
        # A preserved failed guardian log may contain a traceback, not a success receipt.
        try:value=read(path)
        except json.JSONDecodeError:continue
        if value.get('returncode')==0 and value.get('resources',{}).get('record',{}).get('attempt_directory',{}).get('path')==str(attempt):
            guardians.append(value)
    require(len(guardians)==1,'one completed guardian receipt bound to successful attempt required')
    guardian=guardians[0]
    return dict(guardian_elapsed_seconds=guardian['elapsed_seconds'],
        guardian_elapsed_through_child_exit_seconds=child['guardian_elapsed_through_child_exit_seconds'],
        launch_return_through_reap_wall_seconds=child['launch_return_through_reap_wall_seconds'],
        child_time_scope=child['child_time_scope'],isolated_child_execution_seconds=None,
        owned_output_bytes=record['final_attempt_bytes'],reservation_bytes=record['storage_bytes'],reservation_released=True,
        observed_peak_child_rss_bytes=max((item['group_rss']['rss_bytes'] for item in observations),default=None),
        rss_observation_count=len(observations),storage_cap_unchanged=True,
        final_charged_storage_bytes=record['final_accounting']['charged_bytes'])


def quality(panel):
    report=panel['report'];fidelity=panel['source_fidelity'];values=panel['source_values'];counts=panel['source_count']
    require(report['complete'] is True and len(panel['predictions'])==48 and values['present_values']==720,
        'complete actual generation and raw scalar readouts required')
    authority(report);authority(fidelity)
    return dict(numerical_metrics=report['metrics'],generated=fidelity['metrics'],
        by_length=fidelity['by_length'],by_facet=fidelity['by_facet'],
        raw_auxiliary_source_values=dict(correct=values['correct'],present_values=values['present_values'],
            cross_entropy=values['cross_entropy'],by_length=values['by_length'],
            by_field={key:{k:v for k,v in value.items() if k!='classes'} for key,value in values['by_field'].items()}),
        source_count=dict(correct=counts['correct'],rows=counts['rows'],cross_entropy=counts['cross_entropy']),
        scalar_mode=panel['scalar_mode'],postfit_seconds=panel['timing']['postfit_evaluation_elapsed_seconds'],
        numerical_api_wall_seconds=report['elapsed_seconds'],numerical_api_wall_seconds_per_span=report['wall_seconds_per_span'])


def excluded(path):
    if path.parent==R/'packaging-attempts' and path.name.endswith(('.tar.gz','.tar.xz')):return True
    return any(part in ('.git','.lake','__pycache__') or 'pytest-cache' in part or part=='.pytest_cache'
        for part in path.relative_to(R).parts) or path.suffix in ('.pyc','.pyo','.index')


def main():
    audits={phase:audit_receipt(filename,phase) for phase,filename in
        [('readiness','readiness.json'),('diagnostics','diagnostic-audit.json'),('results','independent-audit.json')]}
    require(audits['readiness']['ready'] is True,'clean readiness required')
    docs=read(R/'docs-ready.json')
    require(docs.get('ready') is True and docs.get('files',{}).get(DOC)==sha(P/DOC),'final documentation binding required')
    phases={'diagnostic':('diagnostics','mean-centered-source-diagnostic-comparison/v1'),
        'training':('results','mean-centered-source-training-comparison/v1')}
    attempts={name:attempt_for(audits[key],schema) for name,(key,schema) in phases.items()}
    summaries={name:read(attempt/'results/summary.json') for name,attempt in attempts.items()}
    diagnostic,training=summaries['diagnostic'],summaries['training']
    require(diagnostic['complete'] is True and len(diagnostic['panels'])==48
        and diagnostic['raw_replay_parity'] is True and diagnostic['training_executed'] is False,
        'all forty-eight fixed-state replay panels required')
    require(training['complete'] is True and len(training['runs'])==4 and training['raw_training_replay_parity'] is True,
        'all four matched fits and exact raw training replay required')
    for value in summaries.values():
        authority(value)
        require(value['workers']==1 and value['bridge_names']==[] and value['paragraph_embedding_cache_used'] is True
            and all(value[key] is False for key in ('legal_ir_evaluate_provers','metric_disk_cache_used',
                'encoder_executed','encoder_context_changed','output_limit_changed','downloads_performed',
                'diagnostic_efficacy_used_to_select_training')),'fixed execution or predeclared training scope differs')
    manifests,plans,source_roots=phase_bindings(audits,attempts)
    # Retry test files are retained alongside the original failing-harness suite.
    retry=source_roots['training']!=source_roots['diagnostic']
    test_suffix='-r2' if retry else ''
    test_pins_path=R/('validated-test-source'+test_suffix+'.json')
    code=read(R/'code-files.json');tests_source=read(test_pins_path)
    require(len(code)==len(set(code))==6 and DOC in code and len(tests_source)==33,'exact owner/test inventory required')
    for name,manifest in manifests.items():
        require(len(manifest['extensions'])==33,'frozen phase source inventory differs')
        for path,expected in manifest['inputs'].items():require(sha(path)==expected,'frozen input changed: '+path)
        for relative,expected in manifest['extensions'].items():
            require(sha(source_roots[name]/relative)==expected,'frozen extension changed: '+relative)
            if name=='training':require(sha(P/relative)==expected,'final canonical extension differs: '+relative)
    for relative,expected in tests_source.items():require(sha(P/relative)==expected,'tested source changed: '+relative)
    tests=passing_tests(R/('tests-frozen'+test_suffix+'.xml'));scheduler_tests=passing_tests(R/'scheduler-tests.xml',34)
    previous_tests=passing_tests(R/'tests-frozen.xml') if retry else None
    retry_receipts=[]
    if retry:
        revision=read(R/'runner-revision-r2-independent.json');failure=read(R/'training-r1-parity-diagnosis.json')
        require(revision.get('schema')=='mean-centered-runner-revision-independent-audit/v1'
            and revision.get('complete') is True and revision.get('passed') is True and revision.get('findings')==[]
            and revision.get('diagnostic_evidence_reuse_justified') is True
            and revision.get('training_phase_exact_except_authenticated_selected_panel_reads_and_helper_argument') is True
            and all(revision[key] is False for key in ('model_math_changed','optimizer_math_changed','qualification_or_selection_gates_changed')),
            'clean independent two-function harness revision audit required')
        require(failure.get('schema')=='mean-centered-training-harness-failure-diagnostic/v1'
            and failure.get('complete') is True and failure.get('exact_greedy_rows')==failure.get('exact_complete_selected_evaluator_rows')==48
            and failure.get('training_updates_completed')==340 and failure.get('failed_attempt_retained') is True
            and failure.get('owned_child_exit_code')==1 and failure.get('live_owned_group_processes')==0,
            'preserved bounded harness failure diagnosis required')
        retry_receipts=[revision,failure]

    prior_folder=P/PRIOR_RELATIVE
    prior=read(prior_folder/'manifest.json');prior_results=read(prior_folder/'results.json')
    for name in ('manifest.json','results.json'):
        path=prior_folder/name
        require(path.read_bytes()==subprocess.check_output(['git','show',PRIOR_COMMIT+':'+str(path.relative_to(P))],cwd=P),
            'predecessor metadata differs from exact published Git commit')
    prior_archive=prior_folder/'evidence.tar.gz'
    require(info(prior_archive)==prior['archive']==prior_results['archive'] and sha(prior_archive)==PRIOR_ARCHIVE_SHA,
        'published predecessor archive changed')
    require(prior_results['complete'] is True and prior['archive_standalone'] is True,'standalone complete predecessor required')
    dependency_id='projected-source-'+PRIOR_COMMIT
    dependency=dict(id=dependency_id,repository=REPOSITORY,git_commit=PRIOR_COMMIT,
        archive=dict(path=PRIOR_RELATIVE+'/evidence.tar.gz',**info(prior_archive)),
        manifest=dict(path=PRIOR_RELATIVE+'/manifest.json',**info(prior_folder/'manifest.json')),
        results=dict(path=PRIOR_RELATIVE+'/results.json',**info(prior_folder/'results.json')),
        retrieval='Read the exact Git blob at git_commit:path and verify SHA-256 and byte length before extraction.',
        contains_all_referenced_members=True)
    files,original_paths,referenced={},{},{}
    def add(name,path,expected=None):
        path=Path(path).absolute();observed=info(path);member=PurePosixPath(name)
        require(not member.is_absolute() and '..' not in member.parts and str(member)==name,'unsafe physical member')
        if expected is not None:require(observed==expected,'physical artifact changed: '+str(path))
        if str(path) in original_paths:
            require(files[original_paths[str(path)]]['info']==observed,'duplicate artifact changed');return
        require(name not in files,'conflicting member: '+name)
        files[name]=dict(path=path,info=observed);original_paths[str(path)]=name
    def reference(path,expected=None):
        path=Path(path).absolute();observed=info(path)
        if expected is not None:require(observed==expected,'referenced artifact changed: '+str(path))
        if path==prior_archive:
            referenced[str(path)]=dict(dependency_id=dependency_id,kind='archive_itself',**observed);return
        require(str(path) in prior['original_artifact_archive_paths'],'historical artifact missing from predecessor: '+str(path))
        member=prior['original_artifact_archive_paths'][str(path)]
        require(prior['members'][member]==observed,'historical member digest differs: '+str(path))
        referenced[str(path)]=dict(dependency_id=dependency_id,kind='archive_member',member=member,**observed)
    def retain(path,expected=None):
        path=Path(path).absolute()
        if str(path) in original_paths:
            if expected is not None:require(info(path)==expected,'physical audited pin differs')
        elif path.is_relative_to(R):add('validation/'+path.relative_to(R).as_posix(),path,expected)
        elif path in (prior_folder/'manifest.json',prior_folder/'results.json'):
            add('predecessor-public/'+path.name,path,expected)
        else:reference(path,expected)

    producers=read(R/'baseline-producer-pins.json');require(len(producers)==94,'complete previous producer closure required')
    producers=dict(producers)
    for relative,expected in manifests['training']['extensions'].items():
        if relative in producers and not relative.endswith('/long_span_source_value_training.py'):
            require(producers[relative]==expected,'unreviewed producer changed: '+relative)
        producers[relative]=expected
    require(len(producers)==96,'exact ninety-six producer closure required')
    producer_files={}
    for relative,expected in producers.items():
        path=(source_roots['training'] if relative in manifests['training']['extensions'] else S)/relative
        require(sha(path)==expected,'frozen producer differs: '+relative);producer_files[relative]=path
    for name,summary in summaries.items():
        for scoped,expected in summary['source_dependencies'].items():
            scope,relative=scoped.split(':',1)
            binding=manifests[name]['extensions'].get(relative,producers.get(relative))
            require(scope in ('dependency','extension') and binding==expected,'loaded producer outside phase-specific frozen closure')
    imports=read(R/('test-import-provenance'+test_suffix+'.json'));require(imports['pytest_returncode']==0,'frozen synthetic imports failed')
    for entry in imports['modules'].values():
        path=Path(entry['path']);root=source_roots['training'] if path.is_relative_to(source_roots['training']) else S
        require(path.is_relative_to(root) and producers.get(path.relative_to(root).as_posix())==entry['sha256']==sha(path),
            'test import escaped frozen closure')
    for relative in sorted(set(code)|set(tests_source)|set(producers)):
        path=producer_files.get(relative,P/relative);expected=producers.get(relative,tests_source.get(relative))
        add('source/'+relative,path,None if expected is None else dict(sha256=expected,bytes=path.stat().st_size))
        canonical=(P/relative).absolute()
        if canonical.is_file() and info(canonical)==files['source/'+relative]['info']:
            original_paths[str(canonical)]='source/'+relative
    for name in ('manifest.json','results.json'):retain(prior_folder/name)
    for manifest in manifests.values():
        for path,expected in manifest['inputs'].items():retain(path,dict(sha256=expected,bytes=Path(path).stat().st_size))
    for name in ('coverage-diagnosis.json','source-prior-diagnosis.json','coverage-results.json'):
        value=read(R/name)
        if name=='coverage-results.json':
            require(value.get('schema')=='authored-source-position-support-results/v1' and value.get('complete') is True
                and value.get('panel_count')==8,'complete eight-panel postfit coverage report required')
        elif name=='source-prior-diagnosis.json':
            require(value.get('schema')=='saved-affine-source-prior-diagnostic/v1' and len(value.get('results',[]))==8,
                'exact eight-arm stored prior diagnosis required')
        else:
            require(value.get('schema')=='authored-source-position-support-diagnostic/v1' and value.get('finding_count')==0
                and value.get('checked_component_occurrences')==360 and value.get('unsupported_validation_label_count')==9,
                'exact clean source-position coverage diagnosis required')
        for path,expected in value.get('artifacts',{}).items():retain(path,expected)
    compatibility=read(R/'resource-compatibility.json')
    for relative,entry,key in (
        ('ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py',compatibility['executed_historical_owner'],'path'),
        ('ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py',compatibility['executed_scheduler'],'executed_path')):
        path=Path(entry[key]);add('historical/dependency-source/'+relative,path,dict(sha256=entry['sha256'],bytes=path.stat().st_size))
    for path in sorted(R.iterdir()):
        if path.is_file() and path.suffix in ('.json','.log','.xml','.py','.txt','.md') and path.name not in DYNAMIC:
            retain(path)
    directories={path for path in R.iterdir() if path.is_dir() and not excluded(path)}
    for directory in sorted(directories):
        for path in sorted(directory.rglob('*')):
            if path.is_file() and not excluded(path):retain(path)
    for receipt in [*audits.values(),*retry_receipts]:
        for path,expected in receipt['artifacts'].items():retain(path,expected)
    # Explicit local helper closure: not all imports necessarily appear in outer receipts.
    module=ast.parse((R/'independent_audit.py').read_text())
    helper_bindings=[ast.literal_eval(node.value) for node in module.body if isinstance(node,ast.Assign)
        and any(isinstance(target,ast.Name) and target.id=='HELPERS' for target in node.targets)]
    require(len(helper_bindings)==1 and set(helper_bindings[0])=={'audit_projected_arithmetic.py','audit_leaf_arithmetic.py'},
        'closed two-helper arithmetic audit contract differs')
    for name,expected in helper_bindings[0].items():
        path=R/name;require(sha(path)==expected,'local audit helper changed');retain(path)
    require(not set(original_paths)&set(referenced),'artifact cannot be both physical and external')
    require(all(set(receipt['artifacts'])<=set(original_paths)|set(referenced) for receipt in [*audits.values(),*retry_receipts]),'incomplete audit artifact closure')
    # Verify every referenced member against the actual published archive bytes too.
    needed={entry['member']:entry for entry in referenced.values() if entry['kind']=='archive_member'}
    with tarfile.open(prior_archive,'r:gz') as bundle:
        checked=set()
        for member in bundle:
            if member.name not in needed:continue
            require(member.isfile(),'referenced member is not regular')
            data=bundle.extractfile(member).read();entry=needed[member.name]
            require(hashlib.sha256(data).hexdigest()==entry['sha256'] and len(data)==entry['bytes'],'referenced bytes differ')
            checked.add(member.name)
        require(checked==set(needed),'reference missing from predecessor bytes')

    diagnostic_table=[]
    for panel in diagnostic['panels']:
        path=attempts['diagnostic']/'results'/panel['state']/panel['mode']/('evaluation-'+panel['split']+'.json')
        value=read(path)
        require(value['scalar_mode']==panel['mode'],'diagnostic mode differs')
        diagnostic_table.append(dict(state=panel['state'],split=panel['split'],
            artifact=dict(path=str(path),**info(path)),raw_replay_verified=panel['raw_replay_parity'] is not None,
            **quality(value)))
    arms=[];panels_count=0
    for run in training['runs']:
        folder=attempts['training']/'results'/run['arm'];report=run['training']
        require(report==read(folder/'training.json') and run['budget_completed'] is True
            and report['stopped_reason']=='epochs_completed' and report['optimizer_steps']==340
            and report['row_presentations']==report['count_training_row_presentations']==2440
            and report['valid_target_token_presentations']==225840 and report['source_value_presentations']==25600,
            'matched complete training exposure required')
        authority(report);states={};controls={}
        for role in ('selected','last-attempt'):
            state_path=folder/(role+'-state.json');state=read(state_path)
            require(state['schema']=='private-mean-centered-source-state/v1' and state['role']==role,'state schema/role differs')
            authority(state)
            states[role]=dict(path=str(state_path),**info(state_path),tensor_sha256=state['tensor_sha256'],
                selected=state['selected'])
            controls[role]={}
            for label,split,control in plans['training']['postfit_controls']:
                path=folder/role/('evaluation-'+label+'.json');value=read(path)
                # Cross-length shuffle uses the existing source_shuffle scorer with separate policy metadata.
                expected_control='source_shuffle' if control=='cross_length_shuffle' else control
                require(value['execution']['kind']==expected_control,'control execution differs')
                controls[role][label]=dict(artifact=dict(path=str(path),**info(path)),**quality(value));panels_count+=1
        reasons={}
        for epoch in report['history']:
            for reason in epoch['rejection_reasons']:reasons[reason]=reasons.get(reason,0)+1
        arms.append(dict(arm=run['arm'],seed=run['seed'],recipe=run['recipe'],
            trainable_parameter_count=run['trainable_parameter_count'],selected_epoch=report['selected_epoch'],
            last_complete_attempt_is_selected=report['last_complete_attempt_is_selected'],
            optimizer_steps=340,decoder_row_presentations=2440,count_row_presentations=2440,
            target_token_presentations=225840,source_value_presentations=25600,
            rejection_reason_counts=reasons,raw_training_replay=run['raw_training_replay'],
            fit_call_wall_seconds=run['training_call_elapsed_seconds'],postfit_wall_seconds=run['postfit_elapsed_seconds'],
            whole_arm_seconds=run['elapsed_seconds'],states=states,controls=controls,**FALSE))
    require(panels_count==40,'exactly forty new trained-state control panels required')
    outputs=[str((E/name).relative_to(P)) for name in ('results.json','manifest.json','evidence.tar.xz')]
    write_new(R/'owned-files.json',code+outputs);retain(R/'owned-files.json')
    require(not E.exists() or not any(E.iterdir()),'public evidence destination must be fresh')
    E.mkdir(parents=True,exist_ok=True);archive=E/'evidence.tar.xz'
    with archive.open('xb') as stream:
        with lzma.LZMAFile(stream,mode='wb',format=lzma.FORMAT_XZ,preset=6) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as bundle:
                for name,entry in sorted(files.items()):
                    require(info(entry['path'])==entry['info'],'physical artifact changed during packaging: '+name)
                    header=tarfile.TarInfo(name);header.size=entry['info']['bytes'];header.mode=0o644;header.mtime=0
                    with entry['path'].open('rb') as source:bundle.addfile(header,source)
        stream.flush();os.fsync(stream.fileno())
    require(all(info(entry['path'])==entry['info'] for entry in files.values()),'physical input changed before sealing')
    require(all(info(path)=={key:entry[key] for key in ('sha256','bytes')} for path,entry in referenced.items()),
        'historical input changed before sealing')
    archive_info=info(archive)
    require(archive_info['bytes']<=MAX_ARCHIVE_BYTES,'archive exceeds 90MB hard cap; do not discard raw observations')
    archive_metadata=dict(archive_filename='evidence.tar.xz',archive_compression='xz',xz_preset=6,archive_standalone=False,archive_dependencies=[dependency],referenced_artifacts=referenced,
        dependency_scope='All new observations are physical members; exact historical input/state bytes require the bound prior Git archive.',
        reproducibility_scope='Artifact closure and original-path mapping; Python, external host libraries and hardware are not bundled.')
    write_new(E/'manifest.json',dict(schema='decoder-mean-centered-source-archive/v1',archive=archive_info,
        members={name:entry['info'] for name,entry in files.items()},original_artifact_archive_paths=original_paths,
        validated_producer_source_sha256=producers,archive_maximum_bytes=MAX_ARCHIVE_BYTES,**archive_metadata,**FALSE))
    audit_summary={phase:dict(path=str(R/filename),sha256=sha(R/filename),checks=audits[phase]['checks'],
        findings=audits[phase]['findings'],audited_artifacts=len(audits[phase]['artifacts']))
        for phase,filename in [('readiness','readiness.json'),('diagnostics','diagnostic-audit.json'),('results','independent-audit.json')]}
    results=dict(schema='decoder-mean-centered-source-results/v1',complete=True,
        outcome='Mean-centering did not establish a general reconstruction improvement: generated scalar fidelity improved for one seed and worsened for the other; all four validation exact counts remained zero and selected states remained epoch zero.',
        scope='Fixed-state causal raw/off/mean-centered scalar guidance followed by predeclared matched raw/centered joint training',
        diagnostic_panel_count=48,diagnostic_table=diagnostic_table,raw_diagnostic_replay_verified=True,
        training_fit_count=4,training_arms=arms,trained_state_control_panel_count=40,
        raw_training_replay_verified=True,diagnostic_efficacy_used_to_select_training=False,
        selected_checkpoint_epochs=[run['selected_epoch'] for run in arms],
        selected_nonbaseline_checkpoint_present=any(run['selected_epoch']>0 for run in arms),
        dimensions_actually_trained=[384],historical_8d_teacher_modified=False,actual_768d_training_performed=False,
        training_rows=48,validation_rows=48,clauses_per_paragraph=[1,2,4,8],
        encoder_context_tokens=512,decoder_output_limit=512,generation_temperature=0,
        training_executed=True,generation_executed=True,optimizer_executed=True,
        candidate_sha256={relative:sha(P/relative) for relative in code},
        independent_audit_sha256=sha(R/'independent-audit.json'),diagnostic_audit_sha256=sha(R/'diagnostic-audit.json'),
        independent_audits=audit_summary,tests=tests,additional_scheduler_tests=scheduler_tests,
        pre_retry_tests=previous_tests,parity_harness_retry=retry,
        retry_evidence=None if not retry else dict(revision_audit_sha256=sha(R/'runner-revision-r2-independent.json'),
            failed_attempt_diagnosis_sha256=sha(R/'training-r1-parity-diagnosis.json'),
            failed_attempt_training_updates=340,failed_attempt_resources_retained=True),
        retry_scope=None if not retry else 'Preserved first attempt rejected an envelope comparison after exact tensor and token replay; only the two authorized replay-validation functions changed, and the complete matched run was repeated.',
        coverage_results=dict(path=str(R/'coverage-results.json'),**info(R/'coverage-results.json')),
        telemetry=dict(device='cpu',workers=1,bridge_names=[],legal_ir_evaluate_provers=False,
            legal_ir_bridge_evaluation_performed=False,bridge_on_evaluate_seconds=None,metric_disk_cache_used=False,
            paragraph_embedding_cache_used=True,encoder_executed=False,use_sample_memory=False,
            diagnostic_runner_wall_seconds=diagnostic['elapsed_seconds'],
            fit_call_wall_seconds_total=sum(run['fit_call_wall_seconds'] for run in arms),
            postfit_wall_seconds_total=sum(run['postfit_wall_seconds'] for run in arms),
            phases={phase:resources(attempt,phase) for phase,attempt in attempts.items()},
            workload='Cached-embedding decoder diagnostics and private matched training; not bridge-on legal conversion timings'),
        limitations=['Previously exposed authored development rows; no fresh held-out convergence claim.',
            'Raw auxiliary head scores and potential guidance residuals are different quantities; centering is not calibrated Bayesian prior correction.',
            'Stored scalar guidance arrays cover every slot, not visited generation sites; they are not an actual-prefix trace.',
            'Generated source fidelity and unchanged strict selection gates determine model acceptance; raw head accuracy alone does not.',
            'Nine unseen validation slot labels affect only seven validation documents and cannot explain all zero-exact outcomes; no matched reordered sources establish order sensitivity.',
            'All authored qualifiers are empty; populated exceptions, temporal semantics and complete logic-family coverage remain unestablished.',
            'No native family or Lake admission, production promotion, global convergence, or Constitution formalization is established.',
            'All raw new outputs are retained; original inputs and historical fitted states require the exact predecessor archive.'],
        archive=archive_info,**archive_metadata,**FALSE)
    write_new(E/'results.json',results)
    require((E/'results.json').stat().st_size<1500000,'public results unexpectedly duplicate raw reports')
    # Post-seal byte validation covers every physical member, not just the input list.
    with tarfile.open(archive,'r:xz') as bundle:
        entries=bundle.getmembers();require(len(entries)==len(files) and {v.name for v in entries}==set(files),'sealed membership differs')
        for member in entries:
            require(member.isfile(),'sealed member not regular');data=bundle.extractfile(member).read()
            require(dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))==files[member.name]['info'],'sealed member bytes differ')
    print(json.dumps(dict(archive=archive_info,members=len(files),referenced_artifacts=len(referenced),
        producers=len(producers),test_files=len(tests_source),owned_files=len(code)+3,
        diagnostic_panels=48,fits=4,trained_state_control_panels=40,
        results=info(E/'results.json'),manifest=info(E/'manifest.json'))))


if __name__=='__main__':main()
