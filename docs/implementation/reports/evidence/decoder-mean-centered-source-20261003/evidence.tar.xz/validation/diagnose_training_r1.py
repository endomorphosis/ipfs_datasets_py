"""Read-only saved-artifact diagnosis of the first training harness abort."""
from pathlib import Path
import hashlib
import json

R=Path(__file__).resolve().parent
P=R.parents[2]
OLD=P/'workspace/test-logs/decoder-projected-source-20261003'
artifacts={}


def read(path):
    content=path.read_bytes();artifacts[str(path)]=dict(sha256=hashlib.sha256(content).hexdigest(),bytes=len(content))
    return json.loads(content)


def main():
    output=R/'training-r1-parity-diagnosis.json'
    if output.exists():raise FileExistsError('fresh evidence required')
    folder=R/'training-r1/results/raw-1729'
    report=read(folder/'training.json');actual=read(folder/'selected/evaluation-validation.json')
    prior=read(OLD/'training-r1/results/summary.json')
    original=next(run for run in prior['runs'] if run['arm']=='center_rms-boundary-1729')
    narrow=original['initial_greedy_invariance']['predictions']['validation']
    full_path=OLD/'training-r1/results/center_rms-boundary-1729/selected/evaluation-validation.json'
    full=read(full_path)
    public=read(P/'docs/implementation/reports/evidence/decoder-projected-source-20261003/manifest.json')
    for path in (OLD/'training-r1/results/summary.json',full_path):
        member=public['original_artifact_archive_paths'][str(path)]
        assert public['members'][member]==artifacts[str(path)]
    fields=('id','token_ids','generation_status','eos_reached')
    projected=lambda rows:[{key:row[key] for key in fields} for row in rows]
    assert len(actual['predictions'])==len(narrow)==48
    assert projected(actual['predictions'])==narrow
    assert actual['predictions']==full['predictions']
    assert report['optimizer_steps']==340 and report['row_presentations']==2440
    assert report['valid_target_token_presentations']==225840 and report['source_value_presentations']==25600
    assert report['stopped_reason']=='epochs_completed' and report['selected_epoch']==0
    child=read(R/'training-r1/child-exit.json');failure=read(R/'training-r1/failure.json')
    log=R/'training-r1/child.log';content=log.read_bytes();artifacts[str(log)]=dict(sha256=hashlib.sha256(content).hexdigest(),bytes=len(content))
    assert b'raw selected generation differs from prior initial-selected state' in content
    assert child['returncode']==1 and child['leader_reaped'] is True
    assert failure['cleanup']['live_group_processes']==0
    script=Path(__file__).resolve();content=script.read_bytes();artifacts[str(script)]=dict(sha256=hashlib.sha256(content).hexdigest(),bytes=len(content))
    result=dict(schema='mean-centered-training-harness-failure-diagnostic/v1',complete=True,
        attempt='training-r1',failure_stage='postfit raw selected-prediction parity comparison',
        finding='Full evaluator records were compared directly with the narrower original greedy inventory.',
        expected_greedy_fields=list(fields),extra_evaluator_fields=['exact_target','reconstructed_input'],
        exact_greedy_rows=48,exact_complete_selected_evaluator_rows=48,
        training_updates_completed=340,decoder_rows_presented=2440,target_tokens_presented=225840,
        source_values_presented=25600,selected_epoch=0,checkpoint_promoted=False,
        failed_attempt_retained=True,resource_status=failure['resources']['status'],
        owned_child_exit_code=1,live_owned_group_processes=0,
        model_executed_by_diagnosis=False,training_executed_by_diagnosis=False,qualified=False,admitted=False,
        source_semantics_verified=False,selection_changed=False,artifacts=artifacts)
    output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(dict(path=str(output),exact_greedy_rows=48,exact_full_rows=48,training_updates=340)))


if __name__=='__main__':main()
