"""Preserve revision one and freeze a reporting-only runner correction."""
from pathlib import Path
import ast
import hashlib
import json
import shutil

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
RUNNER='scripts/ops/autoencoder/benchmark_mean_centered_source_reconstruction.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n')

if __name__=='__main__':
    assert not (R/'experiment-source-r2').exists()
    ready=json.loads((R/'runner-ready-r2.json').read_bytes())
    assert ready['ready'] is True
    for rel,value in ready['files'].items():
        assert sha(P/rel)==(value['sha256'] if isinstance(value,dict) else value),rel
    before=ast.parse((R/'experiment-source'/RUNNER).read_text())
    after=ast.parse((P/RUNNER).read_text())
    def nodes(tree):
        return {getattr(node,'name','statement:'+str(i)):ast.dump(node,include_attributes=False)
                for i,node in enumerate(tree.body)}
    old,new=nodes(before),nodes(after)
    assert set(old)==set(new)
    changed=[name for name in old if old[name]!=new[name]]
    assert set(changed)=={'validate_training_parity','training_phase'},changed
    pins=json.loads((R/'frozen-extensions.json').read_bytes())
    for rel,digest in pins.items():assert sha(R/'experiment-source'/rel)==digest,rel
    pins[RUNNER]=sha(P/RUNNER)
    for rel,digest in pins.items():
        source=P/rel if rel==RUNNER else R/'experiment-source'/rel
        target=R/'experiment-source-r2'/rel
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
        assert sha(target)==digest
    save(R/'frozen-extensions-r2.json',pins)
    tests=json.loads((R/'test-files.json').read_bytes())
    save(R/'validated-test-source-r2.json',{rel:sha(P/rel) for rel in tests})
    test_script=(R/'run_frozen_tests.py').read_text()
    for old_name,new_name in [('experiment-source','experiment-source-r2'),
        ('tests-frozen.xml','tests-frozen-r2.xml'),('test-import-provenance.json','test-import-provenance-r2.json'),
        ('pytest-cache','pytest-cache-r2')]:
        test_script=test_script.replace(old_name,new_name)
    (R/'run_frozen_r2_tests.py').write_text(test_script)
    guardian=(R/'run_training_reserved.py').read_text()
    guardian=guardian.replace("choices=('diagnostic','training')", "choices=('training',)")
    guardian=guardian.replace("args.phase+'-manifest.json'", "args.phase+'-r2-manifest.json'")
    guardian=guardian.replace('experiment-source','experiment-source-r2')
    guardian=guardian.replace("'run_training_reserved.py'", "'run_training_r2_reserved.py'")
    (R/'run_training_r2_reserved.py').write_text(guardian)
    save(R/'runner-r2-ast-check.json',dict(changed_functions=changed,
        original_source_sha256=sha(R/'experiment-source'/RUNNER),
        corrected_source_sha256=sha(R/'experiment-source-r2'/RUNNER),
        original_source_preserved=True,diagnostic_functions_unchanged=True))
    print(json.dumps(dict(extensions=len(pins),test_files=len(tests),changed_functions=changed)))
