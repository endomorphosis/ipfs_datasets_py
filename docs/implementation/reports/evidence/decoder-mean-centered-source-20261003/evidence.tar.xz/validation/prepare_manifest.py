"""Bind a phase to frozen producers and authenticated local predecessor evidence."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
R = Path(__file__).resolve().parent
OLD = P/'workspace/test-logs/decoder-projected-source-20261003'
E = P/'docs/implementation/reports/evidence/decoder-projected-source-20261003'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()

if __name__ == '__main__':
    phase = sys.argv[1]
    assert phase in ('diagnostic', 'training')
    destination = R/(phase+'-manifest.json')
    assert not destination.exists(), 'immutable phase manifest already exists'
    runner = R/'experiment-source/scripts/ops/autoencoder/benchmark_mean_centered_source_reconstruction.py'
    spec = importlib.util.spec_from_file_location('_fixed_centering_recipe', runner)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    m = json.loads((OLD/'training-manifest.json').read_bytes())
    m['extensions'] = json.loads((R/'frozen-extensions.json').read_bytes())
    m['inputs'] = {m[key]: sha(m[key]) for key in ('donor','paragraphs','embeddings','curriculum','curriculum_inputs')}
    m.update(parent_public_manifest=str(E/'manifest.json'), parent_public_results=str(E/'results.json'),
        parent_summary=str(OLD/'training-r1/results/summary.json'),
        parent_preprocessing=str(OLD/'training-r1/results/preprocessing.json'))
    m['state_catalog'] = module.expected_catalog(Path(m['parent_summary']).parent)
    for key in ('parent_public_manifest','parent_public_results','parent_summary','parent_preprocessing'):
        m['inputs'][m[key]] = sha(m[key])
    for item in m['state_catalog']:
        for path in [item['state_path'], *item['archived_evaluations'].values()]:
            m['inputs'][path] = sha(path)
    if phase == 'training':
        m.update(diagnostic_summary=str(R/'diagnostic-r1/results/summary.json'),
                 diagnostic_audit=str(R/'diagnostic-audit.json'),
                 diagnostic_plan=str(R/'diagnostic-plan.json'),
                 diagnostic_manifest=str(R/'diagnostic-manifest.json'))
        for key in ('diagnostic_summary', 'diagnostic_audit', 'diagnostic_plan', 'diagnostic_manifest'):
            m['inputs'][m[key]] = sha(m[key])
    plan = module.DIAGNOSTIC_FIXED if phase == 'diagnostic' else module.TRAINING_FIXED
    plan_path = R/(phase+'-plan.json')
    assert json.loads(plan_path.read_bytes()) == plan, 'predeclared plan changed'
    m['plan_sha256'] = sha(plan_path)
    destination.write_text(json.dumps(m, indent=2)+'\n')
    print(json.dumps(dict(phase=phase,inputs=len(m['inputs']),extensions=len(m['extensions']))))
