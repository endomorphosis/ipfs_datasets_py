"""Persisted authored-source coverage checks, without executing a model.

Optional evaluation panels are scored after the fixed experiment only. These
support strata do not participate in training, selection, or qualification.
"""
from collections import Counter, defaultdict
from pathlib import Path
import argparse
import hashlib
import json

FIELDS = ('actor', 'action', 'modality', 'object')
CORPUS_SHA = 'd8418379af64cdce826ae29f9ce9014248d164ab33da417b9585d0329c82dbef'
FALSE = dict(model_executed=False, training_executed=False, native_executed=False,
             selection_modified=False, qualified=False, admitted=False,
             source_semantics_verified=False, fresh_holdout=False)


def digest_text(value):
    return hashlib.sha256(value.encode()).hexdigest()


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)


def read(path, artifacts):
    path = Path(path).resolve()
    content = path.read_bytes()
    artifacts[str(path)] = dict(sha256=hashlib.sha256(content).hexdigest(), bytes=len(content))
    return json.loads(content)


def analyze(corpus):
    findings, component_checks, unsupported = [], [], []
    supports = {(slot, field): Counter() for slot in range(8) for field in FIELDS}
    for row in corpus['train']:
        for slot, rule in enumerate(row['target']['rules']):
            for field in FIELDS:
                supports[slot, field][rule[field]] += 1
    pairsets = {}
    repeated_bags = {}
    for split in ('train', 'validation'):
        bags = defaultdict(list)
        pairsets[split] = sorted({(rule['actor'], rule['action']) for row in corpus[split] for rule in row['target']['rules']})
        for row in corpus[split]:
            source, rules = row['source_text'], row['target']['rules']
            if len(rules) != len(row['components']) or row['clause_count'] != len(rules):
                findings.append(dict(id=row['id'], error='component cardinality mismatch'))
            bag = tuple(sorted(raw(rule) for rule in rules))
            bags[bag].append(dict(id=row['id'], ordered_rules_sha256=digest_text(raw(rules))))
            if digest_text(source) != row['source_sha256']:
                findings.append(dict(id=row['id'], error='paragraph source digest mismatch'))
            slices = []
            for slot, (component, rule) in enumerate(zip(row['components'], rules)):
                text = source[component['char_start']:component['char_end']]
                slices.append(text)
                lower = text.casefold()
                modality = ('F' if 'must not' in lower or 'forbidden' in lower else
                            'P' if ' may ' in lower or 'allowed' in lower else 'O')
                checks = dict(
                    ordered_position=component['position'] == slot,
                    target_component_identity=row['target_component_ids'][slot] == component['id'],
                    exact_source_sha256=digest_text(text) == component['source_sha256'],
                    normalized_source_sha256=digest_text(' '.join(text.casefold().split())) == component['normalized_source_sha256'],
                    byte_offsets=source.encode()[component['byte_start']:component['byte_end']] == text.encode(),
                    target_sha256=digest_text(raw({'rules': [rule]})) == component['target_sha256'],
                    scalar_slot=component['logical_slot'] == [rule['actor'], rule['action'], rule['object']],
                    authored_words=all(rule[field].casefold() in lower for field in ('actor', 'action', 'object')),
                    authored_modality=modality == rule['modality'])
                component_checks.append(dict(paragraph_id=row['id'], component_id=component['id'], slot=slot, checks=checks))
                if not all(checks.values()):
                    findings.append(component_checks[-1])
                if split == 'validation':
                    for field in FIELDS:
                        if rule[field] not in supports[slot, field]:
                            unsupported.append(dict(id=row['id'], component_id=component['id'], clause_count=len(rules),
                                zero_based_slot=slot, field=field, expected=rule[field],
                                training_slot_labels=dict(sorted(supports[slot, field].items()))))
            if '\n\n'.join(slices) != source:
                findings.append(dict(id=row['id'], error='source concatenation mismatch'))
        repeated_bags[split] = [values for values in bags.values() if len(values) > 1]
    pair_overlap = sorted(set(pairsets['train']) & set(pairsets['validation']))
    multi_rule_permutations = [values for split in repeated_bags.values() for values in split
        if len({v['ordered_rules_sha256'] for v in values}) > 1]
    return dict(schema='authored-source-position-support-diagnostic/v1', **FALSE,
        corpus_rows={split: len(corpus[split]) for split in ('train', 'validation')},
        rule_occurrences={split: sum(len(row['target']['rules']) for row in corpus[split]) for split in ('train', 'validation')},
        distinct_paragraphs_per_slot=[sum(len(row['target']['rules']) > slot for row in corpus['train']) for slot in range(8)],
        training_support=[dict(zero_based_slot=slot, field=field, classes=dict(sorted(counter.items())))
            for (slot, field), counter in supports.items()],
        unsupported_validation_labels=unsupported,
        unsupported_validation_label_count=len(unsupported),
        affected_validation_ids=sorted({row['id'] for row in unsupported}),
        actor_action_pairs=pairsets, actor_action_pair_overlap=pair_overlap,
        repeated_rule_bags=repeated_bags, matched_order_permutation_pairs=multi_rule_permutations,
        component_checks=component_checks, checked_component_occurrences=len(component_checks),
        findings=findings, finding_count=len(findings),
        interpretation=[
            'Template/source consistency is a narrow check of these authored development inputs, not independent natural-language semantic qualification.',
            'All validation actor/action pairs are held out while individual scalar classes have global training support.',
            'Position-specific heads have uneven distinct-example coverage; unsupported labels are not proof of impossibility for the complete autoregressive decoder.',
            'There are no matched multi-rule order permutations here; cached paragraph vectors alone do not directly identify order sensitivity.',
            'Mean-centering source guidance does not add missing position-label coverage.'])


def strict_parse_prediction(prediction, vocabulary):
    ids = prediction['token_ids']
    if not ids or ids[0] != 1 or ids[-1] != 2 or any(type(i) is not int or i < 3 or i >= len(vocabulary) for i in ids[1:-1]):
        return None
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result: raise ValueError('duplicate key')
            result[key] = value
        return result
    try:
        value = json.loads(''.join(vocabulary[i] for i in ids[1:-1]), object_pairs_hook=unique)
    except (ValueError, TypeError):
        return None
    return value if isinstance(value, dict) else None


def stratify(corpus, diagnosis, panel):
    unsupported = {(v['id'], v['zero_based_slot'], v['field']) for v in diagnosis['unsupported_validation_labels']}
    affected = {value[0] for value in unsupported}
    expected = {row['id']: row for row in corpus['validation']}
    predictions = {row['id']: row for row in panel['predictions']}
    head = {row['id']: row for row in panel['source_values']['predictions']}
    if set(expected) != set(predictions) or set(expected) != set(head):
        raise ValueError('complete original 48-row validation panel required')
    values = {key: Counter() for key in ('supported', 'unsupported')}
    rows = {key: Counter() for key in ('all_slots_supported', 'has_unsupported_slot_label')}
    details = []
    vocab = corpus['codec']['target_vocabulary']
    for identity, reference in expected.items():
        generated = strict_parse_prediction(predictions[identity], vocab)
        rules = generated.get('rules', []) if generated else []
        if not isinstance(rules, list): rules = []
        key = 'has_unsupported_slot_label' if identity in affected else 'all_slots_supported'
        rows[key]['rows'] += 1
        rows[key]['exact_target'] += int(generated == reference['target'])
        rows[key]['eos_reached'] += int(predictions[identity]['eos_reached'])
        for slot, rule in enumerate(reference['target']['rules']):
            for field_index, field in enumerate(FIELDS):
                support = 'unsupported' if (identity, slot, field) in unsupported else 'supported'
                scores = values[support]
                scores['values'] += 1
                token = vocab.index(raw(rule[field]))
                if head[identity]['expected_token_ids'][slot][field_index] != token:
                    raise ValueError('saved auxiliary reference differs from source corpus')
                head_correct = head[identity]['predicted_token_ids'][slot][field_index] == token
                generated_correct = slot < len(rules) and isinstance(rules[slot], dict) and rules[slot].get(field) == rule[field]
                scores['source_head_correct'] += int(head_correct)
                scores['generated_scalar_correct'] += int(generated_correct)
                if support == 'unsupported':
                    details.append(dict(id=identity, zero_based_slot=slot, field=field, expected=rule[field],
                        source_head_correct=head_correct, generated_scalar_correct=generated_correct))
    return dict(scope='Postfit diagnostic only: missing/malformed scalar outputs count as incorrect; strict JSON parsing does not confer syntax qualification.',
        scalar_strata={k: dict(v) for k, v in values.items()}, row_strata={k: dict(v) for k, v in rows.items()},
        unsupported_details=details, used_for_selection=False, **FALSE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus', required=True, type=Path)
    parser.add_argument('--panel', action='append', default=[], type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists(): raise ValueError('fresh output required')
    artifacts = {}
    corpus = read(args.corpus, artifacts)
    if artifacts[str(args.corpus.resolve())]['sha256'] != CORPUS_SHA: raise ValueError('original corpus digest mismatch')
    result = analyze(corpus)
    result['stratified_panels'] = [dict(path=str(path.resolve()), diagnostic=stratify(corpus, result, read(path, artifacts))) for path in args.panel]
    artifacts[str(Path(__file__).resolve())] = dict(sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), bytes=Path(__file__).stat().st_size)
    result['artifacts'] = artifacts
    args.output.write_text(json.dumps(result, sort_keys=True, indent=2, allow_nan=False)+'\n')
    print(json.dumps({k: result[k] for k in ('finding_count', 'checked_component_occurrences', 'unsupported_validation_label_count', 'affected_validation_ids')}))
    if result['findings']: raise SystemExit(1)


if __name__ == '__main__': main()
