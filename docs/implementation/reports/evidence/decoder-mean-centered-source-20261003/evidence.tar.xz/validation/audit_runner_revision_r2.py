"""Verify the bounded prediction-envelope repair without running models."""
from pathlib import Path
import ast
import copy
import hashlib
import json

R=Path(__file__).resolve().parent
P=R.parents[2]
REL='scripts/ops/autoencoder/benchmark_mean_centered_source_reconstruction.py'
OLD_SHA='6a45b35a65fa4b297572585491b63c310dd943d6662b7b6704f6a50a63ede55c'
NEW_SHA='54ff78ecd9ed03df94ad84f9c02f826de042fe0937c1692305c68ae51aeb0724'
artifacts={}


def pin(path):
    content=path.read_bytes();value=dict(sha256=hashlib.sha256(content).hexdigest(),bytes=len(content))
    artifacts[str(path)]=value
    return value['sha256']


def parsed(path):
    pin(path)
    return ast.parse(path.read_text())


def dump(node):return ast.dump(node,include_attributes=False)


def main():
    destination=R/'runner-revision-r2-independent.json'
    if destination.exists():raise FileExistsError('fresh revision receipt required')
    old_path=R/'experiment-source'/REL;new_path=P/REL
    assert pin(old_path)==OLD_SHA and pin(new_path)==NEW_SHA
    old,new=parsed(old_path),parsed(new_path)
    old_functions={node.name:node for node in old.body if isinstance(node,ast.FunctionDef)}
    new_functions={node.name:node for node in new.body if isinstance(node,ast.FunctionDef)}
    assert old_functions.keys()==new_functions.keys()
    changed=[name for name in old_functions if dump(old_functions[name])!=dump(new_functions[name])]
    assert changed==['validate_training_parity','training_phase']
    # Exact training-phase equivalence after removing only authenticated selected
    # panel reads and the corresponding pure receipt argument.
    phase=copy.deepcopy(new_functions['training_phase'])
    expected=ast.parse("""
selected_paths={'center_rms-boundary-'+str(seed):str(Path(ctx['manifest']['parent_summary']).parent/('center_rms-boundary-'+str(seed))/'selected'/'evaluation-validation.json') for seed in plan['seed_order']}
require(ctx['manifest'].get('prior_selected_evaluations')==selected_paths,'exact two prior selected evaluation bindings required')
selected_evaluations={arm:ctx['archives'].read_bound(path,ctx['manifest'],ctx['public']) for arm,path in selected_paths.items()}
""").body
    for statement in expected:
        matches=[index for index,node in enumerate(phase.body) if dump(node)==dump(statement)]
        assert len(matches)==1
        phase.body.pop(matches[0])
    calls=[node for node in ast.walk(phase) if isinstance(node,ast.Call)
           and isinstance(node.func,ast.Name) and node.func.id=='validate_training_parity']
    assert len(calls)==1 and len(calls[0].keywords)==1
    assert calls[0].keywords[0].arg=='archived_selected'
    assert dump(calls[0].keywords[0].value)==dump(ast.parse("selected_evaluations[prior_arm]",mode='eval').body)
    calls[0].keywords=[]
    assert dump(phase)==dump(old_functions['training_phase'])
    # The reviewed helper adds strict envelope checks, exact four-field greedy
    # comparison, and a stronger six-field original-evaluator comparison.
    helper=new_functions['validate_training_parity']
    assert [arg.arg for arg in helper.args.kwonlyargs]==['archived_selected']
    text=ast.unparse(helper)
    for term in ('numerical_fields',"{'exact_target', 'reconstructed_input'}",'core.digest(selected)',"archived_selected['predictions']"):
        assert term in text
    before=copy.deepcopy(old);after=copy.deepcopy(new)
    before.body=[node for node in before.body if not isinstance(node,ast.FunctionDef) or node.name not in changed]
    after.body=[node for node in after.body if not isinstance(node,ast.FunctionDef) or node.name not in changed]
    assert dump(before)==dump(after)
    for phase_name in ('diagnostic_phase','load_context','evaluate','guidance_diagnostic','validate_preprocessing','restore_prior','fresh_base','wrap'):
        assert dump(old_functions[phase_name])==dump(new_functions[phase_name])
    diagnosis_path=R/'training-r1-parity-diagnosis.json';pin(diagnosis_path);diagnosis=json.loads(diagnosis_path.read_bytes())
    assert diagnosis['complete'] is True and diagnosis['exact_greedy_rows']==diagnosis['exact_complete_selected_evaluator_rows']==48
    for name in ('diagnostic-plan.json','training-plan.json','diagnostic-manifest.json','readiness.json','diagnostic-audit.json'):
        pin(R/name)
    script=Path(__file__).resolve();pin(script)
    result=dict(schema='mean-centered-runner-revision-independent-audit/v1',revision=2,complete=True,passed=True,findings=[],
        old_runner_path=str(old_path),old_runner_sha256=OLD_SHA,new_runner_path=str(new_path),new_runner_sha256=NEW_SHA,
        changed_functions=changed,unchanged_functions=[name for name in old_functions if name not in changed],
        training_phase_exact_except_authenticated_selected_panel_reads_and_helper_argument=True,
        full_module_exact_except_two_reviewed_functions=True,
        diagnostic_execution_functions_unchanged=True,model_math_changed=False,optimizer_math_changed=False,
        qualification_or_selection_gates_changed=False,diagnostic_evidence_reuse_justified=True,
        previous_diagnostic_rerun_required=False,
        revision_reason='Compare exact generated evidence at matching record schemas; preserve initial greedy check and add exact full numerical-record parity against authenticated prior selected evaluations.',
        old_artifacts_preserved=True,failed_attempt_diagnosis=str(diagnosis_path),
        qualified=False,admitted=False,model_executed=False,training_executed=False,native_executed=False,
        limits='Static source/data-envelope audit; new frozen synthetic tests and guarded complete training are separate prerequisites.',artifacts=artifacts)
    destination.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(dict(path=str(destination),sha256=pin(destination),changed_functions=changed,passed=True)))


if __name__=='__main__':main()
