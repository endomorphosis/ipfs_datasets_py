"""Postfit support strata from saved, token-bound fidelity rows; no model run.

The original coverage_diagnosis.py's optional panel helper assumed BOS/EOS were
retained. That helper was never used in the pinned source-only diagnosis. This
owner uses the runtime's actual format: generated IDs exclude special tokens,
EOS is explicit, and invalid rules receive no scalar-fidelity credit.
"""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import re

R=Path(__file__).resolve().parent
FIELDS=('actor','action','modality','object')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.output.exists():raise FileExistsError('fresh output required')
    artifacts={}
    def read(path):
        path=path.resolve();content=path.read_bytes()
        artifacts[str(path)]=dict(sha256=hashlib.sha256(content).hexdigest(),bytes=len(content))
        return json.loads(content)
    diagnosis=read(R/'coverage-diagnosis.json')
    unsupported={(r['id'],r['zero_based_slot'],r['field']) for r in diagnosis['unsupported_validation_labels']}
    affected={x[0] for x in unsupported}
    summary=read(args.results/'summary.json')
    assert summary['complete'] is True and len(summary['runs'])==4
    corpus_path=next(Path(path) for path in diagnosis['artifacts'] if Path(path).name=='paragraphs.json')
    corpus=read(corpus_path);vocab=corpus['codec']['target_vocabulary']
    references={row['id']:row for row in corpus['validation']}
    panels=[]
    for run in summary['runs']:
        for role in ('selected','last-attempt'):
            path=args.results/run['arm']/role/'evaluation-validation.json';panel=read(path)
            predictions={row['id']:row for row in panel['predictions']}
            fidelity={row['id']:row for row in panel['source_fidelity']['rows']}
            heads={row['id']:row for row in panel['source_values']['predictions']}
            assert set(references)==set(predictions)==set(fidelity)==set(heads)
            values={k:Counter() for k in ('supported','unsupported')}
            rows={k:Counter() for k in ('all_slots_supported','has_unsupported_slot_label')}
            details=[]
            for identity,reference in references.items():
                prediction=predictions[identity];record=fidelity[identity];head=heads[identity]
                assert record['expected_ir']==reference['target'] and record['generated_token_ids']==prediction['token_ids']
                actual=record['generated_ir']
                if actual is not None:
                    assert all(type(token) is int and 3<=token<len(vocab) for token in prediction['token_ids'])
                    assert json.loads(''.join(vocab[token] for token in prediction['token_ids']))==actual
                generated=actual['rules'] if isinstance(actual,dict) and set(actual)=={'rules'} and isinstance(actual['rules'],list) else []
                invalid={int(match.group(1)) for error in record['errors'] for match in [re.match(r'rule\[(\d+)\]:',error)] if match}
                valid={slot:rule for slot,rule in enumerate(generated) if slot not in invalid}
                exact=prediction['eos_reached'] and not record['errors'] and actual==reference['target']
                assert int(exact)==record['counts']['ordered_exact']
                rowkey='has_unsupported_slot_label' if identity in affected else 'all_slots_supported'
                rows[rowkey]['rows']+=1;rows[rowkey]['ordered_exact']+=int(exact)
                rows[rowkey]['eos_reached']+=int(prediction['eos_reached'])
                for slot,rule in enumerate(reference['target']['rules']):
                    for index,field in enumerate(FIELDS):
                        key='unsupported' if (identity,slot,field) in unsupported else 'supported'
                        expected=vocab.index(json.dumps(rule[field],ensure_ascii=True))
                        assert head['expected_token_ids'][slot][index]==expected
                        hit=head['predicted_token_ids'][slot][index]==expected
                        generated_hit=slot in valid and valid[slot][field]==rule[field]
                        values[key]['values']+=1;values[key]['raw_source_head_correct']+=int(hit)
                        values[key]['generated_scalar_correct']+=int(generated_hit)
                        if key=='unsupported':details.append(dict(id=identity,zero_based_slot=slot,field=field,
                            expected=rule[field],raw_source_head_correct=hit,generated_scalar_correct=generated_hit))
            assert sum(v['raw_source_head_correct'] for v in values.values())==panel['source_values']['correct']
            assert sum(v['generated_scalar_correct'] for v in values.values())==sum(panel['source_fidelity']['by_facet'][field]['correct'] for field in FIELDS)
            assert sum(v['ordered_exact'] for v in rows.values())==panel['source_fidelity']['metrics']['ordered_exact']
            assert values['unsupported']['values']==9 and values['supported']['values']==711
            assert rows['has_unsupported_slot_label']['rows']==7 and rows['all_slots_supported']['rows']==41
            panels.append(dict(arm=run['arm'],role=role,path=str(path),scalar_strata={k:dict(v) for k,v in values.items()},
                document_strata={k:dict(v) for k,v in rows.items()},unsupported_details=details,used_for_selection=False))
    script=Path(__file__).resolve();artifacts[str(script)]=dict(sha256=hashlib.sha256(script.read_bytes()).hexdigest(),bytes=script.stat().st_size)
    result=dict(schema='authored-source-position-support-results/v1',complete=True,panels=panels,panel_count=len(panels),
        source_diagnosis_sha256=artifacts[str(R/'coverage-diagnosis.json')]['sha256'],artifacts=artifacts,
        model_executed=False,training_executed=False,selection_modified=False,qualified=False,admitted=False,
        source_semantics_verified=False,fresh_holdout=False,
        prior_unused_helper_issue='Source-only coverage receipt remains valid. Its optional panel helper assumed BOS/EOS in generated arrays and was never executed; this separate scorer uses actual saved-token/EOS and valid-rule semantics.',
        scope='Original 48 exposed validation rows; per-slot training-support strata are postfit diagnostics, never acceptance criteria.')
    args.output.write_text(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print(json.dumps([dict(arm=p['arm'],role=p['role'],scalar_strata=p['scalar_strata'],document_strata=p['document_strata']) for p in panels]))


if __name__=='__main__':main()
