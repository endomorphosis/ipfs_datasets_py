#!/usr/bin/env python3
"""Prepare immutable exposed development inputs; no package/model imports.

This local evidence driver preserves the original 180/60 split and token codec.
It grants no teacher, strict-training, source-semantic, or proof qualification.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys

WORKSPACE = Path('/home/barberb/lift_coding')
REPO = WORKSPACE / 'external/ipfs_datasets'
WORK = REPO / 'workspace/test-logs/decoder-distillation-limits-20261002'
DATA = WORKSPACE / 'artifacts/source-reconstruction-v2-20261001/run-01/legal_ir'
ORIGINAL = WORKSPACE / 'artifacts/legal-ir-inference-speed-review/audit/baseline_tree'
S2 = REPO / 'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
ASSETS = Path('/home/barberb/.cache/huggingface/hub/models--thenlper--gte-small/snapshots/17e1f347d17fe144873b1201da91788898c639cd')
PINS = {
    'raw_ce-1729-checkpoint.json': '6e3f4d731d798aa2732afc37bd74fec34da3267a323844975d2dab78f59f9c61',
    'train.json': 'f4ad1d39677ed3184d019ad8556bf0cabd0957f855281c64343e8dfd73319c7b',
    'validation.json': '4b55671a16186773dd65fa9b4b2d51aa7677e4ef89504e55b9937b1f9594fac7',
}
FALSE = dict(qualified=False, admitted=False, proof_authority=False,
             source_semantics_verified=False, training_executed=False,
             neural_inference_executed=False, strict_training_allowed=False,
             checkpoint_promoted=False, fresh_holdout=False)
TOKEN = re.compile(r'"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"'
                   r'|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?'
                   r'|true|false|null|[{}\[\],:]')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('utf-8')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(value):
    return sha(raw(value))


def unique(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, 'duplicate JSON key')
        value[key] = item
    return value


def parse(data):
    return json.loads(data, object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def file_receipt(path):
    path = Path(path)
    require(path.is_file(), f'missing regular input: {path}')
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
    return {'path': str(path), 'resolved_path': str(path.resolve()),
            'bytes': path.stat().st_size, 'sha256': h.hexdigest(),
            'symlink': path.is_symlink()}


def read(path, inputs, expected=None):
    receipt = file_receipt(path)
    require(receipt['bytes'] <= 16 * 1024 * 1024, 'JSON input exceeds bound')
    if expected is not None:
        require(receipt['sha256'] == expected, f'input hash mismatch: {path}')
    data = Path(path).read_bytes()
    require(sha(data) == receipt['sha256'], 'input changed while reading')
    inputs[str(path)] = receipt
    return parse(data)


def token_ids(target, vocabulary):
    require(type(vocabulary) is list and len(vocabulary) == len(set(vocabulary))
            and vocabulary[:3] == ['<pad>', '<bos>', '<eos>'], 'invalid original vocabulary')
    text = raw(target).decode('utf-8')
    tokens = TOKEN.findall(text)
    require(''.join(tokens) == text and len(tokens) <= 1022, 'unconsumed or oversized target')
    by_token = {token: index for index, token in enumerate(vocabulary)}
    require(all(token in by_token for token in tokens), 'target outside original donor vocabulary')
    encoded = [1] + [by_token[token] for token in tokens] + [2]
    require(all(index >= 3 for index in encoded[1:-1]), 'special token inside target')
    require(raw(parse(''.join(vocabulary[index] for index in encoded[1:-1]))) == raw(target),
            'target tokenization did not preserve every typed field')
    return encoded


def prepare_split(name, document, checkpoint):
    expected_count = {'train': 180, 'validation': 60}[name]
    require(type(document) is dict and set(document) == {'rows', 'source_embeddings'}, 'closed original dataset required')
    rows = document['rows']
    require(type(rows) is list and len(rows) == expected_count, 'original complete split required')
    provenance = document['source_embeddings']
    require(provenance == checkpoint['config']['embedding_provenance'], 'embedding provenance differs from donor')
    require(provenance['dimension'] == 384 and provenance['truncated'] is False
            and provenance['model_id'] == 'thenlper/gte-small'
            and provenance['revision'] == '17e1f347d17fe144873b1201da91788898c639cd'
            and provenance['device'] == 'cuda' and provenance['dtype'] == 'float32'
            and provenance['normalized'] is True and provenance['max_tokens_observed'] <= 512,
            'unverified, relabeled or truncated embedding cohort')
    manifest = checkpoint['training_manifest' if name == 'train' else 'validation_manifest']
    require(type(manifest) is list and len(manifest) == len(rows), 'original manifest count differs')
    prepared, metadata, identities = [], [], []
    for row, original in zip(rows, manifest):
        require(type(row) is dict and type(row.get('id')) is str and row['id']
                and type(row.get('source_text')) is str and row['source_text'].strip()
                and type(row.get('group_id')) is str and row['group_id']
                and row.get('split') == name, 'source identity/group/split missing')
        require(row.get('source_semantics_verified') is False and row.get('proof_authority') is False,
                'original weak reference authority changed')
        require(row.get('truncated', False) is False, 'row was truncated')
        embedding = row['embedding']
        require(type(embedding) is list and len(embedding) == 384
                and all(type(v) in (int, float) and math.isfinite(v) for v in embedding),
                'finite genuine 384D embedding required')
        require(abs(sum(v * v for v in embedding) - 1.0) < 1e-4, 'cached L2 normalization differs')
        entry = {'id': row['id'], 'source_sha256': sha(row['source_text'].encode('utf-8')),
                 'normalized_source_sha256': sha(' '.join(row['source_text'].casefold().split()).encode('utf-8')),
                 'target_sha256': digest(row['target']), 'embedding_sha256': digest(embedding)}
        require(entry == original, 'exact original per-row manifest mismatch')
        require(row.get('source_sha256') == entry['source_sha256']
                and row.get('embedding_sha256') == entry['embedding_sha256'], 'retained row digest differs')
        require(type(row.get('embedding_token_ids_sha256')) is str
                and re.fullmatch('[0-9a-f]{64}', row['embedding_token_ids_sha256']), 'token-input receipt absent')
        encoded = token_ids(row['target'], checkpoint['codec']['target_vocabulary'])
        require(len(encoded) <= checkpoint['config']['max_target_tokens'], 'target exceeds original output limit')
        prepared.append({'id': row['id'], 'source_text': row['source_text'],
                         'input': embedding, 'target_ids': encoded})
        metadata.append({'original_row_without_embedding': {k: v for k, v in row.items() if k != 'embedding'},
                         'original_manifest_entry': original,
                         'target_tokens_including_bos_eos': len(encoded)})
        identities.append({**entry, 'group_id': row['group_id']})
    for field in ('id', 'source_sha256', 'normalized_source_sha256', 'embedding_sha256'):
        require(len({entry[field] for entry in identities}) == len(rows), f'duplicate within split: {field}')
    return prepared, metadata, identities


def check_split_exclusion(left, right):
    fields = ('id', 'group_id', 'source_sha256', 'normalized_source_sha256', 'embedding_sha256')
    for field in fields:
        require(not ({row[field] for row in left} & {row[field] for row in right}),
                f'train/validation leakage: {field}')
    return {field: {'overlap': 0, 'train_unique': len({row[field] for row in left}),
                    'validation_unique': len({row[field] for row in right})} for field in fields}


def source_compatibility(checkpoint, inputs):
    implementation = checkpoint['implementation']
    pins = {'ipfs_datasets_py/logic/formalization/autoencoder/source_training_v2.py': implementation['runtime_sha256'],
            'ipfs_datasets_py/optimizers/logic_theorem_optimizer/domain_384_autoencoder.py': implementation['native']['runtime']}
    pins.update({name.replace('.', '/') + '.py': value
                 for name, value in implementation['native']['dependencies'].items()})
    directories = {'canonical_contracts.py': 'logic/legal_ir', 'tree_pin.py': 'logic/autoformal'}
    for name, value in implementation['numerical']['files'].items():
        relative = 'ipfs_datasets_py/' + directories.get(name, 'optimizers/logic_theorem_optimizer') + '/' + name
        require(relative not in pins or pins[relative] == value, 'contradictory implementation pin')
        pins[relative] = value
    require(len(pins) == 14, 'original listed implementation inventory changed')
    inventories = {}
    for label, tree in [('original_donor_sources', ORIGINAL), ('canonical_compiler_tree', S2)]:
        records = []
        for relative, expected in sorted(pins.items()):
            receipt = file_receipt(tree / relative)
            inputs[receipt['path']] = receipt
            records.append({'relative_path': relative, 'expected_donor_sha256': expected,
                            'matches_donor': receipt['sha256'] == expected, **receipt})
        inventories[label] = {'root': str(tree), 'files': records,
                              'mismatches': [r['relative_path'] for r in records if not r['matches_donor']]}
    require(not inventories['original_donor_sources']['mismatches'], 'original donor source authentication failed')
    require(inventories['canonical_compiler_tree']['mismatches'] == ['ipfs_datasets_py/logic/ui_ux_ir/decoder.py'],
            'canonical S2 drift differs from explicitly reviewed UI decoder change')
    inventories['scope'] = 'listed source-byte authentication only; no transitive import or numerical replay'
    inventories['canonical_compiler_tree_changed'] = False
    inventories['checkpoint_pins_rewritten'] = False
    inventories['original_runtime_compatible_with_S2'] = False
    inventories['numerical_owner_matches_original'] = True
    return inventories


def readiness(inputs):
    base = REPO / 'workspace/test-logs'
    linguistic_path = base / 'legacy-teacher-release-20261001/integrated/historical_blank_en/trained-checkpoint/manifest.json'
    linguistic = read(linguistic_path, inputs, 'f0fca433cbe8cfc4a8700c9e7325b79bc6e3d5ec73f067260b9ac61920f72bb1')
    require(linguistic['formula_head_present'] is False and linguistic['dimension'] == 8, 'linguistic lineage changed')
    core = file_receipt(linguistic_path.parent / linguistic['core_file'])
    require(core['sha256'] == linguistic['core_sha256'] and core['bytes'] == linguistic['core_bytes'], 'linguistic core changed')
    inputs[core['path']] = core
    learned_path = base / 'modal-joint-e2e-20261001-final/legacy_v1/formula-head.json'
    learned = read(learned_path, inputs, 'ffca84492b81ab94fa291ae6ddbe52cfc84318f3516a22f901d468de255b6cbe')
    require(learned['binding']['dimension'] == 8 and learned['training_count'] == 2 and learned['tuning_count'] == 2
            and learned['qualified'] is False, 'experimental 8D scope changed')
    native_path = WORKSPACE / 'artifacts/gte-multilingual-preparation-20261001/embed-01/receipts.json'
    native = read(native_path, inputs, '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570')
    require(native == [], '768D availability changed; review new native receipts separately')
    model_dirs = [WORKSPACE / 'artifacts/gte-multilingual-assets' / name for name in ('model', 'code')]
    require(all(not path.exists() for path in model_dirs), '768D asset availability changed; review new assets separately')
    ui_dir = base / 'ui-modal-coverage-20261002/smoke-r3/results'
    ui = read(ui_dir / 'summary.json', inputs, '2f4143c10e07b51e1d77c91d7b6482624933359ae787f12995782a30110b191d')
    require(ui['attempt_count'] == 23 and ui['actual_Lake_pass_count'] == 9
            and ui['strict_training_allowed_count'] == 0 and ui['neural_inference_executed'] is False,
            'prior authored UI evidence scope changed')
    lengths = [{'id': row['id'], 'tokens_including_bos_eos': row['decoder_target_tokens_including_bos_eos'],
                'prior_preparation_status': row['status']} for row in ui['attempts']]
    require(len(lengths) == 23 and min(row['tokens_including_bos_eos'] for row in lengths) == 575
            and max(row['tokens_including_bos_eos'] for row in lengths) == 759, 'prior UI length inventory changed')
    return {'schema': 'decoder-distillation-local-readiness/v1', **FALSE,
        'dimension8_linguistic': {'status': 'not_trainable_as_learned_token_decoder',
            'reason': 'Preserved linguistic feature runtime has no learned formula/token head; its existing feature training is a separate path.',
            'manifest': str(linguistic_path), 'modified': False},
        'dimension8_learned': {'status': 'synthetic_development_only', 'checkpoint': str(learned_path),
            'training_count': 2, 'tuning_count': 2, 'independent_holdout_available': False,
            'reason': 'Separate experimental authored synthetic head, not the full historical teacher; no teacher qualification.'},
        'dimension384': {'status': 'prepared_exposed_train_and_tuning', 'train_count': 180,
            'validation_count': 60, 'test_opened': False, 'fresh_holdout': False,
            'representation': 'original GTE-small CUDA float32 normalized cached vectors; no regeneration'},
        'dimension768': {'status': 'unavailable', 'native_receipts': str(native_path), 'native_receipt_count': 0,
            'missing_configured_directories': [str(path) for path in model_dirs],
            'search_scope': 'configured local artifact directories and existing receipt only', 'downloads_performed': False},
        'ui_compound_targets': {'status': 'unsupported_decoder_grammar_and_existing_token_limit',
            'case_count': 23, 'lengths': lengths, 'minimum_tokens': 575, 'maximum_tokens': 759,
            'current_source_decoder_limit': 64, 'inherited_primary_head_limit': 512,
            'authored_Lake_pass_count': 9, 'strict_training_allowed_count': 0,
            'reason': 'Prior native authored contracts are not model outputs. Output-limit experiments do not add the unsupported compound target grammar.'}}


def write_new(path, value):
    data = json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False).encode() + b'\n'
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    return file_receipt(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    output = args.output.absolute()
    require(output.parent.resolve() == WORK.resolve() and not output.exists(), 'fresh output must be a direct workfolder child')
    inputs = {str(Path(__file__).resolve()): file_receipt(Path(__file__).resolve())}
    intent = read(WORK / 'intent.json', inputs)
    require(intent['downloads_allowed'] is False and intent['encoder_context_changed'] is False
            and intent['inference_temperature'] == 0 and intent['frozen_dependency_tree'] == str(S2), 'experiment intent changed')
    checkpoint = read(DATA / 'raw_ce-1729-checkpoint.json', inputs, PINS['raw_ce-1729-checkpoint.json'])
    require(checkpoint['schema'] == 'shared-source-384-autoencoder/v2'
            and checkpoint['domain_id'] == 'legal_ir' and checkpoint['dimension'] == 384
            and digest(checkpoint['model_state']) == checkpoint['weights_sha256']
            and checkpoint['codec']['schema'] == 'typed-json-lexical/v1', 'donor identity/state/codec invalid')
    require(checkpoint['input_transform'] == {'mode': 'none', 'mean': [0.0] * 384,
            'scale': 1.0, 'origin': 'training_only'}, 'original input transform changed')
    prepared, metadata, identities = {}, {}, {}
    for name in ('train', 'validation'):
        document = read(DATA / (name + '.json'), inputs, PINS[name + '.json'])
        prepared[name], metadata[name], identities[name] = prepare_split(name, document, checkpoint)
    exclusion = check_split_exclusion(identities['train'], identities['validation'])
    provenance = checkpoint['config']['embedding_provenance']
    assets = provenance['assets']
    require(len(assets) == 9 and len({a['name'] for a in assets}) == 9, 'complete original nine-asset inventory required')
    for item in assets:
        relative = Path(item['name'])
        require(not relative.is_absolute() and '..' not in relative.parts, 'unsafe original asset name')
        receipt = file_receipt(ASSETS / relative)
        require(receipt['sha256'] == item['sha256'] and receipt['bytes'] == item['bytes'], 'original embedding asset mismatch')
        inputs[receipt['path']] = receipt
    compatibility = source_compatibility(checkpoint, inputs)
    ready = readiness(inputs)
    meta = {'schema': 'decoder-distillation-original-data-provenance/v1', **FALSE,
        'splits': metadata, 'split_exclusion': exclusion, 'embedding_provenance': provenance,
        'source_compatibility': compatibility, 'original_codec': checkpoint['codec'],
        'target_encoding': 'original canonical JSON lexical tokens, BOS=1, EOS=2, no PAD, no truncation',
        'vocabulary_fitted': False, 'embedding_inference_executed': False,
        'token_input_hash_scope': 'original recorded token-ID digests retained and file-bound; no tokenizer reexecution',
        'test_files_opened': [], 'rows_selected_or_removed': 0, 'context_assembly_changed': False}
    # Recheck every retained input before writing; concurrent drift never becomes a successful preparation.
    for path, receipt in inputs.items():
        require(file_receipt(path) == receipt, f'input changed during preparation: {path}')
    output.mkdir()
    outputs = {}
    for name in ('train', 'validation'):
        outputs[name] = write_new(output / ('prepared384-' + name + '.json'), prepared[name])
    outputs['metadata'] = write_new(output / 'metadata384.json', meta)
    outputs['readiness'] = write_new(output / 'readiness.json', ready)
    manifest = {'schema': 'decoder-distillation-data-preparation/v1', **FALSE,
        'status': 'complete_development_inputs_only', 'inputs': list(inputs.values()), 'outputs': outputs,
        'train_count': 180, 'validation_count': 60, 'split_exclusion': exclusion,
        'target_lengths_including_bos_eos': sorted({len(row['target_ids']) for rows in prepared.values() for row in rows}),
        'vocabulary_size': len(checkpoint['codec']['target_vocabulary']), 'test_files_opened': [],
        'source_compatibility': compatibility, 'original_checkpoint_sha256': PINS['raw_ce-1729-checkpoint.json']}
    write_new(output / 'manifest.json', manifest)
    descriptor = os.open(output, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    print(json.dumps({'status': manifest['status'], 'output': str(output), 'train': 180, 'validation': 60,
                      'target_lengths': manifest['target_lengths_including_bos_eos'], **FALSE}, sort_keys=True))


if __name__ == '__main__':
    main()
