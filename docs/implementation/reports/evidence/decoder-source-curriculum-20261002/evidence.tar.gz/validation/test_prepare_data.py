"""Pure data guards; no model imports or archived-file mutations."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest

SPEC = importlib.util.spec_from_file_location('preparation_under_test', Path(__file__).with_name('prepare_data.py'))
p = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(p)


class PreparationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.checkpoint = json.loads((p.DATA / 'raw_ce-1729-checkpoint.json').read_text())
        cls.train = json.loads((p.DATA / 'train.json').read_text())
        cls.validation = json.loads((p.DATA / 'validation.json').read_text())

    def rejects_row_mutation(self, mutate):
        data = copy.deepcopy(self.train)
        mutate(data['rows'][0])
        with self.assertRaises(ValueError):
            p.prepare_split('train', data, self.checkpoint)

    def test_complete_identity_and_no_mutation(self):
        before = p.digest(self.train)
        rows, meta, ids = p.prepare_split('train', self.train, self.checkpoint)
        self.assertEqual(len(rows), 180)
        self.assertEqual(p.digest(self.train), before)
        self.assertTrue(all(set(row) == {'id', 'source_text', 'input', 'target_ids'} for row in rows))
        self.assertTrue(all(row['target_ids'][0] == 1 and row['target_ids'][-1] == 2
                            and len(row['target_ids']) == 40 for row in rows))
        self.assertEqual(len(meta), len(ids))

    def test_source_mutation(self):
        self.rejects_row_mutation(lambda row: row.update(source_text=row['source_text'] + ' '))

    def test_target_mutation(self):
        self.rejects_row_mutation(lambda row: row['target']['rules'][0].update(modality='F'))

    def test_embedding_mutation(self):
        self.rejects_row_mutation(lambda row: row['embedding'].__setitem__(0, 0.1))

    def test_nonfinite_embedding(self):
        self.rejects_row_mutation(lambda row: row['embedding'].__setitem__(0, float('nan')))

    def test_wrong_width(self):
        self.rejects_row_mutation(lambda row: row['embedding'].pop())

    def test_boolean_embedding(self):
        self.rejects_row_mutation(lambda row: row['embedding'].__setitem__(0, True))

    def test_wrong_split(self):
        self.rejects_row_mutation(lambda row: row.update(split='test'))

    def test_false_authority(self):
        self.rejects_row_mutation(lambda row: row.update(proof_authority=True))

    def test_truncated_row(self):
        self.rejects_row_mutation(lambda row: row.update(truncated=True))

    def test_missing_token_receipt(self):
        self.rejects_row_mutation(lambda row: row.pop('embedding_token_ids_sha256'))

    def test_no_selection(self):
        data = copy.deepcopy(self.train)
        data['rows'].pop()
        with self.assertRaises(ValueError):
            p.prepare_split('train', data, self.checkpoint)

    def test_truncated_provenance(self):
        data = copy.deepcopy(self.train)
        data['source_embeddings']['truncated'] = True
        with self.assertRaises(ValueError):
            p.prepare_split('train', data, self.checkpoint)

    def test_original_manifest_order_required(self):
        data = copy.deepcopy(self.train)
        data['rows'][0], data['rows'][1] = data['rows'][1], data['rows'][0]
        with self.assertRaises(ValueError):
            p.prepare_split('train', data, self.checkpoint)

    def test_each_cross_split_exclusion(self):
        _, _, train = p.prepare_split('train', self.train, self.checkpoint)
        _, _, validation = p.prepare_split('validation', self.validation, self.checkpoint)
        checks = p.check_split_exclusion(train, validation)
        for field in checks:
            with self.subTest(field=field):
                changed = copy.deepcopy(validation)
                changed[0][field] = train[0][field]
                with self.assertRaises(ValueError):
                    p.check_split_exclusion(train, changed)

    def test_unknown_token_never_added(self):
        target = copy.deepcopy(self.train['rows'][0]['target'])
        target['rules'][0]['actor'] = 'new_name'
        vocab = copy.deepcopy(self.checkpoint['codec']['target_vocabulary'])
        before = list(vocab)
        with self.assertRaises(ValueError):
            p.token_ids(target, vocab)
        self.assertEqual(vocab, before)

    def test_closed_json(self):
        for text in ('{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                p.parse(text)


if __name__ == '__main__':
    unittest.main()
