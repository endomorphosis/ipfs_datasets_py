"""Offline train/tuning-only retained-head diagnostic, no optimizer step."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

REPO = Path('/home/barberb/lift_coding/external/ipfs_datasets')
EXPORT = REPO/'workspace/test-logs/reconstruction-training-release-20261001/source'
RUN = REPO/'workspace/test-logs/reconstruction-training-release-20261001/current-training-r4'
OUT = Path(__file__).parent
sys.path.insert(0, str(EXPORT))
import torch
torch.set_num_threads(1)
from scripts.ops.legal_ir import evaluate_actor_composition_curriculum as shared
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import modal_latent_formula as learning
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import modal_joint_formula as joint
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_runtime_registry as runtimes

result = json.loads((RUN/'raw_gain10_v1-result.json').read_text())
report = json.loads((RUN/'report.json').read_text())
for path, digest in report['plan']['source_hashes'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
_, panel, prepared, samples = shared.prepared_inputs(RUN/'inputs')
targets = {part: shared.read_reference(prepared['files'][part]) for part in ('training','tuning')}
runtime = runtimes.open_runtime('legal_ir','current_v2', **result['profile']['core_options'])
rows = {part: joint._rows(runtime.model,[samples[row['id']] for row in panel.rows(part)], targets[part])
        for part in ('training','tuning')}
head_path = Path(result['head']['path'])
original_sha = hashlib.sha256(head_path.read_bytes()).hexdigest()
assert original_sha == result['head']['sha256']
checkpoint = learning.load_checkpoint(head_path, expected_sha256=original_sha)
decoder = learning.LatentFormulaDecoder(checkpoint)
codec = checkpoint['codec']; vocab=codec['target_vocabulary']; model=decoder.model

def trace(row, *, gold_prefix):
    target = learning.codec_module.encode_target(codec,row['canonical_ir'])
    prefix = [learning.codec_module.TARGET_BOS]
    records = []
    with torch.no_grad():
        latent=torch.tensor([row['latent']],dtype=torch.float32)
        hidden=model.start(model.project(latent))
        for step in range(63):
            allowed=learning.codec_module.allowed_token_ids(codec,prefix)
            logits,hidden=model.next_logits(torch.tensor([[prefix[-1]]]),hidden)
            scores=logits[0,-1,allowed]; probabilities=scores.softmax(-1)
            order=torch.argsort(scores,descending=True,stable=True)
            chosen=allowed[int(order[0])]
            # A free-running prefix may have inserted/omitted list items. Only
            # compare to the gold next token while the whole prefix agrees;
            # later free probabilities are observed without target alignment.
            aligned = prefix == target[:len(prefix)]
            expected=target[step+1] if aligned and step+1<len(target) else None
            if len(allowed)>1:
                records.append(dict(step=step+1,gold_prefix_aligned=aligned,
                    expected_token=vocab[expected] if expected is not None else None,
                    chosen_token=vocab[chosen], correct=chosen==expected if expected is not None else None,
                    expected_probability=float(probabilities[allowed.index(expected)]) if expected in allowed else None,
                    expected_rank=next((i+1 for i,idx in enumerate(order) if allowed[int(idx)]==expected),None),
                    top=[dict(token=vocab[allowed[int(idx)]], probability=float(probabilities[idx])) for idx in order[:4]]))
            prefix.append(expected if gold_prefix else chosen)
            if prefix[-1]==learning.codec_module.TARGET_EOS: break
    return records

def cosine(a,b):
    return float(torch.nn.functional.cosine_similarity(a.reshape(1,-1),b.reshape(1,-1)))

with torch.no_grad():
    train_latent=torch.tensor([row['latent'] for row in rows['training']],dtype=torch.float32)
    tune_latent=torch.tensor([row['latent'] for row in rows['tuning']],dtype=torch.float32)
    representations={
        'raw':(train_latent,tune_latent),
        'projected':(model.project(train_latent),model.project(tune_latent)),
        'condition':(model.start(model.project(train_latent))[0],model.start(model.project(tune_latent))[0])}
    nearest=[]
    for i,row in enumerate(rows['tuning']):
        nn={}
        for name,(train,tune) in representations.items():
            ranked=sorted([(cosine(train[j],tune[i]),j) for j in range(len(train))],reverse=True)[:3]
            nn[name]=[dict(cosine=score,source_text=rows['training'][j]['source_text'],
                          target=rows['training'][j]['canonical_ir']) for score,j in ranked]
        nearest.append(dict(id=row['id'],source_text=row['source_text'],expected=row['canonical_ir'],
            predicted=next(r['canonical_ir'] for r in result['outputs']['tuning']['rows'] if r['id']==row['id']),
            free=trace(row,gold_prefix=False),teacher_forced=trace(row,gold_prefix=True),nearest=nn))

parameters=list(model.named_parameters())
gradients={}
for part in ('training','tuning'):
    loss,formula,mse,tokens=learning._loss(model,rows[part],codec,checkpoint['config'])
    gradients[part]={}
    for name,objective in [('joint',loss),('formula',formula),('reconstruction',mse)]:
        values=torch.autograd.grad(objective,[v for _,v in parameters],retain_graph=True,allow_unused=True)
        gradients[part][name]={n:torch.zeros_like(p) if v is None else v for (n,p),v in zip(parameters,values)}
gradient_alignment={}
for objective in ('joint','formula','reconstruction'):
    gradient_alignment[objective]={}
    for group in ('all','projection','decoder'):
        names=[n for n,_ in parameters if group=='all' or n.startswith('projection_')==(group=='projection')]
        vectors=[torch.cat([gradients[part][objective][n].reshape(-1) for n in names]) for part in ('training','tuning')]
        gradient_alignment[objective][group]=dict(cosine=cosine(*vectors),train_norm=float(vectors[0].norm()),tune_norm=float(vectors[1].norm()))

losses=result['training']['report']['batch_losses']
windows=[]
for start in range(0,1000,100):
    block=losses[start:start+100]
    windows.append(dict(first_step=start+1,last_step=start+len(block),
       **{key:dict(mean=statistics.mean(item[key] for item in block),min=min(item[key] for item in block),
                   max=max(item[key] for item in block)) for key in ('token_cross_entropy','reconstruction_mse','joint_loss')}))
decoder._check()
assert hashlib.sha256(head_path.read_bytes()).hexdigest()==original_sha
for path,digest in report['plan']['source_hashes'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
output=dict(schema='retained-formula-composition-diagnosis/v1',source_hashes=report['plan']['source_hashes'],
    checkpoint_sha256=original_sha,partitions_read=['training','tuning'],sealed_targets_read=False,
    training_executed=False,optimizer_steps=0,parameter_mutation=False,seed_count=1,
    before_after_tuning_trajectory_available=False,tuning_details=nearest,gradient_alignment=gradient_alignment,
    training_loss_windows=windows,admitted=False,formalized=False,qualified=False,roundtrip_ok=False)
(OUT/'report.json').write_text(json.dumps(output,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(report=str(OUT/'report.json'),head_sha256=original_sha,rows=len(nearest),training_executed=False)))
