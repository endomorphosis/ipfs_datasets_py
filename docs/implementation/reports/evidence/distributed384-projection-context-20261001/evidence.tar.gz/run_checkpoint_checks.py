"""Development replay: actual merged checkpoints; caller-authored formulas are not model output."""
import argparse
import json
from pathlib import Path

from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384 import contracts as c
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.qualification import qualify_round, CONTEXTS_SCHEMA
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.projection_context_contract import bind_context
from ipfs_datasets_py.logic.formalization.autoencoder.structured_source_384 import Runtime
from ipfs_datasets_py.optimizers.logic_theorem_optimizer.authored_semantic_projection_panel import FORMULAS
from tests.unit.logic.formalization.autoencoder.test_distributed_384_projection_inputs import unit_for

parser = argparse.ArgumentParser()
parser.add_argument('--previous-run', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--lake', required=True)
parser.add_argument('--java', required=True)
parser.add_argument('--sany-jar', required=True)
args = parser.parse_args()
families = ['first_order', 'deontic', 'temporal', 'tdfol', 'event_calculus', 'dcec', 'frame_logic', 'propositional']
results = []
for domain in ('intent_ir', 'security_ir', 'ui_ux_ir', 'legal_ir'):
    old = args.previous_run/domain
    checkpoint_path = json.loads((old/'merged-result.json').read_text())['checkpoint_path']
    checkpoint, checkpoint_ref = c.read_json_bound(checkpoint_path)
    plan = json.loads((old/'coordinator/plan.json').read_text())
    source = json.loads((old/'coordinator/validation.json').read_text())[0]
    # Drop all labels before inference. Context is bound to this actual output.
    row = {key: source[key] for key in ('id', 'source_text', 'embedding')}
    prediction = Runtime(checkpoint).infer([row])['rows'][0]
    inputs = {'formula_inputs': [{'requirement_id': key, 'formula': value} for key, value in FORMULAS.items()]}
    if domain == 'security_ir':
        # This is authored non-CVE Python fixture context; polarity is explicit.
        inputs['code_unit'] = unit_for(row['source_text']).to_dict()
    context = bind_context(domain, prediction['candidate_ir'], row['source_text'], inputs)
    batch = dict(schema=CONTEXTS_SCHEMA, plan_id=plan['plan_id'], checkpoint_sha256=checkpoint_ref['sha256'],
                 rows=[{'id': row['id'], 'context': context}], **c.FALSE)
    context_path = c.write_json(args.output/domain/'declared-context.json', batch)
    selected_families = families + (['program'] if domain == 'security_ir' else [])
    for kind, path in [('candidate-only', None), ('explicit-context', context_path)]:
        summary = qualify_round(old/'coordinator', checkpoint_path, args.output/domain/kind,
            contexts_path=path, row_ids=[row['id']], required_families=selected_families,
            lake_executable=args.lake, java_executable=args.java, tla2tools_jar=args.sany_jar)
        value = dict(domain_id=domain, context=kind, rows=summary['rows'],
            family_counts=summary['family_counts'], all_requested_native_checks_passed=summary['all_requested_native_checks_passed'],
            checkpoint=checkpoint_ref, summary_path=str(args.output/domain/kind/'summary.json'))
        results.append(value)
        print(json.dumps(value), flush=True)
    del checkpoint
c.write_json(args.output/'results.json', dict(schema='distributed384-native-context-development-replay/v1',
    scope='one_tuning_prediction_per_domain; authored_formulas_are_not_model_predictions',
    comparisons=results, **c.FALSE))
