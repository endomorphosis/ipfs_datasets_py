"""Append-only publication of authored development checks beside existing checkpoints."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

from huggingface_hub import HfApi, CommitOperationAdd, hf_hub_download

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--previous', type=Path, required=True)
p.add_argument('--code-commit', required=True)
p.add_argument('--intent-ui-run', required=True)
p.add_argument('--security-run', required=True)
p.add_argument('--upload', action='store_true')
a = p.parse_args()

def raw(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
def sha(data): return hashlib.sha256(data).hexdigest()

def file_set(directory, prefix):
    return {prefix+'/'+str(path.relative_to(directory)):path.read_bytes() for path in sorted(directory.rglob('*'))
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc'}

api = HfApi()
publications = []
for domain in ('intent_ir', 'security_ir', 'ui_ux_ir', 'legal_ir'):
    old = json.loads((a.previous/domain/'merged-result.json').read_text())
    source = json.loads((a.previous/domain/'coordinator/plan.json').read_text())
    checkpoint_dir = a.root/'checkpoints-run-03'/domain
    summary = json.loads((checkpoint_dir/'explicit-context/summary.json').read_text())
    assert summary['all_requested_native_checks_passed'] and summary['target_access'] is False
    assert all(summary[k] is False for k in ('qualified','admitted','proof_authority','source_semantics_verified','promotion_performed'))
    files = file_set(checkpoint_dir, 'checkpoint-predictions')
    files['run_checkpoint_checks.py'] = (a.root/'run_checkpoint_checks.py').read_bytes()
    if domain == 'security_ir':
        files.update(file_set(a.root/'security-authored'/a.security_run, 'authored-native-models'))
        files['authored-reproduce.py'] = (a.root/'security-authored/reproduce.py').read_bytes()
    elif domain in ('intent_ir', 'ui_ux_ir'):
        files.update(file_set(a.root/'intent-ui-authored'/a.intent_ui_run, 'authored-native-models'))
        files['authored-reproduce.py'] = (a.root/'intent-ui-authored/run_authored_checks.py').read_bytes()
    manifest = dict(schema='distributed384-projection-development-evidence/v1', domain_id=domain,
        plan_id=source['plan_id'], checkpoint=summary['checkpoint'], published_checkpoint=old['publication'],
        code_repository='https://github.com/endomorphosis/ipfs_datasets_py', code_commit=a.code_commit,
        scope='one actual tuning prediction per domain plus explicitly authored model/context API controls',
        source_provenance='previously published authored source_reconstruction_v3 controls and repository-owned native fixtures',
        formulas_are_caller_declarations=True, training_executed=False, weights_changed=False,
        model_source_semantic_fidelity_verified=False, new_holdout_evaluation=False,
        qualified=False, admitted=False, proof_authority=False, promotion_performed=False,
        source_semantics_verified=False,
        files=[dict(path=name,sha256=sha(data),bytes=len(data)) for name,data in sorted(files.items())])
    compressed = io.BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode='wb', mtime=0, filename='') as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for name,data in sorted(files.items()):
                entry=tarfile.TarInfo(name); entry.size=len(data); entry.mode=0o644; entry.mtime=0
                tar.addfile(entry, io.BytesIO(data))
    bundle=compressed.getvalue()
    manifest['archive'] = dict(path='evidence.tar.gz',sha256=sha(bundle),bytes=len(bundle))
    manifest_bytes=raw(manifest)
    identity=sha(manifest_bytes)
    prefix='training/structured384/'+source['plan_id']+'/projection-checks/'+identity
    stage=a.root/'publication'/domain; stage.mkdir(parents=True, exist_ok=True)
    for filename,data in [('manifest.json',manifest_bytes),('evidence.tar.gz',bundle)]:
        path=stage/filename
        if path.exists(): assert path.read_bytes()==data
        else: path.write_bytes(data)
    repo=old['publication']['repository_id']
    receipt=dict(repository_id=repo,repo_type='model',path=prefix,manifest_sha256=identity,
                 archive_sha256=sha(bundle),archive_bytes=len(bundle),uploaded=False)
    if a.upload:
        info=api.model_info(repo)
        existing={x.rfilename for x in info.siblings}
        desired={prefix+'/manifest.json':manifest_bytes,prefix+'/evidence.tar.gz':bundle}
        if set(desired) & existing:
            assert set(desired) <= existing, 'partial existing publication requires investigation'
            revision=info.sha
        else:
            commit=api.create_commit(repo_id=repo,repo_type='model',parent_commit=info.sha,
                operations=[CommitOperationAdd(path_in_repo=name,path_or_fileobj=io.BytesIO(data)) for name,data in desired.items()],
                commit_message='Archive candidate-bound native projection development checks')
            revision=commit.oid
        for name,data in desired.items():
            fetched=Path(hf_hub_download(repo_id=repo,repo_type='model',filename=name,revision=revision))
            assert sha(fetched.read_bytes())==sha(data), 'published artifact verification failed'
        receipt.update(uploaded=True,revision=revision,download_verified=True,
            url='https://huggingface.co/'+repo+'/blob/'+revision+'/'+prefix+'/manifest.json')
    (stage/'receipt.json').write_bytes(raw(receipt))
    publications.append(receipt)
    print(json.dumps(receipt),flush=True)
(a.root/'publication/receipts.json').write_bytes(raw(publications))
