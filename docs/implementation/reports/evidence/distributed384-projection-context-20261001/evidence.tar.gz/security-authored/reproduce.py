"""Authored context API validation; no model inference, training or source proof.

Run from the released datasets checkout with PYTHONPATH set to that checkout.
The source/candidate is an authored composition fixture. Supplementary models
and formulas are independent authored declarations attached by exact identity,
not consequences inferred from the scalar code or predictions of a checkpoint.
"""
from pathlib import Path
import argparse
import hashlib
import json

from tests.unit.logic.formalization.autoencoder.test_distributed_384_projection_inputs import sample, security_inputs
from tests.unit.logic.formalization.autoencoder.test_family_training_v2 import concurrency_fixtures, protocol_fixtures
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.projection_inputs import security_source_ref
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.projection_context_contract import bind_context
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.projections_v2 import (
    prepare_candidate_projection, check_candidate_projection,
)
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.contracts import write_json, FALSE, digest

LAKE = '/home/barberb/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake'
JAVA = '/home/barberb/.local/share/ipfs_datasets_py/theorem-provers/advisors/temurin-jdk/17.0.20+8/jdk/bin/java'
JAR = '/home/barberb/.local/share/ipfs_datasets_py/theorem-provers/tlc/1.8.0/tla2tools.jar'
FORMULAS = {
    'FOL': 'forall x. Person(x) -> Reports(x)',
    'DFOL': 'forall x. O(Reports(x))',
    'TFOL': 'forall x. □(Reports(x))',
    'TDFOL': 'forall x. O(□(Reports(x)))',
    'CEC': 'K(Officer,Happens(Submit,Time))',
    'DCEC': 'O(K(Officer,Happens(Submit,Time)))',
    'frame_logic': 'alice[role -> officer].',
    'propositional': 'p and q',
}


def authored_inputs(row):
    inputs = security_inputs(row)
    source = security_source_ref(inputs['code_unit'], row['source_text'])
    for kind, factory in (
        ('concurrency', concurrency_fixtures._producer_consumer),
        ('refinement', concurrency_fixtures._counter_refinement),
        ('protocol', protocol_fixtures._document),
    ):
        model = factory()
        if kind == 'protocol':
            wire = model.to_dict()
            previous = wire['sources'][0]['ref_id']

            def rebound(value):
                if isinstance(value, dict):
                    if 'ref_id' in value and 'content_sha256' in value:
                        return source.to_dict()
                    result = {key: rebound(item) for key, item in value.items()}
                    if 'start_byte' in result and 'end_byte' in result:
                        result.update(start_byte=0, end_byte=len(row['source_text'].encode()))
                    return result
                if isinstance(value, list):
                    return [rebound(item) for item in value]
                return source.ref_id if value == previous else value

            wire = rebound(wire)
            wire['document_id'] = ''
            model = type(model).from_dict(wire)
        inputs['supplemental_inputs'].append(dict(kind=kind, document=model.to_dict()))
    inputs['formula_inputs'] = [dict(requirement_id=name, formula=formula) for name, formula in FORMULAS.items()]
    return inputs


def run(output):
    row = sample('security_ir')
    inputs = authored_inputs(row)
    context = bind_context('security_ir', row['target'], row['source_text'], inputs)
    write_json(output / 'source-candidate.json', dict(source_text=row['source_text'], candidate_ir=row['target'],
        provenance='authored source_reconstruction_v3 fixture; not checkpoint inference', **FALSE))
    write_json(output / 'context.json', context)
    prepared = prepare_candidate_projection('security_ir', row['target'], row['source_text'], context=context)
    supported = [family['family_id'] for family in prepared.report['families'] if family['status'] == 'supported']
    all_families = prepared.report['requested_families']
    records = []
    for name, families, handle in (
        ('all-native-16', all_families, prepared),
        ('supported-native-12', supported, prepare_candidate_projection('security_ir', row['target'],
            row['source_text'], context=context, required_families=supported)),
    ):
        report = check_candidate_projection(handle, lake_executable=LAKE, java_executable=JAVA,
            tla2tools_jar=JAR, output_directory=output / name / 'native', timeout_seconds=60)
        write_json(output / name / 'report.json', report)
        observations = report['native_execution']['per_projection']
        checks = [check for item in observations for check in item.get('additional_syntax_checks', [])]
        records.append(dict(name=name, requested_families=families,
            report_sha256=report['report_sha256'],
            family_statuses={family['family_id']: family['status'] for family in report['families']},
            unsupported_native_rows=[dict(projection_id=item['projection_id'], reason=item['reason'])
                for item in observations if not item['semantic_lowering_supported']],
            emitted_projections=len(observations),
            lake_passed=sum(item['lake_status'] == 'passed' for item in observations),
            sany_checks=len(checks), sany_passed=sum(check['status'] == 'passed' for check in checks),
            all_required_families_supported=report['all_required_families_supported'],
            all_requested_native_checks_passed=report['all_requested_native_checks_passed'],
            lake_build_executed=report['lake_build_executed']))
    summary = dict(schema='authored-security-context-native-checks/v1',
        scope='native projection API fixtures; source-bound caller declarations, not learned output or source fidelity',
        source_sha256=hashlib.sha256(row['source_text'].encode()).hexdigest(),
        candidate_sha256=digest(row['target']), context_sha256=context['context_sha256'],
        source_fixture='tests.fixtures.logic.source_reconstruction_v3',
        model_inference_executed=False, training_executed=False, formulas_inferred_from_code=False,
        supplemental_models_inferred_from_code=False, applicability_reviews_created=False,
        real_world_evaluation=False, records=records,
        tool_sha256={path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in (LAKE, JAVA, JAR)},
        **FALSE)
    write_json(output / 'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    run(args.output_dir)
