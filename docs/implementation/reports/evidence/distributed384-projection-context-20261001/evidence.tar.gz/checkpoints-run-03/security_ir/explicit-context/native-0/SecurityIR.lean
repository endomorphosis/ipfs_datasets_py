-- Actual native interpretation declarations; no source truth asserted.

namespace SecurityIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_0
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t)))
end Projection_0

namespace Projection_1
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Reports" [v0] t)) t)
end Projection_1

namespace Projection_2
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t))
end Projection_2

namespace Projection_3
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Person" [v0] t) t) → ((fun t => i.atom "Reports" [v0] t) t)) t)
end Projection_3

namespace Projection_4
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"alice\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"officer\"}"))
end Projection_4

namespace Projection_6
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "p" [] t) ∧ (i.atom "q" [] t))
end Projection_6

namespace Projection_7
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Reports" [v0] t))) t)
end Projection_7

namespace Projection_8
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Reports" [v0] t)) t)
end Projection_8

end SecurityIR


namespace SecurityIR
namespace Projection_5
def distributedCodeUnitDeclarationJSON : String := "{\"authority\":\"non_authoritative\",\"config_cid\":\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\",\"language\":\"Python\",\"parent_cids\":[\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\"],\"path\":\"fixture.py\",\"payload\":{\"body_cid\":\"bafkreieyyorfp5h3h6a4mabhdtiv3jy77pxiu34r26ayq3dmbzci3rsnmi\",\"body_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\"},\"polarity\":\"fixed\",\"record_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"record_type\":\"code_unit\",\"schema_version\":\"cvefixes-security-ir-derived/v1\",\"source_cids\":[\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\"],\"unit_kind\":\"function\"}"

def distributedCodeUnitJoinedProgramJSON : String := "{\"commands\":[{\"attributes\":{},\"command_id\":\"command:11\",\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"synchronizes\":false,\"writes\":[]},\"evaluation_order\":[\"expr:10\"],\"expression_ids\":[\"expr:10\"],\"kind\":\"return\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.stmt.4\"],\"target_symbol_ids\":[],\"undefined_behavior\":[]}],\"expressions\":[{\"attributes\":{},\"evaluation_order\":[\"expr:7\",\"expr:9\"],\"expression_id\":\"expr:10\",\"kind\":\"binary\",\"operand_ids\":[\"expr:7\",\"expr:9\"],\"operator\":\"add\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.expr.5\"],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"expr:7\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.expr.6\"],\"symbol_ids\":[\"symbol:derive.capacity.parameter\"],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"expr:9\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.expr.8\"],\"symbol_ids\":[\"symbol:derive.threshold.parameter\"],\"type_ref\":\"integer\"}],\"functions\":[{\"cfg\":{\"blocks\":[{\"block_id\":\"block:entry\",\"command_ids\":[\"command:11\"],\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:function.derive.1\"]}],\"edges\":[],\"entry_block_id\":\"block:entry\",\"exceptional_exit_block_ids\":[],\"graph_id\":\"cfg:derive\",\"normal_exit_block_ids\":[\"block:entry\"]},\"declared_exceptions\":[],\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"synchronizes\":false,\"writes\":[]},\"exception_symbol_ids\":[],\"function_id\":\"function:derive\",\"local_symbol_ids\":[],\"name\":\"derive\",\"parameter_symbol_ids\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"purity\":\"pure\",\"result_symbol_id\":\"symbol:derive.result.result\",\"return_type\":\"integer\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:function.derive.1\"]}],\"global_symbol_ids\":[],\"metadata\":{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"distributed_candidate_source_join\":{\"code_unit_cid\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"model_semantics_changed\":false,\"original_program_id\":\"bafkreie5ji4qv2t3emxplhcs42pbtdy7xbluxvjq5lf7npo64o3x4fufwy\",\"original_program_sha256\":\"cb9b1ab45424a220cd762c7673ca5406960fcef8d25958edb7a4af558526baa8\",\"original_source_identifier\":\"source:source.py\",\"polarity_inferred\":false,\"schema\":\"distributed-384-derived-program-source-join/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\"},\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicnoxhe32s2zzvuy2f3b76ts4zvc2snocwhrn6gszb2cdij66c62q\",\"base_program_sha256\":\"3c3fcad37486fe9c2dc95e5416a5d6c946a327669d8bb9ad9b4dca74ea9caa4d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"whole_program_semantics_verified\":false},\"program_id\":\"bafkreif67njiuzco3blaiiacuawe33mhxbs4qyzgh3pbrtkbanani6qzpi\",\"schema_version\":\"program-ir/v1\",\"sources\":[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"bafkreieyyorfp5h3h6a4mabhdtiv3jy77pxiu34r26ayq3dmbzci3rsnmi\",\"content_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"review_status\":\"unreviewed\",\"source_id\":\"fixture.py\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"code-unit:bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"}],\"spans\":[{\"end_byte\":81,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.expr.5\",\"start_byte\":61,\"start_char\":null,\"start_column\":12,\"start_line\":2},{\"end_byte\":69,\"end_char\":null,\"end_column\":19,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.expr.6\",\"start_byte\":61,\"start_char\":null,\"start_column\":12,\"start_line\":2},{\"end_byte\":81,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.expr.8\",\"start_byte\":72,\"start_char\":null,\"start_column\":23,\"start_line\":2},{\"end_byte\":24,\"end_char\":null,\"end_column\":24,\"end_line\":1,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.param.capacity.2\",\"start_byte\":11,\"start_char\":null,\"start_column\":12,\"start_line\":1},{\"end_byte\":40,\"end_char\":null,\"end_column\":40,\"end_line\":1,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.param.threshold.3\",\"start_byte\":26,\"start_char\":null,\"start_column\":27,\"start_line\":1},{\"end_byte\":81,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.stmt.4\",\"start_byte\":54,\"start_char\":null,\"start_column\":5,\"start_line\":2},{\"end_byte\":81,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:function.derive.1\",\"start_byte\":0,\"start_char\":null,\"start_column\":1,\"start_line\":1}],\"symbols\":[{\"attributes\":{},\"kind\":\"parameter\",\"name\":\"capacity\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.param.capacity.2\"],\"symbol_id\":\"symbol:derive.capacity.parameter\",\"type_ref\":\"integer\"},{\"attributes\":{},\"kind\":\"result\",\"name\":\"result\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:function.derive.1\"],\"symbol_id\":\"symbol:derive.result.result\",\"type_ref\":\"integer\"},{\"attributes\":{},\"kind\":\"parameter\",\"name\":\"threshold\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.param.threshold.3\"],\"symbol_id\":\"symbol:derive.threshold.parameter\",\"type_ref\":\"integer\"}]}"

def distributedCodeUnitCandidateJSON : String := "{\"document\":{\"attributes\":{},\"evaluation_order\":[\"expr:capacity\",\"expr:threshold\"],\"expression_id\":\"expr:result\",\"kind\":\"binary\",\"operand_ids\":[\"expr:capacity\",\"expr:threshold\"],\"operator\":\"+\",\"source_ref_ids\":[\"source\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},\"kind\":\"program_expression\"}"

def distributedCodeUnitJoinAuditJSON : String := "{\"caller_polarity_verified\":false,\"candidate_sha256\":\"98d9d4d4379ea24d9366d1d8501298e86c4b176978dd812135581aec64f1816b\",\"code_unit_cid\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"code_unit_sha256\":\"e38ad908c6800a1b3687ba794a998383591a756d977ecd1a93095c1593386344\",\"execution_authority\":false,\"inverse_source_join_verified\":true,\"joined_program_sha256\":\"9d534e243d3f415260b1f66cbef8c4bc369eb9daa50ce990b7cc47ee2359e913\",\"original_metadata_retained\":true,\"original_program_modified\":false,\"original_program_sha256\":\"cb9b1ab45424a220cd762c7673ca5406960fcef8d25958edb7a4af558526baa8\",\"profile\":\"distributed-codeunit-source-program-lean/v1\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_candidate_replayed\":true,\"source_join\":{\"code_unit_cid\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"model_semantics_changed\":false,\"original_program_id\":\"bafkreie5ji4qv2t3emxplhcs42pbtdy7xbluxvjq5lf7npo64o3x4fufwy\",\"original_program_sha256\":\"cb9b1ab45424a220cd762c7673ca5406960fcef8d25958edb7a4af558526baa8\",\"original_source_identifier\":\"source:source.py\",\"polarity_inferred\":false,\"schema\":\"distributed-384-derived-program-source-join/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\"},\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"whole_program_semantics_verified\":false}"

def distributedCodeUnitSourceSemanticsVerified : Bool := false

def distributedCodeUnitPolarityVerified : Bool := false

def sourceEvidenceOriginalProgramSHA256 : String := "cb9b1ab45424a220cd762c7673ca5406960fcef8d25958edb7a4af558526baa8"

def sourceEvidenceOperationalViewSHA256 : String := "1d5cdff70b17b2551e3831cbd9dfdd9a8913d48db09227eceaacafd6884498a3"

def sourceEvidenceSourceSHA256 : String := "0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicnoxhe32s2zzvuy2f3b76ts4zvc2snocwhrn6gszb2cdij66c62q\",\"base_program_sha256\":\"3c3fcad37486fe9c2dc95e5416a5d6c946a327669d8bb9ad9b4dca74ea9caa4d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":82,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicnoxhe32s2zzvuy2f3b76ts4zvc2snocwhrn6gszb2cdij66c62q\",\"base_program_sha256\":\"3c3fcad37486fe9c2dc95e5416a5d6c946a327669d8bb9ad9b4dca74ea9caa4d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Projection_5
end SecurityIR
