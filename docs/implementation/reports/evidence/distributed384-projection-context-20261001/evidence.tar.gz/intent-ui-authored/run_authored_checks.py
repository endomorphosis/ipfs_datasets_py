#!/usr/bin/env python3
"""Real public-API checks of explicit fixtures, never learned predictions."""
from argparse import ArgumentParser
from copy import deepcopy
from dataclasses import fields
import hashlib
from pathlib import Path
import time

from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384 import projections_v2 as api
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.contracts import digest, write_json
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.projection_context_contract import bind_context
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.legal_ui_inputs import prepare_source_inputs
from ipfs_datasets_py.logic.formalization.autoencoder import family_training_v6, family_training_v7
from ipfs_datasets_py.logic.formalization.autoencoder.ui_training_inputs import prepare_ui_training_row
from ipfs_datasets_py.logic.ui_ux_ir.schema import UIComponent
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import authored_guarded_intent_panel as intent
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import authored_legal_ui_qualifier_panel as qualifiers
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import domain_reconstruction_panel as panel

SCOPE = "authored native candidates and explicit source-bound context declarations; no learned decoder, holdout, corpus or semantic-truth claim"
FALSE = dict(model_inference_used=False, learned_output=False, heldout=False, qualified=False,
             admitted=False, source_semantics_verified=False, proof_authority=False,
             runtime_behavior_attested=False, training_executed=False)


def intent_fixture(negative=False):
    native = intent.source_inputs(0, include_false_precondition=negative)
    target, text = native["document"].to_dict(), native["source_text"]
    declarations = dict(projection_context=deepcopy(native["context"]),
        guarded_effect_bindings=intent.effect_bindings(native).to_dict(),
        formula_inputs=[dict(requirement_id=k, formula=v) for k, v in intent.FORMULAS.items()])
    return "intent_ir", target, text, declarations


def ui_fixture():
    selected = next(row for row in panel.rows("ui_ux_ir", "train") if row["variant"] == 0)
    row = panel.source_inputs(selected)["ui_training_row"]
    prepared = prepare_ui_training_row(row)
    component, = prepared.document.component_graph.components
    target = dict(kind="ui_component", document=UIComponent(**{
        field.name: getattr(component, field.name) for field in fields(UIComponent)}).to_dict())
    text = ("Authored UI declaration: " + row["dom_aria"]["title"] + ". "
        "The supplied high-risk action requires a fresh request-correlated confirmation token. "
        "The finite untimed workflow and synthetic activation event are explicit modeling declarations.")
    declarations = dict(ui_training_row=row,
        formula_inputs=[dict(requirement_id=k, formula=v) for k, v in intent.FORMULAS.items()])
    inputs = prepare_source_inputs("ui_ux_ir", target, text,
        context=bind_context("ui_ux_ir", target, text, declarations))
    source = family_training_v7.supplemental_source_ref("ui_ux_ir", **inputs)
    original = family_training_v6.prepare_family_training_targets_v6("ui_ux_ir", **inputs)
    declarations["ui_confirmation_inputs"] = [item.to_dict() for item in
        qualifiers._ui_declarations(0, original, source, row["bindings"][0]["action_id"])]
    return "ui_ux_ir", target, text, declarations


def observe(label, fixture, output, options, families=None):
    domain, candidate, text, inputs = fixture
    context = bind_context(domain, candidate, text, inputs)
    frozen = digest(dict(candidate=candidate, source_text=text, context=context))
    record = dict(schema="authored-candidate-context-native-check/v1", label=label, domain_id=domain,
        candidate=candidate, source_text=text, context=context, required_families=families,
        source_sha256=hashlib.sha256(text.encode()).hexdigest(), candidate_sha256=digest(candidate),
        context_sha256=context["context_sha256"], scope=SCOPE, **FALSE)
    write_json(output / label / "inputs.json", record)
    start = time.perf_counter()
    prepared = api.prepare_candidate_projection(domain, candidate, text, context=context,
        required_families=families)
    write_json(output / label / "prepared.json", prepared.report)
    result = api.check_candidate_projection(prepared, lake_executable=options.lake,
        java_executable=options.java, tla2tools_jar=options.jar, timeout_seconds=60,
        output_directory=output / label / "native-build")
    elapsed = time.perf_counter() - start
    assert digest(dict(candidate=candidate, source_text=text, context=context)) == frozen
    write_json(output / label / "result.json", result)
    execution = result["native_execution"]
    rows = execution["per_projection"]
    summary = dict(label=label, domain_id=domain, requested_families=result["requested_families"],
        family_count=len(result["families"]), families_supported=sum(row["status"] == "supported" for row in result["families"]),
        total_projections=len(rows), lake_passed=sum(row["lake_status"] == "passed" for row in rows),
        complete_native_checks=sum(row["lake_status"] == row["parser_status"] == "passed"
            and row["semantic_lowering_supported"] for row in rows),
        missing_requested_families=execution["missing_requested_families"],
        blocked_projections=[dict(projection_id=row["projection_id"], reason=row["reason"],
            parser_status=row["parser_status"], lake_status=row["lake_status"])
            for row in rows if not (row["semantic_lowering_supported"] and row["lake_status"] == row["parser_status"] == "passed")],
        syntax_checks=[dict(projection_id=row["projection_id"], **check)
            for row in rows for check in row.get("additional_syntax_checks", [])],
        actual_backend_executed=execution["backend_executed"], status=execution["status"],
        all_requested_native_checks_passed=result["all_requested_native_checks_passed"],
        native_check_scope=result["native_check_scope"],
        auxiliary_family_coverage=deepcopy(result["auxiliary_family_coverage"]),
        all_auxiliary_families_supported=result["all_auxiliary_families_supported"],
        all_requested_dependencies_supported=result["all_requested_dependencies_supported"],
        immutable_candidate_source_context_verified=True, elapsed_seconds=elapsed,
        source_sha256=record["source_sha256"], candidate_sha256=record["candidate_sha256"],
        context_sha256=context["context_sha256"], scope=SCOPE, **FALSE)
    write_json(output / label / "summary.json", summary)
    print(label, summary["status"], summary["complete_native_checks"], "/", summary["total_projections"],
        "families", summary["families_supported"], "/", summary["family_count"], flush=True)
    return summary


def main():
    parser = ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--lake", required=True)
    parser.add_argument("--java", required=True)
    parser.add_argument("--jar", required=True)
    options = parser.parse_args()
    if options.output.exists():
        raise ValueError("fresh authored evidence run directory required")
    summaries = []
    for name, fixture in (("intent-guarded", intent_fixture()), ("ui-confirmation", ui_fixture())):
        full = observe(name + "-maximal", fixture, options.output, options)
        summaries.append(full)
        # A separate explicit scope is reported alongside, never substituted
        # for the maximal check or used to hide its missing-context blockers.
        result = api.prepare_candidate_projection(fixture[0], fixture[1], fixture[2],
            context=bind_context(*fixture)).report
        supported = [row["family_id"] for row in result["families"] if row["status"] == "supported"]
        if set(supported) != set(result["requested_families"]):
            summaries.append(observe(name + "-scoped", fixture, options.output, options, supported))
    summaries.append(observe("intent-false-precondition-diagnostic", intent_fixture(True), options.output, options))
    result = dict(schema="authored-intent-ui-candidate-native-evidence/v1", scope=SCOPE,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        tools={key: dict(path=str(Path(value).resolve()), sha256=hashlib.sha256(Path(value).read_bytes()).hexdigest())
            for key, value in (("lake", options.lake), ("java", options.java), ("tla2tools", options.jar))},
        runs=summaries, **FALSE)
    write_json(options.output / "summary.json", result)


if __name__ == "__main__":
    main()
