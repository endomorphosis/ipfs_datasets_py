"""Replay unchanged authored declarations and separately check a new fixture.

Run from the released datasets checkout with PYTHONPATH set to that checkout.
This is projection API evidence, not checkpoint inference or source equivalence.
The new closed fragment is authored explicitly; nothing filters old declarations.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import time

from tests.unit.logic.formalization.autoencoder.test_distributed_384_projection_inputs import security_inputs
from tests.unit.logic.formalization.autoencoder.test_distributed_384_supplemental_native_lake import context_models
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.projection_context_contract import bind_context
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.projections_v2 import prepare_candidate_projection, check_candidate_projection
from ipfs_datasets_py.logic.formalization.autoencoder.distributed_384.contracts import FALSE, digest, write_json

LAKE = '/home/barberb/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake'
JAVA = '/home/barberb/.local/share/ipfs_datasets_py/theorem-provers/advisors/temurin-jdk/17.0.20+8/jdk/bin/java'
JAR = '/home/barberb/.local/share/ipfs_datasets_py/theorem-provers/tlc/1.8.0/tla2tools.jar'
FAMILIES = ['authorization', 'concurrency', 'cryptographic_protocol', 'dcec', 'deontic',
    'event_calculus', 'first_order', 'frame_logic', 'hyperproperty', 'program', 'propositional',
    'refinement', 'separation_logic', 'tdfol', 'temporal', 'transition_system']
FORMULAS = {
    'FOL': 'forall x. Person(x) -> Reports(x)', 'DFOL': 'forall x. O(Reports(x))',
    'TFOL': 'forall x. □(Reports(x))', 'TDFOL': 'forall x. O(□(Reports(x)))',
    'CEC': 'K(Officer,Happens(Submit,Time))', 'DCEC': 'O(K(Officer,Happens(Submit,Time)))',
    'frame_logic': 'alice[role -> officer].', 'propositional': 'p and q',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compact(report):
    observations = report['native_execution']['per_projection']
    checks = [check for row in observations for check in row.get('additional_syntax_checks', [])]
    return dict(requested_families=report['requested_families'], report_sha256=report['report_sha256'],
        source_sha256=report['source_sha256'], candidate_sha256=report['candidate_sha256'],
        context_sha256=report['context_sha256'],
        family_statuses={row['family_id']: row['status'] for row in report['families']},
        supported_family_count=sum(row['status'] == 'supported' for row in report['families']),
        emitted_projections=len(observations), lake_passed=sum(row['lake_status'] == 'passed' for row in observations),
        sany_checks=len(checks), sany_passed=sum(row['status'] == 'passed' for row in checks),
        unsupported_native_rows=[dict(projection_id=row['projection_id'], reason=row['reason'])
            for row in observations if not row['semantic_lowering_supported']],
        all_required_families_supported=report['all_required_families_supported'],
        all_requested_native_checks_passed=report['all_requested_native_checks_passed'],
        lake_build_executed=report['lake_build_executed'],
        native_execution_status=report['native_execution']['status'],
        native_build_status=report['native_execution']['execution']['status'],
        **FALSE)


def check_case(output, candidate, context):
    started = time.monotonic()
    handle = prepare_candidate_projection('security_ir', candidate['candidate_ir'], candidate['source_text'],
        context=context, required_families=FAMILIES)
    write_json(output / 'preparation.json', handle.report)
    report = check_candidate_projection(handle, lake_executable=LAKE, java_executable=JAVA,
        tla2tools_jar=JAR, output_directory=output / 'native', timeout_seconds=60)
    write_json(output / 'report.json', report)
    record = compact(report)
    record['wall_seconds'] = time.monotonic() - started
    write_json(output / 'summary.json', record)
    return record


def run(baseline, output):
    if output.exists():
        raise ValueError('A fresh output directory is required')
    output.mkdir(parents=True)
    baseline_candidate_path, baseline_context_path = baseline / 'source-candidate.json', baseline / 'context.json'
    candidate = json.loads(baseline_candidate_path.read_text())
    context = json.loads(baseline_context_path.read_text())
    original_context_digest = context['context_sha256']
    original_before = json.loads((baseline / 'all-native-16/report.json').read_text())
    assert original_before['requested_families'] == FAMILIES
    records = []
    unchanged = output / 'unchanged-original-context'
    unchanged.mkdir()
    for filename in ('source-candidate.json', 'context.json'):
        shutil.copyfile(baseline / filename, unchanged / filename)
        assert sha(baseline / filename) == sha(unchanged / filename)
    shutil.copyfile(baseline / 'all-native-16/report.json', unchanged / 'prior-report.json')
    record = check_case(unchanged, candidate, context)
    assert record['context_sha256'] == original_context_digest
    record.update(name='unchanged-original-context', context_rewritten=False,
        source_candidate_rewritten=False, scope='exact existing declaration replay under new additive adapters',
        prior_supported_family_count=sum(row['status'] == 'supported' for row in original_before['families']),
        prior_lake_passed=sum(row['lake_status'] == 'passed' for row in original_before['native_execution']['per_projection']))
    records.append(record)

    row, inputs = context_models('security_ir')
    assert row['source_text'] == candidate['source_text'] and row['target'] == candidate['candidate_ir']
    broad = security_inputs(row)
    assert inputs['code_unit'] == broad['code_unit']
    assert inputs['supplemental_inputs'][0] == broad['supplemental_inputs'][0]
    # Explicit construction of a separate fixture. No old declaration is read,
    # filtered or weakened to make the new fixture compile.
    inputs['typed_inputs'] = broad['typed_inputs']
    inputs['formula_inputs'] = [dict(requirement_id=key, formula=value) for key, value in FORMULAS.items()]
    new_context = bind_context('security_ir', row['target'], row['source_text'], inputs)
    assert new_context['context_sha256'] != original_context_digest
    authored = output / 'new-authored-closed-fragment'
    write_json(authored / 'source-candidate.json', candidate)
    write_json(authored / 'context.json', new_context)
    record = check_case(authored, candidate, new_context)
    record.update(name='new-authored-closed-fragment', context_rewritten=False,
        new_authored_context=True, source_candidate_rewritten=False,
        scope='separate explicitly authored supported fragment; not repair or learned coverage',
        fixture_modules=['test_distributed_384_supplemental_native_lake.context_models',
            'test_distributed_384_projection_inputs.security_inputs',
            'test_native_concurrency_lean.fixture', 'test_native_protocol_lean.fixture',
            'test_native_refinement_lean.fixture'])
    records.append(record)
    summary = dict(schema='authored-security-supplemental-native-checks/v1',
        scope='source-bound projection API fixtures; caller declarations are not learned outputs or source proofs',
        baseline_path=str(baseline), baseline_context_sha256=original_context_digest,
        baseline_files_sha256={filename: sha(baseline / filename) for filename in ('source-candidate.json', 'context.json')},
        source_sha256=hashlib.sha256(candidate['source_text'].encode()).hexdigest(),
        candidate_sha256=digest(candidate['candidate_ir']),
        model_inference_executed=False, training_executed=False, formulas_inferred_from_code=False,
        supplemental_models_inferred_from_code=False, applicability_reviews_created=False,
        old_context_automatically_repaired=False, real_world_evaluation=False,
        records=records, tool_sha256={path: sha(path) for path in (LAKE, JAVA, JAR)}, **FALSE)
    write_json(output / 'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    run(args.baseline_dir, args.output_dir)
