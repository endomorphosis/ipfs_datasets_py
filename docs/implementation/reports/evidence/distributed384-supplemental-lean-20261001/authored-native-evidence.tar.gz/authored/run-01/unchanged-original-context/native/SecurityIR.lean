-- Actual native interpretation declarations; no source truth asserted.

namespace SecurityIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_3
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t)))
end Projection_3

namespace Projection_4
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Reports" [v0] t)) t)
end Projection_4

namespace Projection_5
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t))
end Projection_5

namespace Projection_6
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Person" [v0] t) t) → ((fun t => i.atom "Reports" [v0] t) t)) t)
end Projection_6

namespace Projection_7
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"alice\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"officer\"}"))
end Projection_7

namespace Projection_8
set_option linter.unusedVariables false

structure ExecutionView (Value : Type) where
  publicValue : String → Value
  privateValue : String → Value
  observedValue : String → Value

def lowFields : List String := ["public"]

def highFields : List String := ["secret"]

def observationFields : List String := ["result"]

def lowProjection {Value : Type} (trace : ExecutionView Value) : List Value := lowFields.map trace.publicValue

def observationProjection {Value : Type} (trace : ExecutionView Value) : List Value := observationFields.map trace.observedValue

def noninterference {Value : Type} (executions : ExecutionView Value → Prop) : Prop :=
  ∀ left, executions left → ∀ right, executions right →
    lowProjection left = lowProjection right → observationProjection left = observationProjection right

def maxTraces : Nat := 2

def maxPairs : Nat := 1

def declaredMaxSteps : Option Nat := some 4

def sampleWithinCompositionBudget {Value : Type} (sample : List (ExecutionView Value)) : Prop :=
  sample.length ≤ maxTraces ∧ sample.length * (sample.length - 1) / 2 ≤ maxPairs

def temporalExecutionBoundChecked : Bool := false

def universalNoninterferenceProved : Bool := false

def quantifierVariableOrder : List String := ["var:pi1", "var:pi2"]

def policyIdentifier : String := "policy:flow"
end Projection_8

namespace Projection_10
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "p" [] t) ∧ (i.atom "q" [] t))
end Projection_10

namespace Projection_12
set_option linter.unusedVariables false
inductive HeapValue where
  | integer (value : Int)
  | boolean (value : Bool)
  deriving DecidableEq
structure HeapInterpretation where
  address : String → Nat
abbrev Heap := Nat → Option HeapValue
def emptyHeap : Heap := fun _ => none
def singletonHeap (address : Nat) (value : HeapValue) : Heap :=
  fun location => if location = address then some value else none
def finiteHeap (heap : Heap) : Prop :=
  ∃ support : List Nat, ∀ address, heap address ≠ none → address ∈ support
def disjointHeaps (left right : Heap) : Prop :=
  ∀ address, left address = none ∨ right address = none
def unionHeap (left right : Heap) : Heap :=
  fun address => match left address with
    | some value => some value
    | none => right address
def emp (heap : Heap) : Prop := heap = emptyHeap
def pointsTo (address : Nat) (value : HeapValue) (heap : Heap) : Prop :=
  heap = singletonHeap address value
def separating (left right : Heap → Prop) (heap : Heap) : Prop :=
  ∃ first second, finiteHeap first ∧ finiteHeap second ∧ disjointHeaps first second ∧
    heap = unionHeap first second ∧ left first ∧ right second
theorem emptyHeap_finite : finiteHeap emptyHeap := by
  refine ⟨[], ?_⟩
  intro address h
  simp [emptyHeap] at h
theorem singletonHeap_finite (address : Nat) (value : HeapValue) :
    finiteHeap (singletonHeap address value) := by
  refine ⟨[address], ?_⟩
  intro other h
  by_cases same : other = address
  · simp [same]
  · simp [singletonHeap, same] at h
theorem singleton_not_disjoint_with_itself (address : Nat) (value : HeapValue) :
    ¬ disjointHeaps (singletonHeap address value) (singletonHeap address value) := by
  intro h
  have contradiction := h address
  simp [singletonHeap] at contradiction


def location_0 (i : HeapInterpretation) : Nat := i.address "loc:cell"

def value_0 : HeapValue := HeapValue.integer (1 : Int)

def declaredHeapFragment (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def allocatedCellCount : Nat := 0
end Projection_12

namespace Projection_13
set_option linter.unusedVariables false
inductive HeapValue where
  | integer (value : Int)
  | boolean (value : Bool)
  deriving DecidableEq
structure HeapInterpretation where
  address : String → Nat
abbrev Heap := Nat → Option HeapValue
def emptyHeap : Heap := fun _ => none
def singletonHeap (address : Nat) (value : HeapValue) : Heap :=
  fun location => if location = address then some value else none
def finiteHeap (heap : Heap) : Prop :=
  ∃ support : List Nat, ∀ address, heap address ≠ none → address ∈ support
def disjointHeaps (left right : Heap) : Prop :=
  ∀ address, left address = none ∨ right address = none
def unionHeap (left right : Heap) : Heap :=
  fun address => match left address with
    | some value => some value
    | none => right address
def emp (heap : Heap) : Prop := heap = emptyHeap
def pointsTo (address : Nat) (value : HeapValue) (heap : Heap) : Prop :=
  heap = singletonHeap address value
def separating (left right : Heap → Prop) (heap : Heap) : Prop :=
  ∃ first second, finiteHeap first ∧ finiteHeap second ∧ disjointHeaps first second ∧
    heap = unionHeap first second ∧ left first ∧ right second
theorem emptyHeap_finite : finiteHeap emptyHeap := by
  refine ⟨[], ?_⟩
  intro address h
  simp [emptyHeap] at h
theorem singletonHeap_finite (address : Nat) (value : HeapValue) :
    finiteHeap (singletonHeap address value) := by
  refine ⟨[address], ?_⟩
  intro other h
  by_cases same : other = address
  · simp [same]
  · simp [singletonHeap, same] at h
theorem singleton_not_disjoint_with_itself (address : Nat) (value : HeapValue) :
    ¬ disjointHeaps (singletonHeap address value) (singletonHeap address value) := by
  intro h
  have contradiction := h address
  simp [singletonHeap] at contradiction


def location_0 (i : HeapInterpretation) : Nat := i.address "loc:cell"

def value_0 : HeapValue := HeapValue.integer (1 : Int)

def declaredHeapFragment (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def allocatedCellCount : Nat := 0

def formula_0 (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def separationFormula (i : HeapInterpretation) (heap : Heap) : Prop := finiteHeap heap ∧ formula_0 i heap
end Projection_13

namespace Projection_14
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Reports" [v0] t))) t)
end Projection_14

namespace Projection_15
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Reports" [v0] t)) t)
end Projection_15

namespace Projection_16
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (alwaysTime (fun t => i.atom "safe" [] t))
end Projection_16

namespace Projection_17
structure State where
  v0 : Int
def typeOK (s : State) : Prop := ((0 : Int) ≤ s.v0 ∧ s.v0 ≤ (1 : Int))
def predicate_0 (s : State) : Prop := (s.v0 = (0 : Int))
def predicate_1 (s : State) : Prop := (s.v0 = (1 : Int))
def initial (s : State) : Prop := typeOK s ∧ (predicate_0 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:x"].contains variableName
example : [].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:set" ∧ action_0 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
def sourceVariableAliases : List (String × String) := [("var:x", "v0"), ("x", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 64
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:set"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

end Projection_17

namespace Projection_18
structure State where
  v0 : Int
def typeOK (s : State) : Prop := ((0 : Int) ≤ s.v0 ∧ s.v0 ≤ (1 : Int))
def predicate_0 (s : State) : Prop := (s.v0 = (0 : Int))
def predicate_1 (s : State) : Prop := (s.v0 = (1 : Int))
def initial (s : State) : Prop := typeOK s ∧ (predicate_0 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:x"].contains variableName
example : [].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:set" ∧ action_0 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
end Projection_18

end SecurityIR


namespace SecurityIR
namespace Projection_0
set_option linter.unusedVariables false
structure AuthAtom where
  predicate : String
  arguments : List String
  deriving DecidableEq, BEq
structure AuthFact where
  identity : String
  atom : AuthAtom
  issuer : String
inductive AuthGuard where
  | equal (left right : String)
  | unequal (left right : String)
  | member (value : String) (members : List String)
def AuthGuard.holds : AuthGuard → Bool
  | .equal left right => left == right
  | .unequal left right => left != right
  | .member value members => members.contains value
inductive AuthEffect where
  | allow | deny | derive
  deriving DecidableEq, BEq
inductive AuthOutcome where
  | allow | deny | conflict | unknown
  deriving DecidableEq, BEq
inductive AuthPrecedence where
  | deny_overrides | allow_overrides | first_applicable | explicit_conflict
structure AuthRule where
  identity : String
  head : AuthAtom
  positive : List AuthAtom
  negative : List AuthAtom
  guards : List AuthGuard
  secpal : Bool
  issuer : String
  effect : AuthEffect
  stratum : Nat
structure AuthQuery where
  identity : String
  principal : String
  action : String
  resource : String
  goal : Option AuthAtom

def issuerAuthorized (roots : List String) (rule : AuthRule) : Bool :=
  !rule.secpal || roots.contains rule.issuer

def bodySatisfied (facts : List AuthAtom) (rule : AuthRule) : Bool :=
  rule.positive.all facts.contains &&
  rule.negative.all (fun atom => !facts.contains atom) &&
  rule.guards.all AuthGuard.holds

-- Exactly the ground head alignment used by the reference evaluator.
def headAligned (query : AuthQuery) (head : AuthAtom) : Bool :=
  match head.arguments with
  | [] => true
  | [principal] => principal == query.principal
  | [principal, action] => principal == query.principal && action == query.action
  | [principal, action, resource] =>
      principal == query.principal && action == query.action && resource == query.resource
  | _ => false

def evidenceMatches (query : AuthQuery) (atom : AuthAtom) : Bool :=
  match atom.arguments with
  | [] => true
  | [value] => [query.principal, query.action, query.resource].contains value
  | [principal, value] => principal == query.principal &&
      [query.action, query.resource].contains value
  | [principal, action, resource] =>
      principal == query.principal && action == query.action &&
      (query.resource == "" || [query.resource, "*", ""].contains resource)
  | _ => false

def resolveAuthorization (precedence : AuthPrecedence) (allow deny : Bool)
    (first : Option AuthEffect) : AuthOutcome :=
  if allow && deny then
    match precedence with
    | .deny_overrides => .deny
    | .allow_overrides => .allow
    | .explicit_conflict => .conflict
    | .first_applicable =>
      match first with
      | some .allow => .allow
      | some .deny => .deny
      | _ => .conflict
  else if deny then .deny else if allow then .allow else .unknown

def applicableRules (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => issuerAuthorized roots rule && bodySatisfied facts rule)

def queryDirectedRules (query : AuthQuery) (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => headAligned query rule.head)

def evaluatedFacts (facts : List AuthAtom) (applicable : List AuthRule)
    (query : AuthQuery) : List AuthAtom :=
  facts ++ ((queryDirectedRules query applicable).map AuthRule.head) ++
    ((applicable.filter (fun rule => rule.effect == .derive)).map AuthRule.head)

-- Native decision collection also scans EDB/IDB for effect-rule predicates;
-- effect and predicate identity are retained even for a rule that did not fire.
def hasEffectEvidence (effect : AuthEffect) (rules : List AuthRule)
    (facts : List AuthAtom) (query : AuthQuery) : Bool :=
  rules.any (fun rule => rule.effect == effect && facts.any (fun atom =>
    atom.predicate == rule.head.predicate && evidenceMatches query atom))

def evaluateAuthorization (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) (precedence : AuthPrecedence) (query : AuthQuery) : AuthOutcome :=
  let applicable := applicableRules facts roots rules
  let materialized := evaluatedFacts facts applicable query
  let goal := match query.goal with
    | none => false
    | some atom => materialized.contains atom
  let allow := goal || hasEffectEvidence .allow rules materialized query
  let deny := hasEffectEvidence .deny rules materialized query
  let first := ((queryDirectedRules query applicable).find?
    (fun rule => rule.effect != .derive)).map AuthRule.effect
  resolveAuthorization precedence allow deny first


def authorizationFacts : List AuthFact := [⟨"fact:read", ⟨"predicate:read", ["principal:owner"]⟩, ""⟩]

def authorizationRoots : List String := ["principal:owner"]

def authorizationRules : List AuthRule := []

def authorizationPrecedence : AuthPrecedence := .deny_overrides

def authorizationDecision (query : AuthQuery) : AuthOutcome :=
  evaluateAuthorization (authorizationFacts.map AuthFact.atom) authorizationRoots authorizationRules authorizationPrecedence query

def authorizationSignature_0 : String := "{\"argument_sorts\":[\"principal\"],\"arity\":1,\"is_intensional\":false,\"name\":\"can_read\",\"predicate_id\":\"predicate:read\",\"schema_version\":\"authorization-predicate/v1\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[]}"

def authorizationEvidence_principals_0 : String := "{\"attributes\":{},\"kind\":\"agent\",\"name\":\"Owner\",\"principal_id\":\"principal:owner\",\"schema_version\":\"authorization-principal/v1\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[]}"

def authorizationEvidence_sources_0 : String := "{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"bafkreibhobfew27xqgi4vu4h3lkcdya5t7chmab7jsfgzp5yvu2sevjy44\",\"content_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"review_status\":\"unreviewed\",\"source_id\":\"fixture.py\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"code-unit:bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"}"

def authorizationEvidence_bounds : String := "{\"max_delegation_depth\":64,\"max_derivation_depth\":1024,\"max_facts\":100000,\"max_rules\":10000,\"max_stratum\":255,\"schema_version\":\"authorization-bounds/v1\",\"universe_size\":null}"

def authorizationEvidence_precedence : String := "{\"resolution\":\"deny_overrides\",\"schema_version\":\"authorization-precedence/v1\",\"statement\":\"When allow and deny evidence co-exist, deny overrides unless the resolution policy says otherwise.\"}"

def authorizationEvidence_facts_0 : String := "{\"atom\":{\"arguments\":[{\"kind\":\"constant\",\"sort\":\"principal\",\"value\":\"principal:owner\"}],\"polarity\":\"positive\",\"predicate_id\":\"predicate:read\"},\"attributes\":{},\"fact_id\":\"fact:read\",\"issuer_principal_id\":\"\",\"schema_version\":\"authorization-fact/v1\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[]}"

def authorizationPayloadSHA256 : String := "97239a238fa4e88b509447a9928090488379f3ac86535d7d1a7f25e7114cfbea"
end Projection_0

namespace Projection_9
def distributedCodeUnitDeclarationJSON : String := "{\"authority\":\"non_authoritative\",\"config_cid\":\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\",\"language\":\"Python\",\"parent_cids\":[\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\"],\"path\":\"fixture.py\",\"payload\":{\"body_cid\":\"bafkreibhobfew27xqgi4vu4h3lkcdya5t7chmab7jsfgzp5yvu2sevjy44\",\"body_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\"},\"polarity\":\"fixed\",\"record_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"record_type\":\"code_unit\",\"schema_version\":\"cvefixes-security-ir-derived/v1\",\"source_cids\":[\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\"],\"unit_kind\":\"function\"}"

def distributedCodeUnitJoinedProgramJSON : String := "{\"commands\":[{\"attributes\":{},\"command_id\":\"command:11\",\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"synchronizes\":false,\"writes\":[]},\"evaluation_order\":[\"expr:10\"],\"expression_ids\":[\"expr:10\"],\"kind\":\"return\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.stmt.4\"],\"target_symbol_ids\":[],\"undefined_behavior\":[]}],\"expressions\":[{\"attributes\":{},\"evaluation_order\":[\"expr:7\",\"expr:9\"],\"expression_id\":\"expr:10\",\"kind\":\"binary\",\"operand_ids\":[\"expr:7\",\"expr:9\"],\"operator\":\"lt\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.expr.5\"],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"expr:7\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.expr.6\"],\"symbol_ids\":[\"symbol:derive.capacity.parameter\"],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"expr:9\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.expr.8\"],\"symbol_ids\":[\"symbol:derive.threshold.parameter\"],\"type_ref\":\"integer\"}],\"functions\":[{\"cfg\":{\"blocks\":[{\"block_id\":\"block:entry\",\"command_ids\":[\"command:11\"],\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:function.derive.1\"]}],\"edges\":[],\"entry_block_id\":\"block:entry\",\"exceptional_exit_block_ids\":[],\"graph_id\":\"cfg:derive\",\"normal_exit_block_ids\":[\"block:entry\"]},\"declared_exceptions\":[],\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"synchronizes\":false,\"writes\":[]},\"exception_symbol_ids\":[],\"function_id\":\"function:derive\",\"local_symbol_ids\":[],\"name\":\"derive\",\"parameter_symbol_ids\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"purity\":\"pure\",\"result_symbol_id\":\"symbol:derive.result.result\",\"return_type\":\"boolean\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:function.derive.1\"]}],\"global_symbol_ids\":[],\"metadata\":{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"distributed_candidate_source_join\":{\"code_unit_cid\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"model_semantics_changed\":false,\"original_program_id\":\"bafkreibyj2ugewbtorxkoesz4ydtjnarwx4bycwexhlfbmf3jis2tuof6y\",\"original_program_sha256\":\"fda949f539b0d382feff6839af13f3566fe9af57fb0dd8847c280323c70c0311\",\"original_source_identifier\":\"source:source.py\",\"polarity_inferred\":false,\"schema\":\"distributed-384-derived-program-source-join/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\"},\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreie7bulxk6pm4cks2npna6aoddfusfc7zd5yld23ejqgwrcajfhi5a\",\"base_program_sha256\":\"f08ccf47a343537889b1b47087d779ee2c8e623697db448282d22a5e4d7224f1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"whole_program_semantics_verified\":false},\"program_id\":\"bafkreidj5csibtjglap4jqi7xve5mz4vqi3wapzcltbg2gmp4bxsb74dze\",\"schema_version\":\"program-ir/v1\",\"sources\":[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"bafkreibhobfew27xqgi4vu4h3lkcdya5t7chmab7jsfgzp5yvu2sevjy44\",\"content_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"review_status\":\"unreviewed\",\"source_id\":\"fixture.py\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"code-unit:bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"}],\"spans\":[{\"end_byte\":82,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.expr.5\",\"start_byte\":62,\"start_char\":null,\"start_column\":12,\"start_line\":2},{\"end_byte\":70,\"end_char\":null,\"end_column\":19,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.expr.6\",\"start_byte\":62,\"start_char\":null,\"start_column\":12,\"start_line\":2},{\"end_byte\":82,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.expr.8\",\"start_byte\":73,\"start_char\":null,\"start_column\":23,\"start_line\":2},{\"end_byte\":24,\"end_char\":null,\"end_column\":24,\"end_line\":1,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.param.capacity.2\",\"start_byte\":11,\"start_char\":null,\"start_column\":12,\"start_line\":1},{\"end_byte\":40,\"end_char\":null,\"end_column\":40,\"end_line\":1,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.param.threshold.3\",\"start_byte\":26,\"start_char\":null,\"start_column\":27,\"start_line\":1},{\"end_byte\":82,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.stmt.4\",\"start_byte\":55,\"start_char\":null,\"start_column\":5,\"start_line\":2},{\"end_byte\":82,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:function.derive.1\",\"start_byte\":0,\"start_char\":null,\"start_column\":1,\"start_line\":1}],\"symbols\":[{\"attributes\":{},\"kind\":\"parameter\",\"name\":\"capacity\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.param.capacity.2\"],\"symbol_id\":\"symbol:derive.capacity.parameter\",\"type_ref\":\"integer\"},{\"attributes\":{},\"kind\":\"result\",\"name\":\"result\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:function.derive.1\"],\"symbol_id\":\"symbol:derive.result.result\",\"type_ref\":\"boolean\"},{\"attributes\":{},\"kind\":\"parameter\",\"name\":\"threshold\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.param.threshold.3\"],\"symbol_id\":\"symbol:derive.threshold.parameter\",\"type_ref\":\"integer\"}]}"

def distributedCodeUnitCandidateJSON : String := "{\"document\":{\"attributes\":{},\"evaluation_order\":[\"expr:capacity\",\"expr:threshold\"],\"expression_id\":\"expr:result\",\"kind\":\"binary\",\"operand_ids\":[\"expr:capacity\",\"expr:threshold\"],\"operator\":\"<\",\"source_ref_ids\":[\"source\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},\"kind\":\"program_expression\"}"

def distributedCodeUnitJoinAuditJSON : String := "{\"caller_polarity_verified\":false,\"candidate_sha256\":\"3cbbc43010f0a11fcb121b0e62b00eea3033cc22322ac37838e68a5bee36d3cd\",\"code_unit_cid\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"code_unit_sha256\":\"f02ce76c3f523f3b48ad70bf3fe9b3513d4e2ddc17bd81b7558b7d30ab2dfb20\",\"execution_authority\":false,\"inverse_source_join_verified\":true,\"joined_program_sha256\":\"02da3cf4d9546ad8dd6771ed88048c59d6e041f99542681573dfc2752cfb341d\",\"original_metadata_retained\":true,\"original_program_modified\":false,\"original_program_sha256\":\"fda949f539b0d382feff6839af13f3566fe9af57fb0dd8847c280323c70c0311\",\"profile\":\"distributed-codeunit-source-program-lean/v1\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_candidate_replayed\":true,\"source_join\":{\"code_unit_cid\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"model_semantics_changed\":false,\"original_program_id\":\"bafkreibyj2ugewbtorxkoesz4ydtjnarwx4bycwexhlfbmf3jis2tuof6y\",\"original_program_sha256\":\"fda949f539b0d382feff6839af13f3566fe9af57fb0dd8847c280323c70c0311\",\"original_source_identifier\":\"source:source.py\",\"polarity_inferred\":false,\"schema\":\"distributed-384-derived-program-source-join/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\"},\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"whole_program_semantics_verified\":false}"

def distributedCodeUnitSourceSemanticsVerified : Bool := false

def distributedCodeUnitPolarityVerified : Bool := false

def sourceEvidenceOriginalProgramSHA256 : String := "fda949f539b0d382feff6839af13f3566fe9af57fb0dd8847c280323c70c0311"

def sourceEvidenceOperationalViewSHA256 : String := "689707777b9c6fb7e32c125a99e00245e270e9197333ddffd7fe65b662198d57"

def sourceEvidenceSourceSHA256 : String := "10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreie7bulxk6pm4cks2npna6aoddfusfc7zd5yld23ejqgwrcajfhi5a\",\"base_program_sha256\":\"f08ccf47a343537889b1b47087d779ee2c8e623697db448282d22a5e4d7224f1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":83,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreie7bulxk6pm4cks2npna6aoddfusfc7zd5yld23ejqgwrcajfhi5a\",\"base_program_sha256\":\"f08ccf47a343537889b1b47087d779ee2c8e623697db448282d22a5e4d7224f1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 < current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Projection_9
end SecurityIR
