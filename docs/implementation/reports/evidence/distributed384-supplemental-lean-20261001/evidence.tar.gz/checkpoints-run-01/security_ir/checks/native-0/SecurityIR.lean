-- Actual native interpretation declarations; no source truth asserted.

namespace SecurityIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_3
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t)))
end Projection_3

namespace Projection_4
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Reports" [v0] t)) t)
end Projection_4

namespace Projection_5
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t))
end Projection_5

namespace Projection_6
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Person" [v0] t) t) → ((fun t => i.atom "Reports" [v0] t) t)) t)
end Projection_6

namespace Projection_7
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"alice\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"officer\"}"))
end Projection_7

namespace Projection_8
set_option linter.unusedVariables false

structure ExecutionView (Value : Type) where
  publicValue : String → Value
  privateValue : String → Value
  observedValue : String → Value

def lowFields : List String := ["public"]

def highFields : List String := ["secret"]

def observationFields : List String := ["result"]

def lowProjection {Value : Type} (trace : ExecutionView Value) : List Value := lowFields.map trace.publicValue

def observationProjection {Value : Type} (trace : ExecutionView Value) : List Value := observationFields.map trace.observedValue

def noninterference {Value : Type} (executions : ExecutionView Value → Prop) : Prop :=
  ∀ left, executions left → ∀ right, executions right →
    lowProjection left = lowProjection right → observationProjection left = observationProjection right

def maxTraces : Nat := 2

def maxPairs : Nat := 1

def declaredMaxSteps : Option Nat := some 4

def sampleWithinCompositionBudget {Value : Type} (sample : List (ExecutionView Value)) : Prop :=
  sample.length ≤ maxTraces ∧ sample.length * (sample.length - 1) / 2 ≤ maxPairs

def temporalExecutionBoundChecked : Bool := false

def universalNoninterferenceProved : Bool := false

def quantifierVariableOrder : List String := ["var:pi1", "var:pi2"]

def policyIdentifier : String := "policy:flow"
end Projection_8

namespace Projection_10
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "p" [] t) ∧ (i.atom "q" [] t))
end Projection_10

namespace Projection_12
set_option linter.unusedVariables false
inductive HeapValue where
  | integer (value : Int)
  | boolean (value : Bool)
  deriving DecidableEq
structure HeapInterpretation where
  address : String → Nat
abbrev Heap := Nat → Option HeapValue
def emptyHeap : Heap := fun _ => none
def singletonHeap (address : Nat) (value : HeapValue) : Heap :=
  fun location => if location = address then some value else none
def finiteHeap (heap : Heap) : Prop :=
  ∃ support : List Nat, ∀ address, heap address ≠ none → address ∈ support
def disjointHeaps (left right : Heap) : Prop :=
  ∀ address, left address = none ∨ right address = none
def unionHeap (left right : Heap) : Heap :=
  fun address => match left address with
    | some value => some value
    | none => right address
def emp (heap : Heap) : Prop := heap = emptyHeap
def pointsTo (address : Nat) (value : HeapValue) (heap : Heap) : Prop :=
  heap = singletonHeap address value
def separating (left right : Heap → Prop) (heap : Heap) : Prop :=
  ∃ first second, finiteHeap first ∧ finiteHeap second ∧ disjointHeaps first second ∧
    heap = unionHeap first second ∧ left first ∧ right second
theorem emptyHeap_finite : finiteHeap emptyHeap := by
  refine ⟨[], ?_⟩
  intro address h
  simp [emptyHeap] at h
theorem singletonHeap_finite (address : Nat) (value : HeapValue) :
    finiteHeap (singletonHeap address value) := by
  refine ⟨[address], ?_⟩
  intro other h
  by_cases same : other = address
  · simp [same]
  · simp [singletonHeap, same] at h
theorem singleton_not_disjoint_with_itself (address : Nat) (value : HeapValue) :
    ¬ disjointHeaps (singletonHeap address value) (singletonHeap address value) := by
  intro h
  have contradiction := h address
  simp [singletonHeap] at contradiction


def location_0 (i : HeapInterpretation) : Nat := i.address "loc:cell"

def value_0 : HeapValue := HeapValue.integer (1 : Int)

def declaredHeapFragment (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def allocatedCellCount : Nat := 0
end Projection_12

namespace Projection_13
set_option linter.unusedVariables false
inductive HeapValue where
  | integer (value : Int)
  | boolean (value : Bool)
  deriving DecidableEq
structure HeapInterpretation where
  address : String → Nat
abbrev Heap := Nat → Option HeapValue
def emptyHeap : Heap := fun _ => none
def singletonHeap (address : Nat) (value : HeapValue) : Heap :=
  fun location => if location = address then some value else none
def finiteHeap (heap : Heap) : Prop :=
  ∃ support : List Nat, ∀ address, heap address ≠ none → address ∈ support
def disjointHeaps (left right : Heap) : Prop :=
  ∀ address, left address = none ∨ right address = none
def unionHeap (left right : Heap) : Heap :=
  fun address => match left address with
    | some value => some value
    | none => right address
def emp (heap : Heap) : Prop := heap = emptyHeap
def pointsTo (address : Nat) (value : HeapValue) (heap : Heap) : Prop :=
  heap = singletonHeap address value
def separating (left right : Heap → Prop) (heap : Heap) : Prop :=
  ∃ first second, finiteHeap first ∧ finiteHeap second ∧ disjointHeaps first second ∧
    heap = unionHeap first second ∧ left first ∧ right second
theorem emptyHeap_finite : finiteHeap emptyHeap := by
  refine ⟨[], ?_⟩
  intro address h
  simp [emptyHeap] at h
theorem singletonHeap_finite (address : Nat) (value : HeapValue) :
    finiteHeap (singletonHeap address value) := by
  refine ⟨[address], ?_⟩
  intro other h
  by_cases same : other = address
  · simp [same]
  · simp [singletonHeap, same] at h
theorem singleton_not_disjoint_with_itself (address : Nat) (value : HeapValue) :
    ¬ disjointHeaps (singletonHeap address value) (singletonHeap address value) := by
  intro h
  have contradiction := h address
  simp [singletonHeap] at contradiction


def location_0 (i : HeapInterpretation) : Nat := i.address "loc:cell"

def value_0 : HeapValue := HeapValue.integer (1 : Int)

def declaredHeapFragment (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def allocatedCellCount : Nat := 0

def formula_0 (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def separationFormula (i : HeapInterpretation) (heap : Heap) : Prop := finiteHeap heap ∧ formula_0 i heap
end Projection_13

namespace Projection_14
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Reports" [v0] t))) t)
end Projection_14

namespace Projection_15
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Reports" [v0] t)) t)
end Projection_15

namespace Projection_16
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (alwaysTime (fun t => i.atom "safe" [] t))
end Projection_16

namespace Projection_17
structure State where
  v0 : Int
def typeOK (s : State) : Prop := ((0 : Int) ≤ s.v0 ∧ s.v0 ≤ (1 : Int))
def predicate_0 (s : State) : Prop := (s.v0 = (0 : Int))
def predicate_1 (s : State) : Prop := (s.v0 = (1 : Int))
def initial (s : State) : Prop := typeOK s ∧ (predicate_0 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:x"].contains variableName
example : [].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:set" ∧ action_0 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
def sourceVariableAliases : List (String × String) := [("var:x", "v0"), ("x", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 64
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:set"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

end Projection_17

namespace Projection_18
structure State where
  v0 : Int
def typeOK (s : State) : Prop := ((0 : Int) ≤ s.v0 ∧ s.v0 ≤ (1 : Int))
def predicate_0 (s : State) : Prop := (s.v0 = (0 : Int))
def predicate_1 (s : State) : Prop := (s.v0 = (1 : Int))
def initial (s : State) : Prop := typeOK s ∧ (predicate_0 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:x"].contains variableName
example : [].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:set" ∧ action_0 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
end Projection_18

end SecurityIR


namespace SecurityIR
namespace Projection_0
set_option linter.unusedVariables false
structure AuthAtom where
  predicate : String
  arguments : List String
  deriving DecidableEq, BEq
structure AuthFact where
  identity : String
  atom : AuthAtom
  issuer : String
inductive AuthGuard where
  | equal (left right : String)
  | unequal (left right : String)
  | member (value : String) (members : List String)
def AuthGuard.holds : AuthGuard → Bool
  | .equal left right => left == right
  | .unequal left right => left != right
  | .member value members => members.contains value
inductive AuthEffect where
  | allow | deny | derive
  deriving DecidableEq, BEq
inductive AuthOutcome where
  | allow | deny | conflict | unknown
  deriving DecidableEq, BEq
inductive AuthPrecedence where
  | deny_overrides | allow_overrides | first_applicable | explicit_conflict
structure AuthRule where
  identity : String
  head : AuthAtom
  positive : List AuthAtom
  negative : List AuthAtom
  guards : List AuthGuard
  secpal : Bool
  issuer : String
  effect : AuthEffect
  stratum : Nat
structure AuthQuery where
  identity : String
  principal : String
  action : String
  resource : String
  goal : Option AuthAtom

def issuerAuthorized (roots : List String) (rule : AuthRule) : Bool :=
  !rule.secpal || roots.contains rule.issuer

def bodySatisfied (facts : List AuthAtom) (rule : AuthRule) : Bool :=
  rule.positive.all facts.contains &&
  rule.negative.all (fun atom => !facts.contains atom) &&
  rule.guards.all AuthGuard.holds

-- Exactly the ground head alignment used by the reference evaluator.
def headAligned (query : AuthQuery) (head : AuthAtom) : Bool :=
  match head.arguments with
  | [] => true
  | [principal] => principal == query.principal
  | [principal, action] => principal == query.principal && action == query.action
  | [principal, action, resource] =>
      principal == query.principal && action == query.action && resource == query.resource
  | _ => false

def evidenceMatches (query : AuthQuery) (atom : AuthAtom) : Bool :=
  match atom.arguments with
  | [] => true
  | [value] => [query.principal, query.action, query.resource].contains value
  | [principal, value] => principal == query.principal &&
      [query.action, query.resource].contains value
  | [principal, action, resource] =>
      principal == query.principal && action == query.action &&
      (query.resource == "" || [query.resource, "*", ""].contains resource)
  | _ => false

def resolveAuthorization (precedence : AuthPrecedence) (allow deny : Bool)
    (first : Option AuthEffect) : AuthOutcome :=
  if allow && deny then
    match precedence with
    | .deny_overrides => .deny
    | .allow_overrides => .allow
    | .explicit_conflict => .conflict
    | .first_applicable =>
      match first with
      | some .allow => .allow
      | some .deny => .deny
      | _ => .conflict
  else if deny then .deny else if allow then .allow else .unknown

def applicableRules (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => issuerAuthorized roots rule && bodySatisfied facts rule)

def queryDirectedRules (query : AuthQuery) (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => headAligned query rule.head)

def evaluatedFacts (facts : List AuthAtom) (applicable : List AuthRule)
    (query : AuthQuery) : List AuthAtom :=
  facts ++ ((queryDirectedRules query applicable).map AuthRule.head) ++
    ((applicable.filter (fun rule => rule.effect == .derive)).map AuthRule.head)

-- Native decision collection also scans EDB/IDB for effect-rule predicates;
-- effect and predicate identity are retained even for a rule that did not fire.
def hasEffectEvidence (effect : AuthEffect) (rules : List AuthRule)
    (facts : List AuthAtom) (query : AuthQuery) : Bool :=
  rules.any (fun rule => rule.effect == effect && facts.any (fun atom =>
    atom.predicate == rule.head.predicate && evidenceMatches query atom))

def evaluateAuthorization (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) (precedence : AuthPrecedence) (query : AuthQuery) : AuthOutcome :=
  let applicable := applicableRules facts roots rules
  let materialized := evaluatedFacts facts applicable query
  let goal := match query.goal with
    | none => false
    | some atom => materialized.contains atom
  let allow := goal || hasEffectEvidence .allow rules materialized query
  let deny := hasEffectEvidence .deny rules materialized query
  let first := ((queryDirectedRules query applicable).find?
    (fun rule => rule.effect != .derive)).map AuthRule.effect
  resolveAuthorization precedence allow deny first


def authorizationFacts : List AuthFact := [⟨"fact:read", ⟨"predicate:read", ["principal:owner"]⟩, ""⟩]

def authorizationRoots : List String := ["principal:owner"]

def authorizationRules : List AuthRule := []

def authorizationPrecedence : AuthPrecedence := .deny_overrides

def authorizationDecision (query : AuthQuery) : AuthOutcome :=
  evaluateAuthorization (authorizationFacts.map AuthFact.atom) authorizationRoots authorizationRules authorizationPrecedence query

def authorizationSignature_0 : String := "{\"argument_sorts\":[\"principal\"],\"arity\":1,\"is_intensional\":false,\"name\":\"can_read\",\"predicate_id\":\"predicate:read\",\"schema_version\":\"authorization-predicate/v1\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[]}"

def authorizationEvidence_principals_0 : String := "{\"attributes\":{},\"kind\":\"agent\",\"name\":\"Owner\",\"principal_id\":\"principal:owner\",\"schema_version\":\"authorization-principal/v1\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[]}"

def authorizationEvidence_sources_0 : String := "{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"bafkreieyyorfp5h3h6a4mabhdtiv3jy77pxiu34r26ayq3dmbzci3rsnmi\",\"content_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"review_status\":\"unreviewed\",\"source_id\":\"fixture.py\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"code-unit:bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"}"

def authorizationEvidence_bounds : String := "{\"max_delegation_depth\":64,\"max_derivation_depth\":1024,\"max_facts\":100000,\"max_rules\":10000,\"max_stratum\":255,\"schema_version\":\"authorization-bounds/v1\",\"universe_size\":null}"

def authorizationEvidence_precedence : String := "{\"resolution\":\"deny_overrides\",\"schema_version\":\"authorization-precedence/v1\",\"statement\":\"When allow and deny evidence co-exist, deny overrides unless the resolution policy says otherwise.\"}"

def authorizationEvidence_facts_0 : String := "{\"atom\":{\"arguments\":[{\"kind\":\"constant\",\"sort\":\"principal\",\"value\":\"principal:owner\"}],\"polarity\":\"positive\",\"predicate_id\":\"predicate:read\"},\"attributes\":{},\"fact_id\":\"fact:read\",\"issuer_principal_id\":\"\",\"schema_version\":\"authorization-fact/v1\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[]}"

def authorizationPayloadSHA256 : String := "e1ee050ed6515f4cba4d3bf14f7e15a329ee186b76c60654756b6260281c4239"
end Projection_0

namespace Projection_1
set_option linter.unusedVariables false

inductive Component where
  | c0
  | c1
  deriving DecidableEq, Repr

inductive ComponentKind where
  | thread
  | process
  deriving DecidableEq, Repr

inductive Actor where
  | component (id : Component)
  | environment
  deriving DecidableEq, Repr

inductive Step where
  | s0
  | s1
  | s2
  | s3
  deriving DecidableEq, Repr

def componentId : Component → String
  | Component.c0 => "comp:a"
  | Component.c1 => "comp:b"

def componentName : Component → String
  | Component.c0 => "Worker"
  | Component.c1 => "Peer"

def componentKind : Component → ComponentKind
  | Component.c0 => ComponentKind.thread
  | Component.c1 => ComponentKind.process

def componentLocals : Component → List String
  | Component.c0 => []
  | Component.c1 => []

def stepId : Step → String
  | Step.s0 => "step:a"
  | Step.s1 => "step:b"
  | Step.s2 => "step:blocked"
  | Step.s3 => "step:environment"

def stepLabel : Step → String
  | Step.s0 => "tick"
  | Step.s1 => "peer tick"
  | Step.s2 => "disabled"
  | Step.s3 => "external tick"

def stepActor : Step → Actor
  | Step.s0 => Actor.component Component.c0
  | Step.s1 => Actor.component Component.c1
  | Step.s2 => Actor.component Component.c0
  | Step.s3 => Actor.environment

def stepEnabled : Step → Bool
  | Step.s0 => true
  | Step.s1 => true
  | Step.s2 => false
  | Step.s3 => true

def stepAtomicRegion : Step → Option String
  | Step.s0 => some "atomic:a"
  | Step.s1 => none
  | Step.s2 => none
  | Step.s3 => none

def sharedVariables : List String := []

def declaredVariables : List String := []

def allSteps : List Step := [Step.s0, Step.s1, Step.s2, Step.s3]

abbrev Store (Value : Type) := String → Value

def stepRelation {Value : Type} (step : Step) (before after : Store Value) : Prop :=
  stepEnabled step = true ∧ after = before

def componentStep {Value : Type} (component : Component) (step : Step) (before after : Store Value) : Prop :=
  stepActor step = Actor.component component ∧ stepRelation step before after

def environmentStep {Value : Type} (step : Step) (before after : Store Value) : Prop :=
  stepActor step = Actor.environment ∧ stepRelation step before after

theorem step_preserves_store {Value : Type} (step : Step) (before after : Store Value)
    (h : stepRelation step before after) : after = before := h.2

theorem owners_disjoint {Value : Type} (component : Component) (step : Step) (before after : Store Value) :
    ¬ (componentStep component step before after ∧ environmentStep step before after) := by
  intro h
  have wrong : Actor.component component = Actor.environment := h.1.1.symm.trans h.2.1
  cases wrong

structure Execution (Value : Type) where
  state : Nat → Store Value
  event : Nat → Step

def validExecution {Value : Type} (trace : Execution Value) : Prop :=
  ∀ time, stepRelation (trace.event time) (trace.state time) (trace.state (time + 1))

def selectedEnabled (selected : List Step) : Prop := ∃ step, step ∈ selected ∧ stepEnabled step = true

def infinitelyOften (predicate : Nat → Prop) : Prop := ∀ start, ∃ time, start ≤ time ∧ predicate time

def continuouslyEventually (predicate : Nat → Prop) : Prop := ∃ start, ∀ time, start ≤ time → predicate time

def weakFair {Value : Type} (selected : List Step) (trace : Execution Value) : Prop :=
  continuouslyEventually (fun _ => selectedEnabled selected) → infinitelyOften (fun time => trace.event time ∈ selected)

def strongFair {Value : Type} (selected : List Step) (trace : Execution Value) : Prop :=
  infinitelyOften (fun _ => selectedEnabled selected) → infinitelyOften (fun time => trace.event time ∈ selected)

def unconditionalFair {Value : Type} (selected : List Step) (trace : Execution Value) : Prop :=
  infinitelyOften (fun time => trace.event time ∈ selected)

def finiteExecution {Value : Type} (events : List Step) (before after : Store Value) : Prop :=
  (∀ step ∈ events, stepEnabled step = true) ∧ after = before

def requiresInterferenceDeclaration : Bool := true

def requiresFairnessDeclaration : Bool := true

def documentIdentifier : String := "bafkreifbud6b7i57v6n6xykpnaixp4myseng6m5ewdy7pccsksjghkxmk4"

def atomicRegion_0 : Component × Step := (Component.c0, Step.s0)

def interferenceSubject_0 : Component := Component.c0

def interferenceId_0 : String := "interference:environment"

def interference_0 {Value : Type} (trace : Execution Value) : Prop :=
  ∀ time, stepActor (trace.event time) = Actor.environment → True

def fairnessId_0 : String := "fair:a"

def fairness_0 {Value : Type} (trace : Execution Value) : Prop :=
  weakFair [Step.s0] trace

def contractId_0 : String := "contract:a"

def rely_0 {Value : Type} (trace : Execution Value) : Prop :=
  (interference_0 trace) ∧ (∀ time, stepActor (trace.event time) ≠ Actor.component Component.c0 → True)

def guarantee_0 {Value : Type} (trace : Execution Value) : Prop :=
  ∀ time, stepActor (trace.event time) = Actor.component Component.c0 → True

def contract_0 {Value : Type} (trace : Execution Value) : Prop :=
  rely_0 trace → guarantee_0 trace

def scheduleId_0 : String := "schedule:two"

def schedule_0 (events : List Step) : Prop :=
  events.length ≤ 2 ∧ ∀ step ∈ events, step ∈ [Step.s0, Step.s1, Step.s2, Step.s3] ∧ stepEnabled step = true

def declaredSpecification {Value : Type} (trace : Execution Value) : Prop :=
  (validExecution trace) ∧ (fairness_0 trace) ∧ (interference_0 trace) ∧ (contract_0 trace)

def sourceProgramVerified : Bool := false

def unboundedRefinementProved : Bool := false
end Projection_1

namespace Projection_2
set_option linter.unusedVariables false
inductive Term where
  | atom : String → String → Term
  | literal : String → String → Term
  | app : String → String → List Term → Term
  deriving Repr
def termSort : Term → String
  | .atom sort _ => sort
  | .literal sort _ => sort
  | .app sort _ _ => sort
structure Message where
  identifier : String
  sender : String
  receivers : List String
  channel : String
  payload : Term
  deriving Repr
structure Event where
  identifier : String
  role : String
  phase : String
  parameters : List Term
  deriving Repr
inductive Step where
  | event : String → Step
  | send : String → Step
  | inject : String → Term → Step
  | drop : String → Step
  | replay : String → Step
  deriving Repr
abbrev Trace := List Step
def eventOccurs (trace : Trace) (identifier : String) : Prop := Step.event identifier ∈ trace
def eventAt (trace : Trace) (identifier : String) (position : Nat) : Prop :=
  trace[position]? = some (.event identifier)

def retainedProtocolJSON : String := "{\"adversary\":{\"adversary_id\":\"adversary:network\",\"capabilities\":[\"compose\",\"decompose\",\"drop\",\"inject\",\"intercept\",\"replay\"],\"compromised_key_ids\":[],\"compromised_role_ids\":[],\"kind\":\"dolev_yao\",\"knowledge\":[{\"available_after_event_ids\":[],\"knowledge_id\":\"knowledge:public-key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"term\":{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:key\",\"symbol_id\":\"key:initiator-public\"}}],\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},\"channels\":[{\"adversary_access\":\"control\",\"assumption_ids\":[],\"channel_id\":\"channel:network\",\"name\":\"network\",\"security\":\"public\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}],\"claims\":[{\"antecedent_event_ids\":[\"event:accept\"],\"assumption_ids\":[\"assumption:session-key\"],\"claim_id\":\"claim:authentication\",\"consequent_event_ids\":[\"event:begin\"],\"correspondence\":\"injective\",\"kind\":\"authentication\",\"left_terms\":[],\"reachable_event_ids\":[],\"right_terms\":[],\"secret_terms\":[],\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"Every accept authenticates an initiator run.\"},{\"antecedent_event_ids\":[\"event:accept\"],\"assumption_ids\":[],\"claim_id\":\"claim:correspondence\",\"consequent_event_ids\":[\"event:begin\"],\"correspondence\":\"non_injective\",\"kind\":\"correspondence\",\"left_terms\":[],\"reachable_event_ids\":[],\"right_terms\":[],\"secret_terms\":[],\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"Accept events correspond to begin events.\"},{\"antecedent_event_ids\":[],\"assumption_ids\":[],\"claim_id\":\"claim:reachable\",\"consequent_event_ids\":[],\"correspondence\":\"non_injective\",\"kind\":\"reachability\",\"left_terms\":[],\"reachable_event_ids\":[\"event:accept\"],\"right_terms\":[],\"secret_terms\":[],\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"The responder can accept.\"},{\"antecedent_event_ids\":[],\"assumption_ids\":[\"assumption:session-key\"],\"claim_id\":\"claim:secrecy\",\"consequent_event_ids\":[],\"correspondence\":\"non_injective\",\"kind\":\"secrecy\",\"left_terms\":[],\"reachable_event_ids\":[],\"right_terms\":[],\"secret_terms\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"}],\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"The challenge remains secret.\"}],\"document_id\":\"bafkreiemb55dz2rc7i5wscxjoc5qolcu66xfopdb5grghazfqifmjttvuq\",\"equational_theories\":[\"free\",\"symmetric_encryption\"],\"events\":[{\"event_id\":\"event:accept\",\"name\":\"AcceptChallenge\",\"parameters\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"}],\"phase\":\"accept\",\"role_id\":\"role:responder\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"event_id\":\"event:begin\",\"name\":\"BeginChallenge\",\"parameters\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"}],\"phase\":\"begin\",\"role_id\":\"role:initiator\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}],\"fresh_names\":[{\"generated_by_role_id\":\"role:initiator\",\"kind\":\"nonce\",\"name\":\"challenge\",\"name_id\":\"name:challenge\",\"sort\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}],\"functions\":[{\"function_id\":\"function:decrypt\",\"kind\":\"destructor\",\"name\":\"decrypt\",\"parameter_sorts\":[\"sort:message\",\"sort:key\"],\"result_sort\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"theory\":\"symmetric_encryption\"},{\"function_id\":\"function:encrypt\",\"kind\":\"constructor\",\"name\":\"encrypt\",\"parameter_sorts\":[\"sort:nonce\",\"sort:key\"],\"result_sort\":\"sort:message\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"theory\":\"symmetric_encryption\"}],\"interface\":\"ProtocolIR@1\",\"keys\":[{\"key_id\":\"key:initiator-private\",\"kind\":\"private\",\"name\":\"initiator_private\",\"owner_role_ids\":[\"role:initiator\"],\"peer_key_id\":\"key:initiator-public\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"key_id\":\"key:initiator-public\",\"kind\":\"public\",\"name\":\"initiator_public\",\"owner_role_ids\":[\"role:initiator\"],\"peer_key_id\":\"key:initiator-private\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"key_id\":\"key:session\",\"kind\":\"symmetric\",\"name\":\"session_key\",\"owner_role_ids\":[\"role:initiator\",\"role:responder\"],\"peer_key_id\":\"\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}],\"messages\":[{\"channel_id\":\"channel:network\",\"message_id\":\"message:challenge\",\"name\":\"encrypted challenge\",\"payload\":{\"arguments\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"},{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:key\",\"symbol_id\":\"key:session\"}],\"function_id\":\"function:encrypt\",\"literal\":\"\",\"sort\":\"sort:message\",\"symbol_id\":\"\"},\"receiver_role_ids\":[\"role:responder\"],\"sender_role_id\":\"role:initiator\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}],\"metadata\":{\"protocol\":\"ground-four-query-projection-fixture\",\"version\":1},\"observations\":{},\"rewrite_facts\":[{\"fact_id\":\"fact:decrypt-encrypt\",\"left\":{\"arguments\":[{\"arguments\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"},{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:key\",\"symbol_id\":\"key:session\"}],\"function_id\":\"function:encrypt\",\"literal\":\"\",\"sort\":\"sort:message\",\"symbol_id\":\"\"},{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:key\",\"symbol_id\":\"key:session\"}],\"function_id\":\"function:decrypt\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"\"},\"right\":{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"},\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"theory\":\"symmetric_encryption\"}],\"roles\":[{\"name\":\"Initiator\",\"parameter_ids\":[\"variable:initiator-peer\"],\"role_id\":\"role:initiator\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"name\":\"Responder\",\"parameter_ids\":[\"variable:responder-peer\"],\"role_id\":\"role:responder\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}],\"schema_version\":\"protocol-ir/v1\",\"sorts\":[{\"kind\":\"agent\",\"name\":\"Agent\",\"sort_id\":\"sort:agent\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"key\",\"name\":\"Key\",\"sort_id\":\"sort:key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"message\",\"name\":\"Message\",\"sort_id\":\"sort:message\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"nonce\",\"name\":\"Nonce\",\"sort_id\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}],\"sources\":[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"bafkreieyyorfp5h3h6a4mabhdtiv3jy77pxiu34r26ayq3dmbzci3rsnmi\",\"content_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"review_status\":\"unreviewed\",\"source_id\":\"fixture.py\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"code-unit:bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"}],\"spans\":[{\"end_byte\":82,\"end_char\":null,\"end_column\":2,\"end_line\":40,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:protocol\",\"start_byte\":0,\"start_char\":null,\"start_column\":1,\"start_line\":1}],\"trust_assumptions\":[{\"assumption_id\":\"assumption:session-key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"The long-term mechanism delivers the session key only to both roles.\",\"trusted_key_ids\":[\"key:session\"],\"trusted_role_ids\":[\"role:initiator\",\"role:responder\"]}],\"variables\":[{\"name\":\"peer\",\"role_id\":\"role:initiator\",\"sort\":\"sort:agent\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"variable_id\":\"variable:initiator-peer\"},{\"name\":\"peer\",\"role_id\":\"role:responder\",\"sort\":\"sort:agent\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"variable_id\":\"variable:responder-peer\"}]}"
def capabilities : List String := ["compose", "decompose", "drop", "inject", "intercept", "replay"]
def hasCapability (name : String) : Bool := capabilities.contains name
def compromisedKeys : List String := []
def rolesDeclarations : String := "[{\"name\":\"Initiator\",\"parameter_ids\":[\"variable:initiator-peer\"],\"role_id\":\"role:initiator\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"name\":\"Responder\",\"parameter_ids\":[\"variable:responder-peer\"],\"role_id\":\"role:responder\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}]"
def variablesDeclarations : String := "[{\"name\":\"peer\",\"role_id\":\"role:initiator\",\"sort\":\"sort:agent\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"variable_id\":\"variable:initiator-peer\"},{\"name\":\"peer\",\"role_id\":\"role:responder\",\"sort\":\"sort:agent\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"],\"variable_id\":\"variable:responder-peer\"}]"
def sortsDeclarations : String := "[{\"kind\":\"agent\",\"name\":\"Agent\",\"sort_id\":\"sort:agent\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"key\",\"name\":\"Key\",\"sort_id\":\"sort:key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"message\",\"name\":\"Message\",\"sort_id\":\"sort:message\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"nonce\",\"name\":\"Nonce\",\"sort_id\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}]"
def fresh_namesDeclarations : String := "[{\"generated_by_role_id\":\"role:initiator\",\"kind\":\"nonce\",\"name\":\"challenge\",\"name_id\":\"name:challenge\",\"sort\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}]"
def keysDeclarations : String := "[{\"key_id\":\"key:initiator-private\",\"kind\":\"private\",\"name\":\"initiator_private\",\"owner_role_ids\":[\"role:initiator\"],\"peer_key_id\":\"key:initiator-public\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"key_id\":\"key:initiator-public\",\"kind\":\"public\",\"name\":\"initiator_public\",\"owner_role_ids\":[\"role:initiator\"],\"peer_key_id\":\"key:initiator-private\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]},{\"key_id\":\"key:session\",\"kind\":\"symmetric\",\"name\":\"session_key\",\"owner_role_ids\":[\"role:initiator\",\"role:responder\"],\"peer_key_id\":\"\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:protocol\"]}]"
def messages : List Message := [⟨"message:challenge", "role:initiator", ["role:responder"], "channel:network", (.app "sort:message" "function:encrypt" [(.atom "sort:nonce" "name:challenge"), (.atom "sort:key" "key:session")])⟩]
def message (identifier : String) : Option Message := messages.find? fun m => m.identifier == identifier
def events : List Event := [⟨"event:accept", "role:responder", "accept", [(.atom "sort:nonce" "name:challenge")]⟩, ⟨"event:begin", "role:initiator", "begin", [(.atom "sort:nonce" "name:challenge")]⟩]
def eventDeclared (identifier : String) : Bool := events.any fun e => e.identifier == identifier
def observableChannels : List String := ["channel:network"]
def injectableChannels : List String := ["channel:network"]
def replayableChannels : List String := ["channel:network"]
def controlledChannels : List String := ["channel:network"]
def visible (channel : String) : Bool := hasCapability "intercept" && observableChannels.contains channel
def observedStep : Step → List Term
  | .event _ => []
  | .drop _ => []
  | .send identifier | .replay identifier => match message identifier with
    | some m => if visible m.channel then [m.payload] else []
    | none => []
  | .inject channel value => if visible channel then [value] else []
def observed (trace : Trace) : List Term := trace.flatMap observedStep

def initialKnowledge : List Term := [(.atom "sort:key" "key:initiator-public"), (.atom "sort:key" "key:initiator-public")]
def conditionallyKnown (trace : Trace) (value : Term) : Prop := False
def functionAllowed (kind function result : String) (arguments : List Term) : Prop := (kind = "destructor" ∧ function = "function:decrypt" ∧ result = "sort:nonce" ∧ arguments.map termSort = ["sort:message", "sort:key"]) ∨ (kind = "constructor" ∧ function = "function:encrypt" ∧ result = "sort:message" ∧ arguments.map termSort = ["sort:nonce", "sort:key"])
inductive Reduces : Term → Term → Prop where
  | declared_0 : Reduces (.app "sort:nonce" "function:decrypt" [(.app "sort:message" "function:encrypt" [(.atom "sort:nonce" "name:challenge"), (.atom "sort:key" "key:session")]), (.atom "sort:key" "key:session")]) (.atom "sort:nonce" "name:challenge")
  | symmetric (plain key : Term) : termSort plain = "sort:nonce" → termSort key = "sort:key" → Reduces (.app "sort:nonce" "function:decrypt" [(.app "sort:message" "function:encrypt" [plain, key]), key]) plain
  | context (sort function : String) (before after : List Term) (left right : Term) :
      Reduces left right →
      Reduces (.app sort function (before ++ left :: after)) (.app sort function (before ++ right :: after))
inductive Knows (trace : Trace) : Term → Prop where
  | initial (value : Term) : value ∈ initialKnowledge → Knows trace value
  | conditional (value : Term) : conditionallyKnown trace value → Knows trace value
  | observe (value : Term) : value ∈ observed trace → Knows trace value
  | compose (function result : String) (arguments : List Term) :
      hasCapability "compose" = true → functionAllowed "constructor" function result arguments →
      (∀ value, value ∈ arguments → Knows trace value) → Knows trace (.app result function arguments)
  | decompose (function result : String) (arguments : List Term) (output : Term) :
      hasCapability "decompose" = true → functionAllowed "destructor" function result arguments →
      (∀ value, value ∈ arguments → Knows trace value) →
      Reduces (.app result function arguments) output → Knows trace output
  | reduction (left right : Term) : Knows trace left → Reduces left right → Knows trace right
def previouslySent (trace : Trace) (identifier : String) : Prop :=
  Step.send identifier ∈ trace ∨ Step.replay identifier ∈ trace
def validStep (history : Trace) : Step → Prop
  | .event identifier => eventDeclared identifier = true
  | .send identifier => (message identifier).isSome = true
  | .inject channel value => hasCapability "inject" = true ∧
      channel ∈ injectableChannels ∧ Knows history value
  | .drop identifier => ∃ m, message identifier = some m ∧ hasCapability "drop" = true ∧
      m.channel ∈ controlledChannels ∧ previouslySent history identifier
  | .replay identifier => ∃ m, message identifier = some m ∧ hasCapability "replay" = true ∧
      m.channel ∈ replayableChannels ∧ previouslySent history identifier
def validTrace (trace : Trace) : Prop :=
  ∀ history step suffix, trace = history ++ step :: suffix → validStep history step
structure ProtocolInterpretation where
  permitted : Trace → Prop
  trustPremise : String → Prop
def executions (i : ProtocolInterpretation) (trace : Trace) : Prop := i.permitted trace ∧ validTrace trace
def correspondence (trace : Trace) (antecedent consequent : String) : Prop :=
  ∀ position, eventAt trace antecedent position →
    ∃ earlier, earlier < position ∧ eventAt trace consequent earlier
def injectiveCorrespondence (trace : Trace) (antecedent consequent : String) : Prop :=
  ∃ matching : Nat → Nat,
    (∀ position, eventAt trace antecedent position → matching position < position ∧
      eventAt trace consequent (matching position)) ∧
    (∀ first second, eventAt trace antecedent first → eventAt trace antecedent second →
      matching first = matching second → first = second)

def trust_0 (i : ProtocolInterpretation) : Prop := i.trustPremise "{\"assumption_id\":\"assumption:session-key\",\"statement\":\"The long-term mechanism delivers the session key only to both roles.\",\"trusted_key_ids\":[\"key:session\"],\"trusted_role_ids\":[\"role:initiator\",\"role:responder\"]}" ∧ ∀ key, key ∈ ["key:session"] → key ∉ compromisedKeys
def query_0 (i : ProtocolInterpretation) : Prop := (trust_0 i) → (∀ trace, executions i trace → injectiveCorrespondence trace "event:accept" "event:begin")
def query_1 (i : ProtocolInterpretation) : Prop := (True) → (∀ trace, executions i trace → correspondence trace "event:accept" "event:begin")
def query_2 (i : ProtocolInterpretation) : Prop := (True) → (∃ trace, executions i trace ∧ eventOccurs trace "event:accept")
def query_3 (i : ProtocolInterpretation) : Prop := (trust_0 i) → (∀ trace, executions i trace → ∀ secret, secret ∈ [(.atom "sort:nonce" "name:challenge")] → ¬ Knows trace secret)
def protocolSecurityProved : Bool := false
def roleProcessesVerified : Bool := false

end Projection_2

namespace Projection_9
def distributedCodeUnitDeclarationJSON : String := "{\"authority\":\"non_authoritative\",\"config_cid\":\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\",\"language\":\"Python\",\"parent_cids\":[\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\"],\"path\":\"fixture.py\",\"payload\":{\"body_cid\":\"bafkreieyyorfp5h3h6a4mabhdtiv3jy77pxiu34r26ayq3dmbzci3rsnmi\",\"body_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\"},\"polarity\":\"fixed\",\"record_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"record_type\":\"code_unit\",\"schema_version\":\"cvefixes-security-ir-derived/v1\",\"source_cids\":[\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\"],\"unit_kind\":\"function\"}"

def distributedCodeUnitJoinedProgramJSON : String := "{\"commands\":[{\"attributes\":{},\"command_id\":\"command:11\",\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"synchronizes\":false,\"writes\":[]},\"evaluation_order\":[\"expr:10\"],\"expression_ids\":[\"expr:10\"],\"kind\":\"return\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.stmt.4\"],\"target_symbol_ids\":[],\"undefined_behavior\":[]}],\"expressions\":[{\"attributes\":{},\"evaluation_order\":[\"expr:7\",\"expr:9\"],\"expression_id\":\"expr:10\",\"kind\":\"binary\",\"operand_ids\":[\"expr:7\",\"expr:9\"],\"operator\":\"add\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.expr.5\"],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"expr:7\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.expr.6\"],\"symbol_ids\":[\"symbol:derive.capacity.parameter\"],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"expr:9\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.expr.8\"],\"symbol_ids\":[\"symbol:derive.threshold.parameter\"],\"type_ref\":\"integer\"}],\"functions\":[{\"cfg\":{\"blocks\":[{\"block_id\":\"block:entry\",\"command_ids\":[\"command:11\"],\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:function.derive.1\"]}],\"edges\":[],\"entry_block_id\":\"block:entry\",\"exceptional_exit_block_ids\":[],\"graph_id\":\"cfg:derive\",\"normal_exit_block_ids\":[\"block:entry\"]},\"declared_exceptions\":[],\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"synchronizes\":false,\"writes\":[]},\"exception_symbol_ids\":[],\"function_id\":\"function:derive\",\"local_symbol_ids\":[],\"name\":\"derive\",\"parameter_symbol_ids\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"purity\":\"pure\",\"result_symbol_id\":\"symbol:derive.result.result\",\"return_type\":\"integer\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:function.derive.1\"]}],\"global_symbol_ids\":[],\"metadata\":{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"distributed_candidate_source_join\":{\"code_unit_cid\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"model_semantics_changed\":false,\"original_program_id\":\"bafkreie5ji4qv2t3emxplhcs42pbtdy7xbluxvjq5lf7npo64o3x4fufwy\",\"original_program_sha256\":\"cb9b1ab45424a220cd762c7673ca5406960fcef8d25958edb7a4af558526baa8\",\"original_source_identifier\":\"source:source.py\",\"polarity_inferred\":false,\"schema\":\"distributed-384-derived-program-source-join/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\"},\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicnoxhe32s2zzvuy2f3b76ts4zvc2snocwhrn6gszb2cdij66c62q\",\"base_program_sha256\":\"3c3fcad37486fe9c2dc95e5416a5d6c946a327669d8bb9ad9b4dca74ea9caa4d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"whole_program_semantics_verified\":false},\"program_id\":\"bafkreif67njiuzco3blaiiacuawe33mhxbs4qyzgh3pbrtkbanani6qzpi\",\"schema_version\":\"program-ir/v1\",\"sources\":[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"bafkreieyyorfp5h3h6a4mabhdtiv3jy77pxiu34r26ayq3dmbzci3rsnmi\",\"content_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"review_status\":\"unreviewed\",\"source_id\":\"fixture.py\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"code-unit:bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"}],\"spans\":[{\"end_byte\":81,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.expr.5\",\"start_byte\":61,\"start_char\":null,\"start_column\":12,\"start_line\":2},{\"end_byte\":69,\"end_char\":null,\"end_column\":19,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.expr.6\",\"start_byte\":61,\"start_char\":null,\"start_column\":12,\"start_line\":2},{\"end_byte\":81,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.expr.8\",\"start_byte\":72,\"start_char\":null,\"start_column\":23,\"start_line\":2},{\"end_byte\":24,\"end_char\":null,\"end_column\":24,\"end_line\":1,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.param.capacity.2\",\"start_byte\":11,\"start_char\":null,\"start_column\":12,\"start_line\":1},{\"end_byte\":40,\"end_char\":null,\"end_column\":40,\"end_line\":1,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.param.threshold.3\",\"start_byte\":26,\"start_char\":null,\"start_column\":27,\"start_line\":1},{\"end_byte\":81,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:derive.stmt.4\",\"start_byte\":54,\"start_char\":null,\"start_column\":5,\"start_line\":2},{\"end_byte\":81,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"span_id\":\"span:function.derive.1\",\"start_byte\":0,\"start_char\":null,\"start_column\":1,\"start_line\":1}],\"symbols\":[{\"attributes\":{},\"kind\":\"parameter\",\"name\":\"capacity\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.param.capacity.2\"],\"symbol_id\":\"symbol:derive.capacity.parameter\",\"type_ref\":\"integer\"},{\"attributes\":{},\"kind\":\"result\",\"name\":\"result\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:function.derive.1\"],\"symbol_id\":\"symbol:derive.result.result\",\"type_ref\":\"integer\"},{\"attributes\":{},\"kind\":\"parameter\",\"name\":\"threshold\",\"source_ref_ids\":[\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\"],\"span_ids\":[\"span:derive.param.threshold.3\"],\"symbol_id\":\"symbol:derive.threshold.parameter\",\"type_ref\":\"integer\"}]}"

def distributedCodeUnitCandidateJSON : String := "{\"document\":{\"attributes\":{},\"evaluation_order\":[\"expr:capacity\",\"expr:threshold\"],\"expression_id\":\"expr:result\",\"kind\":\"binary\",\"operand_ids\":[\"expr:capacity\",\"expr:threshold\"],\"operator\":\"+\",\"source_ref_ids\":[\"source\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},\"kind\":\"program_expression\"}"

def distributedCodeUnitJoinAuditJSON : String := "{\"caller_polarity_verified\":false,\"candidate_sha256\":\"98d9d4d4379ea24d9366d1d8501298e86c4b176978dd812135581aec64f1816b\",\"code_unit_cid\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"code_unit_sha256\":\"e38ad908c6800a1b3687ba794a998383591a756d977ecd1a93095c1593386344\",\"execution_authority\":false,\"inverse_source_join_verified\":true,\"joined_program_sha256\":\"9d534e243d3f415260b1f66cbef8c4bc369eb9daa50ce990b7cc47ee2359e913\",\"original_metadata_retained\":true,\"original_program_modified\":false,\"original_program_sha256\":\"cb9b1ab45424a220cd762c7673ca5406960fcef8d25958edb7a4af558526baa8\",\"profile\":\"distributed-codeunit-source-program-lean/v1\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_candidate_replayed\":true,\"source_join\":{\"code_unit_cid\":\"bafkreie4bleqtjfd5i2otwfgnxvnflnlbhuvgiphq4s74nqrxtf4l2jw3q\",\"model_semantics_changed\":false,\"original_program_id\":\"bafkreie5ji4qv2t3emxplhcs42pbtdy7xbluxvjq5lf7npo64o3x4fufwy\",\"original_program_sha256\":\"cb9b1ab45424a220cd762c7673ca5406960fcef8d25958edb7a4af558526baa8\",\"original_source_identifier\":\"source:source.py\",\"polarity_inferred\":false,\"schema\":\"distributed-384-derived-program-source-join/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\"},\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"whole_program_semantics_verified\":false}"

def distributedCodeUnitSourceSemanticsVerified : Bool := false

def distributedCodeUnitPolarityVerified : Bool := false

def sourceEvidenceOriginalProgramSHA256 : String := "cb9b1ab45424a220cd762c7673ca5406960fcef8d25958edb7a4af558526baa8"

def sourceEvidenceOperationalViewSHA256 : String := "1d5cdff70b17b2551e3831cbd9dfdd9a8913d48db09227eceaacafd6884498a3"

def sourceEvidenceSourceSHA256 : String := "0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreicnoxhe32s2zzvuy2f3b76ts4zvc2snocwhrn6gszb2cdij66c62q\",\"base_program_sha256\":\"3c3fcad37486fe9c2dc95e5416a5d6c946a327669d8bb9ad9b4dca74ea9caa4d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"0b09b6c6dc7c6f7e324dd5ff17e5e48eac1690a84e899c06d1d8cc7b8b2459d9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":82,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreicnoxhe32s2zzvuy2f3b76ts4zvc2snocwhrn6gszb2cdij66c62q\",\"base_program_sha256\":\"3c3fcad37486fe9c2dc95e5416a5d6c946a327669d8bb9ad9b4dca74ea9caa4d\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Int

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (current.v0 + current.v2)

def expression_1 (initial current : Store) (returned : Int) : Int := current.v0

def expression_2 (initial current : Store) (returned : Int) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Projection_9

namespace Projection_11
set_option linter.unusedVariables false
structure RefinementNode where
  identifier : String
  enabled : Bool
  initial : Bool
  terminal : Bool
  deriving DecidableEq
structure RefinementEdge where
  identifier : String
  source : String
  target : String
  action : String
  deriving DecidableEq
structure RefinementGraph where
  identifier : String
  nodes : List RefinementNode
  edges : List RefinementEdge
  deriving DecidableEq
def enabledNode (graph : RefinementGraph) (identifier : String) : Bool :=
  graph.nodes.any (fun node => node.identifier == identifier && node.enabled)
def initialNode (graph : RefinementGraph) (identifier : String) : Bool :=
  graph.nodes.any (fun node => node.identifier == identifier && node.enabled && node.initial)
def enabledEdge (graph : RefinementGraph) (edge : RefinementEdge) : Bool :=
  enabledNode graph edge.source && enabledNode graph edge.target
def relatedPair (pairs : List (String × String)) (left right : String) : Bool :=
  pairs.contains (left, right)
-- Exactly one trailing edge matches each leading edge in this nonstutter
-- fragment. The recursion limits the number of leading schedule steps.
def boundedMatch (leading trailing : RefinementGraph) (pairs : List (String × String))
    (matchingLimit : Nat) : Nat → String → String → Bool
  | 0, left, right => enabledNode leading left && enabledNode trailing right && relatedPair pairs left right
  | steps + 1, left, right =>
    enabledNode leading left && enabledNode trailing right && relatedPair pairs left right &&
    leading.edges.all (fun edge =>
      if edge.source == left && enabledEdge leading edge then
        matchingLimit > 0 && trailing.edges.any (fun other =>
          other.source == right && other.action == edge.action && enabledEdge trailing other &&
          boundedMatch leading trailing pairs matchingLimit steps edge.target other.target)
      else true)
def boundedSimulation (leading trailing : RefinementGraph) (pairs : List (String × String))
    (matchingLimit scheduleLimit : Nat) : Bool :=
  leading.nodes.all (fun node =>
    if node.initial && node.enabled then
      trailing.nodes.any (fun other =>
        other.initial && other.enabled &&
        boundedMatch leading trailing pairs matchingLimit scheduleLimit node.identifier other.identifier)
    else true) &&
  pairs.all (fun pair =>
    if enabledNode leading pair.1 && enabledNode trailing pair.2 then
      boundedMatch leading trailing pairs matchingLimit scheduleLimit pair.1 pair.2
    else true)
def declaredStep (graph : RefinementGraph) (left : String) (action : String) (right : String) : Prop :=
  ∃ edge, edge ∈ graph.edges ∧ edge.source = left ∧ edge.action = action ∧
    edge.target = right ∧ enabledEdge graph edge = true
def boundedRun (graph : RefinementGraph) : Nat → String → List String → String → Prop
  | _, left, [], right => left = right ∧ enabledNode graph left = true
  | 0, _, _ :: _, _ => False
  | steps + 1, left, action :: actions, right =>
    ∃ middle, declaredStep graph left action middle ∧ boundedRun graph steps middle actions right
theorem zero_budget_cannot_take_step (graph : RefinementGraph) (left action right : String)
    (actions : List String) : ¬ boundedRun graph 0 left (action :: actions) right := by
  simp [boundedRun]
def sourceProgramRefinementProved : Bool := false
def unboundedRefinementClaimed : Bool := false


def system_0 : RefinementGraph := ⟨"abstract", [⟨"a0", true, true, false⟩, ⟨"a1", true, false, true⟩], [⟨"at", "a0", "a1", "finish"⟩]⟩

def system_1 : RefinementGraph := ⟨"concrete", [⟨"c0", true, true, false⟩, ⟨"c1", true, false, true⟩], [⟨"ct", "c0", "c1", "finish"⟩]⟩

def simulation_0 (scheduleLimit : Nat) : Bool := boundedSimulation system_0 system_1 [("a0", "c0"), ("a1", "c1")] 1 scheduleLimit

def obligation_0 : Prop := simulation_0 2 = true

def obligation_0_check : Bool := simulation_0 2

def nativeRefinementDeclaration : String := "{\"boundedness\":[{\"attributes\":{},\"boundedness_id\":\"bound\",\"claims_unbounded_refinement\":false,\"kind\":\"bounded\",\"max_states\":null,\"max_steps\":2,\"schema_version\":\"refinement-boundedness/v1\",\"statement\":\"bounded simulation\"}],\"document_id\":\"bafkreid6ynxsepxfuetkwyx4k6momroqyasjk4pyyxnrylhiiavwxrreja\",\"interface\":\"RefinementIR@1\",\"metadata\":{},\"obligations\":[{\"abstract_system_id\":\"abstract\",\"attributes\":{},\"boundedness_id\":\"bound\",\"claims_unbounded_refinement\":false,\"concrete_system_id\":\"concrete\",\"kind\":\"simulation\",\"obligation_id\":\"goal\",\"schema_version\":\"refinement-obligation/v1\",\"simulation_relation_id\":\"related\",\"statement\":\"simulation\"}],\"schema_version\":\"refinement-ir/v1\",\"simulations\":[{\"abstract_system_id\":\"abstract\",\"attributes\":{},\"claims_unbounded_refinement\":false,\"concrete_system_id\":\"concrete\",\"couples\":[{\"abstract_state_id\":\"a0\",\"attributes\":{},\"concrete_state_id\":\"c0\",\"couple_id\":\"pair0\",\"schema_version\":\"simulation-couple/v1\",\"statement\":\"related\"},{\"abstract_state_id\":\"a1\",\"attributes\":{},\"concrete_state_id\":\"c1\",\"couple_id\":\"pair1\",\"schema_version\":\"simulation-couple/v1\",\"statement\":\"related\"}],\"direction\":\"forward\",\"max_matching_steps\":1,\"relation_id\":\"related\",\"schema_version\":\"simulation-relation/v1\",\"statement\":\"simulation\"}],\"systems\":[{\"attributes\":{},\"concurrency_document_id\":\"\",\"level\":\"abstract\",\"name\":\"Abstract\",\"schema_version\":\"refinement-system/v1\",\"states\":[{\"attributes\":{},\"is_initial\":true,\"is_terminal\":false,\"label\":\"initial\",\"predicate_statement\":\"true\",\"schema_version\":\"refinement-state/v1\",\"state_id\":\"a0\"},{\"attributes\":{},\"is_initial\":false,\"is_terminal\":true,\"label\":\"done\",\"predicate_statement\":\"true\",\"schema_version\":\"refinement-state/v1\",\"state_id\":\"a1\"}],\"system_id\":\"abstract\",\"transitions\":[{\"action_label\":\"finish\",\"attributes\":{},\"is_stutter\":false,\"schema_version\":\"refinement-transition/v1\",\"source_state_id\":\"a0\",\"target_state_id\":\"a1\",\"transition_id\":\"at\"}]},{\"attributes\":{},\"concurrency_document_id\":\"\",\"level\":\"concrete\",\"name\":\"Concrete\",\"schema_version\":\"refinement-system/v1\",\"states\":[{\"attributes\":{},\"is_initial\":true,\"is_terminal\":false,\"label\":\"initial\",\"predicate_statement\":\"true\",\"schema_version\":\"refinement-state/v1\",\"state_id\":\"c0\"},{\"attributes\":{},\"is_initial\":false,\"is_terminal\":true,\"label\":\"done\",\"predicate_statement\":\"true\",\"schema_version\":\"refinement-state/v1\",\"state_id\":\"c1\"}],\"system_id\":\"concrete\",\"transitions\":[{\"action_label\":\"finish\",\"attributes\":{},\"is_stutter\":false,\"schema_version\":\"refinement-transition/v1\",\"source_state_id\":\"c0\",\"target_state_id\":\"c1\",\"transition_id\":\"ct\"}]}]}"
end Projection_11
end SecurityIR
