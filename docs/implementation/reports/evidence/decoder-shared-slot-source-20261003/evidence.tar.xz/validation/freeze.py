"""Freeze reviewed shared-slot sources and tests without changing shared Git state."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
OLD=P/'workspace/test-logs/decoder-mean-centered-source-20261003'
BASE=json.loads((R/'base.json').read_bytes())['base']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):
    (R/name).write_text(json.dumps(value,indent=2)+'\n')

if __name__=='__main__':
    assert not (R/'experiment-source').exists()
    changed=['ipfs_datasets_py/logic/formalization/autoencoder/long_span_source_value_training.py']
    new=['ipfs_datasets_py/logic/formalization/autoencoder/shared_slot_source_decoder_experiment.py',
         'scripts/ops/autoencoder/benchmark_shared_slot_source_reconstruction.py']
    new_tests=['tests/unit/logic/formalization/autoencoder/test_shared_slot_source_decoder_experiment.py',
               'tests/unit/logic/formalization/autoencoder/test_benchmark_shared_slot_source_reconstruction.py']
    for name in ('model-ready.json','runner-ready.json'):
        ready=json.loads((R/name).read_bytes()); assert ready['ready'] is True
        for rel,value in ready['files'].items():
            assert sha(P/rel)==(value['sha256'] if isinstance(value,dict) else value),rel
    prior_tests=json.loads((OLD/'validated-test-source-r2.json').read_bytes())
    for rel,digest in prior_tests.items(): assert sha(P/rel)==digest,rel
    pins=json.loads((OLD/'frozen-extensions-r2.json').read_bytes())
    for rel,digest in pins.items():
        assert sha(OLD/'experiment-source-r2'/rel)==digest,rel
        assert hashlib.sha256(subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)).hexdigest()==digest,rel
    for rel in changed+new: pins[rel]=sha(P/rel)
    for rel,digest in pins.items():
        source=P/rel if rel in changed+new else OLD/'experiment-source-r2'/rel
        target=R/'experiment-source'/rel; target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target); assert sha(target)==digest
    tests=list(dict.fromkeys(json.loads((R/'test-files.json').read_bytes())+new_tests))
    for rel in tests:
        target=R/'experiment-source'/rel; target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(P/rel,target)
    # This script is exercised by a regression test, not the training runner.
    # Freezing test files also relocates their ROOT-relative script imports.
    test_helpers={}
    for rel in ('scripts/ops/autoencoder/evaluate_rejected_decoder_controls.py',):
        data=subprocess.check_output(['git','show',BASE+':'+rel],cwd=P)
        assert (P/rel).read_bytes()==data,rel
        target=R/'experiment-source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data);test_helpers[rel]=hashlib.sha256(data).hexdigest()
    save('test-helper-sources.json',test_helpers)
    save('test-files.json',tests)
    save('validated-test-source.json',{rel:sha(P/rel) for rel in tests})
    save('frozen-extensions.json',pins)
    save('code-files.json',changed+new+new_tests+['docs/autoencoders/decoder_length_distillation.md'])
    print(json.dumps(dict(extensions=len(pins),test_files=len(tests))))
