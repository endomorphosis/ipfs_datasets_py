"""Independent persisted-evidence checks; no model, optimizer or prover execution.

One local SHA-pinned standard-library helper owns historical fidelity/selection
arithmetic. This file owns projected affine heads, training-only preprocessing,
control assignments, exposure, and provenance. Neither helper imports Torch.
"""
from collections import Counter
from pathlib import Path
import argparse
import ast
import datetime
import hashlib
import importlib.util
import json
import math
import random
import struct
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
R = Path(__file__).resolve().parent
HELPER = R/'audit_leaf_arithmetic.py'
HELPER_SHA = 'ea440ebb1fc7b978da165329c864a69631be88048f2b694690522674cdc98c47'
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA:
    raise ValueError('standalone historical arithmetic helper changed')
spec = importlib.util.spec_from_file_location('_projected_source_leaf_audit', HELPER)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
read, sha, digest, raw = old.read, old.sha, old.digest, old.raw
artifacts, findings = old.artifacts, old.findings
COUNTS = {}


def check(condition, label, detail=None):
    bucket = COUNTS.setdefault(label.split('/', 1)[0], {'passed': 0, 'failed': 0})
    bucket['passed' if condition else 'failed'] += 1
    if not condition:
        findings.append({'priority': 'blocking', 'finding': label, 'detail': detail})


old.check = check
artifacts[str(HELPER)] = {'sha256': HELPER_SHA, 'bytes': HELPER.stat().st_size}
FIELDS = ('actor', 'action', 'modality', 'object')
TRAINER_FUNCTION_SHA = '78a668788c7878a7e8eb5fbee75087eb0ed9d4983e9a5ca50a9592ec0a1acc17'
COHORT_GUARD_AST = '''
if head_specification is not None and head_specification.get("schema") == "projected-source-decoder-development/v1":
    inventory = [dict(id=row["id"], source_sha256=hashlib.sha256(row["source_text"].encode()).hexdigest()) for row in training_rows]
    for name in ("normalization", "count_prior"):
        receipt = head_specification[name]
        core._require(receipt["training_rows_sha256"] == core.digest(training_rows)
            and receipt["training_inventory"] == inventory
            and receipt["expected_training_ids"] == [row["id"] for row in training_rows]
            and set(receipt["forbidden_validation_ids"]) == tune_ids,
            "projected-source receipt cohort differs from actual training/validation rows")
'''
UNCHANGED = {
    'decoder_source_fidelity.py': '2f8d9a9722d1375582768e9502b9ca49af0f1961df115b49f2778b4f0e07fa25',
    'long_span_decoder_training.py': 'e030596898619fc802424ba94f954224e18b5d2c8077488802621aa67a3ccdbe',
}


def close(a, b, tolerance=3e-6):
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(close(a[k], b[k], tolerance) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(close(x, y, tolerance) for x, y in zip(a, b))
    if type(a) in (int, float) and type(b) in (int, float):
        return math.isfinite(a) and math.isfinite(b) and math.isclose(a, b, rel_tol=tolerance, abs_tol=tolerance)
    return type(a) is type(b) and a == b


def f32(value):
    return struct.unpack('<f', struct.pack('<f', value))[0]


def affine(weight, bias, vector):
    return [f32(math.fsum(a*b for a, b in zip(row, vector))+offset) for row, offset in zip(weight, bias)]


def canonical_parameters(state):
    result = {}
    for name, value in state['model_state'].items():
        while name.startswith('body.'):
            name = name[5:]
        if name in result:
            raise ValueError('duplicate canonical parameter name')
        result[name] = value
    return result


def project(vector, donor):
    parameters = donor['model_state']
    transform = donor['input_transform']
    source = [f32(f32(f32(v)-f32(m))/transform['scale']) for v, m in zip(vector, transform['mean'])]
    down = affine(parameters['projection_down.weight'], parameters['projection_down.bias'], source)
    up = affine(parameters['projection_up.weight'], parameters['projection_up.bias'], [f32(math.tanh(v)) for v in down])
    return [f32(a+b) for a, b in zip(source, up)]


def protected_sources(source):
    folder = source/'ipfs_datasets_py/logic/formalization/autoencoder'
    for name, expected in UNCHANGED.items():
        check(sha(folder/name) == expected, 'gates/unchanged/'+name)
    tree = ast.parse((folder/'long_span_source_value_training.py').read_text())
    training = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'train')
    expected_guard = ast.dump(ast.parse(COHORT_GUARD_AST).body[0], include_attributes=False)
    matches = [i for i, node in enumerate(training.body) if ast.dump(node, include_attributes=False) == expected_guard]
    check(len(matches) == 1, 'gates/exact_new_schema_only_train_cohort_guard')
    if len(matches) == 1:
        training.body.pop(matches[0])
    protected = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))
        and node.name != '_head_specification']
    actual = hashlib.sha256(ast.dump(ast.Module(body=protected, type_ignores=[]), include_attributes=False).encode()).hexdigest()
    check(actual == TRAINER_FUNCTION_SHA, 'gates/all_existing_trainer_functions_except_exact_schema_and_cohort_guards_unchanged')


def common(manifest_path, plan_path, source):
    manifest, plan = read(manifest_path), read(plan_path)
    check(sha(plan_path) == manifest['plan_sha256'], 'pins/predeclared_plan')
    for path, expected in manifest['inputs'].items():
        check(sha(path) == expected, 'pins/input/'+path)
    for relative, expected in manifest['extensions'].items():
        check(sha(source/relative) == expected, 'pins/frozen_extension/'+relative)
    protected_sources(source)
    check(plan['seed_order'] == [1729, 2718] and len(plan['arms']) == 4
        and {(a['normalization'], a['guide_boundary']) for a in plan['arms']} ==
            {('none', False), ('none', True), ('center_rms', False), ('center_rms', True)}, 'plan/exact_two_by_two_by_two_design')
    check(plan['representation_dimension'] == 384 and plan['fixed_decoder_output_limit'] == 512
        and plan['fixed_encoder_context_tokens'] == 512 and plan['temperature'] == 0
        and plan['no_downloads'] is True and plan['native_qualification'] is False
        and plan['selection_unchanged'] is True and plan['production_promotion_allowed'] is False, 'plan/unchanged_scope_and_limits')
    check(plan['count_prior_classes'] == list(range(1, 33)) and plan['count_prior_total_concentration'] == 1.
        and plan['count_prior_alpha_per_class'] == 1/32 and plan['normalization_fit_split'] == plan['count_prior_fit_split'] == 'train',
        'plan/all_class_positive_prior_and_train_only_preprocessing')
    corpus, donor, embeddings = (read(manifest[key]) for key in ('paragraphs', 'donor', 'embeddings'))
    publication = read(manifest['parent_public_manifest'])
    check(sha(manifest['parent_public_manifest']) == '81f743615576d891a6470dac3a59c60218caa03486e0f2318b85a4994403c689',
        'pins/published_470213895_predecessor_manifest')
    for key in ('donor', 'paragraphs', 'embeddings', 'curriculum', 'curriculum_inputs'):
        path = manifest[key]
        member = publication['original_artifact_archive_paths'].get(path)
        previous = publication['members'][member] if member else publication['referenced_artifacts'][path]
        check(sha(path) == previous['sha256'] and Path(path).stat().st_size == previous['bytes'], 'pins/original_published_data/'+key)
    vectors = {row['input_id']: row['vector'] for row in embeddings['rows']}
    check(len(corpus['train']) == len(corpus['validation']) == 48
        and not {r['id'] for r in corpus['train']} & {r['id'] for r in corpus['validation']}
        and not {r['source_text'] for r in corpus['train']} & {r['source_text'] for r in corpus['validation']}, 'data/disjoint_complete_development_splits')
    for split in ('train', 'validation'):
        check(Counter(r['clause_count'] for r in corpus[split]) == {1: 12, 2: 12, 4: 12, 8: 12}, 'data/balanced_lengths/'+split)
        check(all(len(vectors[r['id']]) == 384 and len(r['target_ids']) <= 512 for r in corpus[split]), 'data/exact_geometry_and_full_targets/'+split)
    return dict(manifest=manifest, plan=plan, source=source, corpus=corpus, donor=donor, vectors=vectors)


def readiness(args):
    ctx = common(args.manifest, args.plan, args.source)
    resource = read(R/'resource-compatibility.json')
    owner = resource['executed_historical_owner']
    scheduler = resource['executed_scheduler']
    check(sha(owner['path']) == owner['sha256'] == '5ed9b83f571a4a892e1fac4a1fe6f5a995950d0725bad8461a0876a9415a03d1', 'resources/authenticated_frozen_owner')
    check(sha(scheduler['executed_path']) == scheduler['sha256'] == 'a418e84f70ed8509ba0518feea69e7a8c27865139f83b6c81349eefdfd5893a4', 'resources/authenticated_scheduler')
    check(resource['reservation_bytes'] == 800000000 and resource['storage_cap_changed'] is False
        and resource['ledger_mutated'] is False, 'resources/declared_bounded_reservation_unchanged_cap')
    for name in ('run_training_reserved.py', 'adopt_shared_scheduler.py'):
        path = R/name
        artifacts[str(path)] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    check(sha(R/'adopt_shared_scheduler.py') == 'c16eb27b9c46bd7e06541bd36ffb5d5f1edc686e15ca12143aca68ea9bfc2dee',
        'resources/unchanged_tested_exact_config_adapter')
    baseline = read(R/'baseline-producer-pins.json')
    check(baseline['publication_base'] == '470213895f4377bb1ca2f342e3962f90968f8bc7'
        and len(baseline['pins']) == 92, 'pins/complete_prior_producer_inventory')
    dependency = P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
    for relative, expected in baseline['pins'].items():
        if relative in baseline['intentional_edits']:
            continue  # Protected trainer bodies are checked separately, schema recognition is intentional.
        path = (args.source if relative in ctx['manifest']['extensions'] else dependency)/relative
        check(sha(path) == expected, 'pins/authenticated_published_producer/'+relative)
    tests = test_receipts()
    return dict(ready=not findings, scope='static prerequisite and authenticated inputs; live resource admission remains guardian responsibility',
        original_data_inputs_checked=5, tests=tests, encoder_context=512, output_limit=512)


def preprocess(ctx, value):
    corpus, vectors, donor = ctx['corpus'], ctx['vectors'], ctx['donor']
    # Exact runner field names are frozen before execution, never inferred from outcomes.
    features, count_rows = value['feature_rows'], value['count_rows']
    expected_ids = [r['id'] for r in corpus['train']]
    validation_ids = [r['id'] for r in corpus['validation']]
    lookup = {r['id']: r for r in corpus['train']}
    check([r['id'] for r in features] == [r['id'] for r in count_rows] == expected_ids, 'preprocessing/exact_training_order')
    for row, count in zip(features, count_rows):
        identity = row['id']
        source_sha = hashlib.sha256(lookup[identity]['source_text'].encode()).hexdigest()
        check(set(row) == {'id', 'source_sha256', 'features'} and set(count) == {'id', 'source_sha256', 'count'}
            and row['source_sha256'] == count['source_sha256'] == source_sha and count['count'] == lookup[identity]['clause_count'],
            'preprocessing/source_only_geometry_and_training_count/'+identity)
        check(close(row['features'], project(vectors[identity], donor), 1e-5), 'preprocessing/independent_frozen_projection/'+identity)
    matrix = [r['features'] for r in features]
    means = [math.fsum(row[i] for row in matrix)/48 for i in range(384)]
    energy = math.fsum((row[i]-means[i])**2 for row in matrix for i in range(384))/48
    scale = 1. if energy == 0. else math.sqrt(energy)
    inventory = [{k: row[k] for k in ('id', 'source_sha256')} for row in features]
    numerical_rows = [dict(id=r['id'], input=vectors[r['id']], target_ids=r['target_ids'], source_text=r['source_text']) for r in corpus['train']]
    for kind, receipt in value['normalizations'].items():
        check(kind in ('none', 'center_rms') and receipt['kind'] == kind
            and receipt['receipt_sha256'] == digest({k: v for k, v in receipt.items() if k != 'receipt_sha256'}), 'preprocessing/normalization_receipt_hash/'+kind)
        check(receipt['training_inventory'] == inventory and receipt['expected_training_ids'] == expected_ids
            and receipt['forbidden_validation_ids'] == validation_ids and receipt['validation_rows_used_for_fitting'] == 0
            and receipt['training_feature_rows_sha256'] == digest(features) and receipt['training_rows_sha256'] == digest(numerical_rows),
            'preprocessing/train_only_normalization_inventory/'+kind)
        check(close(receipt['fitted_training_mean'], means, 1e-12)
            and close(receipt['fitted_training_centered_row_squared_norm'], energy, 1e-12)
            and close(receipt['fitted_training_scale'], scale, 1e-12)
            and receipt['constant_training_features'] is (energy == 0.), 'preprocessing/independent_float64_statistics/'+kind)
        check(close(receipt['mean'], means if kind == 'center_rms' else [0.]*384, 1e-12)
            and close(receipt['scale'], scale if kind == 'center_rms' else 1., 1e-12), 'preprocessing/actual_transform/'+kind)
    prior = value['count_prior']
    histogram = [sum(r['count'] == k for r in count_rows) for k in range(1, 33)]
    probabilities = [(n+1/32)/49 for n in histogram]
    check(prior['receipt_sha256'] == digest({k: v for k, v in prior.items() if k != 'receipt_sha256'})
        and prior['training_inventory'] == inventory and prior['training_count_rows_sha256'] == digest(count_rows)
        and prior['training_rows_sha256'] == digest(numerical_rows) and prior['expected_training_ids'] == expected_ids
        and prior['forbidden_validation_ids'] == validation_ids and prior['validation_rows_used_for_fitting'] == 0,
        'preprocessing/train_only_prior_identity')
    check(prior['class_counts'] == histogram and prior['count_classes'] == list(range(1, 33))
        and prior['alpha_per_class'] == 1/32 and prior['total_pseudocount'] == 1.
        and prior['probabilities'] == probabilities and min(probabilities) > 0.
        and close(prior['log_prior'], [f32(math.log(f32(p))) for p in probabilities], 2e-7), 'preprocessing/independent_smoothed_prior')
    return dict(training_rows=48, dimension=384, mean_recomputed=True, scale_recomputed=scale,
        count_histogram=histogram, positive_support_classes=32)


class Selector:
    """Independent replay of the documented Python count-row stream."""
    def __init__(self, rows, seed):
        self.rng = random.Random(seed)
        self.classes = sorted({r['clause_count'] for r in rows})
        self.order = {k: [r['id'] for r in rows if r['clause_count'] == k] for k in self.classes}
        for ids in self.order.values():
            self.rng.shuffle(ids)
        self.positions = dict.fromkeys(self.classes, 0)
        self.cursor = 0

    def take(self, size):
        result = []
        for _ in range(size):
            kind = self.classes[self.cursor]
            self.cursor = (self.cursor+1) % len(self.classes)
            if self.positions[kind] == len(self.order[kind]):
                self.rng.shuffle(self.order[kind])
                self.positions[kind] = 0
            result.append(self.order[kind][self.positions[kind]])
            self.positions[kind] += 1
        return result


def exposure(report, corpus, label):
    lookup = {r['id']: r for r in corpus['train']}
    selector = Selector(corpus['train'], report['config']['seed'])
    count_stream, decoder_stream = hashlib.sha256(), hashlib.sha256()
    count_classes, inverse_mass = Counter(), Counter()
    epochs, norms = {}, []
    source_total = tokens = rows = 0
    for number, update in enumerate(report['committed_updates'], 1):
        ids, count_ids = update['decoder_row_ids'], update['count_row_ids']
        stage = next(s for s in report['curriculum'] if s['name'] == update['stage'])
        check(update['optimizer_step'] == number and 1 <= len(ids) <= 8 and len(set(ids)) == len(ids)
            and set(ids) <= set(stage['training_ids']) and count_ids == selector.take(len(ids)), label+'/committed_train_only_rows/'+str(number))
        row_tokens = sum(len(lookup[i]['target_ids'])-1 for i in ids)
        row_values = sum(4*lookup[i]['clause_count'] for i in ids)
        check(update['target_token_presentations'] == row_tokens and update['source_value_presentations'] == row_values,
            label+'/committed_exposure/'+str(number))
        expected = update['weighted_token_ce'] + report['config']['reconstruction_weight']*update['raw_reconstruction_mse']
        expected += .25*update['count_ce'] + .25*update['source_value_ce']
        check(close(update['objective'], expected, 5e-7), label+'/objective_arithmetic/'+str(number))
        norms.append(update['preclip_norm'])
        count_stream.update(raw(count_ids)); decoder_stream.update(raw(ids))
        rows += len(ids); tokens += row_tokens; source_total += row_values
        epochs.setdefault(update['epoch'], []).extend(ids)
        for identity in count_ids:
            key = str(lookup[identity]['clause_count'])
            count_classes[key] += 1; inverse_mass[key] += 1/len(ids)
    check(len(norms) == report['optimizer_steps'] == 340 and rows == report['row_presentations'] == report['count_training_row_presentations'] == 2440
        and tokens == report['valid_target_token_presentations'] == 225840 and source_total == report['source_value_presentations'] == 25600,
        label+'/complete_fixed_exposure')
    check(count_stream.hexdigest() == report['committed_count_batch_ids_sha256'] and decoder_stream.hexdigest() == report['committed_decoder_batch_ids_sha256']
        and dict(count_classes) == report['count_training_presentations_by_class'] == {str(k): 610 for k in (1, 2, 4, 8)}
        and dict(inverse_mass) == report['count_mean_loss_exposure_by_class'] == {str(k): 85. for k in (1, 2, 4, 8)}, label+'/balanced_exposure_and_stream_hashes')
    for row in report['history']:
        stage = next(s for s in report['curriculum'] if s['name'] == row['stage'])
        check(Counter(epochs[row['epoch']]) == Counter(stage['training_ids']), label+'/complete_epoch/'+str(row['epoch']))
    check(report['count_validation_rows_used_for_training'] is False and report['source_value_validation_rows_used_for_training'] is False
        and report['count_metrics_used_for_selection'] is False and report['source_value_metrics_used_for_selection'] is False
        and report['optimizer_instance_count'] == 1 and report['optimizer_reinitialized_between_stages'] is False, label+'/scope_and_optimizer_continuity')
    for first, second in zip(report['stage_reports'], report['stage_reports'][1:]):
        check(first['optimizer_state_end'] == second['optimizer_state_start'], label+'/adam_continuity/'+second['name'])
    return dict(steps=340, decoder_rows=2440, count_rows=2440, target_tokens=225840, scalar_values=25600)


def scalar_metrics(value, refs, codec, label):
    lookup = {r['id']: r for r in refs}; vocabulary = codec['target_vocabulary']
    check([r['id'] for r in value['predictions']] == [r['id'] for r in refs], label+'/complete_ordered_rows')
    correct = total = 0; loss = 0.; by_length, by_field = {}, {}
    for row in value['predictions']:
        reference = lookup[row['id']]; expected = [[-1]*4 for _ in range(8)]
        for slot, rule in enumerate(reference['target']['rules']):
            expected[slot] = [vocabulary.index(json.dumps(rule[field], ensure_ascii=True)) for field in FIELDS]
        check(row['expected_token_ids'] == expected and old.shape(row['raw_logits']) == [8, 4, len(vocabulary)], label+'/targets_and_geometry/'+row['id'])
        predicted = [[scores.index(max(scores)) for scores in slot] for slot in row['raw_logits']]
        check(predicted == row['predicted_token_ids'], label+'/full_vocabulary_argmax/'+row['id'])
        length = by_length.setdefault(str(reference['clause_count']), dict(present_values=0, correct=0, rows=0)); length['rows'] += 1
        for slot, labels in enumerate(expected):
            for i, target in enumerate(labels):
                if target == -1: continue
                scores = row['raw_logits'][slot][i]; maximum = max(scores)
                loss += maximum+math.log(sum(math.exp(v-maximum) for v in scores))-scores[target]
                hit = int(predicted[slot][i] == target); correct += hit; total += 1
                length['present_values'] += 1; length['correct'] += hit
                field = by_field.setdefault(FIELDS[i], dict(present_values=0, correct=0, classes={}))
                field['present_values'] += 1; field['correct'] += hit
                cls = field['classes'].setdefault(vocabulary[target], dict(expected=0, correct=0, predicted={}))
                cls['expected'] += 1; cls['correct'] += hit
                guess = vocabulary[predicted[slot][i]]; cls['predicted'][guess] = cls['predicted'].get(guess, 0)+1
    for field in by_field.values():
        field['accuracy'] = field['correct']/field['present_values']
        for cls in field['classes'].values(): cls['recall'] = cls['correct']/cls['expected']
        field['macro_class_recall'] = sum(c['recall'] for c in field['classes'].values())/len(field['classes'])
    check(value['correct'] == correct and value['present_values'] == total == 720 and value['rows'] == 48
        and value['accuracy'] == correct/total and value['absent_slots_unscored'] == 816
        and value['by_length'] == by_length and value['by_field'] == by_field and close(value['cross_entropy'], loss/total), label+'/scalar_confusion_ce_and_denominators')
    check(value['references_passed_to_model'] is False and value['used_for_selection'] is False, label+'/diagnostic_scope')


def count_metrics(count, refs, label):
    old.audit_counts(count, refs, label)
    lookup = {r['id']: r['clause_count'] for r in refs}
    matrix = {str(k): {str(i): 0 for i in range(1, 33)} for k in (1, 2, 4, 8)}
    losses, entropies, confidence = [], [], []
    for row in count['predictions']:
        logits, probabilities = row['logits'], row['probabilities']; peak = max(logits)
        denom = sum(math.exp(v-peak) for v in logits)
        expected = [math.exp(v-peak)/denom for v in logits]
        check(len(logits) == len(probabilities) == 32 and close(expected, probabilities, 3e-6)
            and row['predicted'] == logits.index(peak)+1, label+'/softmax_argmax/'+row['id'])
        entropy = -sum(p*math.log(p) for p in probabilities if p)
        check(close(entropy, row['predictive_entropy']), label+'/entropy/'+row['id'])
        matrix[str(lookup[row['id']])][str(row['predicted'])] += 1
        losses.append(peak+math.log(denom)-logits[lookup[row['id']]-1]); entropies.append(entropy); confidence.append(max(probabilities))
    check(matrix == count['confusion_matrix'] and close(sum(losses)/48, count['cross_entropy'])
        and close(sum(entropies)/48, count['mean_predictive_entropy'])
        and close(sum(confidence)/48, count['mean_max_probability']), label+'/independent_count_statistics')


def source_binding(evaluation, state, projected, label, cache):
    parameters = canonical_parameters(state)
    assignments = evaluation['execution']['source_assignment']; zero = evaluation['execution']['kind'] == 'zero_condition'
    values = {r['id']: r for r in evaluation['source_values']['predictions']}
    counts = {r['id']: r for r in evaluation['source_count']['predictions']}
    zero_key = ('zero_weight_heads', state['tensor_sha256'])
    if zero_key not in cache:
        cache[zero_key] = (all(v == 0. for v in old.flat(parameters['source_value_head.weight'])),
            all(v == 0. for v in old.flat(parameters['count_head.weight'])))
    zero_scalar_weight, zero_count_weight = cache[zero_key]
    max_scalar = max_count = 0.
    for identity, assigned in assignments.items():
        key = (state['tensor_sha256'], None if zero else assigned)
        if key not in cache:
            features = [0.]*384 if zero else [f32(f32(v-m)/parameters['source_scale']) for v, m in zip(projected[assigned], parameters['source_mean'])]
            scalar = parameters['source_value_head.bias'] if zero or zero_scalar_weight else affine(
                parameters['source_value_head.weight'], parameters['source_value_head.bias'], features)
            residual = parameters['count_head.bias'] if zero or zero_count_weight else affine(
                parameters['count_head.weight'], parameters['count_head.bias'], features)
            count = [f32(v+p) for v, p in zip(residual, parameters['count_prior_logits'])]
            cache[key] = (scalar, count)
        scalar, count = cache[key]
        observed = list(old.flat(values[identity]['raw_logits']))
        a = max(abs(x-y) for x, y in zip(scalar, observed)); b = max(abs(x-y) for x, y in zip(count, counts[identity]['logits']))
        max_scalar = max(max_scalar, a); max_count = max(max_count, b)
        check(close(scalar, observed, 3e-5) and close(count, counts[identity]['logits'], 3e-5), label+'/saved_affine_heads_and_assigned_source/'+identity,
            dict(max_scalar_absolute_error=a, max_count_absolute_error=b))
    return dict(max_scalar_error=max_scalar, max_count_error=max_count,
        scope='stdlib saved affine arithmetic; float32 boundaries, float64 dot accumulation; no neural framework or recurrent generation')


def evaluation_scope(value, refs, vectors, expected_kind, label):
    report, execution = value['report'], value['execution']; assignment = execution['source_assignment']
    lookup = {r['id']: r for r in refs}
    check(report['complete'] is True and report['optimizer_steps'] == 0 and report['generation_target_access'] is False
        and report['generation_temperature'] == 0 and report['max_target_tokens'] == 512 and report['input_dimension'] == 384
        and execution['training_performed'] is False and execution['selection_performed'] is False, label+'/fixed_state_target_free_scope')
    kind = 'source_shuffle' if expected_kind == 'cross_length_shuffle' else expected_kind
    check(execution['kind'] == kind and set(assignment) == set(assignment.values()) == set(lookup), label+'/complete_source_permutation')
    if expected_kind in ('source_shuffle', 'cross_length_shuffle'):
        same = expected_kind == 'source_shuffle'
        check(all(k != v and (lookup[k]['clause_count'] == lookup[v]['clause_count']) is same for k, v in assignment.items()), label+'/control_stratum')
        expected = {k: dict(original_input_sha256=digest(vectors[k]), substituted_input_sha256=digest(vectors[v])) for k, v in assignment.items()}
        check(execution['input_substitutions'] == expected and all(vectors[k] != vectors[v] for k, v in assignment.items()), label+'/actual_source_substitutions')
        if expected_kind == 'cross_length_shuffle':
            order = sorted(lookup, key=lambda identity: (lookup[identity]['clause_count'], identity))
            check(assignment == {identity: order[(i+12) % 48] for i, identity in enumerate(order)}
                and execution['shuffle_policy'] == 'cross_length', label+'/predeclared_cross_length_rotation')
    else:
        check(all(k == v for k, v in assignment.items()), label+'/identity_assignment')
    predictions = value['predictions']; metrics = report['metrics']
    check(metrics['count'] == len(refs) == len(predictions) and metrics['target_token_count'] == sum(len(r['target_ids'])-1 for r in refs)
        and metrics['eos_count'] == sum(p['eos_reached'] for p in predictions)
        and metrics['exact_targets'] == sum(p['exact_target'] for p in predictions)
        and metrics['output_limit_count'] == sum(p['generation_status'] == 'output_limit' for p in predictions), label+'/numerical_counts')
    old.authority(value, label)


def test_receipts():
    results = []
    # Development red/green iterations are retained elsewhere, but only these
    # complete frozen-source suites establish launch readiness.
    for path in (R/'tests-frozen.xml', R/'scheduler-tests.xml'):
        suites = list(ET.parse(path).getroot().iter('testsuite'))
        counts = {k: sum(int(s.get(k, 0)) for s in suites) for k in ('tests', 'failures', 'errors', 'skipped')}
        results.append(dict(path=str(path), sha256=sha(path), **counts))
        artifacts[str(path)] = dict(sha256=sha(path), bytes=path.stat().st_size)
    check(bool(results) and all(v['failures'] == v['errors'] == 0 for v in results), 'tests/recorded_suites_pass')
    validated = read(R/'validated-test-source.json')
    for relative, expected in validated.items():
        check(sha(P/relative) == expected, 'tests/validated_test_source/'+relative)
    provenance = read(R/'test-import-provenance.json')
    check(provenance.get('exit_code', 0) == 0, 'tests/frozen_import_receipt')
    return results


def boundary_metrics(value, prior, count, label):
    rows = {r['id']: r for r in count['predictions']}
    def odds(logits, k):
        maximum = max(logits[k:])
        return logits[k-1]-maximum-math.log(math.fsum(math.exp(v-maximum) for v in logits[k:]))
    check(value['applied_to_generation'] is False and value['observed_generation_boundaries'] is False
        and value['reference_clause_count_used'] is False
        and value['count_prior_receipt_sha256'] == prior['receipt_sha256'], label+'/hypothetical_scope')
    check(len(value['rows']) == len(rows) and {r['id'] for r in value['rows']} == set(rows), label+'/all_hypothetical_identities')
    for row in value['rows']:
        expected = {}
        for k in (1, 2, 4, 8):
            posterior = odds(rows[row['id']]['logits'], k); baseline = odds(prior['log_prior'], k)
            expected[str(k)] = dict(posterior_stop_tail_log_odds=posterior, prior_stop_tail_log_odds=baseline,
                hypothetical_logit_correction=posterior-baseline)
        check(close(expected, row['boundaries'], 1e-12), label+'/independent_prior_centered_log_odds/'+row['id'])


def initial_state(value, mode, preprocessing, donor, original_generation, label):
    tensors = value['model_state']; parameters = canonical_parameters(value)
    check(value['schema'] == 'private-projected-source-initial-state/v1'
        and digest(tensors) == value['weights_sha256'] and old.tensor_digest(tensors) == value['tensor_sha256'], label+'/initial_hashes')
    for name in ('count_head.weight', 'count_head.bias', 'source_value_head.weight', 'source_value_head.bias', 'source_to_embedding.weight'):
        check(all(v == 0. for v in old.flat(parameters[name])), label+'/zero_residual/'+name)
    for name, expected in donor['model_state'].items():
        check(old.tensor_bytes(parameters[name]) == old.tensor_bytes(expected), label+'/inherited_donor_bytes/'+name)
    inherited = {name[5:]: tensor for name, tensor in tensors.items() if name.startswith('body.')}
    check(old.tensor_digest(inherited) == value['inherited_tensor_sha256'] == original_generation['model_tensor_sha256']
        == preprocessing['initializer_tensor_sha256'], label+'/inherited_identity')
    normalization = preprocessing['normalizations'][mode]; prior = preprocessing['count_prior']
    expected_buffers = dict(source_mean=[f32(v) for v in normalization['mean']], source_scale=f32(normalization['scale']),
        count_prior_logits=[f32(v) for v in prior['log_prior']])
    for name, expected in expected_buffers.items():
        check(tensors[name] == expected, label+'/exact_frozen_buffer/'+name)
    check(value['architecture']['normalization'] == normalization and value['architecture']['count_prior'] == prior
        and value['architecture']['initial_decoder_logits_unchanged'] is True, label+'/initial_architecture_receipts')
    old.authority(value, label)
    return expected_buffers


def audit_results(args):
    attempt = R/args.attempt; results = attempt/'results'
    command = read(attempt/'command.json'); argv = command['command']
    argument = lambda name: Path(argv[argv.index('--'+name)+1])
    ctx = common(argument('manifest'), argument('plan'), argument('extension-root'))
    summary = read(results/'summary.json'); sealed = read(results/'sealed-recipe.json')
    check(summary['schema'] == 'projected-source-reconstruction-comparison/v1' and summary['complete'] is True
        and sealed['manifest'] == ctx['manifest'] and sealed['plan'] == ctx['plan']
        and sealed['historical_fitted_states_loaded'] is False and summary['historical_fitted_states_loaded'] is False,
        'results/complete_exact_predeclared_experiment')
    for scoped, expected in summary['source_dependencies'].items():
        scope, relative = scoped.split(':', 1)
        path = (argument('dependency-root') if scope == 'dependency' else ctx['source'])/relative
        check(scope in ('dependency', 'extension') and sha(path) == expected, 'pins/actual_loaded_producer/'+scoped)
    check(summary['dimensions_actually_trained'] == [384] and summary['source_preprocessing_fit_split'] == 'train'
        and summary['workers'] == 1 and summary['bridge_names'] == []
        and all(summary[k] is False for k in ('legal_ir_evaluate_provers', 'metric_disk_cache_used', 'encoder_executed',
            'encoder_context_changed', 'output_limit_changed', 'downloads_performed')), 'results/scope_without_native_or_bridge_claim')
    old.authority(summary, 'results')
    preparation = read(results/'preprocessing.json')
    check(sha(results/'preprocessing.json') == summary['preprocessing_sha256']
        and preparation['validation_vectors_used'] is False and preparation['validation_targets_used'] is False,
        'preprocessing/summary_and_training_only_scope')
    prep_record = preprocess(ctx, preparation)
    original = read(results/'original-initial-generation.json')
    for split in ('train', 'validation'):
        check([r['id'] for r in original['predictions'][split]] == [r['id'] for r in ctx['corpus'][split]]
            and original['target_tokens_passed_to_model'] is False and original['reference_documents_passed_to_model'] is False
            and original['max_target_tokens'] == 512 and original['temperature'] == 0, 'initial/original_complete_target_free_inventory/'+split)
    initial, buffers = {}, {}
    for mode in ('none', 'center_rms'):
        initial[mode] = read(results/('initial-state-'+mode+'.json'))
        buffers[mode] = initial_state(initial[mode], mode, preparation, ctx['donor'], original, 'initial/'+mode)
    projected = {identity: project(vector, ctx['donor']) for identity, vector in ctx['vectors'].items()}
    expected_arms = [recipe['name']+'-'+str(seed) for seed in ctx['plan']['seed_order'] for recipe in ctx['plan']['arms']]
    check([r['arm'] for r in summary['runs']] == expected_arms, 'results/all_eight_predeclared_ordered_fits')
    records = []; count_panels = 0
    for run in summary['runs']:
        arm = run['arm']; folder = results/arm; recipe = run['recipe']; mode = recipe['normalization']
        report = read(folder/'training.json')
        check(run == read(folder/'summary.json') and report == run['training'] and run['budget_completed'] is True
            and recipe in ctx['plan']['arms'] and report['stopped_reason'] == 'epochs_completed', arm+'/durable_report_identity')
        check(report['initial_weights_sha256'] == initial[mode]['tensor_sha256']
            and run['initial_inherited_tensor_sha256'] == original['model_tensor_sha256'], arm+'/original_initialization')
        init = read(folder/'initial-generation.json')
        initial_path = results/('initial-state-'+mode+'.json')
        check(init == run['initial_greedy_invariance'] and init['identical_to_original_greedy'] is True
            and init['predictions'] == original['predictions'] and init['model_tensor_sha256'] == initial[mode]['tensor_sha256']
            and init['original_tensor_sha256'] == original['model_tensor_sha256']
            and init['initial_state'] == dict(path=str(initial_path), sha256=sha(initial_path), bytes=initial_path.stat().st_size), arm+'/full_initial_greedy_parity_and_shared_state_binding')
        check(report['source_value_weight'] == report['cardinality_weight'] == .25 and report['count_exposure'] == 'balanced_all'
            and report['strategy'] == 'semantic_fields' and report['selection'] == 'per_length_nonregression_then_fidelity_progress_then_reference_ce'
            and report['generation_temperature'] == 0 and report['config']['max_target_tokens'] == 512
            and report['teacher_distillation_used'] is False and report['config']['alpha'] == 0., arm+'/unchanged_losses_and_selection_policy')
        exposure_record = exposure(report, ctx['corpus'], arm)
        selection = old.audit_selection(report, arm+'/selection')
        cache = {}; role_records = {}
        for role in ('selected', 'last-attempt'):
            state = read(folder/(role+'-state.json'))
            expected_hash = report['selected_weights_sha256'] if role == 'selected' else report['last_complete_attempt_weights_sha256']
            check(state['schema'] == 'private-projected-source-state/v1' and state['recipe'] == recipe and state['role'] == role
                and digest(state['model_state']) == state['weights_sha256']
                and old.tensor_digest(state['model_state']) == state['tensor_sha256'] == expected_hash
                and state['selected'] == (role == 'selected' or report['last_complete_attempt_is_selected']), arm+'/'+role+'/state_role_tensor_and_json_digests')
            old.audit_projections(state['model_state'], ctx['donor'], report['frozen_parameter_names'], arm+'/'+role)
            for name, expected in buffers[mode].items():
                check(state['model_state'][name] == expected, arm+'/'+role+'/unchanged_preprocessing_buffer/'+name)
            architecture = state['architecture']
            check(architecture['normalization'] == preparation['normalizations'][mode]
                and architecture['count_prior'] == preparation['count_prior']
                and architecture['count_features'] == 'normalized_projected_source'
                and architecture['guide_boundary'] is recipe['guide_boundary']
                and architecture['syntax_forced'] is False and architecture['closure_forced'] is False,
                arm+'/'+role+'/architecture_and_no_forced_closure')
            old.authority(state, arm+'/'+role)
            role_records[role] = {}
            for label, split, kind in ctx['plan']['postfit_controls']:
                evaluation = read(folder/role/('evaluation-'+label+'.json'))
                refs = ctx['corpus'][split]; prefix = arm+'/'+role+'/'+label
                evaluation_scope(evaluation, refs, ctx['vectors'], kind, prefix)
                old.audit_fidelity(evaluation['source_fidelity'], refs, evaluation['predictions'], ctx['donor']['codec'], prefix)
                scalar_metrics(evaluation['source_values'], refs, ctx['donor']['codec'], prefix+'/scalar')
                count_metrics(evaluation['source_count'], refs, prefix+'/count')
                boundary_metrics(evaluation['hypothetical_boundary_diagnostics'], preparation['count_prior'], evaluation['source_count'], prefix+'/boundary')
                binding = source_binding(evaluation, state, projected, prefix, cache)
                expected_summary = dict(numerical=evaluation['report'], source_count=evaluation['source_count'],
                    timing=evaluation['timing'], execution=evaluation['execution'],
                    source_values={k: v for k, v in evaluation['source_values'].items() if k != 'predictions'},
                    hypothetical_boundary_diagnostics=evaluation['hypothetical_boundary_diagnostics'],
                    source_fidelity={k: v for k, v in evaluation['source_fidelity'].items() if k != 'rows'})
                check(run['postfit'][role][label] == expected_summary, prefix+'/complete_postfit_summary_binding')
                if label == 'validation':
                    expected_report = report['selected'] if role == 'selected' else report['last_complete_attempt']
                    check(evaluation['predictions'] == read(folder/(role+'-predictions.json'))
                        and evaluation['report']['metrics'] == expected_report['numerical']
                        and expected_summary['source_fidelity'] == expected_report['fidelity'], prefix+'/saved_generation_replay_and_training_metrics')
                role_records[role][label] = dict(metrics=evaluation['source_fidelity']['metrics'],
                    source_value_correct=evaluation['source_values']['correct'], count_correct=evaluation['source_count']['correct'], affine_binding=binding)
                count_panels += 1
        records.append(dict(arm=arm, exposure=exposure_record, selection=selection, selected_epoch=report['selected_epoch'], postfit=role_records))
        print(json.dumps(dict(audited_arm=arm, findings=len(findings))), flush=True)
    check(count_panels == 80, 'results/all_eighty_complete_control_panels')
    resource, child = read(attempt/'resources-final.json'), read(attempt/'child-exit.json')
    record = resource['record']
    check(resource['status'] == record['status'] == 'released' and record['artifacts_durable_asserted'] is True
        and child['returncode'] == 0 and child['leader_reaped'] is True
        and record['last_usage']['group_rss']['live_processes'] == 0, 'resources/complete_durable_release')
    check(record['cpu_slots'] == record['child_process_slots'] == 1 and record['memory_mb'] == 4096
        and record['storage_bytes'] == 800000000 and record['attempt_exceeded_reservation'] is False
        and record['final_accounting']['limit_bytes'] == 140000000000
        and record['final_accounting']['charged_bytes'] <= 140000000000, 'resources/unchanged_reserved_bounds')
    adoption = read(R/(args.attempt+'-scheduler-adoption.json'))
    check(adoption['complete'] is True and adoption['helper_sha256'] == sha(R/'adopt_shared_scheduler.py')
        and adoption['owner_pid'] == record['owner_pid']
        and adoption['shared_config_sha256'] == digest(adoption['shared_config'])
        and adoption['shared_config']['proof_safety_enabled'] is True
        and all(adoption[k] is False for k in ('reset_performed', 'capacity_changed', 'proof_guards_changed',
            'stale_recovery_called_by_adoption', 'global_scheduler_cache_modified'))
        and all(adoption[k] == 0 for k in ('leases_acquired_by_adoption', 'leases_released_by_adoption', 'leases_cancelled_by_adoption')),
        'resources/guardian_exact_existing_scheduler_without_foreign_claim_changes')
    readiness_receipt = read(R/'readiness.json')
    check(readiness_receipt['ready'] is True and not readiness_receipt['findings'], 'readiness/clean_static_prerequisites')
    for path, expected in ctx['manifest']['inputs'].items(): check(sha(path) == expected, 'pins/final_input/'+path)
    for relative, expected in ctx['manifest']['extensions'].items(): check(sha(ctx['source']/relative) == expected, 'pins/final_extension/'+relative)
    return dict(preprocessing=prep_record, runs=records, control_panels=count_panels, tests=test_receipts(),
        independent_scope='state hashes; source affine logits; fit statistics; saved-output grammar/facet/count arithmetic; selection and exposure',
        limits='no recurrent rollout, gradient replay, full token-CE recomputation, external provers, native family qualification, or Lake build')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('readiness', 'results'), required=True)
    parser.add_argument('--attempt', default='training-r1')
    parser.add_argument('--manifest', type=Path, default=R/'training-manifest.json')
    parser.add_argument('--plan', type=Path, default=R/'training-plan.json')
    parser.add_argument('--source', type=Path, default=R/'experiment-source')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists(): raise FileExistsError('audit receipt must be fresh')
    source_sha = sha(__file__)
    records = readiness(args) if args.phase == 'readiness' else audit_results(args)
    check(sha(__file__) == source_sha and sha(HELPER) == HELPER_SHA, 'pins/auditor_sources_unchanged')
    result = dict(schema='independent-projected-source-audit/v1', phase=args.phase, complete=True,
        created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), findings=findings, checks=COUNTS,
        checked_count=sum(sum(v.values()) for v in COUNTS.values()), failed_check_count=len(findings),
        audit_source_sha256=source_sha, audit_helper_sha256=HELPER_SHA, artifacts=artifacts, records=records,
        ready=not findings if args.phase == 'readiness' else None,
        model_training_executed_by_auditor=False, autoregressive_generation_executed_by_auditor=False,
        torch_executed_by_auditor=False, native_executed_by_auditor=False,
        **{key: False for key in old.AUTHORITY})
    with args.output.open('x') as stream:
        json.dump(result, stream, sort_keys=True, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps(dict(path=str(args.output), sha256=sha(args.output), checks=result['checked_count'], findings=findings)))
    return int(bool(findings))


if __name__ == '__main__':
    raise SystemExit(main())
