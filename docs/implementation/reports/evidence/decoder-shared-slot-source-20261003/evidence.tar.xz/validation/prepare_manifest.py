"""Predeclare exact original inputs and raw controls for the shared-slot comparison."""
from pathlib import Path
from copy import deepcopy
import hashlib
import importlib.util
import json

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
OLD=P/'workspace/test-logs/decoder-mean-centered-source-20261003'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

if __name__=='__main__':
    assert not (R/'training-manifest.json').exists()
    path=R/'experiment-source/scripts/ops/autoencoder/benchmark_shared_slot_source_reconstruction.py'
    spec=importlib.util.spec_from_file_location('_shared_slot_recipe',path)
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    old=json.loads((OLD/'training-r2-manifest.json').read_bytes())
    keys=('donor','paragraphs','embeddings','curriculum','curriculum_inputs',
          'parent_public_manifest','parent_public_results','parent_summary','parent_preprocessing',
          'state_catalog','prior_selected_evaluations')
    m={key:old[key] for key in keys}
    m['extensions']=json.loads((R/'frozen-extensions.json').read_bytes())
    paths=[m[key] for key in keys if isinstance(m[key],str)]
    assert m['prior_selected_evaluations']==runner.selected_evaluation_paths(m['parent_summary'])
    paths+=list(m['prior_selected_evaluations'].values())
    for row in m['state_catalog']:
        if row['name'] in m['prior_selected_evaluations']:
            paths.append(row['archived_evaluations']['validation'])
    m['inputs']={path:sha(path) for path in paths}
    for path,digest in m['inputs'].items(): assert old['inputs'][path]==digest,path
    plan=dict(deepcopy(runner.FIXED),input_sha256=deepcopy(m['inputs']))
    runner.validate_plan(plan);runner.validate_input_bindings(plan,m)
    with (R/'training-plan.json').open('x') as f: f.write(json.dumps(plan,indent=2)+'\n')
    m['plan_sha256']=sha(R/'training-plan.json')
    with (R/'training-manifest.json').open('x') as f: f.write(json.dumps(m,indent=2)+'\n')
    print(json.dumps(dict(input_files=len(m['inputs']),extensions=len(m['extensions']),plan_sha256=m['plan_sha256'])))
