"""Independent saved-evidence audit; no Torch, model, training or prover runs.

Two local SHA-pinned standard-library helpers retain prior fidelity, selection,
projection, count and exposure arithmetic. This owner verifies the new shared
head, mixed tensor dtypes, exact raw replay and position-support diagnostics.
"""
from pathlib import Path
from collections import Counter
import argparse
import ast
import copy
import hashlib
import importlib.util
import json
import math
import re
import struct
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
PRIOR=P/'workspace/test-logs/decoder-mean-centered-source-20261003'
HELPERS={'audit_projected_arithmetic.py':'341f91c3ed3b53430a63bd208a3d41ebd810f35cda2cce035d81b8d40fc3a9c2',
         'audit_leaf_arithmetic.py':'ea440ebb1fc7b978da165329c864a69631be88048f2b694690522674cdc98c47'}
for name,expected in HELPERS.items():
    if hashlib.sha256((R/name).read_bytes()).hexdigest()!=expected:raise ValueError('audit helper changed: '+name)
spec=importlib.util.spec_from_file_location('_shared_slot_audit_arithmetic',R/'audit_projected_arithmetic.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
leaf=base.old
read,sha,digest,raw,close=base.read,base.sha,base.digest,base.raw,base.close
check,findings,artifacts=base.check,base.findings,base.artifacts
for name,expected in HELPERS.items():artifacts[str(R/name)]=dict(sha256=expected,bytes=(R/name).stat().st_size)
AUTO='ipfs_datasets_py/logic/formalization/autoencoder/'
FIELDS=('actor','action','modality','object')
HEAD_SHAPES={'source_projection.weight':[64,384],'source_projection.bias':[64],
    'slot_embeddings':[8,64],'field_readout.weight':[128,64],'field_readout.bias':[128]}


def tensor_digest(values):
    result=hashlib.sha256()
    for name,value in sorted(values.items()):
        is_seed=name.split('.')[-1]=='head_initialization_seed'
        if is_seed:
            if type(value) is not int:raise ValueError('seed buffer must be a persisted integer')
            dtype='torch.int64';content=struct.pack('<q',value)
        else:dtype='torch.float32';content=leaf.tensor_bytes(value)
        result.update(raw([name,dtype,leaf.shape(value)]));result.update(content)
    return result.hexdigest()


def canonical(state):return base.canonical_parameters(state)


def protected_sources(source):
    path=source/AUTO/'long_span_source_value_training.py'
    previous=PRIOR/'experiment-source-r2'/AUTO/'long_span_source_value_training.py'
    check(sha(previous)=='74b0c55992dab5a038eb3c700ab44cc9af10e70936fefa4d82682f97007b5ba5','source/authenticated_prior_trainer')
    artifacts[str(previous)]=dict(sha256=sha(previous),bytes=previous.stat().st_size)
    before,after=ast.parse(previous.read_text()),ast.parse(path.read_text())
    old={node.name:node for node in before.body if isinstance(node,ast.FunctionDef)}
    new={node.name:node for node in after.body if isinstance(node,ast.FunctionDef)}
    check(old.keys()==new.keys(),'source/trainer_function_inventory')
    head=new['_head_specification']
    expected=ast.parse('''
if description.get("schema") == "shared-slot-source-decoder-development/v1":
    from . import shared_slot_source_decoder_experiment as shared_values
    return shared_values.checked_specification(model, codec)
''').body[0]
    matches=[node for node in head.body if ast.dump(node)==ast.dump(expected)]
    check(len(matches)==1,'source/exact_new_checked_head_dispatch')
    if len(matches)==1:head.body.remove(matches[0])
    old_guard=[node for node in old['train'].body if isinstance(node,ast.If) and "head_specification.get('schema')" in ast.unparse(node.test)]
    new_guard=[node for node in new['train'].body if isinstance(node,ast.If) and "head_specification.get('schema')" in ast.unparse(node.test)]
    check(len(old_guard)==len(new_guard)==1,'source/single_cohort_guard')
    if len(old_guard)==len(new_guard)==1:
        expected_test=ast.parse("head_specification is not None and head_specification.get('schema') in ('projected-source-decoder-development/v1','mean-centered-source-decoder-development/v1','shared-slot-source-decoder-development/v1')",mode='eval').body
        check(ast.dump(new_guard[0].test)==ast.dump(expected_test),'source/exact_cohort_schema_extension')
        new_guard[0].test=old_guard[0].test
    check(ast.dump(before)==ast.dump(after),'source/full_trainer_ast_unchanged_except_exact_architecture_guards')
    for name,expected_sha in {**base.UNCHANGED,
        'projected_source_decoder_experiment.py':'ce4354a96324285bff08277c3fac43e9885a75e84a50337414f7dea8501af3ee',
        'mean_centered_source_decoder_experiment.py':'bfdba26a640ecdeb1a4bcf7369a9149d83667f72a55fd2d1264e94161fbf0dd6'}.items():
        check(sha(source/AUTO/name)==expected_sha,'source/unchanged_causal_runtime_and_gates/'+name)


def common(args):
    manifest,plan=read(args.manifest),read(args.plan)
    check(sha(args.plan)==manifest['plan_sha256'] and plan['input_sha256']==manifest['inputs'],'pins/sealed_plan_and_predeclared_inputs')
    for path,expected in manifest['inputs'].items():
        check(sha(path)==expected,'pins/input/'+path)
        artifacts[path]=dict(sha256=expected,bytes=Path(path).stat().st_size)
    for relative,expected in manifest['extensions'].items():
        path=args.source/relative;check(sha(path)==expected,'pins/frozen_source/'+relative)
        artifacts[str(path)]=dict(sha256=expected,bytes=path.stat().st_size)
    protected_sources(args.source)
    expected_arms=[dict(name=name,head_kind=kind,hidden_width=width,scalar_mode='raw',normalization='center_rms',
        guide_boundary=True,source_value_weight=.25,count_exposure='balanced_all',cardinality_weight=.25)
        for name,kind,width in [('independent','independent_affine',None),('shared','shared_slot_tanh',64)]]
    check(plan['schema']=='shared-slot-source-reconstruction-plan/v1' and plan['arms']==expected_arms
        and plan['seed_order']==[1729,2718] and plan['head_initialization_seed_policy']=='same_as_fit_seed',
        'plan/exact_two_by_two_head_comparison')
    check(plan['expected_optimizer_steps_per_arm']==340 and plan['expected_training_token_presentations_per_arm']==225840
        and plan['expected_count_presentations_per_arm']==2440 and plan['expected_source_value_presentations_per_candidate']==25600,
        'plan/equal_fixed_exposure')
    check(plan['representation_dimension']==384 and plan['fixed_encoder_context_tokens']==plan['fixed_decoder_output_limit']==512
        and plan['temperature']==0 and plan['no_downloads'] is True and plan['selection_unchanged'] is True
        and plan['native_qualification'] is False and plan['production_promotion_allowed'] is False,
        'plan/unchanged_limits_and_authority')
    check(plan['scalar_auxiliary_readout']==plan['scalar_generation_guidance']=='raw_head_logits'
        and plan['source_value_full_vocabulary'] is True and plan['source_value_guidance'] is True
        and plan['generation_reference_count_access'] is False and plan['generation_reference_prefix_access'] is False
        and plan['source_segment_offsets_used'] is False and plan['source_component_metadata_used_for_generation'] is False
        and plan['cached_source_order_recoverability_claimed'] is False,'plan/causal_source_only_full_vocabulary_scope')
    corpus,donor,embeddings=[read(manifest[key]) for key in ('paragraphs','donor','embeddings')]
    vectors={row['input_id']:row['vector'] for row in embeddings['rows']}
    pre=read(manifest['parent_preprocessing']);parent=read(manifest['parent_summary'])
    ctx=dict(manifest=manifest,plan=plan,corpus=corpus,donor=donor,vectors=vectors,preprocessing=pre,
        parent_runs={run['arm']:run for run in parent['runs']})
    ctx['preprocessing_audit']=base.preprocess(ctx,pre)
    public=read(manifest['parent_public_manifest'])
    for catalog in manifest['state_catalog']:
        for path in [catalog['state_path'],*catalog['archived_evaluations'].values()]:
            member=public['original_artifact_archive_paths'].get(path)
            archived=public['members'].get(member) if member else public.get('referenced_artifacts',{}).get(path)
            if path in manifest['inputs']:
                check(archived is not None and archived['sha256']==manifest['inputs'][path], 'pins/published_parent/'+path)
    return ctx


def state_check(state,label):
    check(digest(state['model_state'])==state['weights_sha256'] and tensor_digest(state['model_state'])==state['tensor_sha256'],
          label+'/exact_json_and_mixed_dtype_tensor_hashes')
    leaf.authority(state,label)


def architecture(state,ctx,seed,label):
    a=state['architecture'];p=canonical(state);pre=ctx['preprocessing']
    check(a['normalization']==pre['normalizations']['center_rms'] and a['count_prior']==pre['count_prior'],label+'/train_only_preprocessing_receipts')
    frozen=dict(source_mean=[base.f32(v) for v in pre['normalizations']['center_rms']['mean']],
        source_scale=base.f32(pre['normalizations']['center_rms']['scale']),count_prior_logits=pre['count_prior']['log_prior'])
    for name,expected in frozen.items():check(p[name]==expected,label+'/exact_frozen_buffer/'+name)
    shared=a['schema']=='shared-slot-source-decoder-development/v1'
    if shared:
        check(type(p['head_initialization_seed']) is int and p['head_initialization_seed']==a['head_initialization_seed']==seed,
              label+'/exact_frozen_int64_seed')
        keys={name.removeprefix('source_value_head.'):value for name,value in p.items() if name.startswith('source_value_head.')}
        check(set(keys)==set(HEAD_SHAPES) and all(leaf.shape(keys[name])==shape for name,shape in HEAD_SHAPES.items()),
              label+'/shared_head_geometry_no_old_head_parameters')
        count=sum(len(list(leaf.flat(value))) for value in keys.values())
        check(count==a['source_value_parameter_count']==33472 and a['replaced_source_value_parameter_count']==394240,
              label+'/actual_shared_parameter_count')
        check(a['hidden_width']==64 and a['activation']=='tanh' and a['scalar_mode']=='raw'
            and a['independent_source_head_replaced'] is True and a['base_architecture_is_pre_replacement_donor'] is True
            and a['field_readouts_shared_across_slots'] is True and a['nonlinear_source_position_interaction'] is True
            and a['normalization_statistics_frozen'] is True and a['count_prior_frozen'] is True
            and a['full_vocabulary_retained'] is True and a['syntax_forced'] is False and a['closure_forced'] is False
            and a['count_path_changed'] is False and a['recurrent_path_changed'] is False and a['projection_path_changed'] is False
            and a['generation_reference_count_access'] is False and a['reference_documents_passed_to_generation'] is False,
              label+'/shared_causal_head_only_contract')
    else:
        check(a['schema']=='mean-centered-source-decoder-development/v1' and a['scalar_mode']=='raw'
            and p['source_reference_mean']==frozen['source_mean'],label+'/unchanged_independent_raw_wrapper')
    return shared


def head_scores(parameters,features,shared):
    def affine(w,b,x):
        return list(b) if not any(v != 0. for row in w for v in row) else base.affine(w,b,x)
    if shared:
        w=parameters['source_value_head.source_projection.weight'];b=parameters['source_value_head.source_projection.bias']
        projected=affine(w,b,features);scores=[]
        for slot in parameters['source_value_head.slot_embeddings']:
            hidden=[base.f32(math.tanh(base.f32(x+position))) for x,position in zip(projected,slot)]
            scores.extend(affine(parameters['source_value_head.field_readout.weight'],parameters['source_value_head.field_readout.bias'],hidden))
    else:scores=affine(parameters['source_value_head.weight'],parameters['source_value_head.bias'],features)
    residual=affine(parameters['count_head.weight'],parameters['count_head.bias'],features)
    return scores,[base.f32(value+prior) for value,prior in zip(residual,parameters['count_prior_logits'])]


def source_binding(state,panel,ctx,label,cache):
    p=canonical(state);shared='source_value_head.slot_embeddings' in p
    zero=panel['execution']['kind']=='zero_condition';assign=panel['execution']['source_assignment']
    scalar={row['id']:row for row in panel['source_values']['predictions']}
    counts={row['id']:row for row in panel['source_count']['predictions']}
    guide=panel['scalar_guidance'];guides={row['id']:row for row in guide['rows']}
    check(set(guides)==set(scalar)==set(counts)==set(assign),'heads/complete_source_assignment/'+label)
    check(guide['source_only'] is True and guide['reference_documents_passed_to_model'] is False
        and guide['target_tokens_passed_to_model'] is False and guide['metric_used_for_selection'] is False,
        label+'/source_only_potential_slot_scores')
    maximum=0.
    for identity,assigned in assign.items():
        key=(state['tensor_sha256'],None if zero else assigned)
        if key not in cache:
            features=[0.]*384 if zero else [base.f32(base.f32(v-m)/p['source_scale']) for v,m in zip(ctx['projected'][assigned],p['source_mean'])]
            cache[key]=head_scores(p,features,shared)
        expected,count=cache[key];actual=list(leaf.flat(scalar[identity]['raw_logits']))
        error=max(abs(a-b) for a,b in zip(actual,expected));maximum=max(maximum,error)
        check(close(actual,expected,3e-5) and close(count,counts[identity]['logits'],3e-5),
              label+'/independent_affine_tanh_and_count/'+identity,dict(max_scalar_error=error))
        check(guides[identity]['applied_logits']==scalar[identity]['raw_logits']
            and guides[identity]['predicted_token_ids']==scalar[identity]['predicted_token_ids'],
              label+'/raw_full_vocabulary_guidance_equals_auxiliary/'+identity)
    return dict(maximum_scalar_absolute_error=maximum,zero_control_retains_learned_slot_and_bias_terms=True,
        scope='Saved source-only affine/tanh/count arithmetic for actual assigned inputs; all-slot potentials are not a visited-prefix trace.')


def support(ctx):
    seen={(i,f,rule[f]) for row in ctx['corpus']['train'] for i,rule in enumerate(row['target']['rules']) for f in FIELDS}
    missing=[dict(id=row['id'],zero_based_slot=i,field=f,expected=rule[f]) for row in ctx['corpus']['validation']
        for i,rule in enumerate(row['target']['rules']) for f in FIELDS if (i,f,rule[f]) not in seen]
    check(len(missing)==9 and len({r['id'] for r in missing})==7,'coverage/unchanged_nine_position_labels_seven_documents')
    global_seen={(f,rule[f]) for row in ctx['corpus']['train'] for rule in row['target']['rules'] for f in FIELDS}
    check(all((r['field'],r['expected']) in global_seen for r in missing),'coverage/all_missing_position_values_seen_globally')
    return missing


def support_panel(panel,ctx,label):
    missing={(r['id'],r['zero_based_slot'],r['field']) for r in ctx['missing']};affected={r[0] for r in missing}
    rows={key:Counter() for key in ('all_slots_supported','has_unsupported_slot_label')}
    values={key:Counter() for key in ('supported','unsupported')}
    records={row['id']:row for row in panel['source_fidelity']['rows']}
    heads={row['id']:row for row in panel['source_values']['predictions']};details=[]
    vocab=ctx['donor']['codec']['target_vocabulary']
    for reference in ctx['corpus']['validation']:
        identity=reference['id'];record=records[identity];head=heads[identity];actual=record['generated_ir']
        generated=actual['rules'] if isinstance(actual,dict) and set(actual)=={'rules'} and isinstance(actual['rules'],list) else []
        invalid={int(m.group(1)) for error in record['errors'] for m in [re.match(r'rule\[(\d+)\]:',error)] if m}
        valid={slot:rule for slot,rule in enumerate(generated) if slot not in invalid}
        group='has_unsupported_slot_label' if identity in affected else 'all_slots_supported'
        rows[group]['rows']+=1;rows[group]['ordered_exact']+=record['counts']['ordered_exact']
        for slot,rule in enumerate(reference['target']['rules']):
            for field_index,field in enumerate(FIELDS):
                key='unsupported' if (identity,slot,field) in missing else 'supported'
                expected=vocab.index(json.dumps(rule[field],ensure_ascii=True))
                hit=head['predicted_token_ids'][slot][field_index]==expected
                generated_hit=slot in valid and valid[slot][field]==rule[field]
                values[key]['values']+=1;values[key]['raw_source_head_correct']+=int(hit)
                values[key]['generated_scalar_correct']+=int(generated_hit)
                if key=='unsupported':details.append(dict(id=identity,slot=slot,field=field,expected=rule[field],raw_head_correct=hit,generated_correct=generated_hit))
    check(values['unsupported']['values']==9 and values['supported']['values']==711
        and rows['has_unsupported_slot_label']['rows']==7 and rows['all_slots_supported']['rows']==41,label+'/complete_support_strata')
    check(sum(v['raw_source_head_correct'] for v in values.values())==panel['source_values']['correct']
        and sum(v['generated_scalar_correct'] for v in values.values())==sum(panel['source_fidelity']['by_facet'][f]['correct'] for f in FIELDS)
        and sum(v['ordered_exact'] for v in rows.values())==panel['source_fidelity']['metrics']['ordered_exact'],label+'/strata_match_audited_totals')
    return dict(scalar_strata={k:dict(v) for k,v in values.items()},document_strata={k:dict(v) for k,v in rows.items()},
        unsupported_details=details,used_for_selection=False,fresh_holdout=False)


def readiness(ctx,args):
    tests=[]
    scheduler=PRIOR/'scheduler-tests.xml'
    public=read(P/'docs/implementation/reports/evidence/decoder-mean-centered-source-20261003/manifest.json')
    for path in (scheduler,PRIOR/'scheduler-tests.log',PRIOR/'adopt_shared_scheduler.py',PRIOR/'test_adopt_shared_scheduler.py'):
        member=public['original_artifact_archive_paths'][str(path)]
        check(sha(path)==public['members'][member]['sha256'],'tests/authenticated_historical_scheduler/'+path.name)
        artifacts[str(path)]=dict(sha256=sha(path),bytes=path.stat().st_size)
        if path.suffix=='.py':check(sha(R/path.name)==sha(path),'tests/unchanged_scheduler_owner/'+path.name)
    for path in (args.tests,scheduler):
        suites=list(ET.parse(path).getroot().iter('testsuite'))
        totals={key:sum(int(s.get(key,0)) for s in suites) for key in ('tests','failures','errors','skipped')}
        check(totals['tests']>0 and all(totals[k]==0 for k in ('failures','errors','skipped')),'tests/clean/'+path.name)
        artifacts[str(path)]=dict(sha256=sha(path),bytes=path.stat().st_size);tests.append(dict(path=str(path),fresh=path==args.tests,reused=path==scheduler,**totals))
    imports=read(args.imports)
    check(imports['pytest_returncode']==0,'tests/frozen_import_exit')
    for name,value in imports['modules'].items():
        path=Path(value['path'])
        check((path.is_relative_to(args.source) or path.is_relative_to(args.dependency)) and sha(path)==value['sha256'],'tests/pinned_module/'+name)
    helper=read(R/'test-helper-sources.json')
    for name,expected in helper.items():
        path=args.source/name;check(sha(path)==expected,'tests/frozen_regression_helper/'+name)
        artifacts[str(path)]=dict(sha256=expected,bytes=path.stat().st_size)
    ctx['missing']=support(ctx)
    return dict(tests=tests,preprocessing=ctx['preprocessing_audit'],unsupported_position_labels=ctx['missing'],
        scope='Static source, unchanged trainer AST, plan/input pins, train-only preprocessing and recorded frozen suites. No model or test execution by auditor.')


def complete_scope(summary,ctx,args):
    check(summary['complete'] is True and summary['schema']=='shared-slot-source-training-comparison/v1'
        and summary['workers']==1 and summary['bridge_names']==[] and summary['dimensions_actually_trained']==[384]
        and summary['training_executed'] is True and summary['raw_training_replay_parity'] is True
        and all(summary[k] is False for k in ('legal_ir_evaluate_provers','metric_disk_cache_used','encoder_executed',
            'encoder_context_changed','output_limit_changed','downloads_performed','cached_source_order_recoverability_claimed')),
        'scope/complete_development_only_comparison')
    leaf.authority(summary,'scope')
    sealed=read(args.results/'sealed-recipe.json')
    check(sealed['manifest']==ctx['manifest'] and sealed['plan']==ctx['plan'],'pins/exact_executed_recipe')
    pre=read(args.results/'preprocessing-replay.json')
    check(pre['complete'] is True and pre['training_feature_rows_sha256']==digest(ctx['preprocessing']['feature_rows'])
        and pre['training_mean_receipt_sha256']==ctx['preprocessing']['normalizations']['center_rms']['receipt_sha256']
        and pre['validation_features_passed_to_fitting'] is False and pre['validation_targets_passed_to_fitting'] is False,
        'preprocessing/executed_training_only_replay')
    for scoped,expected in summary['source_dependencies'].items():
        scope,relative=scoped.split(':',1);path=(args.dependency if scope=='dependency' else args.source)/relative
        check(scope in ('dependency','extension') and sha(path)==expected,'pins/executed_source/'+scoped)
        artifacts[str(path)]=dict(sha256=expected,bytes=path.stat().st_size)


def released(results):
    resource,child=read(results.parent/'resources-final.json'),read(results.parent/'child-exit.json');record=resource['record']
    check(resource['status']==record['status']=='released' and record['artifacts_durable_asserted'] is True
        and child['returncode']==0 and child['leader_reaped'] is True and record['last_usage']['group_rss']['live_processes']==0,
        'resources/clean_exit_durable_release')
    check(record['attempt_exceeded_reservation'] is False
        and record['final_accounting']['charged_bytes']<=record['final_accounting']['limit_bytes']==140000000000,
        'resources/unchanged_cap_and_successful_bounds')


RAW_PARITY_FIELDS=['config','strategy','cardinality_weight','count_exposure','source_value_weight',
    'source_value_presentations','committed_decoder_batch_ids_sha256','committed_updates',
    'count_training_row_presentations','count_training_presentations_by_class','count_mean_loss_exposure_by_class',
    'committed_count_batch_ids_sha256','count_selector_initial','count_selector_final','count_training_inventory_sha256',
    'gradient_norms','curriculum','optimizer_steps','row_presentations','valid_target_token_presentations',
    'optimizer_instance_count','optimizer_reinitialized_between_stages','selected_epoch','selection','baseline','selected',
    'last_complete_attempt','last_complete_attempt_is_selected','history','stopped_reason']


def audit_panel(ctx,state,value,split,kind,label,cache):
    refs,codec=ctx['corpus'][split],ctx['donor']['codec']
    base.evaluation_scope(value,refs,ctx['vectors'],kind,label)
    leaf.audit_fidelity(value['source_fidelity'],refs,value['predictions'],codec,label)
    base.scalar_metrics(value['source_values'],refs,codec,label+'/raw_scalar')
    base.count_metrics(value['source_count'],refs,label+'/count')
    base.boundary_metrics(value['hypothetical_boundary_diagnostics'],ctx['preprocessing']['count_prior'],value['source_count'],label+'/boundary')
    return dict(exact=value['source_fidelity']['metrics']['ordered_exact'],eos=value['source_fidelity']['metrics']['eos_count'],
        syntax=value['source_fidelity']['metrics']['syntax_valid'],raw_source_value_correct=value['source_values']['correct'],
        generated_scalar_correct=sum(value['source_fidelity']['by_facet'][f]['correct'] for f in FIELDS),
        source_arithmetic=source_binding(state,value,ctx,label,cache))


def initial_state(ctx,state,run,initial,folder,label):
    state_check(state,label);shared=architecture(state,ctx,run['seed'],label);p=canonical(state)
    check(state['role']=='initial' and state['selected'] is False and state['recipe']==run['recipe']
        and state['schema']=='private-shared-slot-source-state/v1',label+'/actual_prefit_capture')
    bound=read(folder/'initial-generation.json');path=folder/'initial-state.json'
    check(bound==run['initial_greedy_invariance'] and bound['predictions']==initial['predictions']
        and bound['identical_to_original_greedy'] is True and bound['model_tensor_sha256']==state['tensor_sha256']
        and bound['initial_state']==dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size,tensor_sha256=state['tensor_sha256']),
        label+'/complete_initial_greedy_and_state_binding')
    underlying={key[5:]:value for key,value in state['model_state'].items() if key.startswith('body.')}
    check(tensor_digest(underlying)==state['underlying_body_tensor_sha256'],label+'/initial_underlying_hash')
    parent=ctx['parent_initial'];pp=canonical(parent)
    common_keys=set(pp)-{k for k in pp if k.startswith('source_value_head.')}
    check(all(p[k]==pp[k] for k in common_keys),label+'/exact_original_inherited_tensors')
    for key in ('count_head.weight','count_head.bias','source_to_embedding.weight'):
        check(all(v==0. for v in leaf.flat(p[key])),label+'/zero_initial_inherited_residual/'+key)
    if shared:
        for key in ('source_projection.bias','field_readout.weight','field_readout.bias'):
            check(all(v==0. for v in leaf.flat(p['source_value_head.'+key])),label+'/zero_initial_new_residual/'+key)
        for key,limit in (('source_projection.weight',1/math.sqrt(384)),('slot_embeddings',1/math.sqrt(64))):
            vals=list(leaf.flat(p['source_value_head.'+key]));check(all(abs(v)<=limit for v in vals) and any(v!=0. for v in vals),label+'/seeded_uniform_geometry/'+key)
    else:check(all(p[k]==pp[k] for k in pp),label+'/exact_original_independent_head')
    return p


def results(args,ctx):
    summary=read(args.results/'summary.json');complete_scope(summary,ctx,args)
    initial=read(args.results/'original-initial-generation.json')
    check(initial['predictions']==next(iter(ctx['parent_runs'].values()))['initial_greedy_invariance']['predictions']
        and initial['model_tensor_sha256']==ctx['preprocessing']['initializer_tensor_sha256'],'initial/original_donor_output_and_tensor_parity')
    path=Path(ctx['manifest']['parent_summary']).parent/'initial-state-center_rms.json'
    public=read(ctx['manifest']['parent_public_manifest']);member=public['original_artifact_archive_paths'][str(path)]
    check(sha(path)==public['members'][member]['sha256'],'initial/published_parent_state_pin');ctx['parent_initial']=read(path)
    expected=[name+'-'+str(seed) for seed in (1729,2718) for name in ('independent','shared')]
    check([run['arm'] for run in summary['runs']]==expected,'training/four_predeclared_ordered_fits')
    ctx['projected']={identity:base.project(vector,ctx['donor']) for identity,vector in ctx['vectors'].items()}
    ctx['missing']=support(ctx);records=[];panels=0;initial_heads=[]
    for run in summary['runs']:
        arm=run['arm'];folder=args.results/arm;seed=run['seed'];report=read(folder/'training.json')
        state0=read(folder/'initial-state.json');p0=initial_state(ctx,state0,run,initial,folder,arm+'/initial')
        shared=run['recipe']['head_kind']=='shared_slot_tanh'
        if shared:initial_heads.append(digest({k:v for k,v in p0.items() if k.startswith('source_value_head.')}))
        check(run==read(folder/'summary.json') and report==run['training'] and run['budget_completed'] is True
            and report['initial_weights_sha256']==state0['tensor_sha256'] and report['source_value_weight']==report['cardinality_weight']==.25
            and report['strategy']=='semantic_fields' and report['count_exposure']=='balanced_all'
            and report['selection']=='per_length_nonregression_then_fidelity_progress_then_reference_ce'
            and report['config']['alpha']==0. and report['teacher_distillation_used'] is False,
            arm+'/fixed_initialization_objective_and_selection')
        exposure=base.exposure(report,ctx['corpus'],arm);selection=leaf.audit_selection(report,arm+'/selection')
        prior=ctx['parent_runs']['center_rms-boundary-'+str(seed)]
        if not shared:
            for field in RAW_PARITY_FIELDS:check(report[field]==prior['training'][field],arm+'/exact_raw_numerical_replay/'+field)
            replay=read(folder/'raw-training-replay.json')
            check(replay==run['raw_training_replay'] and replay['complete'] is True and replay['compared_fields']==RAW_PARITY_FIELDS,arm+'/raw_replay_receipt')
        else:check(run['raw_training_replay'] is None,arm+'/no_false_raw_replay')
        cache={};roles={}
        for role in ('selected','last-attempt'):
            state=read(folder/(role+'-state.json'));label=arm+'/'+role;state_check(state,label)
            check(state['schema']=='private-shared-slot-source-state/v1' and state['recipe']==run['recipe'] and state['role']==role,label+'/state_role')
            expected_hash=report['selected_weights_sha256'] if role=='selected' else report['last_complete_attempt_weights_sha256']
            check(state['tensor_sha256']==expected_hash,label+'/report_state_binding')
            check(architecture(state,ctx,seed,label)==shared,label+'/correct_architecture')
            p=canonical(state)
            for key in ('source_mean','source_scale','count_prior_logits')+ (('head_initialization_seed',) if shared else ('source_reference_mean',)):
                check(p[key]==p0[key],label+'/unchanged_initial_buffer/'+key)
            leaf.audit_projections(state['model_state'],ctx['donor'],report['frozen_parameter_names'],label)
            underlying={key[5:]:value for key,value in state['model_state'].items() if key.startswith('body.')}
            body_digest=tensor_digest(underlying)
            check(body_digest==run['underlying_state_tensor_sha256'][role],label+'/underlying_tensor_binding')
            if not shared:
                expected_prior=prior['training']['selected_weights_sha256'] if role=='selected' else prior['training']['last_complete_attempt_weights_sha256']
                check(body_digest==expected_prior,label+'/exact_parent_tensors')
            roles[role]={}
            for name,split,kind in ctx['plan']['postfit_controls']:
                panel=read(folder/role/('evaluation-'+name+'.json'));prefix=label+'/'+name
                record=audit_panel(ctx,state,panel,split,kind,prefix,cache);roles[role][name]=record;panels+=1
                compact=run['postfit'][role][name]
                check(compact['predictions']==panel['predictions'] and compact['numerical']==panel['report']
                    and compact['source_count']==panel['source_count']
                    and compact['source_values']=={k:v for k,v in panel['source_values'].items() if k!='predictions'}
                    and compact['source_fidelity']=={k:v for k,v in panel['source_fidelity'].items() if k!='rows'},prefix+'/summary_binding')
                if name=='validation':
                    selected=report['selected'] if role=='selected' else report['last_complete_attempt']
                    check(panel['predictions']==read(folder/(role+'-predictions.json')) and panel['report']['metrics']==selected['numerical']
                        and compact['source_fidelity']==selected['fidelity'],prefix+'/training_evaluation_binding')
                    record['support_strata']=support_panel(panel,ctx,prefix)
                    if not shared:
                        catalog=next(r for r in ctx['manifest']['state_catalog'] if r['name']=='center_rms-boundary-'+str(seed))
                        old_path=ctx['manifest']['prior_selected_evaluations'][catalog['name']] if role=='selected' else catalog['archived_evaluations']['validation']
                        check(panel['predictions']==read(old_path)['predictions'],prefix+'/exact_full_parent_predictions')
                if not shared:
                    old=prior['postfit'][role][name]
                    check(panel['report']['metrics']==old['numerical']['metrics'] and compact['source_fidelity']==old['source_fidelity'],prefix+'/parent_control_metric_parity')
        records.append(dict(arm=arm,selected_epoch=report['selected_epoch'],exposure=exposure,selection=selection,postfit=roles))
        print(json.dumps(dict(audited_arm=arm,findings=len(findings))),flush=True)
    check(panels==40 and len(initial_heads)==2 and len(set(initial_heads))==2,'training/forty_panels_two_distinct_shared_initializations')
    released(args.results)
    return dict(runs=records,panel_count=panels,state_count=12,preprocessing=ctx['preprocessing_audit'],unsupported_position_labels=ctx['missing'],
        scope='Persisted-output fidelity, strict selection, full matched exposure, independent raw replay, frozen projections/buffers and shared affine/tanh source arithmetic.',
        limits='No model execution, recurrent rollout, token-CE/gradient replay, exact Torch RNG reproduction, native logic-family qualification or Lake admission by auditor.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('readiness','results'),required=True)
    for name in ('manifest','plan','source','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--dependency',type=Path,default=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2')
    parser.add_argument('--results',type=Path)
    parser.add_argument('--tests',type=Path,default=R/'tests-frozen-r2.xml')
    parser.add_argument('--imports',type=Path,default=R/'test-import-provenance-r2.json')
    args=parser.parse_args()
    for name,value in vars(args).items():
        if isinstance(value,Path):setattr(args,name,value.resolve())
    if args.output.exists():raise FileExistsError('fresh audit output required')
    ctx=common(args);records=readiness(ctx,args) if args.phase=='readiness' else results(args,ctx)
    artifacts[str(Path(__file__).resolve())]=dict(sha256=sha(__file__),bytes=Path(__file__).stat().st_size)
    result=dict(schema='shared-slot-source-independent-audit/v1',phase=args.phase,passed=not findings,ready=not findings,complete=True,
        finding_count=len(findings),failed_check_count=len(findings),findings=findings,checks=base.COUNTS,records=records,artifacts=artifacts,
        source_path=str(args.source),manifest_path=str(args.manifest),plan_path=str(args.plan),manifest_sha256=sha(args.manifest),
        plan_sha256=sha(args.plan),audit_source_sha256=sha(__file__),model_executed=False,training_executed=False,torch_executed=False,
        autoregressive_generation_executed=False,native_executed=False,qualified=False,admitted=False,checkpoint_promoted=False,
        source_semantics_verified=False)
    with args.output.open('x') as stream:json.dump(result,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(path=str(args.output),sha256=sha(args.output),finding_count=len(findings))))
    return int(bool(findings))


if __name__=='__main__':raise SystemExit(main())
