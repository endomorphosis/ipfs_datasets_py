"""Package audited shared-slot training without rerunning numerical workloads.

All new observations and producer/test sources are physical members. Original
inputs and raw reference fits are hash-bound members of the projected-source
Git archive. XZ is lossless and each published archive remains below90MB.
"""
import ast
import hashlib
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import xml.etree.ElementTree as ET

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
S=P/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
E=P/'docs/implementation/reports/evidence/decoder-shared-slot-source-20261003'
DOC='docs/autoencoders/decoder_length_distillation.md'
PRIOR_COMMIT='4ecbc3ab8668135f084b1fcd49808c7fbfe8a8dc'
PRIOR_RELATIVE='docs/implementation/reports/evidence/decoder-projected-source-20261003'
PRIOR_ARCHIVE_SHA='e5a0878721ec9134c22c5686b4307c4b49c192fd12dcb363f60a02ac32cb6676'
REPOSITORY='https://github.com/endomorphosis/ipfs_datasets_py'
MAX_ARCHIVE_BYTES=90_000_000
FALSE=dict(qualified=False,admitted=False,proof_authority=False,source_semantics_verified=False,
    convergence_proven=False,fresh_holdout=False,lake_executed=False,formalized=False,
    roundtrip_ok=False,checkpoint_promoted=False,production_checkpoint=False,
    optimizer_resumable=False,native_validation_executed=False)
DYNAMIC={'publication.json','owned-files.json','build-evidence.log','build-evidence-final.log'}


def require(condition,message):
    if not condition:raise ValueError(message)


def read(path):
    def unique(pairs):
        result={}
        for key,value in pairs:
            require(key not in result,'duplicate JSON key: '+key)
            result[key]=value
        return result
    return json.loads(Path(path).read_bytes(),object_pairs_hook=unique)


def sha(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):value.update(block)
    return value.hexdigest()


def info(path):
    path=Path(path)
    require(path.is_file() and not path.is_symlink(),'regular evidence file required: '+str(path))
    return dict(sha256=sha(path),bytes=path.stat().st_size)


def write_new(path,value):
    data=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if path.exists():
        require(path.read_bytes()==data,'existing generated output differs: '+str(path));return
    with path.open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())


def authority(value):
    require(all(value[key] is False for key in FALSE if key in value),'forbidden authority claim')


def passing_tests(path,expected=None):
    result={key:0 for key in ('tests','failures','errors','skipped')}
    for suite in ET.parse(path).getroot().iter('testsuite'):
        for key in result:result[key]+=int(suite.get(key,0))
    require(result['tests']>0 and result['failures']==result['errors']==result['skipped']==0,'complete passing test suite required')
    if expected is not None:require(result['tests']==expected,'test inventory differs')
    return dict(result,junit_sha256=sha(path))


def attempt_for(audit,schema):
    candidates=[]
    for artifact in audit['artifacts']:
        path=Path(artifact)
        if path.is_relative_to(R) and path.name=='summary.json' and path.parent.name=='results':
            if read(path).get('schema')==schema:candidates.append(path.parent.parent)
    require(len(set(candidates))==1,'exactly one audited phase summary required: '+schema)
    return candidates[0]


def resources(attempt,phase):
    final,child=read(attempt/'resources-final.json'),read(attempt/'child-exit.json');record=final['record']
    require(final['status']==record['status']=='released' and record['artifacts_durable_asserted'] is True
        and record['attempt_exceeded_reservation'] is False and child['returncode']==0
        and child['leader_reaped'] is True,'durable released successful phase required')
    require(record['cpu_slots']==record['child_process_slots']==1 and record['memory_mb']==4096
        and record['storage_bytes']==800000000 and record['final_accounting']['limit_bytes']==140000000000,
        'resource contract differs')
    observations=read(attempt/'resource-observations.json')
    guardians=[]
    for path in (R/(attempt.name+'-guardian.log'),R/(phase+'-guardian.log'),R/('guardian-'+attempt.name+'.log')):
        if not path.exists():continue
        # A preserved failed guardian log may contain a traceback, not a success receipt.
        try:value=read(path)
        except json.JSONDecodeError:continue
        if value.get('returncode')==0 and value.get('resources',{}).get('record',{}).get('attempt_directory',{}).get('path')==str(attempt):
            guardians.append(value)
    require(len(guardians)==1,'one completed guardian receipt bound to successful attempt required')
    guardian=guardians[0]
    return dict(guardian_elapsed_seconds=guardian['elapsed_seconds'],
        guardian_elapsed_through_child_exit_seconds=child['guardian_elapsed_through_child_exit_seconds'],
        launch_return_through_reap_wall_seconds=child['launch_return_through_reap_wall_seconds'],
        child_time_scope=child['child_time_scope'],isolated_child_execution_seconds=None,
        owned_output_bytes=record['final_attempt_bytes'],reservation_bytes=record['storage_bytes'],reservation_released=True,
        observed_peak_child_rss_bytes=max((item['group_rss']['rss_bytes'] for item in observations),default=None),
        rss_observation_count=len(observations),storage_cap_unchanged=True,
        final_charged_storage_bytes=record['final_accounting']['charged_bytes'])


def quality(panel):
    report=panel['report'];fidelity=panel['source_fidelity'];values=panel['source_values'];counts=panel['source_count']
    require(report['complete'] is True and len(panel['predictions'])==48 and values['present_values']==720,
        'complete actual generation and raw scalar readouts required')
    authority(report);authority(fidelity)
    return dict(numerical_metrics=report['metrics'],generated=fidelity['metrics'],
        by_length=fidelity['by_length'],by_facet=fidelity['by_facet'],
        raw_auxiliary_source_values=dict(correct=values['correct'],present_values=values['present_values'],
            cross_entropy=values['cross_entropy'],by_length=values['by_length'],
            by_field={key:{k:v for k,v in value.items() if k!='classes'} for key,value in values['by_field'].items()}),
        source_count=dict(correct=counts['correct'],rows=counts['rows'],cross_entropy=counts['cross_entropy']),
        scalar_mode=panel['scalar_mode'],postfit_seconds=panel['timing']['postfit_evaluation_elapsed_seconds'],
        numerical_api_wall_seconds=report['elapsed_seconds'],numerical_api_wall_seconds_per_span=report['wall_seconds_per_span'])


def excluded(path):
    if path.parent==R/'packaging-attempts' and path.name.endswith(('.tar.gz','.tar.xz')):return True
    return any(part in ('.git','.lake','__pycache__') or 'pytest-cache' in part or part=='.pytest_cache'
        for part in path.relative_to(R).parts) or path.suffix in ('.pyc','.pyo','.index')


def audit_receipt(filename,phase):
    value=read(R/filename)
    require(value.get('schema')=='shared-slot-source-independent-audit/v1' and value.get('phase')==phase
        and value.get('complete') is True and value.get('passed') is True and value.get('findings')==[]
        and value.get('failed_check_count')==0,'clean exact shared-slot audit required: '+filename)
    require(value['audit_source_sha256']==sha(R/'independent_audit.py'),'auditor source changed')
    for path,expected in value['artifacts'].items():require(info(path)==expected,'audited artifact changed: '+path)
    authority(value)
    return value


def main():
    audits={'readiness':audit_receipt('readiness.json','readiness'),
        'results':audit_receipt('independent-audit.json','results')}
    docs=read(R/'docs-ready.json')
    require(docs.get('ready') is True and docs.get('files',{}).get(DOC)==sha(P/DOC),'final documentation binding required')
    attempt=attempt_for(audits['results'],'shared-slot-source-training-comparison/v1')
    training=read(attempt/'results/summary.json')
    manifest,plan=read(R/'training-r2-manifest.json'),read(R/'training-plan.json')
    require(training.get('complete') is True and len(training['runs'])==4
        and training.get('raw_training_replay_parity') is True,'all four complete fits and exact raw replay required')
    authority(training)
    require(training['workers']==1 and training['bridge_names']==[]
        and all(training[key] is False for key in ('legal_ir_evaluate_provers','metric_disk_cache_used',
            'encoder_executed','encoder_context_changed','output_limit_changed','downloads_performed')),
        'execution scope differs')
    require(manifest['plan_sha256']==sha(R/'training-plan.json') and plan['input_sha256']==manifest['inputs'],
        'predeclared plan/input binding changed')
    sealed=read(attempt/'results/sealed-recipe.json')
    require(sealed['manifest']==manifest and sealed['plan']==plan,'executed recipe differs')
    source=R/'experiment-source-r2'
    require(len(manifest['extensions'])==35,'exact thirty-five extension owners required')
    for relative,expected in manifest['extensions'].items():
        require(sha(source/relative)==sha(P/relative)==expected,'frozen extension differs: '+relative)
    for path,expected in manifest['inputs'].items():require(sha(path)==expected,'frozen input differs: '+path)
    code,tests_source=read(R/'code-files.json'),read(R/'validated-test-source-r2.json')
    require(len(code)==len(set(code))==6 and DOC in code and len(tests_source)==35,'owner/test inventory differs')
    for relative,expected in tests_source.items():
        require(sha(source/relative)==sha(P/relative)==expected,'tested source differs: '+relative)
    tests=passing_tests(R/'tests-frozen-r2.xml')
    resource_receipt=resources(attempt,'training')

    prior_folder=P/PRIOR_RELATIVE
    prior,prior_results=read(prior_folder/'manifest.json'),read(prior_folder/'results.json')
    for name in ('manifest.json','results.json'):
        path=prior_folder/name
        require(path.read_bytes()==subprocess.check_output(['git','show',PRIOR_COMMIT+':'+str(path.relative_to(P))],cwd=P),
            'predecessor public metadata differs from exact Git commit')
    prior_archive=prior_folder/'evidence.tar.gz'
    require(info(prior_archive)==prior['archive']==prior_results['archive'] and sha(prior_archive)==PRIOR_ARCHIVE_SHA
        and prior_results['complete'] is True and prior['archive_standalone'] is True,'complete exact predecessor required')
    dependency_id='projected-source-'+PRIOR_COMMIT
    dependency=dict(id=dependency_id,repository=REPOSITORY,git_commit=PRIOR_COMMIT,
        archive=dict(path=PRIOR_RELATIVE+'/evidence.tar.gz',**info(prior_archive)),
        manifest=dict(path=PRIOR_RELATIVE+'/manifest.json',**info(prior_folder/'manifest.json')),
        results=dict(path=PRIOR_RELATIVE+'/results.json',**info(prior_folder/'results.json')),
        retrieval='Read the exact Git blob at git_commit:path and verify SHA-256/bytes before extraction.',
        contains_all_referenced_members=True)
    files,original_paths,referenced={},{},{}
    def add(name,path,expected=None):
        path=Path(path).absolute();observed=info(path);member=PurePosixPath(name)
        require(not member.is_absolute() and '..' not in member.parts and str(member)==name,'unsafe archive member')
        if expected is not None:require(observed==expected,'physical artifact pin differs: '+str(path))
        if str(path) in original_paths:
            require(files[original_paths[str(path)]]['info']==observed,'duplicate artifact differs');return
        require(name not in files,'conflicting archive member: '+name)
        files[name]=dict(path=path,info=observed);original_paths[str(path)]=name
    def reference(path,expected=None):
        path=Path(path).absolute();observed=info(path)
        if expected is not None:require(observed==expected,'referenced input differs: '+str(path))
        if path==prior_archive:
            referenced[str(path)]=dict(dependency_id=dependency_id,kind='archive_itself',**observed);return
        require(str(path) in prior['original_artifact_archive_paths'],'historical archive member missing: '+str(path))
        member=prior['original_artifact_archive_paths'][str(path)]
        require(prior['members'][member]==observed,'historical member digest differs')
        referenced[str(path)]=dict(dependency_id=dependency_id,kind='archive_member',member=member,**observed)
    def retain(path,expected=None):
        path=Path(path).absolute()
        if str(path) in original_paths:
            if expected is not None:require(info(path)==expected,'physical audit binding differs')
        elif path.is_relative_to(R):add('validation/'+path.relative_to(R).as_posix(),path,expected)
        elif path in (prior_folder/'manifest.json',prior_folder/'results.json'):
            add('predecessor-public/'+path.name,path,expected)
        elif str(path) in prior['original_artifact_archive_paths'] or path==prior_archive:reference(path,expected)
        else:
            # Later trainer/audit source revisions are small historical evidence,
            # not historical model snapshots. Their exact bytes remain physical.
            require(path.is_relative_to(P) and path.suffix in ('.py','.json','.xml','.log')
                and path.stat().st_size<=4194304,'unmapped historical input requires explicit review: '+str(path))
            add('historical/'+path.relative_to(P).as_posix(),path,expected)

    producers=read(R/'baseline-producer-pins.json');require(len(producers)==96,'complete prior producer closure required')
    producers=dict(producers)
    for relative,expected in manifest['extensions'].items():
        if relative in producers and not relative.endswith('/long_span_source_value_training.py'):
            require(producers[relative]==expected,'unreviewed producer change: '+relative)
        producers[relative]=expected
    require(len(producers)==98,'complete ninety-eight runtime producer closure required')
    test_helpers=read(R/'test-helper-sources.json')
    require(test_helpers=={'scripts/ops/autoencoder/evaluate_rejected_decoder_controls.py':
        '53046e84b6b476535d4694535a11f04a5d8e93972d8da9e20188341411e4e504'},'exact committed synthetic test helper required')
    for relative,expected in test_helpers.items():
        require(relative not in producers and sha(source/relative)==sha(P/relative)==expected,'frozen test helper differs')
        producers[relative]=expected
    require(len(producers)==99,'runtime plus frozen test-helper closure differs')
    producer_files={relative:(source if relative in manifest['extensions'] or relative in test_helpers else S)/relative for relative in producers}
    for relative,path in producer_files.items():require(sha(path)==producers[relative],'producer pin differs: '+relative)
    for scoped,expected in training['source_dependencies'].items():
        scope,relative=scoped.split(':',1)
        require(scope in ('extension','dependency') and producers.get(relative)==expected,'executed producer outside frozen closure')
    imports=read(R/'test-import-provenance-r2.json');require(imports['pytest_returncode']==0,'frozen synthetic imports failed')
    for entry in imports['modules'].values():
        path=Path(entry['path']);root=source if path.is_relative_to(source) else S
        require(path.is_relative_to(root) and producers.get(path.relative_to(root).as_posix())==entry['sha256']==sha(path),
            'tested import escaped frozen tree')
    for relative in sorted(set(code)|set(tests_source)|set(producers)):
        path=producer_files.get(relative,source/relative if relative in tests_source else P/relative)
        expected=producers.get(relative,tests_source.get(relative))
        add('source/'+relative,path,None if expected is None else dict(sha256=expected,bytes=path.stat().st_size))
        canonical=(P/relative).absolute()
        if canonical.is_file() and info(canonical)==files['source/'+relative]['info']:
            original_paths[str(canonical)]='source/'+relative
    for name in ('manifest.json','results.json'):retain(prior_folder/name)
    for path,expected in manifest['inputs'].items():retain(path,dict(sha256=expected,bytes=Path(path).stat().st_size))
    compatibility=read(R/'resource-compatibility.json')
    prior_compatibility=Path(compatibility['prior_compatibility_path'])
    retain(prior_compatibility,dict(sha256=compatibility['prior_compatibility_sha256'],
        bytes=prior_compatibility.stat().st_size))
    for relative,entry,key in (
        ('ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py',compatibility['executed_historical_owner'],'path'),
        ('ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py',compatibility['executed_scheduler'],'executed_path')):
        path=Path(entry[key]);add('historical/dependency-source/'+relative,path,dict(sha256=entry['sha256'],bytes=path.stat().st_size))
    for path in sorted(R.iterdir()):
        if path.is_file() and path.suffix in ('.json','.log','.xml','.py','.txt','.md') and path.name not in DYNAMIC:
            retain(path)
    for directory in sorted(path for path in R.iterdir() if path.is_dir() and not excluded(path)):
        for path in sorted(directory.rglob('*')):
            if path.is_file() and not excluded(path):retain(path)
    for receipt in audits.values():
        for path,expected in receipt['artifacts'].items():retain(path,expected)
    # Keep each explicitly pinned local arithmetic helper even if no artifact
    # inventory happens to mention a transitively imported helper itself.
    for path in sorted(R.glob('audit_*arithmetic.py')):retain(path)
    require(str(R/'audit_leaf_arithmetic.py') in original_paths and str(R/'audit_projected_arithmetic.py') in original_paths,
        'required local arithmetic helpers omitted')
    require(not set(original_paths)&set(referenced),'artifact cannot be both physical and referenced')
    require(all(set(receipt['artifacts'])<=set(original_paths)|set(referenced) for receipt in audits.values()),
        'incomplete audit artifact closure')
    needed={value['member']:value for value in referenced.values() if value['kind']=='archive_member'}
    with tarfile.open(prior_archive,'r:gz') as bundle:
        checked=set()
        for member in bundle:
            if member.name not in needed:continue
            require(member.isfile(),'referenced member must be regular');content=bundle.extractfile(member).read()
            require(dict(sha256=hashlib.sha256(content).hexdigest(),bytes=len(content))==
                {key:needed[member.name][key] for key in ('sha256','bytes')},'referenced archive bytes differ')
            checked.add(member.name)
        require(checked==set(needed),'historical member absent from archive bytes')

    arms=[];panel_count=0;initial_count=0
    for run in training['runs']:
        folder=attempt/'results'/run['arm'];report=run['training']
        require(report==read(folder/'training.json') and run['budget_completed'] is True
            and report['stopped_reason']=='epochs_completed' and report['optimizer_steps']==340
            and report['row_presentations']==report['count_training_row_presentations']==2440
            and report['valid_target_token_presentations']==225840 and report['source_value_presentations']==25600,
            'matched complete optimizer exposure required')
        authority(report);states={};controls={}
        for role in ('initial','selected','last-attempt'):
            state_path=folder/(role+'-state.json');state=read(state_path)
            require(state['schema']=='private-shared-slot-source-state/v1' and state['role']==role,'state role/schema differs')
            authority(state)
            states[role]=dict(path=str(state_path),**info(state_path),tensor_sha256=state['tensor_sha256'])
            if role=='initial':initial_count+=1;continue
            controls[role]={}
            for label,split,control in plan['postfit_controls']:
                path=folder/role/('evaluation-'+label+'.json');value=read(path)
                expected_kind='source_shuffle' if control=='cross_length_shuffle' else control
                require(value['execution']['kind']==expected_kind,'control execution differs')
                controls[role][label]=dict(artifact=dict(path=str(path),**info(path)),**quality(value));panel_count+=1
        reasons={}
        for epoch in report['history']:
            for reason in epoch['rejection_reasons']:reasons[reason]=reasons.get(reason,0)+1
        arms.append(dict(arm=run['arm'],seed=run['seed'],recipe=run['recipe'],
            selected_epoch=report['selected_epoch'],last_complete_attempt_is_selected=report['last_complete_attempt_is_selected'],
            trainable_parameter_count=run['trainable_parameter_count'],
            optimizer_steps=340,decoder_row_presentations=2440,count_row_presentations=2440,
            target_token_presentations=225840,scalar_label_presentations=25600,
            rejection_reason_counts=reasons,raw_training_replay=run['raw_training_replay'],
            fit_call_wall_seconds=run['training_call_elapsed_seconds'],postfit_wall_seconds=run['postfit_elapsed_seconds'],
            whole_arm_seconds=run['elapsed_seconds'],states=states,controls=controls,**FALSE))
    require(panel_count==40 and initial_count==4,'all forty control panels and four initial states required')
    comparisons=[]
    for seed in (1729,2718):
        independent=next(run for run in arms if run['seed']==seed and run['recipe']['head_kind']=='independent_affine')
        shared=next(run for run in arms if run['seed']==seed and run['recipe']['head_kind']=='shared_slot_tanh')
        a,b=(run['controls']['last-attempt']['validation'] for run in (independent,shared))
        keys=('ordered_exact','syntax_valid','eos_count','duplicate_rules','whole_rules_missing','whole_rules_extra')
        comparisons.append(dict(seed=seed,independent_arm=independent['arm'],shared_arm=shared['arm'],
            generated_delta_shared_minus_independent={key:b['generated'][key]-a['generated'][key] for key in keys},
            scalar_fidelity_delta_shared_minus_independent={field:b['by_facet'][field]['correct']-a['by_facet'][field]['correct']
                for field in ('actor','action','modality','object')},
            raw_head_correct_delta=b['raw_auxiliary_source_values']['correct']-a['raw_auxiliary_source_values']['correct'],
            token_cross_entropy_delta_shared_minus_independent=b['numerical_metrics']['token_cross_entropy']-a['numerical_metrics']['token_cross_entropy'],
            parameter_count_ratio_shared_to_independent=shared['trainable_parameter_count']/independent['trainable_parameter_count'],
            fit_call_wall_ratio_shared_to_independent=shared['fit_call_wall_seconds']/independent['fit_call_wall_seconds']))
    selected=[run['selected_epoch'] for run in arms]
    exact=[run['controls']['last-attempt']['validation']['generated']['ordered_exact'] for run in arms]
    outcome=('Shared heads improved generated scalar matches and token cross-entropy in both seeds, but whole-document exactness remained zero and no fitted checkpoint passed selection. Duplicate/extra rules, one EOS regression, and slightly slower fits remain material limitations.'
        if not any(selected) and not any(exact) else
        'Private development reconstruction changed; inspect exact generated fidelity and selection results below. No native qualification or global convergence is established.')
    outputs=[str((E/name).relative_to(P)) for name in ('results.json','manifest.json','evidence.tar.xz')]
    write_new(R/'owned-files.json',code+outputs);retain(R/'owned-files.json')
    require(not E.exists() or not any(E.iterdir()),'public evidence destination must be fresh')
    E.mkdir(parents=True,exist_ok=True);archive=E/'evidence.tar.xz'
    with archive.open('xb') as stream:
        with lzma.LZMAFile(stream,mode='wb',format=lzma.FORMAT_XZ,preset=6) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as bundle:
                for name,entry in sorted(files.items()):
                    require(info(entry['path'])==entry['info'],'physical artifact changed before archive: '+name)
                    header=tarfile.TarInfo(name);header.size=entry['info']['bytes'];header.mode=0o644;header.mtime=0
                    with entry['path'].open('rb') as source_file:bundle.addfile(header,source_file)
        stream.flush();os.fsync(stream.fileno())
    require(all(info(entry['path'])==entry['info'] for entry in files.values()),'physical input changed during packaging')
    require(all(info(path)=={key:entry[key] for key in ('sha256','bytes')} for path,entry in referenced.items()),
        'historical input changed during packaging')
    archive_info=info(archive);require(archive_info['bytes']<=MAX_ARCHIVE_BYTES,'archive exceeds90MB; never drop raw observations')
    archive_metadata=dict(archive_filename='evidence.tar.xz',archive_compression='xz',xz_preset=6,
        archive_standalone=False,archive_dependencies=[dependency],referenced_artifacts=referenced,
        dependency_scope='All new model observations are physical; exact original inputs/reference fits require the bound prior Git archive.',
        reproducibility_scope='Artifact closure with original-path mapping; Python, host libraries and hardware are not bundled.')
    write_new(E/'manifest.json',dict(schema='decoder-shared-slot-source-archive/v1',archive=archive_info,
        members={name:entry['info'] for name,entry in files.items()},original_artifact_archive_paths=original_paths,
        validated_producer_source_sha256=producers,archive_maximum_bytes=MAX_ARCHIVE_BYTES,**archive_metadata,**FALSE))
    results=dict(schema='decoder-shared-slot-source-results/v1',complete=True,outcome=outcome,
        scope='Matched independent-affine versus nonlinear shared-slot source classifiers with unchanged inherited decoder/count policy',
        training_fit_count=4,training_arms=arms,paired_comparisons=comparisons,initial_state_count=4,
        trained_state_control_panel_count=40,raw_training_replay_verified=True,
        support_strata=[dict(arm=run['arm'],role=role,
            **run['postfit'][role]['validation']['support_strata'])
            for run in audits['results']['records']['runs'] for role in ('selected','last-attempt')],
        selected_checkpoint_epochs=selected,selected_nonbaseline_checkpoint_present=any(selected),
        dimensions_actually_trained=[384],historical_8d_teacher_modified=False,actual_768d_training_performed=False,
        training_rows=48,validation_rows=48,clauses_per_paragraph=[1,2,4,8],
        encoder_context_tokens=512,decoder_output_limit=512,generation_temperature=0,
        training_executed=True,generation_executed=True,optimizer_executed=True,
        candidate_sha256={relative:sha(P/relative) for relative in code},independent_audit_sha256=sha(R/'independent-audit.json'),
        independent_audits={phase:dict(path=str(R/filename),sha256=sha(R/filename),
            checks=audits[phase].get('checks',audits[phase].get('checked_count')),findings=audits[phase]['findings'],
            audited_artifacts=len(audits[phase]['artifacts']))
            for phase,filename in [('readiness','readiness.json'),('results','independent-audit.json')]},
        tests=tests,test_scope='Current frozen35-file suite only; historical scheduler tests are not recounted as a new run.',
        telemetry=dict(device='cpu',workers=1,bridge_names=[],legal_ir_evaluate_provers=False,
            legal_ir_bridge_evaluation_performed=False,bridge_on_evaluate_seconds=None,metric_disk_cache_used=False,
            paragraph_embedding_cache_used=True,encoder_executed=False,use_sample_memory=False,
            fit_call_wall_seconds_total=sum(run['fit_call_wall_seconds'] for run in arms),
            postfit_wall_seconds_total=sum(run['postfit_wall_seconds'] for run in arms),resources=resource_receipt,
            workload='Cached-embedding private decoder fits; not bridge-on legal conversion timing'),
        limitations=['Previously exposed authored development corpus; no fresh held-out convergence claim.',
            'Sharing reduces parameter capacity while changing inductive bias; differences cannot be attributed to speed alone.',
            'Shared weights do not establish that paragraph embeddings preserve clause order.',
            'Raw auxiliary scores and potential all-slot guidance captures are not full generated fidelity or visited-prefix traces.',
            'All authored qualifiers are empty; populated exceptions, temporal semantics and complete logic-family coverage remain unestablished.',
            'Only Lake could grant Lean admission; no Lake or other native semantic qualification was executed here.',
            'No production promotion, global optimum, or Constitution formalization follows from these observations.'],
        archive=archive_info,**archive_metadata,**FALSE)
    require(len(json.dumps(results))<1500000,'compact public results unexpectedly contain full raw summaries')
    write_new(E/'results.json',results)
    with tarfile.open(archive,'r:xz') as bundle:
        entries=bundle.getmembers();require(len(entries)==len(files) and {entry.name for entry in entries}==set(files),'sealed membership differs')
        for member in entries:
            require(member.isfile(),'sealed member not regular');content=bundle.extractfile(member).read()
            require(dict(sha256=hashlib.sha256(content).hexdigest(),bytes=len(content))==files[member.name]['info'],
                'sealed bytes differ: '+member.name)
    print(json.dumps(dict(archive=archive_info,members=len(files),references=len(referenced),producers=len(producers),
        test_files=len(tests_source),owned_files=len(code)+3,initial_states=4,selected_final_states=8,panels=40,
        results=info(E/'results.json'),manifest=info(E/'manifest.json'))))


if __name__=='__main__':main()
