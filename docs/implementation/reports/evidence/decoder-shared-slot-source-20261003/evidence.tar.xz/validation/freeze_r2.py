"""Preserve the tested source revision and freeze initial-state evidence capture."""
from pathlib import Path
import hashlib,json,shutil

P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=Path(__file__).resolve().parent
RUNNER='scripts/ops/autoencoder/benchmark_shared_slot_source_reconstruction.py'
TEST='tests/unit/logic/formalization/autoencoder/test_benchmark_shared_slot_source_reconstruction.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(R/name).write_text(json.dumps(value,indent=2)+'\n')

if __name__=='__main__':
    assert not (R/'experiment-source-r2').exists()
    ready=json.loads((R/'runner-ready.json').read_bytes());assert ready['ready'] is True
    for rel,v in ready['files'].items():assert sha(P/rel)==(v['sha256'] if isinstance(v,dict) else v),rel
    pins=json.loads((R/'frozen-extensions.json').read_bytes())
    tests=json.loads((R/'validated-test-source.json').read_bytes())
    helpers=json.loads((R/'test-helper-sources.json').read_bytes())
    for rel,digest in {**pins,**tests,**helpers}.items():assert sha(R/'experiment-source'/rel)==digest,rel
    pins[RUNNER]=sha(P/RUNNER);tests[TEST]=sha(P/TEST)
    for rel,digest in {**pins,**tests,**helpers}.items():
        source=P/rel if rel in (RUNNER,TEST) else R/'experiment-source'/rel
        target=R/'experiment-source-r2'/rel;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target);assert sha(target)==digest,rel
    save('frozen-extensions-r2.json',pins);save('validated-test-source-r2.json',tests)
    manifest=json.loads((R/'training-manifest.json').read_bytes());manifest['extensions']=pins
    assert sha(R/'training-plan.json')==manifest['plan_sha256']
    save('training-r2-manifest.json',manifest)
    s=(R/'run_frozen_tests.py').read_text()
    for a,b in [('frozen-extensions.json','frozen-extensions-r2.json'),
                ('validated-test-source.json','validated-test-source-r2.json'),
                ('experiment-source','experiment-source-r2'),('tests-frozen.xml','tests-frozen-r2.xml'),
                ('test-import-provenance.json','test-import-provenance-r2.json'),('pytest-cache','pytest-cache-r2')]:s=s.replace(a,b)
    (R/'run_frozen_r2_tests.py').write_text(s)
    s=(R/'run_training_reserved.py').read_text().replace('experiment-source','experiment-source-r2')
    s=s.replace("args.phase+'-manifest.json'","args.phase+'-r2-manifest.json'")
    s=s.replace('run_training_reserved.py','run_training_r2_reserved.py')
    (R/'run_training_r2_reserved.py').write_text(s)
    save('capture-revision.json',dict(reason='retain complete prefit states for direct initial-head arithmetic audit',
        prior_runner_sha256=sha(R/'experiment-source'/RUNNER),final_runner_sha256=pins[RUNNER],
        preserved_prior_source=True,training_plan_changed=False,trained_before_revision=False))
    print(json.dumps(dict(extensions=len(pins),test_files=len(tests))))
