-- Actual native interpretation declarations; no source truth asserted.

namespace SecurityIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_0
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Archivist") (fun t => i.atom "Happens" [(i.function "Certify" []), (i.function "Time" [])] t)))
end Projection_0

namespace Projection_1
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Certify" [v0] t)) t)
end Projection_1

namespace Projection_2
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Archivist") (fun t => i.atom "Happens" [(i.function "Certify" []), (i.function "Time" [])] t))
end Projection_2

namespace Projection_3
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Archivist" [v0] t) t) → ((fun t => i.atom "Certify" [v0] t) t)) t)
end Projection_3

namespace Projection_4
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"archivist\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"certify\"}"))
end Projection_4

namespace Projection_5
set_option linter.unusedVariables false

structure ExecutionView (Value : Type) where
  publicValue : String → Value
  privateValue : String → Value
  observedValue : String → Value

def lowFields : List String := ["public"]

def highFields : List String := ["secret"]

def observationFields : List String := ["result"]

def lowProjection {Value : Type} (trace : ExecutionView Value) : List Value := lowFields.map trace.publicValue

def observationProjection {Value : Type} (trace : ExecutionView Value) : List Value := observationFields.map trace.observedValue

def noninterference {Value : Type} (executions : ExecutionView Value → Prop) : Prop :=
  ∀ left, executions left → ∀ right, executions right →
    lowProjection left = lowProjection right → observationProjection left = observationProjection right

def maxTraces : Nat := 2

def maxPairs : Nat := 1

def declaredMaxSteps : Option Nat := some 4

def sampleWithinCompositionBudget {Value : Type} (sample : List (ExecutionView Value)) : Prop :=
  sample.length ≤ maxTraces ∧ sample.length * (sample.length - 1) / 2 ≤ maxPairs

def temporalExecutionBoundChecked : Bool := false

def universalNoninterferenceProved : Bool := false

def quantifierVariableOrder : List String := ["var:pi1", "var:pi2"]

def policyIdentifier : String := "policy:flow"
end Projection_5

namespace Projection_6
set_option linter.unusedVariables false

structure Store where

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (0 : Int)

def expression_1 (initial current : Store) (returned : Int) : Bool := true

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide

def precondition (initial : Store) : Prop := (expression_1 initial initial (0 : Int) = true)

def postcondition (initial final : Store) (returned : Int) : Prop := (expression_1 initial final returned = true)

def frameCondition (initial final : Store) : Prop := True

def contract : Prop := ∀ initial, precondition initial →
  match run initial with
  | .returned final value => postcondition initial final value ∧ frameCondition initial final
  | .blocked => True
  | .assertionFailure => False
end Projection_6

namespace Projection_7
set_option linter.unusedVariables false

structure Store where

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Int)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Int) : Int := (0 : Int)

def expression_1 (initial current : Store) (returned : Int) : Bool := true

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current (0 : Int))

def declaredReads (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Projection_7

namespace Projection_8
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "archivist" [] t) ∧ (i.atom "certify" [] t))
end Projection_8

namespace Projection_9
set_option linter.unusedVariables false
inductive HeapValue where
  | integer (value : Int)
  | boolean (value : Bool)
  deriving DecidableEq
structure HeapInterpretation where
  address : String → Nat
abbrev Heap := Nat → Option HeapValue
def emptyHeap : Heap := fun _ => none
def singletonHeap (address : Nat) (value : HeapValue) : Heap :=
  fun location => if location = address then some value else none
def finiteHeap (heap : Heap) : Prop :=
  ∃ support : List Nat, ∀ address, heap address ≠ none → address ∈ support
def disjointHeaps (left right : Heap) : Prop :=
  ∀ address, left address = none ∨ right address = none
def unionHeap (left right : Heap) : Heap :=
  fun address => match left address with
    | some value => some value
    | none => right address
def emp (heap : Heap) : Prop := heap = emptyHeap
def pointsTo (address : Nat) (value : HeapValue) (heap : Heap) : Prop :=
  heap = singletonHeap address value
def separating (left right : Heap → Prop) (heap : Heap) : Prop :=
  ∃ first second, finiteHeap first ∧ finiteHeap second ∧ disjointHeaps first second ∧
    heap = unionHeap first second ∧ left first ∧ right second
theorem emptyHeap_finite : finiteHeap emptyHeap := by
  refine ⟨[], ?_⟩
  intro address h
  simp [emptyHeap] at h
theorem singletonHeap_finite (address : Nat) (value : HeapValue) :
    finiteHeap (singletonHeap address value) := by
  refine ⟨[address], ?_⟩
  intro other h
  by_cases same : other = address
  · simp [same]
  · simp [singletonHeap, same] at h
theorem singleton_not_disjoint_with_itself (address : Nat) (value : HeapValue) :
    ¬ disjointHeaps (singletonHeap address value) (singletonHeap address value) := by
  intro h
  have contradiction := h address
  simp [singletonHeap] at contradiction


def location_0 (i : HeapInterpretation) : Nat := i.address "loc:cell"

def value_0 : HeapValue := HeapValue.integer (0 : Int)

def declaredHeapFragment (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def allocatedCellCount : Nat := 0
end Projection_9

namespace Projection_10
set_option linter.unusedVariables false
inductive HeapValue where
  | integer (value : Int)
  | boolean (value : Bool)
  deriving DecidableEq
structure HeapInterpretation where
  address : String → Nat
abbrev Heap := Nat → Option HeapValue
def emptyHeap : Heap := fun _ => none
def singletonHeap (address : Nat) (value : HeapValue) : Heap :=
  fun location => if location = address then some value else none
def finiteHeap (heap : Heap) : Prop :=
  ∃ support : List Nat, ∀ address, heap address ≠ none → address ∈ support
def disjointHeaps (left right : Heap) : Prop :=
  ∀ address, left address = none ∨ right address = none
def unionHeap (left right : Heap) : Heap :=
  fun address => match left address with
    | some value => some value
    | none => right address
def emp (heap : Heap) : Prop := heap = emptyHeap
def pointsTo (address : Nat) (value : HeapValue) (heap : Heap) : Prop :=
  heap = singletonHeap address value
def separating (left right : Heap → Prop) (heap : Heap) : Prop :=
  ∃ first second, finiteHeap first ∧ finiteHeap second ∧ disjointHeaps first second ∧
    heap = unionHeap first second ∧ left first ∧ right second
theorem emptyHeap_finite : finiteHeap emptyHeap := by
  refine ⟨[], ?_⟩
  intro address h
  simp [emptyHeap] at h
theorem singletonHeap_finite (address : Nat) (value : HeapValue) :
    finiteHeap (singletonHeap address value) := by
  refine ⟨[address], ?_⟩
  intro other h
  by_cases same : other = address
  · simp [same]
  · simp [singletonHeap, same] at h
theorem singleton_not_disjoint_with_itself (address : Nat) (value : HeapValue) :
    ¬ disjointHeaps (singletonHeap address value) (singletonHeap address value) := by
  intro h
  have contradiction := h address
  simp [singletonHeap] at contradiction


def location_0 (i : HeapInterpretation) : Nat := i.address "loc:cell"

def value_0 : HeapValue := HeapValue.integer (0 : Int)

def declaredHeapFragment (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def allocatedCellCount : Nat := 0

def formula_0 (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def separationFormula (i : HeapInterpretation) (heap : Heap) : Prop := finiteHeap heap ∧ formula_0 i heap
end Projection_10

namespace Projection_11
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Certify" [v0] t))) t)
end Projection_11

namespace Projection_12
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Certify" [v0] t)) t)
end Projection_12

namespace Projection_13
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (alwaysTime (fun t => i.atom "bounded_result" [] t))
end Projection_13

namespace Projection_14
structure State where
  v0 : Int
def typeOK (s : State) : Prop := ((0 : Int) ≤ s.v0 ∧ s.v0 ≤ (1 : Int))
def predicate_0 (s : State) : Prop := (s.v0 = (0 : Int))
def predicate_1 (s : State) : Prop := (s.v0 = (0 : Int))
def initial (s : State) : Prop := typeOK s ∧ (predicate_0 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:result"].contains variableName
example : [].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:return" ∧ action_0 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
def sourceVariableAliases : List (String × String) := [("var:result", "v0"), ("result", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 64
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:return"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

end Projection_14

namespace Projection_15
structure State where
  v0 : Int
def typeOK (s : State) : Prop := ((0 : Int) ≤ s.v0 ∧ s.v0 ≤ (1 : Int))
def predicate_0 (s : State) : Prop := (s.v0 = (0 : Int))
def predicate_1 (s : State) : Prop := (s.v0 = (0 : Int))
def initial (s : State) : Prop := typeOK s ∧ (predicate_0 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:result"].contains variableName
example : [].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:return" ∧ action_0 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
end Projection_15

end SecurityIR

