"""
Native Python 3 implementation of Cognitive Event Calculus components.

This package provides pure Python 3 implementations of:
- DCEC (Deontic Cognitive Event Calculus) logic system
- Theorem proving capabilities
- Natural language conversion

These native implementations replace the Python 2 based submodules.
"""

from .dcec_core import (
    # Operators
    DeonticOperator,
    CognitiveOperator,
    LogicalConnective,
    TemporalOperator,
    # Types
    Sort,
    Variable,
    Function,
    Predicate,
    # Terms
    Term,
    VariableTerm,
    FunctionTerm,
    # Formulas
    Formula,
    AtomicFormula,
    DeonticFormula,
    CognitiveFormula,
    TemporalFormula,
    ConnectiveFormula,
    QuantifiedFormula,
    # Statements
    DCECStatement,
)

from .dcec_namespace import (
    DCECNamespace,
    DCECContainer,
)

from .prover_core import (
    ProofResult,
    ProofTree,
    ProofAttempt,
    TheoremProver,
    InferenceEngine,
)

from .nl_converter import (
    ConversionResult,
    NaturalLanguageConverter,
)

from .dcec_cleaning import (
    strip_whitespace,
    strip_comments,
    consolidate_parens,
    check_parens,
    get_matching_close_paren,
    tuck_functions,
    clean_dcec_expression,
)

from .dcec_parsing import (
    ParseToken,
    remove_comments,
    functorize_symbols,
    replace_synonyms,
    prefix_logical_functions,
    prefix_emdas,
)

from .dcec_prototypes import (
    DCECPrototypeNamespace,
)

from .dcec_integration import (
    parse_expression_to_token,
    token_to_formula,
    parse_dcec_string,
    validate_formula,
    DCECParsingError,
)

from .legal_ir_lifecycle import (
    LEGAL_IR_LIFECYCLE_SCHEMA_VERSION,
    compile_lifecycle_events,
)

__all__ = [
    # Operators
    "DeonticOperator",
    "CognitiveOperator",
    "LogicalConnective",
    "TemporalOperator",
    # Types
    "Sort",
    "Variable",
    "Function",
    "Predicate",
    # Terms
    "Term",
    "VariableTerm",
    "FunctionTerm",
    # Formulas
    "Formula",
    "AtomicFormula",
    "DeonticFormula",
    "CognitiveFormula",
    "TemporalFormula",
    "ConnectiveFormula",
    "QuantifiedFormula",
    # Statements
    "DCECStatement",
    # Namespace
    "DCECNamespace",
    "DCECContainer",
    # Prover
    "ProofResult",
    "ProofTree",
    "ProofAttempt",
    "TheoremProver",
    "InferenceEngine",
    # NL Converter
    "ConversionResult",
    "NaturalLanguageConverter",
    # Cleaning utilities
    "strip_whitespace",
    "strip_comments",
    "consolidate_parens",
    "check_parens",
    "get_matching_close_paren",
    "tuck_functions",
    "clean_dcec_expression",
    # Parsing
    "ParseToken",
    "remove_comments",
    "functorize_symbols",
    "replace_synonyms",
    "prefix_logical_functions",
    "prefix_emdas",
    # Prototypes
    "DCECPrototypeNamespace",
    # Integration
    "parse_expression_to_token",
    "token_to_formula",
    "parse_dcec_string",
    "validate_formula",
    "DCECParsingError",
    "LEGAL_IR_LIFECYCLE_SCHEMA_VERSION",
    "compile_lifecycle_events",
]

# Phase 4C: Grammar-based NL processing
try:
    from .grammar_engine import (
        GrammarEngine,
        Category,
        GrammarRule,
        LexicalEntry,
        ParseNode,
        CompositeGrammar,
        make_binary_rule,
        make_unary_rule,
    )

    from .dcec_english_grammar import (
        DCECEnglishGrammar,
        create_dcec_grammar,
    )

    __all__.extend(
        [
            "GrammarEngine",
            "Category",
            "GrammarRule",
            "LexicalEntry",
            "ParseNode",
            "CompositeGrammar",
            "make_binary_rule",
            "make_unary_rule",
            "DCECEnglishGrammar",
            "create_dcec_grammar",
        ]
    )

    GRAMMAR_AVAILABLE = True
except ImportError:
    GRAMMAR_AVAILABLE = False

# Phase 4D: ShadowProver modal logic theorem prover
try:
    from .shadow_prover import (
        ShadowProver,
        KProver,
        S4Prover,
        S5Prover,
        CognitiveCalculusProver,
        ModalLogic,
        ProofStatus,
        ProofStep,
        ProofTree,
        ProblemFile,
        ModalOperator,
        ProblemReader,
        create_prover,
        create_cognitive_prover,
    )

    from .modal_tableaux import (
        TableauNode,
        ModalTableau,
        TableauProver,
        ResolutionProver,
        NodeStatus,
        create_tableau_prover,
        create_resolution_prover,
    )

    __all__.extend(
        [
            "ShadowProver",
            "KProver",
            "S4Prover",
            "S5Prover",
            "CognitiveCalculusProver",
            "ModalLogic",
            "ProofStatus",
            "ProofStep",
            "ProofTree",
            "ProblemFile",
            "ModalOperator",
            "ProblemReader",
            "create_prover",
            "create_cognitive_prover",
            "TableauNode",
            "ModalTableau",
            "TableauProver",
            "ResolutionProver",
            "NodeStatus",
            "create_tableau_prover",
            "create_resolution_prover",
        ]
    )

    SHADOWPROVER_AVAILABLE = True
except ImportError:
    SHADOWPROVER_AVAILABLE = False

# Phase 4D: Problem file parser
try:
    from .problem_parser import (
        TPTPParser,
        CustomProblemParser,
        ProblemParser,
        TPTPFormula,
        parse_problem_file,
        parse_problem_string,
    )

    __all__.extend(
        [
            "TPTPParser",
            "CustomProblemParser",
            "ProblemParser",
            "TPTPFormula",
            "parse_problem_file",
            "parse_problem_string",
        ]
    )

    PROBLEM_PARSER_AVAILABLE = True
except ImportError:
    PROBLEM_PARSER_AVAILABLE = False

# Phase 3+: Proof caching and ZKP integration
try:
    from .cec_proof_cache import (
        CECCachedProofResult,
        CachedTheoremProver,
        get_global_cached_prover,
        HAVE_CACHE,
    )

    from .cec_zkp_integration import (
        ProvingMethod,
        UnifiedCECProofResult,
        ZKPCECProver,
        create_hybrid_prover,
        HAVE_ZKP,
    )

    __all__.extend(
        [
            "CECCachedProofResult",
            "CachedTheoremProver",
            "get_global_cached_prover",
            "HAVE_CACHE",
            "ProvingMethod",
            "UnifiedCECProofResult",
            "ZKPCECProver",
            "create_hybrid_prover",
            "HAVE_ZKP",
        ]
    )

    CACHING_AVAILABLE = True
    ZKP_AVAILABLE = HAVE_ZKP
except ImportError as e:
    CACHING_AVAILABLE = False
    ZKP_AVAILABLE = False

# Version reflects completion of all Phase 4 components + caching/ZKP
__version__ = "1.1.0"


def tokenize_dcec(expression: str):
    """Tokenize a DCEC expression string into a list of tokens."""
    import re

    # Simple tokenizer: split on whitespace and parentheses
    tokens = re.findall(r"[()]|[^\s()]+", expression)
    return tokens


# Export tokenize_dcec
__all__.append("tokenize_dcec")

# Export InferenceRule from inference_rules for Phase 4B
try:
    from .inference_rules.base import InferenceRule

    __all__.append("InferenceRule")
except ImportError:
    pass
