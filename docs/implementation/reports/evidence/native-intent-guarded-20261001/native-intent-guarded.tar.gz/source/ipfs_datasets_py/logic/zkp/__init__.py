"""
Zero-Knowledge Proof (ZKP) SIMULATION Module - Educational/Demo Only.

⚠️ WARNING: This is a SIMULATED ZKP system for educational and demonstration
purposes ONLY. It is NOT cryptographically secure and should NOT be used in
production systems requiring real zero-knowledge proofs.

What this module provides:
    - Educational demonstration of ZKP concepts
    - Fast simulation for prototyping (<0.1ms)
    - Simple API showing how ZKP systems work
    - Mock proofs using hash-based commitments

What this module does NOT provide:
    - Real cryptographic security
    - Actual zkSNARKs (Groth16, PLONK, etc.)
    - Production-ready zero-knowledge proofs
    - Integration with py_ecc or other crypto libraries

For production ZKP, you need:
    - Integrate py_ecc library with Groth16 zkSNARKs
    - Implement proper trusted setup
    - Use real circuit compilation
    - Add cryptographic security validations

Key Components (Simulated):
    - SimulatedZKPProver: Generate mock proofs for demonstration
    - SimulatedZKPVerifier: Verify mock proofs
    - SimulatedZKPCircuit: Mock circuit definitions

Use Cases (Educational Only):
    1. Learning ZKP concepts and workflows
    2. Prototyping ZKP-enabled systems
    3. Testing application logic with mock proofs
    4. Educational demonstrations

Example:
    >>> from ipfs_datasets_py.logic.zkp import SimulatedZKPProver, SimulatedZKPVerifier
    >>>
    >>> # SIMULATION - NOT cryptographically secure!
    >>> prover = SimulatedZKPProver()
    >>> proof = prover.generate_proof(
    ...     theorem="Q",
    ...     private_axioms=["P", "P -> Q"]
    ... )
    >>>
    >>> # Verify mock proof
    >>> verifier = SimulatedZKPVerifier()
    >>> assert verifier.verify_proof(proof)  # Mock verification
    >>>
    >>> print("⚠️  This is a SIMULATION - not cryptographically secure!")

Performance (Simulation):
    - Proof Size: ~160 bytes (mock commitment)
    - Proving Time: <0.1ms (no real cryptography)
    - Verification Time: <0.01ms (simple hash check)
    - Security: NONE - simulation only!

For Production Use:
    See KNOWN_LIMITATIONS.md for roadmap to real ZKP integration.
    DO NOT use this module for security-critical applications.
"""

from typing import Dict, Any
from dataclasses import dataclass
import importlib
import warnings

__all__ = [
    "ZKPProof",  # Kept for backward compatibility
    "SimulatedZKPProof",  # New name reflecting simulation
    "ZKPProver",  # Deprecated - use SimulatedZKPProver
    "SimulatedZKPProver",  # Correct name
    "ZKPVerifier",  # Deprecated - use SimulatedZKPVerifier
    "SimulatedZKPVerifier",  # Correct name
    "ZKPCircuit",  # Deprecated - use SimulatedZKPCircuit
    "SimulatedZKPCircuit",  # Correct name
    "BooleanCircuit",  # Alias for ZKPCircuit (backward compatibility with docs)
    "ZKPError",
    "create_implication_circuit",
    "build_proof_attestation_view",
    "attestation_view_matches_proof",
    "compiler_guidance_contract_from_metadata",
    "compiler_guidance_ref_from_metadata",
    "complete_zkp_attestation_record",
    "decode_simulated_proof_layout",
    "proof_attestation_view_from_proof_dict",
    "proof_digest_from_proof_dict",
    "proof_public_inputs_from_proof_dict",
    "refresh_proof_attestation",
    "zkp_attestation_legal_ir_view_loss",
]

_SIMULATION_WARNING = (
    "⚠️  WARNING: ipfs_datasets_py.logic.zkp is a SIMULATION module, NOT cryptographically secure! "
    "Do not use for production systems requiring real zero-knowledge proofs. "
    "See KNOWN_LIMITATIONS.md for details."
)

_WARNED = False


def _warn_once() -> None:
    global _WARNED
    if _WARNED:
        return
    _WARNED = True
    warnings.warn(_SIMULATION_WARNING, UserWarning, stacklevel=3)


# Version
__version__ = "0.1.0"


@dataclass
class ZKPProof:
    """
    SIMULATED Zero-Knowledge Proof - Educational/Demo Only.

    ⚠️  WARNING: This is NOT a cryptographically secure proof!
    It uses simple hash-based commitments for demonstration purposes.

    For production ZKP, integrate py_ecc library with real zkSNARKs.

    Attributes:
        proof_data: Mock proof data (hash-based, not cryptographic)
        public_inputs: Public information (theorem statement)
        metadata: Additional proof metadata
        timestamp: When proof was generated
        size_bytes: Size of proof in bytes
    """

    proof_data: bytes
    public_inputs: Dict[str, Any]
    metadata: Dict[str, Any]
    timestamp: float
    size_bytes: int

    def __post_init__(self) -> None:
        # Emit once on actual simulated proof usage, not for real Groth16 proof
        # subclasses that share this compatibility dataclass.
        metadata = self.metadata if isinstance(self.metadata, dict) else {}
        backend = str(metadata.get("backend") or "").lower()
        proof_system = str(metadata.get("proof_system") or "").lower()
        if not backend or "simulated" in backend or "simulated" in proof_system:
            _warn_once()

    def to_dict(self) -> Dict[str, Any]:
        """Convert proof to dictionary format."""
        return {
            "proof_data": self.proof_data.hex(),
            "public_inputs": self.public_inputs,
            "metadata": self.metadata,
            "timestamp": self.timestamp,
            "size_bytes": self.size_bytes,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ZKPProof":
        """Create proof from dictionary format."""
        return cls(
            proof_data=bytes.fromhex(data["proof_data"]),
            public_inputs=data["public_inputs"],
            metadata=data["metadata"],
            timestamp=data["timestamp"],
            size_bytes=data["size_bytes"],
        )


class ZKPError(Exception):
    """Exception raised for ZKP-related errors."""

    pass


def __getattr__(name: str):
    # Only warn on use of the simulated API (not on import).
    if name in {
        "SimulatedZKPProver",
        "SimulatedZKPVerifier",
        "ZKPCircuit",
        "SimulatedZKPCircuit",
        "BooleanCircuit",  # Alias for ZKPCircuit
        "create_implication_circuit",
    }:
        _warn_once()

    if name in {"ZKPProver", "SimulatedZKPProver"}:
        mod = importlib.import_module(f"{__name__}.zkp_prover")
        value = getattr(mod, "ZKPProver")
        globals()["ZKPProver"] = value
        globals()["SimulatedZKPProver"] = value
        return globals()[name]

    if name in {"ZKPVerifier", "SimulatedZKPVerifier"}:
        mod = importlib.import_module(f"{__name__}.zkp_verifier")
        value = getattr(mod, "ZKPVerifier")
        globals()["ZKPVerifier"] = value
        globals()["SimulatedZKPVerifier"] = value
        return globals()[name]

    if name in {
        "ZKPCircuit",
        "SimulatedZKPCircuit",
        "BooleanCircuit",
        "create_implication_circuit",
        "build_proof_attestation_view",
        "attestation_view_matches_proof",
        "compiler_guidance_contract_from_metadata",
        "compiler_guidance_ref_from_metadata",
        "complete_zkp_attestation_record",
        "decode_simulated_proof_layout",
        "proof_attestation_view_from_proof_dict",
        "proof_digest_from_proof_dict",
        "proof_public_inputs_from_proof_dict",
        "refresh_proof_attestation",
        "zkp_attestation_legal_ir_view_loss",
    }:
        mod = importlib.import_module(f"{__name__}.circuits")
        if name in {
            "create_implication_circuit",
            "build_proof_attestation_view",
            "attestation_view_matches_proof",
            "compiler_guidance_contract_from_metadata",
            "compiler_guidance_ref_from_metadata",
            "complete_zkp_attestation_record",
            "decode_simulated_proof_layout",
            "proof_attestation_view_from_proof_dict",
            "proof_digest_from_proof_dict",
            "proof_public_inputs_from_proof_dict",
            "refresh_proof_attestation",
            "zkp_attestation_legal_ir_view_loss",
        }:
            value = getattr(mod, name)
            globals()[name] = value
            return value
        value = getattr(mod, "ZKPCircuit")
        globals()["ZKPCircuit"] = value
        globals()["SimulatedZKPCircuit"] = value
        globals()["BooleanCircuit"] = value  # Alias for backward compatibility with docs
        return globals()[name]

    if name == "SimulatedZKPProof":
        globals()[name] = ZKPProof
        return ZKPProof

    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


def __dir__():
    return sorted(set(globals().keys()) | set(__all__))


# Aliases with correct naming (Simulated prefix)
SimulatedZKPProof = ZKPProof  # Same class, clearer name

# BooleanCircuit will be aliased to ZKPCircuit via __getattr__ for backward compatibility
