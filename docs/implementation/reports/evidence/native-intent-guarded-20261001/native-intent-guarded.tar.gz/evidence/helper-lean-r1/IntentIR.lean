structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 4
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:declared", [("completed", (.boolean false)), ("ready", (.boolean true))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:declared", [("completed", (.boolean true)), ("ready", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def condition0 (values : Values) : Bool := (lookup values "completed" == some (.boolean true))
def condition0Source : String × String × List String := ("effect", "complete", ["report"])
def condition1 (values : Values) : Bool := (lookup values "ready" == some (.boolean true))
def condition1Source : String × String × List String := ("pre", "ready", ["report"])
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:declared")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("completed", (.boolean true))])) && ((configuration2.phase == "done")) && (condition1 configuration1.values) && (condition0 configuration2.values)
theorem action_case_0_checks : actionCase0 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by decide
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by decide
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by decide
def declaredActions : List String := ["action:declared"]
def enabledActions : List String := ["action:declared"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent
