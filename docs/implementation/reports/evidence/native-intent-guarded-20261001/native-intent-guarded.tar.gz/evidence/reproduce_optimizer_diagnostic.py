"""Transcription of the read-only inline probe, saved after its execution.

Original invocation: from ../native-semantic-projections-20261001/source,
PYTHONPATH=$PWD python3 <this-file>. All checkpoint tensors are newly allocated;
no optimizer is constructed, stepped, or saved. The final write is diagnostic
JSON only. These are the previously exposed authored train/tuning inputs.
"""
import json,pathlib,hashlib,torch
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_family_training_validated_v3 as trainer
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_family_training_prepared as prep
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_family_training as codec
torch.set_num_threads(1)
root=pathlib.Path('../authored-training-r1').resolve(); outputs=[]
for domain in ['intent_ir','security_ir','ui_ux_ir','legal_ir']:
 parent=root/domain
 saved=json.loads((parent/'checkpoint/family_checkpoint.json').read_text());report=saved['report']
 source=[json.loads((parent/f'source-{i}-prepared-targets.json').read_text()) for i in range(3)]
 atoms,_=prep._atom_encoder();rows=trainer._reports(source,atoms=atoms)
 x,m,spans,_=codec._matrix(saved['space'],rows[:2]);y,vm,_,_=codec._matrix(saved['space'],rows[2:])
 p=[torch.tensor(a,dtype=torch.float64,requires_grad=True) for a in saved['parameters']]
 loss,metrics=codec._objective(torch,prep._forward(torch,y,p),y,vm,spans,saved['space']['projections'])
 assert abs(float(loss)-report['after']['objective'])<1e-14
 gen=torch.Generator(device='cpu').manual_seed(report['settings']['seed']);idx=torch.randperm(len(x),generator=gen)
 clean=x[idx];mask=m[idx];obj=prep._PreparedObjective(torch,clean,mask,spans,saved['space']['projections'],(len(x),m.sum(dim=0).tolist()))
 cleanloss=obj(prep._forward(torch,clean,p));corruption=torch.rand(clean.shape,generator=gen)>=report['settings']['denoising'];noisyloss=obj(prep._forward(torch,clean*corruption,p))
 def grads(loss):return torch.cat([v.reshape(-1) for v in torch.autograd.grad(loss,p,retain_graph=True)])
 cg,ng,vg=grads(cleanloss),grads(noisyloss),grads(loss);blend=.75*cg+.25*ng
 train_value=.75*float(cleanloss)+.25*float(noisyloss)
 assert abs(train_value-report['history'][0]['training_objective'])<1e-14
 def cosine(a,b):return float(torch.nn.functional.cosine_similarity(a,b,dim=0,eps=1e-30))
 norm=lambda a:float(torch.linalg.vector_norm(a))
 out={'domain':domain,'checkpoint_sha256':hashlib.sha256((parent/'checkpoint/family_checkpoint.json').read_bytes()).hexdigest(),'saved_baseline_replay_exact_loss':True,'first_epoch_training_objective_replay_matches':True,'clean_loss':float(cleanloss),'denoising_loss':float(noisyloss),'combined_loss':train_value,'clean_gradient_norm':norm(cg),'denoising_gradient_norm':norm(ng),'weighted_denoising_gradient_norm':norm(.25*ng),'weighted_clean_gradient_norm':norm(.75*cg),'gradient_cosine_clean_vs_denoising':cosine(cg,ng),'tuning_gradient_dot_clean_gradient':float(vg@cg),'tuning_gradient_dot_blended_gradient':float(vg@blend),'update_executed':False}
 # Adam first-step direction is coordinate-normalized (not raw gradient).
 adam_direction=blend/(blend.abs()+1e-8)
 out['tuning_gradient_dot_initial_Adam_direction']=float(vg@adam_direction)
 out['clean_gradient_dot_initial_Adam_direction']=float(cg@adam_direction)
 out['zero_training_variance_projections']=[name for name,(start,end) in spans.items() if bool(torch.equal(x[0,start:end],x[1,start:end]))]
 outputs.append(out)
 print(json.dumps(out),flush=True)
path=root.parent/'optimizer-readonly-diagnosis.json';path.write_text(json.dumps({'scope':'read-only loss and first-step gradient diagnosis; no optimizer update or source qualification','items':outputs},indent=2)+'\n')
