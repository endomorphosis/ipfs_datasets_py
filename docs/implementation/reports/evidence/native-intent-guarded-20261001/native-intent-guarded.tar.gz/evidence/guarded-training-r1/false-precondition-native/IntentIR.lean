-- Actual native interpretation declarations; no source truth asserted.

namespace IntentIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_0
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.cognitive "I" (i.agent "officer") (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
def programSatisfaction {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := (formula_0 i t) ∧ (formula_1 i t)
end Projection_0

namespace Projection_1
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.function "S050778938157fb22ee8ed65041ad1e982bdb810b8774e69eaebaa89ff3f37986" []), (i.function "S5d97d1650aaa8e9725d546180f30e97cb9de96c30527940a2c52fc71d0443bff" [])] t))
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "I" (i.agent "S050778938157fb22ee8ed65041ad1e982bdb810b8774e69eaebaa89ff3f37986") (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.function "S050778938157fb22ee8ed65041ad1e982bdb810b8774e69eaebaa89ff3f37986" []), (i.function "S5d97d1650aaa8e9725d546180f30e97cb9de96c30527940a2c52fc71d0443bff" [])] t))
end Projection_1

namespace Projection_2
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t)))
end Projection_2

namespace Projection_3
def norm_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
end Projection_3

namespace Projection_4
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Reports" [v0] t)) t)
end Projection_4

namespace Projection_5
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
end Projection_5

namespace Projection_6
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t))
end Projection_6

namespace Projection_7
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Person" [v0] t) t) → ((fun t => i.atom "Reports" [v0] t) t)) t)
end Projection_7

namespace Projection_8
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_49da8d75bab26a1343aaaf3b305440ac139a81a1a0adb9bfdb198a51d157942e") "/document_id" (i.constant "\"intent:authored-guarded:0\"")
def frame_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_49da8d75bab26a1343aaaf3b305440ac139a81a1a0adb9bfdb198a51d157942e") "/entry_action_ids/0" (i.constant "\"action:declared\"")
def frame_2 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_49da8d75bab26a1343aaaf3b305440ac139a81a1a0adb9bfdb198a51d157942e") "/intent_kind" (i.constant "\"procedure\"")
def frame_3 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_49da8d75bab26a1343aaaf3b305440ac139a81a1a0adb9bfdb198a51d157942e") "/schema_version" (i.constant "\"intent-ir/v1\"")
def frame_4 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_49da8d75bab26a1343aaaf3b305440ac139a81a1a0adb9bfdb198a51d157942e") "/tags" (i.constant "[]")
def frame_5 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_49da8d75bab26a1343aaaf3b305440ac139a81a1a0adb9bfdb198a51d157942e") "/terminal_action_ids/0" (i.constant "\"action:declared\"")
def frame_6 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_49da8d75bab26a1343aaaf3b305440ac139a81a1a0adb9bfdb198a51d157942e") "/title" (i.constant "\"Authored guarded Intent fixture\"")
def frame_7 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_sha256" (i.constant "\"\"")
def frame_8 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_uri" (i.constant "\"\"")
def frame_9 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_cid" (i.constant "\"\"")
def frame_10 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_sha256" (i.constant "\"58d9e7712fcc8baf3bc91a8c7974aa31a24d31758fbbf3458146ca1d75ebd9ed\"")
def frame_11 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/license_expression" (i.constant "\"\"")
def frame_12 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/ref_id" (i.constant "\"source\"")
def frame_13 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/review_status" (i.constant "\"unreviewed\"")
def frame_14 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_id" (i.constant "\"authored-guarded:0\"")
def frame_15 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_revision" (i.constant "\"v1\"")
def frame_16 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_uri" (i.constant "\"urn:authored:guarded-intent:0\"")
def frame_17 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span" (i.constant "null")
def frame_18 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/arguments/0" (i.constant "\"report\"")
def frame_19 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/confidence" (i.constant "1.0")
def frame_20 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/grounding" (i.constant "\"grounded\"")
def frame_21 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/kind" (i.constant "\"effect\"")
def frame_22 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/modality" (i.constant "\"asserted\"")
def frame_23 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/normalized_text" (i.constant "\"Report operation is complete.\"")
def frame_24 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/predicate" (i.constant "\"complete\"")
def frame_25 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/review_status" (i.constant "\"machine_extracted\"")
def frame_26 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_27 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4fda89b6fdf6b1a636c7f6d9193b84881a64d30a7caa8312ae9cd8a4505fc740") "/statement_id" (i.constant "\"effect\"")
def frame_28 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/arguments/0" (i.constant "\"officer\"")
def frame_29 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/arguments/1" (i.constant "\"report\"")
def frame_30 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/confidence" (i.constant "1.0")
def frame_31 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/grounding" (i.constant "\"grounded\"")
def frame_32 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/kind" (i.constant "\"goal\"")
def frame_33 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/modality" (i.constant "\"asserted\"")
def frame_34 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/normalized_text" (i.constant "\"officer intends to publish report.\"")
def frame_35 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/predicate" (i.constant "\"publish\"")
def frame_36 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/review_status" (i.constant "\"machine_extracted\"")
def frame_37 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_38 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_4dfa9d6b2cee1b2ba7d851710ce8976fc76e2e4fb302f03be247dd4754901728") "/statement_id" (i.constant "\"goal:intended\"")
def frame_39 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/arguments/0" (i.constant "\"officer\"")
def frame_40 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/arguments/1" (i.constant "\"report\"")
def frame_41 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/confidence" (i.constant "1.0")
def frame_42 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/grounding" (i.constant "\"grounded\"")
def frame_43 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/kind" (i.constant "\"goal\"")
def frame_44 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/modality" (i.constant "\"required\"")
def frame_45 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/normalized_text" (i.constant "\"officer must publish report.\"")
def frame_46 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/predicate" (i.constant "\"publish\"")
def frame_47 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/review_status" (i.constant "\"machine_extracted\"")
def frame_48 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_49 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e9fd2d405997f363d857adc17f43a1f3de00c1e138e1b44c4b9eae2b65bd2eec") "/statement_id" (i.constant "\"goal:required\"")
def frame_50 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/arguments/0" (i.constant "\"report\"")
def frame_51 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/confidence" (i.constant "1.0")
def frame_52 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/grounding" (i.constant "\"grounded\"")
def frame_53 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/kind" (i.constant "\"precondition\"")
def frame_54 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/modality" (i.constant "\"asserted\"")
def frame_55 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/normalized_text" (i.constant "\"Report is ready.\"")
def frame_56 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/predicate" (i.constant "\"ready\"")
def frame_57 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/review_status" (i.constant "\"machine_extracted\"")
def frame_58 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_59 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b2072fa2f53c99d3643625cf49bfeec5d79fee77a0168260eaeca3a84fedc81e") "/statement_id" (i.constant "\"pre\"")
def frame_60 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/action_id" (i.constant "\"action:declared\"")
def frame_61 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/actor" (i.constant "\"officer\"")
def frame_62 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/effect_ids/0" (i.constant "\"effect\"")
def frame_63 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/grounding" (i.constant "\"grounded\"")
def frame_64 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/input_refs" (i.constant "[]")
def frame_65 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/object_refs/0" (i.constant "\"report\"")
def frame_66 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/output_refs" (i.constant "[]")
def frame_67 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/precondition_ids/0" (i.constant "\"pre\"")
def frame_68 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_69 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/tool_refs" (i.constant "[]")
def frame_70 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/verb" (i.constant "\"publish\"")
def frame_71 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_7035a720e707bd30d9be10386867e5cd43660799c4e8c710109c2bf2b28091b3") "/verification_ids" (i.constant "[]")
end Projection_8

namespace Projection_9
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"alice\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"officer\"}"))
end Projection_9

namespace Projection_10
-- Generated candidate embedding. No semantic axioms or program proofs are asserted.
namespace IntentProjection

structure Interpretation where
  atom : String → List String → Prop
  intended : Prop → Prop
  required : Prop → Prop
  prohibited : Prop → Prop
  permitted : Prop → Prop
  recommended : Prop → Prop

def statement_11869691d490163b6656395be0479bda069f67b889bd9efa3afc89aae1a5398e (i : Interpretation) : Prop :=
  i.required (i.atom "publish" ["officer", "report"])

def statement_bfb50fc3afbac668f963c2faa8eeaddfa3504d64bba2767b0b7b5f142c6d74cc (i : Interpretation) : Prop :=
  i.intended (i.atom "publish" ["officer", "report"])

def statement_695252f664b93b2375fc1738693a32a19e8c722fe14e81a3d80cc5b85a923da0 (i : Interpretation) : Prop :=
  i.atom "ready" ["report"]

def statement_dcb576426a17b7df13907007cb02a1f1dfc12fc6c69f603717abca59d03b888e (i : Interpretation) : Prop :=
  i.atom "complete" ["report"]

end IntentProjection

end Projection_10

namespace Projection_11
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.cognitive "I" (i.agent "officer") (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
def programSatisfaction {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := (formula_0 i t) ∧ (formula_1 i t)
end Projection_11

namespace Projection_12
def norm_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.cognitive "I" (i.agent "officer") (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
end Projection_12

namespace Projection_13
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.cognitive "I" (i.agent "officer") (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
end Projection_13

namespace Projection_14
structure IntentActionInterpretation (World Entity : Type) where
  constant : String → Entity
  atom : String → List Entity → World → Prop
  step : String → Entity → String → List Entity → World → World → Prop
def actionContract_0 {World Entity : Type} (i : IntentActionInterpretation World Entity) : Prop :=
  ∀ s t, ((i.atom "ready" [(i.constant "report")] s)) → (i.step "action:declared" (i.constant "officer") "publish" [(i.constant "report")] s t) → ((i.atom "complete" [(i.constant "report")] t))
end Projection_14

namespace Projection_16
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "p" [] t) ∧ (i.atom "q" [] t))
end Projection_16

namespace Projection_17
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.constant "entity:050778938157fb22ee8ed65041ad1e982bdb810b8774e69eaebaa89ff3f37986"), (i.constant "entity:5d97d1650aaa8e9725d546180f30e97cb9de96c30527940a2c52fc71d0443bff")] t))
end Projection_17

namespace Projection_18
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Reports" [v0] t))) t)
end Projection_18

namespace Projection_20
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Reports" [v0] t)) t)
end Projection_20

end IntentIR

