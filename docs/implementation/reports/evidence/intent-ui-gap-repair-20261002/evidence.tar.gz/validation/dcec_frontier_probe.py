#!/usr/bin/env python3
"""Read-only parser diagnosis of four archived rich Intent DCEC frontiers.

Run from any working directory. Only a new output receipt is written. No model,
training, native build, source repair, or projection replacement is executed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

RUN = Path(__file__).resolve().parent
ROOT = RUN / "validation-source"
NATIVE = RUN / "native-r1"
IDS = ("fixture-intent-if", "fixture-intent-if-negative", "fixture-intent-and", "fixture-intent-or")
FALSE = {"lake_executed": False, "external_solver_executed": False,
    "training_executed": False, "model_inference_executed": False,
    "candidate_rewritten": False, "formula_rewritten": False,
    "source_modified": False, "qualified": False, "admitted": False,
    "formalized": False, "source_semantics_verified": False,
    "proof_authority": False, "execution_authority": False}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=RUN / "dcec-frontier-r1.json")
    args = parser.parse_args()
    output = args.output.resolve()
    require(output.parent == RUN and not output.exists(), "write a new sibling receipt; never overwrite evidence")
    sys.dont_write_bytecode = True
    os.environ.update(PYTHONDONTWRITEBYTECODE="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                      IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI="0")
    sys.path.insert(0, str(ROOT))
    inputs = {str(Path(__file__).resolve()): sha(__file__)}

    def read(path):
        path = path.resolve()
        inputs[str(path)] = sha(path)
        return json.loads(path.read_bytes())

    manifest = read(NATIVE / "source-manifest.json")
    require(Path(manifest["root"]).resolve() == ROOT, "archived canonical producer root differs")
    source_pins = {row["path"]: row["sha256"] for row in manifest["files"]}
    for relative, digest in source_pins.items():
        path = (ROOT / relative).resolve()
        require(path.is_relative_to(ROOT) and sha(path) == digest, "frozen source differs: " + relative)
    summary = read(NATIVE / "summary.json")
    require(summary["all_source_and_input_files_unchanged"] is True, "completed native evidence required")
    from ipfs_datasets_py.logic.autoformal.tree_pin import require_workspace_logic_tree
    from ipfs_datasets_py.logic.autoformal import family_qualification as qualification
    from ipfs_datasets_py.logic.CEC.native.dcec_integration import parse_dcec_string
    from ipfs_datasets_py.logic.intent_ir.formalize.modal_projections import _ast
    tree = require_workspace_logic_tree()
    started = time.perf_counter()
    observations = []
    for identity in IDS:
        packet = read(NATIVE / identity / "result.json")
        report = packet["family_report"]
        projection = next(row for row in report["projections"] if row["projection_id"] == "rich-intent/dcec/v1")
        payload = projection["payload"]
        formula = payload["source"]
        formula_sha = hashlib.sha256(formula.encode()).hexdigest()
        native = parse_dcec_string(formula)
        native_ast = _ast(native)
        native_equal = native_ast == payload["ast"]
        require(native_equal and not native.get_free_variables(), "original native DCEC parser changed formula AST")
        independent = {"passed": False, "parser": qualification.__name__ + "._strict_tdfol"}
        try:
            _, receipt = qualification._strict_tdfol(formula)
            independent.update(passed=True, receipt=receipt)
        except (ValueError, TypeError) as error:
            independent.update(error_type=type(error).__name__, reason=str(error))
        strict = qualification.validate_family_artifact("dcec", formula)
        require(independent["passed"] is False and strict["passed"] is False,
                "frontier changed; retain this unexpected result for a new investigation")
        native_receipt = packet["native_check"]["native"]
        prepared_families = sorted({row["logic_family"] for row in report["projections"] if row["ready_for_training"]})
        passed_families = sorted({row["logic_family"] for row in native_receipt["per_projection"]
                                  if row["parser_status"] == "passed"})
        blocked = [{"projection_id": row["projection_id"], "logic_family": row["logic_family"],
                    "reason": row.get("reason")} for row in native_receipt["per_projection"]
                   if row["parser_status"] != "passed"]
        require(any(row["projection_id"] == projection["projection_id"]
                    and row["reason"] == "strict_native_formula_reparse_failed" for row in blocked),
                "archived native blocker differs")
        observations.append({"attempt_id": identity, "source_text": packet["source_text"],
            "candidate": packet["candidate"], "formula": formula, "formula_sha256": formula_sha,
            "original_native_ast": payload["ast"], "native_reparsed_ast": native_ast,
            "native_parse_passed": True, "native_complete_ast_equal": native_equal, "free_variables": [],
            "independent_strict_parse": independent, "strict_family_validator": strict,
            "requested_family_count": len(report["requested_families"]),
            "prepared_families": prepared_families, "native_passing_families": passed_families,
            "prepared_missing_families": native_receipt["missing_requested_families"],
            "native_passing_missing_families": sorted(set(report["requested_families"]) - set(passed_families)),
            "blocked_projections": blocked,
            "archived_lake_status": native_receipt["execution"]["status"],
            "archived_lake_receipt_scope": "prior native-r1 build; not executed by this diagnostic", **FALSE})
    modules = {name: {"path": str(Path(module.__file__).resolve()), "sha256": sha(module.__file__)}
        for name, module in tuple(sys.modules.items())
        if name.startswith("ipfs_datasets_py") and getattr(module, "__file__", None)}
    require(all(Path(row["path"]).is_relative_to(ROOT) for row in modules.values()), "producer drifted outside frozen tree")
    require(all(sha(ROOT / relative) == digest for relative, digest in source_pins.items()), "frozen source changed")
    require(all(sha(path) == digest for path, digest in inputs.items()), "diagnostic input changed")
    receipt = {"schema": "rich-intent-dcec-parser-frontier/v1", "source_root": str(ROOT),
        "logic_tree_pin": tree, "observations": observations, "observation_count": len(observations),
        "diagnosis": "native_DCEC_functional_Boolean_serialization_not_accepted_by_independent_strict_TDFOL_gate",
        "scope": "parser interoperability defect; unchanged source/candidates; no ambiguity claim or family bypass",
        "open_repair": "versioned faithful normalization plus exact AST parity across independent parsers; no source-input-only bypass",
        "coverage_scope": "prepared targets and native-passing families are separate; all forty requested families retained",
        "producer_modules": modules, "input_sha256": inputs, "frozen_source_file_count": len(source_pins),
        "inputs_and_frozen_source_unchanged": True, "elapsed_seconds": time.perf_counter() - started,
        "timing_scope": "four in-process parser probes and final provenance verification; no native build", **FALSE}
    with output.open("xb") as handle:
        handle.write(wire(receipt) + b"\n")
    print(json.dumps({"output": str(output), "observations": len(observations), "lake_executed": False}))


if __name__ == "__main__":
    main()
