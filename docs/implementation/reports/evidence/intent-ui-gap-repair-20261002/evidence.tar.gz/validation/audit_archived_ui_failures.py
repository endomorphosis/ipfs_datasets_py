"""Re-audit already exposed six UI failures without generation or target repair."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import time

RUN = Path(__file__).resolve().parent
WORKSPACE = RUN.parents[2]
SOURCE = RUN / "source"
sys.path.insert(0, str(SOURCE))
from ipfs_datasets_py.logic.formalization.autoencoder.ui_candidate_fidelity import audit_ui_candidate

OLD = WORKSPACE / "workspace/test-logs/intent-ui-coverage-20261002/native-checks-r1"
started = time.perf_counter()
manifest = json.loads((OLD / "summary.json").read_text())
results = []
inputs = {}
for row in manifest["attempts"]:
    if row.get("domain") != "ui_ux_ir" or row.get("strategy") != "v1":
        continue
    path = OLD / row["attempt_id"] / "candidate-and-preparation.json"
    before = path.read_bytes()
    inputs[str(path)] = hashlib.sha256(before).hexdigest()
    packet = json.loads(before)
    prediction = packet["recorded_prediction"]["raw_candidate_ir"]
    result = audit_ui_candidate(packet["source_text"], prediction)
    assert result["candidate"] == prediction
    assert path.read_bytes() == before
    results.append({"attempt_id": row["attempt_id"], "seed": row["seed"], "audit": result})
assert len(results) == 6
summary = {"schema": "archived-ui-source-fidelity-audit/v1",
    "evidence_scope": "six_previously_exposed_baseline_failures_not_fresh_holdout_or_training",
    "attempt_count": len(results), "status_counts": dict(Counter(r["audit"]["status"] for r in results)),
    "source_supported_count": sum(r["audit"]["source_supported"] for r in results),
    "native_valid_count": sum(r["audit"]["native_valid"] for r in results),
    "mismatch_path_counts": dict(Counter(d["path"] for r in results for d in r["audit"]["differences"])),
    "inputs_sha256": inputs, "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "source_snapshot": str(SOURCE), "attempts": results,
    "elapsed_seconds": time.perf_counter() - started,
    "candidate_rewritten": False, "training_executed": False, "inference_executed": False,
    "lake_executed": False, "qualified": False, "admitted": False, "formalized": False,
    "source_semantics_verified": False, "proof_authority": False}
(RUN / "archived-ui-fidelity-r1.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
print(json.dumps({k: v for k, v in summary.items() if k not in {"attempts", "inputs_sha256"}}, sort_keys=True))
