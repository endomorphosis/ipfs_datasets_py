-- Actual native interpretation declarations; no source truth asserted.

namespace IntentIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_1
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ((i.modal "deontic:O" [] none (fun t => i.atom "Se904a35838cc115556680ad432c62b3f5ac0767d70a997e85ab0b44dcb889adb" [(i.constant "entity:Se03778de48f3ed6b0126f4f17546aa99fad5175acde9faefa7af57939302b478"), (i.constant "entity:S8127bd5cdb73e98731c26d2ebb94bc9f89ffb1eca5669a93f692966cd1aa6b73")] t)) t) ∨ ((i.modal "deontic:F" [] none (fun t => i.atom "S443c71c069b4b03cc954bafe44408b5619e724dd8df2bb36ee3650f1174e44f6" [(i.constant "entity:S75a3f7b8ecf72aa2ab0f01531b01703a1f41f523ef0b53fe32afec0903a4f5f6"), (i.constant "entity:S4eaa422ad59aa224b45c48616f66a7d69f558b792fd870a08842f6f174a4d6e0")] t)) t))
end Projection_1

namespace Projection_2
-- Parameterized syntax fixture; referents and modal operators are arbitrary inputs.
namespace TypedSlotFixture
set_option autoImplicit false
def formula (T0 : Type) (T1 : Type) (v0 : T0) (v1 : T1) (v2 : T0) (v3 : T1) (p0 : T0 → T1 → Prop) (p1 : T0 → T1 → Prop) (m0 : Prop → Prop) (m1 : Prop → Prop) : Prop := ((m0 (p0 v0 v1)) ∨ (m1 (p1 v2 v3)))
end TypedSlotFixture

end Projection_2

namespace Projection_3
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ((i.modal "deontic:O" [] none (fun t => i.atom "Se904a35838cc115556680ad432c62b3f5ac0767d70a997e85ab0b44dcb889adb" [(i.constant "entity:Se03778de48f3ed6b0126f4f17546aa99fad5175acde9faefa7af57939302b478"), (i.constant "entity:S8127bd5cdb73e98731c26d2ebb94bc9f89ffb1eca5669a93f692966cd1aa6b73")] t)) t) ∨ ((i.modal "deontic:F" [] none (fun t => i.atom "S443c71c069b4b03cc954bafe44408b5619e724dd8df2bb36ee3650f1174e44f6" [(i.constant "entity:S75a3f7b8ecf72aa2ab0f01531b01703a1f41f523ef0b53fe32afec0903a4f5f6"), (i.constant "entity:S4eaa422ad59aa224b45c48616f66a7d69f558b792fd870a08842f6f174a4d6e0")] t)) t))
end Projection_3

end IntentIR

