"""Seal declared-source coverage without confusing it with learned outputs."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
import xml.etree.ElementTree as ET

P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
R = Path(__file__).resolve().parent
S = R / 'validation-source'
A = R / 'smoke-r1'
D = A / 'results'
O = P / 'docs/implementation/reports/evidence/family-coverage-context-20261002'
DOC = 'docs/autoencoders/source_family_coverage.md'
read = lambda p: json.loads(Path(p).read_bytes())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')


def tests(path):
    xml = ET.parse(path).getroot()
    return {k: sum(int(s.attrib.get(k, 0)) for s in xml.iter('testsuite'))
            for k in ('tests', 'failures', 'errors', 'skipped')}


summary = read(D / 'summary.json')
release = read(A / 'resources-final.json')
assert release['status'] == 'released' and release['record']['artifacts_durable_asserted'] is True
assert read(A / 'child-exit.json')['returncode'] == 0
assert summary['attempt_count'] == 26 and summary['prepared_count'] == summary['actual_Lake_pass_count'] == 11
assert summary['blocked_count'] == 15 and summary['strict_training_allowed_count'] == 0
for key in ('admitted', 'qualified', 'formalized', 'roundtrip_ok', 'source_semantics_verified',
    'neural_inference_executed', 'training_executed', 'weights_loaded', 'embeddings_loaded',
    'downloads_performed', 'checkpoint_promoted', 'fresh_holdout', 'constitution_formalized'):
    assert summary[key] is False, key
totals, cleanup = tests(R / 'validation-tests.xml'), tests(R / 'guardian-tests.xml')
assert totals == dict(tests=544, failures=0, errors=0, skipped=0), totals
assert cleanup == dict(tests=4, failures=0, errors=0, skipped=0), cleanup
pins = read(R / 'candidate-sha256.json')
for rel, digest in pins.items():
    assert sha(S / rel) == sha(P / rel) == digest, rel
for row in read(R / 'source-manifest.json')['files']:
    assert sha(S / row['path']) == row['sha256'], row['path']
audit = read(R / 'independent-audit.json')
assert audit['verdict'] == 'no_blocking_correctness_issue_found'
assert not audit['blocking_findings'] and audit['all_pins_match'] is True
compatibility = read(R / 'publication-compatibility.json')
assert compatibility['validated_base'] == read(R / 'base.json')['base']
assert not compatibility['producer_overlap'] and not compatibility['owned_overlap']
assert not O.exists()
O.mkdir(parents=True)
members, metadata, producers = {}, {}, {}


def add(path, name):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert name not in members and not Path(name).is_absolute() and '..' not in Path(name).parts
    members[name] = path
    metadata[name] = {'sha256': sha(path), 'bytes': path.stat().st_size}


def producer(path):
    path = Path(path)
    rel = path.relative_to(S).as_posix()
    digest = sha(path)
    assert producers.get(rel, digest) == digest
    producers[rel] = digest
    if 'source/' + rel not in members:
        add(path, 'source/' + rel)


for item in read(D / 'loaded-modules.json').values():
    assert sha(item['path']) == item['sha256']
    producer(item['path'])
for rel in read(R / 'candidate-files.json') + read(R / 'validation-test-files.json'):
    producer(S / rel)
for path in sorted((S / 'tests/fixtures/logic').rglob('*')):
    if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
        producer(path)
for path in sorted(A.rglob('*')):
    if not path.is_file() or path.is_symlink() or {'.git', '.lake', '__pycache__', '.pytest_cache'}.intersection(path.parts):
        continue
    add(path, 'validation/' + path.relative_to(R).as_posix())
for name in ('base.json', 'candidate-files.json', 'candidate-sha256.json', 'source-manifest.json',
    'resource-preflight.json', 'run_reserved.py', 'test_run_reserved.py', 'guardian.log',
    'validation-test-files.json', 'validation-tests.log', 'validation-tests.xml',
    'guardian-tests.log', 'guardian-tests.xml', 'independent-audit.json', 'publication-compatibility.json'):
    add(R / name, 'validation/' + name)
for path in sorted(R.glob('*unit-r*')):
    if path.is_file() and path.suffix in ('.log', '.xml'):
        add(path, 'validation/' + path.name)
add(P / DOC, 'source/' + DOC)
add(Path(__file__), 'validation/package_evidence.py')
archive = O / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=9) as target:
    for name, path in sorted(members.items()):
        content = path.read_bytes()
        assert hashlib.sha256(content).hexdigest() == metadata[name]['sha256']
        info = tarfile.TarInfo(name)
        info.size = len(content)
        info.mode = 0o644
        info.mtime = 0
        target.addfile(info, io.BytesIO(content))
artifact = {'sha256': sha(archive), 'bytes': archive.stat().st_size}
results = {'schema': 'declared-family-coverage-release/v1', 'validated_base': read(R / 'base.json')['base'],
    'candidate_sha256': pins, 'tests': totals, 'separate_guardian_cleanup_tests': cleanup,
    'summary': summary, 'independent_audit': audit, 'resource_release': release,
    'strict_native_batch_gates': read(D / 'native-batch-gates.json'),
    'all_frozen_producer_files_unchanged': True, 'archive': artifact,
    'artifact_count': len(members), 'scope': 'authored_declaration_coverage_not_learned_model_fidelity',
    'bridge_on_evaluation_ran': False, 'neural_inference_executed': False, 'training_executed': False,
    'model_target_token_ceiling': 64, 'admitted': False, 'qualified': False, 'formalized': False,
    'fresh_holdout': False, 'downloads_performed': False, 'checkpoint_promoted': False}
save(O / 'results.json', results)
save(O / 'manifest.json', {'schema': 'declared-family-coverage-evidence/v1',
    'tested_base_revision': results['validated_base'], 'archive': artifact, 'members': metadata,
    'validated_producer_source_sha256': producers})
owned = read(R / 'candidate-files.json') + [DOC] + [path.relative_to(P).as_posix() for path in sorted(O.iterdir())]
save(R / 'owned-files.json', owned)
print(json.dumps({'owned_files': len(owned), 'archive': artifact, 'artifacts': len(members), 'tests': totals}))
