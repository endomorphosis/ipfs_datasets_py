-- Actual native interpretation declarations; no source truth asserted.

namespace IntentIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_0
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => i.atom "ready" [(i.constant "report")] t)
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:P" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
def programSatisfaction {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := (formula_0 i t) ∧ (formula_1 i t)
end Projection_0

namespace Projection_1
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => i.atom "S316e748df68fac9b85c872e3c7f7fe418180b4c203ec809c01297ff74891c243" [(i.function "S5d97d1650aaa8e9725d546180f30e97cb9de96c30527940a2c52fc71d0443bff" [])] t)
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:P" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.function "S050778938157fb22ee8ed65041ad1e982bdb810b8774e69eaebaa89ff3f37986" []), (i.function "S5d97d1650aaa8e9725d546180f30e97cb9de96c30527940a2c52fc71d0443bff" [])] t))
end Projection_1

namespace Projection_2
def norm_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:P" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
end Projection_2

namespace Projection_3
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:P" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
end Projection_3

namespace Projection_4
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => i.atom "ready" [(i.constant "report")] t)
end Projection_4

namespace Projection_5
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9a09d7d0da24e246f3de9269b4681a6e3ec2fe53901c94281d08d2b3403684c1") "/document_id" (i.constant "\"intent-native-source:34de21cef94dae8dd867772092ee059a55a5d527c3a91060ae6df1bd10cbb491\"")
def frame_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9a09d7d0da24e246f3de9269b4681a6e3ec2fe53901c94281d08d2b3403684c1") "/entry_action_ids/0" (i.constant "\"action:0\"")
def frame_2 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9a09d7d0da24e246f3de9269b4681a6e3ec2fe53901c94281d08d2b3403684c1") "/intent_kind" (i.constant "\"procedure\"")
def frame_3 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9a09d7d0da24e246f3de9269b4681a6e3ec2fe53901c94281d08d2b3403684c1") "/schema_version" (i.constant "\"intent-ir/v1\"")
def frame_4 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9a09d7d0da24e246f3de9269b4681a6e3ec2fe53901c94281d08d2b3403684c1") "/tags/0" (i.constant "\"bounded-source-reference\"")
def frame_5 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9a09d7d0da24e246f3de9269b4681a6e3ec2fe53901c94281d08d2b3403684c1") "/terminal_action_ids/0" (i.constant "\"action:0\"")
def frame_6 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9a09d7d0da24e246f3de9269b4681a6e3ec2fe53901c94281d08d2b3403684c1") "/title" (i.constant "\"Bounded source Intent document\"")
def frame_7 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_sha256" (i.constant "\"\"")
def frame_8 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_uri" (i.constant "\"\"")
def frame_9 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_cid" (i.constant "\"\"")
def frame_10 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_sha256" (i.constant "\"34de21cef94dae8dd867772092ee059a55a5d527c3a91060ae6df1bd10cbb491\"")
def frame_11 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/license_expression" (i.constant "\"\"")
def frame_12 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/ref_id" (i.constant "\"source\"")
def frame_13 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/review_status" (i.constant "\"machine_extracted\"")
def frame_14 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_id" (i.constant "\"34de21cef94dae8dd867772092ee059a55a5d527c3a91060ae6df1bd10cbb491\"")
def frame_15 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_revision" (i.constant "\"34de21cef94dae8dd867772092ee059a55a5d527c3a91060ae6df1bd10cbb491\"")
def frame_16 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_uri" (i.constant "\"instruction:bounded-native-intent\"")
def frame_17 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span/end_char" (i.constant "59")
def frame_18 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span/start_char" (i.constant "0")
def frame_19 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/arguments/0" (i.constant "\"report\"")
def frame_20 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/confidence" (i.constant "0.0")
def frame_21 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/grounding" (i.constant "\"inferred\"")
def frame_22 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/kind" (i.constant "\"assumption\"")
def frame_23 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/modality" (i.constant "\"asserted\"")
def frame_24 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/normalized_text" (i.constant "\"Assume report is ready.\"")
def frame_25 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/predicate" (i.constant "\"ready\"")
def frame_26 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/review_status" (i.constant "\"machine_extracted\"")
def frame_27 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_28 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/statement_id" (i.constant "\"statement:0\"")
def frame_29 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/arguments/0" (i.constant "\"officer\"")
def frame_30 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/arguments/1" (i.constant "\"report\"")
def frame_31 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/confidence" (i.constant "0.0")
def frame_32 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/grounding" (i.constant "\"inferred\"")
def frame_33 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/kind" (i.constant "\"goal\"")
def frame_34 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/modality" (i.constant "\"permitted\"")
def frame_35 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/normalized_text" (i.constant "\"The officer may publish the report.\"")
def frame_36 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/predicate" (i.constant "\"publish\"")
def frame_37 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/review_status" (i.constant "\"machine_extracted\"")
def frame_38 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_39 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/statement_id" (i.constant "\"statement:1\"")
def frame_40 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/action_id" (i.constant "\"action:0\"")
def frame_41 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/actor" (i.constant "\"officer\"")
def frame_42 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/effect_ids" (i.constant "[]")
def frame_43 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/grounding" (i.constant "\"inferred\"")
def frame_44 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/input_refs" (i.constant "[]")
def frame_45 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/object_refs/0" (i.constant "\"report\"")
def frame_46 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/output_refs" (i.constant "[]")
def frame_47 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/precondition_ids" (i.constant "[]")
def frame_48 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_49 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/tool_refs" (i.constant "[]")
def frame_50 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/verb" (i.constant "\"publish\"")
def frame_51 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/verification_ids" (i.constant "[]")
end Projection_5

namespace Projection_6
-- Generated candidate embedding. No semantic axioms or program proofs are asserted.
namespace IntentProjection

structure Interpretation where
  atom : String → List String → Prop
  intended : Prop → Prop
  required : Prop → Prop
  prohibited : Prop → Prop
  permitted : Prop → Prop
  recommended : Prop → Prop

def statement_a2e441df177975785905cf8f1f3c501a5de5a7320fbf2973d42a6b86f77fed1b (i : Interpretation) : Prop :=
  i.atom "ready" ["report"]

def statement_598c42e181e5a092034f695c24c64614f3275002f9ec1685e923945965162964 (i : Interpretation) : Prop :=
  i.permitted (i.atom "publish" ["officer", "report"])

end IntentProjection

end Projection_6

namespace Projection_7
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => i.atom "ready" [(i.constant "report")] t)
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:P" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
def programSatisfaction {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := (formula_0 i t) ∧ (formula_1 i t)
end Projection_7

namespace Projection_8
structure IntentActionInterpretation (World Entity : Type) where
  constant : String → Entity
  atom : String → List Entity → World → Prop
  step : String → Entity → String → List Entity → World → World → Prop
def actionContract_0 {World Entity : Type} (i : IntentActionInterpretation World Entity) : Prop :=
  ∀ s t, (True) → (i.step "action:0" (i.constant "officer") "publish" [(i.constant "report")] s t) → (True)
end Projection_8

namespace Projection_9
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => i.atom "S316e748df68fac9b85c872e3c7f7fe418180b4c203ec809c01297ff74891c243" [(i.constant "entity:5d97d1650aaa8e9725d546180f30e97cb9de96c30527940a2c52fc71d0443bff")] t)
def formula_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:P" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.constant "entity:050778938157fb22ee8ed65041ad1e982bdb810b8774e69eaebaa89ff3f37986"), (i.constant "entity:5d97d1650aaa8e9725d546180f30e97cb9de96c30527940a2c52fc71d0443bff")] t))
end Projection_9

namespace Projection_10
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["position_0", "done"])
def predicate_0 (s : State) : Prop := (s.v0 = "done")
def predicate_1 (s : State) : Prop := (s.v0 = "done")
def predicate_2 (s : State) : Prop := (s.v0 = "position_0")
def predicate_3 (s : State) : Prop := (s.v0 = "position_0")
def predicate_4 (s : State) : Prop := (s.v0 = "done")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:abstract:0" ∧ action_0 s t) ∨ (label = "action:done" ∧ action_1 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_0 s) : action_1 s s := by
  simpa [action_1, predicate_0, predicate_1] using And.intro h h
def declaredMaxSteps : Nat := 64
def boundedControlRun (trace : Nat → State) (labels : Nat → String) : Prop :=
  initial (trace 0) ∧ ∀ k, k < declaredMaxSteps → next (labels k) (trace k) (trace (k + 1))
def intentActionOrigins : List (String × String) := [("action:abstract:0", "action:0")]
def completeDeclaredActionSequence (labels : List String) : Prop := labels = ["action:0"]

end Projection_10

namespace Projection_11
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["position_0", "done"])
def predicate_0 (s : State) : Prop := (s.v0 = "done")
def predicate_1 (s : State) : Prop := (s.v0 = "done")
def predicate_2 (s : State) : Prop := (s.v0 = "position_0")
def predicate_3 (s : State) : Prop := (s.v0 = "position_0")
def predicate_4 (s : State) : Prop := (s.v0 = "done")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:abstract:0" ∧ action_0 s t) ∨ (label = "action:done" ∧ action_1 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_0 s) : action_1 s s := by
  simpa [action_1, predicate_0, predicate_1] using And.intro h h
def declaredMaxSteps : Nat := 64
def boundedControlRun (trace : Nat → State) (labels : Nat → String) : Prop :=
  initial (trace 0) ∧ ∀ k, k < declaredMaxSteps → next (labels k) (trace k) (trace (k + 1))
def intentActionOrigins : List (String × String) := [("action:abstract:0", "action:0")]

end Projection_11

namespace Projection_12
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["position_0", "done"])
def predicate_0 (s : State) : Prop := (s.v0 = "done")
def predicate_1 (s : State) : Prop := (s.v0 = "done")
def predicate_2 (s : State) : Prop := (s.v0 = "position_0")
def predicate_3 (s : State) : Prop := (s.v0 = "position_0")
def predicate_4 (s : State) : Prop := (s.v0 = "done")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:abstract:0" ∧ action_0 s t) ∨ (label = "action:done" ∧ action_1 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_0 s) : action_1 s s := by
  simp_all [action_1, predicate_0, predicate_1]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := [("action:abstract:0", "action:0")]
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := [("action:done", "adapter_generated_terminal_self_loop")]
def stateAbstraction : String := "abstract_intent_control_flow"
def sourceIntentDocument : String := "intent-native-source:34de21cef94dae8dd867772092ee059a55a5d527c3a91060ae6df1bd10cbb491"
def sourceIntentIRSHA256 : String := "9c45e8ffc4ee88e7f9eb1a116204333c4d508735da2184be4dda225c6d765be3"
def intentPositionMap : List (String × String × String × String) := [("action:abstract:0", "action:0", "position_0", "done")]
def codeEffectsModeled : Bool := false
def normativeComplianceModeled : Bool := false
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 64
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:abstract:0", "action:done"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

end Projection_12

end IntentIR

