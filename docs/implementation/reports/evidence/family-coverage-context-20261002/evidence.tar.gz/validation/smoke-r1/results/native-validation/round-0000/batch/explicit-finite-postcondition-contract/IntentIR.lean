-- Actual native interpretation declarations; no source truth asserted.

namespace IntentIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_0
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
def programSatisfaction {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := (formula_0 i t)
end Projection_0

namespace Projection_1
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.function "S050778938157fb22ee8ed65041ad1e982bdb810b8774e69eaebaa89ff3f37986" []), (i.function "S5d97d1650aaa8e9725d546180f30e97cb9de96c30527940a2c52fc71d0443bff" [])] t))
end Projection_1

namespace Projection_2
def norm_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
end Projection_2

namespace Projection_3
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
end Projection_3

namespace Projection_4
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9e228316fc27a676be7a59995655f8c6527cb54b390bd059c9aee52a167981a4") "/document_id" (i.constant "\"intent-native-source:1d233b4e741e8f6f74cff87ec9ec5f98be64f6583a4a2ca3b152e3f1d24d62b6\"")
def frame_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9e228316fc27a676be7a59995655f8c6527cb54b390bd059c9aee52a167981a4") "/entry_action_ids/0" (i.constant "\"action:0\"")
def frame_2 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9e228316fc27a676be7a59995655f8c6527cb54b390bd059c9aee52a167981a4") "/intent_kind" (i.constant "\"procedure\"")
def frame_3 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9e228316fc27a676be7a59995655f8c6527cb54b390bd059c9aee52a167981a4") "/schema_version" (i.constant "\"intent-ir/v1\"")
def frame_4 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9e228316fc27a676be7a59995655f8c6527cb54b390bd059c9aee52a167981a4") "/tags/0" (i.constant "\"bounded-source-reference\"")
def frame_5 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9e228316fc27a676be7a59995655f8c6527cb54b390bd059c9aee52a167981a4") "/terminal_action_ids/0" (i.constant "\"action:0\"")
def frame_6 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_9e228316fc27a676be7a59995655f8c6527cb54b390bd059c9aee52a167981a4") "/title" (i.constant "\"Bounded source Intent document\"")
def frame_7 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_sha256" (i.constant "\"\"")
def frame_8 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_uri" (i.constant "\"\"")
def frame_9 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_cid" (i.constant "\"\"")
def frame_10 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_sha256" (i.constant "\"1d233b4e741e8f6f74cff87ec9ec5f98be64f6583a4a2ca3b152e3f1d24d62b6\"")
def frame_11 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/license_expression" (i.constant "\"\"")
def frame_12 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/ref_id" (i.constant "\"source\"")
def frame_13 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/review_status" (i.constant "\"machine_extracted\"")
def frame_14 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_id" (i.constant "\"1d233b4e741e8f6f74cff87ec9ec5f98be64f6583a4a2ca3b152e3f1d24d62b6\"")
def frame_15 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_revision" (i.constant "\"1d233b4e741e8f6f74cff87ec9ec5f98be64f6583a4a2ca3b152e3f1d24d62b6\"")
def frame_16 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_uri" (i.constant "\"instruction:bounded-native-intent\"")
def frame_17 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span/end_char" (i.constant "166")
def frame_18 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span/start_char" (i.constant "0")
def frame_19 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/arguments/0" (i.constant "\"officer\"")
def frame_20 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/arguments/1" (i.constant "\"report\"")
def frame_21 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/confidence" (i.constant "0.0")
def frame_22 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/grounding" (i.constant "\"inferred\"")
def frame_23 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/kind" (i.constant "\"goal\"")
def frame_24 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/modality" (i.constant "\"required\"")
def frame_25 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/normalized_text" (i.constant "\"The officer must publish the report.\"")
def frame_26 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/predicate" (i.constant "\"publish\"")
def frame_27 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/review_status" (i.constant "\"machine_extracted\"")
def frame_28 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_29 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_01bc4035943ce435c274c4e1e10da52e887f5fe6bcd69cc2ffeca9aa5d5833fd") "/statement_id" (i.constant "\"statement:0\"")
def frame_30 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/arguments/0" (i.constant "\"report\"")
def frame_31 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/confidence" (i.constant "0.0")
def frame_32 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/grounding" (i.constant "\"inferred\"")
def frame_33 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/kind" (i.constant "\"precondition\"")
def frame_34 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/modality" (i.constant "\"asserted\"")
def frame_35 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/normalized_text" (i.constant "\"Precondition of publish by officer on report: report is ready.\"")
def frame_36 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/predicate" (i.constant "\"ready\"")
def frame_37 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/review_status" (i.constant "\"machine_extracted\"")
def frame_38 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_39 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_f2fa51c4cba72b4223fc787086951b02ffbf29dbc6ed183edb2e859d7c3ee271") "/statement_id" (i.constant "\"statement:1\"")
def frame_40 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/arguments/0" (i.constant "\"report\"")
def frame_41 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/confidence" (i.constant "0.0")
def frame_42 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/grounding" (i.constant "\"inferred\"")
def frame_43 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/kind" (i.constant "\"postcondition\"")
def frame_44 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/modality" (i.constant "\"asserted\"")
def frame_45 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/normalized_text" (i.constant "\"Postcondition of publish by officer on report: report is complete.\"")
def frame_46 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/predicate" (i.constant "\"complete\"")
def frame_47 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/review_status" (i.constant "\"machine_extracted\"")
def frame_48 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_49 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b43249cc9bfd44eac5fbbb1cca0f0eade0dd59db2f140838b7aa8aa7a0322726") "/statement_id" (i.constant "\"statement:2\"")
def frame_50 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/action_id" (i.constant "\"action:0\"")
def frame_51 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/actor" (i.constant "\"officer\"")
def frame_52 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/effect_ids/0" (i.constant "\"statement:2\"")
def frame_53 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/grounding" (i.constant "\"inferred\"")
def frame_54 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/input_refs" (i.constant "[]")
def frame_55 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/object_refs/0" (i.constant "\"report\"")
def frame_56 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/output_refs" (i.constant "[]")
def frame_57 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/precondition_ids/0" (i.constant "\"statement:1\"")
def frame_58 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_59 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/tool_refs" (i.constant "[]")
def frame_60 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/verb" (i.constant "\"publish\"")
def frame_61 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/verification_ids" (i.constant "[]")
end Projection_4

namespace Projection_5
-- Generated candidate embedding. No semantic axioms or program proofs are asserted.
namespace IntentProjection

structure Interpretation where
  atom : String → List String → Prop
  intended : Prop → Prop
  required : Prop → Prop
  prohibited : Prop → Prop
  permitted : Prop → Prop
  recommended : Prop → Prop

def statement_a2e441df177975785905cf8f1f3c501a5de5a7320fbf2973d42a6b86f77fed1b (i : Interpretation) : Prop :=
  i.required (i.atom "publish" ["officer", "report"])

def statement_598c42e181e5a092034f695c24c64614f3275002f9ec1685e923945965162964 (i : Interpretation) : Prop :=
  i.atom "ready" ["report"]

def statement_14aeef89ec4a3010a9e05b04caeeca6cc19aadd6f74612c2cf596709a7394ccb (i : Interpretation) : Prop :=
  i.atom "complete" ["report"]

end IntentProjection

end Projection_5

namespace Projection_6
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "publish" [(i.constant "officer"), (i.constant "report")] t)
def programSatisfaction {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := (formula_0 i t)
end Projection_6

namespace Projection_7
structure IntentActionInterpretation (World Entity : Type) where
  constant : String → Entity
  atom : String → List Entity → World → Prop
  step : String → Entity → String → List Entity → World → World → Prop
def actionContract_0 {World Entity : Type} (i : IntentActionInterpretation World Entity) : Prop :=
  ∀ s t, ((i.atom "ready" [(i.constant "report")] s)) → (i.step "action:0" (i.constant "officer") "publish" [(i.constant "report")] s t) → ((i.atom "complete" [(i.constant "report")] t))
end Projection_7

namespace Projection_8
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 10
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:0", [("complete", (.boolean false)), ("ready", (.boolean true))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:0", [("complete", (.boolean true)), ("ready", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def condition0 (values : Values) : Bool := (lookup values "ready" == some (.boolean true))
def condition0Source : String × String × List String := ("statement:1", "ready", ["report"])
def condition1 (values : Values) : Bool := (lookup values "complete" == some (.boolean true))
def condition1Source : String × String × List String := ("statement:2", "complete", ["report"])
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("complete", (.boolean true))])) && ((configuration2.phase == "done")) && (condition0 configuration1.values) && (condition1 configuration2.values)
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean true)].contains (lookup configuration1.values "ready"))) && (([some (.boolean false)].contains (lookup configuration1.values "complete")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:0"]
def enabledActions : List String := ["action:0"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_8

namespace Projection_9
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S17b77d56cae59a976b54f836ae626664de1877118d32234b4a237e51ca83579f" [(i.constant "entity:050778938157fb22ee8ed65041ad1e982bdb810b8774e69eaebaa89ff3f37986"), (i.constant "entity:5d97d1650aaa8e9725d546180f30e97cb9de96c30527940a2c52fc71d0443bff")] t))
end Projection_9

namespace Projection_10
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 10
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:0", [("complete", (.boolean false)), ("ready", (.boolean true))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:0", [("complete", (.boolean true)), ("ready", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def condition0 (values : Values) : Bool := (lookup values "ready" == some (.boolean true))
def condition0Source : String × String × List String := ("statement:1", "ready", ["report"])
def condition1 (values : Values) : Bool := (lookup values "complete" == some (.boolean true))
def condition1Source : String × String × List String := ("statement:2", "complete", ["report"])
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("complete", (.boolean true))])) && ((configuration2.phase == "done")) && (condition0 configuration1.values) && (condition1 configuration2.values)
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean true)].contains (lookup configuration1.values "ready"))) && (([some (.boolean false)].contains (lookup configuration1.values "complete")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:0"]
def enabledActions : List String := ["action:0"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_10

namespace Projection_11
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 10
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:0", [("complete", (.boolean false)), ("ready", (.boolean true))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:0", [("complete", (.boolean true)), ("ready", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def condition0 (values : Values) : Bool := (lookup values "ready" == some (.boolean true))
def condition0Source : String × String × List String := ("statement:1", "ready", ["report"])
def condition1 (values : Values) : Bool := (lookup values "complete" == some (.boolean true))
def condition1Source : String × String × List String := ("statement:2", "complete", ["report"])
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("complete", (.boolean true))])) && ((configuration2.phase == "done")) && (condition0 configuration1.values) && (condition1 configuration2.values)
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean true)].contains (lookup configuration1.values "ready"))) && (([some (.boolean false)].contains (lookup configuration1.values "complete")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:0"]
def enabledActions : List String := ["action:0"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_11

namespace Projection_12
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 10
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:0", [("complete", (.boolean false)), ("ready", (.boolean true))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:0", [("complete", (.boolean true)), ("ready", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def condition0 (values : Values) : Bool := (lookup values "ready" == some (.boolean true))
def condition0Source : String × String × List String := ("statement:1", "ready", ["report"])
def condition1 (values : Values) : Bool := (lookup values "complete" == some (.boolean true))
def condition1Source : String × String × List String := ("statement:2", "complete", ["report"])
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("complete", (.boolean true))])) && ((configuration2.phase == "done")) && (condition0 configuration1.values) && (condition1 configuration2.values)
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean true)].contains (lookup configuration1.values "ready"))) && (([some (.boolean false)].contains (lookup configuration1.values "complete")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:0"]
def enabledActions : List String := ["action:0"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_12

end IntentIR

