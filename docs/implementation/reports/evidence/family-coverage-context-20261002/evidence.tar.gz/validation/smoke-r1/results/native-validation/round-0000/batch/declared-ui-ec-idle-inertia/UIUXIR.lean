-- Actual native interpretation declarations; no source truth asserted.

namespace UIUXIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_0
structure ECEdge where
  identity : String
  source : String
  target : String
  guardEnabled : Bool
  deriving DecidableEq, Repr
def edges : List ECEdge := [⟨"close", "open", "closed", true⟩]
def knownFluents : List String := ["closed", "open"]
def initialFluents : List String := ["open"]
def signedOccurrences : List (Option String) := [none, none, none]
def declaredClock : String := "{\"clock_id\":\"clock:fixture\",\"domain\":\"discrete\",\"epoch\":\"explicit-fixture-epoch\",\"resolution\":{\"denominator\":1,\"numerator\":2},\"schema_version\":\"trace-clock/v1\",\"unit\":\"logical_tick\"}"
def eventSymbolTable : String := "{\"close\":\"e_5b22636c6f7365222c22636c6f73655f6576656e74225d\"}"
def fluentSymbolTable : String := "{\"closed\":\"f_636c6f736564\",\"open\":\"f_6f70656e\"}"
def origin : Nat := 10
def resolution : Nat := 2
def cause (before : List String) (event fluent : String) (initiate : Bool) : Bool :=
  edges.any fun e => e.identity == event && e.guardEnabled && before.contains e.source &&
    (if initiate then e.target == fluent else e.source == fluent)
def stepFluents (before : List String) (event : Option String) : List String :=
  knownFluents.filter fun f =>
    event.any (fun e => cause before e f true) ||
    (before.contains f && !(event.any (fun e => cause before e f false)))
def fluentAt : Nat → List String
  | 0 => initialFluents
  | n + 1 => stepFluents (fluentAt n) ((signedOccurrences[n]?).getD none)
def tickIndex (time : Nat) : Option Nat :=
  if origin ≤ time ∧ (time - origin) % resolution = 0 then some ((time - origin) / resolution) else none
def happens (event : String) (time : Nat) : Option Bool := do
  let tick ← tickIndex time
  let occurrence ← signedOccurrences[tick]?
  if edges.any (fun e => e.identity == event) then some (occurrence == some event) else none
def holdsAt (fluent : String) (time : Nat) : Option Bool := do
  let tick ← tickIndex time
  if tick ≤ signedOccurrences.length ∧ knownFluents.contains fluent = true
  then some ((fluentAt tick).contains fluent) else none
def effectAt (event fluent : String) (time : Nat) (initiate : Bool) : Option Bool := do
  let tick ← tickIndex time
  if tick < signedOccurrences.length ∧ knownFluents.contains fluent = true ∧
      edges.any (fun e => e.identity == event) = true
  then some (cause (fluentAt tick) event fluent initiate) else none
def initiates (event fluent : String) (time : Nat) : Option Bool := effectAt event fluent time true
def terminates (event fluent : String) (time : Nat) : Option Bool := effectAt event fluent time false
def occurrenceEnabled (tick : Nat) : Bool :=
  ((signedOccurrences[tick]?).getD none).all fun event =>
    edges.any fun e => e.identity == event && e.guardEnabled && (fluentAt tick).contains e.source
theorem successor_inertia (tick : Nat) : fluentAt (tick + 1) =
    stepFluents (fluentAt tick) ((signedOccurrences[tick]?).getD none) := rfl
example : occurrenceEnabled 0 = true := by decide
example : happens "close" 10 = some false := by decide
example : occurrenceEnabled 1 = true := by decide
example : happens "close" 12 = some false := by decide
example : occurrenceEnabled 2 = true := by decide
example : happens "close" 14 = some false := by decide
example : (fluentAt 0).length = 1 := by decide
example : holdsAt "closed" 10 = some false := by decide
example : holdsAt "open" 10 = some true := by decide
example : (fluentAt 1).length = 1 := by decide
example : holdsAt "closed" 12 = some false := by decide
example : holdsAt "open" 12 = some true := by decide
example : (fluentAt 2).length = 1 := by decide
example : holdsAt "closed" 14 = some false := by decide
example : holdsAt "open" 14 = some true := by decide
example : (fluentAt 3).length = 1 := by decide
example : holdsAt "closed" 16 = some false := by decide
example : holdsAt "open" 16 = some true := by decide
example : initiates "close" "closed" 10 = some true := by decide
example : terminates "close" "closed" 10 = some false := by decide
example : initiates "close" "open" 10 = some false := by decide
example : terminates "close" "open" 10 = some true := by decide
example : initiates "close" "closed" 12 = some true := by decide
example : terminates "close" "closed" 12 = some false := by decide
example : initiates "close" "open" 12 = some false := by decide
example : terminates "close" "open" 12 = some true := by decide
example : initiates "close" "closed" 14 = some true := by decide
example : terminates "close" "closed" 14 = some false := by decide
example : initiates "close" "open" 14 = some false := by decide
example : terminates "close" "open" 14 = some true := by decide
example : happens "close" 16 = none := by decide
example : holdsAt "closed" 18 = none := by decide
example : holdsAt "open" 18 = none := by decide
def declaredNativeECFormulas : List String := ["forall t:Time. in_prefix(t) implies (initiates(e_5b22636c6f7365222c22636c6f73655f6576656e74225d, f_636c6f736564, t) iff (holds_at(f_6f70656e, t) and true))", "forall t:Time. in_prefix(t) implies (terminates(e_5b22636c6f7365222c22636c6f73655f6576656e74225d, f_6f70656e, t) iff (holds_at(f_6f70656e, t) and true))", "not happens(e_5b22636c6f7365222c22636c6f73655f6576656e74225d, 10)", "not happens(e_5b22636c6f7365222c22636c6f73655f6576656e74225d, 12)", "not happens(e_5b22636c6f7365222c22636c6f73655f6576656e74225d, 14)", "not holds_at(f_636c6f736564, 10)", "holds_at(f_6f70656e, 10)", "not holds_at(f_636c6f736564, 12)", "holds_at(f_6f70656e, 12)", "not holds_at(f_636c6f736564, 14)", "holds_at(f_6f70656e, 14)", "not holds_at(f_636c6f736564, 16)", "holds_at(f_6f70656e, 16)"]
end Projection_0

namespace Projection_1
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ((fun t => ((fun t => ((fun t => ((fun t => i.atom "UIAccessibleDescriptionRef" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_accessible_description_ref:v")] t) t) ∧ ((fun t => i.atom "UIAccessibleNameRef" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_accessible_name_ref:v")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIChildListLength" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_list_length:v30")] t) t) ∧ ((fun t => i.atom "UIComponent" [(i.constant "ui_component:v627574746f6e")] t) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UICompositionEdgeSetSize" [(i.constant "ui_document:v7569"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => i.atom "UIDataBindingSetSize" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_set_size:v30")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIDeclaredComponentSetSize" [(i.constant "ui_document:v7569"), (i.constant "ui_set_size:v31")] t) t) ∧ ((fun t => ((fun t => i.atom "UIDocumentComponent" [(i.constant "ui_document:v7569"), (i.constant "ui_component:v627574746f6e")] t) t) ∧ ((fun t => i.atom "UIEmptyParentField" [(i.constant "ui_component:v627574746f6e")] t) t)) t)) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => ((fun t => i.atom "UIEntryComponent" [(i.constant "ui_document:v7569"), (i.constant "ui_component:v627574746f6e")] t) t) ∧ ((fun t => i.atom "UIEntrySetSize" [(i.constant "ui_document:v7569"), (i.constant "ui_set_size:v31")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIFeedbackSetSize" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => ((fun t => i.atom "UIModalityBindingSetSize" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_set_size:v30")] t) t) ∧ ((fun t => i.atom "UIPresentation" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_presentation:v696e746572616374697665")] t) t)) t)) t)) t) ∧ ((fun t => ((fun t => ((fun t => i.atom "UIPrivacy" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_privacy:v6e6f6e65")] t) t) ∧ ((fun t => i.atom "UIProgramBindingSetSize" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_set_size:v30")] t) t)) t) ∧ ((fun t => ((fun t => i.atom "UIPurposeText" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_purpose:v")] t) t) ∧ ((fun t => ((fun t => i.atom "UIRole" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_role:v627574746f6e")] t) t) ∧ ((fun t => i.atom "UISourceRefSetSize" [(i.constant "ui_component:v627574746f6e"), (i.constant "ui_set_size:v30")] t) t)) t)) t)) t)) t))
end Projection_1

namespace Projection_2
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "button") "ui_component" (i.constant "button")
end Projection_2

namespace Projection_3
structure State where
  v0 : String
  v1 : Bool
def typeOK (s : State) : Prop := (s.v0 ∈ ["state_0", "state_1"])
def predicate_0 (s : State) : Prop := (s.v0 = "state_1") ∧ (s.v1 = true)
def predicate_1 (s : State) : Prop := (s.v0 = "state_0")
def predicate_2 (s : State) : Prop := (s.v0 = "state_1") ∧ (s.v1 = true)
def initial (s : State) : Prop := typeOK s ∧ (predicate_2 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:ui-control", "var:ui-param:0"].contains variableName
example : ["var:ui-control", "var:ui-param:0"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_1 t) ∧ (t.v1 = s.v1)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:ui-guard:0:1" ∧ action_0 s t)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
def sourceVariableAliases : List (String × String) := [("var:ui-control", "v0"), ("ui_control", "v0"), ("var:ui-param:0", "v1"), ("ui_parameter_0", "v1")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 4
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:ui-guard:0:1"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace ExplicitUIGuards
def guard_0 (values : List Bool) : Bool := values[0]!
def guardRecord_0 : String := "{\"constraint_ref\":\"open\",\"formal_constraint_id\":\"\",\"guard_id\":\"guard_close\",\"source_ref_ids\":[\"source\"]}"
example : guard_0 [false] = false := by decide
example : guard_0 [true] = true := by decide
def completeTruthTable : String := "[{\"enabled\":false,\"event_id\":\"close_event\",\"guard_id\":\"guard_close\",\"source_state\":\"open\",\"target_state\":\"closed\",\"transition_id\":\"close\",\"valuation_index\":0,\"values\":{\"allowed\":false}},{\"enabled\":true,\"event_id\":\"close_event\",\"guard_id\":\"guard_close\",\"source_state\":\"open\",\"target_state\":\"closed\",\"transition_id\":\"close\",\"valuation_index\":1,\"values\":{\"allowed\":true}}]"
def stateIdentityMap : String := "{\"closed\":\"state_0\",\"open\":\"state_1\"}"
def parameterIdentityMap : String := "{\"allowed\":\"var:ui-param:0\"}"
def reachableNonterminalDeadlocks : List String := []
example : action_0 ⟨"state_1", true⟩ ⟨"state_0", true⟩ := by simp [action_0, predicate_0, predicate_1]
-- A disabled original transition has no expanded native successor, for any target state.
example (t : State) : ¬ (action_0 ⟨"state_1", false⟩ t) := by simp [action_0, predicate_0, predicate_1]
end ExplicitUIGuards
end Projection_3

namespace Projection_4
structure State where
  v0 : String
  v1 : Bool
def typeOK (s : State) : Prop := (s.v0 ∈ ["state_0", "state_1"])
def predicate_0 (s : State) : Prop := (s.v0 = "state_1") ∧ (s.v1 = true)
def predicate_1 (s : State) : Prop := (s.v0 = "state_0")
def predicate_2 (s : State) : Prop := (s.v0 = "state_1") ∧ (s.v1 = true)
def initial (s : State) : Prop := typeOK s ∧ (predicate_2 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:ui-control", "var:ui-param:0"].contains variableName
example : ["var:ui-control", "var:ui-param:0"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_1 t) ∧ (t.v1 = s.v1)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:ui-guard:0:1" ∧ action_0 s t)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
def sourceVariableAliases : List (String × String) := [("var:ui-control", "v0"), ("ui_control", "v0"), ("var:ui-param:0", "v1"), ("ui_parameter_0", "v1")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 4
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:ui-guard:0:1"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace ExplicitUIGuards
def guard_0 (values : List Bool) : Bool := values[0]!
def guardRecord_0 : String := "{\"constraint_ref\":\"open\",\"formal_constraint_id\":\"\",\"guard_id\":\"guard_close\",\"source_ref_ids\":[\"source\"]}"
example : guard_0 [false] = false := by decide
example : guard_0 [true] = true := by decide
def completeTruthTable : String := "[{\"enabled\":false,\"event_id\":\"close_event\",\"guard_id\":\"guard_close\",\"source_state\":\"open\",\"target_state\":\"closed\",\"transition_id\":\"close\",\"valuation_index\":0,\"values\":{\"allowed\":false}},{\"enabled\":true,\"event_id\":\"close_event\",\"guard_id\":\"guard_close\",\"source_state\":\"open\",\"target_state\":\"closed\",\"transition_id\":\"close\",\"valuation_index\":1,\"values\":{\"allowed\":true}}]"
def stateIdentityMap : String := "{\"closed\":\"state_0\",\"open\":\"state_1\"}"
def parameterIdentityMap : String := "{\"allowed\":\"var:ui-param:0\"}"
def reachableNonterminalDeadlocks : List String := []
example : action_0 ⟨"state_1", true⟩ ⟨"state_0", true⟩ := by simp [action_0, predicate_0, predicate_1]
-- A disabled original transition has no expanded native successor, for any target state.
example (t : State) : ¬ (action_0 ⟨"state_1", false⟩ t) := by simp [action_0, predicate_0, predicate_1]
end ExplicitUIGuards
end Projection_4

end UIUXIR

