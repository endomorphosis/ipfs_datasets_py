"""Package all attempts; distinguish final validated producers from history."""
from collections import Counter
import hashlib,io,json,re,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('/home/barberb/lift_coding/external/ipfs_datasets');RUN=Path(__file__).resolve().parent
SOURCE=RUN/'validation-source-r3';OUT=ROOT/'docs/implementation/reports/evidence/ui-event-validation-resume-20261002'
DOCS=['docs/autoencoders/bounded_ui_event_validation_and_resume.md','docs/autoencoders/source_conditioning_fidelity_ablation.md']
def require(c,m):
 if not c:raise ValueError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def raw(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n')
initial=read(RUN/'native-r3/initial-summary.json');resumed=read(RUN/'native-r3/resume-summary.json');controlled=read(RUN/'controlled-r3/summary.json')
require(initial['native_lake_status_counts']=={'passed':9} and initial['live_job_count']==9,'final actual nine builds incomplete')
require(resumed['live_job_count']==0 and resumed['archived_job_count']==9,'archive incorrectly restored live authority')
require(len(initial['receipt']['rounds'])==len(resumed['receipt']['rounds'])==1,'clean batch should not repeat native work on restart')
for label,summary in [('initial',initial),('resumed',resumed)]:
 m=summary['receipt'];require(m['manifest_sha256']==hashlib.sha256(raw({k:v for k,v in m.items() if k!='manifest_sha256'})).hexdigest(),label+' returned seal differs')
require(resumed['receipt']==read(RUN/'native-r3/validation/manifest.json'),'returned/durable manifest differs')
require(controlled['native']['execution']['status']=='passed' and len(controlled['wrapper']['rounds'])==2,'actual contention recovery incomplete')
require(controlled['default_host_pressure_sampler_preserved'] and not controlled['limits_relaxed'],'controlled pressure checks changed')
first=read(RUN/'controlled-r3/validation/round-0000/result.json');second=read(RUN/'controlled-r3/validation/round-0001/result.json')
require(first['jobs'][0]['retryable_lease_timeout'] and first['jobs'][0]['receipt']['error_type']=='LeaseTimeoutError','actual acquired timeout absent')
require(second['jobs'][0]['receipt']['native']['execution']['status']=='passed','controlled actual Lake missing')
xml=ET.parse(RUN/'tests-r3.xml').getroot();suites=list(xml.iter('testsuite'));totals={k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']}
require(totals=={'tests':208,'failures':0,'errors':0,'skipped':0},'final tests incomplete')
owned=read(RUN/'candidate-files.json');frozen=read(RUN/'frozen-candidates-r3.json')
for name,digest in frozen.items():require(sha(ROOT/name)==sha(SOURCE/name)==digest,'changed frozen candidate '+name)
prepared=read(RUN/'native-r3/prepared-inputs.json');require(len(prepared['attempts'])==15,'missing fixture attempts')
rows=read(RUN/'native-r3/validation/round-0000/result.json')['jobs'];gates=read(RUN/'native-r3/initial-strict-gates.json')
require(len(gates)==9 and all(not x['strict_training_allowed'] for x in gates.values()),'partial target allowed strict training')
per_job=[]
for row in rows:
 n=row['receipt']['native'];require(n['status']=='partial' and n['execution']['command'][1]=='build','native scope changed')
 require(len(n['requested_families'])==40,'family request narrowed')
 per_job.append({'job_id':row['job_id'],'library':n['library'],'lake_status':n['execution']['status'],'native_status':n['status'],'requested_family_count':len(n['requested_families']),'all_requested_projections_passed':n['all_requested_projections_passed'],'projections':[{k:p.get(k) for k in ['projection_id','logic_family','parser_status','lake_status','reason','lowering']} for p in n['per_projection']]})
# Only final producer bytes are required in the publication tree. Historical
# attempts keep their own code below history/, not masquerading as final checks.
producers={};members={};origins={}
def add(path,name):
 p=Path(path);require(p.is_file() and not p.is_symlink(),'regular archive file required '+str(p))
 require(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe archive name')
 require(name not in members or sha(members[name])==sha(p),'archive collision '+name);members[name]=p

def producer(p,digest=None,scope='loaded'):
 p=Path(p);require(p.is_relative_to(SOURCE) and p.suffix=='.py','producer outside final export')
 name=p.relative_to(SOURCE).as_posix();actual=sha(p);require(digest is None or digest==actual,'producer hash mismatch '+name)
 require(name not in producers or producers[name]==actual,'producer identity mismatch '+name)
 producers[name]=actual;origins.setdefault(name,set()).add(scope);add(p,'source/'+name)

for namespace in ['native-r3/initial-loaded-modules.json','native-r3/resume-loaded-modules.json','controlled-r3/loaded-modules.json']:
 for name,item in read(RUN/namespace).items():
  require(name.startswith('ipfs_datasets_py'),'unexpected loaded namespace')
  producer(item['path'],item['sha256'],namespace)
for name in owned:producer(SOURCE/name,frozen[name],'owned_candidate')
for name in DOCS:add(ROOT/name,'source/'+name)
# Retain fixture dependencies and selected tests, including unchanged sources.
for name in read(RUN/'test-selection.json'):
 producer(SOURCE/name.split('::')[0],scope='selected_test')
producer(SOURCE/'tests/fixtures/logic/native_dcec_ui_v1/guard_cases.py',scope='fixture_dependency')
for directory in ['native','native-r2','native-r3','controlled','controlled-r3']:
 for p in sorted((RUN/directory).rglob('*')):
  if p.is_file() and p.name!='.lock':add(p,'validation/'+directory+'/'+p.relative_to(RUN/directory).as_posix())
for p in sorted(RUN.iterdir()):
 if p.is_file() and p.suffix in {'.py','.json','.xml','.log'} and not p.name.startswith('publication'):
  add(p,'validation/'+p.name)
for tag,snapshot in [('first-tests','validation-source-r1'),('first-native','validation-source'),('second-native','validation-source-r2')]:
 for name in owned:
  old=RUN/snapshot/name
  if old.exists() and sha(old)!=frozen[name]:add(old,'history/'+tag+'/'+name)
# Record exact selected tools, never add binaries/weights to source archive.
results={'schema':'bounded-ui-event-validation-results/v1','validated_code_base':read(RUN/'base.json')['base'],'candidate_sha256':frozen,'tests':totals,'native':{'initial':initial,'resume':resumed,'per_job':per_job,'controlled_recovery':{k:controlled[k] for k in ['scope','default_host_pressure_sampler_preserved','limits_relaxed','elapsed_seconds','max_rss_kib']},'controlled_rounds':2,'controlled_timeout_count':1,'controlled_actual_lake_passes':1,'final_version_actual_lake_passes':10,'all_native_builds_remain_partial':True,'strict_training_refusals':9,'negative_EC_preparation_blocks':6,'cold_model_inference_ran':False,'bridge_on_evaluation_ran':False,'bridge_names':[],'legal_ir_target_count':None,'cache_measurement':'no_model_or_legal_IR_metric_evaluation','global_workers':2,'cpu_slots_per_native_job':2,'memory_mb_per_native_job':1024,'native_step_timeout_seconds':60,'global_lease_wait_timeout_seconds':30,'controlled_lease_wait_timeout_seconds':.25},'historical_attempts_retained':True,'historical_findings':['one stale trace-id test setup fixed without weakening native epoch validation','driver JSON arrays versus tuples comparison fixed','returned resume manifest seal updated to match durable manifest'],'model_inference_executed':False,'training_executed':False,'weights_modified':False,'qualified':False,'admitted':False,'formalized':False,'source_semantics_verified':False,'fresh_holdout':False,'remaining_gaps':['missing full modality floors remain strict-training blockers','bounded UI EC does not establish timeout/release/concurrency semantics or event authenticity','source GRU composition fidelity still needs the predeclared conditioning ablation','learned action-head data still lacks right-hand requirements and repeated-operand combinations']}
OUT.mkdir(parents=True,exist_ok=False);dump(OUT/'results.json',results)
archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
 for name,p in sorted(members.items()):
  item=tf.gettarinfo(str(p),arcname=name);item.uid=item.gid=0;item.uname=item.gname='';item.mtime=0
  with p.open('rb') as stream:tf.addfile(item,stream)
metadata={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in sorted(members.items())}
manifest={'schema':'bounded-ui-event-evidence-manifest/v1','archive':{'path':'evidence.tar.gz','sha256':sha(archive),'bytes':archive.stat().st_size,'member_count':len(members)},'validated_producer_source_sha256':dict(sorted(producers.items())),'producer_origins':{k:sorted(v) for k,v in sorted(origins.items())},'members':metadata,'results_sha256':sha(OUT/'results.json'),'weights_included':False,'restores_live_authority':False}
dump(OUT/'manifest.json',manifest)
owned+=DOCS+[p.relative_to(ROOT).as_posix() for p in [OUT/'results.json',OUT/'manifest.json',archive]];dump(RUN/'owned-files.json',owned)
print(json.dumps({'files':len(owned),'producers':len(producers),'archive_bytes':archive.stat().st_size,'members':len(members)}))
