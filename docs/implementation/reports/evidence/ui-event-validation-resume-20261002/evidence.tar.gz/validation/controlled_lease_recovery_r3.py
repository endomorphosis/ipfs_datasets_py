"""Real scheduler contention + actual Lake; isolated stricter test capacity."""
import dataclasses,hashlib,importlib.util,json,os,sys,threading,time,resource
from pathlib import Path
RUN=Path(__file__).resolve().parent
SOURCE=RUN/'validation-source-r3'
sys.path.insert(0,str(SOURCE));sys.dont_write_bytecode=True
os.environ.update(PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',IPFS_DATASETS_PY_LAZY_INSTALL_ERGOAI='0',CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
from ipfs_datasets_py.logic.formalization.autoencoder import ui_source_contract_384_v5 as ui
from ipfs_datasets_py.logic.formalization.autoencoder import parallel_projection_checks_v3 as checks
from ipfs_datasets_py.logic.formalization.autoencoder import resumable_native_validation as durable
spec=importlib.util.spec_from_file_location('controller_ec_fixture',SOURCE/'tests/fixtures/logic/ui_bounded_event_v1/cases.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
row=fixture.cases()[1];prepared=ui.prepare_family_targets(row['source_text'],row['candidate'],**row['options'])
root=RUN/'controlled-r3';root.mkdir()
actual=checks.resources.get_global_resource_scheduler()
config=dataclasses.replace(actual.config,state_path=root/'scheduler.json',total_cpu_slots=2,total_memory_mb=min(4096,actual.config.total_memory_mb),total_child_process_slots=2,lane_reservations={})
assert config.proof_safety_enabled and config.proof_resource_sampler is actual.config.proof_resource_sampler
scheduler=checks.resources.GlobalResourceScheduler(config)
lease=scheduler.acquire(checks.resources.ResourceLane.TRAINER,cpu_slots=2,memory_mb=128,child_process_slots=2,timeout=15,request_id='controlled-resume-holder')
stop=threading.Event();observed=[]
def release_after_observed_timeout():
 p=root/'validation/round-0000/lease-events.jsonl'
 while not stop.wait(.02):
  if p.exists():
   try:events=[json.loads(line) for line in p.read_text().splitlines()]
   except json.JSONDecodeError:continue
   if any(e['phase']=='lease_wait_timeout' for e in events):
    observed.append({'action':'release_held_capacity_after_observed_timeout','events':events,'monotonic':time.monotonic()})
    lease.release();return
thread=threading.Thread(target=release_after_observed_timeout,daemon=True);thread.start()
started=time.perf_counter()
try:
 result=durable.run_resumable_native_validation([checks.NativeProjectionJob('controlled-ec',prepared['report'],prepared['source_inputs'])],owner=durable.NativeValidationOwner.from_module(checks),output_directory=root/'validation',scheduler=scheduler,max_attempts_per_job=3,max_admission_seconds=90,retry_backoff_seconds=.5,max_workers=1,native_memory_mb=1024,native_cpu_slots=2,native_child_process_slots=2,lease_wait_timeout_seconds=.25,native_step_timeout_seconds=60,lake_executable='/home/barberb/.elan/toolchains/leanprover--lean4---v4.30.0/bin/lake',java_executable='/home/barberb/.local/share/ipfs_datasets_py/theorem-provers/advisors/temurin-jdk/17.0.20+8/jdk/bin/java',tla2tools_jar='/home/barberb/.local/share/ipfs_datasets_py/theorem-provers/tlc/1.8.0/tla2tools.jar')
finally:
 stop.set();thread.join(2);lease.release()
assert observed and len(result['live_jobs'])==1 and result['receipt']['status']=='completed'
assert len(result['receipt']['rounds'])==2
native=result['live_jobs'][0]['native_execution'].to_dict()
assert native['execution']['status']=='passed' and all(p['lake_status']=='passed' for p in native['per_projection'])
probe=checks.validation.evaluate_projection_training_batch([result['live_jobs'][0]['observation']],domain_id='ui_ux_ir')
assert not probe['strict_training_allowed']
loaded={name:{'path':str(Path(module.__file__).resolve()),'sha256':hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()} for name,module in tuple(sys.modules.items()) if name.startswith('ipfs_datasets_py') and getattr(module,'__file__',None)}
summary={'scope':'controlled_real_scheduler_contention_with_actual_Lake_not_natural_host_pressure','controller_events':observed,'global_config':actual.config.persisted_dict(),'controlled_config':config.persisted_dict(),'default_host_pressure_sampler_preserved':True,'limits_relaxed':False,'source':str(SOURCE),'native':native,'training_gate':probe,'wrapper':result['receipt'],'elapsed_seconds':time.perf_counter()-started,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'training_executed':False,'model_inference_executed':False,'qualified':False,'admitted':False}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(root/'loaded-modules.json').write_text(json.dumps(loaded,indent=2)+'\n')
print(json.dumps({'rounds':len(result['receipt']['rounds']),'lake_status':native['execution']['status'],'elapsed_seconds':summary['elapsed_seconds']}),flush=True)
