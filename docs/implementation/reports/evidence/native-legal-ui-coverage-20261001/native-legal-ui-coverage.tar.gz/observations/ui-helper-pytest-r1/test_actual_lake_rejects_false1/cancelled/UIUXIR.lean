set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t

inductive UIConfirmationKind where
  | confirm | invoke | cancel
  deriving DecidableEq, Repr
structure UIConfirmationEvent (Entity : Type) where
  kind : UIConfirmationKind
  action : Entity
  request : Entity
  token : Entity
  tick : Nat
  deriving DecidableEq, Repr

def uiSameKey {Entity : Type} [DecidableEq Entity]
    (left right : UIConfirmationEvent Entity) : Bool :=
  decide (left.action = right.action ∧ left.request = right.request ∧ left.token = right.token)

def uiClockOrdered {Entity : Type} (events : List (UIConfirmationEvent Entity))
    (origin : Nat) : Bool :=
  events.zipIdx.all fun left => events.zipIdx.all fun right =>
    if origin ≤ left.2 ∧ left.2 ≤ right.2 then decide (left.1.tick ≤ right.1.tick) else true

def uiValidConfirmation {Entity : Type} [DecidableEq Entity]
    (events : List (UIConfirmationEvent Entity)) (origin position maxAge : Nat)
    (invocation : UIConfirmationEvent Entity) : Bool :=
  events.zipIdx.any fun confirmation =>
    decide (origin ≤ confirmation.2 ∧ confirmation.2 < position ∧
      confirmation.1.kind = .confirm ∧ confirmation.1.tick ≤ invocation.tick ∧
      invocation.tick ≤ confirmation.1.tick + maxAge) &&
    uiSameKey confirmation.1 invocation &&
    (events.zipIdx.all fun cancellation =>
      if confirmation.2 < cancellation.2 ∧ cancellation.2 < position ∧
          cancellation.1.kind = .cancel then !(uiSameKey cancellation.1 invocation) else true) &&
    (events.zipIdx.all fun prior =>
      if origin ≤ prior.2 ∧ prior.2 < position ∧ prior.1.kind = .invoke
      then !(uiSameKey prior.1 invocation) else true)

def uiObservedPolicy {Entity : Type} [DecidableEq Entity]
    (events : List (UIConfirmationEvent Entity)) (action : Entity) (maxAge origin : Nat) : Bool :=
  events.zipIdx.all fun occurrence =>
    if origin ≤ occurrence.2 ∧ occurrence.1.kind = .invoke ∧ occurrence.1.action = action
    then uiValidConfirmation events origin occurrence.2 maxAge occurrence.1 else true

def uiObservedViolation {Entity : Type} [DecidableEq Entity]
    (events : List (UIConfirmationEvent Entity)) (action : Entity) (maxAge origin : Nat) : Bool :=
  !(uiObservedPolicy events action maxAge origin)

-- A checked clock is required separately from the deontic policy. Neither
-- condition establishes event authenticity or facts about an unobserved future.
def uiPrefixWellFormed {Entity : Type} (events : List (UIConfirmationEvent Entity))
    (origin : Nat) : Prop := origin ≤ events.length ∧ uiClockOrdered events origin = true

def uiConfirmationFormula_0 {Entity Agent : Type} [DecidableEq Entity] (i : Interpretation Entity Agent) (events : List (UIConfirmationEvent Entity)) : Nat → Prop := i.modal "deontic:O" [] (some "UI-strength:strict") (fun origin => uiObservedPolicy events (i.constant "publish") 5 origin = true)
def uiConfirmationSources_0 : String := "[\"source:fixture\"]"
def uiConfirmationCheckedFormula_0 {Entity Agent : Type} [DecidableEq Entity] (i : Interpretation Entity Agent) (events : List (UIConfirmationEvent Entity)) (origin : Nat) : Prop := uiPrefixWellFormed events origin ∧ uiConfirmationFormula_0 i events origin
def uiConfirmationFormula_1 {Entity Agent : Type} [DecidableEq Entity] (i : Interpretation Entity Agent) (events : List (UIConfirmationEvent Entity)) : Nat → Prop := i.modal "deontic:F" [] (some "UI-strength:strict") (fun origin => uiObservedViolation events (i.constant "publish") 5 origin = true)
def uiConfirmationSources_1 : String := "[\"source:fixture\"]"
def uiConfirmationCheckedFormula_1 {Entity Agent : Type} [DecidableEq Entity] (i : Interpretation Entity Agent) (events : List (UIConfirmationEvent Entity)) (origin : Nat) : Prop := uiPrefixWellFormed events origin ∧ uiConfirmationFormula_1 i events origin
def uiConfirmationFormula_2 {Entity Agent : Type} [DecidableEq Entity] (i : Interpretation Entity Agent) (_events : List (UIConfirmationEvent Entity)) : Nat → Prop := i.modal "deontic:F" [] (some "UI-strength:strict") (fun t => i.atom "weaken_norm" [i.constant "publish"] t)
def uiConfirmationSources_2 : String := "[\"source:fixture\"]"
def uiConfirmationCheckedFormula_2 {Entity Agent : Type} [DecidableEq Entity] (i : Interpretation Entity Agent) (events : List (UIConfirmationEvent Entity)) (origin : Nat) : Prop := uiPrefixWellFormed events origin ∧ uiConfirmationFormula_2 i events origin
def toy : Interpretation String String where
  agent := id
  cognitive := fun _ _ body => body
  constant := id
  function := fun _ _ => "opaque"
  atom := fun _ _ _ => False
  modal := fun op _ _ body t => if op = "deontic:F" then ¬ body t else body t
  frame := fun _ _ _ => False
  frameScalar := fun _ _ => "opaque"
  member := fun _ _ => False
  subclass := fun _ _ => False
def event (kind : UIConfirmationKind) (request token : String) (tick : Nat) : UIConfirmationEvent String :=
  ⟨kind, "publish", request, token, tick⟩
def good := [event .confirm "r1" "t1" 1, event .invoke "r1" "t1" 6]
def stale := [event .confirm "r1" "t1" 1, event .invoke "r1" "t1" 7]
def cancelled := [event .confirm "r1" "t1" 1, event .cancel "r1" "t1" 2, event .invoke "r1" "t1" 3]
def renewed := [event .confirm "r1" "t1" 1, event .cancel "r1" "t1" 2,
  event .confirm "r1" "t1" 3, event .invoke "r1" "t1" 4]
def wrongRequest := [event .confirm "r1" "t1" 1, event .invoke "r2" "t1" 2]
def wrongToken := [event .confirm "r1" "t1" 1, event .invoke "r1" "t2" 2]
def wrongAction := [{(event .confirm "r1" "t1" 1) with action := "erase"}, event .invoke "r1" "t1" 2]
def reused := [event .confirm "r1" "t1" 1, event .invoke "r1" "t1" 2, event .invoke "r1" "t1" 2]
def reconfirmedReuse := [event .confirm "r1" "t1" 1, event .invoke "r1" "t1" 2,
  event .confirm "r1" "t1" 3, event .invoke "r1" "t1" 4]
def sameTick := [event .confirm "r1" "t1" 2, event .invoke "r1" "t1" 2]
def reversed := [event .invoke "r1" "t1" 2, event .confirm "r1" "t1" 2]
def foreignCancellation := [event .confirm "r1" "t1" 1, event .cancel "r2" "t1" 2,
  event .invoke "r1" "t1" 3]
def independentRequests := [event .confirm "r1" "t1" 1, event .invoke "r1" "t1" 2,
  event .confirm "r2" "t1" 3, event .invoke "r2" "t1" 4]
def badClock := [event .confirm "r1" "t1" 1, event .invoke "r1" "t1" 2,
  event .cancel "r2" "t1" 1]

example : uiConfirmationCheckedFormula_0 toy cancelled 0 := by decide
