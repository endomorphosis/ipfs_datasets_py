set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


def toy (p : String → Nat → Prop) : Interpretation Unit Unit where
  agent := fun _ => ()
  cognitive := fun _ _ body => body
  constant := fun _ => ()
  function := fun _ _ => ()
  atom := fun name _ t => p name t
  modal := fun _ _ _ body => body
  frame := fun _ _ _ => False
  frameScalar := fun _ _ => ()
  member := fun _ _ => False
  subclass := fun _ _ => False

namespace Deadline
def qualifiedLegalFormula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => (((fun t => i.atom "requested" [] t) t)) → (i.modal "deontic:O" [] (some "explicit-clock:day") (fun origin => ∃ u, origin ≤ u ∧ u ≤ origin + 10 ∧ (fun t => i.atom "submit" [i.constant "agency", i.constant "record"] t) u)) t)
def originalFormulaProvenance_0 : String := "{\"citation\":null,\"end_char\":59,\"source_id\":\"fixture:qualified\",\"start_char\":0}"
end Deadline
namespace Instant
def qualifiedLegalFormula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => (((fun t => i.atom "requested" [] t) t)) → (i.modal "deontic:O" [] (some "explicit-clock:instantaneous") (fun t => i.atom "retain" [i.constant "agency", i.constant "record"] t)) t)
def originalFormulaProvenance_0 : String := "{\"citation\":null,\"end_char\":59,\"source_id\":\"fixture:qualified\",\"start_char\":0}"
end Instant
namespace Waiver
def qualifiedLegalFormula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ((¬ (((fun t => i.atom "emergency" [] t) t)))) → (i.modal "deontic:O" [] (some "explicit-clock:day") (fun origin => ∀ u, origin ≤ u → u ≤ origin + 20 → (fun t => i.atom "retain" [i.constant "agency", i.constant "record"] t) u)) t)
def originalFormulaProvenance_0 : String := "{\"citation\":null,\"end_char\":59,\"source_id\":\"fixture:qualified\",\"start_char\":0}"
end Waiver
namespace Tick
def qualifiedLegalFormula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] (some "explicit-clock:day") (fun origin => ∀ u, origin ≤ u → u ≤ origin + 20 → (¬ (((fun t => i.atom "emergency" [] t) u)) → (fun t => i.atom "retain" [i.constant "agency", i.constant "record"] t) u)))
def originalFormulaProvenance_0 : String := "{\"citation\":null,\"end_char\":59,\"source_id\":\"fixture:qualified\",\"start_char\":0}"
end Tick
namespace Compound
def qualifiedLegalFormula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ((((fun t => i.atom "requested" [] t) t) ∧ (¬ ((fun t => i.atom "withdrawn" [] t) t)) ∧ (((fun t => i.atom "authorized" [] t) t) ∨ ((fun t => i.atom "urgent" [] t) t)))) → (i.modal "deontic:O" [] (some "explicit-clock:instantaneous") (fun t => i.atom "retain" [i.constant "agency", i.constant "record"] t)) t)
def originalFormulaProvenance_0 : String := "{\"citation\":null,\"end_char\":59,\"source_id\":\"fixture:qualified\",\"start_char\":0}"
end Compound

-- These are semantic scope checks under a transparent toy modal interpretation.
-- They assert no law, corpus translation, event or real-world compliance.
example : Deadline.qualifiedLegalFormula_0 (toy (fun name t => name = "requested" ∨ t = 10)) 0 := by
  intro _
  exact ⟨10, by decide, by decide, Or.inr rfl⟩
example : ¬ Deadline.qualifiedLegalFormula_0 (toy (fun name t => name = "requested" ∨ t = 11)) 0 := by
  intro h
  obtain ⟨u, _, upper, value⟩ := h (Or.inl rfl)
  have eq : u = 11 := by simpa [toy] using value
  subst u
  exact (by decide : ¬ (11 ≤ 0 + 10)) upper
example : Instant.qualifiedLegalFormula_0 (toy (fun _ _ => False)) 0 := by
  intro h
  exact False.elim h
example : ¬ Instant.qualifiedLegalFormula_0 (toy (fun name _ => name = "requested")) 0 := by
  intro h
  have impossible := h rfl
  exact (by decide : ¬ ("retain" = "requested")) impossible
example : Compound.qualifiedLegalFormula_0 (toy (fun name _ =>
    name = "requested" ∨ name = "urgent" ∨ name = "retain")) 0 := by
  simp [Compound.qualifiedLegalFormula_0, toy]
example : ¬ Compound.qualifiedLegalFormula_0 (toy (fun name _ =>
    name = "requested" ∨ name = "urgent")) 0 := by
  simp [Compound.qualifiedLegalFormula_0, toy]
-- An emergency only at tick 5 exempts that tick, not the whole interval.
example : Tick.qualifiedLegalFormula_0 (toy (fun name t =>
    (name = "emergency" ∧ t = 5) ∨ (name = "retain" ∧ t ≠ 5))) 0 := by
  intro u _ _ noEmergency
  apply Or.inr
  refine ⟨rfl, ?_⟩
  intro eq
  exact noEmergency (Or.inl ⟨rfl, eq⟩)
example : ¬ Waiver.qualifiedLegalFormula_0 (toy (fun name t =>
    (name = "emergency" ∧ t = 5) ∨ (name = "retain" ∧ t ≠ 5))) 0 := by
  intro h
  have noEmergency : ¬ (("emergency" = "emergency" ∧ 0 = 5) ∨ ("emergency" = "retain" ∧ 0 ≠ 5)) := by decide
  have value := h noEmergency 5 (by decide) (by decide)
  simpa [toy] using value
-- Conversely activation waiver can waive the full body, unlike per-tick exemption.
example : Waiver.qualifiedLegalFormula_0 (toy (fun name t => name = "emergency" ∧ t = 0)) 0 := by
  intro h
  exact False.elim (h ⟨rfl, rfl⟩)
example : ¬ Tick.qualifiedLegalFormula_0 (toy (fun name t => name = "emergency" ∧ t = 0)) 0 := by
  intro h
  have value := h 1 (by decide) (by decide) (by simp [toy])
  simpa [toy] using value
