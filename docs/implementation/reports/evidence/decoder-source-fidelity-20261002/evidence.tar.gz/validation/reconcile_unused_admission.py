"""One explicit, never-launched failed admission; not a production recovery API."""
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import time

if not __debug__:
    raise RuntimeError('optimized Python is forbidden for this explicit closeout')

RUN = Path(__file__).resolve().parent
PACKAGE = RUN.parents[2]
SOURCE = PACKAGE/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
sys.path.insert(0, str(SOURCE)); sys.dont_write_bytecode = True
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_daemon_resources as resources
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import resource_scheduler as scheduler
from ipfs_datasets_py.optimizers.logic_theorem_optimizer import autoencoder_resource_recovery as recovery

RESERVATION = '038f1c4e1d96456cabee0a01fa1be6c0'
OWNER_PID = 39412
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source_pins = {x['path']: x['sha256'] for x in read(PACKAGE/'workspace/test-logs/ui-modal-coverage-20261002/source-manifest.json')['files']}
for module in (resources, scheduler, recovery):
    path = Path(module.__file__).resolve()
    assert path.is_relative_to(SOURCE)
    assert sha(path) == source_pins[str(path.relative_to(SOURCE))]
ledger_path = PACKAGE/'workspace/test-logs/federal-corpus-audits/owned-daemon-resource-control/disk-reservations.json'
initial = read(ledger_path)
record = initial['reservations'][RESERVATION]
expected_sha = recovery._digest(record)
assert record['owner_pid'] == OWNER_PID and record['status'] == 'retained'
assert record['retention_reason'] == 'scheduler_admission_failed'
assert record['storage_bytes'] == 100_000_000
assert record['attempt_directory'] is None and record['child'] is None
assert record['prior_children'] == [] and record['external_charges'] == {}
assert not (RUN/'smoke-r1').exists(), 'original admission never created an attempt'
assert 'LeaseTimeoutError: timed out waiting for a resource lease' in (RUN/'guardian.log').read_text()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2); stream.write('\n')
        stream.flush(); os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)

def stopped():
    assert resources._process(OWNER_PID) is None, 'any PID reuse blocks this closeout'
    state = read(scheduler.default_scheduler_state_path())
    for field in ('leases', 'waiters'):
        assert not any(v.get('owner_pid') == OWNER_PID or v.get('request_id') == 'daemon:'+RESERVATION
                       for v in state[field].values()), 'outstanding scheduler authority remains'

artifacts = {}
for name in ('guardian.log', 'run_reserved_r1.py', 'manifest.json', 'plan-r2.json'):
    path = RUN/name
    with path.open('rb') as stream: os.fsync(stream.fileno())
    artifacts[name] = dict(sha256=sha(path), bytes=path.stat().st_size)
plan = dict(schema='explicit-unused-admission-reconciliation-plan/v1', reservation_id=RESERVATION,
    owner_pid=OWNER_PID, expected_record_sha256=expected_sha, original_record=record,
    artifacts=artifacts, child_ever_started=False, original_attempt_directory_bound=False,
    outputs_deleted=False, no_automatic_expiry=True, scope='only this known never-launched admission')
save(RUN/'unused-admission-plan.json', plan)
helper = resources.DaemonResourceReservation(ledger_path, roots=[x['path'] for x in initial['roots']],
    storage_bytes=1, memory_mb=1, ledger_lock_timeout_seconds=60)
with helper._locked():
    current = helper._read()
    save(RUN/'unused-admission-ledger-before.json', current)
    row = current['reservations'][RESERVATION]
    assert recovery._digest(row) == expected_sha
    assert current['limit_bytes'] == initial['limit_bytes'] == 140_000_000_000
    stopped()
    before_other = recovery._digest({k:v for k,v in current['reservations'].items() if k != RESERVATION})
    accounting = helper._account(current)
    stopped()
    assert all(sha(RUN/name)==value['sha256'] for name,value in artifacts.items())
    final = copy.deepcopy(accounting)
    final['outstanding_full_reservations_bytes'] -= row['storage_bytes']
    final['charged_bytes'] -= row['storage_bytes']
    receipt = dict(schema='explicit-unused-admission-reconciliation/v1', **{k:v for k,v in plan.items() if k != 'schema'},
        full_claim_accounting=accounting, final_accounting=final, other_reservations_sha256=before_other,
        released_at=time.time(), process_absent_before_and_after_census=True,
        scheduler_authority_absent_before_and_after_census=True, original_owner_birth_not_recorded=True,
        refusal_on_any_pid_reuse=True, production_recovery_api_modified=False,
        evidence_artifacts_remain_charged_as_observed_files=True)
    save(RUN/'unused-admission-receipt.json', receipt)
    row.update(status='released', released_at=receipt['released_at'], artifacts_durable_asserted=True,
        final_accounting=final, explicit_unused_admission_reconciliation=receipt)
    assert recovery._digest({k:v for k,v in current['reservations'].items() if k != RESERVATION}) == before_other
    helper._write(current)
    after = helper._read()
    save(RUN/'unused-admission-ledger-after.json', after)
    assert after['reservations'][RESERVATION]['status']=='released'
    assert recovery._digest({k:v for k,v in after['reservations'].items() if k != RESERVATION})==before_other
print(json.dumps(dict(reservation_id=RESERVATION, released=True, other_reservations_unchanged=True, outputs_deleted=False)))
