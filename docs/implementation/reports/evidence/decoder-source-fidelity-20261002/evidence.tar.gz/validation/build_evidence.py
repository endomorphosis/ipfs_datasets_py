import gzip, hashlib, io, json, tarfile
from pathlib import Path
P=Path('/home/barberb/lift_coding/external/ipfs_datasets')
R=P/'workspace/test-logs/decoder-source-fidelity-20261002'
E=P/'docs/implementation/reports/evidence/decoder-source-fidelity-20261002'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
false=dict(qualified=False,admitted=False,proof_authority=False,source_semantics_verified=False,
    convergence_proven=False,fresh_holdout=False,lake_executed=False,formalized=False,roundtrip_ok=False,
    checkpoint_promoted=False)
code=read(R/'code-files.json');manifest=read(R/'manifest-r3.json');data=read(R/'smoke-r3/results/summary.json')
assert data['complete'] and len(data['runs'])==8
assert sha(R/'independent-audit.json')=='d7458c01a6828a5b98c1896047eeefc7006e3cbf87d60792a3ff3debdd76b60b'
assert all(sha(P/rel)==digest for rel,digest in manifest['extensions'].items())
# Retain a deterministic first input from each clause-count bin for each arm.
corpus=read(Path(manifest['paragraphs']));vocab=corpus['codec']['target_vocabulary']
chosen=[next(row for row in corpus['validation'] if row['clause_count']==n) for n in [1,2,4,8]]
samples=[];arms=[]
for entry in data['runs']:
 t=entry['training']; folder=R/'smoke-r3/results'/entry['arm'];last={x['id']:x for x in read(folder/'last-complete-attempt-predictions.json')}
 for row in chosen:
  prediction=last[row['id']];text=''.join(vocab[x] for x in prediction['token_ids'])
  try: document=json.loads(text)
  except ValueError:document=None
  samples.append(dict(arm=entry['arm'],id=row['id'],clause_count=row['clause_count'],source_text=row['source_text'],
   expected_target=row['target'],last_attempt_output_text=text,last_attempt_parsed_document=document,
   generation_status=prediction['generation_status'],selected=False,**false))
 arms.append(dict(arm=entry['arm'],architecture=entry['architecture'],loss=entry['strategy'],seed=entry['seed'],
  optimizer_steps=t['optimizer_steps'],valid_target_token_presentations=t['valid_target_token_presentations'],
  row_presentations=t['row_presentations'],trainable_parameter_count=entry['trainable_parameter_count'],
  elapsed_seconds=t['elapsed_seconds'],selected_epoch=t['selected_epoch'],selected=t['selected'],last_attempt=t['last_complete_attempt'],
  selected_evaluate_wall_seconds_per_span=entry['postfit']['validation']['numerical']['wall_seconds_per_span']))
(R/'sampled-outputs.json').write_text(json.dumps(dict(selection='first archived validation row in each clause-count bin, all8arms',rows=samples,**false),indent=2)+'\n')
E.mkdir(parents=True,exist_ok=True)
files={}
for rel in set(code)|set(manifest['extensions']):files['source/'+rel]=P/rel
# Successful, failed, and administrative evidence; exclude indexes/caches and this archive.
for path in R.iterdir():
 if path.is_file() and path.suffix in ('.json','.log','.xml','.py') and path.name not in ('publication.json',):
  files['validation/'+path.name]=path
for name in ['smoke-r2','smoke-r3','experiment-source','experiment-source-r3']:
 for path in (R/name).rglob('*'):
  if path.is_file():files['validation/'+str(path.relative_to(R))]=path
for key in ['donor','paragraphs','embeddings','curriculum','curriculum_inputs']:
 path=Path(manifest[key]);assert sha(path)==manifest['inputs'][str(path)]
 files['inputs/'+key+'/'+path.name]=path
members={}
archive=E/'evidence.tar.gz'
with archive.open('xb') as target:
 with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as bundle:
   for name,path in sorted(files.items()):
    content=path.read_bytes();members[name]=dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
    info=tarfile.TarInfo(name);info.size=len(content);info.mtime=0;info.mode=0o644
    bundle.addfile(info,io.BytesIO(content))
producers={key.split(':',1)[1]:digest for key,digest in data['source_dependencies'].items()}
producers.update(manifest['extensions'])
archive_info=dict(sha256=sha(archive),bytes=archive.stat().st_size)
archive_manifest=dict(schema='source-fidelity-evidence-archive/v1',archive=archive_info,members=members,
 validated_producer_source_sha256=producers,**false)
(E/'manifest.json').write_text(json.dumps(archive_manifest,indent=2)+'\n')
resources=read(R/'smoke-r3/resources-final.json')['record'];guardian=read(R/'guardian-r3.log')
results=dict(schema='decoder-source-fidelity-results/v1',scope='exposed authored Legal development only',
 complete=True,dimensions_actually_trained=[384],historical_8d_teacher_modified=False,
 actual_768d_training_performed=False,training_rows=48,validation_rows=48,clauses_per_paragraph=[1,2,4,8],
 source_token_range=[9,72],target_token_lengths=[40,73,139,271],encoder_context_tokens=512,decoder_output_limit=512,
 numerical_fit_arms=arms,selected_quality_gain=False,selected_checkpoint_epochs=[0]*8,
 final_attempt_exact_paragraphs=[0]*8,selected_validation_exact_paragraphs=[0]*8,
 original_donor_sha256=manifest['inputs'][manifest['donor']],
 frozen_experiment_manifest_sha256=sha(R/'manifest-r3.json'),plan_sha256=sha(R/'plan-r2.json'),
 candidate_sha256={rel:sha(P/rel) for rel in code},
 independent_audit_sha256=sha(R/'independent-audit.json'),independent_audit_checks=19724,independent_audit_findings=0,
 tests=dict(passed=293,failed=0,junit_sha256=sha(R/'tests-r3.xml')),
 telemetry=dict(device='cpu',workers=1,bridge_names=[],legal_ir_evaluate_provers=False,
  legal_ir_bridge_evaluation_performed=False,metric_disk_cache_used=False,paragraph_embedding_cache_used=True,
  encoder_executed=False,use_sample_memory=False,unique_validation_samples=48,
  fit_seconds_total=sum(x['training']['elapsed_seconds'] for x in data['runs']),
  child_cycle_seconds=read(R/'smoke-r3/child-exit.json')['elapsed_seconds'],
  guardian_total_seconds=guardian['elapsed_seconds'],owned_output_bytes=resources['final_attempt_bytes'],
  reservation_bytes=100000000,reservation_released=resources['status']=='released',storage_cap_unchanged=True,
  observed_peak_child_rss_bytes=max(x['group_rss']['rss_bytes'] for x in read(R/'smoke-r3/resource-observations.json')),
  wall_seconds_per_span_scope='selected initializer evaluation incl teacherforcedCE+greedygeneration+copy/integrity'),
 operational_failures_preserved=['five-process-slot admission timedout without model execution; exact unused claim reconciled',
  'postfit training.json collision after first fit; disjoint evaluation paths and same-recipe retry; owned claim reconciled'],
 limitations=['All selected checkpoints are initial weights; negative controls do not characterize trained source adapters',
  'Authored/exposed paragraphs, no fresh holdout or natural-statute benchmark',
  'Empty conditions/exceptions/temporal fields do not test nonempty qualifier semantics',
  'No new family projections or native/Lake admission',
  'Only384actualtraining;8Dlinguisticteacherpreserved;768localinputprerequisitesmissing',
  'No trained candidate promoted; lower teacherforcedCE does not establish longer-span fidelity'],
 archive=archive_info,**false)
(E/'results.json').write_text(json.dumps(results,indent=2)+'\n')
owned=code+[str((E/name).relative_to(P)) for name in ['results.json','manifest.json','evidence.tar.gz']]
(R/'owned-files.json').write_text(json.dumps(owned,indent=2)+'\n')
print(json.dumps(dict(archive=archive_info,archive_members=len(members),source_files=len(code),owned_files=len(owned))))
