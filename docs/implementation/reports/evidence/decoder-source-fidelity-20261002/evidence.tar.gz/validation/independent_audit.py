"""Read persisted records only; never import a numerical or native owner."""
from collections import Counter
from pathlib import Path
import datetime,hashlib,json,math,re,struct,sys,importlib.util,subprocess,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
ROOT=Path('/home/barberb/lift_coding/external/ipfs_datasets')
RUN=ROOT/'workspace/test-logs/decoder-source-fidelity-20261002'
ATTEMPT=RUN/(sys.argv[1] if len(sys.argv)>1 else 'smoke-r3')
RESULT=ATTEMPT/'results'
checks=[];findings=[];artifacts={}
def raw(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(raw(v)).hexdigest()
def read(p):
 p=Path(p);v=json.loads(p.read_bytes());artifacts[str(p)]=dict(sha256=sha(p),bytes=p.stat().st_size);return v
def check(ok,label):
 checks.append(dict(check=label,passed=bool(ok)))
 if not ok:findings.append(dict(priority='blocking',finding=label))
def shape(v):
 if not isinstance(v,list):return []
 s=shape(v[0]) if v else []
 if any(shape(x)!=s for x in v):raise ValueError('ragged saved tensor')
 return [len(v)]+s
def flat(v):
 if isinstance(v,list):
  for x in v:yield from flat(x)
 else:yield float(v)
def tensor_bytes(v):return b''.join(struct.pack('<f',x) for x in flat(v))
def tensor_sha(state):
 h=hashlib.sha256()
 for name,v in sorted(state.items()):h.update(raw([name,'torch.float32',shape(v)]));h.update(tensor_bytes(v))
 return h.hexdigest()
FACETS=('modality','actor','action','object','conditions','exceptions','temporal')
MAXIMIZE=('ordered_exact','all_rules_preserved','eos_count','syntax_valid')
MINIMIZE=('whole_rules_missing','whole_rules_extra','invalid_rule_count','invalid_rows','unscorable_generation_rows','prediction_missing_rows')
def nonregress(c,b):
 reasons=[];progress=False
 for length,part in c['by_length'].items():
  old=b['by_length'][length]
  for name in ('rows','expected_rules'):
   if part['metrics'][name]!=old['metrics'][name]:reasons.append('denominator')
  for name in MAXIMIZE+MINIMIZE:
   x,y=part['metrics'][name],old['metrics'][name]
   if (x<y if name in MAXIMIZE else x>y):reasons.append(length+'/'+name)
   if (x>y if name in MAXIMIZE else x<y):progress=True
  for field in FACETS:
   x,y=part['by_facet'][field],old['by_facet'][field]
   if x['total']!=y['total'] or x['correct']<y['correct']:reasons.append(length+'/'+field)
   progress|=x['correct']>y['correct']
 return not reasons,progress,reasons

def audit_fidelity(doc, refs, predictions, codec, label):
 check(doc['report_sha256']==digest({k:v for k,v in doc.items() if k!='report_sha256'}),label+'/full_report_hash')
 byid={r['id']:r for r in refs};pred={r['id']:r for r in predictions}
 check(len(doc['rows'])==len(refs)==len(predictions) and set(pred)==set(byid),label+'/complete_ids')
 countnames=tuple(doc['metrics']);sums={k:0 for k in countnames};lengths={};facets={f:dict(correct=0,total=0,unordered_correct=0) for f in FACETS}
 for r in doc['rows']:
  ref=byid[r['id']];prediction=pred[r['id']];gold=ref['target']['rules'];actual=r['generated_ir']
  check(r['expected_ir']==ref['target'] and r['target_sha256']==digest(ref['target']),label+'/'+r['id']+'/reference_identity')
  check(r['generated_token_ids']==prediction['token_ids'],label+'/'+r['id']+'/prediction_tokens')
  if actual is not None:
   check(json.loads(''.join(codec['target_vocabulary'][i] for i in prediction['token_ids']))==actual,label+'/'+r['id']+'/parsed_model_output')
  # Independent arithmetic conditional on the recorded canonical-validity decisions;
  # this audit does not create a second semantic/parser/native validation authority.
  generated=actual['rules'] if isinstance(actual,dict) and set(actual)=={'rules'} and isinstance(actual['rules'],list) else []
  bad={int(m.group(1)) for e in r['errors'] for m in [re.match(r'rule\[(\d+)\]:',e)] if m}
  valid={i:rule for i,rule in enumerate(generated) if i not in bad}
  expected=Counter(raw(rule) for rule in gold);observed=Counter(raw(rule) for rule in valid.values());matched=sum((expected&observed).values())
  check(r['counts']['whole_rules_missing']==len(gold)-matched and r['counts']['whole_rules_extra']==len(generated)-matched,label+'/'+r['id']+'/multiplicity')
  check(bool(r['counts']['ordered_exact'])==(prediction['eos_reached'] and not r['errors'] and actual==ref['target']),label+'/'+r['id']+'/ordered_exact')
  for field in FACETS:
   correct=sum(i in valid and valid[i][field]==rule[field] for i,rule in enumerate(gold))
   unordered=sum((Counter(raw(rule[field]) for rule in gold)&Counter(raw(rule[field]) for rule in valid.values())).values())
   expectedfield=dict(correct=correct,total=len(gold),unordered_correct=unordered)
   check(r['by_facet'][field]==expectedfield,label+'/'+r['id']+'/'+field)
  length=str(ref['clause_count']);bucket=lengths.setdefault(length,dict(metrics={k:0 for k in countnames},by_facet={f:dict(correct=0,total=0,unordered_correct=0) for f in FACETS}))
  for key in countnames:sums[key]+=r['counts'][key];bucket['metrics'][key]+=r['counts'][key]
  for field in FACETS:
   for key in facets[field]:facets[field][key]+=r['by_facet'][field][key];bucket['by_facet'][field][key]+=r['by_facet'][field][key]
 check(sums==doc['metrics'] and lengths==doc['by_length'] and facets==doc['by_facet'],label+'/aggregates')
 check(all(doc[k] is False for k in ('qualified','admitted','proof_authority','source_semantics_verified','lake_executed','native_validation_executed','model_executed','control_execution_verified','fresh_holdout','convergence_proven')),label+'/no_authority')

if not (ATTEMPT/'command.json').exists():
 print('WAITING_FOR_ATTEMPT');sys.exit(3)
command=read(ATTEMPT/'command.json');cmd=command['command']
manifest_path=Path(cmd[cmd.index('--manifest')+1]);plan_path=Path(cmd[cmd.index('--plan')+1]);extension=Path(cmd[cmd.index('--extension-root')+1])
manifest=read(manifest_path);plan=read(plan_path)
check(sha(plan_path)==manifest['plan_sha256'],'sealed_recipe_hash')
for p,h in manifest['extensions'].items():check(sha(extension/p)==h,'frozen_extension/'+p)
for p,h in manifest['inputs'].items():check(sha(p)==h,'sealed_input/'+p)
if not (RESULT/'summary.json').exists() or not (ATTEMPT/'resources-final.json').exists():
 print('WAITING_FOR_COMPLETE_SUMMARY_AND_RESOURCE_RELEASE');sys.exit(3)
summary=read(RESULT/'summary.json');resources=read(ATTEMPT/'resources-final.json');command=read(ATTEMPT/'command.json')
old_recipe=read(RUN/'smoke-r2/results/sealed-recipe.json')
changed_extensions=[p for p,h in manifest['extensions'].items() if old_recipe['manifest']['extensions'].get(p)!=h]
check(changed_extensions==['scripts/ops/autoencoder/benchmark_decoder_source_fidelity.py'],'retry_changed_driver_only')
check(old_recipe['plan']==plan and old_recipe['manifest']['inputs']==manifest['inputs'],'retry_recipe_and_all_inputs_unchanged')
unused=read(RUN/'unused-admission-receipt.json');unusedbefore=read(RUN/'unused-admission-ledger-before.json');unusedafter=read(RUN/'unused-admission-ledger-after.json');unusedid=unused['reservation_id']
ufb={k:v for k,v in unusedbefore['reservations'].items() if k!=unusedid};ufa={k:v for k,v in unusedafter['reservations'].items() if k!=unusedid}
check(ufb==ufa and hashlib.sha256(json.dumps(ufb,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()).hexdigest()==unused['other_reservations_sha256'],'unused_admission_all_foreign_reservations_unchanged')
urow=unusedbefore['reservations'][unusedid]
check(urow['status']=='retained' and urow['retention_reason']=='scheduler_admission_failed' and urow['attempt_directory'] is None and urow['child'] is None and urow['prior_children']==[] and urow['external_charges']=={} and unusedafter['reservations'][unusedid]['status']=='released','unused_admission_exact_never_started_row_released')
check(not (RUN/'smoke-r1').exists() and unused['refusal_on_any_pid_reuse'] and unused['production_recovery_api_modified'] is False,'unused_admission_scope_no_production_policy_change')
check(unused['full_claim_accounting']['charged_bytes']-unused['final_accounting']['charged_bytes']==100000000 and unusedbefore['limit_bytes']==unusedafter['limit_bytes']==140000000000,'unused_admission_only_claim_removed_cap_unchanged')
for name,item in unused['artifacts'].items():check(sha(RUN/name)==item['sha256'],'unused_admission_preserved_artifact/'+name)
artifacts[str(RUN/'reconcile_unused_admission.py')]=dict(sha256=sha(RUN/'reconcile_unused_admission.py'),bytes=(RUN/'reconcile_unused_admission.py').stat().st_size)

failed=read(RUN/'smoke-r2/failure.json');failed_exit=read(RUN/'smoke-r2/child-exit.json')
check(failed_exit['returncode']==1 and failed['cleanup']['leader_reaped'] is True and failed['cleanup']['live_group_processes']==0,'failed_r2_child_reaped_and_no_live_group')
check('FileExistsError' in (RUN/'smoke-r2/child.log').read_text() and not (RUN/'smoke-r2/results/summary.json').exists(),'failed_r2_serialization_error_preserved_not_complete')
recovery=read(RUN/'recovery-smoke-r2.json');ledgerbefore=read(RUN/'recovery-smoke-r2-ledger-before.json');ledgerafter=read(RUN/'recovery-smoke-r2-ledger-after.json')
recoveryid=recovery['reservation_id'];foreignbefore={k:v for k,v in ledgerbefore['reservations'].items() if k!=recoveryid};foreignafter={k:v for k,v in ledgerafter['reservations'].items() if k!=recoveryid}
check(foreignbefore==foreignafter and hashlib.sha256(json.dumps(foreignbefore,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()).hexdigest()==recovery['other_reservations_sha256'],'r2_recovery_all_foreign_rows_unchanged')
check(ledgerbefore['reservations'][recoveryid]['status']=='retained' and ledgerafter['reservations'][recoveryid]['status']=='released','r2_recovery_only_owned_status')
for item in recovery['artifacts']:check(sha(RUN/'smoke-r2'/item['path'])==item['sha256'],'r2_preserved_failure_artifact/'+item['path'])

childexit=read(ATTEMPT/'child-exit.json');check(childexit['returncode']==0 and childexit['leader_reaped'] is True,'child_exit_and_reaped')
check(resources['status']=='released' and resources['record']['status']=='released' and resources['resource_lease']['released'] is True,'resource_claim_and_lease_released')
check(resources['record']['artifacts_durable_asserted'] is True and resources['record']['final_total_charged_bytes']<=resources['record']['storage_bytes'],'artifacts_durable_and_within_claim')
check(resources['storage_limit_bytes']==140000000000,'storage_cap_not_raised')
cmd=command['command'];dependency=Path(cmd[cmd.index('--dependency-root')+1]);extension=Path(cmd[cmd.index('--extension-root')+1])
for key,h in summary['source_dependencies'].items():
 scope,relative=key.split(':',1);check(sha((dependency if scope=='dependency' else extension)/relative)==h,'loaded_producer/'+key)
corpus=read(manifest['paragraphs']);embeddings=read(manifest['embeddings']);curr=read(manifest['curriculum']);donor=read(manifest['donor'])
archive_binding=read(RUN/'prior-input-archive-binding.json');prior_commit=subprocess.check_output(['git','rev-parse','origin/main'],cwd=ROOT,text=True).strip()
prior_manifest_path='docs/implementation/reports/evidence/decoder-source-curriculum-20261002/manifest.json'
prior_manifest_raw=subprocess.check_output(['git','show',prior_commit+':'+prior_manifest_path],cwd=ROOT);prior_manifest=json.loads(prior_manifest_raw)
check(hashlib.sha256(prior_manifest_raw).hexdigest()==archive_binding['prior_archive_manifest_sha256'],'published_prior_archive_manifest_hash')
for key,entry in archive_binding['checks'].items():
 check(prior_manifest['members'][entry['prior_archive_member']]==dict(bytes=entry['bytes'],sha256=entry['sha256']) and sha(manifest[key])==entry['sha256'],'published_prior_input/'+key)
check(prior_manifest['members']['inputs/original-source384-donor.json']['sha256']==sha(manifest['donor']),'published_prior_donor_hash')

train={r['id']:r for r in corpus['train']};vectors={r['input_id']:r['vector'] for r in embeddings['rows']}
steps=tokens=presentations=0;previous=set();stages=[]
for stage in curr['stages']:
 now=set(stage['training_ids'])
 if now and now!=previous:
  e=plan['epochs_per_source_stage'];n=len(now);step=e*math.ceil(n/plan['batch_size']);token=e*sum(len(train[i]['target_ids'])-1 for i in now)
  stages.append(dict(stage=stage['stage_id'],rows=n,epochs=e,steps=step,tokens=token));steps+=step;tokens+=token;presentations+=e*n;previous=now
check(steps==340 and tokens==225840,'independent_expected_work_arithmetic')
check(len(summary['runs'])==8,'eight_registered_fits')
expectedarms=[f'{architecture}-{loss}-{seed}' for seed in plan['seed_order'] for architecture in plan['architecture_arms'] for loss in plan['loss_arms']]
check([r['arm'] for r in summary['runs']]==expectedarms,'exact_arm_order')
arm_results=[];initialhashes=set();capacities=set();acceptedtotal=0
spec=importlib.util.spec_from_file_location('audit_fidelity_replay',extension/'ipfs_datasets_py/logic/formalization/autoencoder/decoder_source_fidelity.py');fidelity=importlib.util.module_from_spec(spec);spec.loader.exec_module(fidelity)
def bounded_legal_shape(document):
 rule=document['rules'][0]
 valid=type(rule) is dict and set(rule)==set(FACETS)
 if valid:
  valid=rule['modality'] in ('O','P','F') and all(type(rule[k]) is str and len(rule[k])<=4096 for k in FACETS[:4]) and bool(rule['actor'].strip()) and bool(rule['action'].strip())
 if valid:
  valid=all(type(rule[k]) is list and len(rule[k])<=4 and all(type(v) is str and 0<len(v.strip()) and len(v)<=4096 for v in rule[k]) and rule[k]==sorted(set(rule[k])) for k in FACETS[4:])
 return {'valid':bool(valid)}

for run in summary['runs']:
 name=run['arm'];folder=RESULT/name;report=read(folder/'training.json');saved=read(folder/'private-state.json');predictions=read(folder/'selected-predictions.json');lastpredictions=read(folder/'last-complete-attempt-predictions.json')
 check(report==run['training'],name+'/summary_training_identity')
 check(report['optimizer_steps']==steps and report['valid_target_token_presentations']==tokens and report['row_presentations']==presentations,name+'/work_budget')
 initialhashes.add(report['initial_weights_sha256']);capacities.add(run['trainable_parameter_count'])
 check(report['optimizer_instance_count']==1 and report['optimizer_reinitialized_between_stages'] is False,name+'/single_continuous_optimizer')
 for a,b in zip(report['stage_reports'],report['stage_reports'][1:]):check(a['optimizer_state_end']==b['optimizer_state_start'] and a['optimizer_step_end']==b['optimizer_step_start'],name+'/stage_continuity/'+b['name'])
 previous=report['baseline'];selectedepoch=0;accepted=0
 for history in report['history']:
  if history['source_fidelity'] is not None:
   cand=history['source_fidelity'];allowed0,_,_=nonregress(cand,report['baseline']['fidelity']);allowed1,progress1,_=nonregress(cand,previous['fidelity'])
   bound=report['baseline']['numerical']['reconstructed_input_mse']*(1+report['config']['reconstruction_relative_tolerance'])+report['config']['reconstruction_absolute_tolerance']
   eligible=allowed0 and allowed1 and history['numerical']['reconstructed_input_mse']<=bound and (progress1 or history['numerical']['token_cross_entropy']<previous['numerical']['token_cross_entropy'])
   check(history['accepted']==eligible or (not history['accepted'] and 'deadline_before_selection_commit' in history['rejection_reasons']),name+'/selection_decision/'+str(history['epoch']))
  if history['accepted']:
   candidate=history['source_fidelity'];g1,_,_=nonregress(candidate,report['baseline']['fidelity']);g2,progress,_=nonregress(candidate,previous['fidelity'])
   msebound=report['baseline']['numerical']['reconstructed_input_mse']*(1+report['config']['reconstruction_relative_tolerance'])+report['config']['reconstruction_absolute_tolerance']
   check(g1 and g2 and history['numerical']['reconstructed_input_mse']<=msebound and (progress or history['numerical']['token_cross_entropy']<previous['numerical']['token_cross_entropy']) and not history['rejection_reasons'] and history['complete_epoch'],name+'/accepted_epoch/'+str(history['epoch']))
   previous=dict(numerical=history['numerical'],fidelity=candidate);selectedepoch=history['epoch'];accepted+=1
  check(history['selected_epoch']==selectedepoch,name+'/selected_epoch_history/'+str(history['epoch']))
 check(previous==report['selected'] and selectedepoch==report['selected_epoch'],name+'/selected_receipt_matches_history')
 last_replay=fidelity.score_predictions(corpus['validation'],lastpredictions,codec=donor['codec'],validate_rule=bounded_legal_shape,output_limit=512,validator_id='independent-bounded-scalar-shape-replay-not-native')
 for key in ('metrics','by_length','by_facet'):check(last_replay[key]==report['last_complete_attempt']['fidelity'][key],name+'/last_attempt_generated_token_replay/'+key)

 acceptedtotal+=accepted
 check(saved['weights_sha256']==digest(saved['model_state']),name+'/saved_weights_json_digest')
 check(tensor_sha(saved['model_state'])==report['selected_weights_sha256']==saved['architecture_specification']['model_weights_sha256'],name+'/saved_float32_digest_matches_selected_description')
 check(saved['architecture_specification']['conditioning']==run['architecture'],name+'/saved_conditioning_identity')
 check(saved['architecture_specification']['current_adapter_is_zero']==all(x==0 for x in flat(saved['model_state']['source_to_embedding.weight'])),name+'/adapter_description_matches_values')
 for parameter in report['frozen_parameter_names']:check(tensor_bytes(saved['model_state'][parameter])==tensor_bytes(donor['model_state'][parameter.removeprefix('body.')]),name+'/frozen_parent/'+parameter)
 for label,split in [('validation','validation'),('training','train'),('zero-condition','validation'),('source-shuffle','validation')]:
  evaluation=read(folder/('evaluation-'+label+'.json'));f=evaluation['source_fidelity'];p=evaluation['predictions'];refs=corpus[split]
  audit_fidelity(f,refs,p,saved['codec'],name+'/'+label)
  check(evaluation['report']['complete'] and evaluation['report']['optimizer_steps']==0 and evaluation['execution']['selection_performed'] is False and evaluation['execution']['training_performed'] is False,name+'/'+label+'/postfit_only')
  check(evaluation['report']==run['postfit'][label]['numerical'] and {k:v for k,v in f.items() if k!='rows'}==run['postfit'][label]['source_fidelity'],name+'/'+label+'/summary_identity')
  if label=='validation':check(p==predictions and {k:v for k,v in f.items() if k!='rows'}==report['selected']['fidelity'],name+'/reloaded_validation_matches_selection')
  if label=='source-shuffle':
   assignment=evaluation['execution']['source_assignment'];lookup={r['id']:r for r in refs}
   check(set(assignment)==set(assignment.values())==set(lookup) and all(k!=v and lookup[k]['clause_count']==lookup[v]['clause_count'] for k,v in assignment.items()),name+'/source_shuffle_exact_length_derangement')
   for k,v in assignment.items():check(evaluation['execution']['input_substitutions'][k]==dict(original_input_sha256=digest(vectors[k]),substituted_input_sha256=digest(vectors[v])),name+'/shuffle_vector_hash/'+k)
 if report['last_complete_attempt_state_available']:
  last=read(folder/'last-complete-attempt-state.json');check(last['selected']==report['last_complete_attempt_is_selected'],name+'/last_attempt_selection_flag');check(last['weights_sha256']==digest(last['model_state']),name+'/last_attempt_weight_hash')
 arm_results.append(dict(arm=name,steps=report['optimizer_steps'],epochs=len(report['history']),selected_epoch=report['selected_epoch'],accepted_epochs=accepted,training_seconds=report['elapsed_seconds'],selected_metrics=report['selected']['fidelity']['metrics'],last_attempt_metrics=report['last_complete_attempt']['fidelity']['metrics'],selected_facets=report['selected']['fidelity']['by_facet'],control_exact={key:v['source_fidelity']['metrics']['ordered_exact'] for key,v in run['postfit'].items()}))
check(len(initialhashes)==len(capacities)==1,'all_arms_matched_initial_weights_and_capacity')
check(summary['complete'] is True and all(r['budget_completed'] for r in summary['runs']),'summary_budget_complete')
check(summary['dimensions_actually_trained']==[384] and summary['bridge_evaluation_performed'] is False and summary['legal_ir_evaluate_provers'] is False and summary['bridge_names']==[],'actual_scope_384_no_bridge_or_native')
suite=ET.parse(RUN/'tests-r3.xml').getroot().find('testsuite');tests={k:int(suite.attrib[k]) for k in ('tests','failures','errors','skipped')};check(tests['tests']>=293 and tests['failures']==tests['errors']==tests['skipped']==0,'final_regression_counts')
artifacts[str(RUN/'tests-r3.xml')]=dict(sha256=sha(RUN/'tests-r3.xml'),bytes=(RUN/'tests-r3.xml').stat().st_size)
output=dict(schema='independent-decoder-source-fidelity-audit/v1',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),verdict='blocking_findings' if findings else 'no_blocking_correctness_issue_found',findings=findings,all_pins_match=all(c['passed'] for c in checks if c['check'].startswith(('frozen_extension/','sealed_input/','loaded_producer/','sealed_recipe_hash'))),checked_count=len(checks),failed_check_count=len(findings),checks=checks,source_extension_count=len(manifest['extensions']),published_prior_manifest=dict(commit=prior_commit,path=prior_manifest_path,sha256=hashlib.sha256(prior_manifest_raw).hexdigest()),loaded_producer_count=len(summary['source_dependencies']),input_count=len(manifest['inputs']),tests=tests,stages=stages,expected_steps_per_arm=steps,expected_tokens_per_arm=tokens,accepted_epoch_total=acceptedtotal,arm_results=arm_results,artifacts=artifacts,resource_status=resources['status'],prior_attempts=[dict(attempt='smoke-r1',status='scheduler_timeout_before_model_execution',claim='only known unused100MB claim explicitly reconciled; foreign records unchanged'),dict(attempt='smoke-r2',status='one_complete_fit_then_postfit_filename_collision',outputs_preserved=True,resource_recovered=True)],limitations=['Exposed authored train/validation compositions; no fresh holdout or natural long statute claim.','Reference agreement is not authenticated source semantics or legal formalization.','Per-length/per-facet guards aggregate rows and do not guarantee every individual row is monotonic.','Independent arithmetic uses recorded canonical-validity decisions; no independent syntax, model or native run occurred.','Summary reports retain the hash of their full parent report; only full postfit reports were rehashed directly.','Tensor memory estimates exclude allocator/Python/RSS and deadlines are cooperative.','All selected epochs are0: selected zero-condition and shuffled-source controls characterize initial weights, not a learned persistent source residual.','Last-attempt token replay uses a separately declared bounded scalar-shape validator, not new native or full canonical qualification.','Two minibatch seeds share the same inherited initial weights; no claim of architecture superiority or global minimum.','384D only; historical8D and factorized768D were not trained in this experiment.'],model_executed_by_auditor=False,native_executed_by_auditor=False,qualified=False,admitted=False,proof_authority=False,source_semantics_verified=False,fresh_holdout=False,convergence_proven=False)
path=RUN/'independent-audit.json';path.write_bytes(json.dumps(output,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
print(json.dumps(dict(verdict=output['verdict'],checks=len(checks),findings=findings,sha256=sha(path),bytes=path.stat().st_size,selected_exact=[r['selected_metrics']['ordered_exact'] for r in arm_results],last_exact=[r['last_attempt_metrics']['ordered_exact'] for r in arm_results])))
