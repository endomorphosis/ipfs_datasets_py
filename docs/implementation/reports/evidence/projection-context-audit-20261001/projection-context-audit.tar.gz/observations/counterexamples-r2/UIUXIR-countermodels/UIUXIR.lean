-- Authored finite event-witness models, not a deployed confirmation policy.
set_option autoImplicit false
namespace UIUXIR

structure Event where
  kind : String
  action : String
  request : String
  token : String
  tick : Nat

-- This intentionally small predicate only asks whether the supplied prefix has
-- a matching, strictly earlier, fresh confirmation. It does not implement
-- cancellation, token consumption, event authenticity, or lifetime enforcement.
def hasFreshConfirmation (history : List Event) (invocation : Event) (maxAge : Nat) : Bool :=
  history.any (fun event =>
    event.kind == "confirm" && event.action == invocation.action &&
    event.request == invocation.request && event.token == invocation.token &&
    decide (event.tick < invocation.tick) && decide (invocation.tick - event.tick ≤ maxAge))

def confirmation : Event := ⟨"confirm", "publish", "request:1", "token:1", 1⟩
def invocation : Event := ⟨"invoke", "publish", "request:1", "token:1", 8⟩
def wrongRequest : Event := ⟨"confirm", "publish", "request:2", "token:1", 1⟩

theorem fiveTickPolicyHasNoFreshWitness :
    hasFreshConfirmation [confirmation] invocation 5 = false := by decide
theorem tenTickPolicyHasFreshWitness :
    hasFreshConfirmation [confirmation] invocation 10 = true := by decide
theorem suppliedFreshnessPolicyChangesVerdict :
    hasFreshConfirmation [confirmation] invocation 5 ≠
      hasFreshConfirmation [confirmation] invocation 10 := by decide
theorem absentPrefixHasNoObservedWitness :
    hasFreshConfirmation [] invocation 10 = false := by decide
theorem retrievingEarlierEvidenceChangesWitnessResult :
    hasFreshConfirmation [] invocation 10 ≠
      hasFreshConfirmation [confirmation] invocation 10 := by decide
theorem wrongRequestIsNotAWitness :
    hasFreshConfirmation [wrongRequest] invocation 10 = false := by decide

-- No witness in a truncated prefix does not assert no confirmation ever occurred.
end UIUXIR
