-- Authored finite countermodels, not an interpretation of any legal span.
namespace LegalIR

-- Explicit toy clock: discrete natural ticks with both interval endpoints included.
def withinDeadline (origin duration : Nat) (event : Nat → Bool) : Bool :=
  (List.range (duration + 1)).any (fun delta => event (origin + delta))

def publishedAtSix (tick : Nat) : Bool := tick == 6

theorem deadlineFromZero : withinDeadline 0 10 publishedAtSix = true := by decide
theorem deadlineFromSeven : withinDeadline 7 10 publishedAtSix = false := by decide
theorem deadlineOriginChangesVerdict :
    withinDeadline 0 10 publishedAtSix ≠ withinDeadline 7 10 publishedAtSix := by decide

-- Two explicit ideal worlds; no assumption identifies either with actual behavior.
def idealWorlds : List Nat := [0, 1]
def obligated (claim : Nat → Bool) : Bool := idealWorlds.all claim
def idealPublication (world tick : Nat) : Bool :=
  (world == 0 && tick == 2) || (world == 1 && tick == 5)
def actualPublication (_tick : Nat) : Bool := false

theorem idealDeadlineObligation :
    obligated (fun world => withinDeadline 0 10 (idealPublication world)) = true := by decide
theorem actualDeadlineMissed : withinDeadline 0 10 actualPublication = false := by decide
theorem obligationDoesNotEstablishActualPublication :
    obligated (fun world => withinDeadline 0 10 (idealPublication world)) ≠
      withinDeadline 0 10 actualPublication := by decide

-- O(F p) quantifies world then time; F(O p) demands one shared publication tick.
theorem everyIdealWorldEventuallyPublishes :
    obligated (fun world => withinDeadline 0 10 (idealPublication world)) = true := by decide
theorem noTickHasPublicationInEveryIdealWorld :
    withinDeadline 0 10 (fun tick => obligated (fun world => idealPublication world tick)) = false := by decide
theorem modalityOrderChangesMeaning :
    obligated (fun world => withinDeadline 0 10 (idealPublication world)) ≠
      withinDeadline 0 10 (fun tick => obligated (fun world => idealPublication world tick)) := by decide

end LegalIR
