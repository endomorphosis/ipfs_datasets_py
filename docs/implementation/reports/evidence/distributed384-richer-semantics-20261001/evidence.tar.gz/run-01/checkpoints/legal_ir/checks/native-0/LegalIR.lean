-- Actual native interpretation declarations; no source truth asserted.

namespace LegalIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_1
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t)))
end Projection_1

namespace Projection_2
def norm_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "register" [(i.constant "custodian"), (i.constant "certificate")] t)
end Projection_2

namespace Projection_3
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Reports" [v0] t)) t)
end Projection_3

namespace Projection_4
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t))
end Projection_4

namespace Projection_5
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Person" [v0] t) t) → ((fun t => i.atom "Reports" [v0] t) t)) t)
end Projection_5

namespace Projection_6
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"alice\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"officer\"}"))
end Projection_6

namespace Projection_7
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "p" [] t) ∧ (i.atom "q" [] t))
end Projection_7

namespace Projection_8
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Reports" [v0] t))) t)
end Projection_8

namespace Projection_9
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Reports" [v0] t)) t)
end Projection_9

end LegalIR


namespace LegalIR
namespace Projection_0
set_option linter.unusedVariables false
structure AuthAtom where
  predicate : String
  arguments : List String
  deriving DecidableEq, BEq
structure AuthFact where
  identity : String
  atom : AuthAtom
  issuer : String
inductive AuthGuard where
  | equal (left right : String)
  | unequal (left right : String)
  | member (value : String) (members : List String)
def AuthGuard.holds : AuthGuard → Bool
  | .equal left right => left == right
  | .unequal left right => left != right
  | .member value members => members.contains value
inductive AuthEffect where
  | allow | deny | derive
  deriving DecidableEq, BEq
inductive AuthOutcome where
  | allow | deny | conflict | unknown
  deriving DecidableEq, BEq
inductive AuthPrecedence where
  | deny_overrides | allow_overrides | first_applicable | explicit_conflict
structure AuthRule where
  identity : String
  head : AuthAtom
  positive : List AuthAtom
  negative : List AuthAtom
  guards : List AuthGuard
  secpal : Bool
  issuer : String
  effect : AuthEffect
  stratum : Nat
structure AuthQuery where
  identity : String
  principal : String
  action : String
  resource : String
  goal : Option AuthAtom

def issuerAuthorized (roots : List String) (rule : AuthRule) : Bool :=
  !rule.secpal || roots.contains rule.issuer

def bodySatisfied (facts : List AuthAtom) (rule : AuthRule) : Bool :=
  rule.positive.all facts.contains &&
  rule.negative.all (fun atom => !facts.contains atom) &&
  rule.guards.all AuthGuard.holds

-- Exactly the ground head alignment used by the reference evaluator.
def headAligned (query : AuthQuery) (head : AuthAtom) : Bool :=
  match head.arguments with
  | [] => true
  | [principal] => principal == query.principal
  | [principal, action] => principal == query.principal && action == query.action
  | [principal, action, resource] =>
      principal == query.principal && action == query.action && resource == query.resource
  | _ => false

def evidenceMatches (query : AuthQuery) (atom : AuthAtom) : Bool :=
  match atom.arguments with
  | [] => true
  | [value] => [query.principal, query.action, query.resource].contains value
  | [principal, value] => principal == query.principal &&
      [query.action, query.resource].contains value
  | [principal, action, resource] =>
      principal == query.principal && action == query.action &&
      (query.resource == "" || [query.resource, "*", ""].contains resource)
  | _ => false

def resolveAuthorization (precedence : AuthPrecedence) (allow deny : Bool)
    (first : Option AuthEffect) : AuthOutcome :=
  if allow && deny then
    match precedence with
    | .deny_overrides => .deny
    | .allow_overrides => .allow
    | .explicit_conflict => .conflict
    | .first_applicable =>
      match first with
      | some .allow => .allow
      | some .deny => .deny
      | _ => .conflict
  else if deny then .deny else if allow then .allow else .unknown

def applicableRules (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => issuerAuthorized roots rule && bodySatisfied facts rule)

def queryDirectedRules (query : AuthQuery) (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => headAligned query rule.head)

def evaluatedFacts (facts : List AuthAtom) (applicable : List AuthRule)
    (query : AuthQuery) : List AuthAtom :=
  facts ++ ((queryDirectedRules query applicable).map AuthRule.head) ++
    ((applicable.filter (fun rule => rule.effect == .derive)).map AuthRule.head)

-- Native decision collection also scans EDB/IDB for effect-rule predicates;
-- effect and predicate identity are retained even for a rule that did not fire.
def hasEffectEvidence (effect : AuthEffect) (rules : List AuthRule)
    (facts : List AuthAtom) (query : AuthQuery) : Bool :=
  rules.any (fun rule => rule.effect == effect && facts.any (fun atom =>
    atom.predicate == rule.head.predicate && evidenceMatches query atom))

def evaluateAuthorization (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) (precedence : AuthPrecedence) (query : AuthQuery) : AuthOutcome :=
  let applicable := applicableRules facts roots rules
  let materialized := evaluatedFacts facts applicable query
  let goal := match query.goal with
    | none => false
    | some atom => materialized.contains atom
  let allow := goal || hasEffectEvidence .allow rules materialized query
  let deny := hasEffectEvidence .deny rules materialized query
  let first := ((queryDirectedRules query applicable).find?
    (fun rule => rule.effect != .derive)).map AuthRule.effect
  resolveAuthorization precedence allow deny first


def authorizationFacts : List AuthFact := [⟨"fact:read", ⟨"predicate:read", ["principal:owner"]⟩, ""⟩]

def authorizationRoots : List String := ["principal:owner"]

def authorizationRules : List AuthRule := []

def authorizationPrecedence : AuthPrecedence := .deny_overrides

def authorizationDecision (query : AuthQuery) : AuthOutcome :=
  evaluateAuthorization (authorizationFacts.map AuthFact.atom) authorizationRoots authorizationRules authorizationPrecedence query

def authorizationSignature_0 : String := "{\"argument_sorts\":[\"principal\"],\"arity\":1,\"is_intensional\":false,\"name\":\"can_read\",\"predicate_id\":\"predicate:read\",\"schema_version\":\"authorization-predicate/v1\",\"source_ref_ids\":[\"source:legal_ir:9aa196f2a64b50b577348a9c8291569301dfa173c53ffa0cf7572b02654d16f3\"],\"span_ids\":[]}"

def authorizationEvidence_principals_0 : String := "{\"attributes\":{},\"kind\":\"agent\",\"name\":\"Owner\",\"principal_id\":\"principal:owner\",\"schema_version\":\"authorization-principal/v1\",\"source_ref_ids\":[\"source:legal_ir:9aa196f2a64b50b577348a9c8291569301dfa173c53ffa0cf7572b02654d16f3\"],\"span_ids\":[]}"

def authorizationEvidence_sources_0 : String := "{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"9aa196f2a64b50b577348a9c8291569301dfa173c53ffa0cf7572b02654d16f3\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"source:legal_ir:9aa196f2a64b50b577348a9c8291569301dfa173c53ffa0cf7572b02654d16f3\",\"review_status\":\"unreviewed\",\"source_id\":\"exact_supplied_source_text\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"urn:domain-family-training:legal_ir:9aa196f2a64b50b577348a9c8291569301dfa173c53ffa0cf7572b02654d16f3\"}"

def authorizationEvidence_bounds : String := "{\"max_delegation_depth\":64,\"max_derivation_depth\":1024,\"max_facts\":100000,\"max_rules\":10000,\"max_stratum\":255,\"schema_version\":\"authorization-bounds/v1\",\"universe_size\":null}"

def authorizationEvidence_precedence : String := "{\"resolution\":\"deny_overrides\",\"schema_version\":\"authorization-precedence/v1\",\"statement\":\"When allow and deny evidence co-exist, deny overrides unless the resolution policy says otherwise.\"}"

def authorizationEvidence_facts_0 : String := "{\"atom\":{\"arguments\":[{\"kind\":\"constant\",\"sort\":\"principal\",\"value\":\"principal:owner\"}],\"polarity\":\"positive\",\"predicate_id\":\"predicate:read\"},\"attributes\":{},\"fact_id\":\"fact:read\",\"issuer_principal_id\":\"\",\"schema_version\":\"authorization-fact/v1\",\"source_ref_ids\":[\"source:legal_ir:9aa196f2a64b50b577348a9c8291569301dfa173c53ffa0cf7572b02654d16f3\"],\"span_ids\":[]}"

def authorizationPayloadSHA256 : String := "1738d004aef0f88766808ea1ab35bf22c30421063e8b1f96659d2d11a6c92909"
end Projection_0
end LegalIR
