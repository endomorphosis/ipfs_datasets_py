-- Actual native interpretation declarations; no source truth asserted.

namespace IntentIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_1
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S6ac86e15738d77ce2418d52366210717e7e79b9304ec725b148f069303ca4fa5" [(i.function "Sfdd437124dcb3ae3352bedd25b32fef3714c428da138b2b790508c0d0367e5b7" []), (i.function "S0a094df0fe2354385816155e09d52743de9ba0f2fa24d3e05540e16946b5d1c5" [])] t))
end Projection_1

namespace Projection_2
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t)))
end Projection_2

namespace Projection_3
def norm_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "classify" [(i.constant "dispatcher"), (i.constant "manifest")] t)
end Projection_3

namespace Projection_4
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Reports" [v0] t)) t)
end Projection_4

namespace Projection_5
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := i.modal "deontic:O" [] none (fun t => i.atom "classify" [(i.constant "dispatcher"), (i.constant "manifest")] t)
end Projection_5

namespace Projection_6
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t))
end Projection_6

namespace Projection_7
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Person" [v0] t) t) → ((fun t => i.atom "Reports" [v0] t) t)) t)
end Projection_7

namespace Projection_8
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e6e83ab1b5e4721cf8e22870b8ac4cf873a9cfcb20cd7322a8fee6788d96dbf4") "/document_id" (i.constant "\"intent-rich:132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\"")
def frame_1 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e6e83ab1b5e4721cf8e22870b8ac4cf873a9cfcb20cd7322a8fee6788d96dbf4") "/entry_action_ids/0" (i.constant "\"action:0\"")
def frame_2 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e6e83ab1b5e4721cf8e22870b8ac4cf873a9cfcb20cd7322a8fee6788d96dbf4") "/intent_kind" (i.constant "\"declarative\"")
def frame_3 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e6e83ab1b5e4721cf8e22870b8ac4cf873a9cfcb20cd7322a8fee6788d96dbf4") "/schema_version" (i.constant "\"intent-ir/v1\"")
def frame_4 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e6e83ab1b5e4721cf8e22870b8ac4cf873a9cfcb20cd7322a8fee6788d96dbf4") "/tags/0" (i.constant "\"learned-candidate\"")
def frame_5 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e6e83ab1b5e4721cf8e22870b8ac4cf873a9cfcb20cd7322a8fee6788d96dbf4") "/terminal_action_ids/0" (i.constant "\"action:0\"")
def frame_6 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_e6e83ab1b5e4721cf8e22870b8ac4cf873a9cfcb20cd7322a8fee6788d96dbf4") "/title" (i.constant "\"Rich candidate action/workflow view\"")
def frame_7 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_sha256" (i.constant "\"\"")
def frame_8 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/container_uri" (i.constant "\"\"")
def frame_9 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_cid" (i.constant "\"\"")
def frame_10 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/content_sha256" (i.constant "\"132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\"")
def frame_11 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/license_expression" (i.constant "\"\"")
def frame_12 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/ref_id" (i.constant "\"source\"")
def frame_13 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/review_status" (i.constant "\"machine_extracted\"")
def frame_14 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_id" (i.constant "\"132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\"")
def frame_15 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_revision" (i.constant "\"132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\"")
def frame_16 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/source_uri" (i.constant "\"instruction:learned-rich-intent\"")
def frame_17 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span/end_char" (i.constant "42")
def frame_18 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_b5230448693194d28ee72e9121e8fcf5a93d43cd1eb6290aa1da28b3f59fdd35") "/span/start_char" (i.constant "0")
def frame_19 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/arguments/0" (i.constant "\"dispatcher\"")
def frame_20 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/arguments/1" (i.constant "\"manifest\"")
def frame_21 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/confidence" (i.constant "0.0")
def frame_22 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/grounding" (i.constant "\"inferred\"")
def frame_23 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/kind" (i.constant "\"goal\"")
def frame_24 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/modality" (i.constant "\"required\"")
def frame_25 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/normalized_text" (i.constant "\"dispatcher must classify manifest.\"")
def frame_26 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/predicate" (i.constant "\"classify\"")
def frame_27 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/review_status" (i.constant "\"machine_extracted\"")
def frame_28 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_29 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_04f82b9a1c2fcde546c1e848f4dfb1eb15d10c0e505b2f524940829c793150f8") "/statement_id" (i.constant "\"goal:0\"")
def frame_30 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/action_id" (i.constant "\"action:0\"")
def frame_31 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/actor" (i.constant "\"dispatcher\"")
def frame_32 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/effect_ids" (i.constant "[]")
def frame_33 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/grounding" (i.constant "\"inferred\"")
def frame_34 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/input_refs" (i.constant "[]")
def frame_35 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/object_refs/0" (i.constant "\"manifest\"")
def frame_36 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/output_refs" (i.constant "[]")
def frame_37 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/precondition_ids" (i.constant "[]")
def frame_38 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/source_ref_ids/0" (i.constant "\"source\"")
def frame_39 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/tool_refs" (i.constant "[]")
def frame_40 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/verb" (i.constant "\"classify\"")
def frame_41 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := i.frame (i.constant "intent_1514f1dcb004c35a8cb522ec260dc1dc5cba0296c330a37bc316e826566460a0") "/verification_ids" (i.constant "[]")
end Projection_8

namespace Projection_9
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"alice\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"officer\"}"))
end Projection_9

namespace Projection_10
structure IntentActionInterpretation (World Entity : Type) where
  constant : String → Entity
  atom : String → List Entity → World → Prop
  step : String → Entity → String → List Entity → World → World → Prop
def actionContract_0 {World Entity : Type} (i : IntentActionInterpretation World Entity) : Prop :=
  ∀ s t, (True) → (i.step "action:0" (i.constant "dispatcher") "classify" [(i.constant "manifest")] s t) → (True)
end Projection_10

namespace Projection_11
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 8
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:0", [("classified", (.boolean false))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:0", [("classified", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("classified", (.boolean true))])) && ((configuration2.phase == "done"))
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean false)].contains (lookup configuration1.values "classified")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:0"]
def enabledActions : List String := ["action:0"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_11

namespace Projection_12
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "p" [] t) ∧ (i.atom "q" [] t))
end Projection_12

namespace Projection_13
def formula_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (fun t => i.atom "S6ac86e15738d77ce2418d52366210717e7e79b9304ec725b148f069303ca4fa5" [(i.constant "entity:fdd437124dcb3ae3352bedd25b32fef3714c428da138b2b790508c0d0367e5b7"), (i.constant "entity:0a094df0fe2354385816155e09d52743de9ba0f2fa24d3e05540e16946b5d1c5")] t))
end Projection_13

namespace Projection_14
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Reports" [v0] t))) t)
end Projection_14

namespace Projection_15
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 8
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:0", [("classified", (.boolean false))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:0", [("classified", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("classified", (.boolean true))])) && ((configuration2.phase == "done"))
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean false)].contains (lookup configuration1.values "classified")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:0"]
def enabledActions : List String := ["action:0"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_15

namespace Projection_16
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Reports" [v0] t)) t)
end Projection_16

namespace Projection_17
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 8
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:0", [("classified", (.boolean false))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:0", [("classified", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("classified", (.boolean true))])) && ((configuration2.phase == "done"))
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean false)].contains (lookup configuration1.values "classified")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:0"]
def enabledActions : List String := ["action:0"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_17

namespace Projection_18
structure State where
  v0 : String
def typeOK (s : State) : Prop := (s.v0 ∈ ["configuration_0", "configuration_1", "configuration_2"])
def predicate_0 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_1 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_2 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_3 (s : State) : Prop := (s.v0 = "configuration_0")
def predicate_4 (s : State) : Prop := (s.v0 = "configuration_1")
def predicate_5 (s : State) : Prop := (s.v0 = "configuration_2")
def predicate_6 (s : State) : Prop := (s.v0 = "configuration_2")
def initial (s : State) : Prop := typeOK s ∧ (predicate_3 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_0 s) ∧ (predicate_4 t)
def readFrame_1 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_1 = true := by decide
def action_1 (s t : State) : Prop := (predicate_1 s) ∧ (predicate_5 t)
def readFrame_2 (variableName : String) : Bool := ["var:pc"].contains variableName
example : ["var:pc"].all readFrame_2 = true := by decide
def action_2 (s t : State) : Prop := (predicate_2 s) ∧ (predicate_6 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:guarded:0" ∧ action_0 s t) ∨ (label = "action:guarded:1" ∧ action_1 s t) ∨ (label = "action:guarded:2" ∧ action_2 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
example (s : State) (h : predicate_2 s) : action_2 s s := by
  simp_all [action_2, predicate_2, predicate_6]

def sourceVariableAliases : List (String × String) := [("var:pc", "v0"), ("pc", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 8
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:guarded:0", "action:guarded:1", "action:guarded:2"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

namespace GuardedIntent
inductive Value where
  | boolean : Bool → Value
  | integer : Int → Value
  | enumeration : String → Value
  deriving DecidableEq, BEq, Repr
abbrev Values := List (String × Value)
def lookup (values : Values) (key : String) : Option Value := (values.find? fun p => p.1 == key).map Prod.snd
def update (values patch : Values) : Values := values.map fun p => (p.1, (lookup patch p.1).getD p.2)
structure Configuration where
  position : String
  phase : String
  actionId : String
  values : Values
  retries : List (String × Nat)
  terminal : Bool
  deriving DecidableEq, BEq, Repr
def configuration0 : Configuration := ⟨"configuration_0", "initial", "", [], [], false⟩
def configuration1 : Configuration := ⟨"configuration_1", "ready", "action:0", [("classified", (.boolean false))], [], false⟩
def configuration2 : Configuration := ⟨"configuration_2", "done", "action:0", [("classified", (.boolean true))], [], true⟩
def configurations : List Configuration := [configuration0, configuration1, configuration2]
def actionCase0 : Bool := ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration2.actionId == configuration1.actionId)) && ((configuration2.retries == configuration1.retries)) && ((configuration2.values == update configuration1.values [("classified", (.boolean true))])) && ((configuration2.phase == "done"))
theorem action_case_0_checks : actionCase0 = true := by decide
def retryCount (c : Configuration) (edge : String) : Nat := ((c.retries.find? fun p => p.1 == edge).map Prod.snd).getD 0
def graphCase0 : Bool := ((configuration0.phase == "initial")) && ((configuration1.phase == "ready")) && ((configuration1.actionId == "action:0")) && ((configuration1.retries.all fun p => p.2 == 0)) && (([some (.boolean false)].contains (lookup configuration1.values "classified")))
theorem graph_case_0_checks : graphCase0 = true := by decide
def graphCase1 : Bool := ((actionCase0))
theorem graph_case_1_checks : graphCase1 = true := by decide
def graphCase2 : Bool := (configuration2.terminal) && ((configuration2.phase == "done")) && ((configuration2 == configuration2))
theorem graph_case_2_checks : graphCase2 = true := by decide
def explicitSuccessors : List (String × String) := [("configuration_0", "configuration_1"), ("configuration_1", "configuration_2"), ("configuration_2", "configuration_2")]
def noAbstractDeadlock : Bool := configurations.all fun c => c.terminal || explicitSuccessors.any (fun e => e.1 == c.position)
theorem complete_model_has_no_deadlock : noAbstractDeadlock = true := by decide
theorem kernel_edge_0 : action_0 ⟨"configuration_0"⟩ ⟨"configuration_1"⟩ := by simp [action_0, predicate_0, predicate_4]
theorem kernel_edge_1 : action_1 ⟨"configuration_1"⟩ ⟨"configuration_2"⟩ := by simp [action_1, predicate_1, predicate_5]
theorem kernel_edge_2 : action_2 ⟨"configuration_2"⟩ ⟨"configuration_2"⟩ := by simp [action_2, predicate_2, predicate_6]
def declaredActions : List String := ["action:0"]
def enabledActions : List String := ["action:0"]
def everyActionHasReachableExecution : Bool := declaredActions.all enabledActions.contains
theorem all_actions_reachable : everyActionHasReachableExecution = true := by decide
def callerSuppliedInterpretation : Bool := true
def sourceCodeEquivalenceVerified : Bool := false
def normativeComplianceVerified : Bool := false
end GuardedIntent

end Projection_18

end IntentIR


namespace IntentIR
namespace Projection_0
set_option linter.unusedVariables false
structure AuthAtom where
  predicate : String
  arguments : List String
  deriving DecidableEq, BEq
structure AuthFact where
  identity : String
  atom : AuthAtom
  issuer : String
inductive AuthGuard where
  | equal (left right : String)
  | unequal (left right : String)
  | member (value : String) (members : List String)
def AuthGuard.holds : AuthGuard → Bool
  | .equal left right => left == right
  | .unequal left right => left != right
  | .member value members => members.contains value
inductive AuthEffect where
  | allow | deny | derive
  deriving DecidableEq, BEq
inductive AuthOutcome where
  | allow | deny | conflict | unknown
  deriving DecidableEq, BEq
inductive AuthPrecedence where
  | deny_overrides | allow_overrides | first_applicable | explicit_conflict
structure AuthRule where
  identity : String
  head : AuthAtom
  positive : List AuthAtom
  negative : List AuthAtom
  guards : List AuthGuard
  secpal : Bool
  issuer : String
  effect : AuthEffect
  stratum : Nat
structure AuthQuery where
  identity : String
  principal : String
  action : String
  resource : String
  goal : Option AuthAtom

def issuerAuthorized (roots : List String) (rule : AuthRule) : Bool :=
  !rule.secpal || roots.contains rule.issuer

def bodySatisfied (facts : List AuthAtom) (rule : AuthRule) : Bool :=
  rule.positive.all facts.contains &&
  rule.negative.all (fun atom => !facts.contains atom) &&
  rule.guards.all AuthGuard.holds

-- Exactly the ground head alignment used by the reference evaluator.
def headAligned (query : AuthQuery) (head : AuthAtom) : Bool :=
  match head.arguments with
  | [] => true
  | [principal] => principal == query.principal
  | [principal, action] => principal == query.principal && action == query.action
  | [principal, action, resource] =>
      principal == query.principal && action == query.action && resource == query.resource
  | _ => false

def evidenceMatches (query : AuthQuery) (atom : AuthAtom) : Bool :=
  match atom.arguments with
  | [] => true
  | [value] => [query.principal, query.action, query.resource].contains value
  | [principal, value] => principal == query.principal &&
      [query.action, query.resource].contains value
  | [principal, action, resource] =>
      principal == query.principal && action == query.action &&
      (query.resource == "" || [query.resource, "*", ""].contains resource)
  | _ => false

def resolveAuthorization (precedence : AuthPrecedence) (allow deny : Bool)
    (first : Option AuthEffect) : AuthOutcome :=
  if allow && deny then
    match precedence with
    | .deny_overrides => .deny
    | .allow_overrides => .allow
    | .explicit_conflict => .conflict
    | .first_applicable =>
      match first with
      | some .allow => .allow
      | some .deny => .deny
      | _ => .conflict
  else if deny then .deny else if allow then .allow else .unknown

def applicableRules (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => issuerAuthorized roots rule && bodySatisfied facts rule)

def queryDirectedRules (query : AuthQuery) (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => headAligned query rule.head)

def evaluatedFacts (facts : List AuthAtom) (applicable : List AuthRule)
    (query : AuthQuery) : List AuthAtom :=
  facts ++ ((queryDirectedRules query applicable).map AuthRule.head) ++
    ((applicable.filter (fun rule => rule.effect == .derive)).map AuthRule.head)

-- Native decision collection also scans EDB/IDB for effect-rule predicates;
-- effect and predicate identity are retained even for a rule that did not fire.
def hasEffectEvidence (effect : AuthEffect) (rules : List AuthRule)
    (facts : List AuthAtom) (query : AuthQuery) : Bool :=
  rules.any (fun rule => rule.effect == effect && facts.any (fun atom =>
    atom.predicate == rule.head.predicate && evidenceMatches query atom))

def evaluateAuthorization (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) (precedence : AuthPrecedence) (query : AuthQuery) : AuthOutcome :=
  let applicable := applicableRules facts roots rules
  let materialized := evaluatedFacts facts applicable query
  let goal := match query.goal with
    | none => false
    | some atom => materialized.contains atom
  let allow := goal || hasEffectEvidence .allow rules materialized query
  let deny := hasEffectEvidence .deny rules materialized query
  let first := ((queryDirectedRules query applicable).find?
    (fun rule => rule.effect != .derive)).map AuthRule.effect
  resolveAuthorization precedence allow deny first


def authorizationFacts : List AuthFact := [⟨"fact:read", ⟨"predicate:read", ["principal:owner"]⟩, ""⟩]

def authorizationRoots : List String := ["principal:owner"]

def authorizationRules : List AuthRule := []

def authorizationPrecedence : AuthPrecedence := .deny_overrides

def authorizationDecision (query : AuthQuery) : AuthOutcome :=
  evaluateAuthorization (authorizationFacts.map AuthFact.atom) authorizationRoots authorizationRules authorizationPrecedence query

def authorizationSignature_0 : String := "{\"argument_sorts\":[\"principal\"],\"arity\":1,\"is_intensional\":false,\"name\":\"can_read\",\"predicate_id\":\"predicate:read\",\"schema_version\":\"authorization-predicate/v1\",\"source_ref_ids\":[\"source:intent_ir:132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\"],\"span_ids\":[]}"

def authorizationEvidence_principals_0 : String := "{\"attributes\":{},\"kind\":\"agent\",\"name\":\"Owner\",\"principal_id\":\"principal:owner\",\"schema_version\":\"authorization-principal/v1\",\"source_ref_ids\":[\"source:intent_ir:132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\"],\"span_ids\":[]}"

def authorizationEvidence_sources_0 : String := "{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"source:intent_ir:132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\",\"review_status\":\"unreviewed\",\"source_id\":\"exact_supplied_source_text\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"urn:domain-family-training:intent_ir:132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\"}"

def authorizationEvidence_bounds : String := "{\"max_delegation_depth\":64,\"max_derivation_depth\":1024,\"max_facts\":100000,\"max_rules\":10000,\"max_stratum\":255,\"schema_version\":\"authorization-bounds/v1\",\"universe_size\":null}"

def authorizationEvidence_precedence : String := "{\"resolution\":\"deny_overrides\",\"schema_version\":\"authorization-precedence/v1\",\"statement\":\"When allow and deny evidence co-exist, deny overrides unless the resolution policy says otherwise.\"}"

def authorizationEvidence_facts_0 : String := "{\"atom\":{\"arguments\":[{\"kind\":\"constant\",\"sort\":\"principal\",\"value\":\"principal:owner\"}],\"polarity\":\"positive\",\"predicate_id\":\"predicate:read\"},\"attributes\":{},\"fact_id\":\"fact:read\",\"issuer_principal_id\":\"\",\"schema_version\":\"authorization-fact/v1\",\"source_ref_ids\":[\"source:intent_ir:132ef85237e07790cf9918c865b3d17bb4f4acd68b6961a8d084ed72476074c1\"],\"span_ids\":[]}"

def authorizationPayloadSHA256 : String := "2bb2450f350ce7dfd36a0a9f9a35ae7b3e8186e6ae35c5f1d2a8528c1b5091a4"
end Projection_0
end IntentIR
