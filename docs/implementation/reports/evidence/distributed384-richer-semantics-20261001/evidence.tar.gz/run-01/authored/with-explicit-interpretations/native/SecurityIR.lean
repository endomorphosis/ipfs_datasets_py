-- Actual native interpretation declarations; no source truth asserted.

namespace SecurityIR

set_option autoImplicit false
structure Interpretation (Entity Agent : Type) where
  agent : String → Agent
  cognitive : String → Agent → (Nat → Prop) → Nat → Prop
  constant : String → Entity
  function : String → List Entity → Entity
  atom : String → List Entity → Nat → Prop
  modal : String → List Entity → Option String → (Nat → Prop) → Nat → Prop
  frame : Entity → String → Entity → Prop
  frameScalar : Entity → String → Entity
  member : Entity → Entity → Prop
  subclass : Entity → Entity → Prop

def nextTime (p : Nat → Prop) (t : Nat) : Prop := p (t + 1)
def alwaysTime (p : Nat → Prop) (t : Nat) : Prop := ∀ u, t ≤ u → p u
def eventuallyTime (p : Nat → Prop) (t : Nat) : Prop := ∃ u, t ≤ u ∧ p u
def untilTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, t ≤ u ∧ q u ∧ ∀ v, t ≤ v → v < u → p v
def sinceTime (p q : Nat → Prop) (t : Nat) : Prop :=
  ∃ u, u ≤ t ∧ q u ∧ ∀ v, u < v → v ≤ t → p v
def weakUntilTime (p q : Nat → Prop) (t : Nat) : Prop := untilTime p q t ∨ alwaysTime p t
def releaseTime (p q : Nat → Prop) (t : Nat) : Prop := ¬ untilTime (fun u => ¬ p u) (fun u => ¬ q u) t


namespace Projection_3
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.modal "deontic:O" [] none (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t)))
end Projection_3

namespace Projection_4
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (fun t => i.atom "Reports" [v0] t)) t)
end Projection_4

namespace Projection_5
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (i.cognitive "K" (i.agent "Officer") (fun t => i.atom "Happens" [(i.function "Submit" []), (i.function "Time" [])] t))
end Projection_5

namespace Projection_6
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (fun t => ((fun t => i.atom "Person" [v0] t) t) → ((fun t => i.atom "Reports" [v0] t) t)) t)
end Projection_6

namespace Projection_7
def frame_0 {Entity Agent : Type} (i : Interpretation Entity Agent) : Prop := (i.frameScalar (i.constant "{\"kind\":\"constant\",\"name\":\"alice\"}") "role" = (i.constant "{\"kind\":\"constant\",\"name\":\"officer\"}"))
end Projection_7

namespace Projection_8
set_option linter.unusedVariables false

structure ExecutionView (Value : Type) where
  publicValue : String → Value
  privateValue : String → Value
  observedValue : String → Value

def lowFields : List String := ["public"]

def highFields : List String := ["secret"]

def observationFields : List String := ["result"]

def lowProjection {Value : Type} (trace : ExecutionView Value) : List Value := lowFields.map trace.publicValue

def observationProjection {Value : Type} (trace : ExecutionView Value) : List Value := observationFields.map trace.observedValue

def noninterference {Value : Type} (executions : ExecutionView Value → Prop) : Prop :=
  ∀ left, executions left → ∀ right, executions right →
    lowProjection left = lowProjection right → observationProjection left = observationProjection right

def maxTraces : Nat := 2

def maxPairs : Nat := 1

def declaredMaxSteps : Option Nat := some 4

def sampleWithinCompositionBudget {Value : Type} (sample : List (ExecutionView Value)) : Prop :=
  sample.length ≤ maxTraces ∧ sample.length * (sample.length - 1) / 2 ≤ maxPairs

def temporalExecutionBoundChecked : Bool := false

def universalNoninterferenceProved : Bool := false

def quantifierVariableOrder : List String := ["var:pi1", "var:pi2"]

def policyIdentifier : String := "policy:flow"
end Projection_8

namespace Projection_10
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) (t : Nat) : Prop := ((i.atom "p" [] t) ∧ (i.atom "q" [] t))
end Projection_10

namespace Projection_12
set_option linter.unusedVariables false
inductive HeapValue where
  | integer (value : Int)
  | boolean (value : Bool)
  deriving DecidableEq
structure HeapInterpretation where
  address : String → Nat
abbrev Heap := Nat → Option HeapValue
def emptyHeap : Heap := fun _ => none
def singletonHeap (address : Nat) (value : HeapValue) : Heap :=
  fun location => if location = address then some value else none
def finiteHeap (heap : Heap) : Prop :=
  ∃ support : List Nat, ∀ address, heap address ≠ none → address ∈ support
def disjointHeaps (left right : Heap) : Prop :=
  ∀ address, left address = none ∨ right address = none
def unionHeap (left right : Heap) : Heap :=
  fun address => match left address with
    | some value => some value
    | none => right address
def emp (heap : Heap) : Prop := heap = emptyHeap
def pointsTo (address : Nat) (value : HeapValue) (heap : Heap) : Prop :=
  heap = singletonHeap address value
def separating (left right : Heap → Prop) (heap : Heap) : Prop :=
  ∃ first second, finiteHeap first ∧ finiteHeap second ∧ disjointHeaps first second ∧
    heap = unionHeap first second ∧ left first ∧ right second
theorem emptyHeap_finite : finiteHeap emptyHeap := by
  refine ⟨[], ?_⟩
  intro address h
  simp [emptyHeap] at h
theorem singletonHeap_finite (address : Nat) (value : HeapValue) :
    finiteHeap (singletonHeap address value) := by
  refine ⟨[address], ?_⟩
  intro other h
  by_cases same : other = address
  · simp [same]
  · simp [singletonHeap, same] at h
theorem singleton_not_disjoint_with_itself (address : Nat) (value : HeapValue) :
    ¬ disjointHeaps (singletonHeap address value) (singletonHeap address value) := by
  intro h
  have contradiction := h address
  simp [singletonHeap] at contradiction


def location_0 (i : HeapInterpretation) : Nat := i.address "loc:cell"

def value_0 : HeapValue := HeapValue.integer (1 : Int)

def declaredHeapFragment (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def allocatedCellCount : Nat := 0
end Projection_12

namespace Projection_13
set_option linter.unusedVariables false
inductive HeapValue where
  | integer (value : Int)
  | boolean (value : Bool)
  deriving DecidableEq
structure HeapInterpretation where
  address : String → Nat
abbrev Heap := Nat → Option HeapValue
def emptyHeap : Heap := fun _ => none
def singletonHeap (address : Nat) (value : HeapValue) : Heap :=
  fun location => if location = address then some value else none
def finiteHeap (heap : Heap) : Prop :=
  ∃ support : List Nat, ∀ address, heap address ≠ none → address ∈ support
def disjointHeaps (left right : Heap) : Prop :=
  ∀ address, left address = none ∨ right address = none
def unionHeap (left right : Heap) : Heap :=
  fun address => match left address with
    | some value => some value
    | none => right address
def emp (heap : Heap) : Prop := heap = emptyHeap
def pointsTo (address : Nat) (value : HeapValue) (heap : Heap) : Prop :=
  heap = singletonHeap address value
def separating (left right : Heap → Prop) (heap : Heap) : Prop :=
  ∃ first second, finiteHeap first ∧ finiteHeap second ∧ disjointHeaps first second ∧
    heap = unionHeap first second ∧ left first ∧ right second
theorem emptyHeap_finite : finiteHeap emptyHeap := by
  refine ⟨[], ?_⟩
  intro address h
  simp [emptyHeap] at h
theorem singletonHeap_finite (address : Nat) (value : HeapValue) :
    finiteHeap (singletonHeap address value) := by
  refine ⟨[address], ?_⟩
  intro other h
  by_cases same : other = address
  · simp [same]
  · simp [singletonHeap, same] at h
theorem singleton_not_disjoint_with_itself (address : Nat) (value : HeapValue) :
    ¬ disjointHeaps (singletonHeap address value) (singletonHeap address value) := by
  intro h
  have contradiction := h address
  simp [singletonHeap] at contradiction


def location_0 (i : HeapInterpretation) : Nat := i.address "loc:cell"

def value_0 : HeapValue := HeapValue.integer (1 : Int)

def declaredHeapFragment (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def allocatedCellCount : Nat := 0

def formula_0 (i : HeapInterpretation) (heap : Heap) : Prop := emp heap

def separationFormula (i : HeapInterpretation) (heap : Heap) : Prop := finiteHeap heap ∧ formula_0 i heap
end Projection_13

namespace Projection_14
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (i.modal "deontic:O" [] none (alwaysTime (fun t => i.atom "Reports" [v0] t))) t)
end Projection_14

namespace Projection_15
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (fun t => ∀ v0 : Entity, (alwaysTime (fun t => i.atom "Reports" [v0] t)) t)
end Projection_15

namespace Projection_16
def formula {Entity Agent : Type} (i : Interpretation Entity Agent) : Nat → Prop := (alwaysTime (fun t => i.atom "safe" [] t))
end Projection_16

namespace Projection_17
structure State where
  v0 : Int
def typeOK (s : State) : Prop := ((0 : Int) ≤ s.v0 ∧ s.v0 ≤ (1 : Int))
def predicate_0 (s : State) : Prop := (s.v0 = (0 : Int))
def predicate_1 (s : State) : Prop := (s.v0 = (1 : Int))
def initial (s : State) : Prop := typeOK s ∧ (predicate_0 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:x"].contains variableName
example : [].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:set" ∧ action_0 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
def sourceVariableAliases : List (String × String) := [("var:x", "v0"), ("x", "v0")]
def actionIntentOrigins : List (String × String) := []
def actionEventOrigins : List (String × String × String) := []
def syntheticActionOrigins : List (String × String) := []
def runtimeEventOccurrencesAttested : Bool := false

def maxSteps : Nat := 64
structure BoundedState where
  state : State
  steps : Nat
  lastLabel : String
def boundedTypeOK (s : BoundedState) : Prop :=
  typeOK s.state ∧ s.steps ≤ maxSteps ∧ s.lastLabel ∈ ["initial", "stutter", "action:set"]
def boundedInitial (s : BoundedState) : Prop :=
  boundedTypeOK s ∧ initial s.state ∧ s.steps = 0 ∧ s.lastLabel = "initial"
def boundedNext (s t : BoundedState) : Prop :=
  boundedTypeOK s ∧ boundedTypeOK t ∧ s.steps < maxSteps ∧ t.steps = s.steps + 1 ∧
  next t.lastLabel s.state t.state
def specification (trace : Nat → BoundedState) : Prop :=
  boundedInitial (trace 0) ∧ ∀ n, boundedNext (trace n) (trace (n + 1)) ∨ trace (n + 1) = trace n
def safety (trace : Nat → BoundedState) : Prop :=
  ∀ n, boundedTypeOK (trace n)
theorem next_preserves_declared_type (s t : BoundedState) (h : boundedNext s t) : boundedTypeOK t := h.2.1

end Projection_17

namespace Projection_18
structure State where
  v0 : Int
def typeOK (s : State) : Prop := ((0 : Int) ≤ s.v0 ∧ s.v0 ≤ (1 : Int))
def predicate_0 (s : State) : Prop := (s.v0 = (0 : Int))
def predicate_1 (s : State) : Prop := (s.v0 = (1 : Int))
def initial (s : State) : Prop := typeOK s ∧ (predicate_0 s)
def invariants (s : State) : Prop := True
def readFrame_0 (variableName : String) : Bool := ["var:x"].contains variableName
example : [].all readFrame_0 = true := by decide
def action_0 (s t : State) : Prop := (predicate_1 t)
def transition_0 (label : String) (s t : State) : Prop := (label = "action:set" ∧ action_0 s t) ∨ (label = "stutter" ∧ t = s)
def next (label : String) (s t : State) : Prop := typeOK s ∧ typeOK t ∧ (transition_0 label s t)
end Projection_18

end SecurityIR


namespace SecurityIR
namespace Projection_0
set_option linter.unusedVariables false
structure AuthAtom where
  predicate : String
  arguments : List String
  deriving DecidableEq, BEq
structure AuthFact where
  identity : String
  atom : AuthAtom
  issuer : String
inductive AuthGuard where
  | equal (left right : String)
  | unequal (left right : String)
  | member (value : String) (members : List String)
def AuthGuard.holds : AuthGuard → Bool
  | .equal left right => left == right
  | .unequal left right => left != right
  | .member value members => members.contains value
inductive AuthEffect where
  | allow | deny | derive
  deriving DecidableEq, BEq
inductive AuthOutcome where
  | allow | deny | conflict | unknown
  deriving DecidableEq, BEq
inductive AuthPrecedence where
  | deny_overrides | allow_overrides | first_applicable | explicit_conflict
structure AuthRule where
  identity : String
  head : AuthAtom
  positive : List AuthAtom
  negative : List AuthAtom
  guards : List AuthGuard
  secpal : Bool
  issuer : String
  effect : AuthEffect
  stratum : Nat
structure AuthQuery where
  identity : String
  principal : String
  action : String
  resource : String
  goal : Option AuthAtom

def issuerAuthorized (roots : List String) (rule : AuthRule) : Bool :=
  !rule.secpal || roots.contains rule.issuer

def bodySatisfied (facts : List AuthAtom) (rule : AuthRule) : Bool :=
  rule.positive.all facts.contains &&
  rule.negative.all (fun atom => !facts.contains atom) &&
  rule.guards.all AuthGuard.holds

-- Exactly the ground head alignment used by the reference evaluator.
def headAligned (query : AuthQuery) (head : AuthAtom) : Bool :=
  match head.arguments with
  | [] => true
  | [principal] => principal == query.principal
  | [principal, action] => principal == query.principal && action == query.action
  | [principal, action, resource] =>
      principal == query.principal && action == query.action && resource == query.resource
  | _ => false

def evidenceMatches (query : AuthQuery) (atom : AuthAtom) : Bool :=
  match atom.arguments with
  | [] => true
  | [value] => [query.principal, query.action, query.resource].contains value
  | [principal, value] => principal == query.principal &&
      [query.action, query.resource].contains value
  | [principal, action, resource] =>
      principal == query.principal && action == query.action &&
      (query.resource == "" || [query.resource, "*", ""].contains resource)
  | _ => false

def resolveAuthorization (precedence : AuthPrecedence) (allow deny : Bool)
    (first : Option AuthEffect) : AuthOutcome :=
  if allow && deny then
    match precedence with
    | .deny_overrides => .deny
    | .allow_overrides => .allow
    | .explicit_conflict => .conflict
    | .first_applicable =>
      match first with
      | some .allow => .allow
      | some .deny => .deny
      | _ => .conflict
  else if deny then .deny else if allow then .allow else .unknown

def applicableRules (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => issuerAuthorized roots rule && bodySatisfied facts rule)

def queryDirectedRules (query : AuthQuery) (rules : List AuthRule) : List AuthRule :=
  rules.filter (fun rule => headAligned query rule.head)

def evaluatedFacts (facts : List AuthAtom) (applicable : List AuthRule)
    (query : AuthQuery) : List AuthAtom :=
  facts ++ ((queryDirectedRules query applicable).map AuthRule.head) ++
    ((applicable.filter (fun rule => rule.effect == .derive)).map AuthRule.head)

-- Native decision collection also scans EDB/IDB for effect-rule predicates;
-- effect and predicate identity are retained even for a rule that did not fire.
def hasEffectEvidence (effect : AuthEffect) (rules : List AuthRule)
    (facts : List AuthAtom) (query : AuthQuery) : Bool :=
  rules.any (fun rule => rule.effect == effect && facts.any (fun atom =>
    atom.predicate == rule.head.predicate && evidenceMatches query atom))

def evaluateAuthorization (facts : List AuthAtom) (roots : List String)
    (rules : List AuthRule) (precedence : AuthPrecedence) (query : AuthQuery) : AuthOutcome :=
  let applicable := applicableRules facts roots rules
  let materialized := evaluatedFacts facts applicable query
  let goal := match query.goal with
    | none => false
    | some atom => materialized.contains atom
  let allow := goal || hasEffectEvidence .allow rules materialized query
  let deny := hasEffectEvidence .deny rules materialized query
  let first := ((queryDirectedRules query applicable).find?
    (fun rule => rule.effect != .derive)).map AuthRule.effect
  resolveAuthorization precedence allow deny first


def authorizationFacts : List AuthFact := [⟨"fact:read", ⟨"predicate:read", ["principal:owner"]⟩, ""⟩]

def authorizationRoots : List String := ["principal:owner"]

def authorizationRules : List AuthRule := []

def authorizationPrecedence : AuthPrecedence := .deny_overrides

def authorizationDecision (query : AuthQuery) : AuthOutcome :=
  evaluateAuthorization (authorizationFacts.map AuthFact.atom) authorizationRoots authorizationRules authorizationPrecedence query

def authorizationSignature_0 : String := "{\"argument_sorts\":[\"principal\"],\"arity\":1,\"is_intensional\":false,\"name\":\"can_read\",\"predicate_id\":\"predicate:read\",\"schema_version\":\"authorization-predicate/v1\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[]}"

def authorizationEvidence_principals_0 : String := "{\"attributes\":{},\"kind\":\"agent\",\"name\":\"Owner\",\"principal_id\":\"principal:owner\",\"schema_version\":\"authorization-principal/v1\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[]}"

def authorizationEvidence_sources_0 : String := "{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"bafkreibhobfew27xqgi4vu4h3lkcdya5t7chmab7jsfgzp5yvu2sevjy44\",\"content_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"review_status\":\"unreviewed\",\"source_id\":\"fixture.py\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"code-unit:bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"}"

def authorizationEvidence_bounds : String := "{\"max_delegation_depth\":64,\"max_derivation_depth\":1024,\"max_facts\":100000,\"max_rules\":10000,\"max_stratum\":255,\"schema_version\":\"authorization-bounds/v1\",\"universe_size\":null}"

def authorizationEvidence_precedence : String := "{\"resolution\":\"deny_overrides\",\"schema_version\":\"authorization-precedence/v1\",\"statement\":\"When allow and deny evidence co-exist, deny overrides unless the resolution policy says otherwise.\"}"

def authorizationEvidence_facts_0 : String := "{\"atom\":{\"arguments\":[{\"kind\":\"constant\",\"sort\":\"principal\",\"value\":\"principal:owner\"}],\"polarity\":\"positive\",\"predicate_id\":\"predicate:read\"},\"attributes\":{},\"fact_id\":\"fact:read\",\"issuer_principal_id\":\"\",\"schema_version\":\"authorization-fact/v1\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[]}"

def authorizationPayloadSHA256 : String := "97239a238fa4e88b509447a9928090488379f3ac86535d7d1a7f25e7114cfbea"
end Projection_0

namespace Projection_1
set_option linter.unusedVariables false

structure Store where
  v0 : Int
  deriving DecidableEq, Repr

inductive Component where
  | c0
  | c1
  deriving DecidableEq, Repr

inductive Actor where
  | component (component : Component)
  | environment
  deriving DecidableEq, Repr

inductive Step where
  | s0
  | s1
  | s2
  deriving DecidableEq, Repr

def componentId : Component → String
  | Component.c0 => "comp:consumer"
  | Component.c1 => "comp:producer"

def stepId : Step → String
  | Step.s0 => "step:cons-read"
  | Step.s1 => "step:env-noise"
  | Step.s2 => "step:prod-write"

def stepActor : Step → Actor
  | Step.s0 => Actor.component Component.c0
  | Step.s1 => Actor.environment
  | Step.s2 => Actor.component Component.c1

def stepGuard : Step → Store → Bool
  | Step.s0 => fun before => (decide (before.v0 > (0 : Int)))
  | Step.s1 => fun before => true
  | Step.s2 => fun before => (decide (((4 : Int) - before.v0) > (0 : Int)))

def stepUpdate : Step → Store → Store
  | Step.s0 => fun before => { before with v0 := (before.v0 - (1 : Int)) }
  | Step.s1 => fun before => before
  | Step.s2 => fun before => { before with v0 := (before.v0 + (1 : Int)) }

def readFrame : Step → List String
  | Step.s0 => ["var:buffer"]
  | Step.s1 => ["var:buffer"]
  | Step.s2 => ["var:buffer"]

def writeFrame : Step → List String
  | Step.s0 => ["var:buffer"]
  | Step.s1 => []
  | Step.s2 => ["var:buffer"]

def stepRelation (step : Step) (before after : Store) : Prop := stepGuard step before = true ∧ after = stepUpdate step before

def componentStep (actor : Component) (step : Step) (before after : Store) : Prop := stepActor step = .component actor ∧ stepRelation step before after

def environmentStep (step : Step) (before after : Store) : Prop := stepActor step = .environment ∧ stepRelation step before after

theorem actors_disjoint (actor : Component) (step : Step) (before after : Store) :
    ¬ (componentStep actor step before after ∧ environmentStep step before after) := by
  intro h
  have wrong : Actor.component actor = Actor.environment := h.1.1.symm.trans h.2.1
  cases wrong

structure Execution where
  state : Nat → Store
  event : Nat → Step

def validExecution (trace : Execution) : Prop := ∀ t, stepRelation (trace.event t) (trace.state t) (trace.state (t + 1))

def selectedEnabled (selected : List Step) (state : Store) : Prop := ∃ step ∈ selected, stepGuard step state = true

def infinitelyOften (predicate : Nat → Prop) : Prop := ∀ start, ∃ t, start ≤ t ∧ predicate t

def continuouslyEventually (predicate : Nat → Prop) : Prop := ∃ start, ∀ t, start ≤ t → predicate t

def weakFair (selected : List Step) (trace : Execution) : Prop := continuouslyEventually (fun t => selectedEnabled selected (trace.state t)) → infinitelyOften (fun t => trace.event t ∈ selected)

def strongFair (selected : List Step) (trace : Execution) : Prop := infinitelyOften (fun t => selectedEnabled selected (trace.state t)) → infinitelyOften (fun t => trace.event t ∈ selected)

def unconditionalFair (selected : List Step) (trace : Execution) : Prop := infinitelyOften (fun t => trace.event t ∈ selected)

def fairness_0 (trace : Execution) : Prop := weakFair [Step.s0] trace

def fairness_1 (trace : Execution) : Prop := weakFair [Step.s2] trace

def interferenceAccess_0 : Step → Bool
  | Step.s0 => false
  | Step.s1 => true
  | Step.s2 => false

def interference_0 (trace : Execution) : Prop := ∀ t, stepActor (trace.event t) = .environment → interferenceAccess_0 (trace.event t) = true

def interferenceSubject_0 : Component := Component.c1

def interferenceAccess_1 : Step → Bool
  | Step.s0 => true
  | Step.s1 => true
  | Step.s2 => true

def interference_1 (trace : Execution) : Prop := ∀ t, stepActor (trace.event t) = .component Component.c0 → interferenceAccess_1 (trace.event t) = true

def interferenceSubject_1 : Component := Component.c1

def relyRelation_0 (before after : Store) : Prop := (decide (after.v0 ≥ (0 : Int))) = true

def guaranteeRelation_0 (before after : Store) : Prop := ((decide ((before.v0 - after.v0) ≥ (0 : Int))) && (decide ((before.v0 - after.v0) ≤ (1 : Int)))) = true

def rely_0 (trace : Execution) : Prop := (interference_1 trace) ∧ (∀ t, stepActor (trace.event t) ≠ .component Component.c0 → relyRelation_0 (trace.state t) (trace.state (t + 1)))

def guarantee_0 (trace : Execution) : Prop := ∀ t, stepActor (trace.event t) = .component Component.c0 → guaranteeRelation_0 (trace.state t) (trace.state (t + 1))

def contract_0 (trace : Execution) : Prop := rely_0 trace → guarantee_0 trace

def relyRelation_1 (before after : Store) : Prop := (decide (after.v0 ≥ (0 : Int))) = true

def guaranteeRelation_1 (before after : Store) : Prop := ((decide ((after.v0 - before.v0) ≥ (0 : Int))) && (decide ((after.v0 - before.v0) ≤ (1 : Int)))) = true

def rely_1 (trace : Execution) : Prop := (interference_0 trace) ∧ (interference_1 trace) ∧ (∀ t, stepActor (trace.event t) ≠ .component Component.c1 → relyRelation_1 (trace.state t) (trace.state (t + 1)))

def guarantee_1 (trace : Execution) : Prop := ∀ t, stepActor (trace.event t) = .component Component.c1 → guaranteeRelation_1 (trace.state t) (trace.state (t + 1))

def contract_1 (trace : Execution) : Prop := rely_1 trace → guarantee_1 trace

def linearizationRelation_0 (before after : Store) : Prop := (decide ((before.v0 - after.v0) = (1 : Int))) = true

def linearizationObligation_0 : Prop := ∀ before after, stepRelation Step.s0 before after → linearizationRelation_0 before after

def abstractOperation_0 : String := "AbstractDequeue"

def linearizationRelation_1 (before after : Store) : Prop := (decide ((after.v0 - before.v0) = (1 : Int))) = true

def linearizationObligation_1 : Prop := ∀ before after, stepRelation Step.s2 before after → linearizationRelation_1 before after

def abstractOperation_1 : String := "AbstractEnqueue"

def schedule_0 (events : List Step) : Prop := events.length ≤ 8 ∧ ∀ step ∈ events, step ∈ [Step.s0, Step.s2]

def channelSend_0 {Value : String → Type} (sender : Component) (value : Value "Item") (before after : List (Value "Item")) : Prop := sender ∈ [Component.c1, Component.c0] ∧ after = before ++ [value] ∧ before.length ≤ 4 ∧ after.length ≤ 4

def channelReceive_0 {Value : String → Type} (receiver : Component) (value : Value "Item") (before after : List (Value "Item")) : Prop := receiver ∈ [Component.c1, Component.c0] ∧ before = value :: after ∧ before.length ≤ 4 ∧ after.length ≤ 4

def channelPayloadSort_0 : String := "Item"

structure SessionAction where
  identity : String
  polarity : String
  label : String
  payloadSort : String
  next : List String
  deriving DecidableEq, BEq

def dualPolarity : String → String
  | "send" => "receive"
  | "receive" => "send"
  | other => other

def sessionDual (left right : List SessionAction) : Bool := left.all (fun action => right.any (fun other => other.identity == action.identity && other.polarity == dualPolarity action.polarity && other.label == action.label && other.payloadSort == action.payloadSort && other.next == action.next)) && left.length == right.length

def sessionActions_0 : List SessionAction := [⟨"sess:req", "send", "request", "Item", ["sess:ack"]⟩, ⟨"sess:ack", "receive", "ack", "Ack", ["sess:end"]⟩, ⟨"sess:end", "end", "end", "", []⟩]

def sessionEntry_0 : String := "sess:req"

def sessionStep_0 (current polarity payloadSort : String) (next : Option String) : Prop := ∃ action, action ∈ sessionActions_0 ∧ action.identity = current ∧ action.polarity = polarity ∧ action.payloadSort = payloadSort ∧ (match next with | none => action.polarity = "end" | some following => following ∈ action.next)

def sessionActions_1 : List SessionAction := [⟨"sess:req", "receive", "request", "Item", ["sess:ack"]⟩, ⟨"sess:ack", "send", "ack", "Ack", ["sess:end"]⟩, ⟨"sess:end", "end", "end", "", []⟩]

def sessionEntry_1 : String := "sess:req"

def sessionStep_1 (current polarity payloadSort : String) (next : Option String) : Prop := ∃ action, action ∈ sessionActions_1 ∧ action.identity = current ∧ action.polarity = polarity ∧ action.payloadSort = payloadSort ∧ (match next with | none => action.polarity = "end" | some following => following ∈ action.next)

def sessionDuality_0 : Bool := sessionDual sessionActions_0 sessionActions_1

def sessionDuality_1 : Bool := sessionDual sessionActions_1 sessionActions_0

def declaredSpecification (trace : Execution) : Prop := (validExecution trace) ∧ (fairness_0 trace) ∧ (fairness_1 trace) ∧ (interference_0 trace) ∧ (interference_1 trace) ∧ (contract_0 trace) ∧ (contract_1 trace)

def nativeConcurrencyEvidence : List String := ["{\"atomic_regions\":[{\"atomicity\":\"atomic\",\"attributes\":{},\"component_id\":\"comp:consumer\",\"region_id\":\"atom:cons\",\"schema_version\":\"atomic-region/v1\",\"statement\":\"consume is atomic\",\"step_ids\":[\"step:cons-read\"]},{\"atomicity\":\"atomic\",\"attributes\":{},\"component_id\":\"comp:producer\",\"region_id\":\"atom:prod\",\"schema_version\":\"atomic-region/v1\",\"statement\":\"produce is atomic\",\"step_ids\":[\"step:prod-write\"]}],\"channels\":[{\"attributes\":{},\"capacity\":4,\"channel_id\":\"chan:items\",\"endpoint_component_ids\":[\"comp:producer\",\"comp:consumer\"],\"mode\":\"buffered\",\"name\":\"items\",\"payload_sort\":\"Item\",\"schema_version\":\"concurrent-channel/v1\"}],\"components\":[{\"attributes\":{},\"component_id\":\"comp:consumer\",\"kind\":\"thread\",\"local_variable_ids\":[],\"name\":\"Consumer\",\"schema_version\":\"concurrent-component/v1\",\"step_ids\":[\"step:cons-read\"]},{\"attributes\":{},\"component_id\":\"comp:producer\",\"kind\":\"thread\",\"local_variable_ids\":[],\"name\":\"Producer\",\"schema_version\":\"concurrent-component/v1\",\"step_ids\":[\"step:prod-write\"]}],\"document_id\":\"bafkreigl64a2nd3yrianierskuszgk42jkrq7yozt2z6ewwymi7kqvjcwe\",\"fairness\":[{\"attributes\":{},\"component_ids\":[\"comp:consumer\"],\"fairness_id\":\"fair:cons\",\"kind\":\"weak\",\"schema_version\":\"concurrency-fairness/v1\",\"statement\":\"Consumer is weakly fair.\",\"step_ids\":[]},{\"attributes\":{},\"component_ids\":[],\"fairness_id\":\"fair:prod\",\"kind\":\"weak\",\"schema_version\":\"concurrency-fairness/v1\",\"statement\":\"Producer is weakly fair.\",\"step_ids\":[\"step:prod-write\"]}],\"interface\":\"ConcurrencyIR@1\",\"interference\":[{\"attributes\":{},\"interference_id\":\"intf:env-buffer\",\"interferer_component_id\":\"\",\"interferer_is_environment\":true,\"kind\":\"read\",\"schema_version\":\"interference-assumption/v1\",\"shared_variable_ids\":[\"var:buffer\"],\"statement\":\"Environment may observe the buffer.\",\"subject_component_id\":\"comp:producer\"},{\"attributes\":{},\"interference_id\":\"intf:peer\",\"interferer_component_id\":\"comp:consumer\",\"interferer_is_environment\":false,\"kind\":\"both\",\"schema_version\":\"interference-assumption/v1\",\"shared_variable_ids\":[\"var:buffer\"],\"statement\":\"Consumer may read and write the buffer while producer runs.\",\"subject_component_id\":\"comp:producer\"}],\"linearizability_points\":[{\"abstract_operation\":\"AbstractDequeue\",\"attributes\":{},\"point_id\":\"lin:cons\",\"schema_version\":\"linearizability-point/v1\",\"statement\":\"consume linearizes at the read\",\"step_id\":\"step:cons-read\"},{\"abstract_operation\":\"AbstractEnqueue\",\"attributes\":{},\"point_id\":\"lin:prod\",\"schema_version\":\"linearizability-point/v1\",\"statement\":\"produce linearizes at the write\",\"step_id\":\"step:prod-write\"}],\"metadata\":{\"example\":\"producer-consumer\"},\"rely_guarantee\":[{\"attributes\":{},\"component_id\":\"comp:consumer\",\"contract_id\":\"rg:consumer\",\"guarantee_statement\":\"buffer decreases by at most one\",\"interference_ids\":[\"intf:peer\"],\"rely_statement\":\"buffer stays non-negative\",\"schema_version\":\"rely-guarantee-contract/v1\",\"shared_variable_ids\":[\"var:buffer\"]},{\"attributes\":{},\"component_id\":\"comp:producer\",\"contract_id\":\"rg:producer\",\"guarantee_statement\":\"buffer increases by at most one\",\"interference_ids\":[\"intf:env-buffer\",\"intf:peer\"],\"rely_statement\":\"buffer stays non-negative\",\"schema_version\":\"rely-guarantee-contract/v1\",\"shared_variable_ids\":[\"var:buffer\"]}],\"require_fairness\":true,\"require_interference\":true,\"schedules\":[{\"attributes\":{},\"claims_unbounded_refinement\":false,\"component_ids\":[\"comp:consumer\",\"comp:producer\"],\"max_steps\":8,\"schedule_id\":\"sched:depth-8\",\"schema_version\":\"bounded-schedule/v1\",\"statement\":\"explore at most 8 interleavings\",\"step_ids\":[]}],\"schema_version\":\"concurrency-ir/v1\",\"sessions\":[{\"actions\":[{\"action_id\":\"sess:req\",\"attributes\":{},\"continuation_action_ids\":[\"sess:ack\"],\"label\":\"request\",\"payload_sort\":\"Item\",\"polarity\":\"send\",\"schema_version\":\"session-action/v1\"},{\"action_id\":\"sess:ack\",\"attributes\":{},\"continuation_action_ids\":[\"sess:end\"],\"label\":\"ack\",\"payload_sort\":\"Ack\",\"polarity\":\"receive\",\"schema_version\":\"session-action/v1\"},{\"action_id\":\"sess:end\",\"attributes\":{},\"continuation_action_ids\":[],\"label\":\"end\",\"payload_sort\":\"\",\"polarity\":\"end\",\"schema_version\":\"session-action/v1\"}],\"attributes\":{},\"dual_protocol_id\":\"sess:server\",\"entry_action_id\":\"sess:req\",\"name\":\"ItemClient\",\"protocol_id\":\"sess:client\",\"role\":\"client\",\"schema_version\":\"session-protocol/v1\"},{\"actions\":[{\"action_id\":\"sess:req\",\"attributes\":{},\"continuation_action_ids\":[\"sess:ack\"],\"label\":\"request\",\"payload_sort\":\"Item\",\"polarity\":\"receive\",\"schema_version\":\"session-action/v1\"},{\"action_id\":\"sess:ack\",\"attributes\":{},\"continuation_action_ids\":[\"sess:end\"],\"label\":\"ack\",\"payload_sort\":\"Ack\",\"polarity\":\"send\",\"schema_version\":\"session-action/v1\"},{\"action_id\":\"sess:end\",\"attributes\":{},\"continuation_action_ids\":[],\"label\":\"end\",\"payload_sort\":\"\",\"polarity\":\"end\",\"schema_version\":\"session-action/v1\"}],\"attributes\":{},\"dual_protocol_id\":\"sess:client\",\"entry_action_id\":\"sess:req\",\"name\":\"ItemServer\",\"protocol_id\":\"sess:server\",\"role\":\"server\",\"schema_version\":\"session-protocol/v1\"}],\"shared_variable_ids\":[\"var:buffer\"],\"steps\":[{\"atomic_region_id\":\"atom:cons\",\"attributes\":{},\"component_id\":\"comp:consumer\",\"effect_statement\":\"buffer := buffer - 1\",\"guard_statement\":\"buffer > 0\",\"label\":\"consume\",\"owner\":\"component\",\"read_variable_ids\":[\"var:buffer\"],\"schema_version\":\"concurrent-step/v1\",\"step_id\":\"step:cons-read\",\"write_variable_ids\":[\"var:buffer\"]},{\"atomic_region_id\":\"\",\"attributes\":{},\"component_id\":\"\",\"effect_statement\":\"may read buffer\",\"guard_statement\":\"true\",\"label\":\"environment interference\",\"owner\":\"environment\",\"read_variable_ids\":[\"var:buffer\"],\"schema_version\":\"concurrent-step/v1\",\"step_id\":\"step:env-noise\",\"write_variable_ids\":[]},{\"atomic_region_id\":\"atom:prod\",\"attributes\":{},\"component_id\":\"comp:producer\",\"effect_statement\":\"buffer := buffer + 1\",\"guard_statement\":\"buffer_space > 0\",\"label\":\"produce\",\"owner\":\"component\",\"read_variable_ids\":[\"var:buffer\"],\"schema_version\":\"concurrent-step/v1\",\"step_id\":\"step:prod-write\",\"write_variable_ids\":[\"var:buffer\"]}]}"]

def typedInterpretationEvidence : List String := ["{\"channel_semantics\":[{\"channel_id\":\"chan:items\",\"discipline\":\"fifo\",\"evidence_id\":\"fixture:explicit-FIFO-choice\"}],\"contracts\":[{\"contract_id\":\"rg:consumer\",\"evidence_id\":\"fixture:reviewed-contract:rg:consumer\",\"guarantee_expression_id\":\"decrease_bounded\",\"rely_expression_id\":\"nonnegative\"},{\"contract_id\":\"rg:producer\",\"evidence_id\":\"fixture:reviewed-contract:rg:producer\",\"guarantee_expression_id\":\"increase_bounded\",\"rely_expression_id\":\"nonnegative\"}],\"evidence_id\":\"fixture:explicit-authored-concurrency-interpretation\",\"expression_program\":{\"commands\":[{\"attributes\":{},\"command_id\":\"interpretation:carrier:return\",\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[],\"synchronizes\":false,\"writes\":[]},\"evaluation_order\":[\"interpretation:carrier:true\"],\"expression_ids\":[\"interpretation:carrier:true\"],\"kind\":\"return\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"target_symbol_ids\":[],\"undefined_behavior\":[]}],\"expressions\":[{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"buffer\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[\"buffer\"],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[\"buffer\",\"zero\"],\"expression_id\":\"can_consume\",\"kind\":\"binary\",\"operand_ids\":[\"buffer\",\"zero\"],\"operator\":\"gt\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"space\",\"zero\"],\"expression_id\":\"can_produce\",\"kind\":\"binary\",\"operand_ids\":[\"space\",\"zero\"],\"operator\":\"gt\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{\"value\":4},\"evaluation_order\":[],\"expression_id\":\"capacity\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[\"buffer\",\"one\"],\"expression_id\":\"consume\",\"kind\":\"binary\",\"operand_ids\":[\"buffer\",\"one\"],\"operator\":\"sub\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[\"old_buffer\",\"buffer\"],\"expression_id\":\"decrease\",\"kind\":\"binary\",\"operand_ids\":[\"old_buffer\",\"buffer\"],\"operator\":\"sub\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[\"decrease\",\"one\"],\"expression_id\":\"decrease_at_most_one\",\"kind\":\"binary\",\"operand_ids\":[\"decrease\",\"one\"],\"operator\":\"le\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"decrease_nonnegative\",\"decrease_at_most_one\"],\"expression_id\":\"decrease_bounded\",\"kind\":\"binary\",\"operand_ids\":[\"decrease_nonnegative\",\"decrease_at_most_one\"],\"operator\":\"and\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"decrease\",\"zero\"],\"expression_id\":\"decrease_nonnegative\",\"kind\":\"binary\",\"operand_ids\":[\"decrease\",\"zero\"],\"operator\":\"ge\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"decrease\",\"one\"],\"expression_id\":\"decrease_one\",\"kind\":\"binary\",\"operand_ids\":[\"decrease\",\"one\"],\"operator\":\"eq\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"buffer\",\"old_buffer\"],\"expression_id\":\"increase\",\"kind\":\"binary\",\"operand_ids\":[\"buffer\",\"old_buffer\"],\"operator\":\"sub\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[\"increase\",\"one\"],\"expression_id\":\"increase_at_most_one\",\"kind\":\"binary\",\"operand_ids\":[\"increase\",\"one\"],\"operator\":\"le\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"increase_nonnegative\",\"increase_at_most_one\"],\"expression_id\":\"increase_bounded\",\"kind\":\"binary\",\"operand_ids\":[\"increase_nonnegative\",\"increase_at_most_one\"],\"operator\":\"and\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"increase\",\"zero\"],\"expression_id\":\"increase_nonnegative\",\"kind\":\"binary\",\"operand_ids\":[\"increase\",\"zero\"],\"operator\":\"ge\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"increase\",\"one\"],\"expression_id\":\"increase_one\",\"kind\":\"binary\",\"operand_ids\":[\"increase\",\"one\"],\"operator\":\"eq\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{\"value\":true},\"evaluation_order\":[],\"expression_id\":\"interpretation:carrier:true\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"buffer\",\"zero\"],\"expression_id\":\"nonnegative\",\"kind\":\"binary\",\"operand_ids\":[\"buffer\",\"zero\"],\"operator\":\"ge\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"buffer\"],\"expression_id\":\"old_buffer\",\"kind\":\"old\",\"operand_ids\":[\"buffer\"],\"operator\":\"\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{\"value\":1},\"evaluation_order\":[],\"expression_id\":\"one\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[\"buffer\",\"one\"],\"expression_id\":\"produce\",\"kind\":\"binary\",\"operand_ids\":[\"buffer\",\"one\"],\"operator\":\"add\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[\"capacity\",\"buffer\"],\"expression_id\":\"space\",\"kind\":\"binary\",\"operand_ids\":[\"capacity\",\"buffer\"],\"operator\":\"sub\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{\"value\":true},\"evaluation_order\":[],\"expression_id\":\"true\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{\"value\":0},\"evaluation_order\":[],\"expression_id\":\"zero\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"}],\"functions\":[{\"cfg\":{\"blocks\":[{\"block_id\":\"interpretation:carrier:block\",\"command_ids\":[\"interpretation:carrier:return\"],\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[]}],\"edges\":[],\"entry_block_id\":\"interpretation:carrier:block\",\"exceptional_exit_block_ids\":[],\"graph_id\":\"interpretation:carrier:cfg\",\"normal_exit_block_ids\":[\"interpretation:carrier:block\"]},\"declared_exceptions\":[],\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[],\"synchronizes\":false,\"writes\":[]},\"exception_symbol_ids\":[],\"function_id\":\"interpretation:carrier:function\",\"local_symbol_ids\":[],\"name\":\"InterpretationExpressionCarrier\",\"parameter_symbol_ids\":[],\"purity\":\"pure\",\"result_symbol_id\":\"\",\"return_type\":\"boolean\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[]}],\"global_symbol_ids\":[\"buffer\"],\"metadata\":{},\"program_id\":\"bafkreidajq7yenji55duqq57aqwgpf3dqcll3mtnv4kg63szfqd4k5rkw4\",\"schema_version\":\"program-ir/v1\",\"sources\":[{\"container_sha256\":\"\",\"cont", "ainer_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"70bb17049af4b316dd8221b74ca4433c703d833e8bc6a8572bb7a853f569cfb1\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"source:authored-concurrency-interpretation\",\"review_status\":\"unreviewed\",\"source_id\":\"explicit-concurrency-interpretation\",\"source_revision\":\"fixture:v1\",\"source_uri\":\"urn:test:explicit-concurrency-interpretation\"}],\"spans\":[],\"symbols\":[{\"attributes\":{},\"kind\":\"global\",\"name\":\"buffer\",\"source_ref_ids\":[\"source:authored-concurrency-interpretation\"],\"span_ids\":[],\"symbol_id\":\"buffer\",\"type_ref\":\"integer\"}]},\"linearizations\":[{\"evidence_id\":\"fixture:reviewed-abstract-operation:lin:cons\",\"point_id\":\"lin:cons\",\"relation_expression_id\":\"decrease_one\"},{\"evidence_id\":\"fixture:reviewed-abstract-operation:lin:prod\",\"point_id\":\"lin:prod\",\"relation_expression_id\":\"increase_one\"}],\"native_document_sha256\":\"70bb17049af4b316dd8221b74ca4433c703d833e8bc6a8572bb7a853f569cfb1\",\"schema\":\"native-concurrency-interpretation/v1\",\"statement_bindings\":[{\"evidence_id\":\"fixture:reviewed-statement:/steps/0/guard_statement\",\"meaning\":\"typed_expression\",\"path\":\"/steps/0/guard_statement\",\"statement_sha256\":\"14d4eb186bd2e7c8d6e039520125091aa1d6c14799316715eb68ce77854557a9\"},{\"evidence_id\":\"fixture:reviewed-statement:/steps/0/effect_statement\",\"meaning\":\"typed_expression\",\"path\":\"/steps/0/effect_statement\",\"statement_sha256\":\"b08560eda9016849e7f9a7e99348b9f756a0a3054999a9bebd7e5114c2fefcba\"},{\"evidence_id\":\"fixture:reviewed-statement:/steps/1/guard_statement\",\"meaning\":\"typed_expression\",\"path\":\"/steps/1/guard_statement\",\"statement_sha256\":\"18d10c7d2b4b04aaf04254d1ae5d655a5dc0407cbcdd5a8c3986e985370f36ee\"},{\"evidence_id\":\"fixture:reviewed-statement:/steps/1/effect_statement\",\"meaning\":\"typed_expression\",\"path\":\"/steps/1/effect_statement\",\"statement_sha256\":\"c2254e6922cb9b4210902660cb0121592b196118d9b4c707401599553a4e62e9\"},{\"evidence_id\":\"fixture:reviewed-statement:/steps/2/guard_statement\",\"meaning\":\"typed_expression\",\"path\":\"/steps/2/guard_statement\",\"statement_sha256\":\"dbc1e0c509334824a3ee14f1458984ff90aba5176fee56c60ca7088530f0385d\"},{\"evidence_id\":\"fixture:reviewed-statement:/steps/2/effect_statement\",\"meaning\":\"typed_expression\",\"path\":\"/steps/2/effect_statement\",\"statement_sha256\":\"ea502cee9a04758a1e11548bc606f4ec9fe45d69a77183a9538bd1dc5022e86c\"},{\"evidence_id\":\"fixture:reviewed-statement:/atomic_regions/0/statement\",\"meaning\":\"native_structure\",\"path\":\"/atomic_regions/0/statement\",\"statement_sha256\":\"5ffd19da20945232291f85968a644ef61570a7efe915bc0e7afd0d68a0af44c9\"},{\"evidence_id\":\"fixture:reviewed-statement:/atomic_regions/1/statement\",\"meaning\":\"native_structure\",\"path\":\"/atomic_regions/1/statement\",\"statement_sha256\":\"78e5d5448b81fe100e61de9d9a45af973970fd6a083afe6379b02de6073db301\"},{\"evidence_id\":\"fixture:reviewed-statement:/interference/0/statement\",\"meaning\":\"native_structure\",\"path\":\"/interference/0/statement\",\"statement_sha256\":\"ca2e638f1d5c4d3fd6812899c185560c7cd5bc2d47c994a6cda7f8397af7ae05\"},{\"evidence_id\":\"fixture:reviewed-statement:/interference/1/statement\",\"meaning\":\"native_structure\",\"path\":\"/interference/1/statement\",\"statement_sha256\":\"0cae2676112a96119559a3f756f1e7dbed0a9960edaa8e4a0573b9e67b721a6f\"},{\"evidence_id\":\"fixture:reviewed-statement:/fairness/0/statement\",\"meaning\":\"native_structure\",\"path\":\"/fairness/0/statement\",\"statement_sha256\":\"c38488dc76eb16d1bd2b162f8d6dd1c438cc8a96386979f03f148e9a0902269f\"},{\"evidence_id\":\"fixture:reviewed-statement:/fairness/1/statement\",\"meaning\":\"native_structure\",\"path\":\"/fairness/1/statement\",\"statement_sha256\":\"d3ccdc7af629ccd627c6c7767bf30cfa23f6ab91cf09c67373933f9573f1e2de\"},{\"evidence_id\":\"fixture:reviewed-statement:/rely_guarantee/0/rely_statement\",\"meaning\":\"typed_expression\",\"path\":\"/rely_guarantee/0/rely_statement\",\"statement_sha256\":\"04c9add5451d0e65da2602d18ac59d96668e800b1322d2443a5eff453c531ed5\"},{\"evidence_id\":\"fixture:reviewed-statement:/rely_guarantee/0/guarantee_statement\",\"meaning\":\"typed_expression\",\"path\":\"/rely_guarantee/0/guarantee_statement\",\"statement_sha256\":\"726c49c2b7b029931f64a1c646f0ae7677695f5767d5cb9b4fd76758ffcc567f\"},{\"evidence_id\":\"fixture:reviewed-statement:/rely_guarantee/1/rely_statement\",\"meaning\":\"typed_expression\",\"path\":\"/rely_guarantee/1/rely_statement\",\"statement_sha256\":\"04c9add5451d0e65da2602d18ac59d96668e800b1322d2443a5eff453c531ed5\"},{\"evidence_id\":\"fixture:reviewed-statement:/rely_guarantee/1/guarantee_statement\",\"meaning\":\"typed_expression\",\"path\":\"/rely_guarantee/1/guarantee_statement\",\"statement_sha256\":\"b6fd4e53a57251ee9243a3666850d48dd8a1057ede1171fb82266eb000c6eea4\"},{\"evidence_id\":\"fixture:reviewed-statement:/linearizability_points/0/statement\",\"meaning\":\"typed_expression\",\"path\":\"/linearizability_points/0/statement\",\"statement_sha256\":\"888f9cb5049993a52f4cf257249163c438780a1fd941ad31f1b5ec830ece20bd\"},{\"evidence_id\":\"fixture:reviewed-statement:/linearizability_points/0/abstract_operation\",\"meaning\":\"typed_expression\",\"path\":\"/linearizability_points/0/abstract_operation\",\"statement_sha256\":\"a8998c1bcadef42e9c88e9ec9ef3ca82259434048a042e4d64acab38ca4e0855\"},{\"evidence_id\":\"fixture:reviewed-statement:/linearizability_points/1/statement\",\"meaning\":\"typed_expression\",\"path\":\"/linearizability_points/1/statement\",\"statement_sha256\":\"cc6360e38f159c154e94570011006cd55abbc44aa7aad89da8e07e4434c8b7c3\"},{\"evidence_id\":\"fixture:reviewed-statement:/linearizability_points/1/abstract_operation\",\"meaning\":\"typed_expression\",\"path\":\"/linearizability_points/1/abstract_operation\",\"statement_sha256\":\"ef1f97d11a820116a0bd1a17d69f4db7255038a17482ab0f3f064895240cc4ec\"},{\"evidence_id\":\"fixture:reviewed-statement:/schedules/0/statement\",\"meaning\":\"native_structure\",\"path\":\"/schedules/0/statement\",\"statement_sha256\":\"7b84854b6d1e51f53ef4fa16d8becd27e2f8be6dda90f341b100375d2a2c9b43\"},{\"evidence_id\":\"fixture:reviewed-statement:/metadata/example\",\"meaning\":\"descriptive\",\"path\":\"/metadata/example\",\"statement_sha256\":\"933fceaae0d4c380b258e36927f880e541eb6956be520b576b54d34eb67c6a37\"}],\"steps\":[{\"evidence_id\":\"fixture:reviewed-step:step:cons-read\",\"guard_expression_id\":\"can_consume\",\"step_id\":\"step:cons-read\",\"updates\":{\"var:buffer\":\"consume\"}},{\"evidence_id\":\"fixture:reviewed-step:step:env-noise\",\"guard_expression_id\":\"true\",\"step_id\":\"step:env-noise\",\"updates\":{}},{\"evidence_id\":\"fixture:reviewed-step:step:prod-write\",\"guard_expression_id\":\"can_produce\",\"step_id\":\"step:prod-write\",\"updates\":{\"var:buffer\":\"produce\"}}],\"surface_aliases\":{\"buffer_space\":\"space\"},\"variable_symbols\":{\"var:buffer\":\"buffer\"}}"]

def sourceSemanticsVerified : Bool := false

def channelStoreCouplingVerified : Bool := false

def sessionExecutionLinked : Bool := false

def globalLinearizabilityVerified : Bool := false
end Projection_1

namespace Projection_2
set_option linter.unusedVariables false
inductive Term where
  | atom : String → String → Term
  | literal : String → String → Term
  | app : String → String → List Term → Term
  deriving Repr
def termSort : Term → String
  | .atom sort _ => sort
  | .literal sort _ => sort
  | .app sort _ _ => sort
structure Message where
  identifier : String
  sender : String
  receivers : List String
  channel : String
  payload : Term
  deriving Repr
structure Event where
  identifier : String
  role : String
  phase : String
  parameters : List Term
  deriving Repr
inductive Step where
  | event : String → Step
  | send : String → Step
  | inject : String → Term → Step
  | drop : String → Step
  | replay : String → Step
  deriving Repr
abbrev Trace := List Step
def eventOccurs (trace : Trace) (identifier : String) : Prop := Step.event identifier ∈ trace
def eventAt (trace : Trace) (identifier : String) (position : Nat) : Prop :=
  trace[position]? = some (.event identifier)

def retainedProtocolJSON : String := "{\"adversary\":{\"adversary_id\":\"adversary:network\",\"capabilities\":[\"compose\",\"decompose\",\"drop\",\"inject\",\"intercept\",\"replay\"],\"compromised_key_ids\":[],\"compromised_role_ids\":[],\"kind\":\"dolev_yao\",\"knowledge\":[{\"available_after_event_ids\":[],\"knowledge_id\":\"knowledge:public-key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"term\":{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:key\",\"symbol_id\":\"key:initiator-public\"}}],\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},\"channels\":[{\"adversary_access\":\"control\",\"assumption_ids\":[],\"channel_id\":\"channel:network\",\"name\":\"network\",\"security\":\"public\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}],\"claims\":[{\"antecedent_event_ids\":[\"event:accept\"],\"assumption_ids\":[\"assumption:session-key\"],\"claim_id\":\"claim:authentication\",\"consequent_event_ids\":[\"event:begin\"],\"correspondence\":\"injective\",\"kind\":\"authentication\",\"left_terms\":[],\"reachable_event_ids\":[],\"right_terms\":[],\"secret_terms\":[],\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"Every accept authenticates an initiator run.\"},{\"antecedent_event_ids\":[\"event:accept\"],\"assumption_ids\":[],\"claim_id\":\"claim:correspondence\",\"consequent_event_ids\":[\"event:begin\"],\"correspondence\":\"non_injective\",\"kind\":\"correspondence\",\"left_terms\":[],\"reachable_event_ids\":[],\"right_terms\":[],\"secret_terms\":[],\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"Accept events correspond to begin events.\"},{\"antecedent_event_ids\":[],\"assumption_ids\":[],\"claim_id\":\"claim:equivalence\",\"consequent_event_ids\":[],\"correspondence\":\"non_injective\",\"kind\":\"equivalence\",\"left_terms\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"left-observation\",\"sort\":\"sort:message\",\"symbol_id\":\"\"}],\"reachable_event_ids\":[],\"right_terms\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"right-observation\",\"sort\":\"sort:message\",\"symbol_id\":\"\"}],\"secret_terms\":[],\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"The two opaque observations are indistinguishable.\"},{\"antecedent_event_ids\":[],\"assumption_ids\":[],\"claim_id\":\"claim:reachable\",\"consequent_event_ids\":[],\"correspondence\":\"non_injective\",\"kind\":\"reachability\",\"left_terms\":[],\"reachable_event_ids\":[\"event:accept\"],\"right_terms\":[],\"secret_terms\":[],\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"The responder can accept.\"},{\"antecedent_event_ids\":[],\"assumption_ids\":[\"assumption:session-key\"],\"claim_id\":\"claim:secrecy\",\"consequent_event_ids\":[],\"correspondence\":\"non_injective\",\"kind\":\"secrecy\",\"left_terms\":[],\"reachable_event_ids\":[],\"right_terms\":[],\"secret_terms\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"}],\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"The challenge remains secret.\"}],\"document_id\":\"bafkreidrokny64uxwlu7pmyzvdzr63c6mlqasmqf4zzqmsgurh2uo4q45i\",\"equational_theories\":[\"free\",\"symmetric_encryption\"],\"events\":[{\"event_id\":\"event:accept\",\"name\":\"AcceptChallenge\",\"parameters\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"}],\"phase\":\"accept\",\"role_id\":\"role:responder\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"event_id\":\"event:begin\",\"name\":\"BeginChallenge\",\"parameters\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"}],\"phase\":\"begin\",\"role_id\":\"role:initiator\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}],\"fresh_names\":[{\"generated_by_role_id\":\"role:initiator\",\"kind\":\"nonce\",\"name\":\"challenge\",\"name_id\":\"name:challenge\",\"sort\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}],\"functions\":[{\"function_id\":\"function:decrypt\",\"kind\":\"destructor\",\"name\":\"decrypt\",\"parameter_sorts\":[\"sort:message\",\"sort:key\"],\"result_sort\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"theory\":\"symmetric_encryption\"},{\"function_id\":\"function:encrypt\",\"kind\":\"constructor\",\"name\":\"encrypt\",\"parameter_sorts\":[\"sort:nonce\",\"sort:key\"],\"result_sort\":\"sort:message\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"theory\":\"symmetric_encryption\"}],\"interface\":\"ProtocolIR@1\",\"keys\":[{\"key_id\":\"key:initiator-private\",\"kind\":\"private\",\"name\":\"initiator_private\",\"owner_role_ids\":[\"role:initiator\"],\"peer_key_id\":\"key:initiator-public\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"key_id\":\"key:initiator-public\",\"kind\":\"public\",\"name\":\"initiator_public\",\"owner_role_ids\":[\"role:initiator\"],\"peer_key_id\":\"key:initiator-private\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"key_id\":\"key:session\",\"kind\":\"symmetric\",\"name\":\"session_key\",\"owner_role_ids\":[\"role:initiator\",\"role:responder\"],\"peer_key_id\":\"\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}],\"messages\":[{\"channel_id\":\"channel:network\",\"message_id\":\"message:challenge\",\"name\":\"encrypted challenge\",\"payload\":{\"arguments\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"},{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:key\",\"symbol_id\":\"key:session\"}],\"function_id\":\"function:encrypt\",\"literal\":\"\",\"sort\":\"sort:message\",\"symbol_id\":\"\"},\"receiver_role_ids\":[\"role:responder\"],\"sender_role_id\":\"role:initiator\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}],\"metadata\":{\"protocol\":\"challenge-response\",\"version\":1},\"observations\":{},\"rewrite_facts\":[{\"fact_id\":\"fact:decrypt-encrypt\",\"left\":{\"arguments\":[{\"arguments\":[{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"},{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:key\",\"symbol_id\":\"key:session\"}],\"function_id\":\"function:encrypt\",\"literal\":\"\",\"sort\":\"sort:message\",\"symbol_id\":\"\"},{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:key\",\"symbol_id\":\"key:session\"}],\"function_id\":\"function:decrypt\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"\"},\"right\":{\"arguments\":[],\"function_id\":\"\",\"literal\":\"\",\"sort\":\"sort:nonce\",\"symbol_id\":\"name:challenge\"},\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"theory\":\"symmetric_encryption\"}],\"roles\":[{\"name\":\"Initiator\",\"parameter_ids\":[\"variable:initiator-peer\"],\"role_id\":\"role:initiator\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"name\":\"Responder\",\"parameter_ids\":[\"variable:responder-peer\"],\"role_id\":\"role:responder\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}],\"schema_version\":\"protocol-ir/v1\",\"sorts\":[{\"kind\":\"agent\",\"name\":\"Agent\",\"sort_id\":\"sort:agent\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"key\",\"name\":\"Key\",\"sort_id\":\"sort:key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"message\",\"name\":\"Message\",\"sort_id\":\"sort:message\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"nonce\",\"name\":\"Nonce\",\"sort_id\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}],\"sources\":[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"bafkreibhobfew27xqgi4vu4h3lkcdya5t7chmab7jsfgzp5yvu2sevjy44\",\"content_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"review_status\":\"unreviewed\",\"source_id\":\"fixture.py\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"code-unit:bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"}],\"spans\":[{\"end_byte\":83,\"end_char\":null,\"end_column\":2,\"end_line\":40,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:protocol\",\"start_byte\":0,\"start_char\":null,\"start_column\":1,\"start_line\":1}],\"trust_assumptions\":[{\"assumption_id\":\"assumption:session-key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"statement\":\"The long-term mechanism delivers the session key only to both roles.\",\"trusted_key_ids\":[\"key:session\"],\"trusted_role_ids\":[\"role:initiator\",\"role:responder\"]}],\"variables\":[{\"name\":\"peer\",\"role_id\":\"role:initiator\",\"sort\":\"sort:agent\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"variable_id\":\"variable:initiator-peer\"},{\"name\":\"peer\",\"role_id\":\"role:responder\",\"sort\":\"sort:agent\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"variable_id\":\"variable:responder-peer\"}]}"
def capabilities : List String := ["compose", "decompose", "drop", "inject", "intercept", "replay"]
def hasCapability (name : String) : Bool := capabilities.contains name
def compromisedKeys : List String := []
def rolesDeclarations : String := "[{\"name\":\"Initiator\",\"parameter_ids\":[\"variable:initiator-peer\"],\"role_id\":\"role:initiator\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"name\":\"Responder\",\"parameter_ids\":[\"variable:responder-peer\"],\"role_id\":\"role:responder\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}]"
def variablesDeclarations : String := "[{\"name\":\"peer\",\"role_id\":\"role:initiator\",\"sort\":\"sort:agent\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"variable_id\":\"variable:initiator-peer\"},{\"name\":\"peer\",\"role_id\":\"role:responder\",\"sort\":\"sort:agent\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"],\"variable_id\":\"variable:responder-peer\"}]"
def sortsDeclarations : String := "[{\"kind\":\"agent\",\"name\":\"Agent\",\"sort_id\":\"sort:agent\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"key\",\"name\":\"Key\",\"sort_id\":\"sort:key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"message\",\"name\":\"Message\",\"sort_id\":\"sort:message\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"kind\":\"nonce\",\"name\":\"Nonce\",\"sort_id\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}]"
def fresh_namesDeclarations : String := "[{\"generated_by_role_id\":\"role:initiator\",\"kind\":\"nonce\",\"name\":\"challenge\",\"name_id\":\"name:challenge\",\"sort\":\"sort:nonce\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}]"
def keysDeclarations : String := "[{\"key_id\":\"key:initiator-private\",\"kind\":\"private\",\"name\":\"initiator_private\",\"owner_role_ids\":[\"role:initiator\"],\"peer_key_id\":\"key:initiator-public\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"key_id\":\"key:initiator-public\",\"kind\":\"public\",\"name\":\"initiator_public\",\"owner_role_ids\":[\"role:initiator\"],\"peer_key_id\":\"key:initiator-private\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]},{\"key_id\":\"key:session\",\"kind\":\"symmetric\",\"name\":\"session_key\",\"owner_role_ids\":[\"role:initiator\",\"role:responder\"],\"peer_key_id\":\"\",\"sort\":\"sort:key\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:protocol\"]}]"
def messages : List Message := [⟨"message:challenge", "role:initiator", ["role:responder"], "channel:network", (.app "sort:message" "function:encrypt" [(.atom "sort:nonce" "name:challenge"), (.atom "sort:key" "key:session")])⟩]
def message (identifier : String) : Option Message := messages.find? fun m => m.identifier == identifier
def events : List Event := [⟨"event:accept", "role:responder", "accept", [(.atom "sort:nonce" "name:challenge")]⟩, ⟨"event:begin", "role:initiator", "begin", [(.atom "sort:nonce" "name:challenge")]⟩]
def eventDeclared (identifier : String) : Bool := events.any fun e => e.identifier == identifier
def observableChannels : List String := ["channel:network"]
def injectableChannels : List String := ["channel:network"]
def replayableChannels : List String := ["channel:network"]
def controlledChannels : List String := ["channel:network"]
def visible (channel : String) : Bool := hasCapability "intercept" && observableChannels.contains channel
def observedStep : Step → List Term
  | .event _ => []
  | .drop _ => []
  | .send identifier | .replay identifier => match message identifier with
    | some m => if visible m.channel then [m.payload] else []
    | none => []
  | .inject channel value => if visible channel then [value] else []
def observed (trace : Trace) : List Term := trace.flatMap observedStep

def initialKnowledge : List Term := [(.atom "sort:key" "key:initiator-public"), (.atom "sort:key" "key:initiator-public")]
def conditionallyKnown (trace : Trace) (value : Term) : Prop := False
def functionAllowed (kind function result : String) (arguments : List Term) : Prop := (kind = "destructor" ∧ function = "function:decrypt" ∧ result = "sort:nonce" ∧ arguments.map termSort = ["sort:message", "sort:key"]) ∨ (kind = "constructor" ∧ function = "function:encrypt" ∧ result = "sort:message" ∧ arguments.map termSort = ["sort:nonce", "sort:key"])
inductive Reduces : Term → Term → Prop where
  | declared_0 : Reduces (.app "sort:nonce" "function:decrypt" [(.app "sort:message" "function:encrypt" [(.atom "sort:nonce" "name:challenge"), (.atom "sort:key" "key:session")]), (.atom "sort:key" "key:session")]) (.atom "sort:nonce" "name:challenge")
  | symmetric (plain key : Term) : termSort plain = "sort:nonce" → termSort key = "sort:key" → Reduces (.app "sort:nonce" "function:decrypt" [(.app "sort:message" "function:encrypt" [plain, key]), key]) plain
  | context (sort function : String) (before after : List Term) (left right : Term) :
      Reduces left right →
      Reduces (.app sort function (before ++ left :: after)) (.app sort function (before ++ right :: after))
inductive Knows (trace : Trace) : Term → Prop where
  | initial (value : Term) : value ∈ initialKnowledge → Knows trace value
  | conditional (value : Term) : conditionallyKnown trace value → Knows trace value
  | observe (value : Term) : value ∈ observed trace → Knows trace value
  | compose (function result : String) (arguments : List Term) :
      hasCapability "compose" = true → functionAllowed "constructor" function result arguments →
      (∀ value, value ∈ arguments → Knows trace value) → Knows trace (.app result function arguments)
  | decompose (function result : String) (arguments : List Term) (output : Term) :
      hasCapability "decompose" = true → functionAllowed "destructor" function result arguments →
      (∀ value, value ∈ arguments → Knows trace value) →
      Reduces (.app result function arguments) output → Knows trace output
  | reduction (left right : Term) : Knows trace left → Reduces left right → Knows trace right
def previouslySent (trace : Trace) (identifier : String) : Prop :=
  Step.send identifier ∈ trace ∨ Step.replay identifier ∈ trace
def validStep (history : Trace) : Step → Prop
  | .event identifier => eventDeclared identifier = true
  | .send identifier => (message identifier).isSome = true
  | .inject channel value => hasCapability "inject" = true ∧
      channel ∈ injectableChannels ∧ Knows history value
  | .drop identifier => ∃ m, message identifier = some m ∧ hasCapability "drop" = true ∧
      m.channel ∈ controlledChannels ∧ previouslySent history identifier
  | .replay identifier => ∃ m, message identifier = some m ∧ hasCapability "replay" = true ∧
      m.channel ∈ replayableChannels ∧ previouslySent history identifier
def validTrace (trace : Trace) : Prop :=
  ∀ history step suffix, trace = history ++ step :: suffix → validStep history step
structure ProtocolInterpretation where
  permitted : Trace → Prop
  trustPremise : String → Prop
def executions (i : ProtocolInterpretation) (trace : Trace) : Prop := i.permitted trace ∧ validTrace trace
def correspondence (trace : Trace) (antecedent consequent : String) : Prop :=
  ∀ position, eventAt trace antecedent position →
    ∃ earlier, earlier < position ∧ eventAt trace consequent earlier
def injectiveCorrespondence (trace : Trace) (antecedent consequent : String) : Prop :=
  ∃ matching : Nat → Nat,
    (∀ position, eventAt trace antecedent position → matching position < position ∧
      eventAt trace consequent (matching position)) ∧
    (∀ first second, eventAt trace antecedent first → eventAt trace antecedent second →
      matching first = matching second → first = second)

def trust_0 (i : ProtocolInterpretation) : Prop := i.trustPremise "{\"assumption_id\":\"assumption:session-key\",\"statement\":\"The long-term mechanism delivers the session key only to both roles.\",\"trusted_key_ids\":[\"key:session\"],\"trusted_role_ids\":[\"role:initiator\",\"role:responder\"]}" ∧ ∀ key, key ∈ ["key:session"] → key ∉ compromisedKeys
def retainedStaticFrameInterpretation : String := "{\"claim_ids\":[\"claim:equivalence\"],\"mode\":\"static_observation_vectors\",\"native_document_sha256\":\"cbffc5659492ea419d8e4d4d595c9fd9d75ad30257edb8843ac6097b93f4f511\",\"schema\":\"protocol-static-frame-interpretation/v1\"}"
def frameSortKnown (sort : String) : Bool := ["sort:agent", "sort:key", "sort:message", "sort:nonce"].contains sort
def frameFunctionAccessible (function : String) : Bool := (function == "function:decrypt" && hasCapability "decompose") || (function == "function:encrypt" && hasCapability "compose")

mutual
  def frameTermEq (left right : Term) : Bool :=
    match left, right with
    | .atom sort value, .atom otherSort other => sort == otherSort && value == other
    | .literal sort value, .literal otherSort other => sort == otherSort && value == other
    | .app sort function args, .app otherSort otherFunction others =>
      sort == otherSort && function == otherFunction && frameTermsEq args others
    | _, _ => false
  termination_by sizeOf left
  def frameTermsEq (left right : List Term) : Bool :=
    match left, right with
    | [], [] => true
    | first :: tail, other :: rest => frameTermEq first other && frameTermsEq tail rest
    | _, _ => false
  termination_by sizeOf left
end
theorem frameTermEq_exact (left : Term) : ∀ right, frameTermEq left right = true ↔ left = right := by
  refine Term.rec (motive_1 := fun a => ∀ b, frameTermEq a b = true ↔ a = b)
    (motive_2 := fun xs => ∀ ys, frameTermsEq xs ys = true ↔ xs = ys) ?_ ?_ ?_ ?_ ?_ left
  · intro sort symbol right
    cases right <;> simp [frameTermEq]
  · intro sort value right
    cases right <;> simp [frameTermEq]
  · intro sort function arguments ih right
    cases right <;> simp [frameTermEq, ih, and_assoc]
  · intro ys
    cases ys <;> simp [frameTermsEq]
  · intro head tail ihHead ihTail ys
    cases ys <;> simp [frameTermsEq, ihHead, ihTail]

def frameApply (function : String) (arguments : List Term) : Option Term :=
  if function == "function:decrypt" && arguments.map termSort == ["sort:message", "sort:key"] then
    match arguments with
    | [.app sort constructor [plain, key], supplied] =>
      if sort == "sort:message" && constructor == "function:encrypt" && frameTermEq key supplied then some plain else none
    | _ => none
  else
  if function == "function:encrypt" && arguments.map termSort == ["sort:nonce", "sort:key"] then
    some (.app "sort:message" function arguments)
  else
  none

inductive ObserverRecipe where
  | handle : Nat → ObserverRecipe
  | initial : Nat → ObserverRecipe
  | literal : String → String → ObserverRecipe
  | apply : String → List ObserverRecipe → ObserverRecipe
  deriving Repr
def frameNormalize (term : Term) : Option Term :=
  match term with
  | .atom sort symbol => some (.atom sort symbol)
  | .literal sort value => some (.literal sort value)
  | .app _ function arguments => do
    let values ← arguments.attach.mapM (fun child => frameNormalize child.val)
    frameApply function values
termination_by sizeOf term
decreasing_by
  simp_wf
  have h := List.sizeOf_lt_of_mem child.property
  omega
def frameEvaluate (frame : List Term) (recipe : ObserverRecipe) : Option Term :=
  match recipe with
  | .handle index => frame[index]?.bind frameNormalize
  | .initial index => initialKnowledge[index]?.bind frameNormalize
  | .literal sort value =>
    if frameSortKnown sort then some (.literal sort value) else none
  | .apply function arguments => do
    if !frameFunctionAccessible function then none else do
      let values ← arguments.attach.mapM (fun child => frameEvaluate frame child.val)
      frameApply function values
termination_by sizeOf recipe
decreasing_by
  simp_wf
  have h := List.sizeOf_lt_of_mem child.property
  omega
def frameObservation (frame : List Term) (first second : ObserverRecipe) : Option Bool := do
  let left ← frameEvaluate frame first
  let right ← frameEvaluate frame second
  pure (frameTermEq left right)
def staticFrameEquivalent (left right : List Term) : Prop :=
  ∀ first second, frameObservation left first second = frameObservation right first second

def frameClaim_0Left : List Term := [(.literal "sort:message" "left-observation")]
def frameClaim_0Right : List Term := [(.literal "sort:message" "right-observation")]
def frameClaim_0 : Prop := staticFrameEquivalent frameClaim_0Left frameClaim_0Right
theorem frameClaim_0_distinguishing_observation :
    frameObservation frameClaim_0Left (.handle 0) (.literal "sort:message" "left-observation") ≠ frameObservation frameClaim_0Right (.handle 0) (.literal "sort:message" "left-observation") := by
  simp [frameObservation, frameEvaluate, frameNormalize, frameApply, termSort, frameTermEq, frameTermsEq, frameFunctionAccessible, frameSortKnown, initialKnowledge, hasCapability, capabilities, frameClaim_0Left, frameClaim_0Right]
theorem frameClaim_0_not_equivalent : ¬ frameClaim_0 := by
  intro equivalence
  exact frameClaim_0_distinguishing_observation (equivalence (.handle 0) (.literal "sort:message" "left-observation"))

def query_0 (i : ProtocolInterpretation) : Prop := (trust_0 i) → (∀ trace, executions i trace → injectiveCorrespondence trace "event:accept" "event:begin")
def query_1 (i : ProtocolInterpretation) : Prop := (True) → (∀ trace, executions i trace → correspondence trace "event:accept" "event:begin")
def query_2 (i : ProtocolInterpretation) : Prop := (True) → (frameClaim_0)
def query_3 (i : ProtocolInterpretation) : Prop := (True) → (∃ trace, executions i trace ∧ eventOccurs trace "event:accept")
def query_4 (i : ProtocolInterpretation) : Prop := (trust_0 i) → (∀ trace, executions i trace → ∀ secret, secret ∈ [(.atom "sort:nonce" "name:challenge")] → ¬ Knows trace secret)
def protocolSecurityProved : Bool := false
def roleProcessesVerified : Bool := false

end Projection_2

namespace Projection_9
def distributedCodeUnitDeclarationJSON : String := "{\"authority\":\"non_authoritative\",\"config_cid\":\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\",\"language\":\"Python\",\"parent_cids\":[\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\"],\"path\":\"fixture.py\",\"payload\":{\"body_cid\":\"bafkreibhobfew27xqgi4vu4h3lkcdya5t7chmab7jsfgzp5yvu2sevjy44\",\"body_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\"},\"polarity\":\"fixed\",\"record_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"record_type\":\"code_unit\",\"schema_version\":\"cvefixes-security-ir-derived/v1\",\"source_cids\":[\"bafkreib53dxdjxuwasyfmkacziowr2ppwzuropcvx3eenduoq2s7ofu6lm\"],\"unit_kind\":\"function\"}"

def distributedCodeUnitJoinedProgramJSON : String := "{\"commands\":[{\"attributes\":{},\"command_id\":\"command:11\",\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"synchronizes\":false,\"writes\":[]},\"evaluation_order\":[\"expr:10\"],\"expression_ids\":[\"expr:10\"],\"kind\":\"return\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.stmt.4\"],\"target_symbol_ids\":[],\"undefined_behavior\":[]}],\"expressions\":[{\"attributes\":{},\"evaluation_order\":[\"expr:7\",\"expr:9\"],\"expression_id\":\"expr:10\",\"kind\":\"binary\",\"operand_ids\":[\"expr:7\",\"expr:9\"],\"operator\":\"lt\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.expr.5\"],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"expr:7\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.expr.6\"],\"symbol_ids\":[\"symbol:derive.capacity.parameter\"],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"expr:9\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.expr.8\"],\"symbol_ids\":[\"symbol:derive.threshold.parameter\"],\"type_ref\":\"integer\"}],\"functions\":[{\"cfg\":{\"blocks\":[{\"block_id\":\"block:entry\",\"command_ids\":[\"command:11\"],\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:function.derive.1\"]}],\"edges\":[],\"entry_block_id\":\"block:entry\",\"exceptional_exit_block_ids\":[],\"graph_id\":\"cfg:derive\",\"normal_exit_block_ids\":[\"block:entry\"]},\"declared_exceptions\":[],\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"synchronizes\":false,\"writes\":[]},\"exception_symbol_ids\":[],\"function_id\":\"function:derive\",\"local_symbol_ids\":[],\"name\":\"derive\",\"parameter_symbol_ids\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"purity\":\"pure\",\"result_symbol_id\":\"symbol:derive.result.result\",\"return_type\":\"boolean\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:function.derive.1\"]}],\"global_symbol_ids\":[],\"metadata\":{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"distributed_candidate_source_join\":{\"code_unit_cid\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"model_semantics_changed\":false,\"original_program_id\":\"bafkreibyj2ugewbtorxkoesz4ydtjnarwx4bycwexhlfbmf3jis2tuof6y\",\"original_program_sha256\":\"fda949f539b0d382feff6839af13f3566fe9af57fb0dd8847c280323c70c0311\",\"original_source_identifier\":\"source:source.py\",\"polarity_inferred\":false,\"schema\":\"distributed-384-derived-program-source-join/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\"},\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreie7bulxk6pm4cks2npna6aoddfusfc7zd5yld23ejqgwrcajfhi5a\",\"base_program_sha256\":\"f08ccf47a343537889b1b47087d779ee2c8e623697db448282d22a5e4d7224f1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"whole_program_semantics_verified\":false},\"program_id\":\"bafkreidj5csibtjglap4jqi7xve5mz4vqi3wapzcltbg2gmp4bxsb74dze\",\"schema_version\":\"program-ir/v1\",\"sources\":[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"bafkreibhobfew27xqgi4vu4h3lkcdya5t7chmab7jsfgzp5yvu2sevjy44\",\"content_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"review_status\":\"unreviewed\",\"source_id\":\"fixture.py\",\"source_revision\":\"domain-family-training/v2\",\"source_uri\":\"code-unit:bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"}],\"spans\":[{\"end_byte\":82,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.expr.5\",\"start_byte\":62,\"start_char\":null,\"start_column\":12,\"start_line\":2},{\"end_byte\":70,\"end_char\":null,\"end_column\":19,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.expr.6\",\"start_byte\":62,\"start_char\":null,\"start_column\":12,\"start_line\":2},{\"end_byte\":82,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.expr.8\",\"start_byte\":73,\"start_char\":null,\"start_column\":23,\"start_line\":2},{\"end_byte\":24,\"end_char\":null,\"end_column\":24,\"end_line\":1,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.param.capacity.2\",\"start_byte\":11,\"start_char\":null,\"start_column\":12,\"start_line\":1},{\"end_byte\":40,\"end_char\":null,\"end_column\":40,\"end_line\":1,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.param.threshold.3\",\"start_byte\":26,\"start_char\":null,\"start_column\":27,\"start_line\":1},{\"end_byte\":82,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:derive.stmt.4\",\"start_byte\":55,\"start_char\":null,\"start_column\":5,\"start_line\":2},{\"end_byte\":82,\"end_char\":null,\"end_column\":31,\"end_line\":2,\"metadata\":{},\"source_ref_id\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"span_id\":\"span:function.derive.1\",\"start_byte\":0,\"start_char\":null,\"start_column\":1,\"start_line\":1}],\"symbols\":[{\"attributes\":{},\"kind\":\"parameter\",\"name\":\"capacity\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.param.capacity.2\"],\"symbol_id\":\"symbol:derive.capacity.parameter\",\"type_ref\":\"integer\"},{\"attributes\":{},\"kind\":\"result\",\"name\":\"result\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:function.derive.1\"],\"symbol_id\":\"symbol:derive.result.result\",\"type_ref\":\"boolean\"},{\"attributes\":{},\"kind\":\"parameter\",\"name\":\"threshold\",\"source_ref_ids\":[\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\"],\"span_ids\":[\"span:derive.param.threshold.3\"],\"symbol_id\":\"symbol:derive.threshold.parameter\",\"type_ref\":\"integer\"}]}"

def distributedCodeUnitCandidateJSON : String := "{\"document\":{\"attributes\":{},\"evaluation_order\":[\"expr:capacity\",\"expr:threshold\"],\"expression_id\":\"expr:result\",\"kind\":\"binary\",\"operand_ids\":[\"expr:capacity\",\"expr:threshold\"],\"operator\":\"<\",\"source_ref_ids\":[\"source\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},\"kind\":\"program_expression\"}"

def distributedCodeUnitJoinAuditJSON : String := "{\"caller_polarity_verified\":false,\"candidate_sha256\":\"3cbbc43010f0a11fcb121b0e62b00eea3033cc22322ac37838e68a5bee36d3cd\",\"code_unit_cid\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"code_unit_sha256\":\"f02ce76c3f523f3b48ad70bf3fe9b3513d4e2ddc17bd81b7558b7d30ab2dfb20\",\"execution_authority\":false,\"inverse_source_join_verified\":true,\"joined_program_sha256\":\"02da3cf4d9546ad8dd6771ed88048c59d6e041f99542681573dfc2752cfb341d\",\"original_metadata_retained\":true,\"original_program_modified\":false,\"original_program_sha256\":\"fda949f539b0d382feff6839af13f3566fe9af57fb0dd8847c280323c70c0311\",\"profile\":\"distributed-codeunit-source-program-lean/v1\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_candidate_replayed\":true,\"source_join\":{\"code_unit_cid\":\"bafkreihnwtaaxoixkf5zv7ho7mhgbxtgmry7ngum6tuw6uygfbmp67b5fi\",\"model_semantics_changed\":false,\"original_program_id\":\"bafkreibyj2ugewbtorxkoesz4ydtjnarwx4bycwexhlfbmf3jis2tuof6y\",\"original_program_sha256\":\"fda949f539b0d382feff6839af13f3566fe9af57fb0dd8847c280323c70c0311\",\"original_source_identifier\":\"source:source.py\",\"polarity_inferred\":false,\"schema\":\"distributed-384-derived-program-source-join/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\"},\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"whole_program_semantics_verified\":false}"

def distributedCodeUnitSourceSemanticsVerified : Bool := false

def distributedCodeUnitPolarityVerified : Bool := false

def sourceEvidenceOriginalProgramSHA256 : String := "fda949f539b0d382feff6839af13f3566fe9af57fb0dd8847c280323c70c0311"

def sourceEvidenceOperationalViewSHA256 : String := "689707777b9c6fb7e32c125a99e00245e270e9197333ddffd7fe65b662198d57"

def sourceEvidenceSourceSHA256 : String := "10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9"

def sourceEvidenceMetadataJSON : String := "{\"adapter\":\"SourceSoftwareVerificationAdapter@1\",\"assumptions\":[\"The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.\",\"The mathematical integer model excludes resource exhaustion and concurrent environment changes.\",\"Native effects and purity retain the source adapter's conservative classification.\"],\"completion_authority\":false,\"effect_summary_assumption\":\"Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved.\",\"effect_summary_audit\":{\"base_program_id\":\"bafkreie7bulxk6pm4cks2npna6aoddfusfc7zd5yld23ejqgwrcajfhi5a\",\"base_program_sha256\":\"f08ccf47a343537889b1b47087d779ee2c8e623697db448282d22a5e4d7224f1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"},\"effect_summary_contract\":\"closed-command-expression-reads-and-assignment-writes/v1\",\"execution_authority\":false,\"input_type_basis\":\"explicit_int_annotations\",\"language\":\"python\",\"path\":\"source.py\",\"proof_authority\":false,\"security_specification_inferred\":false,\"source_binding_effects_schema\":\"security-source-program-effects-384/v2\",\"source_binding_schema\":\"security-source-program-binding-384/v1\",\"source_semantics_verified\":false,\"source_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"whole_program_semantics_verified\":false}"

def sourceEvidenceSourceReferencesJSON : String := "[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"10b91f530e244b6adcb9e14999de4e00a53d2988335fb9da06bf6ae0a682c3c9\",\"license_expression\":\"\",\"metadata\":{\"byte_length\":83,\"language\":\"python\",\"path\":\"source.py\"},\"ref_id\":\"source:source.py\",\"review_status\":\"unreviewed\",\"source_id\":\"source.py\",\"source_revision\":\"workspace:local\",\"source_uri\":\"file:///source.py\"}]"

def sourceEvidenceEffectAuditJSON : String := "{\"base_program_id\":\"bafkreie7bulxk6pm4cks2npna6aoddfusfc7zd5yld23ejqgwrcajfhi5a\",\"base_program_sha256\":\"f08ccf47a343537889b1b47087d779ee2c8e623697db448282d22a5e4d7224f1\",\"commands\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[],\"writes\":[]},\"command_id\":\"command:11\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"functions\":[{\"after\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"before\":{\"reads\":[\"symbol:derive.capacity.parameter\",\"symbol:derive.threshold.parameter\"],\"writes\":[]},\"function_id\":\"function:derive\",\"purity\":\"pure\",\"retained_effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"synchronizes\":false}}],\"schema\":\"security-source-program-effect-audit/v1\"}"

def sourceEvidenceAssumptions : List String := ["The annotation name int denotes exact built-in Python integers; annotations do not enforce runtime types.", "The mathematical integer model excludes resource exhaustion and concurrent environment changes.", "Native effects and purity retain the source adapter's conservative classification.", "Read/write summaries are derived from the validated expression graph; all other effect flags and the native purity classification are preserved."]

def sourceEvidence_proof_authority : Bool := false

def sourceEvidence_execution_authority : Bool := false

def sourceEvidence_completion_authority : Bool := false

def sourceEvidence_source_semantics_verified : Bool := false

def sourceEvidence_whole_program_semantics_verified : Bool := false

def sourceEvidence_security_specification_inferred : Bool := false

def sourceEvidence_commands_reads : List (String × List String) := [("command:11", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_commands_writes : List (String × List String) := [("command:11", [])]

def sourceEvidence_functions_reads : List (String × List String) := [("function:derive", ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"])]

def sourceEvidence_functions_writes : List (String × List String) := [("function:derive", [])]

set_option linter.unusedVariables false

structure Store where

  v0 : Int

  v1 : Bool

  v2 : Int

  deriving DecidableEq



inductive Outcome where

  | returned (store : Store) (value : Bool)

  | blocked

  | assertionFailure

  deriving DecidableEq

def expression_0 (initial current : Store) (returned : Bool) : Bool := (decide (current.v0 < current.v2))

def expression_1 (initial current : Store) (returned : Bool) : Int := current.v0

def expression_2 (initial current : Store) (returned : Bool) : Int := current.v2

def run (initial : Store) : Outcome :=
  let current := initial;
  Outcome.returned current (expression_0 initial current false)

def declaredReads (symbol : String) : Bool := ["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"].contains symbol

example : (["symbol:derive.capacity.parameter", "symbol:derive.threshold.parameter"] : List String).all declaredReads = true := by decide

def declaredWrites (symbol : String) : Bool := [].contains symbol

example : ([] : List String).all declaredWrites = true := by decide
end Projection_9

namespace Projection_11
set_option linter.unusedVariables false
structure SymbolicConfiguration (Store : Type) where
  node : String
  values : Store
  deriving DecidableEq, Repr
structure SymbolicSystem (Store : Type) where
  valid : SymbolicConfiguration Store → Bool
  initial : SymbolicConfiguration Store → Bool
  terminal : SymbolicConfiguration Store → Bool
  visible : SymbolicConfiguration Store → String → SymbolicConfiguration Store → Bool
  silent : SymbolicConfiguration Store → SymbolicConfiguration Store → Bool
-- A trailing match has zero or more explicitly declared silent steps and
-- exactly one visible action. Every silent or visible edge consumes one unit.
def symbolicVisibleMatch {Store : Type} (system : SymbolicSystem Store) :
    Nat → SymbolicConfiguration Store → String → SymbolicConfiguration Store → Prop
  | 0, _, _, _ => False
  | budget + 1, before, label, after =>
      system.visible before label after = true ∨
      ∃ middle, system.silent before middle = true ∧
        symbolicVisibleMatch system budget middle label after

def boundedSymbolicMatch {Left Right : Type}
    (leading : SymbolicSystem Left) (trailing : SymbolicSystem Right)
    (related : SymbolicConfiguration Left → SymbolicConfiguration Right → Prop)
    (matchingLimit : Nat) : Nat → SymbolicConfiguration Left → SymbolicConfiguration Right → Prop
  | 0, left, right => related left right
  | steps + 1, left, right =>
      related left right ∧ ∀ label next,
        leading.visible left label next = true →
        ∃ other, symbolicVisibleMatch trailing matchingLimit right label other ∧
          boundedSymbolicMatch leading trailing related matchingLimit steps next other

def boundedSymbolicSimulation {Left Right : Type}
    (leading : SymbolicSystem Left) (trailing : SymbolicSystem Right)
    (related : SymbolicConfiguration Left → SymbolicConfiguration Right → Prop)
    (matchingLimit scheduleLimit : Nat) : Prop :=
  (∃ state, leading.initial state = true) ∧
  (∃ state, trailing.initial state = true) ∧
  (∀ left, leading.initial left = true → ∃ right, trailing.initial right = true ∧
    boundedSymbolicMatch leading trailing related matchingLimit scheduleLimit left right) ∧
  (∀ left right, related left right →
    boundedSymbolicMatch leading trailing related matchingLimit scheduleLimit left right)

theorem zero_matching_budget_rejects_visible_action {Store : Type}
    (system : SymbolicSystem Store) (before after : SymbolicConfiguration Store) (label : String) :
    ¬ symbolicVisibleMatch system 0 before label after := by
  simp [symbolicVisibleMatch]

def sourceProgramRefinementProved : Bool := false
def unboundedRefinementClaimed : Bool := false


namespace System_0

structure Store where
  deriving DecidableEq, Repr

abbrev Configuration := SymbolicConfiguration Store

def statePredicate_0 (s : Store) : Bool := true

def statePredicate_1 (s : Store) : Bool := true

def valid (state : Configuration) : Bool := ((state.node == "abs:off") && (statePredicate_0 state.values)) || ((state.node == "abs:on") && (statePredicate_1 state.values))

def initial (state : Configuration) : Bool := valid state && ["abs:off"].contains state.node

def terminal (state : Configuration) : Bool := valid state && [].contains state.node

def edgeRelation_0 (before after : Store) : Bool := true

def edge_0 (before after : Configuration) : Bool := (before.node == "abs:on") && (after.node == "abs:off") && (valid before) && (valid after) && (edgeRelation_0 before.values after.values)

def edgeRelation_1 (before after : Store) : Bool := true

def edge_1 (before after : Configuration) : Bool := (before.node == "abs:off") && (after.node == "abs:on") && (valid before) && (valid after) && (edgeRelation_1 before.values after.values)

def visible (before : Configuration) (label : String) (after : Configuration) : Bool := ((label == "disable") && (edge_0 before after)) || ((label == "enable") && (edge_1 before after))

def silent (before after : Configuration) : Bool := false

def system : SymbolicSystem Store := ⟨valid, initial, terminal, visible, silent⟩

def initialWitness : Configuration := ⟨"abs:off", {  }⟩

example : initial initialWitness = true := by decide

end System_0

namespace System_1

structure Store where
  v0 : Int
  deriving DecidableEq, Repr

abbrev Configuration := SymbolicConfiguration Store

def statePredicate_0 (s : Store) : Bool := (decide (s.v0 = (0 : Int)))

def statePredicate_1 (s : Store) : Bool := (decide (s.v0 = (1 : Int)))

def statePredicate_2 (s : Store) : Bool := (decide (s.v0 ≥ (2 : Int)))

def valid (state : Configuration) : Bool := ((state.node == "con:0") && (statePredicate_0 state.values)) || ((state.node == "con:1") && (statePredicate_1 state.values)) || ((state.node == "con:2") && (statePredicate_2 state.values))

def initial (state : Configuration) : Bool := valid state && ["con:0"].contains state.node

def terminal (state : Configuration) : Bool := valid state && [].contains state.node

def edgeRelation_0 (before after : Store) : Bool := (decide (after.v0 = (before.v0 + (1 : Int))))

def edge_0 (before after : Configuration) : Bool := (before.node == "con:0") && (after.node == "con:1") && (valid before) && (valid after) && (edgeRelation_0 before.values after.values)

def edgeRelation_1 (before after : Store) : Bool := (decide (after.v0 = (before.v0 + (1 : Int))))

def edge_1 (before after : Configuration) : Bool := (before.node == "con:1") && (after.node == "con:2") && (valid before) && (valid after) && (edgeRelation_1 before.values after.values)

def edgeRelation_2 (before after : Store) : Bool := (decide (after.v0 = (0 : Int)))

def edge_2 (before after : Configuration) : Bool := (before.node == "con:1") && (after.node == "con:0") && (valid before) && (valid after) && (edgeRelation_2 before.values after.values)

def edgeRelation_3 (before after : Store) : Bool := (decide (after.v0 = (0 : Int)))

def edge_3 (before after : Configuration) : Bool := (before.node == "con:2") && (after.node == "con:0") && (valid before) && (valid after) && (edgeRelation_3 before.values after.values)

def edgeRelation_4 (before after : Store) : Bool := (decide (after.v0 = before.v0))

def edge_4 (before after : Configuration) : Bool := (before.node == "con:2") && (after.node == "con:2") && (valid before) && (valid after) && (edgeRelation_4 before.values after.values)

def visible (before : Configuration) (label : String) (after : Configuration) : Bool := ((label == "enable") && (edge_0 before after)) || ((label == "enable") && (edge_1 before after)) || ((label == "disable") && (edge_2 before after)) || ((label == "disable") && (edge_3 before after))

def silent (before after : Configuration) : Bool := (edge_4 before after)

def system : SymbolicSystem Store := ⟨valid, initial, terminal, visible, silent⟩

def initialWitness : Configuration := ⟨"con:0", { v0 := (0 : Int) }⟩

example : initial initialWitness = true := by decide

end System_1

def related_0 (left : System_0.Configuration) (right : System_1.Configuration) : Prop :=
  System_0.valid left = true ∧ System_1.valid right = true ∧ ((left.node = "abs:off" ∧ right.node = "con:0") ∨ (left.node = "abs:on" ∧ right.node = "con:1") ∨ (left.node = "abs:on" ∧ right.node = "con:2"))

def simulation_0 (scheduleLimit : Nat) : Prop := boundedSymbolicSimulation System_0.system System_1.system related_0 4 scheduleLimit

def obligation_0 : Prop := simulation_0 16

def originalRefinementDeclaration : List String := ["{\"boundedness\":[{\"attributes\":{},\"boundedness_id\":\"bound:steps-16\",\"claims_unbounded_refinement\":false,\"kind\":\"bounded\",\"max_states\":null,\"max_steps\":16,\"schema_version\":\"refinement-boundedness/v1\",\"statement\":\"At most 16 refinement matching steps.\"}],\"document_id\":\"bafkreiez2r7wsvzszqam7znnmwph4zemcvaegodbdyoxxnbyrdnq6ekt7y\",\"interface\":\"RefinementIR@1\",\"metadata\":{\"example\":\"flag-counter\"},\"obligations\":[{\"abstract_system_id\":\"sys:abstract-flag\",\"attributes\":{},\"boundedness_id\":\"bound:steps-16\",\"claims_unbounded_refinement\":false,\"concrete_system_id\":\"sys:concrete-counter\",\"kind\":\"simulation\",\"obligation_id\":\"obl:sim\",\"schema_version\":\"refinement-obligation/v1\",\"simulation_relation_id\":\"sim:forward\",\"statement\":\"Concrete counter forward-simulates the abstract flag.\"}],\"schema_version\":\"refinement-ir/v1\",\"simulations\":[{\"abstract_system_id\":\"sys:abstract-flag\",\"attributes\":{},\"claims_unbounded_refinement\":false,\"concrete_system_id\":\"sys:concrete-counter\",\"couples\":[{\"abstract_state_id\":\"abs:off\",\"attributes\":{},\"concrete_state_id\":\"con:0\",\"couple_id\":\"c:off-0\",\"schema_version\":\"simulation-couple/v1\",\"statement\":\"related\"},{\"abstract_state_id\":\"abs:on\",\"attributes\":{},\"concrete_state_id\":\"con:1\",\"couple_id\":\"c:on-1\",\"schema_version\":\"simulation-couple/v1\",\"statement\":\"related\"},{\"abstract_state_id\":\"abs:on\",\"attributes\":{},\"concrete_state_id\":\"con:2\",\"couple_id\":\"c:on-2\",\"schema_version\":\"simulation-couple/v1\",\"statement\":\"related\"}],\"direction\":\"forward\",\"max_matching_steps\":4,\"relation_id\":\"sim:forward\",\"schema_version\":\"simulation-relation/v1\",\"statement\":\"counter refines flag\"}],\"systems\":[{\"attributes\":{},\"concurrency_document_id\":\"\",\"level\":\"abstract\",\"name\":\"AbstractFlag\",\"schema_version\":\"refinement-system/v1\",\"states\":[{\"attributes\":{},\"is_initial\":true,\"is_terminal\":false,\"label\":\"off\",\"predicate_statement\":\"true\",\"schema_version\":\"refinement-state/v1\",\"state_id\":\"abs:off\"},{\"attributes\":{},\"is_initial\":false,\"is_terminal\":false,\"label\":\"on\",\"predicate_statement\":\"true\",\"schema_version\":\"refinement-state/v1\",\"state_id\":\"abs:on\"}],\"system_id\":\"sys:abstract-flag\",\"transitions\":[{\"action_label\":\"disable\",\"attributes\":{},\"is_stutter\":false,\"schema_version\":\"refinement-transition/v1\",\"source_state_id\":\"abs:on\",\"target_state_id\":\"abs:off\",\"transition_id\":\"abs:t-off\"},{\"action_label\":\"enable\",\"attributes\":{},\"is_stutter\":false,\"schema_version\":\"refinement-transition/v1\",\"source_state_id\":\"abs:off\",\"target_state_id\":\"abs:on\",\"transition_id\":\"abs:t-on\"}]},{\"attributes\":{},\"concurrency_document_id\":\"\",\"level\":\"concrete\",\"name\":\"ConcreteCounter\",\"schema_version\":\"refinement-system/v1\",\"states\":[{\"attributes\":{},\"is_initial\":true,\"is_terminal\":false,\"label\":\"zero\",\"predicate_statement\":\"n = 0\",\"schema_version\":\"refinement-state/v1\",\"state_id\":\"con:0\"},{\"attributes\":{},\"is_initial\":false,\"is_terminal\":false,\"label\":\"one\",\"predicate_statement\":\"n = 1\",\"schema_version\":\"refinement-state/v1\",\"state_id\":\"con:1\"},{\"attributes\":{},\"is_initial\":false,\"is_terminal\":false,\"label\":\"two\",\"predicate_statement\":\"n >= 2\",\"schema_version\":\"refinement-state/v1\",\"state_id\":\"con:2\"}],\"system_id\":\"sys:concrete-counter\",\"transitions\":[{\"action_label\":\"enable\",\"attributes\":{},\"is_stutter\":false,\"schema_version\":\"refinement-transition/v1\",\"source_state_id\":\"con:0\",\"target_state_id\":\"con:1\",\"transition_id\":\"con:inc0\"},{\"action_label\":\"enable\",\"attributes\":{},\"is_stutter\":false,\"schema_version\":\"refinement-transition/v1\",\"source_state_id\":\"con:1\",\"target_state_id\":\"con:2\",\"transition_id\":\"con:inc1\"},{\"action_label\":\"disable\",\"attributes\":{},\"is_stutter\":false,\"schema_version\":\"refinement-transition/v1\",\"source_state_id\":\"con:1\",\"target_state_id\":\"con:0\",\"transition_id\":\"con:reset\"},{\"action_label\":\"disable\",\"attributes\":{},\"is_stutter\":false,\"schema_version\":\"refinement-transition/v1\",\"source_state_id\":\"con:2\",\"target_state_id\":\"con:0\",\"transition_id\":\"con:reset2\"},{\"action_label\":\"tau\",\"attributes\":{},\"is_stutter\":true,\"schema_version\":\"refinement-transition/v1\",\"source_state_id\":\"con:2\",\"target_state_id\":\"con:2\",\"transition_id\":\"con:stutter2\"}]}]}"]

def explicitRefinementInterpretation : List String := ["{\"metadata_annotation\":{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"metadata\":{\"example\":\"flag-counter\"},\"role\":\"descriptive_annotation\"},\"native_document_sha256\":\"ab597a8d2f2b367f09353231056e9d065f677b1a9be1e3a72e15cf4dba0b9d4c\",\"schema\":\"native-symbolic-refinement-interpretation/v1\",\"statement_bindings\":[{\"collection\":\"simulations\",\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"record_id\":\"sim:forward\",\"semantics\":\"simulation\",\"statement\":\"counter refines flag\"},{\"collection\":\"obligations\",\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"record_id\":\"obl:sim\",\"semantics\":\"simulation\",\"statement\":\"Concrete counter forward-simulates the abstract flag.\"},{\"collection\":\"boundedness\",\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"record_id\":\"bound:steps-16\",\"semantics\":\"bounded_simulation\",\"statement\":\"At most 16 refinement matching steps.\"}],\"systems\":[{\"expression_program\":{\"commands\":[{\"attributes\":{},\"command_id\":\"interpretation:carrier:return\",\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[],\"synchronizes\":false,\"writes\":[]},\"evaluation_order\":[\"interpretation:carrier:true\"],\"expression_ids\":[\"interpretation:carrier:true\"],\"kind\":\"return\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"target_symbol_ids\":[],\"undefined_behavior\":[]}],\"expressions\":[{\"attributes\":{\"value\":true},\"evaluation_order\":[],\"expression_id\":\"interpretation:carrier:true\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{\"value\":true},\"evaluation_order\":[],\"expression_id\":\"truth\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"}],\"functions\":[{\"cfg\":{\"blocks\":[{\"block_id\":\"interpretation:carrier:block\",\"command_ids\":[\"interpretation:carrier:return\"],\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[]}],\"edges\":[],\"entry_block_id\":\"interpretation:carrier:block\",\"exceptional_exit_block_ids\":[],\"graph_id\":\"interpretation:carrier:cfg\",\"normal_exit_block_ids\":[\"interpretation:carrier:block\"]},\"declared_exceptions\":[],\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[],\"synchronizes\":false,\"writes\":[]},\"exception_symbol_ids\":[],\"function_id\":\"interpretation:carrier:function\",\"local_symbol_ids\":[],\"name\":\"InterpretationExpressionCarrier\",\"parameter_symbol_ids\":[],\"purity\":\"pure\",\"result_symbol_id\":\"\",\"return_type\":\"boolean\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[]}],\"global_symbol_ids\":[],\"metadata\":{},\"program_id\":\"bafkreiayxhyqhrwnxzkz6nhmt4apzoog25ymttmjptmassbygbbor26pjq\",\"schema_version\":\"program-ir/v1\",\"sources\":[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"ab597a8d2f2b367f09353231056e9d065f677b1a9be1e3a72e15cf4dba0b9d4c\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"source:counter-native\",\"review_status\":\"unreviewed\",\"source_id\":\"counter-refinement-native-declaration\",\"source_revision\":\"v1\",\"source_uri\":\"urn:authored:counter-refinement-interpretation\"}],\"spans\":[],\"symbols\":[]},\"initial_witness\":{\"state_id\":\"abs:off\",\"values\":{}},\"state_predicates\":[{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"truth\",\"state_id\":\"abs:off\",\"statement\":\"true\"},{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"truth\",\"state_id\":\"abs:on\",\"statement\":\"true\"}],\"system_id\":\"sys:abstract-flag\",\"transition_relations\":[{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"truth\",\"semantics\":\"caller_declared_before_after_relation\",\"transition_id\":\"abs:t-off\"},{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"truth\",\"semantics\":\"caller_declared_before_after_relation\",\"transition_id\":\"abs:t-on\"}]},{\"expression_program\":{\"commands\":[{\"attributes\":{},\"command_id\":\"interpretation:carrier:return\",\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[],\"synchronizes\":false,\"writes\":[]},\"evaluation_order\":[\"interpretation:carrier:true\"],\"expression_ids\":[\"interpretation:carrier:true\"],\"kind\":\"return\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"target_symbol_ids\":[],\"undefined_behavior\":[]}],\"expressions\":[{\"attributes\":{},\"evaluation_order\":[\"n\",\"zero\"],\"expression_id\":\"eq0\",\"kind\":\"binary\",\"operand_ids\":[\"n\",\"zero\"],\"operator\":\"eq\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"n\",\"one\"],\"expression_id\":\"eq1\",\"kind\":\"binary\",\"operand_ids\":[\"n\",\"one\"],\"operator\":\"eq\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{\"value\":false},\"evaluation_order\":[],\"expression_id\":\"falsity\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"n\",\"two\"],\"expression_id\":\"ge2\",\"kind\":\"binary\",\"operand_ids\":[\"n\",\"two\"],\"operator\":\"ge\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"oldn\",\"one\"],\"expression_id\":\"increment\",\"kind\":\"binary\",\"operand_ids\":[\"oldn\",\"one\"],\"operator\":\"add\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{\"value\":true},\"evaluation_order\":[],\"expression_id\":\"interpretation:carrier:true\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[],\"expression_id\":\"n\",\"kind\":\"symbol\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[\"n\"],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[\"n\"],\"expression_id\":\"oldn\",\"kind\":\"old\",\"operand_ids\":[\"n\"],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{\"value\":1},\"evaluation_order\":[],\"expression_id\":\"one\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{\"value\":true},\"evaluation_order\":[],\"expression_id\":\"truth\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{\"value\":2},\"evaluation_order\":[],\"expression_id\":\"two\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"},{\"attributes\":{},\"evaluation_order\":[\"n\",\"increment\"],\"expression_id\":\"update_increment\",\"kind\":\"binary\",\"operand_ids\":[\"n\",\"increment\"],\"operator\":\"eq\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{},\"evaluation_order\":[\"n\",\"oldn\"],\"expression_id\":\"update_stutter\",\"kind\":\"binary\",\"operand_ids\":[\"n\",\"oldn\"],\"operator\":\"eq\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"boolean\"},{\"attributes\":{\"value\":0},\"evaluation_order\":[],\"expression_id\":\"zero\",\"kind\":\"literal\",\"operand_ids\":[],\"operator\":\"\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_ids\":[],\"type_ref\":\"integer\"}],\"functions\":[{\"cfg\":{\"blocks\":[{\"block_id\":\"interpretation:carrier:block\",\"command_ids\":[\"interpretation:carrier:return\"],\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[]}],\"edges\":[],\"entry_block_id\":\"interpretation:carrier:block\",\"exceptional_exit_block_ids\":[],\"graph_id\":\"interpretation:carrier:cfg\",\"normal_exit_block_ids\":[\"interpretation:carrier:block\"]},\"declared_exceptions\":[],\"effects\":{\"allocates\":[],\"deallocates\":[],\"nondeterministic\":false,\"performs_io\":false,\"raises\":[],\"reads\":[],\"synchronizes\":false,\"writes\":[]},\"exception_symbol_ids\":[],\"function_i", "d\":\"interpretation:carrier:function\",\"local_symbol_ids\":[],\"name\":\"InterpretationExpressionCarrier\",\"parameter_symbol_ids\":[],\"purity\":\"pure\",\"result_symbol_id\":\"\",\"return_type\":\"boolean\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[]}],\"global_symbol_ids\":[\"n\"],\"metadata\":{},\"program_id\":\"bafkreihousv4fhjju4jm7yqhi5rra4jyjfacsmpmj5qyclo5qz3dl3sfga\",\"schema_version\":\"program-ir/v1\",\"sources\":[{\"container_sha256\":\"\",\"container_uri\":\"\",\"content_cid\":\"\",\"content_sha256\":\"ab597a8d2f2b367f09353231056e9d065f677b1a9be1e3a72e15cf4dba0b9d4c\",\"license_expression\":\"\",\"metadata\":{},\"ref_id\":\"source:counter-native\",\"review_status\":\"unreviewed\",\"source_id\":\"counter-refinement-native-declaration\",\"source_revision\":\"v1\",\"source_uri\":\"urn:authored:counter-refinement-interpretation\"}],\"spans\":[],\"symbols\":[{\"attributes\":{},\"kind\":\"global\",\"name\":\"n\",\"source_ref_ids\":[\"source:counter-native\"],\"span_ids\":[],\"symbol_id\":\"n\",\"type_ref\":\"integer\"}]},\"initial_witness\":{\"state_id\":\"con:0\",\"values\":{\"n\":0}},\"state_predicates\":[{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"eq0\",\"state_id\":\"con:0\",\"statement\":\"n = 0\"},{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"eq1\",\"state_id\":\"con:1\",\"statement\":\"n = 1\"},{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"ge2\",\"state_id\":\"con:2\",\"statement\":\"n >= 2\"}],\"system_id\":\"sys:concrete-counter\",\"transition_relations\":[{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"update_increment\",\"semantics\":\"caller_declared_before_after_relation\",\"transition_id\":\"con:inc0\"},{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"update_increment\",\"semantics\":\"caller_declared_before_after_relation\",\"transition_id\":\"con:inc1\"},{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"eq0\",\"semantics\":\"caller_declared_before_after_relation\",\"transition_id\":\"con:reset\"},{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"eq0\",\"semantics\":\"caller_declared_before_after_relation\",\"transition_id\":\"con:reset2\"},{\"evidence_ref\":\"urn:authored:counter-refinement-interpretation:v1\",\"expression_id\":\"update_stutter\",\"semantics\":\"caller_declared_before_after_relation\",\"transition_id\":\"con:stutter2\"}]}]}"]
end Projection_11
end SecurityIR
